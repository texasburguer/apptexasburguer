# Etapa 10 — Leitor Fiscal IA

## Incluído
- `SUBIR-NO-GITHUB/app-28-leitor-fiscal.js`: cartão na área de IA administrativa, foto/XML/texto, conferência de itens/total, fornecedor, forma de pagamento e confirmação explícita.
- `SUPABASE/supabase-codigo/ajustes/2026-10-14-etapa10-leitor-fiscal.sql`: bucket privado, histórico, índice de duplicidade, RPCs restritas, retenção e ajuda.
- `SUPABASE/supabase-codigo/funcoes/leitor-fiscal`: leitura de foto com Gemini e leitura de texto com fallback Groq 2 → Groq → Gemini; leitura básica de XML NF-e.
- `SUPABASE/supabase-codigo/funcoes/fiscal-limpar`: remoção de arquivos e histórico expirados.
- Campos de chave `gemini_fotos` e `groq_2` incluídos no painel e nos SQL de integração.

## Regras de segurança
- Apenas Admin/Operador; o backend revalida o perfil.
- Fotos em bucket privado, JPEG reduzido no dispositivo, máximo 5 MB no upload.
- A IA propõe; compra/estoque/financeiro só são lançados depois da confirmação humana.
- Chave NF-e repetida e CNPJ da própria empresa são bloqueados no backend. A confirmação usa um identificador idempotente para reduzir risco de compra duplicada em repetição de rede.
- O cron de limpeza deve ser verificado após aplicar o SQL.

## Limitação conhecida
O banco de compras existente suporta `Pago` e `A pagar`, não pagamento dividido. Por segurança, essa opção não grava automaticamente: deve ser lançada manualmente até uma etapa específica ampliar o esquema financeiro. Também é necessário confirmar Compras recentes se o lançamento da compra funcionar mas o registro de histórico fiscal falhar.

## Aplicação manual
1. Revisar e executar o SQL de Etapa 10 em homologação.
2. Atualizar o `index.html`, `sw.js`, `app-11-admin-integracoes.js` e `app-28-leitor-fiscal.js`.
3. Implantar as Edge Functions `leitor-fiscal` e `fiscal-limpar` com `verify_jwt=false` e manter validação JWT/perfil dentro do código.
4. Cadastrar as chaves dedicadas nas Contas e acessos; a chave Gemini geral é fallback para foto.
5. Testar todos os cenários antes de produção.
