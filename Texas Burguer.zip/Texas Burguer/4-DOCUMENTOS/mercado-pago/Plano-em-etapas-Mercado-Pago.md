# Plano em etapas — Mercado Pago no Texas Burger

Base: Plano___Mercado_Pago_no_Texas_Burger.md (12/10/2026) · @Lucas

## Como vamos trabalhar

- Uma etapa por vez. Entrego os arquivos da etapa e só sigo depois da sua aprovação.
- A cada etapa entrego também este plano atualizado: etapa marcada como feita e com o código usado nela.
- Nada é aplicado no Supabase por mim. Eu apenas gero os códigos (SQL e Edge Functions) para você colar. Eles também vão na pasta SUPABASE do zip.
- A integração nasce **desligada**. Com ela desligada, o cardápio funciona exatamente como hoje.

## Andamento

| Etapa | O que é | Status |
| --- | --- | --- |
| 0 | Mapeamento do sistema atual | [x] feita e aprovada |
| 1 | Banco: estrutura | [x] feita e aprovada |
| 2 | Banco: funções | [x] feita e aprovada |
| 3 | Funções na nuvem (Edge Functions) | [x] feita e aprovada |
| 4 | Painel Admin: card Mercado Pago | [x] feita (aguardando sua aprovação) |
| 5 | Cardápio: telas de pagamento | [x] feita (aguardando sua aprovação) |
| 6 | Operação: pedidos, caixa, relatórios | [x] feita (aguardando sua aprovação) |
| 7 | Textos, LGPD e pacote v35 | [x] feita (aguardando sua aprovação) |
| 8 | Testes e conferência | [x] feita (aguardando sua aprovação) |
| 9 | Ligar de verdade (você) | [ ] |
| 10 | Leitor Fiscal IA (3 fases) | [x] preparada (aguardando sua aprovação) |
| 11 | Auditoria completa | [x] feita (aguardando sua aprovação) |
| 12 | Revisão do plano inteiro (etapas 1 a 11) e telas iguais à prévia | [x] feita (aguardando sua aprovação) |

Ordem geral: 1) Mercado Pago (etapas 0 a 9), 2) Leitor Fiscal IA, 3) auditoria completa.

## Decisões já tomadas

| Decisão | Valor |
| --- | --- |
| Formas online | Pix e cartão de crédito, pagos dentro do site |
| Formas na entrega | Dinheiro, maquininha (débito/crédito), Pix pelo QR da maquininha e Alelo |
| Parcelamento | Só 1x (à vista) |
| Validade do Pix | 15 minutos |
| Quando o pedido nasce | Só depois do pagamento aprovado |
| Reserva | Estoque, cupom e brinde são reservados na hora de finalizar |
| Pix vencido sem pagar | Reserva cancelada; estoque, cupom e brinde voltam; nada chega à cozinha |
| Aprovado sem estoque, Pix pago depois de vencer, cardápio ou caixa fechado | Nunca reembolsa sozinho. O pedido entra marcado "Pagamento a decidir" e o operador de caixa ou o Admin escolhe: seguir ou reembolsar |
| Reembolso ao cancelar | Nunca automático: quem decide é o operador de caixa ou o Admin |
| Mesas e balcão | Fora do pagamento online |
| Taxa do Mercado Pago | Por conta do restaurante, sem cobrar do cliente |
| CPF | Pedido só no cartão |
| E-mail do pagador | Pedido só no pagamento online (cliente logado em Minha conta) |
| Contingência da planilha | Não vale para pagamento online. Se o banco cair, só pagar na entrega |
| Função extra | `mp-status`, para consultar o pagamento de forma ativa |
| Se o Mercado Pago cair | A página avisa e oferece pagar na entrega |

**Ponto que o plano original dizia diferente:** a seção "O que muda na operação" falava que cancelar pedido pago dispara o reembolso pela API. Prevalece a decisão acima: o cancelamento de pedido pago abre a decisão de reembolso e quem confirma é o operador de caixa ou o Admin.

---

## Etapa 0 — Mapeamento do sistema atual

**Objetivo:** conhecer o que existe antes de mexer, para não criar um segundo caminho.

- Abrir o `Texas_Burguer.zip` e conferir `index.html`, funções do banco, `formas_pagamento`, `integracoes_config`, `integracoes_segredos`, `integracoes_log`, `_integ_checklist_def` e `api_integracoes_flags`.
- Mapear o fluxo atual de finalizar pedido: validação de itens, preços, cupom, brindes, estoque, fidelidade e envio ao WhatsApp.
- Conferir como iFood e Nota fiscal estão montados, para copiar o mesmo molde.
- Listar dúvidas antes de seguir.

**Entrega:** `Etapa-0-Mapeamento.md`.

**Status: feita e aprovada.** Código usado: nenhum (só leitura do zip, nada alterado nem aplicado). Principais achados: a chave "ligado" precisa de leitura pública para o cardápio; "aceita online" não pode ser exclusivo (o Pix aparece nos dois grupos da Prévia); reserva em tabela própria; já existe a tabela `reembolsos` com gatilho, que será reaproveitada. Dúvidas abertas no arquivo da Etapa 0.

## Etapa 1 — Banco: estrutura

**Objetivo:** criar só as peças novas, sem alterar nada existente (as migrações apenas adicionam).

- Tabela `pagamentos_online` (e `pagamentos_online_eventos`, para o mesmo aviso do Mercado Pago não ser processado duas vezes).
- Colunas novas em `formas_pagamento`: `aceita_online` (sem tirar a opção na entrega) e `tipo_online` (Pix ou crédito).
- Reserva do pedido em **tabela própria**, `pedidos_reserva`: guarda o carrinho já validado até a aprovação.
- Linha `mercadopago` desligada em `integracoes_config`, chaves novas em `integracoes_segredos` e os 5 passos do checklist da Prévia.
- Leitura pública `api_mp_config_publica` para o cardápio saber se está ligado (devolve só a chave pública, nunca segredo).

**Status: feita e aprovada.** Nada foi aplicado. Arquivos: `2026-10-13-mp-etapa1-estrutura.sql` (o código está logo abaixo) e `teste-mp-etapa1.sql` (não grava nada; termina com o erro "RELATORIO", que é o resultado).

**Escolhas desta etapa**

- As funções `_integ_checklist_def`, `_integ_pendencias` e `api_integracoes_flags` foram redefinidas partindo da **versão mais recente de cada uma** (a de `api_integracoes_flags` está em `imposto-e-ifood.sql`), só acrescentando o Mercado Pago.
- Modo Teste na tela = `homologacao` no banco, igual à Nota fiscal.
- Em modo Teste o cliente só vê o pagamento online se `testeNoCardapio` for true (padrão: não), para ninguém tentar pagar de verdade com chave de teste.
- Cadastro do cartão: nada é guardado além dos 4 últimos dígitos e a bandeira. CPF e e-mail do pagador não são gravados.
- Ainda **não** mexe em `api_integracoes_salvar_segredo`, `ligar`, `desligar`, `config`, `status` nem em `_saude_integracoes`: isso é a Etapa 4. Até lá o card não aparece na tela e o botão Ligar do Mercado Pago não existe.
- Não consegui rodar o SQL num Postgres aqui. Ele foi revisado à mão contra o código do pacote; o `teste-mp-etapa1.sql` serve para você conferir depois de colar.

**Código usado**

```sql
-- =====================================================================================
-- MERCADO PAGO · ETAPA 1 (estrutura do banco) · 2026-10-13 · NÃO APLICADO
-- Só ADICIONA. Nada existente é apagado e o cardápio continua igual: a integração nasce DESLIGADA.
-- Rode DEPOIS do SUBIR-TUDO-supabase.sql e dos ajustes de 11 e 12/10. Pode rodar de novo (idempotente).
-- Cole inteiro no SQL Editor do Supabase. Para conferir depois, rode testes/teste-mp-etapa1.sql.
-- =====================================================================================
begin;

-- ---------- 1) O Mercado Pago entra no molde das integrações (iFood e Nota fiscal) ----------
do $d$
declare c record;
begin
  for c in select conname from pg_constraint where conrelid = 'public.integracoes_config'::regclass and contype = 'c' and pg_get_constraintdef(oid) like '%provedor%' loop
    execute format('alter table public.integracoes_config drop constraint %I', c.conname);
  end loop;
  alter table public.integracoes_config add constraint integracoes_config_provedor_check
    check (provedor in ('ifood', 'nfce', 'mercadopago'));

  for c in select conname from pg_constraint where conrelid = 'public.integracoes_segredos'::regclass and contype = 'c' and pg_get_constraintdef(oid) like '%chave%' loop
    execute format('alter table public.integracoes_segredos drop constraint %I', c.conname);
  end loop;
  alter table public.integracoes_segredos add constraint integracoes_segredos_chave_check
    check (chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id', 'nfce_token_homologacao', 'nfce_token_producao', 'nfce_csc',
                     'mp_public_key_teste', 'mp_public_key_producao', 'mp_access_token_teste', 'mp_access_token_producao', 'mp_webhook_secret'));
end $d$;

-- modo 'homologacao' = Teste na tela. pixValidadeMin = validade do Pix na tela do cliente (minutos).
-- testeNoCardapio = só com true o cliente vê o pagamento online enquanto o modo for Teste (padrão: não).
insert into public.integracoes_config (provedor, modo, config) values
  ('mercadopago', 'homologacao', '{"pixValidadeMin": 15, "testeNoCardapio": false}'::jsonb)
on conflict (provedor) do nothing;

-- ---------- 2) Formas de pagamento: quais aceitam pagar online (a forma continua valendo na entrega) ----------
alter table public.formas_pagamento
  add column if not exists aceita_online boolean not null default false,
  add column if not exists tipo_online text;

do $d$
begin
  if not exists (select 1 from pg_constraint where conrelid = 'public.formas_pagamento'::regclass and conname = 'formas_pagamento_tipo_online_check') then
    alter table public.formas_pagamento add constraint formas_pagamento_tipo_online_check
      check (tipo_online is null or tipo_online in ('pix', 'credito'));
  end if;
  if not exists (select 1 from pg_constraint where conrelid = 'public.formas_pagamento'::regclass and conname = 'formas_pagamento_online_exige_tipo') then
    alter table public.formas_pagamento add constraint formas_pagamento_online_exige_tipo
      check (not aceita_online or tipo_online is not null);
  end if;
end $d$;

-- ---------- 3) Reserva do pedido (o pedido só vira venda depois do pagamento aprovado) ----------
create table if not exists public.pedidos_reserva (
  id uuid primary key default gen_random_uuid(),
  requisicao_id text unique,                                   -- id da tentativa enviado pela página: repetir não duplica
  user_id uuid not null,                                       -- conta do cliente (pagar online exige login)
  estado text not null default 'ativa' check (estado in ('ativa', 'confirmada', 'expirada', 'cancelada')),
  cliente_nome text not null default '',
  telefone text not null default '',
  tipo_entrega text not null default '',
  forma_pagamento_id uuid references public.formas_pagamento(id) on delete set null,
  dados_entrega jsonb,                                         -- endereço, número, cidade, complemento, referência (como a venda usa)
  observacoes text not null default '',
  itens jsonb not null,                                        -- itens JÁ validados no servidor (preço, custo, adicionais), no formato da venda
  beneficios jsonb not null default '[]'::jsonb,               -- brindes da conta incluídos no pedido
  cupom jsonb,                                                 -- resultado do cálculo do cupom (null = sem cupom)
  valor_original numeric(12,2) not null default 0,
  valor_desconto numeric(12,2) not null default 0,
  taxa_entrega numeric(12,2) not null default 0,
  acrescimo_forma numeric(12,2) not null default 0,
  valor_total numeric(12,2) not null check (valor_total > 0),
  custo_total numeric(12,2) not null default 0,
  estoque_reservado boolean not null default false,            -- true = a baixa de estoque está feita neste momento
  cupom_uso_id uuid,                                           -- linha reservada em cupons_usos (se houver cupom)
  brindes_reservados boolean not null default false,
  venda_id uuid references public.vendas(id) on delete set null,
  motivo_fim text not null default '',
  expira_em timestamptz not null,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
create index if not exists pedidos_reserva_ativas_idx on public.pedidos_reserva (expira_em) where estado = 'ativa';
create index if not exists pedidos_reserva_user_idx on public.pedidos_reserva (user_id, criado_em desc);
create index if not exists pedidos_reserva_venda_idx on public.pedidos_reserva (venda_id);
alter table public.pedidos_reserva enable row level security;   -- sem policy: só funções seguras e a chave de serviço

-- ---------- 4) Pagamentos online (um pedido no Mercado Pago por tentativa) ----------
create table if not exists public.pagamentos_online (
  id uuid primary key default gen_random_uuid(),
  reserva_id uuid not null references public.pedidos_reserva(id),
  venda_id uuid references public.vendas(id) on delete set null,
  user_id uuid,
  metodo text not null check (metodo in ('pix', 'credito')),
  mp_modo text not null check (mp_modo in ('homologacao', 'producao')),   -- modo em que o pagamento foi criado
  mp_order_id text unique,
  mp_payment_id text,
  status text not null default 'aguardando'
    check (status in ('aguardando', 'aprovado', 'recusado', 'expirado', 'cancelado', 'reembolso_parcial', 'reembolsado', 'erro')),
  status_detalhe text not null default '',
  valor numeric(12,2) not null check (valor > 0),
  valor_reembolsado numeric(12,2) not null default 0 check (valor_reembolsado >= 0),
  pix_copia_cola text,
  pix_qr_base64 text,
  pix_expira_em timestamptz,
  cartao_final text,                                            -- só os 4 últimos dígitos, se vierem
  cartao_bandeira text,
  aprovado_em timestamptz,
  decisao_pendente boolean not null default false,              -- "Pagamento a decidir": operador de caixa ou Admin escolhe
  decisao_motivo text not null default '',
  decisao text check (decisao is null or decisao in ('seguir', 'reembolsar')),
  decidido_por uuid,
  decidido_em timestamptz,
  erro text not null default '',
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
create index if not exists pagamentos_online_reserva_idx on public.pagamentos_online (reserva_id);
create index if not exists pagamentos_online_venda_idx on public.pagamentos_online (venda_id);
create index if not exists pagamentos_online_status_idx on public.pagamentos_online (status, criado_em desc);
create index if not exists pagamentos_online_decidir_idx on public.pagamentos_online (criado_em desc) where decisao_pendente and decisao is null;
create index if not exists pagamentos_online_mp_payment_idx on public.pagamentos_online (mp_payment_id);
alter table public.pagamentos_online enable row level security;

-- avisos (webhook) já recebidos: o mesmo aviso repetido não é processado duas vezes
create table if not exists public.pagamentos_online_eventos (
  id bigserial primary key,
  chave text not null unique,                                  -- identifica o aviso (definida na função mp-webhook)
  pagamento_id uuid references public.pagamentos_online(id) on delete cascade,
  tipo text not null default '',
  status_mp text not null default '',
  assinatura_ok boolean not null default false,
  detalhe jsonb,
  recebido_em timestamptz not null default now()
);
create index if not exists pagamentos_online_eventos_pag_idx on public.pagamentos_online_eventos (pagamento_id, recebido_em desc);
alter table public.pagamentos_online_eventos enable row level security;

-- as tabelas novas só são lidas/gravadas por funções seguras (security definer) e pela chave de serviço
revoke all on public.pedidos_reserva, public.pagamentos_online, public.pagamentos_online_eventos from anon, authenticated;
revoke all on sequence public.pagamentos_online_eventos_id_seq from anon, authenticated;

-- ---------- 5) Checklist do cartão Mercado Pago (mesmos itens da Prévia) ----------
-- Atenção: as duas funções abaixo partem das versões mais recentes (SUBIR-TUDO / f4) e só acrescentam o 'mercadopago'.
create or replace function public._integ_checklist_def(p_prov text) returns jsonb
 language sql immutable set search_path to 'public' as $f$
  select case p_prov
    when 'ifood' then '[
      {"id":"conta_dev","titulo":"O dono criou a conta de desenvolvedor no iFood (precisa do CNPJ)"},
      {"id":"acesso","titulo":"Acesso liberado aos módulos Pedidos, Catálogo, Loja, Financeiro e Avaliações"},
      {"id":"chaves","titulo":"Client ID, Client Secret e código da loja digitados aqui","auto":true},
      {"id":"teste_conexao","titulo":"Teste de conexão deu certo","auto":true},
      {"id":"homologacao","titulo":"Homologação do iFood aprovada"},
      {"id":"itens","titulo":"Itens do iFood ligados aos produtos (aba Itens do iFood)"},
      {"id":"equipe","titulo":"Equipe avisada de como o pedido do iFood aparece"}]'::jsonb
    when 'nfce' then '[
      {"id":"contador","titulo":"O contador definiu NCM, CFOP e situação tributária de cada perfil"},
      {"id":"certificado","titulo":"Certificado digital A1 do restaurante pronto"},
      {"id":"sefaz","titulo":"Credenciamento na Sefaz-SP feito e CSC (código de segurança) obtido"},
      {"id":"focus","titulo":"Conta na Focus NFe criada e empresa cadastrada lá (com o certificado)"},
      {"id":"token","titulo":"Token da Focus digitado aqui","auto":true},
      {"id":"empresa","titulo":"Dados fiscais da empresa preenchidos aqui","auto":true},
      {"id":"perfis","titulo":"Todos os produtos têm perfil fiscal","auto":true},
      {"id":"nota_teste","titulo":"Nota de teste (homologação) emitida e conferida pelo contador"}]'::jsonb
    when 'mercadopago' then '[
      {"id":"conta_vendedor","titulo":"Conta de vendedor criada no Mercado Pago (com a verificação de identidade)"},
      {"id":"chaves_teste","titulo":"Chaves de teste coladas","auto":true},
      {"id":"webhook","titulo":"Endereço do aviso (webhook) cadastrado no Mercado Pago","auto":true},
      {"id":"teste_guiado","titulo":"Teste guiado feito (Pix e cartão)","auto":true},
      {"id":"chaves_producao","titulo":"Chaves de produção coladas","auto":true}]'::jsonb
    else '[]'::jsonb end
$f$;

create or replace function public._integ_pendencias(p_prov text, p_modo text) returns text[]
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_out text[] := '{}'; v_item jsonb; v_ck jsonb; v_ok boolean;
begin
  select checklist into v_ck from integracoes_config where provedor = p_prov;
  for v_item in select * from jsonb_array_elements(_integ_checklist_def(p_prov)) loop
    if coalesce((v_item->>'auto')::boolean, false) then
      v_ok := case v_item->>'id'
        when 'chaves' then (select count(*) from integracoes_segredos where chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id')) = 3
        when 'token' then exists (select 1 from integracoes_segredos where chave = 'nfce_token_' || p_modo)
        when 'empresa' then public._fiscal_empresa_ok()
        when 'perfis' then public._fiscal_perfis_ok()
        when 'chaves_teste' then (select count(*) from integracoes_segredos where chave in ('mp_public_key_teste', 'mp_access_token_teste')) = 2
        when 'webhook' then exists (select 1 from integracoes_segredos where chave = 'mp_webhook_secret')
        when 'teste_guiado' then exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'pix' and status in ('aprovado', 'reembolso_parcial', 'reembolsado'))
                             and exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'credito' and status in ('aprovado', 'reembolso_parcial', 'reembolsado'))
        when 'chaves_producao' then (select count(*) from integracoes_segredos where chave in ('mp_public_key_producao', 'mp_access_token_producao')) = 2
        else coalesce((v_ck->>(v_item->>'id'))::boolean, false) end;
    else
      v_ok := coalesce((v_ck->>(v_item->>'id'))::boolean, false);
    end if;
    if not v_ok then v_out := v_out || (v_item->>'titulo'); end if;
  end loop;
  return v_out;
end $f$;

-- ---------- 6) Flags para a equipe: ganha 'mercadopago' (parte da versão mais recente, de imposto-e-ifood) ----------
create or replace function public.api_integracoes_flags(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public'
as $function$
declare v_adm boolean := tem_nivel('Admin');
begin
  if auth_nivel() is null then return _negado(); end if;
  return jsonb_build_object('ok', true, 'ifood', _integracao_ligada('ifood'), 'nfce', _integracao_ligada('nfce'),
    'mercadopago', _integracao_ligada('mercadopago'),
    'nfceModo', (select modo from integracoes_config where provedor = 'nfce'),
    'impostoPct', case when v_adm then _imposto_pct(current_date) else 0 end,
    'impostoPadrao', case when v_adm then coalesce((select aliquota_simples from fiscal_empresa where id), 0) else 0 end,
    'impostoMeses', case when v_adm then coalesce((select valor from sistema where chave = 'ImpostoAliquotasMes' and jsonb_typeof(valor) = 'object'), '{}'::jsonb) else '{}'::jsonb end);
end $function$;

-- ---------- 7) Leitura PÚBLICA para o cardápio (cliente sem login de equipe) ----------
-- Desligado, ou sem chave pública, ou sem forma online: devolve só {ligado:false}. Nunca devolve segredo (só a chave PÚBLICA).
-- Em modo Teste o cliente só vê o pagamento online se "testeNoCardapio" estiver true.
create or replace function public.api_mp_config_publica(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare c integracoes_config%rowtype; v_prod boolean; v_pk text; v_formas jsonb; v_min int;
begin
  select * into c from integracoes_config where provedor = 'mercadopago';
  if c.provedor is null or not c.ligado then return jsonb_build_object('ok', true, 'ligado', false); end if;
  v_prod := (c.modo = 'producao');
  if not v_prod and coalesce((c.config->>'testeNoCardapio')::boolean, false) is not true then return jsonb_build_object('ok', true, 'ligado', false); end if;
  select valor into v_pk from integracoes_segredos where chave = case when v_prod then 'mp_public_key_producao' else 'mp_public_key_teste' end;
  select coalesce(jsonb_agg(jsonb_build_object('id', f.id, 'tipo', f.tipo_online) order by f.ordem), '[]'::jsonb) into v_formas
    from formas_pagamento f where f.ativa and f.visivel_cardapio and f.aceita_online and f.tipo_online is not null;
  if v_pk is null or jsonb_array_length(v_formas) = 0 then return jsonb_build_object('ok', true, 'ligado', false); end if;
  v_min := case when coalesce(c.config->>'pixValidadeMin', '') ~ '^[0-9]{1,3}$' then least(120, greatest(5, (c.config->>'pixValidadeMin')::int)) else 15 end;
  return jsonb_build_object('ok', true, 'ligado', true, 'modo', case when v_prod then 'producao' else 'teste' end,
    'publicKey', v_pk, 'formas', v_formas, 'pixValidadeMin', v_min);
end $f$;
revoke all on function public.api_mp_config_publica(jsonb) from public, anon, authenticated;
grant execute on function public.api_mp_config_publica(jsonb) to anon, authenticated;

commit;
```

## Etapa 2 — Banco: funções

**Objetivo:** toda a regra de negócio dentro do banco.

**Status: feita e aprovada.** Nada foi aplicado por mim. Arquivos: `2026-10-13-mp-etapa2-funcoes.sql` (o código está logo abaixo) e `teste-mp-etapa2.sql` (não grava nada; termina com o erro "RELATORIO", que é o resultado, com 40 verificações e o que se espera de cada uma). Rode a Etapa 1, depois este arquivo, depois o teste.

**Como você mandou seguir sem responder as dúvidas da Etapa 0, valem as sugestões.** Nesta etapa vale a 3: operador de caixa e Admin decidem sobre "Pagamento a decidir". As 1, 2 e 4 (cartão online usa a forma Crédito, troco sempre obrigatório, fonte que o cardápio já usa) entram na Etapa 5. O `api_confirmar_reembolso` continua só do Admin até a Etapa 6.

**O que foi criado**

| Função | Quem chama | Para quê |
| --- | --- | --- |
| `api_mp_reservar` | cliente logado | valida o pedido (preços, adicionais, cupom, brindes, estoque, taxa, acréscimo) e guarda a **reserva**. Não cria venda |
| `api_mp_status_pagamento` | cliente logado | situação para a tela: aguardando, aprovado, conferindo, recusado, expirado, cancelado, reembolso, erro |
| `api_mp_cancelar_reserva` | cliente logado | cliente desistiu: solta estoque, cupom e brinde na hora |
| `api_mp_decidir_pagamento` | Admin ou Operador | "Pagamento a decidir": seguir com o pedido ou reembolsar |
| `mp_credenciais` | só a nuvem | chaves do modo certo (teste ou produção). Nunca vão ao navegador |
| `mp_preparar_pagamento` | só a nuvem (`mp-criar`) | confere dono, tempo, tentativas e cria o pagamento. Pix ainda valendo é reaproveitado |
| `mp_aplicar_status` | só a nuvem | única porta do resultado do Mercado Pago (criação, aviso, consulta, reembolso). Ignora aviso repetido e aviso com assinatura inválida |
| `mp_expirar_reservas` | agendamento a cada minuto | reserva vencida sem pagamento devolve estoque, cupom e brinde |
| `_mp_prender`, `_mp_soltar`, `_mp_criar_venda`, `_mp_marcar_decidir`, `_mp_confirmar_pagamento` | só dentro do banco | o miolo: segurar, soltar, criar a venda paga, marcar a decidir, confirmar |

Também entram: `_criar_pedido_publico` ganhou um 3º argumento (`p_reserva`) e `_cupom_calcular` passou a ignorar cupom reservado e desfeito. A função de 2 argumentos, que o cardápio e a mesa usam hoje, só repassa com `p_reserva = false`: o comportamento com o Mercado Pago desligado é idêntico ao de hoje.

**Escolhas desta etapa (me corrija se discordar)**

- **"Pagamento a decidir" não cria venda.** O dinheiro entrou, mas o pedido fica guardado (com o motivo) e **nada chega à cozinha** até o operador de caixa ou o Admin escolher. "Seguir" cria a venda paga e segura de novo estoque, cupom e brinde, sem barrar por falta de estoque (é decisão humana); exige o caixa aberto. "Reembolsar" só registra a decisão: quem devolve o dinheiro é a `mp-reembolsar` (Etapa 3). Isso evita uma venda "fantasma" disparando cozinha, aviso, planilha e nota fiscal antes da decisão. O plano dizia "o pedido entra marcado"; se preferir a venda já criada e marcada, me avise.
- **Casos que viram "Pagamento a decidir":** Pix pago depois de vencer (reserva já solta), pagamento aprovado com reserva cancelada, caixa fechado ou cardápio fechado na hora da aprovação, e pagamento em duplicidade na mesma reserva. Nunca reembolsa sozinho.
- **Reserva que tem pagamento aprovado ou aguardando decisão não vence**: fica segurada até alguém decidir.
- **Cartão recusado mantém a reserva** para outra tentativa (até 5 tentativas por reserva). Erro ao criar o pagamento (Mercado Pago fora do ar) solta a reserva na hora.
- **O status chega do Mercado Pago já traduzido** (aguardando, aprovado, recusado, expirado, cancelado, reembolso_parcial, reembolsado, erro). A tradução dos nomes do Mercado Pago fica na Etapa 3, onde dá para conferir na documentação. O banco não depende deles.
- **Cupom reservado e desfeito** fica com a linha marcada `anulado` (sem apagar nada) e deixa de contar no limite. Novas colunas: só `cupons_usos.anulado`.
- **Fidelidade:** a marca no cartão é dada quando o pagamento é aprovado, igual ao recebimento manual de hoje. O brinde de fidelidade reserva e devolve o cartão como o cancelamento de hoje.
- **Cancelar venda paga online** continua abrindo o reembolso pendente (gatilho que já existe). Quando o Mercado Pago confirmar o reembolso total, ele passa a "Devolvido" sozinho.
- A chave `mercadopago` em `api_integracoes_flags` já foi feita na Etapa 1, então não precisou mexer de novo.
- Agendamento `mp-expirar-reservas` (1 vez por minuto) é criado só se o `pg_cron` existir. Com a integração desligada ele não encontra nada para fazer.
- Não consegui rodar o SQL num Postgres aqui. As duas funções que já existiam foram copiadas **exatamente** da versão mais recente do pacote, com os remendos conferidos por programa (e a diferença contra o original só mostra os trechos novos). O `teste-mp-etapa2.sql` serve para você conferir depois de colar.

**O que a Etapa 3 vai usar:** `mp_credenciais(modo)` para ler a chave; `mp_preparar_pagamento({reservaId, userId})` antes de falar com o Mercado Pago; `mp_aplicar_status({...})` para entregar qualquer resultado. O contrato de cada campo está nos comentários do SQL.

**Código usado**

```sql
-- =====================================================================================
-- MERCADO PAGO · ETAPA 2 (funções do banco) · 2026-10-13 · NÃO APLICADO
-- Rode DEPOIS da Etapa 1 (2026-10-13-mp-etapa1-estrutura.sql). Pode rodar de novo (idempotente).
-- Cole inteiro no SQL Editor do Supabase. Para conferir depois, rode testes/teste-mp-etapa2.sql.
-- Com a integração DESLIGADA nada muda: o pedido normal do cardápio continua idêntico ao de hoje.
-- Nenhum "delete from" dentro de função (o conector do Supabase cancela): reserva desfeita = marcada, não apagada.
-- =====================================================================================
begin;

-- ---------- 1) Cupom reservado e depois desfeito: a linha fica "anulada" e deixa de contar no limite ----------
alter table public.cupons_usos add column if not exists anulado boolean not null default false;

-- ---------- 2) Cálculo do cupom: versão mais recente (contas-clientes), só com "and not cu.anulado" no limite de usos ----------
CREATE OR REPLACE FUNCTION public._cupom_calcular(p_codigo text, p_tel text, p_subtotal numeric, p_tipo text, p_user uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c cupons%rowtype; v_cod text := upper(regexp_replace(btrim(coalesce(p_codigo, '')), '\s+', '', 'g'));
  v_tel text := _so_digitos(p_tel); v_bruto numeric := round(coalesce(p_subtotal, 0), 2); v_desc numeric := 0;
  v_agora timestamp := now() at time zone 'America/Sao_Paulo'; v_hh int; v_hi int; v_hf int; v_usos int; v_usos_cli int; v_fx record;
  v_conta contas_cliente; v_cc cupons_concedidos;
begin
  if v_cod = '' then return _falha('Informe um cupom.'); end if;
  select * into c from cupons where codigo = v_cod and ativa;
  if not found then return _falha('Cupom inválido ou inativo.'); end if;
  if p_user is not null then select * into v_conta from contas_cliente where user_id = p_user and aceite_versao > 0; end if;
  if (c.somente_conta or c.automatico is not null or c.cliente_id is not null) and v_conta.user_id is null then
    return _falha('Este cupom é para quem tem conta. Entre com a sua conta Google para usar.');
  end if;
  if c.cliente_id is not null and v_conta.cliente_id is distinct from c.cliente_id then
    return _falha('Este cupom não está disponível para a sua conta.');
  end if;
  if (c.data_inicio is not null and v_agora::date < c.data_inicio) or (c.data_fim is not null and v_agora::date > c.data_fim) then
    return _falha('Este cupom está fora do período de validade.');
  end if;
  if c.hora_inicio is not null and c.hora_fim is not null then
    v_hh := extract(hour from v_agora)::int * 60 + extract(minute from v_agora)::int;
    v_hi := extract(hour from c.hora_inicio)::int * 60 + extract(minute from c.hora_inicio)::int;
    v_hf := extract(hour from c.hora_fim)::int * 60 + extract(minute from c.hora_fim)::int;
    if v_hi <= v_hf then
      if v_hh < v_hi or v_hh > v_hf then return _falha('Este cupom está fora do período de validade.'); end if;
    else
      if v_hh < v_hi and v_hh > v_hf then return _falha('Este cupom está fora do período de validade.'); end if;
    end if;
  end if;
  if c.automatico is not null then
    select * into v_cc from cupons_concedidos
     where cupom_id = c.id and user_id = p_user and usado_em is null and (valido_ate is null or valido_ate >= v_agora::date)
     order by valido_ate nulls last, criado_em limit 1;
    if not found then return _falha('Você não tem este cupom disponível (ou ele já venceu).'); end if;
  end if;
  select count(*), count(*) filter (where (v_tel <> '' and _so_digitos(cu.telefone) = v_tel) or (p_user is not null and cu.user_id = p_user))
    into v_usos, v_usos_cli from cupons_usos cu where cu.cupom_id = c.id and not cu.anulado and not exists (select 1 from vendas vv where vv.id = cu.venda_id and vv.status = 'Cancelada');
  if c.limite_total > 0 and v_usos >= c.limite_total then return _falha('O limite de utilizações deste cupom foi atingido.'); end if;
  if c.automatico in ('boas_vindas', 'indicacao_indicado') then
    if v_usos_cli > 0 then return _falha('Este cupom já foi usado (uma vez por cliente).'); end if;
  elsif c.automatico is null and c.limite_por_cliente > 0 and v_usos_cli >= c.limite_por_cliente then
    return _falha('Você já atingiu o limite de uso deste cupom.');
  end if;
  if v_bruto < c.valor_minimo then return _falha('Este cupom exige pedido mínimo de R$ ' || replace(_dinheiro(c.valor_minimo), '.', ',') || '.'); end if;
  if c.tipo = 'percentual' then
    if c.valor <= 0 or c.valor > 100 then return _falha('Cupom configurado com percentual inválido.'); end if;
    v_desc := round(v_bruto * c.valor / 100, 2);
  elsif c.tipo = 'fixo' then
    if c.valor <= 0 then return _falha('Cupom configurado com valor inválido.'); end if;
    v_desc := least(v_bruto, round(c.valor, 2));
  elsif c.tipo = 'progressivo' then
    select (x->>'minimo')::numeric mn, (x->>'desconto')::numeric ds into v_fx from jsonb_array_elements(c.faixas) x where (x->>'minimo')::numeric <= v_bruto order by (x->>'minimo')::numeric desc limit 1;
    if v_fx.mn is null then
      select min((x->>'minimo')::numeric) into v_fx.mn from jsonb_array_elements(c.faixas) x;
      return _falha('Este cupom vale a partir de R$ ' || replace(_dinheiro(coalesce(v_fx.mn, 0)), '.', ',') || ' em pedidos.');
    end if;
    v_desc := least(v_bruto, round(v_fx.ds, 2));
  elsif c.tipo = 'frete' then
    v_desc := 0;
  else
    return _falha('Tipo de cupom não suportado.');
  end if;
  v_desc := round(least(v_desc, greatest(0, v_bruto - 0.01)), 2);
  return jsonb_build_object('ok', true, 'cupomId', c.id, 'codigo', c.codigo, 'nome', c.nome, 'tipo', c.tipo, 'desconto', v_desc,
    'freteGratis', (c.frete_gratis or c.tipo = 'frete'), 'acumula', c.acumula,
    'limiteRestante', case when c.limite_total > 0 then greatest(0, c.limite_total - v_usos - 1) else null end);
end $function$
;

-- ---------- 3) Reservar e soltar (estoque, cupom e brinde) ----------
-- _mp_prender: faz a baixa do estoque e marca cupom e brindes como usados, SEM criar a venda.
--   p_forcar = false: o pedido acabou de ser validado, então qualquer falha aqui é erro (desfaz tudo).
--   p_forcar = true: usado quando o operador decide "seguir" com um pagamento já aprovado: aplica o que der, sem barrar por limite/estoque.
create or replace function public._mp_prender(p_reserva uuid, p_forcar boolean default false) returns void
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; rec record; v_cup jsonb; v_uso uuid; v_cc uuid; v_novo jsonb := '[]'::jsonb;
        v_cli uuid; v_fid fidelidade%rowtype; v_bid uuid; v_tipo text; v_prod uuid;
begin
  select * into r from pedidos_reserva where id = p_reserva for update;
  if not found then raise exception 'Reserva não encontrada.'; end if;

  if not r.estoque_reservado then perform _ajustar_estoque(r.itens, 1, null); end if;

  v_cup := r.cupom; v_uso := r.cupom_uso_id;
  if v_cup is not null and v_uso is null then
    insert into cupons_usos (cupom_id, codigo, venda_id, cliente_id, telefone, desconto, frete_gratis, requisicao_id, user_id)
    values ((v_cup->>'cupomId')::uuid, v_cup->>'codigo', null, null, r.telefone, coalesce((v_cup->>'desconto')::numeric, 0),
            coalesce((v_cup->>'freteGratis')::boolean, false), r.requisicao_id, r.user_id)
    returning id into v_uso;
    -- cupom automático da conta (boas-vindas, aniversário, indicação): segura o cupom recebido enquanto a reserva existir
    select id into v_cc from cupons_concedidos
     where cupom_id = (v_cup->>'cupomId')::uuid and user_id = r.user_id and usado_em is null and (valido_ate is null or valido_ate >= _hoje_br())
     order by valido_ate nulls last, criado_em limit 1 for update;
    if v_cc is not null then update cupons_concedidos set usado_em = now(), venda_id = null where id = v_cc; end if;
    v_cup := v_cup || jsonb_build_object('concedidoId', v_cc);
  end if;

  for rec in select value as e from jsonb_array_elements(r.beneficios) loop
    v_tipo := rec.e->>'tipo'; v_prod := _uuid(rec.e->>'produtoId'); v_bid := _uuid(rec.e->>'id');
    if v_tipo = 'Fidelidade' then
      select cc.cliente_id into v_cli from contas_cliente cc where cc.user_id = r.user_id;
      select * into v_fid from fidelidade where cliente_id = v_cli for update;
      if v_fid.id is not null and v_fid.carimbos >= 10 then
        update fidelidade set carimbos = 0, premios_resgatados = premios_resgatados + 1, atualizada_em = now() where cliente_id = v_cli;
        insert into contas_beneficios (user_id, tipo, status, produto_id, venda_id, usado_em) values (r.user_id, 'Fidelidade', 'Usado', v_prod, null, now())
          returning id into v_bid;
      elsif not p_forcar then
        raise exception 'O cartão fidelidade não está completo.';
      else
        v_bid := null;   -- seguiu à força: o item sai a R$ 0, mas o cartão não é mexido
      end if;
    elsif v_tipo = 'Indicação' then
      update contas_beneficios set status = 'Usado', produto_id = v_prod, usado_em = now()
       where id = v_bid and user_id = r.user_id and status = 'Disponível';
      if not found then
        if not p_forcar then raise exception 'O brinde de indicação não está mais disponível.'; end if;
        v_bid := null;
      end if;
    end if;
    v_novo := v_novo || jsonb_build_array(jsonb_build_object('tipo', v_tipo, 'id', v_bid, 'produtoId', v_prod));
  end loop;

  update pedidos_reserva set estoque_reservado = true, cupom = v_cup, cupom_uso_id = v_uso, beneficios = v_novo,
         brindes_reservados = jsonb_array_length(v_novo) > 0, atualizado_em = now()
   where id = r.id;
end $f$;

-- _mp_soltar: devolve estoque, cupom e brindes e marca a reserva com o estado final (expirada ou cancelada). Nada é apagado.
create or replace function public._mp_soltar(p_reserva uuid, p_estado text, p_motivo text) returns void
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; rec record; v_cc uuid; v_cli uuid;
begin
  if p_estado not in ('expirada', 'cancelada') then raise exception 'Estado final inválido.'; end if;
  select * into r from pedidos_reserva where id = p_reserva for update;
  if not found or r.estado not in ('ativa', 'expirada', 'cancelada') then return; end if;   -- reserva já confirmada nunca é solta

  if r.estoque_reservado then perform _ajustar_estoque(r.itens, -1, null); end if;
  if r.cupom_uso_id is not null then update cupons_usos set anulado = true where id = r.cupom_uso_id and venda_id is null; end if;
  v_cc := _uuid(r.cupom->>'concedidoId');
  if v_cc is not null then update cupons_concedidos set usado_em = null, venda_id = null where id = v_cc and venda_id is null; end if;

  for rec in select value as e from jsonb_array_elements(r.beneficios) loop
    if _uuid(rec.e->>'id') is null then continue; end if;
    if rec.e->>'tipo' = 'Indicação' then
      update contas_beneficios set status = 'Disponível', venda_id = null, usado_em = null, produto_id = null
       where id = _uuid(rec.e->>'id') and venda_id is null and status = 'Usado';
    elsif rec.e->>'tipo' = 'Fidelidade' then
      update contas_beneficios set status = 'Anulado' where id = _uuid(rec.e->>'id') and venda_id is null and status = 'Usado';
      if found then
        select cc.cliente_id into v_cli from contas_cliente cc where cc.user_id = r.user_id;
        update fidelidade set carimbos = 10, premios_resgatados = greatest(0, premios_resgatados - 1), atualizada_em = now() where cliente_id = v_cli;
      end if;
    end if;
  end loop;

  update pedidos_reserva set estado = p_estado, motivo_fim = left(coalesce(p_motivo, ''), 200), estoque_reservado = false, brindes_reservados = false,
         cupom_uso_id = null, cupom = case when cupom is null then null else cupom - 'concedidoId' end, atualizado_em = now()
   where id = r.id;
end $f$;

-- ---------- 4) Pedido do cardápio: versão mais recente (contas-brindes) + modo reserva (p_reserva = true). Com false é IDÊNTICO ao de hoje ----------
CREATE OR REPLACE FUNCTION public._criar_pedido_publico(p jsonb, p_mesa_id uuid, p_reserva boolean)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_eh_mesa boolean := p_mesa_id is not null; v_mesa mesas%rowtype;
  v_nome text := _texto_publico(p->>'clienteNome', 80);
  v_tel text := case when p_mesa_id is not null then '' else _texto_publico(p->>'clienteTelefone', 20) end;
  v_dig text := case when p_mesa_id is not null then '' else _so_digitos(p->>'clienteTelefone') end;
  v_obs_troco text := _texto_publico(p->>'observacaoTroco', 200);
  v_de jsonb := case when jsonb_typeof(p->'dadosEntrega') = 'object' then p->'dadosEntrega' else '{}'::jsonb end;
  v_end text := _texto_publico(v_de->>'endereco', 200); v_comp text := _texto_publico(v_de->>'complemento', 100); v_ref text := _texto_publico(v_de->>'referencia', 150);
  v_obs_ent text := _texto_publico(coalesce(nullif(p->>'observacoes', ''), v_de->>'observacoes'), 300);
  v_itens jsonb := p->'itens'; v_tipo_in text := p->>'tipoEntrega'; v_ip text := _ip_cliente();
  v_req text := nullif(left(btrim(coalesce(p->>'requisicaoId', '')), 80), '');
  v_forma formas_pagamento%rowtype; v_caixa uuid; v_tipo venda_tipo; v_ja record; v_prod produtos%rowtype; v_comb combos%rowtype;
  it record; r record; v_prod_id uuid; v_comb_id uuid; v_qtd numeric; v_preco numeric; v_custo_u numeric; v_nome_item text; v_extra numeric; v_n_ad int; v_n_ok int;
  v_ads text; v_obs_item text; v_ads_ids jsonb; v_itens_ok jsonb := '[]'::jsonb; v_orig numeric := 0; v_custo numeric := 0;
  v_cod text := ''; v_cup jsonb; v_desc numeric := 0; v_frete boolean := false; v_taxa numeric := 0; v_pad numeric; v_total numeric;
  v_venda uuid := gen_random_uuid(); v_numero int; v_cli uuid; v_chave text; v_obs_final text; v_bloqueia boolean; v_forma_nome text; v_acr numeric := 0; v_bloq text; v_user uuid := (select cc.user_id from contas_cliente cc where cc.user_id = auth.uid() and cc.aceite_versao > 0);
  v_ben jsonb := case when jsonb_typeof(p->'beneficios') = 'array' then p->'beneficios' else '[]'::jsonb end;
  b record; v_bens jsonb := '[]'::jsonb; v_bc contas_cliente; v_fid fidelidade%rowtype; v_bid uuid; v_pb produtos%rowtype; v_btipo text;
  v_res uuid; v_min int; v_cfg integracoes_config%rowtype; v_ja_res record;
begin
  -- Mercado Pago (p_reserva = true): valida tudo igual ao pedido normal, mas em vez de criar a venda guarda uma RESERVA até o pagamento ser aprovado
  if p_reserva then
    if p_mesa_id is not null then return _falha('Mesas e balcão não pagam pelo site.'); end if;
    if v_user is null then return _falha('Entre com a sua conta para pagar pelo site.'); end if;
    if v_req is null then return _falha('Não foi possível identificar esta tentativa. Atualize a página e tente de novo.'); end if;
    if coalesce((public.api_mp_config_publica('{}'::jsonb)->>'ligado')::boolean, false) is not true then
      return _falha('O pagamento pelo site não está disponível agora. Escolha pagar na entrega.');
    end if;
    perform pg_advisory_xact_lock(hashtext('reserva:' || v_req));
    select id, estado, valor_total, expira_em into v_ja_res from pedidos_reserva where requisicao_id = v_req;
    if found then
      return jsonb_build_object('ok', true, 'duplicado', true, 'reservaId', v_ja_res.id, 'estado', v_ja_res.estado,
        'valorTotal', v_ja_res.valor_total, 'expiraEm', v_ja_res.expira_em, 'message', 'Pedido já recebido — envio repetido ignorado.');
    end if;
  end if;

  -- repetição do mesmo envio (duplo toque, nova tentativa): devolve o pedido já criado, sem criar outro
  if v_req is not null and not p_reserva then
    perform pg_advisory_xact_lock(hashtext('venda:' || v_req));
    select id, numero_pedido, valor_total into v_ja from vendas where requisicao_id = v_req;
    if found then
      return jsonb_build_object('ok', true, 'duplicado', true, 'id', v_ja.id, 'numero', v_ja.numero_pedido, 'valorTotal', v_ja.valor_total, 'message', 'Pedido já recebido — envio repetido ignorado.');
    end if;
  end if;

  if jsonb_typeof(v_itens) <> 'array' then return _falha('Carrinho vazio.'); end if;
  if jsonb_array_length(v_itens) = 0 and (p_mesa_id is not null or jsonb_array_length(v_ben) = 0) then return _falha('Carrinho vazio.'); end if;
  if jsonb_array_length(v_itens) > 40 then return _falha('Carrinho grande demais.'); end if;
  if v_eh_mesa then
    if v_nome = '' then return _falha('Informe o seu nome.'); end if;
    v_chave := 'pedmesa_' || p_mesa_id::text;
  else
    if v_nome = '' or v_dig = '' then return _falha('Informe nome e telefone.'); end if;
    if length(v_dig) < 10 or length(v_dig) > 13 then return _falha('Informe um telefone válido com DDD.'); end if;
    v_chave := 'pedcard_' || v_dig;
  end if;
  if _excedeu('pedcard_global', 150) then return _falha('Estamos com muitos pedidos no momento. Tente novamente em alguns minutos ou ligue para o restaurante.'); end if;
  if _excedeu('pedcard_ip_' || v_ip, 40) then return _falha('Muitos pedidos em sequência deste local. Aguarde alguns minutos.'); end if;
  if _excedeu(v_chave, case when v_eh_mesa then 8 else 5 end) then
    return _falha(case when v_eh_mesa then 'Muitos pedidos em sequência nesta mesa. Chame o garçom.' else 'Muitos pedidos em sequência. Aguarde alguns minutos.' end);
  end if;

  -- cardápio fechado à mão ou em período programado (pedido de mesa, feito dentro do restaurante, não é bloqueado)
  if not v_eh_mesa then
    v_bloq := _cardapio_bloqueio();
    if v_bloq is not null then return _falha(v_bloq); end if;
  end if;
  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;
  if v_caixa is null then return _falha('Estamos fechados no momento. Tente novamente mais tarde.'); end if;

  if v_eh_mesa then
    select * into v_mesa from mesas where id = p_mesa_id for update;
    if not found then return _falha('Mesa não encontrada.'); end if;
    if v_mesa.status::text not in ('Livre', 'Ocupada') then
      return _falha(case when v_mesa.status::text = 'Aguardando fechamento' then 'A conta desta mesa já foi pedida. Chame o garçom para novos pedidos.' else 'Esta mesa não está disponível para pedidos pelo celular. Chame o garçom.' end);
    end if;
    v_tipo := 'Mesa';
    -- mesa: o cliente não escolhe a forma; vale a primeira forma do cardápio só para o preço (o recebimento é feito no fechamento da conta)
    select * into v_forma from formas_pagamento where ativa and visivel_cardapio order by ordem limit 1;
    v_forma_nome := 'A Receber (Mesa)';
  else
    v_tipo := (case when v_tipo_in = 'Entrega' then 'Entrega' else 'Retirada' end)::venda_tipo;
    if v_tipo = 'Entrega' and v_end = '' then return _falha('Informe o endereço de entrega.'); end if;
    if v_tipo = 'Entrega' then
      declare v_num text := _texto_publico(v_de->>'numero', 20); v_cid text := _texto_publico(v_de->>'cidade', 80);
              v_cid_loc text := _texto_publico(v_de->>'cidadeLocalizacao', 80); v_lista jsonb; v_nomes text;
      begin
        if v_de ? 'numero' and v_num = '' then return _falha('Informe o número da casa (ou "s/n").'); end if;
        if v_de ? 'cidade' and v_cid = '' then return _falha('Informe a cidade da entrega.'); end if;
        if v_num <> '' then v_end := left(v_end || ', nº ' || v_num, 200); end if;
        if v_cid <> '' then v_end := left(v_end || ' — ' || v_cid, 200); end if;
      end;
    end if;
    select * into v_forma from formas_pagamento where id = _uuid(p->>'formaPagamentoId') and ativa and visivel_cardapio;
    v_forma_nome := v_forma.nome;
  end if;
  if v_forma.id is null then return _falha('Forma de pagamento inválida.'); end if;
  if p_reserva and not (v_forma.aceita_online and v_forma.tipo_online is not null) then return _falha('Esta forma de pagamento não é aceita pelo site.'); end if;

  -- itens: tudo vem do cadastro (produto/combo ativo, preço da forma escolhida, adicionais ativos e vinculados)
  for it in select value as e from jsonb_array_elements(v_itens) loop
    v_qtd := _num(it.e->>'quantidade');
    if v_qtd <= 0 then continue; end if;
    if v_qtd > 50 or v_qtd <> floor(v_qtd) then return _falha('Quantidade inválida no carrinho.'); end if;
    v_prod_id := _uuid(it.e->>'produtoId'); v_comb_id := _uuid(it.e->>'comboId');
    if (v_prod_id is null) = (v_comb_id is null) then return _falha('Item inválido no carrinho.'); end if;
    if jsonb_typeof(it.e->'adicionaisIds') = 'array' and jsonb_array_length(it.e->'adicionaisIds') > 20 then return _falha('Adicionais demais em um item.'); end if;
    if v_prod_id is not null then
      select * into v_prod from produtos where id = v_prod_id and ativo;
      if not found then return _falha('Um dos produtos não está mais disponível.'); end if;
      v_nome_item := v_prod.nome;
      select preco, custo into v_preco, v_custo_u from produto_precos where produto_id = v_prod_id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_nome_item || '" não tem preço configurado para essa forma de pagamento.'); end if;
    else
      select * into v_comb from combos where id = v_comb_id and ativo;
      if not found then return _falha('Um dos combos não está mais disponível.'); end if;
      if exists (select 1 from combo_itens ci join produtos pr on pr.id = ci.produto_id where ci.combo_id = v_comb_id and not pr.ativo) then
        return _falha('O combo "' || v_comb.nome || '" está temporariamente indisponível.');
      end if;
      v_nome_item := v_comb.nome;
      select preco, custo into v_preco, v_custo_u from combo_precos where combo_id = v_comb_id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_nome_item || '" não tem preço configurado para essa forma de pagamento.'); end if;
    end if;
    select count(*), coalesce(sum(a.preco), 0),
           count(a.id) filter (where a.ativo and ((v_prod_id is not null and exists (select 1 from produto_adicionais pa where pa.produto_id = v_prod_id and pa.adicional_id = a.id)) or (v_comb_id is not null and exists (select 1 from combo_itens ci join produto_adicionais pa on pa.produto_id = ci.produto_id where ci.combo_id = v_comb_id and pa.adicional_id = a.id)))),
           coalesce(string_agg(' + ' || a.nome, '' order by s.ord) filter (where a.id is not null), ''),
           coalesce(jsonb_agg(a.id order by s.ord) filter (where a.id is not null), '[]'::jsonb)
      into v_n_ad, v_extra, v_n_ok, v_ads, v_ads_ids
      from jsonb_array_elements_text(case when jsonb_typeof(it.e->'adicionaisIds') = 'array' then it.e->'adicionaisIds' else '[]'::jsonb end) with ordinality as s(x, ord)
      left join adicionais a on a.id = _uuid(s.x);
    if v_n_ad <> v_n_ok then return _falha('Um adicional escolhido para "' || v_nome_item || '" não está disponível.'); end if;
    v_obs_item := _texto_publico(it.e->>'observacao', 100);
    v_itens_ok := v_itens_ok || jsonb_build_array(jsonb_build_object('produtoId', v_prod_id, 'comboId', v_comb_id,
      'descricao', v_nome_item || v_ads || case when v_obs_item <> '' then ' — Obs: ' || v_obs_item else '' end,
      'quantidade', v_qtd, 'valorUnitario', v_preco + v_extra, 'custoUnitario', v_custo_u, 'adicionaisIds', v_ads_ids));
    v_orig := v_orig + round(v_qtd * (v_preco + v_extra), 2); v_custo := v_custo + v_qtd * v_custo_u;
  end loop;
  if jsonb_array_length(v_itens_ok) = 0 and jsonb_array_length(v_ben) = 0 then return _falha('Carrinho vazio.'); end if;
  -- brindes da conta (cartão fidelidade e indicação): entram como item de R$ 0, com custo e baixa no estoque
  if jsonb_array_length(v_ben) > 0 then
    if v_eh_mesa or v_user is null then return _falha('Entre com a sua conta para resgatar o brinde.'); end if;
    if jsonb_array_length(v_ben) > 5 then return _falha('Brindes demais no mesmo pedido.'); end if;
    select * into v_bc from contas_cliente where user_id = v_user for update;
    for b in select value as e from jsonb_array_elements(v_ben) loop
      v_btipo := b.e->>'tipo';
      select * into v_pb from produtos where id = _uuid(b.e->>'produtoId') and ativo;
      if not found then return _falha('O brinde escolhido não está mais disponível.'); end if;
      select custo into v_custo_u from produto_precos where produto_id = v_pb.id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_pb.nome || '" não está disponível para essa forma de pagamento.'); end if;
      v_bid := null;
      if v_btipo = 'Fidelidade' then
        if not v_pb.premio_fidelidade then return _falha('"' || v_pb.nome || '" não é um prêmio do cartão fidelidade.'); end if;
        if v_bc.cliente_id is null then return _falha('Seu cartão fidelidade ainda não está ligado à sua conta. Ele liga depois do seu primeiro pedido concluído.'); end if;
        if exists (select 1 from jsonb_array_elements(v_bens) x where x->>'tipo' = 'Fidelidade') then return _falha('Só dá para resgatar 1 prêmio do cartão fidelidade por pedido.'); end if;
        select * into v_fid from fidelidade where cliente_id = v_bc.cliente_id for update;
        if v_fid.id is null or v_fid.carimbos < 10 then return _falha('Seu cartão fidelidade ainda não completou as 10 marcas.'); end if;
      elsif v_btipo = 'Indicação' then
        if not v_pb.premio_indicacao then return _falha('"' || v_pb.nome || '" não é um prêmio de indicação.'); end if;
        select id into v_bid from contas_beneficios where id = _uuid(b.e->>'id') and user_id = v_user and tipo = 'Indicação' and status = 'Disponível' for update;
        if v_bid is null or exists (select 1 from jsonb_array_elements(v_bens) x where x->>'id' = v_bid::text) then return _falha('Este brinde de indicação não está mais disponível.'); end if;
      else
        return _falha('Brinde inválido.');
      end if;
      v_bens := v_bens || jsonb_build_array(jsonb_build_object('tipo', v_btipo, 'id', v_bid, 'produtoId', v_pb.id));
      v_itens_ok := v_itens_ok || jsonb_build_array(jsonb_build_object('produtoId', v_pb.id, 'comboId', null,
        'descricao', '🎁 Brinde ' || case when v_btipo = 'Fidelidade' then 'fidelidade' else 'indicação' end || ' — ' || v_pb.nome,
        'quantidade', 1, 'valorUnitario', 0, 'custoUnitario', v_custo_u, 'adicionaisIds', '[]'::jsonb));
      v_custo := v_custo + v_custo_u;
    end loop;
  end if;
  v_orig := round(v_orig, 2); v_custo := round(v_custo, 2);

  select coalesce((select (valor #>> '{}') = 'true' from sistema where chave = 'BLOQUEAR_ESTOQUE_NEGATIVO'), false) into v_bloqueia;
  if v_bloqueia then
    for r in select c.ingrediente_id, c.qtd, e.quantidade from _consumo(v_itens_ok) c join estoque e on e.id = c.ingrediente_id loop
      if r.quantidade + 0.000000001 < r.qtd then return _falha('Um dos itens do pedido acabou. Escolha outro item ou fale com o restaurante.'); end if;
    end loop;
  end if;

  -- cupom (só no cardápio comum; travado por código para dois pedidos simultâneos não estourarem o limite)
  if not v_eh_mesa then
    v_cod := upper(regexp_replace(btrim(coalesce(p->>'codigoCupom', '')), '\s+', '', 'g'));
    if v_cod <> '' then
      if v_orig <= 0 then return _falha('O cupom vale para pedidos com pelo menos um item pago.'); end if;
      perform pg_advisory_xact_lock(hashtext('cupom:' || v_cod));
      v_cup := _cupom_calcular(v_cod, v_tel, v_orig, v_tipo::text, v_user);
      if coalesce(v_cup->>'ok', '') <> 'true' then return v_cup; end if;
      v_desc := (v_cup->>'desconto')::numeric; v_frete := (v_cup->>'freteGratis')::boolean;
    end if;
  end if;

  if v_tipo = 'Entrega' and not v_frete then
    select coalesce(_num(valor #>> '{}'), 0) into v_pad from sistema where chave = 'TaxaEntregaPadrao';
    v_taxa := coalesce(v_pad, 0);
  end if;
  v_total := case when v_orig <= 0 and jsonb_array_length(v_bens) > 0 then round(v_taxa, 2) else greatest(0.01, round(v_orig - v_desc + v_taxa, 2)) end;
  -- acréscimo da forma de pagamento escolhida (mesa: o acréscimo entra no fechamento da conta)
  if not v_eh_mesa and v_orig > 0 then v_acr := _acrescimo_forma(v_forma, greatest(0.01, v_total - v_taxa)); v_total := round(v_total + v_acr, 2); end if;
  v_obs_final := coalesce(concat_ws(' — ', nullif(v_obs_ent, ''), nullif(v_obs_troco, '')), '');

  -- Mercado Pago: não cria a venda agora. Guarda a reserva (e já segura estoque, cupom e brinde) até o pagamento ser aprovado.
  if p_reserva then
    if v_total <= 0 then return _falha('Este pedido não tem valor a pagar pelo site.'); end if;
    select * into v_cfg from integracoes_config where provedor = 'mercadopago';
    v_min := case when coalesce(v_cfg.config->>'pixValidadeMin', '') ~ '^[0-9]{1,3}$' then least(120, greatest(5, (v_cfg.config->>'pixValidadeMin')::int)) else 15 end;
    insert into pedidos_reserva (requisicao_id, user_id, cliente_nome, telefone, tipo_entrega, forma_pagamento_id, dados_entrega, observacoes,
                                 itens, beneficios, cupom, valor_original, valor_desconto, taxa_entrega, acrescimo_forma, valor_total, custo_total, expira_em)
    values (v_req, v_user, v_nome, v_tel, v_tipo::text, v_forma.id,
            jsonb_build_object('endereco', case when v_tipo = 'Entrega' then v_end else '' end, 'complemento', case when v_tipo = 'Entrega' then v_comp else '' end,
                               'referencia', case when v_tipo = 'Entrega' then v_ref else '' end),
            v_obs_final, v_itens_ok, v_bens, case when v_cod <> '' then v_cup else null end, v_orig, v_desc, v_taxa, v_acr, v_total, v_custo,
            now() + make_interval(mins => v_min))
    returning id into v_res;
    perform _mp_prender(v_res, false);
    perform _registrar_falha(v_chave, 600); perform _registrar_falha('pedcard_global', 300); perform _registrar_falha('pedcard_ip_' || v_ip, 600);
    perform _auditar_publico('Pedido reservado para pagamento pelo site',
      'Total R$ ' || _dinheiro(v_total) || case when jsonb_array_length(v_bens) > 0 then ' | Brindes ' || jsonb_array_length(v_bens) else '' end || case when v_cod <> '' then ' | Cupom ' || (v_cup->>'codigo') else '' end, v_tel);
    return jsonb_build_object('ok', true, 'reservaId', v_res, 'metodo', v_forma.tipo_online, 'valorTotal', v_total, 'valorOriginal', v_orig,
      'acrescimo', v_acr, 'valorDesconto', v_desc, 'taxaEntrega', v_taxa, 'minutos', v_min, 'expiraEm', now() + make_interval(mins => v_min));
  end if;

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido,
                      endereco, complemento, referencia, observacoes_entrega, status_pagamento, valor_original, valor_desconto,
                      desconto_detalhe, origem, mesa_id, taxa_entrega, caixa_id, requisicao_id, acrescimo_forma)
  values (v_venda, v_nome, v_tel, v_forma_nome, v_total, v_custo, 'Confirmada', v_tipo, 'Recebido',
          case when v_tipo = 'Entrega' then v_end else '' end, case when v_tipo = 'Entrega' then v_comp else '' end, case when v_tipo = 'Entrega' then v_ref else '' end,
          v_obs_final, (case when v_total <= 0 then 'Pago' else 'A Receber' end)::status_pagamento, v_orig, v_desc, case when v_cod <> '' then 'Cupom ' || (v_cup->>'codigo') else '' end, 'Cardápio',
          case when v_eh_mesa then p_mesa_id else null end, v_taxa, v_caixa, v_req, v_acr)
  returning numero_pedido into v_numero;

  insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
  select v_venda, _uuid(e->>'produtoId'), _uuid(e->>'comboId'), e->>'descricao', _num(e->>'quantidade', 1)::int, _num(e->>'valorUnitario'), _num(e->>'custoUnitario'),
         round(_num(e->>'quantidade', 1) * _num(e->>'valorUnitario'), 2),
         coalesce((select array_agg(_uuid(x)) filter (where _uuid(x) is not null) from jsonb_array_elements_text(e->'adicionaisIds') x), '{}')
  from jsonb_array_elements(v_itens_ok) e;

  insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo)
  values (v_venda, v_forma_nome, v_total, case when v_eh_mesa or v_total <= 0 then 0 else round(v_total * v_forma.taxa_percentual / 100 + v_forma.taxa_fixa, 2) end, v_acr);
  if v_total <= 0 then update vendas set recebido_em = now() where id = v_venda; end if;

  if v_eh_mesa and v_mesa.status::text = 'Livre' then update mesas set status = 'Ocupada' where id = p_mesa_id; end if;
  perform _ajustar_estoque(v_itens_ok, 1, v_venda);
  if v_tel <> '' then v_cli := _upsert_cliente(v_tel, v_nome); end if;
  if v_user is not null and not v_eh_mesa then insert into contas_pedidos (venda_id, user_id) values (v_venda, v_user) on conflict do nothing; end if;
  if jsonb_array_length(v_bens) > 0 then
    for b in select value as e from jsonb_array_elements(v_bens) loop
      if b.e->>'tipo' = 'Fidelidade' then
        update fidelidade set carimbos = 0, premios_resgatados = premios_resgatados + 1, atualizada_em = now() where cliente_id = v_bc.cliente_id;
        insert into contas_beneficios (user_id, tipo, status, produto_id, venda_id, usado_em) values (v_user, 'Fidelidade', 'Usado', _uuid(b.e->>'produtoId'), v_venda, now());
      else
        update contas_beneficios set status = 'Usado', produto_id = _uuid(b.e->>'produtoId'), venda_id = v_venda, usado_em = now() where id = _uuid(b.e->>'id');
      end if;
    end loop;
  end if;
  if v_cod <> '' then
    insert into cupons_usos (cupom_id, codigo, venda_id, cliente_id, telefone, desconto, frete_gratis, requisicao_id, user_id)
    values ((v_cup->>'cupomId')::uuid, v_cup->>'codigo', v_venda, v_cli, v_tel, v_desc, v_frete, v_req, v_user);
    perform _conta_cupom_usado(v_user, (v_cup->>'cupomId')::uuid, v_venda);
  end if;
  perform _registrar_falha(v_chave, 600); perform _registrar_falha('pedcard_global', 300); perform _registrar_falha('pedcard_ip_' || v_ip, 600);
  perform _auditar_publico(case when v_eh_mesa then 'Pedido recebido pelo cliente na mesa ' || v_mesa.numero else 'Pedido recebido pelo Cardápio' end,
    'Total R$ ' || _dinheiro(v_total) || case when jsonb_array_length(v_bens) > 0 then ' | Brindes ' || jsonb_array_length(v_bens) else '' end || case when v_cod <> '' then ' | Cupom ' || (v_cup->>'codigo') else '' end, case when v_eh_mesa then v_nome else v_tel end);

  return jsonb_build_object('ok', true, 'message', 'Pedido enviado! Nº ' || v_numero || '. Total: R$ ' || _dinheiro(v_total) || '.',
    'id', v_venda, 'numero', v_numero, 'valorTotal', v_total, 'valorOriginal', v_orig, 'acrescimo', v_acr, 'valorDesconto', v_desc,
    'cupom', case when v_cod <> '' then v_cup->>'codigo' else '' end, 'freteGratis', v_frete);
end $function$
;

-- a função de 2 argumentos (usada por api_criar_pedido_cardapio e api_criar_pedido_mesa) continua igual para quem chama: só repassa com p_reserva = false
create or replace function public._criar_pedido_publico(p jsonb, p_mesa_id uuid) returns jsonb
 language sql security definer set search_path to 'public' as $f$ select public._criar_pedido_publico(p, p_mesa_id, false) $f$;

-- ---------- 5) Funções que o cardápio chama (cliente logado) ----------
-- Valida o pedido e RESERVA (não cria venda). Devolve reservaId, valor e quando a reserva vence. Depois a página chama a função mp-criar.
create or replace function public.api_mp_reservar(p jsonb) returns jsonb
 language sql security definer set search_path to 'public' as $f$ select public._criar_pedido_publico(p, null, true) $f$;

-- Situação do pagamento, para a tela do cliente (Pix aguardando, aprovado, recusado...). A tela consulta esta função de tempos em tempos.
create or replace function public.api_mp_status_pagamento(p jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; g pagamentos_online%rowtype; v_est text;
begin
  if auth.uid() is null then return _negado(); end if;
  select * into r from pedidos_reserva where id = _uuid(p->>'reservaId') and user_id = auth.uid();
  if not found then return _falha('Pedido não encontrado.'); end if;
  select * into g from pagamentos_online where reserva_id = r.id order by criado_em desc limit 1;
  v_est := case
    when r.estado = 'confirmada' then 'aprovado'
    when g.id is not null and (g.decisao = 'reembolsar' or g.status in ('reembolso_parcial', 'reembolsado')) then 'reembolso'
    when g.id is not null and g.status = 'aprovado' then 'conferindo'
    when r.estado = 'expirada' then 'expirado'
    when r.estado = 'cancelada' then 'cancelado'
    when g.id is not null and g.status = 'recusado' then 'recusado'
    when g.id is not null and g.status = 'erro' then 'erro'
    else 'aguardando' end;
  return jsonb_build_object('ok', true, 'estado', v_est, 'reservaId', r.id, 'metodo', g.metodo, 'valorTotal', r.valor_total, 'expiraEm', r.expira_em,
    'vendaId', r.venda_id, 'numero', (select v.numero_pedido from vendas v where v.id = r.venda_id), 'detalhe', coalesce(g.status_detalhe, ''),
    'pixCopiaCola', case when v_est = 'aguardando' then g.pix_copia_cola else null end, 'pixQrBase64', case when v_est = 'aguardando' then g.pix_qr_base64 else null end,
    'pixExpiraEm', case when v_est = 'aguardando' then g.pix_expira_em else null end);
end $f$;

-- O cliente desistiu (fechou a tela do Pix, voltou ao carrinho): solta estoque, cupom e brinde na hora.
create or replace function public.api_mp_cancelar_reserva(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype;
begin
  if auth.uid() is null then return _negado(); end if;
  select * into r from pedidos_reserva where id = _uuid(p->>'reservaId') and user_id = auth.uid() for update;
  if not found then return _falha('Pedido não encontrado.'); end if;
  if r.estado <> 'ativa' then return jsonb_build_object('ok', true, 'estado', r.estado); end if;
  if exists (select 1 from pagamentos_online g where g.reserva_id = r.id and (g.status = 'aprovado' or (g.decisao_pendente and g.decisao is null))) then
    return _falha('O pagamento deste pedido já foi aprovado. Fale com o restaurante.');
  end if;
  update pagamentos_online set status = 'cancelado', status_detalhe = 'cancelado pelo cliente', atualizado_em = now() where reserva_id = r.id and status = 'aguardando';
  perform _mp_soltar(r.id, 'cancelada', 'Cancelado pelo cliente');
  return jsonb_build_object('ok', true, 'estado', 'cancelada');
end $f$;

-- ---------- 6) Confirmar o pagamento: a venda nasce PAGA ----------
-- Cria a venda a partir da reserva, no mesmo formato do pedido do cardápio (itens, pagamento, conta, cupom, brindes, fidelidade).
-- Estoque, cupom e brinde já foram segurados na reserva: aqui só se liga tudo à venda.
create or replace function public._mp_criar_venda(p_reserva uuid, p_pag uuid) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; f formas_pagamento%rowtype; v_caixa uuid; v_venda uuid := gen_random_uuid(); v_numero int; v_cli uuid;
        v_cod text; rec record; v_tipo venda_tipo; v_de jsonb; v_nome text; v_cc uuid;
begin
  select * into r from pedidos_reserva where id = p_reserva for update;
  if not found then raise exception 'Reserva não encontrada.'; end if;
  select * into f from formas_pagamento where id = r.forma_pagamento_id;
  v_nome := coalesce(f.nome, 'Pagamento online');
  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;
  if v_caixa is null then raise exception 'Caixa fechado.'; end if;
  v_tipo := (case when r.tipo_entrega = 'Entrega' then 'Entrega' else 'Retirada' end)::venda_tipo;
  v_de := coalesce(r.dados_entrega, '{}'::jsonb);
  v_cod := coalesce(r.cupom->>'codigo', '');

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido,
                      endereco, complemento, referencia, observacoes_entrega, status_pagamento, recebido_em, valor_original, valor_desconto,
                      desconto_detalhe, origem, mesa_id, taxa_entrega, caixa_id, requisicao_id, acrescimo_forma)
  values (v_venda, r.cliente_nome, r.telefone, v_nome, r.valor_total, r.custo_total, 'Confirmada', v_tipo, 'Recebido',
          case when v_tipo = 'Entrega' then coalesce(v_de->>'endereco', '') else '' end, case when v_tipo = 'Entrega' then coalesce(v_de->>'complemento', '') else '' end,
          case when v_tipo = 'Entrega' then coalesce(v_de->>'referencia', '') else '' end, r.observacoes, 'Pago', now(), r.valor_original, r.valor_desconto,
          case when v_cod <> '' then 'Cupom ' || v_cod else '' end, 'Cardápio', null, r.taxa_entrega, v_caixa, r.requisicao_id, r.acrescimo_forma)
  returning numero_pedido into v_numero;

  insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
  select v_venda, _uuid(e->>'produtoId'), _uuid(e->>'comboId'), e->>'descricao', _num(e->>'quantidade', 1)::int, _num(e->>'valorUnitario'), _num(e->>'custoUnitario'),
         round(_num(e->>'quantidade', 1) * _num(e->>'valorUnitario'), 2),
         coalesce((select array_agg(_uuid(x)) filter (where _uuid(x) is not null) from jsonb_array_elements_text(e->'adicionaisIds') x), '{}')
  from jsonb_array_elements(r.itens) e;

  insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo)
  values (v_venda, v_nome, r.valor_total, round(r.valor_total * coalesce(f.taxa_percentual, 0) / 100 + coalesce(f.taxa_fixa, 0), 2), r.acrescimo_forma);

  if r.telefone <> '' then
    v_cli := _upsert_cliente(r.telefone, r.cliente_nome);
    perform _carimbar_fidelidade(r.telefone, r.cliente_nome);   -- como no recebimento manual: pedido pago = marca no cartão fidelidade
  end if;
  insert into contas_pedidos (venda_id, user_id) values (v_venda, r.user_id) on conflict do nothing;

  if r.cupom_uso_id is not null then update cupons_usos set venda_id = v_venda, cliente_id = v_cli where id = r.cupom_uso_id; end if;
  v_cc := _uuid(r.cupom->>'concedidoId');
  if v_cc is not null then update cupons_concedidos set venda_id = v_venda where id = v_cc; end if;
  for rec in select value as e from jsonb_array_elements(r.beneficios) loop
    if _uuid(rec.e->>'id') is not null then update contas_beneficios set venda_id = v_venda where id = _uuid(rec.e->>'id'); end if;
  end loop;

  update pedidos_reserva set estado = 'confirmada', venda_id = v_venda, atualizado_em = now() where id = r.id;
  update pagamentos_online set venda_id = v_venda, atualizado_em = now() where id = p_pag;
  perform _auditar_publico('Pedido pago pelo site (Mercado Pago)', 'Nº ' || v_numero || ' | Total R$ ' || _dinheiro(r.valor_total), r.telefone);
  return jsonb_build_object('vendaId', v_venda, 'numero', v_numero);
end $f$;

-- Marca o pagamento como "Pagamento a decidir": o dinheiro entrou, mas o pedido NÃO vai para a cozinha até o operador de caixa ou o Admin escolher.
create or replace function public._mp_marcar_decidir(p_pag uuid, p_motivo text) returns void
 language plpgsql security definer set search_path to 'public' as $f$
begin
  update pagamentos_online set decisao_pendente = true, decisao = null, decisao_motivo = left(coalesce(p_motivo, ''), 200), atualizado_em = now() where id = p_pag;
  perform _auditar('Pagamento a decidir', 'Pagamento ' || p_pag || ' | ' || coalesce(p_motivo, ''), '');
end $f$;

-- Pagamento aprovado pelo Mercado Pago. Reserva ativa e restaurante aberto: cria a venda Paga.
-- Reserva vencida/cancelada, caixa ou cardápio fechado, pagamento em duplicidade: nunca reembolsa sozinho, marca "Pagamento a decidir".
-- Ordem de trava: sempre reserva primeiro, depois pagamento (evita travar um no outro).
create or replace function public._mp_confirmar_pagamento(p_pag uuid) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare g pagamentos_online%rowtype; r pedidos_reserva%rowtype; v_motivo text; v_v jsonb;
begin
  select * into g from pagamentos_online where id = p_pag;
  if not found then return _falha('Pagamento não encontrado.'); end if;
  select * into r from pedidos_reserva where id = g.reserva_id for update;
  select * into g from pagamentos_online where id = p_pag for update;
  if g.status in ('reembolso_parcial', 'reembolsado') or g.venda_id is not null or g.decisao_pendente or g.decisao is not null then
    return jsonb_build_object('ok', true, 'duplicado', true);
  end if;
  update pagamentos_online set status = 'aprovado', aprovado_em = coalesce(aprovado_em, now()), erro = '', atualizado_em = now() where id = g.id;

  if r.estado = 'confirmada' then v_motivo := 'Já existe um pedido pago nesta reserva (pagamento em duplicidade)';
  elsif r.estado = 'expirada' then v_motivo := case when g.metodo = 'pix' then 'Pix pago depois de vencer' else 'Pagamento aprovado depois de a reserva vencer' end;
  elsif r.estado = 'cancelada' then v_motivo := 'Pagamento aprovado depois de a reserva ser cancelada';
  elsif not exists (select 1 from caixa_sessoes where status = 'Aberto') then v_motivo := 'Caixa fechado quando o pagamento foi aprovado';
  elsif _cardapio_bloqueio() is not null then v_motivo := 'Cardápio fechado quando o pagamento foi aprovado';
  end if;
  if v_motivo is not null then
    perform _mp_marcar_decidir(g.id, v_motivo);
    return jsonb_build_object('ok', true, 'decidir', true, 'motivo', v_motivo);
  end if;

  v_v := _mp_criar_venda(r.id, g.id);
  return jsonb_build_object('ok', true, 'vendaId', v_v->>'vendaId', 'numero', (v_v->>'numero')::int);
end $f$;

-- Operador de caixa ou Admin decide sobre um "Pagamento a decidir": seguir com o pedido ou reembolsar.
-- "reembolsar" só registra a decisão e solta a reserva; quem devolve o dinheiro é a função mp-reembolsar (Etapa 3), que depois avisa o banco.
create or replace function public.api_mp_decidir_pagamento(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare g pagamentos_online%rowtype; r pedidos_reserva%rowtype; v_dec text := lower(btrim(coalesce(p->>'decisao', ''))); v_v jsonb; v_id uuid := _uuid(p->>'pagamentoId');
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  if v_dec not in ('seguir', 'reembolsar') then return _falha('Escolha entre seguir com o pedido ou reembolsar.'); end if;
  select * into g from pagamentos_online where id = v_id;
  if not found then return _falha('Pagamento não encontrado.'); end if;
  select * into r from pedidos_reserva where id = g.reserva_id for update;
  select * into g from pagamentos_online where id = v_id for update;
  if not g.decisao_pendente or g.decisao is not null then return _falha('Este pagamento não está aguardando decisão.'); end if;
  if g.status <> 'aprovado' then return _falha('Só dá para decidir sobre um pagamento aprovado.'); end if;

  if v_dec = 'seguir' then
    if r.estado = 'confirmada' then return _falha('Já existe um pedido pago nesta reserva. Aqui só dá para reembolsar.'); end if;
    if not exists (select 1 from caixa_sessoes where status = 'Aberto') then return _falha('Abra o caixa para seguir com este pedido.'); end if;
    if r.estado <> 'ativa' then perform _mp_prender(r.id, true); end if;   -- reserva já foi solta: segura estoque, cupom e brinde de novo, sem barrar
    update pagamentos_online set decisao = 'seguir', decisao_pendente = false, decidido_por = auth.uid(), decidido_em = now(), atualizado_em = now() where id = g.id;
    v_v := _mp_criar_venda(r.id, g.id);
    perform _auditar('Pagamento online: seguir com o pedido', 'Pagamento ' || g.id || ' | Pedido Nº ' || (v_v->>'numero'), '');
    return jsonb_build_object('ok', true, 'decisao', 'seguir', 'vendaId', v_v->>'vendaId', 'numero', (v_v->>'numero')::int, 'message', 'Pedido liberado para a cozinha.');
  end if;

  if r.estado = 'ativa' then perform _mp_soltar(r.id, 'cancelada', 'Pagamento será reembolsado'); end if;
  update pagamentos_online set decisao = 'reembolsar', decisao_pendente = false, decidido_por = auth.uid(), decidido_em = now(), atualizado_em = now() where id = g.id;
  perform _auditar('Pagamento online: reembolsar', 'Pagamento ' || g.id || ' | R$ ' || _dinheiro(g.valor), '');
  return jsonb_build_object('ok', true, 'decisao', 'reembolsar', 'pagamentoId', g.id, 'valorAReembolsar', round(g.valor - g.valor_reembolsado, 2),
    'message', 'Decisão registrada. Falta devolver o dinheiro pelo Mercado Pago.');
end $f$;

-- ---------- 7) Funções só para as Edge Functions (chave de serviço) ----------
-- Credenciais do modo atual (ou do modo em que o pagamento foi criado). Nunca vão para o navegador.
create or replace function public.mp_credenciais(p_modo text default null) returns jsonb
 language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('ligado', c.ligado, 'modoAtual', case when c.modo = 'producao' then 'producao' else 'homologacao' end,
    'modo', m.modo, 'config', c.config,
    'publicKey', (select valor from integracoes_segredos where chave = case when m.modo = 'producao' then 'mp_public_key_producao' else 'mp_public_key_teste' end),
    'accessToken', (select valor from integracoes_segredos where chave = case when m.modo = 'producao' then 'mp_access_token_producao' else 'mp_access_token_teste' end),
    'webhookSecret', (select valor from integracoes_segredos where chave = 'mp_webhook_secret'))
  from integracoes_config c,
       lateral (select case when coalesce(p_modo, c.modo) = 'producao' then 'producao' else 'homologacao' end as modo) m
  where c.provedor = 'mercadopago'
$f$;

-- mp-criar chama antes de falar com o Mercado Pago. p: {reservaId, userId}. Confere dono, tempo, ligado, tentativas e cria a linha do pagamento.
-- Pix ainda valendo na mesma reserva: devolve o mesmo (reaproveitar = true), sem criar outro.
create or replace function public.mp_preparar_pagamento(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; f formas_pagamento%rowtype; g pagamentos_online%rowtype; v_modo text; v_novo uuid; v_email text; v_achou boolean;
begin
  select * into r from pedidos_reserva where id = _uuid(p->>'reservaId') for update;
  if not found or r.user_id is distinct from _uuid(p->>'userId') then return _falha('Pedido não encontrado.'); end if;
  if r.estado = 'confirmada' then return _falha('Este pedido já foi pago.'); end if;
  if r.estado <> 'ativa' or r.expira_em < now() then return _falha('O tempo deste pedido acabou. Faça o pedido de novo.'); end if;
  if coalesce((public.api_mp_config_publica('{}'::jsonb)->>'ligado')::boolean, false) is not true then return _falha('O pagamento pelo site não está disponível agora.'); end if;
  select * into f from formas_pagamento where id = r.forma_pagamento_id;
  if f.id is null or not f.aceita_online or f.tipo_online is null then return _falha('Forma de pagamento inválida.'); end if;
  if exists (select 1 from pagamentos_online where reserva_id = r.id and status = 'aprovado') then return _falha('Este pedido já foi pago.'); end if;
  if (select count(*) from pagamentos_online where reserva_id = r.id) >= 5 then return _falha('Muitas tentativas de pagamento. Faça o pedido de novo.'); end if;

  select * into g from pagamentos_online
   where reserva_id = r.id and metodo = 'pix' and status = 'aguardando' and pix_copia_cola is not null and (pix_expira_em is null or pix_expira_em > now())
   order by criado_em desc limit 1;
  v_achou := found;
  if v_achou and f.tipo_online = 'pix' then
    return jsonb_build_object('ok', true, 'reaproveitar', true, 'pagamentoId', g.id, 'metodo', 'pix', 'valor', g.valor,
      'pixCopiaCola', g.pix_copia_cola, 'pixQrBase64', g.pix_qr_base64, 'pixExpiraEm', g.pix_expira_em);
  end if;
  if f.tipo_online = 'credito' and exists (select 1 from pagamentos_online where reserva_id = r.id and metodo = 'credito' and status = 'aguardando' and criado_em > now() - interval '2 minutes') then
    return _falha('Seu pagamento está em andamento. Aguarde alguns segundos.');
  end if;

  update pagamentos_online set status = 'cancelado', status_detalhe = 'substituído por nova tentativa', atualizado_em = now() where reserva_id = r.id and status = 'aguardando';
  select case when modo = 'producao' then 'producao' else 'homologacao' end into v_modo from integracoes_config where provedor = 'mercadopago';
  insert into pagamentos_online (reserva_id, user_id, metodo, mp_modo, valor) values (r.id, r.user_id, f.tipo_online, v_modo, r.valor_total) returning id into v_novo;
  select email into v_email from auth.users where id = r.user_id;   -- só é repassado ao Mercado Pago; não é guardado aqui
  return jsonb_build_object('ok', true, 'pagamentoId', v_novo, 'metodo', f.tipo_online, 'modo', v_modo, 'valor', r.valor_total, 'expiraEm', r.expira_em,
    'email', v_email, 'nome', r.cliente_nome,
    'itens', (select coalesce(jsonb_agg(jsonb_build_object('titulo', left(coalesce(e->>'descricao', 'Item'), 100), 'quantidade', _num(e->>'quantidade', 1), 'valorUnitario', _num(e->>'valorUnitario'))), '[]'::jsonb)
                from jsonb_array_elements(r.itens) e));
end $f$;

-- Única porta de entrada do resultado do Mercado Pago (criação, aviso/webhook, consulta ativa, reembolso). O status chega JÁ traduzido pela função da nuvem:
--   status = aguardando | aprovado | recusado | expirado | cancelado | reembolso_parcial | reembolsado | erro
-- p: {pagamentoId ou mpOrderId, status, statusDetalhe, mpOrderId, mpPaymentId, pixCopiaCola, pixQrBase64, pixExpiraEm, cartaoFinal, cartaoBandeira,
--     valorReembolsado, erro, chaveEvento (só aviso), assinaturaOk (só aviso), tipoEvento, statusMp, detalhe}
-- Aviso repetido (mesma chaveEvento) é ignorado. Aviso com assinatura inválida só é registrado e nada mais acontece.
create or replace function public.mp_aplicar_status(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare g pagamentos_online%rowtype; v_chave text := nullif(btrim(coalesce(p->>'chaveEvento', '')), ''); v_ass boolean := coalesce((p->>'assinaturaOk')::boolean, false);
        v_st text := lower(btrim(coalesce(p->>'status', ''))); v_ev bigint; v_vr numeric; v_res jsonb; v_reserva uuid; v_oid text := nullif(btrim(coalesce(p->>'mpOrderId', '')), '');
begin
  if v_chave is not null and not v_ass then
    insert into pagamentos_online_eventos (chave, tipo, status_mp, assinatura_ok, detalhe)
    values ('invalida:' || gen_random_uuid()::text, left(coalesce(p->>'tipoEvento', ''), 60), left(coalesce(p->>'statusMp', ''), 60), false, p->'detalhe');
    return jsonb_build_object('ok', false, 'ignorado', 'assinatura');
  end if;
  if v_st not in ('aguardando', 'aprovado', 'recusado', 'expirado', 'cancelado', 'reembolso_parcial', 'reembolsado', 'erro') then return _falha('Status inválido.'); end if;

  select reserva_id into v_reserva from pagamentos_online where id = _uuid(p->>'pagamentoId');
  if v_reserva is null and v_oid is not null then select reserva_id into v_reserva from pagamentos_online where mp_order_id = v_oid; end if;
  if v_reserva is null then
    if v_chave is not null then
      insert into pagamentos_online_eventos (chave, tipo, status_mp, assinatura_ok, detalhe) values (v_chave, left(coalesce(p->>'tipoEvento', ''), 60), left(coalesce(p->>'statusMp', ''), 60), true, p->'detalhe')
      on conflict (chave) do nothing;
    end if;
    return jsonb_build_object('ok', false, 'ignorado', 'pagamento_desconhecido');
  end if;
  perform 1 from pedidos_reserva where id = v_reserva for update;                 -- trava: reserva primeiro, depois o pagamento
  select * into g from pagamentos_online where id = coalesce(_uuid(p->>'pagamentoId'), (select id from pagamentos_online where mp_order_id = v_oid)) for update;

  if v_chave is not null then
    insert into pagamentos_online_eventos (chave, pagamento_id, tipo, status_mp, assinatura_ok, detalhe)
    values (v_chave, g.id, left(coalesce(p->>'tipoEvento', ''), 60), left(coalesce(p->>'statusMp', ''), 60), true, p->'detalhe')
    on conflict (chave) do nothing returning id into v_ev;
    if v_ev is null then return jsonb_build_object('ok', true, 'duplicado', true); end if;
  end if;

  update pagamentos_online set
    mp_order_id = coalesce(v_oid, mp_order_id), mp_payment_id = coalesce(nullif(p->>'mpPaymentId', ''), mp_payment_id),
    pix_copia_cola = coalesce(nullif(p->>'pixCopiaCola', ''), pix_copia_cola), pix_qr_base64 = coalesce(nullif(p->>'pixQrBase64', ''), pix_qr_base64),
    pix_expira_em = coalesce(nullif(p->>'pixExpiraEm', '')::timestamptz, pix_expira_em),
    cartao_final = case when p->>'cartaoFinal' ~ '^[0-9]{4}$' then p->>'cartaoFinal' else cartao_final end,
    cartao_bandeira = coalesce(left(nullif(p->>'cartaoBandeira', ''), 30), cartao_bandeira),
    status_detalhe = case when p ? 'statusDetalhe' then left(coalesce(p->>'statusDetalhe', ''), 200) else status_detalhe end, atualizado_em = now()
   where id = g.id;
  select * into g from pagamentos_online where id = g.id;

  if v_st = 'aprovado' then
    if g.status not in ('reembolso_parcial', 'reembolsado') then v_res := _mp_confirmar_pagamento(g.id); end if;
  elsif v_st in ('recusado', 'expirado', 'cancelado') then
    if g.status = 'aguardando' then update pagamentos_online set status = v_st, atualizado_em = now() where id = g.id; end if;
  elsif v_st = 'erro' then
    if g.status = 'aguardando' then
      update pagamentos_online set status = 'erro', erro = left(coalesce(p->>'erro', ''), 300), atualizado_em = now() where id = g.id;
      -- não deu nem para criar o pagamento: solta a reserva na hora (a página oferece pagar na entrega)
      if exists (select 1 from pedidos_reserva where id = g.reserva_id and estado = 'ativa')
         and not exists (select 1 from pagamentos_online where reserva_id = g.reserva_id and status = 'aprovado') then
        perform _mp_soltar(g.reserva_id, 'cancelada', 'Erro ao criar o pagamento');
      end if;
    end if;
  elsif v_st in ('reembolso_parcial', 'reembolsado') then
    if g.status in ('aprovado', 'reembolso_parcial', 'reembolsado') then
      v_vr := round(least(g.valor, greatest(g.valor_reembolsado, case when v_st = 'reembolsado' then g.valor else coalesce(_num(p->>'valorReembolsado'), 0) end)), 2);
      update pagamentos_online set valor_reembolsado = v_vr, status = case when v_vr >= g.valor then 'reembolsado' else 'reembolso_parcial' end, atualizado_em = now() where id = g.id;
      if v_vr >= g.valor and g.venda_id is not null then
        update reembolsos set status = 'Devolvido', devolvido_em = now(), observacao = 'Reembolsado pelo Mercado Pago' where venda_id = g.venda_id and status = 'Pendente';
      end if;
      perform _auditar('Reembolso Mercado Pago', 'Pagamento ' || g.id || ' | R$ ' || _dinheiro(v_vr) || ' de R$ ' || _dinheiro(g.valor), '');
    end if;
  end if;

  return jsonb_build_object('ok', true, 'pagamentoId', g.id, 'status', (select status from pagamentos_online where id = g.id), 'resultado', v_res);
end $f$;

-- Rodada a cada minuto (pg_cron): reservas vencidas sem pagamento devolvem estoque, cupom e brinde. Nada é apagado.
-- Reserva com pagamento aprovado ou aguardando decisão NÃO vence: segue até alguém decidir.
create or replace function public.mp_expirar_reservas() returns int
 language plpgsql security definer set search_path to 'public' as $f$
declare r record; n int := 0;
begin
  for r in select id from pedidos_reserva where estado = 'ativa' and expira_em < now() order by expira_em limit 100 for update skip locked loop
    if exists (select 1 from pagamentos_online g where g.reserva_id = r.id and (g.status = 'aprovado' or (g.decisao_pendente and g.decisao is null))) then continue; end if;
    update pagamentos_online set status = 'expirado', status_detalhe = 'reserva vencida', atualizado_em = now() where reserva_id = r.id and status = 'aguardando';
    perform _mp_soltar(r.id, 'expirada', 'Tempo esgotado sem pagamento');
    n := n + 1;
  end loop;
  return n;
end $f$;

do $d$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    if not exists (select 1 from cron.job where jobname = 'mp-expirar-reservas') then
      perform cron.schedule('mp-expirar-reservas', '* * * * *', 'select public.mp_expirar_reservas()');
    end if;
  end if;
end $d$;

-- ---------- 8) Permissões ----------
revoke all on function public._mp_prender(uuid, boolean), public._mp_soltar(uuid, text, text), public._mp_criar_venda(uuid, uuid),
  public._mp_marcar_decidir(uuid, text), public._mp_confirmar_pagamento(uuid), public._criar_pedido_publico(jsonb, uuid, boolean) from public, anon, authenticated;
revoke all on function public.api_mp_reservar(jsonb), public.api_mp_status_pagamento(jsonb), public.api_mp_cancelar_reserva(jsonb), public.api_mp_decidir_pagamento(jsonb) from public, anon;
grant execute on function public.api_mp_reservar(jsonb), public.api_mp_status_pagamento(jsonb), public.api_mp_cancelar_reserva(jsonb), public.api_mp_decidir_pagamento(jsonb) to authenticated;
revoke all on function public.mp_credenciais(text), public.mp_preparar_pagamento(jsonb), public.mp_aplicar_status(jsonb), public.mp_expirar_reservas() from public, anon, authenticated;
grant execute on function public.mp_credenciais(text), public.mp_preparar_pagamento(jsonb), public.mp_aplicar_status(jsonb), public.mp_expirar_reservas() to service_role;

commit;
```

## Etapa 3 — Funções na nuvem (Edge Functions)

**Objetivo:** falar com o Mercado Pago só pelo servidor.

**Status: feita e aprovada.** Nada foi publicado. Arquivos: pasta `SUPABASE/supabase-codigo/funcoes/` com `mp-criar`, `mp-webhook`, `mp-status` e `mp-reembolsar` (cada uma com `index.ts`, `mp.ts` e `mp-puro.ts`; os dois últimos são iguais nas quatro) e `testes/mp-etapa3/` (`bash rodar.sh`). Publicar as quatro com `verify_jwt` desligado, depois das Etapas 1 e 2 no banco. Não há segredo novo para cadastrar: as chaves vêm do banco (`mp_credenciais`). Com a integração desligada, nada chama essas funções.

| Função | Quem chama | Para quê |
| --- | --- | --- |
| `mp-criar` | cliente logado (cardápio) | cria o Pix ou o cartão no Mercado Pago (`POST /v1/orders`). O valor vem da reserva no banco, nunca da tela |
| `mp-webhook` | só o Mercado Pago | recebe o aviso, confere a assinatura, **consulta o pedido** no Mercado Pago e entrega o resultado ao banco |
| `mp-status` | cliente logado | consulta ativa quando o aviso atrasa; devolve a situação para a tela |
| `mp-reembolsar` | Admin ou Operador | devolve o dinheiro (total ou parcial), só com decisão já registrada |

**Como funciona (resumo)**

- **Idempotência:** a chave do Mercado Pago na criação é o id do pagamento no banco; repetir a chamada nunca cobra duas vezes. No reembolso é pagamento + valor já devolvido + valor pedido.
- **Rede ou 5xx:** `mp-criar` tenta de novo uma vez, com a mesma chave. Se ainda falhar, solta a reserva e a página oferece pagar na entrega. Cartão recusado mantém a reserva.
- **Antes de gastar tentativa:** dado de cartão faltando ou CPF inválido é recusado antes de chamar o banco.
- **Webhook:** assinatura inválida só é registrada (resposta 401). O aviso nunca é confiado: o status vem de `GET /v1/orders/{id}`. Aviso repetido é ignorado pelo banco. Erro nosso responde 500 (o Mercado Pago reenvia); pedido que não é nosso, ou o "Simular" do painel, responde 200.
- **Reembolso:** só devolve se o pagamento tem decisão "reembolsar" **ou** a venda cancelada tem reembolso "Pendente". Qualquer outro pedido é recusado.
- **Nada sensível no log:** nem token do cartão, nem CPF, nem Access Token.

**Status do Mercado Pago → banco**

| Mercado Pago | Banco |
| --- | --- |
| processed / accredited | aprovado |
| processed / partially_refunded | reembolso_parcial |
| refunded | reembolsado |
| failed | recusado |
| expired | expirado |
| canceled | cancelado |
| created, processing, action_required (waiting_transfer, pending_challenge) ou qualquer valor novo | aguardando |

**Escolhas desta etapa (me corrija se discordar)**

- **Corpo mínimo ao Mercado Pago:** só os campos da documentação (valor, referência, e-mail, CPF no cartão). Não mando `items`: com desconto, taxa e acréscimo a soma não bate e poderia ser recusada.
- **Pix de 15 minutos:** o Mercado Pago só aceita vencimento a partir de 30 minutos, então o QR vale 30 lá, mas o seu cronômetro e a reserva são de 15. Para ninguém pagar um QR "morto": `mp-criar` cancela no Mercado Pago o Pix substituído por um novo, e `mp-status` cancela lá o Pix que já venceu ou foi cancelado aqui (melhor esforço). O que escapar cai em "Pagamento a decidir", como combinado.
- **Cronômetro da tela:** na Etapa 5 usar `reservaExpiraEm` (15 min), não `pix.expiraEm` (o do Mercado Pago, 30 min).
- **Quem reembolsa:** Admin, Operador e Desenvolvedor (que vale como Admin no banco).
- **Cartão:** só crédito e só à vista. Débito é recusado.
- **Limite de abuso:** 12 criações por minuto por cliente (o limite de 5 tentativas por reserva continua no banco).

**Ainda não conferido com o Mercado Pago de verdade (conferir na Etapa 8 com a conta de teste)**

1. O endereço de cancelar pedido (`POST /v1/orders/{id}/cancel`): a documentação que li cita a função, mas não mostrei o endereço exato. Se falhar, só deixa de cancelar o QR velho.
2. A **chave secreta do webhook** pode ser uma para o modo Teste e outra para Produção. Hoje o banco guarda uma só (`mp_webhook_secret`). Se forem diferentes, troco por duas na Etapa 4.
3. Nomes de campos que eu li pouco: final do cartão (`last_four_digits`), lista de reembolsos feitos fora do sistema (`transactions.refunds`), e a página de autenticação 3DS (`transaction_security.url`). Se não vierem, o pagamento funciona igual; só não aparece o final do cartão e o 3DS precisaria de ajuste.
4. O e-mail do pagador em modo Teste (o Mercado Pago pode exigir e-mail de usuário de teste).
5. O texto assinado do aviso: usei `id:…;request-id:…;ts:…;` (aceitando o id como veio e em minúsculas). Na documentação que li o passo "Sem SDKs" não carregou; confirmo com o botão "Simular".

**Testes feitos:** 42 conferências das partes puras (assinatura, tradução de status, CPF, textos) e 64 de fluxo das quatro funções, com Supabase e Mercado Pago de mentira (Pix, cartão aprovado/recusado, Mercado Pago fora do ar, assinatura inválida, aviso repetido, "Simular", permissões, reembolso total e parcial, CORS, freio). Tipos conferidos com `tsc`. **Não rodei no Deno nem contra o Mercado Pago real.**

**O que a Etapa 5 (tela) vai usar**

- `mp-criar` recebe `{reservaId}` (Pix) ou `{reservaId, token, paymentMethodId, paymentTypeId, payerCpf}` (cartão) e devolve `{ok, estado, pagamentoId, metodo, pix?{copiaCola, qrBase64, expiraEm}, reservaExpiraEm, numero?, mensagem?, desafio?}`.
- `estado`: `aguardando`, `aprovado`, `conferindo` (aprovado, mas caiu em "Pagamento a decidir"), `recusado`, `erro` (reserva solta: oferecer pagar na entrega).
- `mp-status` recebe `{reservaId}` e devolve o mesmo que `api_mp_status_pagamento`.

**Código usado**

**mp-puro.ts (funções puras)**

```ts
// =====================================================================
// MERCADO PAGO · funções PURAS (sem rede, sem banco, sem Deno): tradução de status, assinatura do aviso, CPF, textos.
// Este arquivo é copiado igual para dentro de mp-criar, mp-webhook, mp-status e mp-reembolsar.
// Escrito a partir da documentação pública do Mercado Pago (Orders API, 13/10/2026): ainda NÃO testado contra o Mercado Pago de verdade.
// =====================================================================

export type StatusBanco = "aguardando" | "aprovado" | "recusado" | "expirado" | "cancelado" | "reembolso_parcial" | "reembolsado" | "erro";

export const num = (x: unknown): number => { const n = Number(String(x ?? "").replace(",", ".")); return Number.isFinite(n) ? n : 0; };
export const dinheiro = (n: number): string => (Math.round(n * 100) / 100).toFixed(2);   // o Mercado Pago quer texto "00.00"
export const centavos = (n: number): number => Math.round(n * 100);
export const apenasDigitos = (s: unknown): string => String(s ?? "").replace(/\D+/g, "");
export const minusc = (s: unknown): string => String(s ?? "").trim().toLowerCase();
export const ehUuid = (s: unknown): boolean => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(s ?? ""));

// CPF com os dois dígitos verificadores (recusa 111.111.111-11 e parecidos)
export function cpfValido(valor: unknown): boolean {
  const c = apenasDigitos(valor);
  if (c.length !== 11 || /^(\d)\1{10}$/.test(c)) return false;
  for (let t = 9; t < 11; t++) {
    let soma = 0;
    for (let i = 0; i < t; i++) soma += Number(c[i]) * (t + 1 - i);
    const dv = ((soma * 10) % 11) % 10;
    if (dv !== Number(c[t])) return false;
  }
  return true;
}

// Duração ISO 8601 do vencimento do Pix. O Mercado Pago aceita no mínimo 30 minutos (e no máximo 30 dias).
export function duracaoPix(minutos: number): string { return "PT" + Math.max(30, Math.min(43200, Math.ceil(minutos))) + "M"; }

// ---------- status do Mercado Pago → status do banco ----------
// Pedido (order) e transação (payment) usam: created, processing, action_required (waiting_payment/waiting_transfer/pending_challenge),
// processed (accredited | partially_refunded), failed, expired, canceled, refunded.
export function mapearStatus(statusMp: unknown, detalheMp: unknown): StatusBanco {
  const s = minusc(statusMp), d = minusc(detalheMp);
  if (s === "refunded" || d === "refunded") return "reembolsado";
  if (s === "processed") return d === "partially_refunded" ? "reembolso_parcial" : "aprovado";
  if (s === "failed") return "recusado";
  if (s === "expired") return "expirado";
  if (s === "canceled" || s === "cancelled") return "cancelado";
  return "aguardando";   // created, processing, action_required, at_terminal e qualquer valor novo: espera, nunca aprova por engano
}

export interface Traducao {
  status: StatusBanco; statusMp: string; detalheMp: string; orderId: string; paymentId: string; externalReference: string;
  valorPago: number; valorReembolsado: number;
  pix: { copiaCola: string; qrBase64: string; ticketUrl: string; expiraEm: string } | null;
  cartaoFinal: string; cartaoBandeira: string;
  desafio: { url: string } | null;   // autenticação 3DS pedida pelo banco do cartão (se vier)
}

// Lê a resposta de POST/GET /v1/orders e devolve só o que o banco precisa. Prefere o status da transação; sem ela, usa o do pedido.
export function traduzirOrder(o: any): Traducao {
  const pg = Array.isArray(o?.transactions?.payments) ? o.transactions.payments[0] : null;
  const pm = pg?.payment_method || {};
  const statusMp = String(pg?.status || o?.status || ""), detalheMp = String(pg?.status_detail || o?.status_detail || "");
  const refunds: any[] = Array.isArray(o?.transactions?.refunds) ? o.transactions.refunds : [];
  const reemb = refunds.reduce((t, r) => t + (minusc(r?.status) === "failed" ? 0 : num(r?.amount)), 0);
  const final4 = [pm.last_four_digits, pm.card?.last_four_digits, pm.card_last_four_digits].map(apenasDigitos).find((x) => /^\d{4}$/.test(x)) || "";
  const url3ds = String(pm?.transaction_security?.url || "");
  const eh = String(pm.type || "") === "bank_transfer" || String(pm.id || "") === "pix";
  return {
    status: mapearStatus(statusMp, detalheMp), statusMp, detalheMp,
    orderId: String(o?.id || ""), paymentId: String(pg?.id || ""), externalReference: String(o?.external_reference || ""),
    valorPago: num(pg?.paid_amount ?? o?.total_paid_amount), valorReembolsado: Math.round(reemb * 100) / 100,
    pix: eh && (pm.qr_code || pm.qr_code_base64) ? { copiaCola: String(pm.qr_code || ""), qrBase64: String(pm.qr_code_base64 || ""), ticketUrl: String(pm.ticket_url || ""), expiraEm: String(pg?.date_of_expiration || "") } : null,
    cartaoFinal: final4, cartaoBandeira: String(pm.type === "credit_card" || pm.type === "debit_card" ? (pm.id || "") : "").slice(0, 30),
    desafio: /^https:\/\//i.test(url3ds) ? { url: url3ds } : null,
  };
}

// Texto para o cliente quando o cartão não passa (nunca mostra o código bruto do Mercado Pago)
export function mensagemRecusa(detalhe: unknown): string {
  const d = minusc(detalhe);
  if (d === "insufficient_amount") return "O cartão não tem limite suficiente. Tente outro cartão ou pague na entrega.";
  if (d === "card_disabled") return "Esse cartão está desativado. Tente outro cartão ou pague na entrega.";
  if (d === "amount_limit_exceeded") return "O valor passou do limite do cartão. Tente outro cartão ou pague na entrega.";
  if (d === "high_risk") return "O pagamento foi recusado por segurança. Tente outro cartão ou pague na entrega.";
  if (d === "invalid_card_token" || d === "bad_filled_card_data") return "Confira os dados do cartão e tente de novo.";
  if (d === "invalid_installments") return "Esse cartão não aceita pagamento à vista neste pedido. Tente outro cartão.";
  return "O pagamento não foi aprovado. Tente outro cartão ou pague na entrega.";
}

// Código do erro do Mercado Pago (só para o log, sem dados do cliente)
export function codigoErroMp(j: any): string {
  const e = Array.isArray(j?.errors) ? j.errors[0] : null;
  return String(e?.code || j?.error || j?.code || j?.message || "").slice(0, 80);
}

// ---------- assinatura do aviso (webhook) ----------
export function lerAssinatura(h: string | null | undefined): { ts: string; v1: string } {
  let ts = "", v1 = "";
  for (const parte of String(h || "").split(",")) {
    const i = parte.indexOf("="); if (i < 0) continue;
    const k = parte.slice(0, i).trim(), v = parte.slice(i + 1).trim();
    if (k === "ts") ts = v; else if (k === "v1") v1 = v;
  }
  return { ts, v1 };
}
export async function hmacHex(segredo: string, texto: string): Promise<string> {
  const enc = new TextEncoder();
  const chave = await crypto.subtle.importKey("raw", enc.encode(segredo), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const ass = await crypto.subtle.sign("HMAC", chave, enc.encode(texto));
  return Array.from(new Uint8Array(ass)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
export function iguaisSeguro(a: string, b: string): boolean {   // compara sem parar no primeiro caractere diferente
  if (a.length !== b.length) return false;
  let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
// Texto assinado: "id:<data.id>;request-id:<x-request-id>;ts:<ts>;" (parte ausente sai do texto). O id é aceito como veio e em minúsculas.
export async function validarAssinatura(o: { segredo: string; assinatura: string | null; requestId: string | null; ids: string[] }): Promise<boolean> {
  const { ts, v1 } = lerAssinatura(o.assinatura);
  if (!o.segredo || !ts || !v1) return false;
  const candidatos = Array.from(new Set(o.ids.filter(Boolean).flatMap((x) => [x, x.toLowerCase()])));
  if (!candidatos.length) candidatos.push("");
  for (const id of candidatos) {
    const manifesto = (id ? `id:${id};` : "") + (o.requestId ? `request-id:${o.requestId};` : "") + `ts:${ts};`;
    if (iguaisSeguro(await hmacHex(o.segredo, manifesto), v1.toLowerCase())) return true;
  }
  return false;
}
```

**mp.ts (apoio)**

```ts
// =====================================================================
// MERCADO PAGO · apoio das 4 Edge Functions (rede, banco, login). Copiado igual para dentro de cada pasta.
// verify_jwt = false em todas: cada função confere sozinha quem chamou (cliente logado, equipe ou assinatura do Mercado Pago).
// Segredos NUNCA ficam aqui: o Access Token e a chave do aviso vêm do banco (mp_credenciais, só chave de serviço).
// Nada sensível vai para o log: nem token do cartão, nem CPF, nem corpo da requisição.
// =====================================================================
import { createClient } from "npm:@supabase/supabase-js@2";
import { ehUuid } from "./mp-puro.ts";

export const URL_ = Deno.env.get("SUPABASE_URL")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
export const svc = createClient(URL_, SVC, { auth: { persistSession: false } });
export const MP_BASE = Deno.env.get("MP_BASE") || "https://api.mercadopago.com";

// ---------- CORS (o cardápio e o app falam com estas funções pelo navegador) ----------
const ORIGENS = ["https://texasburguer.github.io", "http://localhost:8080", "http://127.0.0.1:8080", "http://localhost:5500", "http://127.0.0.1:5500"];
export const cors = (req: Request) => {
  const o = req.headers.get("origin") || "";
  return { "Access-Control-Allow-Origin": ORIGENS.includes(o) ? o : ORIGENS[0], "Vary": "Origin",
    "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info", "Access-Control-Allow-Methods": "POST, OPTIONS" };
};
export const resp = (req: Request, corpo: unknown, status = 200) =>
  new Response(JSON.stringify(corpo), { status, headers: { ...cors(req), "Content-Type": "application/json; charset=utf-8" } });

// ---------- log sem dados sensíveis ----------
export const log = (evento: string, detalhe: Record<string, unknown> = {}) => { try { console.log(JSON.stringify({ evento, ...detalhe })); } catch { /* nada */ } };

// ---------- limite simples por instância (freio de abuso; o limite de verdade está no banco) ----------
const _lim = new Map<string, number[]>();
export function limite(chave: string, max: number, janelaMs: number): boolean {
  const agora = Date.now(); const l = (_lim.get(chave) || []).filter((t) => agora - t < janelaMs);
  if (l.length >= max) { _lim.set(chave, l); return false; }
  l.push(agora); _lim.set(chave, l);
  if (_lim.size > 5000) for (const k of _lim.keys()) { _lim.delete(k); if (_lim.size < 2500) break; }
  return true;
}

// ---------- quem chamou ----------
export const bearer = (req: Request) => (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "").trim();
export async function usuario(req: Request): Promise<{ id: string; email: string; token: string } | null> {
  const token = bearer(req); if (!token) return null;
  const { data } = await svc.auth.getUser(token);
  return data?.user ? { id: data.user.id, email: data.user.email || "", token } : null;
}
// Equipe (Admin, Operador; o Desenvolvedor vale como Admin, igual a auth_nivel() no banco). Devolve null se não puder.
export async function equipe(req: Request, niveis: string[]): Promise<{ id: string; nivel: string } | null> {
  const u = await usuario(req); if (!u) return null;
  const { data: usr } = await svc.from("usuarios").select("id,nivel,ativo").eq("id", u.id).maybeSingle();
  if (!usr || usr.ativo === false || !niveis.includes(usr.nivel)) return null;
  return { id: usr.id, nivel: usr.nivel };
}

// ---------- banco ----------
export async function rpc(fn: string, args: Record<string, unknown> = {}): Promise<any> {
  const { data, error } = await svc.rpc(fn, args);
  if (error) throw new Error(fn + ": " + error.message);
  return data;
}
export const credenciais = async (modo?: string | null) => await rpc("mp_credenciais", { p_modo: modo ?? null });   // {ligado, modoAtual, modo, config, publicKey, accessToken, webhookSecret}
export const aplicarStatus = async (p: Record<string, unknown>) => await rpc("mp_aplicar_status", { p });

// Chave pública do projeto (para chamar funções do banco COMO o cliente logado, ex.: api_mp_status_pagamento)
let _pk = "";
export async function chavePublica(): Promise<string> {
  if (_pk) return _pk;
  _pk = Deno.env.get("SB_PUBLISHABLE_KEY") || Deno.env.get("SUPABASE_ANON_KEY") || "";
  if (!_pk) { try { const { data } = await svc.rpc("api_segredo", { p_nome: "publishable_key" }); _pk = (data as string) || ""; } catch { /* nada */ } }
  return _pk;
}
export async function comoCliente(token: string) {
  return createClient(URL_, await chavePublica(), { global: { headers: { Authorization: `Bearer ${token}` } }, auth: { persistSession: false } });
}

// ---------- Mercado Pago ----------
export class MpRede extends Error { constructor() { super("rede_ou_timeout"); } }
export async function mpChamar(metodo: "GET" | "POST", caminho: string, accessToken: string, corpo?: unknown, chaveIdem?: string, ms = 25000): Promise<{ status: number; json: any }> {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), ms);
  try {
    const h: Record<string, string> = { Authorization: "Bearer " + accessToken, Accept: "application/json" };
    let body: string | undefined;
    if (corpo !== undefined) { body = JSON.stringify(corpo); h["Content-Type"] = "application/json"; }
    if (metodo === "POST") h["X-Idempotency-Key"] = (chaveIdem || crypto.randomUUID()).slice(0, 64);   // 1 a 64 caracteres
    const r = await fetch(MP_BASE + caminho, { method: metodo, headers: h, body, signal: ctl.signal });
    const txt = await r.text(); let json: any = null; try { json = txt ? JSON.parse(txt) : null; } catch { json = { message: txt.slice(0, 200) }; }
    return { status: r.status, json };
  } catch { throw new MpRede(); } finally { clearTimeout(t); }
}
// POST que repete UMA vez, com a MESMA chave de idempotência, se a rede cair ou o Mercado Pago responder 429/5xx (a chave impede cobrança dupla)
export async function mpPostComRetentativa(caminho: string, accessToken: string, corpo: unknown, chaveIdem: string): Promise<{ status: number; json: any }> {
  let ultimo: { status: number; json: any } | null = null;
  for (let i = 0; i < 2; i++) {
    try {
      const r = await mpChamar("POST", caminho, accessToken, corpo, chaveIdem);
      if (r.status !== 429 && r.status < 500) return r;
      ultimo = r;
    } catch (e) { if (!(e instanceof MpRede)) throw e; ultimo = null; }
    if (i === 0) await new Promise((ok) => setTimeout(ok, 1500));
  }
  if (ultimo) return ultimo;
  throw new MpRede();
}
export { ehUuid };
```

**mp-criar/index.ts**

```ts
// =====================================================================
// mp-criar · cria o pagamento (Pix ou cartão de crédito) no Mercado Pago, pela Orders API. Chamada pelo cardápio (cliente LOGADO).
// verify_jwt = false: a função confere o login do cliente ela mesma (auth.getUser) e o dono da reserva (mp_preparar_pagamento).
// Entrada: { reservaId, token?, paymentMethodId?, paymentTypeId?, payerCpf? }   (os campos de cartão só vêm no cartão)
// Saída:   { ok, estado: aguardando | aprovado | conferindo | recusado | erro, pagamentoId, metodo, pix?, numero?, mensagem? }
// Regras:
//  • o valor vem SEMPRE do banco (reserva já validada): o navegador nunca diz quanto cobrar;
//  • idempotência: a chave do Mercado Pago é o id do pagamento no banco, então repetir a chamada nunca cobra duas vezes;
//  • rede/timeout/5xx: repete UMA vez com a mesma chave; se ainda falhar, solta a reserva e a página oferece "pagar na entrega";
//  • cartão recusado mantém a reserva para outra tentativa; Pix ainda valendo é reaproveitado (decidido no banco);
//  • CPF só vai ao Mercado Pago (cartão) e nada de cartão/CPF é gravado nem escrito no log.
// =====================================================================
import { resp, cors, usuario, svc, rpc, credenciais, aplicarStatus, mpChamar, mpPostComRetentativa, MpRede, limite, log } from "./mp.ts";
import { apenasDigitos, cpfValido, dinheiro, duracaoPix, ehUuid, mensagemRecusa, minusc, traduzirOrder, codigoErroMp } from "./mp-puro.ts";

// Pix antigo da mesma reserva trocado por um novo: cancela no Mercado Pago para ninguém pagar o QR velho (melhor esforço)
async function cancelarSubstituidos(reservaId: string, novoId: string, accessToken: string) {
  try {
    const { data } = await svc.from("pagamentos_online").select("id,mp_order_id").eq("reserva_id", reservaId).eq("metodo", "pix").eq("status", "cancelado")
      .eq("status_detalhe", "substituído por nova tentativa").not("mp_order_id", "is", null).neq("id", novoId).limit(5);
    for (const g of data || []) {
      try {
        await mpChamar("POST", `/v1/orders/${encodeURIComponent(g.mp_order_id)}/cancel`, accessToken, undefined, "cancel-" + g.id, 8000);
        await svc.from("pagamentos_online").update({ status_detalhe: "substituído (cancelado no Mercado Pago)" }).eq("id", g.id);
      } catch { /* melhor esforço */ }
    }
  } catch { /* melhor esforço */ }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors(req) });
  if (req.method !== "POST") return resp(req, { ok: false, message: "Método não permitido." }, 405);
  try {
    const u = await usuario(req);
    if (!u) return resp(req, { ok: false, message: "Entre na sua conta para pagar pelo site." }, 401);
    if (!limite("criar:" + u.id, 12, 60000)) return resp(req, { ok: false, message: "Muitas tentativas seguidas. Aguarde um minuto e tente de novo." }, 429);
    const corpo = await req.json().catch(() => ({}));
    const reservaId = String(corpo?.reservaId || "");
    if (!ehUuid(reservaId)) return resp(req, { ok: false, message: "Pedido inválido. Volte ao carrinho e tente de novo." }, 400);

    // 1) descobre o método da reserva ANTES de gastar uma tentativa (assim dado de cartão faltando não conta como tentativa)
    const { data: rv } = await svc.from("pedidos_reserva").select("user_id,forma_pagamento_id").eq("id", reservaId).maybeSingle();
    if (!rv || rv.user_id !== u.id) return resp(req, { ok: false, message: "Pedido não encontrado." });
    const { data: fp } = await svc.from("formas_pagamento").select("tipo_online").eq("id", rv.forma_pagamento_id).maybeSingle();
    const metodoPedido = fp?.tipo_online === "credito" ? "credito" : fp?.tipo_online === "pix" ? "pix" : "";
    if (!metodoPedido) return resp(req, { ok: false, message: "Esta forma de pagamento não é aceita pelo site." });

    let cartao: { token: string; bandeira: string; cpf: string } | null = null;
    if (metodoPedido === "credito") {
      const token = String(corpo?.token || ""), bandeira = minusc(corpo?.paymentMethodId), cpf = apenasDigitos(corpo?.payerCpf);
      if (minusc(corpo?.paymentTypeId || "credit_card") !== "credit_card") return resp(req, { ok: false, message: "Aceitamos só cartão de crédito pelo site." });
      if (!/^[A-Za-z0-9_-]{10,80}$/.test(token) || !/^[a-z0-9_]{2,25}$/.test(bandeira)) return resp(req, { ok: false, message: "Os dados do cartão não chegaram. Digite de novo." });
      if (!cpfValido(cpf)) return resp(req, { ok: false, message: "CPF inválido. Confira os números." });
      cartao = { token, bandeira, cpf };
    }

    // 2) o banco confere dono, tempo, ligado e tentativas, e cria a linha do pagamento (ou devolve o Pix que ainda vale)
    const prep: any = await rpc("mp_preparar_pagamento", { p: { reservaId, userId: u.id } });
    if (!prep?.ok) return resp(req, { ok: false, message: prep?.message || "Não foi possível iniciar o pagamento." });
    if (prep.reaproveitar) {
      return resp(req, { ok: true, estado: "aguardando", reaproveitado: true, metodo: "pix", pagamentoId: prep.pagamentoId, valor: prep.valor,
        pix: { copiaCola: prep.pixCopiaCola || "", qrBase64: prep.pixQrBase64 || "", expiraEm: prep.pixExpiraEm || "" } });
    }
    const pagamentoId = String(prep.pagamentoId);
    const falhar = async (mensagem: string, detalhe: string) => {   // não deu nem para criar: solta a reserva (o banco devolve estoque, cupom e brinde)
      await aplicarStatus({ pagamentoId, status: "erro", statusDetalhe: detalhe, erro: detalhe });
      return resp(req, { ok: true, estado: "erro", pagamentoId, metodo: prep.metodo, mensagem });
    };

    // 3) credenciais do modo em que o pagamento nasceu (teste ou produção)
    const cred: any = await credenciais(prep.modo);
    if (!cred?.accessToken) { log("mp_criar_sem_token", { modo: prep.modo }); return await falhar("O pagamento pelo site não está disponível agora. Escolha pagar na entrega.", "sem credencial"); }
    const email = String(prep.email || u.email || "").trim();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return await falhar("Sua conta está sem e-mail válido. Escolha pagar na entrega.", "sem e-mail");

    // 4) monta o pedido no Mercado Pago (campos mínimos da documentação; valor sempre em texto "00.00")
    const valor = dinheiro(Number(prep.valor));
    const pedidoMp: any = { type: "online", processing_mode: "automatic", total_amount: valor, external_reference: pagamentoId, payer: { email }, transactions: { payments: [] as any[] } };
    if (prep.metodo === "pix") {
      const minutos = Math.max(0, Math.ceil((new Date(prep.expiraEm).getTime() - Date.now()) / 60000));
      pedidoMp.transactions.payments.push({ amount: valor, payment_method: { id: "pix", type: "bank_transfer" }, expiration_time: duracaoPix(minutos) });   // o Mercado Pago só aceita a partir de 30 min
    } else {
      if (!cartao) return await falhar("Os dados do cartão não chegaram. Tente de novo.", "sem dados do cartão");
      pedidoMp.payer.identification = { type: "CPF", number: cartao.cpf };
      pedidoMp.transactions.payments.push({ amount: valor, payment_method: { id: cartao.bandeira, type: "credit_card", token: cartao.token, installments: 1 } });   // só à vista (1x)
    }

    // 5) cria no Mercado Pago
    let r: { status: number; json: any };
    try { r = await mpPostComRetentativa("/v1/orders", String(cred.accessToken), pedidoMp, pagamentoId); }
    catch (e) {
      if (e instanceof MpRede) { log("mp_criar_rede", { pagamentoId }); return await falhar("Não conseguimos falar com o Mercado Pago agora. Escolha pagar na entrega.", "rede ou timeout"); }
      throw e;
    }
    if (r.status < 200 || r.status >= 300) {
      log("mp_criar_http", { pagamentoId, http: r.status, codigo: codigoErroMp(r.json), metodo: prep.metodo });
      if ((r.status === 400 || r.status === 422) && prep.metodo === "credito") {   // dado do cartão não aceito: cliente pode tentar de novo
        await aplicarStatus({ pagamentoId, status: "recusado", statusDetalhe: "dados rejeitados (" + r.status + ")" });
        return resp(req, { ok: true, estado: "recusado", pagamentoId, metodo: prep.metodo, mensagem: "Os dados do cartão não foram aceitos. Confira e tente de novo, ou pague na entrega." });
      }
      return await falhar("O pagamento pelo site não está disponível agora. Escolha pagar na entrega.", "http " + r.status + " " + codigoErroMp(r.json));
    }

    // 6) entrega o resultado ao banco (única porta) e responde à página
    const tr = traduzirOrder(r.json);
    const ap: any = await aplicarStatus({
      pagamentoId, mpOrderId: tr.orderId, mpPaymentId: tr.paymentId, status: tr.status, statusDetalhe: tr.detalheMp,
      pixCopiaCola: tr.pix?.copiaCola || "", pixQrBase64: tr.pix?.qrBase64 || "", pixExpiraEm: tr.pix?.expiraEm || "",
      cartaoFinal: tr.cartaoFinal, cartaoBandeira: tr.cartaoBandeira, valorReembolsado: tr.valorReembolsado,
    });
    log("mp_criar_ok", { pagamentoId, metodo: prep.metodo, statusMp: tr.statusMp, detalheMp: tr.detalheMp, status: tr.status });
    if (prep.metodo === "pix") await cancelarSubstituidos(reservaId, pagamentoId, String(cred.accessToken));
    const base = { ok: true, pagamentoId, metodo: prep.metodo, valor: Number(prep.valor), reservaExpiraEm: prep.expiraEm };

    if (tr.status === "aprovado") {
      const res = ap?.resultado || {};
      if (res.vendaId) return resp(req, { ...base, estado: "aprovado", vendaId: res.vendaId, numero: res.numero });
      return resp(req, { ...base, estado: "conferindo", mensagem: "Seu pagamento foi aprovado e estamos conferindo o pedido com o restaurante." });   // caiu em "Pagamento a decidir"
    }
    if (tr.status === "recusado") return resp(req, { ...base, estado: "recusado", mensagem: mensagemRecusa(tr.detalheMp) });
    if (tr.status === "aguardando") return resp(req, { ...base, estado: "aguardando", pix: tr.pix ? { copiaCola: tr.pix.copiaCola, qrBase64: tr.pix.qrBase64, expiraEm: tr.pix.expiraEm } : null, desafio: tr.desafio });
    return resp(req, { ...base, estado: "erro", mensagem: "O pagamento não pôde ser concluído. Tente de novo ou pague na entrega." });   // expirado/cancelado na criação
  } catch (e) {
    log("mp_criar_falha", { erro: String((e as Error)?.message || e).slice(0, 200) });
    return resp(req, { ok: false, message: "Não foi possível processar o pagamento agora. Tente de novo em instantes." }, 500);
  }
});
```

**mp-webhook/index.ts**

```ts
// =====================================================================
// mp-webhook · recebe os AVISOS do Mercado Pago (evento "Order (Mercado Pago)"). Chamada só pelo Mercado Pago.
// verify_jwt = false: a prova de que o aviso é do Mercado Pago é a assinatura (header x-signature, HMAC-SHA256 com a chave secreta do webhook).
// Regras:
//  • aviso com assinatura inválida: só é registrado e nada mais acontece (resposta 401);
//  • o aviso nunca é confiado: o status vem de uma CONSULTA ao pedido no Mercado Pago (GET /v1/orders/{id}) com o Access Token do modo certo;
//  • aviso repetido é ignorado no banco (chave do evento); responder 200 em poucos segundos (o Mercado Pago espera até 22 s e reenvia a cada 15 min);
//  • erro nosso (banco ou Mercado Pago fora do ar) responde 500 para o Mercado Pago tentar de novo; pedido que não é nosso responde 200 (não adianta reenviar);
//  • o clique em "Simular" do painel do Mercado Pago (número de pedido falso) responde 200.
// =====================================================================
import { svc, credenciais, aplicarStatus, mpChamar, MpRede, limite, log } from "./mp.ts";
import { ehUuid, traduzirOrder, validarAssinatura } from "./mp-puro.ts";

const json = (o: unknown, status = 200) => new Response(JSON.stringify(o), { status, headers: { "Content-Type": "application/json" } });
const ID_ORDER = /^[A-Za-z0-9_-]{8,64}$/;

// consulta o pedido no Mercado Pago; sem saber o modo, tenta o provável e depois o outro (aviso de teste x produção)
async function consultarPedido(orderId: string, modos: string[]): Promise<{ pedido: any; modo: string } | null> {
  for (const modo of modos) {
    const cred: any = await credenciais(modo);
    if (!cred?.accessToken) continue;
    const r = await mpChamar("GET", `/v1/orders/${encodeURIComponent(orderId)}`, String(cred.accessToken), undefined, undefined, 15000);
    if (r.status >= 200 && r.status < 300 && r.json) return { pedido: r.json, modo };
    if (r.status >= 500 || r.status === 429) throw new MpRede();   // problema do lado deles: pedir reenvio
  }
  return null;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ ok: false, erro: "metodo" }, 405);
  try {
    const url = new URL(req.url);
    const bruto = await req.text();
    let corpo: any = {}; try { corpo = bruto ? JSON.parse(bruto) : {}; } catch { corpo = {}; }
    const dataIdQuery = String(url.searchParams.get("data.id") || ""), dataIdCorpo = String(corpo?.data?.id || "");
    const tipo = String(url.searchParams.get("type") || corpo?.type || "");
    const requestId = req.headers.get("x-request-id");
    const orderId = dataIdQuery || dataIdCorpo;

    // 1) assinatura: sem chave cadastrada ou assinatura errada = não é confiável
    const cred0: any = await credenciais(null);
    const segredo = String(cred0?.webhookSecret || "");
    if (!segredo) { log("mp_webhook_sem_chave"); return json({ ok: false, erro: "chave_do_aviso_nao_cadastrada" }, 401); }
    const assinaturaOk = await validarAssinatura({ segredo, assinatura: req.headers.get("x-signature"), requestId, ids: [dataIdQuery, dataIdCorpo] });
    if (!assinaturaOk) {
      if (limite("assinatura_invalida", 30, 60000)) await aplicarStatus({ chaveEvento: "x", assinaturaOk: false, tipoEvento: tipo, statusMp: "", detalhe: { action: String(corpo?.action || ""), motivo: "assinatura inválida" } });
      log("mp_webhook_assinatura_invalida", { tipo });
      return json({ ok: false, erro: "assinatura" }, 401);
    }

    // 2) só o tópico "order" interessa; o resto recebe 200 para o Mercado Pago não reenviar
    if (tipo && tipo !== "order") return json({ ok: true, ignorado: "tipo" });
    if (!ID_ORDER.test(orderId)) return json({ ok: true, ignorado: "sem_id" });

    // 3) descobre o modo (teste/produção) e consulta o pedido de verdade
    const { data: g } = await svc.from("pagamentos_online").select("id,mp_modo").eq("mp_order_id", orderId).maybeSingle();
    const provavel = g?.mp_modo || (corpo?.live_mode === true ? "producao" : "homologacao");
    const modos = g ? [provavel] : [provavel, provavel === "producao" ? "homologacao" : "producao"];
    const achado = await consultarPedido(orderId, modos);
    if (!achado) { log("mp_webhook_pedido_nao_encontrado"); return json({ ok: true, ignorado: "pedido_inexistente" }); }   // inclui o "Simular" do painel
    const tr = traduzirOrder(achado.pedido);

    // 4) o pagamento é nosso? (external_reference = id do pagamento no banco; ou pelo número do pedido já gravado)
    const pagamentoId = ehUuid(tr.externalReference) ? tr.externalReference : (g?.id || null);
    if (!pagamentoId && !g) { log("mp_webhook_pagamento_desconhecido"); return json({ ok: true, ignorado: "pagamento_desconhecido" }); }

    // 5) entrega ao banco: a chave do evento impede processar o mesmo aviso duas vezes
    const chaveEvento = `order:${orderId}:${String(corpo?.action || "")}:${String(corpo?.date_created || requestId || "")}`.slice(0, 200);
    const res: any = await aplicarStatus({
      pagamentoId, mpOrderId: tr.orderId || orderId, mpPaymentId: tr.paymentId, status: tr.status, statusDetalhe: tr.detalheMp,
      pixCopiaCola: tr.pix?.copiaCola || "", pixQrBase64: tr.pix?.qrBase64 || "", pixExpiraEm: tr.pix?.expiraEm || "",
      cartaoFinal: tr.cartaoFinal, cartaoBandeira: tr.cartaoBandeira, valorReembolsado: tr.valorReembolsado,
      chaveEvento, assinaturaOk: true, tipoEvento: tipo || "order", statusMp: tr.statusMp, detalhe: { action: String(corpo?.action || ""), status: tr.statusMp, status_detail: tr.detalheMp, modo: achado.modo },
    });
    log("mp_webhook_ok", { status: tr.status, duplicado: res?.duplicado === true, ignorado: res?.ignorado || null });
    return json({ ok: true, duplicado: res?.duplicado === true });
  } catch (e) {
    log("mp_webhook_falha", { erro: String((e as Error)?.message || e).slice(0, 200) });
    return json({ ok: false, erro: "tente_de_novo" }, 500);   // o Mercado Pago reenvia
  }
});
```

**mp-status/index.ts**

```ts
// =====================================================================
// mp-status · consulta ATIVA do pagamento, para a tela do cliente quando o aviso (webhook) atrasa. Chamada pelo cardápio (cliente LOGADO).
// verify_jwt = false: confere o login do cliente e que a reserva é dele.
// Entrada: { reservaId }     Saída: o mesmo que api_mp_status_pagamento (estado, valorTotal, expiraEm, pixCopiaCola, numero, ...)
// Regras:
//  • só pergunta ao Mercado Pago se o pagamento ainda está "aguardando" e não foi atualizado nos últimos 5 s (a tela pode chamar de 3 em 3 s sem sobrecarregar);
//  • o resultado entra pela MESMA porta do aviso (mp_aplicar_status), então aviso e consulta nunca se atropelam;
//  • Pix que já foi cancelado/vencido no nosso banco mas continua aberto no Mercado Pago é cancelado lá também (melhor esforço), para ninguém pagar um QR morto.
// =====================================================================
import { resp, cors, usuario, svc, credenciais, aplicarStatus, mpChamar, MpRede, comoCliente, limite, log } from "./mp.ts";
import { ehUuid, traduzirOrder } from "./mp-puro.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors(req) });
  if (req.method !== "POST") return resp(req, { ok: false, message: "Método não permitido." }, 405);
  try {
    const u = await usuario(req);
    if (!u) return resp(req, { ok: false, message: "Entre na sua conta." }, 401);
    if (!limite("status:" + u.id, 40, 60000)) return resp(req, { ok: false, message: "Muitas consultas seguidas. Aguarde alguns segundos." }, 429);
    const corpo = await req.json().catch(() => ({}));
    const reservaId = String(corpo?.reservaId || "");
    if (!ehUuid(reservaId)) return resp(req, { ok: false, message: "Pedido inválido." }, 400);

    const { data: rv } = await svc.from("pedidos_reserva").select("id,user_id,estado").eq("id", reservaId).maybeSingle();
    if (!rv || rv.user_id !== u.id) return resp(req, { ok: false, message: "Pedido não encontrado." });
    const { data: g } = await svc.from("pagamentos_online").select("id,status,metodo,mp_modo,mp_order_id,atualizado_em").eq("reserva_id", reservaId).order("criado_em", { ascending: false }).limit(1).maybeSingle();

    if (g?.mp_order_id) {
      const parado = Date.now() - new Date(g.atualizado_em).getTime() > 5000;
      const consultar = (g.status === "aguardando" && parado)
        || (g.metodo === "pix" && (g.status === "cancelado" || g.status === "expirado") && Date.now() - new Date(g.atualizado_em).getTime() < 2 * 3600 * 1000 && limite("cancelar:" + g.id, 1, 600000));
      if (consultar) {
        try {
          const cred: any = await credenciais(g.mp_modo);
          if (cred?.accessToken) {
            const r = await mpChamar("GET", `/v1/orders/${encodeURIComponent(g.mp_order_id)}`, String(cred.accessToken), undefined, undefined, 12000);
            if (r.status >= 200 && r.status < 300 && r.json) {
              const tr = traduzirOrder(r.json);
              if (g.status === "aguardando") {
                if (tr.status !== "aguardando") {   // mudou lá e o aviso ainda não chegou: aplica agora (o banco ignora o que já estiver aplicado)
                  await aplicarStatus({ pagamentoId: g.id, mpOrderId: tr.orderId, mpPaymentId: tr.paymentId, status: tr.status, statusDetalhe: tr.detalheMp,
                    cartaoFinal: tr.cartaoFinal, cartaoBandeira: tr.cartaoBandeira, valorReembolsado: tr.valorReembolsado });
                }
              } else if (tr.status === "aguardando") {   // nosso lado já desistiu, o Mercado Pago ainda espera o Pix: cancela lá
                await mpChamar("POST", `/v1/orders/${encodeURIComponent(g.mp_order_id)}/cancel`, String(cred.accessToken), undefined, "cancel-" + g.id, 8000);
                log("mp_status_pix_cancelado_no_mp", { pagamentoId: g.id });
              }
            }
          }
        } catch (e) { if (!(e instanceof MpRede)) log("mp_status_consulta_falhou", { erro: String((e as Error)?.message || e).slice(0, 160) }); /* a tela volta a perguntar */ }
      }
    }

    // a resposta final vem do banco, COMO o cliente (a função confere o dono de novo)
    const cli = await comoCliente(u.token);
    const { data, error } = await cli.rpc("api_mp_status_pagamento", { p: { reservaId } });
    if (error) return resp(req, { ok: false, message: "Não foi possível consultar o pagamento agora." }, 502);
    return resp(req, data);
  } catch (e) {
    log("mp_status_falha", { erro: String((e as Error)?.message || e).slice(0, 200) });
    return resp(req, { ok: false, message: "Não foi possível consultar o pagamento agora." }, 500);
  }
});
```

**mp-reembolsar/index.ts**

```ts
// =====================================================================
// mp-reembolsar · devolve o dinheiro (total ou parcial) de um pagamento online, pelo Mercado Pago. Chamada só pela EQUIPE (Admin, Operador).
// verify_jwt = false: confere o login e o nível (Admin, Operador; o Desenvolvedor vale como Admin) e se existe uma DECISÃO registrada.
// Entrada: { pagamentoId, valor? }   sem "valor" = devolver tudo o que falta. Saída: { ok, estado, valorReembolsado, restante, message }
// Regras:
//  • NUNCA reembolsa sozinho: só devolve se alguém já decidiu (api_mp_decidir_pagamento = "reembolsar") OU se a venda foi cancelada e há
//    um reembolso "Pendente" na tabela reembolsos (cancelamento de pedido pago). Qualquer outro pedido de reembolso é recusado;
//  • idempotência: a chave do Mercado Pago é fixa por pagamento + valor já devolvido + valor pedido, então duplo clique não devolve duas vezes;
//  • reembolso total sem corpo (como a documentação manda); parcial com o id da transação e o valor;
//  • depois de devolvido, o resultado entra pela mesma porta do aviso (mp_aplicar_status): o banco marca "Devolvido" sozinho quando for o total.
// =====================================================================
import { resp, cors, equipe, svc, credenciais, aplicarStatus, mpChamar, MpRede, limite, log } from "./mp.ts";
import { centavos, codigoErroMp, dinheiro, ehUuid, num, traduzirOrder } from "./mp-puro.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors(req) });
  if (req.method !== "POST") return resp(req, { ok: false, message: "Método não permitido." }, 405);
  try {
    const eq = await equipe(req, ["Admin", "Operador", "Desenvolvedor"]);
    if (!eq) return resp(req, { ok: false, message: "Sem permissão para reembolsar." }, 403);
    if (!limite("reemb:" + eq.id, 10, 60000)) return resp(req, { ok: false, message: "Muitos pedidos seguidos. Aguarde um minuto." }, 429);
    const corpo = await req.json().catch(() => ({}));
    const pagamentoId = String(corpo?.pagamentoId || "");
    if (!ehUuid(pagamentoId)) return resp(req, { ok: false, message: "Pagamento inválido." }, 400);

    const { data: g } = await svc.from("pagamentos_online").select("id,venda_id,status,mp_modo,mp_order_id,mp_payment_id,valor,valor_reembolsado,decisao").eq("id", pagamentoId).maybeSingle();
    if (!g) return resp(req, { ok: false, message: "Pagamento não encontrado." });
    if (g.status !== "aprovado" && g.status !== "reembolso_parcial") return resp(req, { ok: false, message: g.status === "reembolsado" ? "Este pagamento já foi devolvido por inteiro." : "Só dá para devolver um pagamento aprovado." });
    if (!g.mp_order_id) return resp(req, { ok: false, message: "Este pagamento não tem número no Mercado Pago." });

    // só devolve com decisão registrada
    let autorizado = g.decisao === "reembolsar";
    if (!autorizado && g.venda_id) {
      const { data: pend } = await svc.from("reembolsos").select("id").eq("venda_id", g.venda_id).eq("status", "Pendente").limit(1);
      autorizado = !!(pend && pend.length);
    }
    if (!autorizado) return resp(req, { ok: false, message: "Antes de devolver, registre a decisão de reembolsar (ou cancele o pedido pago)." });

    // quanto devolver
    const total = Number(g.valor), jaDevolvido = Number(g.valor_reembolsado || 0), restante = Math.round((total - jaDevolvido) * 100) / 100;
    if (restante <= 0) return resp(req, { ok: false, message: "Não há nada a devolver neste pagamento." });
    const pedido = corpo?.valor === undefined || corpo?.valor === null || corpo?.valor === "" ? restante : Math.round(num(corpo.valor) * 100) / 100;
    if (!(pedido > 0)) return resp(req, { ok: false, message: "Informe um valor maior que zero." });
    if (centavos(pedido) > centavos(restante)) return resp(req, { ok: false, message: `O valor passa do que falta devolver (R$ ${dinheiro(restante).replace(".", ",")}).` });
    const total_ = jaDevolvido === 0 && centavos(pedido) === centavos(total);   // devolução total "limpa": sem corpo

    const cred: any = await credenciais(g.mp_modo);
    if (!cred?.accessToken) return resp(req, { ok: false, message: "As chaves do Mercado Pago deste modo não estão cadastradas." });
    const token = String(cred.accessToken);

    let corpoMp: unknown = undefined;
    if (!total_) {
      let idTransacao = String(g.mp_payment_id || "");
      if (!idTransacao) {   // o id da transação pode não ter sido guardado: pega no pedido
        const c = await mpChamar("GET", `/v1/orders/${encodeURIComponent(g.mp_order_id)}`, token, undefined, undefined, 15000);
        idTransacao = c.status >= 200 && c.status < 300 ? traduzirOrder(c.json).paymentId : "";
      }
      if (!idTransacao) return resp(req, { ok: false, message: "Não foi possível identificar a transação no Mercado Pago. Tente de novo." });
      corpoMp = { transactions: [{ id: idTransacao, amount: dinheiro(pedido) }] };
    }

    // chave fixa: mesmo pagamento + mesmo valor já devolvido + mesmo valor pedido = mesma devolução (repetir não devolve de novo)
    const chave = `ref-${g.id}-${centavos(jaDevolvido)}-${centavos(pedido)}`.slice(0, 64);
    let r: { status: number; json: any };
    try { r = await mpChamar("POST", `/v1/orders/${encodeURIComponent(g.mp_order_id)}/refund`, token, corpoMp, chave); }
    catch (e) {
      if (e instanceof MpRede) { log("mp_reembolso_rede", { pagamentoId }); return resp(req, { ok: false, message: "Não houve resposta do Mercado Pago. Confira no painel do Mercado Pago se a devolução saiu antes de repetir; repetir o mesmo pedido é seguro." }); }
      throw e;
    }
    if (r.status < 200 || r.status >= 300) {
      log("mp_reembolso_http", { pagamentoId, http: r.status, codigo: codigoErroMp(r.json) });
      const msg = r.status === 400 || r.status === 409 || r.status === 422
        ? "O Mercado Pago não aceitou a devolução agora (talvez já exista uma em andamento). Aguarde um minuto e confira o estado do pagamento."
        : "O Mercado Pago não conseguiu devolver agora. Tente de novo em instantes.";
      return resp(req, { ok: false, message: msg });
    }

    // deu certo: registra pela mesma porta do aviso (o banco passa o reembolso pendente para "Devolvido" quando for o total)
    const novoTotal = Math.round((jaDevolvido + pedido) * 100) / 100;
    const completo = centavos(novoTotal) >= centavos(total);
    const ap: any = await aplicarStatus({ pagamentoId: g.id, mpOrderId: g.mp_order_id, status: completo ? "reembolsado" : "reembolso_parcial", valorReembolsado: novoTotal, statusDetalhe: completo ? "refunded" : "partially_refunded" });
    log("mp_reembolso_ok", { pagamentoId, completo, valor: dinheiro(pedido) });
    return resp(req, { ok: true, estado: ap?.status || (completo ? "reembolsado" : "reembolso_parcial"), valorReembolsado: novoTotal, restante: Math.max(0, Math.round((total - novoTotal) * 100) / 100),
      message: completo ? "Devolvido por inteiro pelo Mercado Pago." : `Devolvidos R$ ${dinheiro(pedido).replace(".", ",")}. Ainda faltam R$ ${dinheiro(total - novoTotal).replace(".", ",")}.` });
  } catch (e) {
    log("mp_reembolso_falha", { erro: String((e as Error)?.message || e).slice(0, 200) });
    return resp(req, { ok: false, message: "Não foi possível devolver agora. Tente de novo em instantes." }, 500);
  }
});
```

## Etapa 4 — Painel Admin: card Mercado Pago

**Objetivo:** cadastro e liga/desliga em Contas e acessos, ao lado de iFood e Nota fiscal.

**Status: feita (aguardando sua aprovação).** Nada foi aplicado nem publicado. Arquivos: `2026-10-13-mp-etapa4-painel.sql` (o código está logo abaixo), `teste-mp-etapa4.sql` (não grava nada; termina com o erro "RELATORIO", que é o resultado) e a pasta `SUBIR-NO-GITHUB/` selada (mudaram `app-11-admin-integracoes.js`, `app-01-base-e-api.js`, `index.html` e `sw.js`). `planilha_FINAL.gs` segue junto, **sem mudança** nesta etapa. Ordem: Etapas 1 e 2 no banco, depois este SQL, depois o teste, depois subir a pasta no GitHub. Com o Mercado Pago desligado, nada muda para o cliente.

**O que o card tem**

- Guia em português simples com os 6 passos (conta de vendedor e verificação, aplicação Checkout Transparente, credenciais de teste, webhook e evento "Order (Mercado Pago)", teste guiado, credenciais de produção e ligar).
- As 5 chaves (Public Key e Access Token de teste e de produção, chave secreta do webhook), mascaradas, com **Ver** e **Trocar** pedindo a senha de Admin, como no iFood.
- Checklist (5 passos, 3 marcados sozinhos pelo sistema), endereço do webhook com botão Copiar, e **Ver registro**.
- **Formas de pagamento pelo site**: para cada forma ativa, "Só na entrega", "Também online: Pix" ou "Também online: cartão de crédito". Uma de cada tipo; dinheiro (com troco) é recusado.
- Ajustes: validade do Pix (5 a 120 min; combinado 15), e-mails de teste, e-mail do comprador de teste e a opção "mostrar a todos em Teste".
- Teste guiado: passo a passo, botão para abrir o cardápio, e a lista dos últimos pagamentos online com os dois selos (Pix aprovado em teste, cartão aprovado em teste).
- Botões **Ligar em TESTE**, **Ligar em PRODUÇÃO**, **Passar para PRODUÇÃO**, **Voltar para TESTE** e **Desligar**, todos com senha de Admin.
- Saúde do sistema: item "Mercado Pago" (pagamentos esperando decisão, reservas vencidas não liberadas, erros na última hora).

**Escolhas desta etapa (me corrija se discordar)**

- **Regra do Ligar:** em **Teste** só exige conta de vendedor, chaves de teste e webhook; em **Produção** exige os 5 passos (inclusive o teste guiado feito e as chaves de produção). Motivo: o teste guiado só pode acontecer com o Mercado Pago ligado em Teste, então não dá para exigi-lo para ligar em Teste. Também só liga se houver ao menos uma forma online escolhida.
- **Quem vê o pagamento em Teste:** só as contas Google da lista "e-mails de teste" (ou todos, se você marcar a opção). Assim ninguém tenta pagar de verdade com chave de teste. Para isso `api_mp_config_publica` e `mp_preparar_pagamento` ganharam uma peça interna (`_mp_publico`); sem lista e com a opção desmarcada, o comportamento é o da Etapa 1.
- **E-mail do comprador de teste:** campo novo, usado só em Teste (resolve o ponto 4 da Etapa 3, se o Mercado Pago exigir e-mail de usuário de teste). Em Produção vale sempre o e-mail da conta do cliente.
- **Chave secreta do webhook:** continua **uma só**. A documentação do Mercado Pago diz que a chave secreta é exclusiva da aplicação (as URLs de teste e produção são separadas, a chave não). Resolve o ponto 2 da Etapa 3, salvo surpresa na Etapa 8.
- **Pedido de teste é pedido de verdade:** quando um pagamento de teste é aprovado, a venda nasce, vai para a cozinha e baixa estoque. O guia e o card avisam; cancele depois.
- Formato das chaves: só letras, números, `-` e `_`; Access Token com pelo menos 30 caracteres e chave do webhook com pelo menos 16. Não obriga o prefixo `TEST-`/`APP_USR-` porque não confirmei como o Mercado Pago nomeia hoje as de teste.
- Partimos da **versão mais recente** de `api_integracoes_status`, `config`, `salvar_segredo`, `ligar`, `desligar`, `_integ_pendencias` e `_saude_integracoes`; as partes de iFood e Nota fiscal ficam idênticas.
- Não consegui rodar o SQL num Postgres aqui (revisado à mão; parênteses e blocos conferidos por programa). A tela foi conferida com um teste de renderização (botões por estado, webhook, formas). `selar.py` e `verificar.py` deram APROVADO. O `sw.js` foi só selado (continua `texas-shell-v34`; a v35 fica para a Etapa 7).

**Código usado (SQL)**

```sql
-- =====================================================================================
-- MERCADO PAGO · ETAPA 4 (painel Admin: card Mercado Pago) · 2026-10-13 · NÃO APLICADO
-- Rode DEPOIS das Etapas 1 e 2. Pode rodar de novo (idempotente). Cole inteiro no SQL Editor do Supabase.
-- Para conferir depois, rode testes/teste-mp-etapa4.sql.
-- Só acrescenta o 'mercadopago' às funções de integração (partindo da versão MAIS RECENTE de cada uma:
-- as de iFood e Nota fiscal ficam idênticas). Nenhum "delete from" dentro de função. Integração segue DESLIGADA.
-- =====================================================================================
begin;

-- ---------- 1) Regra do "Ligar": em TESTE só exige conta, chaves de teste e webhook; em PRODUÇÃO exige os 5 passos ----------
-- (o "teste guiado" só é possível com a integração ligada em teste, por isso não pode ser exigido para ligar em teste)
create or replace function public._integ_pendencias(p_prov text, p_modo text) returns text[]
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_out text[] := '{}'; v_item jsonb; v_ck jsonb; v_ok boolean;
begin
  select checklist into v_ck from integracoes_config where provedor = p_prov;
  for v_item in select * from jsonb_array_elements(_integ_checklist_def(p_prov)) loop
    if p_prov = 'mercadopago' and p_modo = 'homologacao' and (v_item->>'id') in ('teste_guiado', 'chaves_producao') then continue; end if;
    if coalesce((v_item->>'auto')::boolean, false) then
      v_ok := case v_item->>'id'
        when 'chaves' then (select count(*) from integracoes_segredos where chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id')) = 3
        when 'token' then exists (select 1 from integracoes_segredos where chave = 'nfce_token_' || p_modo)
        when 'empresa' then public._fiscal_empresa_ok()
        when 'perfis' then public._fiscal_perfis_ok()
        when 'chaves_teste' then (select count(*) from integracoes_segredos where chave in ('mp_public_key_teste', 'mp_access_token_teste')) = 2
        when 'webhook' then exists (select 1 from integracoes_segredos where chave = 'mp_webhook_secret')
        when 'teste_guiado' then exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'pix' and status in ('aprovado', 'reembolso_parcial', 'reembolsado'))
                             and exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'credito' and status in ('aprovado', 'reembolso_parcial', 'reembolsado'))
        when 'chaves_producao' then (select count(*) from integracoes_segredos where chave in ('mp_public_key_producao', 'mp_access_token_producao')) = 2
        else coalesce((v_ck->>(v_item->>'id'))::boolean, false) end;
    else
      v_ok := coalesce((v_ck->>(v_item->>'id'))::boolean, false);
    end if;
    if not v_ok then v_out := v_out || (v_item->>'titulo'); end if;
  end loop;
  return v_out;
end $f$;

-- ---------- 2) Quem vê o pagamento online no cardápio ----------
-- Produção: todos. Teste: só quem está na lista "emailsTeste" (a conta Google de teste), ou todos se "testeNoCardapio" = true (padrão: não).
-- _mp_publico(user) é o miolo; api_mp_config_publica usa o usuário logado e mp_preparar_pagamento usa o dono da reserva.
create or replace function public._mp_publico(p_user uuid) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare c integracoes_config%rowtype; v_prod boolean; v_pk text; v_formas jsonb; v_min int; v_email text; v_visivel boolean;
begin
  select * into c from integracoes_config where provedor = 'mercadopago';
  if c.provedor is null or not c.ligado then return jsonb_build_object('ok', true, 'ligado', false); end if;
  v_prod := (c.modo = 'producao');
  if not v_prod then
    v_visivel := coalesce((c.config->>'testeNoCardapio')::boolean, false);
    if not v_visivel and p_user is not null and jsonb_typeof(c.config->'emailsTeste') = 'array' then
      select lower(email) into v_email from auth.users where id = p_user;
      v_visivel := v_email is not null and exists (select 1 from jsonb_array_elements_text(c.config->'emailsTeste') x where lower(btrim(x)) = v_email);
    end if;
    if not coalesce(v_visivel, false) then return jsonb_build_object('ok', true, 'ligado', false); end if;
  end if;
  select valor into v_pk from integracoes_segredos where chave = case when v_prod then 'mp_public_key_producao' else 'mp_public_key_teste' end;
  select coalesce(jsonb_agg(jsonb_build_object('id', f.id, 'tipo', f.tipo_online) order by f.ordem), '[]'::jsonb) into v_formas
    from formas_pagamento f where f.ativa and f.visivel_cardapio and f.aceita_online and f.tipo_online is not null;
  if v_pk is null or jsonb_array_length(v_formas) = 0 then return jsonb_build_object('ok', true, 'ligado', false); end if;
  v_min := case when coalesce(c.config->>'pixValidadeMin', '') ~ '^[0-9]{1,3}$' then least(120, greatest(5, (c.config->>'pixValidadeMin')::int)) else 15 end;
  return jsonb_build_object('ok', true, 'ligado', true, 'modo', case when v_prod then 'producao' else 'teste' end,
    'publicKey', v_pk, 'formas', v_formas, 'pixValidadeMin', v_min);
end $f$;

create or replace function public.api_mp_config_publica(p jsonb default '{}'::jsonb) returns jsonb
 language sql stable security definer set search_path to 'public' as $f$ select public._mp_publico(auth.uid()) $f$;
revoke all on function public._mp_publico(uuid) from public, anon, authenticated;
revoke all on function public.api_mp_config_publica(jsonb) from public, anon, authenticated;
grant execute on function public.api_mp_config_publica(jsonb) to anon, authenticated;

-- mp_preparar_pagamento (Etapa 2) com duas mudanças: usa _mp_publico(dono da reserva) e, em modo Teste, o e-mail do pagador pode ser o "emailPagadorTeste" do card
create or replace function public.mp_preparar_pagamento(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; f formas_pagamento%rowtype; g pagamentos_online%rowtype; v_modo text; v_novo uuid; v_email text; v_achou boolean; v_teste_email text;
begin
  select * into r from pedidos_reserva where id = _uuid(p->>'reservaId') for update;
  if not found or r.user_id is distinct from _uuid(p->>'userId') then return _falha('Pedido não encontrado.'); end if;
  if r.estado = 'confirmada' then return _falha('Este pedido já foi pago.'); end if;
  if r.estado <> 'ativa' or r.expira_em < now() then return _falha('O tempo deste pedido acabou. Faça o pedido de novo.'); end if;
  if coalesce((public._mp_publico(r.user_id)->>'ligado')::boolean, false) is not true then return _falha('O pagamento pelo site não está disponível agora.'); end if;
  select * into f from formas_pagamento where id = r.forma_pagamento_id;
  if f.id is null or not f.aceita_online or f.tipo_online is null then return _falha('Forma de pagamento inválida.'); end if;
  if exists (select 1 from pagamentos_online where reserva_id = r.id and status = 'aprovado') then return _falha('Este pedido já foi pago.'); end if;
  if (select count(*) from pagamentos_online where reserva_id = r.id) >= 5 then return _falha('Muitas tentativas de pagamento. Faça o pedido de novo.'); end if;

  select * into g from pagamentos_online
   where reserva_id = r.id and metodo = 'pix' and status = 'aguardando' and pix_copia_cola is not null and (pix_expira_em is null or pix_expira_em > now())
   order by criado_em desc limit 1;
  v_achou := found;
  if v_achou and f.tipo_online = 'pix' then
    return jsonb_build_object('ok', true, 'reaproveitar', true, 'pagamentoId', g.id, 'metodo', 'pix', 'valor', g.valor,
      'pixCopiaCola', g.pix_copia_cola, 'pixQrBase64', g.pix_qr_base64, 'pixExpiraEm', g.pix_expira_em);
  end if;
  if f.tipo_online = 'credito' and exists (select 1 from pagamentos_online where reserva_id = r.id and metodo = 'credito' and status = 'aguardando' and criado_em > now() - interval '2 minutes') then
    return _falha('Seu pagamento está em andamento. Aguarde alguns segundos.');
  end if;

  update pagamentos_online set status = 'cancelado', status_detalhe = 'substituído por nova tentativa', atualizado_em = now() where reserva_id = r.id and status = 'aguardando';
  select case when modo = 'producao' then 'producao' else 'homologacao' end, nullif(btrim(coalesce(config->>'emailPagadorTeste', '')), '')
    into v_modo, v_teste_email from integracoes_config where provedor = 'mercadopago';
  insert into pagamentos_online (reserva_id, user_id, metodo, mp_modo, valor) values (r.id, r.user_id, f.tipo_online, v_modo, r.valor_total) returning id into v_novo;
  select email into v_email from auth.users where id = r.user_id;   -- só é repassado ao Mercado Pago; não é guardado aqui
  if v_modo = 'homologacao' and v_teste_email is not null then v_email := v_teste_email; end if;   -- só em Teste: e-mail de comprador de teste do Mercado Pago
  return jsonb_build_object('ok', true, 'pagamentoId', v_novo, 'metodo', f.tipo_online, 'modo', v_modo, 'valor', r.valor_total, 'expiraEm', r.expira_em,
    'email', v_email, 'nome', r.cliente_nome,
    'itens', (select coalesce(jsonb_agg(jsonb_build_object('titulo', left(coalesce(e->>'descricao', 'Item'), 100), 'quantidade', _num(e->>'quantidade', 1), 'valorUnitario', _num(e->>'valorUnitario'))), '[]'::jsonb)
                from jsonb_array_elements(r.itens) e));
end $f$;
revoke all on function public.mp_preparar_pagamento(jsonb) from public, anon, authenticated;
grant execute on function public.mp_preparar_pagamento(jsonb) to service_role;

-- ---------- 3) Status das integrações (versão mais recente + Mercado Pago) ----------
create or replace function public.api_integracoes_status(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_modo text; v_def jsonb; v_it jsonb; v_pend text[]; v_pt text[]; v_pp text[];
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  for r in select * from integracoes_config order by provedor loop
    v_def := _integ_checklist_def(r.provedor); v_pend := _integ_pendencias(r.provedor, r.modo);
    v := v || (jsonb_build_object('provedor', r.provedor, 'ligado', r.ligado, 'modo', r.modo, 'ligadoEm', r.ligado_em, 'config', r.config,
      'checklist', (select coalesce(jsonb_agg(jsonb_build_object('id', x->>'id', 'titulo', x->>'titulo', 'auto', coalesce((x->>'auto')::boolean, false),
          'feito', not ((x->>'titulo') = any (v_pend))) ), '[]'::jsonb) from jsonb_array_elements(v_def) x),
      'pendencias', to_jsonb(v_pend), 'podeLigar', coalesce(array_length(v_pend, 1), 0) = 0,
      'segredos', (select coalesce(jsonb_object_agg(s.chave, jsonb_build_object('tem', true, 'final', case when length(s.valor) > 8 then right(s.valor, 4) else '' end, 'em', s.atualizado_em)), '{}'::jsonb)
                    from integracoes_segredos s where (r.provedor = 'ifood' and s.chave like 'ifood\_%') or (r.provedor = 'nfce' and s.chave like 'nfce\_%') or (r.provedor = 'mercadopago' and s.chave like 'mp\_%')))
      || case when r.provedor = 'mercadopago' then (
           select jsonb_build_object('pendenciasTeste', to_jsonb(a.t), 'pendenciasProducao', to_jsonb(a.p),
             'podeLigarTeste', coalesce(array_length(a.t, 1), 0) = 0, 'podeLigarProducao', coalesce(array_length(a.p, 1), 0) = 0,
             'formas', (select coalesce(jsonb_agg(jsonb_build_object('id', f.id, 'nome', f.nome, 'aceitaOnline', f.aceita_online, 'tipoOnline', f.tipo_online) order by f.ordem), '[]'::jsonb)
                          from formas_pagamento f where f.ativa and f.visivel_cardapio))
             from (select _integ_pendencias('mercadopago', 'homologacao') as t, _integ_pendencias('mercadopago', 'producao') as p) a)
         else '{}'::jsonb end);
  end loop;
  return jsonb_build_object('ok', true, 'integracoes', v);
end $f$;

-- ---------- 4) Ajustes (config): mercadopago ganha validade do Pix, e-mails de teste e "mostrar a todos em Teste" ----------
create or replace function public.api_integracoes_config(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text := p->>'provedor'; v_cfg jsonb := coalesce(p->'config', '{}'::jsonb); v_atual jsonb; v_chave text; v_novo jsonb := '{}'::jsonb;
        v_re text := '^[^@\s]+@[^@\s]+\.[^@\s]+$';
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_prov not in ('ifood', 'nfce', 'mercadopago') then return _falha('Integração inválida.'); end if;
  select config into v_atual from integracoes_config where provedor = v_prov;
  -- só chaves conhecidas, com valores simples
  for v_chave in select jsonb_object_keys(v_cfg) loop
    if v_prov = 'ifood' and v_chave in ('confirmacaoAutomatica', 'abrirFecharComCaixa', 'pausarSemEstoque', 'enviarPrecos') then v_novo := v_novo || jsonb_build_object(v_chave, coalesce((v_cfg->>v_chave)::boolean, false));
    elsif v_prov = 'ifood' and v_chave = 'baixaEstoque' and (v_cfg->>v_chave) in ('confirmacao', 'entrega') then v_novo := v_novo || jsonb_build_object(v_chave, v_cfg->>v_chave);
    elsif v_prov = 'ifood' and v_chave = 'retencaoClientesDias' and (v_cfg->>v_chave)::int between 7 and 365 then v_novo := v_novo || jsonb_build_object(v_chave, (v_cfg->>v_chave)::int);
    elsif v_prov = 'ifood' and v_chave = 'limitePrecoPct' and (v_cfg->>v_chave)::numeric between 0 and 100 then v_novo := v_novo || jsonb_build_object(v_chave, (v_cfg->>v_chave)::numeric);
    elsif v_prov = 'nfce' and v_chave = 'emitirQuando' and (v_cfg->>v_chave) in ('pagamento', 'entrega') then v_novo := v_novo || jsonb_build_object(v_chave, v_cfg->>v_chave);
    elsif v_prov = 'nfce' and v_chave = 'canais' and jsonb_typeof(v_cfg->v_chave) = 'array' then v_novo := v_novo || jsonb_build_object(v_chave, (select coalesce(jsonb_agg(c), '[]'::jsonb) from jsonb_array_elements_text(v_cfg->v_chave) c where c in ('balcao', 'cardapio', 'ifood', 'mesa')));
    elsif v_prov = 'mercadopago' and v_chave = 'pixValidadeMin' then
      if coalesce(v_cfg->>v_chave, '') !~ '^[0-9]{1,3}$' or (v_cfg->>v_chave)::int not between 5 and 120 then return _falha('A validade do Pix deve ficar entre 5 e 120 minutos.'); end if;
      v_novo := v_novo || jsonb_build_object(v_chave, (v_cfg->>v_chave)::int);
    elsif v_prov = 'mercadopago' and v_chave = 'testeNoCardapio' then v_novo := v_novo || jsonb_build_object(v_chave, coalesce((v_cfg->>v_chave)::boolean, false));
    elsif v_prov = 'mercadopago' and v_chave = 'emailPagadorTeste' then
      if btrim(coalesce(v_cfg->>v_chave, '')) <> '' and (lower(btrim(v_cfg->>v_chave)) !~ v_re or length(v_cfg->>v_chave) > 120) then return _falha('E-mail do comprador de teste inválido.'); end if;
      v_novo := v_novo || jsonb_build_object(v_chave, lower(btrim(coalesce(v_cfg->>v_chave, ''))));
    elsif v_prov = 'mercadopago' and v_chave = 'emailsTeste' and jsonb_typeof(v_cfg->v_chave) = 'array' then
      if exists (select 1 from jsonb_array_elements_text(v_cfg->v_chave) x where btrim(x) <> '' and lower(btrim(x)) !~ v_re) then return _falha('Um dos e-mails de teste é inválido.'); end if;
      v_novo := v_novo || jsonb_build_object(v_chave, (select coalesce(jsonb_agg(q.e), '[]'::jsonb) from (select distinct lower(btrim(x)) as e from jsonb_array_elements_text(v_cfg->v_chave) x where btrim(x) <> '' limit 5) q));
    end if;
  end loop;
  update integracoes_config set config = v_atual || v_novo, atualizado_em = now() where provedor = v_prov;
  perform _auditar('Integração: ajustes salvos', v_prov);
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Ajustes salvos.');
end $f$;

-- ---------- 5) Guardar chaves (versão mais recente, com nfce_csc) + as 5 chaves do Mercado Pago ----------
create or replace function public.api_integracoes_salvar_segredo(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_chave text := p->>'chave'; v_valor text := btrim(coalesce(p->>'valor', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_chave not in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id', 'nfce_token_homologacao', 'nfce_token_producao', 'nfce_csc',
                     'mp_public_key_teste', 'mp_public_key_producao', 'mp_access_token_teste', 'mp_access_token_producao', 'mp_webhook_secret') then return _falha('Campo desconhecido.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  if length(v_valor) < 8 or length(v_valor) > 400 or v_valor ~ '\s' then return _falha('Valor inválido. Copie inteiro, sem espaços.'); end if;
  if v_chave like 'mp\_%' then
    if v_valor !~ '^[A-Za-z0-9_-]+$' then return _falha('Valor inválido. Use só letras, números, - e _ (copie inteiro, sem espaços).'); end if;
    if v_chave = 'mp_webhook_secret' and length(v_valor) < 16 then return _falha('A chave secreta do aviso (webhook) é maior que isso. Copie inteira.'); end if;
    if v_chave like 'mp\_access\_token%' and length(v_valor) < 30 then return _falha('O Access Token é maior que isso. Copie inteiro.'); end if;
  end if;
  insert into integracoes_segredos (chave, valor, atualizado_em) values (v_chave, v_valor, now())
    on conflict (chave) do update set valor = excluded.valor, atualizado_em = now();
  perform _auditar('Integração: chave salva', v_chave);
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Salvo.');
end $f$;

-- ---------- 6) Ligar e desligar ----------
create or replace function public.api_integracoes_ligar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text := p->>'provedor'; v_modo text := coalesce(p->>'modo', 'producao'); v_pend text[]; v_uid text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_prov not in ('ifood', 'nfce', 'mercadopago') then return _falha('Integração inválida.'); end if;
  if v_prov in ('nfce', 'mercadopago') and (nullif(p->>'modo', '') is null or v_modo not in ('homologacao', 'producao')) then return _falha('Escolha o ambiente: teste (homologação) ou produção.'); end if;
  if v_prov = 'ifood' then v_modo := 'producao'; end if;
  v_uid := _exige_admin(p->>'senhaAdmin');
  if coalesce(p->>'senhaAdmin', '') = '' or v_uid is null then return _falha('Senha de administrador incorreta.'); end if;
  v_pend := _integ_pendencias(v_prov, v_modo);
  if coalesce(array_length(v_pend, 1), 0) > 0 then return _falha('Ainda faltam passos: ' || array_to_string(v_pend, '; ')); end if;
  if v_prov = 'mercadopago' and not exists (select 1 from formas_pagamento where ativa and visivel_cardapio and aceita_online and tipo_online is not null) then
    return _falha('Escolha pelo menos uma forma de pagamento online (Pix ou cartão de crédito) antes de ligar.');
  end if;
  update integracoes_config set ligado = true, modo = v_modo, ligado_em = now(), ligado_por = v_uid, atualizado_em = now() where provedor = v_prov;
  perform _auditar('Integração LIGADA', v_prov || ' · ' || v_modo);
  perform _integ_log(v_prov, 'info', 'Integração ligada (' || v_modo || ')');
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Ligado.');
end $f$;

create or replace function public.api_integracoes_desligar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if p->>'provedor' not in ('ifood', 'nfce', 'mercadopago') then return _falha('Integração inválida.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' or _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  update integracoes_config set ligado = false, atualizado_em = now() where provedor = p->>'provedor';
  perform _auditar('Integração DESLIGADA', p->>'provedor');
  perform _integ_log(p->>'provedor', 'aviso', 'Integração desligada');
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Desligado. O sistema voltou a funcionar como antes.');
end $f$;

-- ---------- 7) Formas de pagamento online (Pix / cartão de crédito) ----------
create or replace function public.api_mp_forma_online(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_id uuid := _uuid(p->>'formaId'); v_on boolean := coalesce((p->>'aceitaOnline')::boolean, false); v_tipo text := lower(btrim(coalesce(p->>'tipoOnline', '')));
        f formas_pagamento%rowtype; o formas_pagamento%rowtype;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into f from formas_pagamento where id = v_id;
  if not found then return _falha('Forma de pagamento não encontrada.'); end if;
  if v_on then
    if v_tipo not in ('pix', 'credito') then return _falha('Escolha Pix ou cartão de crédito.'); end if;
    if not f.ativa or not f.visivel_cardapio then return _falha('Esta forma está oculta no cardápio. Deixe-a ativa e visível antes.'); end if;
    if f.permite_troco then return _falha('Forma com troco (dinheiro) não pode ser paga pelo site.'); end if;
    select * into o from formas_pagamento where id <> f.id and aceita_online and tipo_online = v_tipo limit 1;
    if found then return _falha('A forma "' || o.nome || '" já está como ' || case when v_tipo = 'pix' then 'Pix' else 'cartão de crédito' end || ' online. Desmarque-a antes.'); end if;
    update formas_pagamento set aceita_online = true, tipo_online = v_tipo where id = f.id;
  else
    update formas_pagamento set aceita_online = false, tipo_online = null where id = f.id;
  end if;
  perform _auditar('Mercado Pago: forma online', f.nome || ' · ' || case when v_on then v_tipo else 'desligada' end);
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Salvo.');
end $f$;

-- Últimos pagamentos online + situação do teste guiado (a tela do card usa)
create or replace function public.api_mp_pagamentos_recentes(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'itens', (select coalesce(jsonb_agg(jsonb_build_object('em', to_char(x.criado_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI'), 'modo', x.mp_modo, 'metodo', x.metodo,
                'status', x.status, 'valor', x.valor, 'aDecidir', (x.decisao_pendente and x.decisao is null), 'detalhe', left(coalesce(nullif(x.erro, ''), x.status_detalhe, ''), 120)) order by x.criado_em desc), '[]'::jsonb)
              from (select * from pagamentos_online order by criado_em desc limit 15) x),
    'testePix', exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'pix' and status in ('aprovado', 'reembolso_parcial', 'reembolsado')),
    'testeCredito', exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'credito' and status in ('aprovado', 'reembolso_parcial', 'reembolsado')),
    'aDecidir', (select count(*) from pagamentos_online where decisao_pendente and decisao is null));
end $f$;

-- ---------- 8) Saúde do sistema: versão mais recente de _saude_integracoes + bloco do Mercado Pago ----------
create or replace function public._saude_integracoes() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_desc int; e ifood_estado%rowtype; v_min numeric; v_sem int; v_novos int; v_acoes int; v_nivel text; v_txt text; v_urg int;
        v_dec int; v_dec_velho int; v_venc int; v_err int;
begin
  if exists (select 1 from ai_segredos where provedor = 'nvidia') or exists (select 1 from ai_segredos where provedor = 'cloudflare') then
    select count(*) into v_desc from unnest(array['nvidia', 'cloudflare']) x(p) where _ia_provedor_descansando(x.p);
    v := v || jsonb_build_object('id', 'ia_extras', 'titulo', 'IAs de reserva (NVIDIA / Cloudflare)', 'nivel', case when v_desc > 0 then 'atencao' else 'ok' end,
      'texto', (select string_agg(x.rot || ': ' || case when not exists (select 1 from ai_segredos where provedor = x.p) then 'sem chave' when _ia_provedor_descansando(x.p) then 'descansando (erros recentes)' else 'pronta' end, ' · ')
                from (values ('nvidia', 'NVIDIA'), ('cloudflare', 'Cloudflare')) x(p, rot)));
  end if;
  if _integracao_ligada('ifood') then
    select * into e from ifood_estado where id;
    v_min := case when e.ultima_consulta_ok is null then null else extract(epoch from (now() - e.ultima_consulta_ok)) / 60 end;
    select coalesce(sum(itens_sem_ligacao), 0) into v_sem from ifood_pedidos where estado <> 'cancelado' and criado_em > now() - interval '7 days';
    select count(*) into v_novos from ifood_pedidos where estado = 'novo' and not simulado and criado_em < now() - interval '4 minutes';
    select count(*) into v_acoes from ifood_acoes where estado in ('erro', 'duvida') and criado_em > now() - interval '1 day';
    select count(*) into v_urg from ifood_negociacoes where estado = 'aberta' and expira_em > now() and expira_em < now() + interval '3 minutes';
    v_nivel := case when v_min is null or v_min > 2 or e.token_ok is false or v_novos > 0 or v_urg > 0 then 'problema' when v_acoes > 0 or v_sem > 0 or e.ultimo_erro is not null or exists (select 1 from ifood_negociacoes where estado = 'aberta' and expira_em > now()) then 'atencao' else 'ok' end;
    v_txt := case when v_min is null then 'Ligado, mas ainda sem nenhuma consulta bem-sucedida ao iFood.' else 'Última consulta ao iFood há ' || round(v_min, 1) || ' min' end
      || case when e.ultimo_pedido_em is not null then ' · último pedido às ' || to_char(e.ultimo_pedido_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') else ' · nenhum pedido ainda' end
      || case when e.token_ok is false then ' · ACESSO RECUSADO (confira as chaves)' else '' end
      || case when v_novos > 0 then ' · ' || v_novos || ' pedido(s) esperando confirmação há mais de 4 min' else '' end
      || case when v_acoes > 0 then ' · ' || v_acoes || ' ação(ões) não confirmada(s) no iFood' else '' end
      || case when v_sem > 0 then ' · ' || v_sem || ' item(ns) sem ligação' else '' end || public._saude_ifood_extra();
    v := v || jsonb_build_object('id', 'ifood', 'titulo', 'iFood', 'nivel', v_nivel, 'texto', v_txt);
  end if;
  v := v || public._saude_nfce();
  if _integracao_ligada('mercadopago') then
    select count(*) into v_dec from pagamentos_online where decisao_pendente and decisao is null;
    select count(*) into v_dec_velho from pagamentos_online where decisao_pendente and decisao is null and atualizado_em < now() - interval '10 minutes';
    select count(*) into v_venc from pedidos_reserva pr where pr.estado = 'ativa' and pr.expira_em < now() - interval '3 minutes'
      and not exists (select 1 from pagamentos_online g where g.reserva_id = pr.id and (g.status = 'aprovado' or (g.decisao_pendente and g.decisao is null)));
    select count(*) into v_err from pagamentos_online where status = 'erro' and criado_em > now() - interval '1 hour';
    v_nivel := case when v_venc > 0 or v_dec_velho > 0 then 'problema' when v_dec > 0 or v_err > 0 then 'atencao' else 'ok' end;
    v_txt := 'Ligado (' || case when (select modo from integracoes_config where provedor = 'mercadopago') = 'producao' then 'produção' else 'teste' end || ')'
      || case when v_dec > 0 then ' · ' || v_dec || ' pagamento(s) esperando decisão (seguir ou reembolsar)' else '' end
      || case when v_venc > 0 then ' · ' || v_venc || ' reserva(s) vencida(s) não liberada(s) (confira o agendamento mp-expirar-reservas)' else '' end
      || case when v_err > 0 then ' · ' || v_err || ' erro(s) ao criar pagamento na última hora' else '' end;
    v := v || jsonb_build_object('id', 'mercadopago', 'titulo', 'Mercado Pago', 'nivel', v_nivel, 'texto', v_txt);
  end if;
  return v;
end $f$;

-- ---------- 9) Permissões ----------
revoke all on function public._saude_integracoes() from public, anon, authenticated;
revoke all on function public._integ_pendencias(text, text) from public, anon, authenticated;
revoke all on function public.api_integracoes_status(jsonb), public.api_integracoes_config(jsonb), public.api_integracoes_salvar_segredo(jsonb),
  public.api_integracoes_ligar(jsonb), public.api_integracoes_desligar(jsonb), public.api_mp_forma_online(jsonb), public.api_mp_pagamentos_recentes(jsonb) from public, anon;
grant execute on function public.api_integracoes_status(jsonb), public.api_integracoes_config(jsonb), public.api_integracoes_salvar_segredo(jsonb),
  public.api_integracoes_ligar(jsonb), public.api_integracoes_desligar(jsonb), public.api_mp_forma_online(jsonb), public.api_mp_pagamentos_recentes(jsonb) to authenticated;

commit;
```

**Trechos do painel:** estão nos arquivos da pasta `SUBIR-NO-GITHUB/` (procure `mercadopago`, `integBotoes_`, `mpExtraHtml_`, `carregarMpRecentes_` e `mpFormaOnline_` em `app-11-admin-integracoes.js`; duas ações novas em `app-01-base-e-api.js`; só o título do cartão mudou no `index.html`).

## Etapa 5 — Cardápio: telas de pagamento

**Objetivo:** o cliente paga sem sair do site. Tudo protegido pela chave "ligado": desligada, o código novo nem executa.

- Lista de formas dinâmica: lê as formas cadastradas, na ordem e com os preços de cada uma. Grupos "Pagar agora, pelo site" (só com o Mercado Pago ligado) e "Pagar na entrega".
- Pagar online exige estar logado em Minha conta; quem não estiver vê "Entrar ou criar conta".
- Pix: QR Code, copia-e-cola, cronômetro de 15 minutos e mudança automática para "Pagamento aprovado".
- Cartão: tela segura do Mercado Pago (Card Payment Brick), CPF pedido só aqui, aprovação na hora ou mensagem para tentar outro cartão.
- Dinheiro: "Troco para quanto?" obrigatório, ou "Não preciso de troco". Alelo: itens e total com o preço do Alelo e aviso.
- Aviso e saída para pagar na entrega se o Mercado Pago estiver fora do ar.

**Entrega:** trechos do cardápio.

## Etapa 6 — Operação: pedidos, caixa e relatórios

**Objetivo:** o pagamento online aparecer certo no dia a dia.

- Pedidos: online chega como Pago, com selo "Mercado Pago"; pagamento na entrega continua A Receber. WhatsApp ganha a linha "PAGO via Pix/Cartão (Mercado Pago). Não cobrar na entrega".
- Caixa: valor entra como recebimento pela forma online; taxa em `taxa_aplicada`, pela taxa de cada forma.
- "Pagamento a decidir": tela para operador de caixa ou Admin escolher entre seguir com o pedido ou reembolsar.
- Cancelamento: pedido pago e cancelado abre a decisão de reembolso (manual). Reaproveita a tabela `reembolsos` e o gatilho que já existem; ao confirmar, chama `mp-reembolsar`. A regra de 3 minutos para o cliente cancelar continua.
- Relatórios: quebra por forma online e total de taxas.
- Nota fiscal: sem mudança.

**Entrega:** SQL e trechos de tela.

## Etapa 7 — Textos, LGPD e pacote v35

- Textos na Ajuda, Novidades e `ai_ajuda`.
- Aviso de Privacidade com uma linha citando o Mercado Pago como operador (CPF e e-mail vão ao Mercado Pago só para o pagamento).
- Versão v35, `sw.js` novo, receita para outros projetos e `Texas Burguer.zip` atualizado, com a pasta SUPABASE.

**Entrega:** o zip atualizado.

## Etapa 8 — Testes e conferência

- **Desligado:** pedido, cupom, brinde e fidelidade iguais aos de hoje; testes SQL existentes passam sem alteração.
- **Ligado em modo Teste (contas de teste):** Pix aprovado, Pix vencido, cartão aprovado, cartão recusado, webhook repetido, webhook com assinatura inválida.
- **Reembolso** total e parcial; estoque, cupom e brinde voltando ao cancelar.
- **Conferir da Etapa 3:** os 5 pontos "ainda não conferido" acima.
- **Celular:** telas de Pix e cartão no navegador.

**Entrega:** relatório dos testes e correções.

## Etapa 9 — Ligar de verdade (com você)

1. Cadastrar as credenciais no card.
2. Fazer o teste guiado.
3. Colar as credenciais de produção, mudar para Produção, escolher as formas online e ligar.

**Plano de volta:** botão Desligar no card devolve a página ao modo de hoje na hora, sem apagar nada. Pagamentos já feitos continuam registrados e reembolsáveis.

---

## Etapa 10 — Leitor Fiscal IA (depois do Mercado Pago)

Lê a foto de uma nota ou cupom e preenche, para você conferir, a Compra que o sistema já tem. Nada entra no estoque nem no financeiro sem sua confirmação. Reaproveita Compras, Estoque, Fornecedores, Despesas e Caixa; não cria caminho novo.

- **Fase 1:** foto, leitura e conferência (soma dos itens contra o total da nota, chave de 44 dígitos como trava de duplicidade, bloqueio se o emitente for o CNPJ do Texas Burguer, XML da NF-e lido direto quando houver).
- **Fase 2:** entrada no estoque e pagamento ("Como foi paga esta compra?": dinheiro do caixa aberto, Pix/transferência/cartão, a prazo como Contas a Pagar, ou pagamento dividido).
- **Fase 3:** exclusão automática em 30 dias, histórico e testes (notas boas, fotos ruins, notas repetidas, cada forma de pagamento).

Pontos fixos:

- IA de visão: Gemini como leitor principal, com chave dedicada; se o limite acabar, usa a chave Gemini do chat. Se falhar nas duas, digitação manual.
- Chat de texto, na ordem: Groq 1, Groq 2, NVIDIA, Cloudflare e, por último, a Gemini que já existe.
- Fotos no Supabase Storage (pasta privada), reduzidas no celular antes de enviar.
- Segundo caminho: caixa "Colar texto da nota", usando as IAs de texto.
- Uso dentro do assistente Tex (só Admin e Operador): cartão no chat com itens, total e dúvidas, e um botão "Confirmar". O Tex público nunca recebe esse recurso.
- Contas e acessos recebe só os campos das chaves (Gemini de fotos e Groq 2). As chaves já estão no Vault do Supabase como `pendente_gemini_fotos` e `pendente_groq_2`; na execução, ligar aos campos e remover os nomes `pendente_`.
- Histórico no Financeiro, junto das Compras, com a marca "Lida pelo Tex", quem confirmou e quando.

## Etapa 11 — Auditoria completa

Depois de tudo executado: revisão de todo o sistema e de todas as funções, procurando erros e bugs (cardápio, caixa, pedidos, contas, brindes, feedback, integrações e Mercado Pago). Entram também:

- Conferir que o ping a cada 2 dias que mantém o Supabase ativo continua rodando.
- Sincronização da planilha a cada 10 minutos, que mostra "tempo esgotado" de 5 segundos apesar de a planilha atualizar: ver se há algo a corrigir.

Corrijo o que achar e conto o resultado.

---

## Etapa 12 — Revisão do plano inteiro e telas iguais à prévia

Feita em 13 e 14/10/2026. Detalhes por etapa, erros achados, correções e ordem para aplicar em `4-DOCUMENTOS/revisao-do-plano-completo/REVISAO-DO-PLANO-COMPLETO.md` (no zip).

- **Também corrigido (14/10):** Leitor Fiscal (bucket só da equipe, fotos órfãs, leitura esquecida, descartar apaga a foto), resumo mensal sem contagem em dobro e LGPD das reservas/pagamentos online (SQL novo `2026-10-14-mp-lgpd-reservas-MANUAL.sql`).
- **Código usado:** `1-SUBIR-NO-GITHUB/index.html`, `estilo-16-pagamento.css` (novo), `app-15-cardapio-cliente.js`, `app-11-admin-integracoes.js`, `sw.js` (v37). SQL e Edge Functions sem mudança.
- **Visual:** formas agrupadas ("Pagar agora, pelo site" e "Pagar na entrega") com etiquetas, resumo, botão "Pagar com Pix · R$", tela do Pix com relógio de 15:00, cartão, tela "Pagamento aprovado" com a mensagem do WhatsApp e card do Admin com lista ✓/!, campos, chave liga/desliga e guia.
- **Correções:** política de segurança liberando o Mercado Pago, uso da `mp-status`, tela para "pagamento recebido, conferindo", consulta que parava de verdade ao fechar, aprovado automático, acompanhamento/avisos/local no pedido pago, taxa de entrega certa no WhatsApp, confirmação do banco (3DS), CPF com dígitos verificadores.

---

## Fontes

Documentação do Mercado Pago Developers (Orders API, Checkout Transparente, Webhooks, reembolsos, contas e cartões de teste) e página pública de tarifas, consultadas em 12/10/2026. Taxas citadas no plano original (a confirmar na sua conta): Pix 0,99%; crédito 4,98% (dinheiro na hora), 4,49% (14 dias) ou 3,98% (30 dias).
