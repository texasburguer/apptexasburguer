# Revisão do plano completo (etapas 1 a 11) — 14/10/2026

Nada foi aplicado no Supabase nem publicado. **Não rodei SQL num Postgres de verdade e não testei com o Mercado Pago, a Focus, o Gemini ou o Groq reais**: a revisão é de leitura do código, testes locais (42 + 64 verificações do Mercado Pago, sintaxe de todos os `.js`/`.ts`) e testes de tela no navegador.

## Resultado por etapa
| Etapa | O que revisei | Achados e correções |
| --- | --- | --- |
| 1 Estrutura (SQL) | Tabelas, restrições, RLS, permissões | Bom. Dados pessoais sem prazo de limpeza → **corrigido (LGPD)** |
| 2 Funções do banco (SQL) | Reserva, status, aplicar status, expirar reservas | Bom (trava de linha, chave de evento, idempotência) |
| 3 Edge Functions `mp-*` | Criar, webhook, status, reembolsar | Bom. Ressalvas abaixo |
| 4 Painel Admin (SQL + tela) | Ligar/desligar, chaves, senha do Admin | Bom. Card refeito no visual da prévia |
| 5 Telas do cardápio | Pix, cartão, aprovado | **9 erros corrigidos** (CSP, `mp-status`, conferência, aprovado, WhatsApp, 3DS, CPF...) |
| 6 Operação (SQL) | Pendências, resumo, reembolsos | Resumo do mês podia **contar em dobro** → corrigido |
| 7 Textos e LGPD | Aviso de Privacidade, ajuda | Faltava anonimizar reservas e pagamentos → **corrigido (LGPD)** |
| 8 Testes | Scripts de verificação | Passam. Um estava velho (exigia `texas-shell-v35`) → ajustado |
| 10 Leitor Fiscal (IA das fotos) | Função, limpeza, SQL, tela | **4 correções** (abaixo) |
| 11 Auditoria | Relatório, timeouts de sincronização, agendamentos | Timeout de 30 s conferido no código; jobs só se confirmam no Supabase real |

## Leitor Fiscal IA — erros corrigidos
1. **Qualquer pessoa com conta (inclusive cliente do cardápio) podia enviar fotos para o bucket `fiscal-notas`.** Agora só Admin e Operador. *Se você já aplicou o SQL da Etapa 10, rode `ajustes/2026-10-14-etapa10-correcao-bucket.sql`.*
2. **Fotos "órfãs"** (enviadas, mas a leitura falhou ou foi abandonada) ficavam guardadas para sempre. A `fiscal-limpar` agora apaga as que têm mais de 1 dia e não pertencem a nenhuma leitura.
3. **Leitura esquecida bloqueava a nota para sempre** (a chave ficava como "duplicada"). Agora, leitura não confirmada há mais de 30 minutos é descartada e a nota pode ser lida de novo.
4. **Descartar uma leitura não apagava a foto.** Agora apaga na hora.

O que conferi sem achar problema: só Admin/Operador chamam a função; foto só de dentro da pasta do próprio usuário; chave do Gemini vai no cabeçalho, não na URL; texto vindo da IA é limpo e a pessoa confere tudo antes de lançar; bloqueio do CNPJ da própria loja no servidor; a compra usa um identificador fixo por leitura (repetir o clique não duplica); pagamento dividido fica bloqueado de propósito.

## LGPD (novo): reservas e pagamentos online
`pedidos_reserva` guarda nome, telefone e endereço; `pagamentos_online` guarda o QR do Pix. Nem "apagar conta" nem a anonimização de 3 anos passavam por elas. O arquivo `ajustes/2026-10-14-mp-lgpd-reservas-MANUAL.sql` (colar à mão, como os outros MANUAL) cria a anonimização, uma limpeza diária (QR de Pix vencido em 2 dias; reservas encerradas em 180 dias) e faz "apagar conta" incluir esses dados. Reservas com pagamento aprovado esperando decisão não são tocadas.

## Pontos de atenção (não são erros comprovados)
- **Chave secreta do aviso (webhook) é uma só** para teste e produção. Se o Mercado Pago der uma chave diferente em cada modo, depois de ligar em produção os avisos serão recusados. A tela do cliente continua funcionando (ela consulta o pagamento sozinha), mas confirme isso no teste da Etapa 9.
- Webhook sem conferência da idade da assinatura: risco baixo, o status sempre vem de uma consulta ao Mercado Pago.
- Tabela de avisos (`pagamentos_online_eventos`) cresce sem limpeza; assinatura inválida é limitada por minuto.
- As Edge Functions respondem com CORS aberto (`*`) e usam login por token, não cookie; é o padrão do projeto.
- `Código do Supabase.html` estava desatualizado (sem Mercado Pago e sem Leitor Fiscal). Foi atualizado nesta entrega.
- Os agendamentos (`ping-2dias`, `sync-fila-2min`, `contingencia-espelho-10min`, `fiscal-leituras-limpeza-diaria`, `mp-expirar-reservas`, `mp-lgpd-diario`) estão no SQL, mas só você confirma que estão ativos em `cron.job` no Supabase.

## Ordem para aplicar no Supabase (o que ainda não aplicou)
1. Mercado Pago: etapa1 → etapa2 → etapa4 → etapa6 (o resumo corrigido já está dentro da etapa6).
2. Leitor Fiscal: `2026-10-14-etapa10-leitor-fiscal.sql` (já com a política corrigida) — ou, se já aplicou, só o `...-correcao-bucket.sql`.
3. LGPD: `2026-10-14-mp-lgpd-reservas-MANUAL.sql` (por último; depende de 1 e do SQL de contas de clientes).
4. Publicar as funções `mp-criar`, `mp-webhook`, `mp-status`, `mp-reembolsar`, `leitor-fiscal` e `fiscal-limpar` (as duas últimas mudaram).
5. Publicar a pasta `1-SUBIR-NO-GITHUB` inteira.

## Teste em modo TESTE (Etapa 9, com você)
Pix e cartão de teste (APRO aprova, OTHE recusa) → tela "Pagamento aprovado" e WhatsApp → cancelar os pedidos de teste. Leitor Fiscal: foto ruim, nota repetida, CNPJ da própria loja, XML, nota sem chave, fornecedor não cadastrado, foto descartada some do bucket.
