// ---------- ROTEADOR DE INTENÇÃO (sem IA): decide quais dados, catálogo, manual e blocos de instrução a pergunta realmente precisa ----------
// Cada área = chaves do JSON de ia_contexto_geral. Prompt menor = resposta bem mais rápida e menos recusa por limite nas IAs gratuitas.
const BASE_CHAVES = ["ok", "agora", "dia_semana", "perfil"];
const AREAS: Record<string, { re: RegExp; chaves: string[]; direto?: boolean }> = {
  vendas: { re: /venda|vendi|vend[eo]u|faturamento|fatur|receita|ticket|lucro|margem|quantos pedidos|movimento|pico|dia da semana|forma de pagamento|pagamento|pix|cart[aã]o|dinheiro|mais vendid|menos vendid|ranking|desempenho|compar/i,
    chaves: ["periodos", "top_produtos_hoje", "top_produtos_30d", "menos_vendidos_30d", "pedidos_por_hora_30d", "pedidos_por_dia_semana_30d", "formas_pagamento"] },
  operacao: { re: /andamento|em preparo|preparo|cozinha|produ[cç][aã]o|fila|atras|demor|entrega|entregador|motoboy|em rota|mesa|chamad|gar[cç]om/i,
    chaves: ["pedidos_em_andamento", "producao", "entregas", "mesas"], direto: true },
  estoque: { re: /estoque|insumo|ingrediente|acabando|zerad|repor|reposi[cç][aã]o|comprar|compras/i, chaves: ["estoque", "estoque_valor_total"], direto: true },
  caixa: { re: /caixa|sangria|fundo de caixa|abertura|fechamento/i, chaves: ["caixa"], direto: true },
  clientes: { re: /cliente|fidelidade|fiel|aniversar/i, chaves: ["clientes", "feedbacks_30d", "cupons_ativos"] },
  despesas: { re: /despesa|gasto|conta a pagar|a pagar|vencid|custo|evento|financeiro|aluguel|energia|sal[aá]rio/i, chaves: ["despesas", "eventos_proximos", "periodos"] },
  cardapio: { re: /card[aá]pio|produto|lanche|burg|combo|pre[cç]o|custa|\bitens?\b|esgot|dispon[ií]ve|promo|adicional|bebida|batata|sobremesa|\bmenu\b|cupom|cupons/i, chaves: ["cardapio", "cupons_ativos", "top_produtos_30d"] },
  avaliacoes: { re: /feedback|avalia[cç]|nota|reclama|elogio|ocorr[eê]ncia|problema|coment[aá]rio/i, chaves: ["feedbacks_30d", "ocorrencias_abertas"] },
};
const BASICO = ["periodos", "caixa", "pedidos_em_andamento", "estoque", "feedbacks_30d", "ocorrencias_abertas"];
const GERAL = /como est[aá] (o )?(neg[oó]cio|restaurante|movimento)|resumo|panorama|vis[aã]o geral|an[aá]lise geral|o que (voc[eê] )?(acha|sugere|recomenda)|dicas?|melhorar|estrat[eé]gia|oportunidade/i;
const TEMPORAL_FORA = /m[eê]s passado|m[eê]s anterior|ano passado|semana passada|h[aá] \d+|janeiro|fevereiro|mar[cç]o|abril|maio|junho|julho|agosto|setembro|outubro|novembro|dezembro|\d{1,2}\/\d{1,2}|antigo|hist[oó]ric|arquivo|[uú]ltimos? \d+|desde|entre .* e /i;
const QUER_ACAO = /registr|lan[cç]|comprei|paguei|pagar|cadastr|sangria|ajuste|brinde|ocorr[eê]ncia|propon|anot|adicion|entrada|perda|invent[aá]rio|receber (a )?compra|cancelar (a )?(compra|despesa)|salvar|confirm/i;
const QUER_TABELA = /lista|listar|quais|detalh|tabela|fornecedor|compra|usu[aá]rio|funcion|evento|reserva|auditoria|log|todos os|todas as|por (dia|m[eê]s|categoria)|agrup/i;
const QUER_MANUAL = /como (fa[cç]o|faz|eu|se|posso|usar|configur|cadastr|abr|fech|imprim)|onde (fica|vejo|est[aá]|acho)|passo a passo|tutorial|ajuda|n[aã]o consigo|configur|imprim|funciona|para que serve|o que [eé]\b/i;

function rotear(pergunta: string, conversa: string, comDados: boolean) {
  const tc = pergunta + " " + conversa;   // follow-ups curtos herdam o assunto da conversa
  let areas = Object.keys(AREAS).filter((a) => AREAS[a].re.test(pergunta));
  if (!areas.length && pergunta.trim().length < 40) areas = Object.keys(AREAS).filter((a) => AREAS[a].re.test(tc));
  const geral = GERAL.test(pergunta);
  const temporal = TEMPORAL_FORA.test(pergunta);
  const manual = QUER_MANUAL.test(pergunta) || !comDados;
  const propostas = QUER_ACAO.test(tc);
  const sem = !areas.length && !geral;
  const catalogo = comDados && (geral || QUER_TABELA.test(pergunta) || temporal);   // se faltar, o catálogo é buscado na hora em que a IA pedir explorar/agregar
  const direto = comDados && !geral && !temporal && !propostas && areas.length > 0 && areas.every((a) => AREAS[a].direto);
  return { areas, geral, temporal, manual, propostas, catalogo, direto, sem };
}

function filtrarDados(ctx: any, rota: ReturnType<typeof rotear>) {
  if (!ctx || typeof ctx !== "object") return ctx;
  if (rota.geral) { const { cardapio: _c, ...resto } = ctx; return { ...resto, cardapio: "(lista omitida: peça uma consulta explorar em produtos se precisar)" }; }
  const quer = new Set<string>(BASE_CHAVES);
  if (rota.areas.length) rota.areas.forEach((a) => AREAS[a].chaves.forEach((k) => quer.add(k)));
  else BASICO.forEach((k) => quer.add(k));
  const out: any = {};
  for (const k of Object.keys(ctx)) if (quer.has(k)) out[k] = ctx[k];
  if (out.periodos && !rota.areas.some((a) => ["vendas", "despesas"].includes(a)) && !rota.sem) { const { hoje, ontem } = out.periodos; out.periodos = { hoje, ontem }; }
  const omitidas = Object.keys(ctx).filter((k) => !quer.has(k));
  if (omitidas.length) out.dados_omitidos = `(não enviados para esta pergunta: ${omitidas.join(", ")}. Se precisar deles, peça uma consulta.)`;
  return out;
}


export { rotear, filtrarDados };
