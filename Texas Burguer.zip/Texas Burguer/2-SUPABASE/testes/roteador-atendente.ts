const RE_COMIDA = /card[aá]pio|lanche|burg|combo|pre[cç]o|custa|quanto|\bitens?\b|esgot|dispon[ií]ve|promo|adicional|bebida|batata|sobremesa|por[cç][aã]o|recomend|sugest|indica|fome|pessoas|or[cç]amento|barato|melhor|mais pedid|vegetar|monte|montar|quero|vou querer|pedir/i;
const RE_LOJA = /hor[aá]rio|abre|abrem|fecha|fecham|aberto|endere[cç]o|onde fica|entrega|taxa|frete|bairro|pagamento|pix|cart[aã]o|troco|dinheiro|telefone|contato|whats|retirada|reserva|estacion|wi-?fi/i;
const RE_PEDIDO = /meu pedido|cad[eê]|demor|chegou|status|onde est[aá]|atras|j[aá] saiu|previs[aã]o|n[aã]o chegou|errad|faltou|faltando|cobran[cç]|reclama|problema|cancel/i;
const RE_DETALHE = /ingrediente|leva |cont[eé]m|composi|descri|al[eé]rgi|gl[uú]ten|lactose|picante|apimentad|sem (cebola|queijo|carne|molho|p[aã]o)|vegetar|vegano|o que (tem|vem)|como [eé]/i;
function filtrarCtx(ctx: any, pergunta: string, hist: string, temStatus: boolean) {
  if (!ctx || typeof ctx !== "object") return { ctx, rotulo: "bruto" };
  const t = pergunta.trim().length < 40 ? pergunta + " " + hist : pergunta;   // follow-up curto herda o assunto
  const comida = RE_COMIDA.test(t), loja = RE_LOJA.test(t), pedido = RE_PEDIDO.test(t) && temStatus;
  const { produtos, combos, mais_pedidos, promocoes, adicionais_disponiveis_em_todos_os_lanches, ...resto } = ctx;
  if (!comida && pedido) return { ctx: { ...resto, aviso: "(lista de produtos não enviada: a pergunta é sobre o pedido do cliente)" }, rotulo: "pedido" };
  if (!comida && loja) return { ctx: { ...resto, aviso: "(lista de produtos não enviada: a pergunta é sobre a loja; se o cliente perguntar de comida, ele repete a pergunta e você recebe o cardápio)" }, rotulo: "loja" };
  // cardápio completo (padrão seguro); descrições só quando perguntam de ingredientes/composição
  if (RE_DETALHE.test(t)) return { ctx, rotulo: "cardapio+detalhe" };
  const semDesc = (l: any) => Array.isArray(l) ? l.map((x: any) => { if (x && typeof x === "object" && "descricao" in x) { const { descricao: _d, ...r } = x; return r; } return x; }) : l;
  return { ctx: { ...ctx, produtos: semDesc(produtos), combos: semDesc(combos) }, rotulo: "cardapio" };
}


export { filtrarCtx };
