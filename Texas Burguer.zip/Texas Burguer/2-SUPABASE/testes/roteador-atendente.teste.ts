import { filtrarCtx } from "./roteador-atendente.ts";
const ctx:any={caixa_aberto:true,config:{a:1},formas_pagamento:[1],produtos:[{nome:"X",descricao:"pão e carne",preco:20}],combos:[{nome:"C",descricao:"d"}],mais_pedidos:["X"],promocoes:[],adicionais_disponiveis_em_todos_os_lanches:[]};
const q:[string,boolean][]=[["que horas vocês abrem?",false],["qual o preço do X?",false],["meu pedido demora?",true],["o que tem no X?",false],["tem pix?",false],["quero um lanche pra 2 pessoas",false],["oi",false]];
for (const [p,st] of q){const f=filtrarCtx(ctx,p,"",st);console.log(p.padEnd(32),f.rotulo.padEnd(18),Object.keys(f.ctx).join(","),"desc:",JSON.stringify(f.ctx.produtos?.[0]?.descricao));}
