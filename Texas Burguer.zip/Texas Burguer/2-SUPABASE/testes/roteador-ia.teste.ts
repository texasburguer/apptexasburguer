import { rotear, filtrarDados } from "./roteador-ia.ts";
const casos: [string,string][] = [
 ["quanto vendi hoje?","vendas"],["como está o caixa?","caixa"],["tem pedido atrasado?","operacao"],
 ["o que está acabando no estoque","estoque"],["qual o preço do x-bacon","cardapio"],["quais clientes mais gastaram","clientes"],
 ["tenho contas vencidas?","despesas"],["como está o negócio?","geral"],["registrar despesa de luz 120","despesas"],
 ["como faço para imprimir o pedido","-"],["vendas de março","vendas"],["oi","basico"],["e ontem?","basico"],
 ["qual a nota média dos feedbacks","avaliacoes"],["me dá dicas para melhorar o lucro","geral"],["quem é o presidente","basico"],
];
for (const [q,esperado] of casos) { const r = rotear(q,"",true); console.log(q.padEnd(44), "areas=",r.areas.join("+")||(r.geral?"geral":"basico"), "| direto",r.direto,"cat",r.catalogo,"manual",r.manual,"prop",r.propostas,"temp",r.temporal, " esperado:",esperado); }
const ctx:any={ok:true,agora:"x",dia_semana:"s",perfil:"Admin",periodos:{hoje:1,ontem:2,ultimos_7_dias:3},cardapio:{p:1},estoque:{a:1},caixa:{aberto:true},clientes:{}};
console.log(JSON.stringify(filtrarDados(ctx,rotear("como está o caixa?","",true))));
