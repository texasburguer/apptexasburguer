import { rotear, filtrarDados } from "./roteador-ia.ts";
// [pergunta, conversa anterior, áreas esperadas (ordenadas, "" = nenhuma), direto?, geral?, catalogo?, manual?]
const casos: [string, string, string, boolean, boolean, boolean, boolean][] = [
 ["quanto vendi hoje?", "", "vendas", false, false, false, false],
 ["qual o faturamento de ontem", "", "vendas", false, false, false, false],
 ["como está o caixa?", "", "caixa", true, false, false, false],
 ["o caixa está aberto?", "", "caixa", true, false, false, false],
 ["tem pedido atrasado?", "", "operacao", true, false, false, false],
 ["quais entregas estão em rota", "", "operacao", true, false, true, false],
 ["o que está acabando no estoque", "", "estoque", true, false, false, false],
 ["preciso repor algum insumo?", "", "estoque", true, false, false, false],
 ["qual o preço do x-bacon", "", "cardapio", false, false, false, false],
 ["tem algum item esgotado?", "", "cardapio", false, false, false, false],
 ["quais clientes mais gastaram", "", "clientes", false, false, true, false],
 ["tenho contas vencidas?", "", "despesas", false, false, false, false],
 ["como está o negócio?", "", "", false, true, true, false],
 ["me dá dicas para melhorar o lucro", "", "vendas", false, true, true, false],
 ["vendas de março", "", "vendas", false, false, true, false],
 ["como faço para imprimir o pedido", "", "", false, false, false, true],
 ["registrar despesa de luz 120", "", "despesas", false, false, false, false],
 ["oi", "", "", false, false, false, false],
 ["e ontem?", "usuario: quanto vendi hoje?", "vendas", false, false, false, false],
 ["quem é o presidente do Brasil", "", "", false, false, false, false],
];
let falhas = 0;
for (const [q, conv, areas, direto, geral, cat, manual] of casos) {
  const r = rotear(q, conv, true);
  const got = r.areas.slice().sort().join("+");
  const ok = got === areas.split("+").sort().join("+") || (areas === "" && got === "");
  const flags = r.direto === direto && r.geral === geral;
  // só reporta divergência de área/direto/geral (catálogo/manual são informativos)
  if (!ok || !flags) { falhas++; console.log("DIVERGE ", q.padEnd(40), "areas=", got || "-", "direto", r.direto, "geral", r.geral, "| esperado", areas || "-", direto, geral); }
  else console.log("ok      ", q.padEnd(40), "areas=", got || "-", "direto", r.direto, "cat", r.catalogo, "manual", r.manual);
}
// Operador (sem dados): nunca recebe dados nem catálogo
const op = rotear("quanto vendi hoje?", "", false);
console.log("operador sem dados: direto", op.direto, "catalogo", op.catalogo, "manual", op.manual);
// tamanho do contexto: filtrar deve cortar bastante
const ctx: any = { ok: true, agora: "x", dia_semana: "s", perfil: "Admin", periodos: { hoje: 1, ontem: 2, u7: 3 }, cardapio: "c".repeat(6000), estoque: { a: 1 }, caixa: { aberto: true }, clientes: "k".repeat(3000), top_produtos_30d: "t".repeat(1500), despesas: "d".repeat(1500) };
for (const q of ["como está o caixa?", "quanto vendi hoje?", "qual o preço do x-bacon"]) console.log(q.padEnd(28), "bytes enviados:", JSON.stringify(filtrarDados(ctx, rotear(q, "", true))).length, "de", JSON.stringify(ctx).length);
console.log(falhas ? `${falhas} divergência(s)` : "TUDO CONFORME");
