# Backup completo + restauração segura (itens 1 e 2 do plano)

## Ordem para aplicar (importa)
1. SQL Editor do Supabase: rodar `ajustes/2026-10-15-backup-restauracao.sql` (uma vez).
2. Publicar `funcoes/criar-backup/index.ts` e `funcoes/restaurar-backup/index.ts` (cada uma com seu `auth.ts` atual).
3. Testar num projeto Supabase separado (item 3 do plano) antes de usar em produção.

## O que mudou
- **Backup**: a lista de tabelas vem do banco (`backup_tabelas()`): todo o schema `public`, menos
  `backups, arquivo_historico, backup_config, ai_segredos, integracoes_segredos, ifood_token, contas_acessos,
  fila_sync, ai_cache, ai_log, tentativas, sync_estado, versoes_sync`. Tabela nova entra sozinha.
  Backup e restauração não têm mais duas listas para manter iguais.
- **Restauração**: uma função SQL (`restaurar_backup_dados`) faz tudo em uma transação. Falhou = nada muda.
  Não apaga e recria. Grava por cima (pais antes dos filhos, ordem lida das chaves estrangeiras) e depois remove
  só as linhas que não estavam no backup. Assim `vendas` do backup nunca são apagadas e o cascata não atinge
  `contas_pedidos`, `chat_*`, `entrega_destinos`, `pedido_destinos` etc. dessas vendas. `brindes` e `reembolsos`
  passam a ser tratados porque entram no backup. No fim confere a contagem de cada tabela (senão desfaz).
- `usuarios` e `auditoria` continuam sendo salvos mas não restaurados; `sistema` só grava por cima.
- Backups antigos (38 tabelas) continuam restaurando: só as tabelas presentes no arquivo são tocadas.

## Atenção
- Aplicado em produção em 15/10/2026 (SQL + funções). Testado com transação desfeita (rollback); a restauração real ainda não foi exercitada. Teste num projeto separado antes de usar o botão Restaurar.
- Pontos para observar no teste: tempo e memória do backup com 100+ tabelas; tamanho do envio único ao banco
  na restauração; gatilhos que gerem linhas extras (a conferência de contagem vai acusar e desfazer).
- Segredos ficam fora do backup: após restaurar num projeto novo, recadastrar as chaves.
- Restauração: linhas com chave única repetida entre backup e linha nova podem dar erro (desfaz tudo, com mensagem).
- Falta ajustar o `SUBIR-TUDO-supabase.sql`/`01-estrutura.sql` se quiser que um banco novo já nasça com essas funções.
