-- JÁ APLICADO no Supabase em 16/10/2026 (migração rls_initplan_mesas_vendas_destinos). Só rode de novo se refizer o banco.
-- Troca auth.uid() por (select auth.uid()) em 3 políticas de leitura, para o banco calcular uma vez por consulta (e não por linha).
-- Mesma regra de acesso de antes; só muda o desempenho.
alter policy mesas_ler on public.mesas using (
  tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso])
  OR (tem_nivel(VARIADIC ARRAY['Garçom'::nivel_acesso]) AND ((garcom_responsavel_id IS NULL) OR (garcom_responsavel_id = (select auth.uid()))))
);
alter policy vendas_ler on public.vendas using (
  tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso])
  OR (tem_nivel(VARIADIC ARRAY['Garçom'::nivel_acesso]) AND (((tipo = 'Mesa'::venda_tipo) AND (mesa_id IN ( SELECT m.id FROM mesas m WHERE (m.garcom_responsavel_id = (select auth.uid()))))) OR (registrado_por = (select auth.uid()))))
  OR (tem_nivel(VARIADIC ARRAY['Cozinha'::nivel_acesso]) AND (status = 'Confirmada'::venda_status) AND (status_pedido = ANY (ARRAY['Recebido'::status_pedido, 'Em preparo'::status_pedido, 'Pronta'::status_pedido, 'Suspenso'::status_pedido])))
  OR (tem_nivel(VARIADIC ARRAY['Cozinha'::nivel_acesso]) AND (status = 'Confirmada'::venda_status) AND (status_pedido = ANY (ARRAY['Retirada'::status_pedido, 'Entregue'::status_pedido, 'Servida'::status_pedido])) AND (caixa_id = ( SELECT _caixa_aberto_id() AS _caixa_aberto_id)))
  OR (tem_nivel(VARIADIC ARRAY['Entregador'::nivel_acesso]) AND (tipo = 'Entrega'::venda_tipo) AND (entregador_id = (select auth.uid())))
);
alter policy destinos_ler on public.pedido_destinos using (
  tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso])
  OR (tem_nivel(VARIADIC ARRAY['Entregador'::nivel_acesso]) AND (EXISTS ( SELECT 1 FROM vendas v WHERE ((v.id = pedido_destinos.venda_id) AND (v.entregador_id = (select auth.uid()))))))
);
