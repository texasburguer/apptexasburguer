-- Caixa vencido (Fase 4, item 0) · JÁ APLICADO no Supabase em 16/10/2026 (migração caixa_vencido_fase4_item0).
-- Exportado do banco em 16/10/2026 para referência. Só rode de novo se refizer o banco. Teste: testes/teste-caixa-vencido.sql
-- As 5 funções que ganharam trava (api_iniciar_venda, api_fechar_conta_mesa, api_add_sangria, api_registrar_brinde, api_fechar_caixa) e a view v_sessao_aberta estão COMPLETAS em 01-estrutura.sql (conferidas contra o banco em 16/10/2026).

create table if not exists public.caixa_config (
  id boolean primary key default true check (id),
  corte_hora time not null default '06:00',
  vida_minima_horas int not null default 6,
  teto_horas int not null default 24,
  aviso_horas int not null default 2,
  liberacao_padrao_horas int not null default 4,
  liberacao_max_horas int not null default 12,
  atualizado_em timestamptz not null default now()
);
insert into public.caixa_config (id) values (true) on conflict do nothing;
create table if not exists public.caixa_liberacoes (
  id uuid primary key default gen_random_uuid(),
  caixa_id uuid not null references public.caixa_sessoes(id) on delete cascade,
  liberado_por uuid,
  motivo text not null,
  horas int not null,
  criado_em timestamptz not null default now(),
  ate timestamptz not null
);
alter table public.caixa_sessoes add column if not exists fechamento_atrasado boolean not null default false;
alter table public.caixa_sessoes add column if not exists fechamento_motivo text;
alter table public.caixa_config enable row level security;
alter table public.caixa_liberacoes enable row level security;

CREATE OR REPLACE FUNCTION public._caixa_vence_em(p_abertura timestamp with time zone)
 RETURNS timestamp with time zone LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare c caixa_config%rowtype; v_base timestamp; v_corte timestamp; v_vence timestamptz;
begin
  select * into c from caixa_config limit 1;
  v_base := (p_abertura at time zone 'America/Sao_Paulo') + make_interval(hours => c.vida_minima_horas);
  v_corte := date_trunc('day', v_base) + c.corte_hora;
  if v_corte < v_base then v_corte := v_corte + interval '1 day'; end if;
  v_vence := v_corte at time zone 'America/Sao_Paulo';
  return least(v_vence, p_abertura + make_interval(hours => c.teto_horas));
end $function$;

CREATE OR REPLACE FUNCTION public._caixa_vencido(p_caixa uuid)
 RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
  select coalesce(s.status = 'Aberto'::status_caixa
         and now() >= _caixa_vence_em(s.abertura)
         and not exists (select 1 from caixa_liberacoes l where l.caixa_id = s.id and l.ate > now()), false)
  from caixa_sessoes s where s.id = p_caixa
$function$;

CREATE OR REPLACE FUNCTION public._caixa_msg_vencido()
 RETURNS text LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare v_ab timestamptz;
begin
  select abertura into v_ab from caixa_sessoes where status = 'Aberto'::status_caixa order by abertura desc limit 1;
  if auth_nivel()::text in ('Admin', 'Operador', 'Desenvolvedor') then
    return 'O caixa está vencido (aberto em ' || to_char(v_ab at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI')
      || '). Feche-o em "Fechar caixa vencido" e abra um novo. Em emergência, o Administrador pode liberar por algumas horas.';
  end if;
  return 'O caixa está vencido — chame o responsável.';
end $function$;

CREATE OR REPLACE FUNCTION public.api_caixa_config(p jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare c caixa_config%rowtype;
begin
  if not tem_nivel('Admin', 'Operador', 'Desenvolvedor') then return _negado(); end if;
  select * into c from caixa_config limit 1;
  return jsonb_build_object('ok', true, 'corteHora', to_char(c.corte_hora, 'HH24:MI'), 'vidaMinimaHoras', c.vida_minima_horas, 'tetoHoras', c.teto_horas,
    'avisoHoras', c.aviso_horas, 'liberacaoPadraoHoras', c.liberacao_padrao_horas, 'liberacaoMaxHoras', c.liberacao_max_horas);
end $function$;

CREATE OR REPLACE FUNCTION public.api_caixa_liberar(p jsonb)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare c caixa_config%rowtype; v_cx uuid; v_h int; v_mot text := btrim(coalesce(p->>'motivo', '')); v_ate timestamptz; v_quem text;
begin
  if not tem_nivel('Admin', 'Desenvolvedor') then return _negado(); end if;
  select * into c from caixa_config limit 1;
  select id into v_cx from caixa_sessoes where status = 'Aberto'::status_caixa order by abertura desc limit 1 for update;
  if v_cx is null then return _falha('Não há caixa aberto para liberar.'); end if;
  if not _caixa_vencido(v_cx) then return _falha('O caixa não está vencido (ou já está liberado). Nada a fazer.'); end if;
  if length(v_mot) < 3 then return _falha('Informe o motivo da liberação.'); end if;
  v_h := coalesce(nullif(p->>'horas', '')::int, c.liberacao_padrao_horas);
  if v_h < 1 or v_h > c.liberacao_max_horas then return _falha('A liberação vai de 1 a ' || c.liberacao_max_horas || ' horas.'); end if;
  v_ate := now() + make_interval(hours => v_h);
  insert into caixa_liberacoes (caixa_id, liberado_por, motivo, horas, ate) values (v_cx, auth.uid(), left(v_mot, 300), v_h, v_ate);
  perform _auditar('Caixa vencido liberado', v_h || ' h, até ' || to_char(v_ate at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') || ' | Motivo: ' || left(v_mot, 300));
  select login into v_quem from usuarios where id = auth.uid();
  perform _push_enviar('caixa', '⚠️ Caixa vencido liberado', coalesce(v_quem, 'Admin') || ' liberou por ' || v_h || ' h: ' || left(v_mot, 80), 'caixa-liberado-' || v_cx::text);
  return jsonb_build_object('ok', true, 'message', 'Caixa liberado por ' || v_h || ' h (até ' || to_char(v_ate at time zone 'America/Sao_Paulo', 'HH24:MI') || ').');
end $function$;

CREATE OR REPLACE FUNCTION public.api_caixa_salvar_config(p jsonb)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
begin
  if not tem_nivel('Admin', 'Desenvolvedor') then return _negado(); end if;
  update caixa_config set
    corte_hora = coalesce(nullif(p->>'corteHora', '')::time, corte_hora),
    vida_minima_horas = coalesce(nullif(p->>'vidaMinimaHoras', '')::int, vida_minima_horas),
    teto_horas = coalesce(nullif(p->>'tetoHoras', '')::int, teto_horas),
    aviso_horas = coalesce(nullif(p->>'avisoHoras', '')::int, aviso_horas),
    liberacao_padrao_horas = coalesce(nullif(p->>'liberacaoPadraoHoras', '')::int, liberacao_padrao_horas),
    liberacao_max_horas = coalesce(nullif(p->>'liberacaoMaxHoras', '')::int, liberacao_max_horas),
    atualizado_em = now()
  where id = true;
  perform _auditar('Regra do caixa vencido alterada', 'Corte ' || (select to_char(corte_hora, 'HH24:MI') from caixa_config) || ' | teto ' || (select teto_horas from caixa_config) || ' h');
  return jsonb_build_object('ok', true, 'message', 'Regra do caixa vencido salva.');
exception when others then
  return _falha('Valores inválidos para a regra do caixa vencido.');
end $function$;
