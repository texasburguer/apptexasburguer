-- 2026-10-15 · api_compartilhar_destino_pedido: limite também por pedido (achado F da auditoria)
-- Já aplicado no projeto awryywtgqfaxppayzpca (migração destino_pedido_limite_por_pedido).
-- Antes: só limite por IP (10 chamadas / 10 min). Agora também 6 chamadas / 10 min por pedido, de qualquer IP.
-- Por que não exigir o ID completo: o "código" de 8 caracteres é a credencial pública de TODO o acompanhamento
-- (status, distância, cancelar, feedback) e a tela de acompanhamento só conhece esses 8. Exigir o ID completo
-- quebraria o botão de localização sem proteger mais; o limite por pedido impede ficar trocando o destino de outro.
-- Teste feito com transação desfeita: 6 chamadas passam, a 7ª recebe "Muitas tentativas para este pedido".

CREATE OR REPLACE FUNCTION public.api_compartilhar_destino_pedido(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_alvo text := lower(btrim(coalesce(p->>'codigo', ''))); v_ip text := _ip_cliente(); v vendas%rowtype;
  v_lat double precision; v_lng double precision; v_chave_ped text;
begin
  if v_alvo !~ '^[0-9a-f-]{8,36}$' then return jsonb_build_object('ok', false, 'message', 'Código do pedido inválido.'); end if;
  if _excedeu('destino_ip_' || v_ip, 10) then return jsonb_build_object('ok', false, 'limite', true, 'message', 'Muitas tentativas. Aguarde alguns minutos.'); end if;
  perform _registrar_falha('destino_ip_' || v_ip, 600);
  -- Limite também por pedido (qualquer IP): quem descobrir o final do ID não consegue ficar trocando o destino do outro.
  v_chave_ped := 'destino_ped_' || right(v_alvo, 8);
  if _excedeu(v_chave_ped, 6) then return jsonb_build_object('ok', false, 'limite', true, 'message', 'Muitas tentativas para este pedido. Aguarde alguns minutos.'); end if;
  perform _registrar_falha(v_chave_ped, 600);
  begin v_lat := (p->>'lat')::double precision; v_lng := (p->>'lng')::double precision;
  exception when others then return jsonb_build_object('ok', false, 'message', 'Localização inválida.'); end;
  if v_lat is null or v_lng is null or v_lat not between -90 and 90 or v_lng not between -180 and 180 then
    return jsonb_build_object('ok', false, 'message', 'Localização inválida.'); end if;
  select * into v from vendas where right(id::text, 8) = right(v_alvo, 8) and right(id::text, length(v_alvo)) = v_alvo order by data_hora desc limit 1;
  if not found or v.tipo::text <> 'Entrega' or v.status::text <> 'Confirmada'
     or v.status_pedido::text not in ('Recebido', 'Em preparo', 'Pronta', 'Saiu para entrega') then
    return jsonb_build_object('ok', false, 'message', 'Não foi possível registrar a localização para este pedido.'); end if;
  insert into entrega_destinos (venda_id, lat, lng, compartilhado_em) values (v.id, v_lat, v_lng, now())
  on conflict (venda_id) do update set lat = excluded.lat, lng = excluded.lng, compartilhado_em = now();
  return jsonb_build_object('ok', true);
end $function$;
