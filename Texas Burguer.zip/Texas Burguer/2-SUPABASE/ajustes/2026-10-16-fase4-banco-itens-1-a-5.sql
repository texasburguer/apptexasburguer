-- =====================================================================
-- Fase 4 · itens 1 a 5 do banco (2026-10-16)
-- 1) Fuso horário: o banco roda em UTC. Onde a regra é "dia de hoje" do restaurante, usa America/Sao_Paulo.
--    (api_mp_resumo_operacional já estava certo.) Muda: _imposto_pct, api_integracoes_flags, api_simular_precificacao,
--    chat_ia_consumir_cota (cota diária da IA do cliente: zerava às 21h) e api_ifood_financeiro (recebido nos últimos 30 dias).
-- 2) Revoga TRUNCATE de anon/authenticated nas tabelas do schema public (a API não alcança, mas não deve existir).
-- 3) _nfce_traduzir com search_path fixo.
-- 4) Índice duplicado em ai_ajuda: fica o da restrição (ai_ajuda_slug_key); cai o ai_ajuda_slug_uq.
-- 5) chamar_edge: prazo de 30 s no pg_net (o padrão de 5 s perdia a resposta de chamadas lentas; a função continuava rodando).
-- Idempotente: pode rodar de novo sem efeito. Não apaga nem altera dados.
-- =====================================================================
do $$
declare
  v_sp text := '(now() at time zone ''America/Sao_Paulo'')::date';
  r record; d text;
begin
  -- 1) fuso horário
  for r in select p.oid, p.proname from pg_proc p
            where p.pronamespace = 'public'::regnamespace and p.prokind = 'f'
              and p.proname in ('_imposto_pct', 'api_integracoes_flags', 'api_simular_precificacao', 'chat_ia_consumir_cota', 'api_ifood_financeiro') loop
    d := pg_get_functiondef(r.oid);
    if r.proname = 'api_ifood_financeiro' then
      d := replace(d, 'criado_em::date', '(criado_em at time zone ''America/Sao_Paulo'')::date');
    end if;
    d := replace(replace(d, 'CURRENT_DATE', v_sp), 'current_date', v_sp);
    execute d;
  end loop;

  -- 5) prazo do pg_net
  d := pg_get_functiondef('public.chamar_edge'::regproc);
  if position('timeout_milliseconds' in d) = 0 then
    d := replace(d, 'body := p_body)', 'body := p_body, timeout_milliseconds := 30000)');
    execute d;
  end if;
end $$;

-- 2) TRUNCATE
revoke truncate on all tables in schema public from anon, authenticated;
do $$ begin
  begin alter default privileges for role postgres in schema public revoke truncate on tables from anon, authenticated;
  exception when others then null; end;
end $$;

-- 3) search_path fixo
alter function public._nfce_traduzir(text) set search_path = public;

-- 4) índice duplicado
drop index if exists public.ai_ajuda_slug_uq;
