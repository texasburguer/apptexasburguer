-- Fase 1 · Dinheiro e fiscal (16/10/2026)
-- 1 CPF do iFood na nota · 2 LGPD do CPF · 3 nota bloqueada com item sem ligação e descrição fiscal limpa
-- 4 pagamento 99 com descrição (campo da Focus: descricao_pagamento, 2 a 60 letras, só quando forma = 99)
-- 5 reembolso feito no painel do Mercado Pago. Teste: testes/teste-fase1.sql

-- ---------- 4. descrição do pagamento 99 ----------
create or replace function public._nfce_forma_desc(p text) returns text
language sql immutable set search_path to 'public' as $$
  select case when public._nfce_forma_codigo(p) <> '99' then null
    else left(case
      when lower(coalesce(p,'')) ~ 'ifood' and lower(p) ~ 'entrega' and lower(p) ~ 'app' then 'iFood - parte no app, parte na entrega'
      when lower(coalesce(p,'')) ~ 'ifood' and lower(p) ~ 'entrega' then 'iFood - pagar na entrega'
      when lower(coalesce(p,'')) ~ 'ifood' then 'iFood - pago no app'
      else coalesce(nullif(btrim(p), ''), 'Outros') end, 60) end
$$;

-- ---------- 3 e 4. nfce_montar ----------
create or replace function public.nfce_montar(p_id bigint)
 returns jsonb language plpgsql stable security definer set search_path to 'public'
as $function$
declare n nfce_notas%rowtype; v vendas%rowtype; e fiscal_empresa%rowtype; r record; v_itens jsonb := '[]'::jsonb; v_pags jsonb := '[]'::jsonb;
  v_sem text; v_semlig text; v_bruto numeric := 0; v_desc numeric; v_outras numeric; v_total numeric; v_dsum numeric := 0; v_osum numeric := 0; v_di numeric; v_oi numeric;
  v_cnt int; v_i int := 0; v_psum numeric := 0; v_pf fiscal_perfis%rowtype; v_cpf text; v_item jsonb;
begin
  select * into n from nfce_notas where id = p_id; if not found then return jsonb_build_object('ok', false, 'motivo', 'Nota não encontrada.'); end if;
  select * into v from vendas where id = n.venda_id; if not found then return jsonb_build_object('ok', false, 'motivo', 'Venda não encontrada.'); end if;
  select * into e from fiscal_empresa where id;
  if not public._fiscal_empresa_ok() then return jsonb_build_object('ok', false, 'motivo', 'Dados fiscais da empresa incompletos (Integrações → Nota fiscal → Dados fiscais).'); end if;
  select string_agg(distinct coalesce(iv.descricao, '(item)'), ', ') into v_sem from itens_venda iv where iv.venda_id = v.id and iv.valor_total_item > 0 and public._perfil_fiscal_efetivo(iv.produto_id, iv.combo_id) is null;
  if v_sem is not null then return jsonb_build_object('ok', false, 'motivo', 'Item sem perfil fiscal: ' || left(v_sem, 150) || '. Defina o perfil e reemita.'); end if;
  -- item do iFood sem ligação com produto: não usa o perfil padrão (poderia sair com NCM/CFOP errado)
  select string_agg(distinct btrim(regexp_replace(regexp_replace(iv.descricao, '\s*\(obs:.*$', ''), '\s*\[SEM LIGAÇÃO\]', '')), ', ') into v_semlig
    from itens_venda iv where iv.venda_id = v.id and iv.valor_total_item > 0 and iv.descricao like '%[SEM LIGAÇÃO]%';
  if v_semlig is not null then return jsonb_build_object('ok', false, 'motivo', 'Item do iFood sem ligação com um produto: ' || left(v_semlig, 150) || '. Ligue o item (Integrações e contas → iFood) e reemita.'); end if;
  select coalesce(sum(valor_total_item), 0), count(*) into v_bruto, v_cnt from itens_venda where venda_id = v.id and valor_total_item > 0;
  if v_cnt = 0 or v_bruto <= 0 then return jsonb_build_object('ok', false, 'dispensar', true, 'motivo', 'Venda sem valor: não há nota a emitir.'); end if;
  v_desc := coalesce(v.valor_desconto, 0); v_outras := coalesce(v.taxa_entrega, 0) + coalesce(v.acrescimo_forma, 0);
  v_total := round(v_bruto - v_desc + v_outras, 2);
  for r in select iv.id, iv.produto_id, iv.combo_id, iv.descricao, iv.quantidade, iv.valor_total_item vt from itens_venda iv where iv.venda_id = v.id and iv.valor_total_item > 0 order by iv.id loop
    v_i := v_i + 1;
    if v_i = v_cnt then v_di := round(v_desc - v_dsum, 2); v_oi := round(v_outras - v_osum, 2);
    else v_di := round(v_desc * r.vt / v_bruto, 2); v_oi := round(v_outras * r.vt / v_bruto, 2); end if;
    v_dsum := v_dsum + v_di; v_osum := v_osum + v_oi;
    select * into v_pf from fiscal_perfis where id = public._perfil_fiscal_efetivo(r.produto_id, r.combo_id);
    v_item := jsonb_build_object('numero_item', v_i, 'codigo_produto', coalesce(r.produto_id, r.combo_id)::text,
      -- descrição fiscal sem a observação do cliente e sem marcas internas
      'descricao', left(coalesce(nullif(btrim(regexp_replace(regexp_replace(coalesce(r.descricao, ''), '\s*\(obs:.*$', ''), '\s*\[SEM LIGAÇÃO\]', '')), ''), 'Item'), 120),
      'codigo_ncm', v_pf.ncm, 'cfop', v_pf.cfop, 'unidade_comercial', v_pf.unidade, 'quantidade_comercial', r.quantidade, 'valor_unitario_comercial', round(r.vt / nullif(r.quantidade, 0), 6),
      'unidade_tributavel', v_pf.unidade, 'quantidade_tributavel', r.quantidade, 'valor_unitario_tributavel', round(r.vt / nullif(r.quantidade, 0), 6), 'valor_bruto', round(r.vt, 2),
      'icms_origem', v_pf.origem::int, 'icms_situacao_tributaria', coalesce(v_pf.csosn, v_pf.cst_icms), 'pis_situacao_tributaria', v_pf.pis_cst, 'cofins_situacao_tributaria', v_pf.cofins_cst, 'inclui_no_total', 1);
    if v_pf.cest is not null then v_item := v_item || jsonb_build_object('cest', v_pf.cest); end if;
    if v_di > 0 then v_item := v_item || jsonb_build_object('valor_desconto', v_di); end if;
    if v_oi > 0 then v_item := v_item || jsonb_build_object('valor_outras_despesas', v_oi); end if;
    v_itens := v_itens || v_item;
  end loop;
  for r in select forma_pagamento, valor from pagamentos_venda where venda_id = v.id and valor > 0 order by valor desc loop
    v_pags := v_pags || jsonb_build_object('forma_pagamento', public._nfce_forma_codigo(r.forma_pagamento), 'valor_pagamento', round(r.valor, 2), 'descricao_pagamento', public._nfce_forma_desc(r.forma_pagamento));
    v_psum := v_psum + round(r.valor, 2);
  end loop;
  if jsonb_array_length(v_pags) = 0 then
    v_pags := jsonb_build_array(jsonb_build_object('forma_pagamento', public._nfce_forma_codigo(v.forma_pagamento), 'valor_pagamento', v_total, 'descricao_pagamento', public._nfce_forma_desc(v.forma_pagamento)));
  elsif v_psum <> v_total then
    v_pags := jsonb_set(v_pags, '{0,valor_pagamento}', to_jsonb(round((v_pags->0->>'valor_pagamento')::numeric + (v_total - v_psum), 2)));
  end if;
  v_cpf := coalesce(n.cpf, v.cpf_nota);
  return jsonb_build_object('ok', true, 'valor', v_total, 'payload', jsonb_strip_nulls(jsonb_build_object(
    'natureza_operacao', 'VENDA AO CONSUMIDOR', 'cnpj_emitente', e.cnpj, 'presenca_comprador', case when v.tipo::text = 'Entrega' then 4 else 1 end,
    'modalidade_frete', 9, 'local_destino', 1, 'consumidor_final', 1, 'cpf_destinatario', v_cpf, 'itens', v_itens, 'formas_pagamento', v_pags)));
end $function$;

-- ---------- 2. LGPD: ifood_limpar também apaga o CPF ----------
create or replace function public.ifood_limpar() returns void
language plpgsql security definer set search_path to 'public' as $function$
declare v_dias int := coalesce((select (config->>'retencaoClientesDias')::int from integracoes_config where provedor = 'ifood'), 90);
begin
  delete from ifood_eventos where recebido_em < now() - interval '30 days';
  delete from ifood_acoes where criado_em < now() - interval '60 days' and estado in ('ok', 'pulada');
  update ifood_pedidos set bruto = jsonb_set(coalesce(bruto, '{}'::jsonb) - 'customer' - 'delivery', '{apagado}', 'true'::jsonb) where criado_em < now() - make_interval(days => v_dias) and coalesce((bruto->>'apagado'), '') <> 'true';
  -- a nota autorizada já guarda o CPF no XML; aqui sai só a cópia da venda
  update vendas set telefone_cliente = null, endereco = '', complemento = '', referencia = '', cliente_nome = 'Cliente iFood', cpf_nota = null
   where canal = 'iFood' and data_hora < now() - make_interval(days => v_dias) and (telefone_cliente is not null or endereco <> '' or cliente_nome <> 'Cliente iFood' or cpf_nota is not null);
end $function$;

-- ---------- 1. ifood_criar_pedido grava o CPF (só se válido) ----------
do $mig$
declare d text;
begin
  d := pg_get_functiondef('public.ifood_criar_pedido(jsonb,boolean)'::regprocedure);
  if d like '%v_cpf%' then raise notice 'ifood_criar_pedido já tem v_cpf'; return; end if;
  d := replace(d, 'v_stpag status_pagamento; ad jsonb;', 'v_stpag status_pagamento; ad jsonb; v_cpf text;');
  d := replace(d, '  v_val := public._ifood_valores(p_order);',
    E'  v_cpf := regexp_replace(coalesce(p_order->''customer''->>''documentNumber'', ''''), ''[^0-9]'', '''', ''g'');\n  if not public._cpf_valido(v_cpf) then v_cpf := null; end if;\n  v_val := public._ifood_valores(p_order);');
  d := replace(d, 'status_pagamento, recebido_em, valor_original,', 'status_pagamento, cpf_nota, recebido_em, valor_original,');
  d := replace(d, 'v_stpag, case when v_stpag = ''Pago'' then now() end,', 'v_stpag, v_cpf, case when v_stpag = ''Pago'' then now() end,');
  if d not like '%v_cpf, case when v_stpag%' or d not like '%v_cpf := regexp_replace%' or d not like '%ad jsonb; v_cpf text;%' or d not like '%status_pagamento, cpf_nota, recebido_em%' then
    raise exception 'ifood_criar_pedido: texto inesperado, nada foi alterado'; end if;
  execute d;
end $mig$;

-- ---------- 5. reembolso feito no painel do Mercado Pago ----------
do $mig$
declare d text;
begin
  d := pg_get_functiondef('public.mp_aplicar_status(jsonb)'::regprocedure);
  if d like '%painel do Mercado Pago%' then raise notice 'mp_aplicar_status já alterada'; return; end if;
  d := replace(d, 'v_oid text := nullif(btrim(coalesce(p->>''mpOrderId'', '''')), '''');',
                  'v_oid text := nullif(btrim(coalesce(p->>''mpOrderId'', '''')), ''''); v_vst text; v_n int; v_antes numeric;');
  d := replace(d, E'      v_vr := round(least(g.valor,', E'      v_antes := coalesce(g.valor_reembolsado, 0);\n      v_vr := round(least(g.valor,');
  d := replace(d, E'      perform _auditar(''Reembolso Mercado Pago''',
E'      -- devolução feita fora do sistema (painel do Mercado Pago) numa venda que NÃO foi cancelada: o dinheiro já saiu\n      if g.venda_id is not null and coalesce(g.decisao, '''') <> ''reembolsar'' then\n        select status::text into v_vst from vendas where id = g.venda_id;\n        if v_vst is not null and v_vst <> ''Cancelada'' then\n          if v_vr >= g.valor then\n            insert into reembolsos (venda_id, valor, forma_pagamento, motivo, status, devolvido_em, observacao)\n            values (g.venda_id, v_vr, ''Mercado Pago'', ''Reembolso feito no painel do Mercado Pago'', ''Devolvido'', now(), ''Devolvido direto no painel do Mercado Pago; a venda continua ativa: decida se cancela.'')\n            on conflict (venda_id) do nothing;\n            get diagnostics v_n = row_count;\n            if v_n > 0 then perform _push_enviar(''reembolso'', ''Reembolso feito no Mercado Pago'', ''R$ '' || _dinheiro(v_vr) || '' devolvido direto no painel do Mercado Pago. A venda continua ativa: veja se cancela.'', ''mp-reembolso-'' || g.venda_id::text); end if;\n          elsif v_vr > v_antes + 0.009 then\n            perform _push_enviar(''reembolso'', ''Reembolso parcial no Mercado Pago'', ''R$ '' || _dinheiro(v_vr) || '' de R$ '' || _dinheiro(g.valor) || '' devolvido direto no painel do Mercado Pago.'', ''mp-reembolso-'' || g.venda_id::text);\n          end if;\n        end if;\n      end if;\n      perform _auditar(''Reembolso Mercado Pago''');
  if d not like '%painel do Mercado Pago%' or d not like '%v_antes := coalesce%' or d not like '%v_vst text; v_n int; v_antes numeric;%' then
    raise exception 'mp_aplicar_status: texto inesperado, nada foi alterado'; end if;
  execute d;
end $mig$;
