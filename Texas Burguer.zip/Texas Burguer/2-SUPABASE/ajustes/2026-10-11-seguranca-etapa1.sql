-- Segurança (Etapa 1 do plano 10/10) · 2026-10-11 · seguro para rodar de novo
-- 1) Funções auxiliares com caminho de busca fixo (alerta "function_search_path_mutable" do Supabase)
alter function public._ifood_n(jsonb) set search_path = public;
alter function public._ifood_norm(text) set search_path = public;
alter function public._integ_checklist_def(text) set search_path = public;
alter function public._norm_cidade(text) set search_path = public;
alter function public._cnpj_valido(text) set search_path = public;
alter function public._cpf_valido(text) set search_path = public;
alter function public._nfce_canal_da_venda(text,text,text) set search_path = public;
alter function public._nfce_forma_codigo(text) set search_path = public;
-- 2) Função administrativa não precisa ser chamável por visitante (ela já negava quem não é Admin)
revoke execute on function public.api_editar_premio_produto(jsonb) from anon;
