-- Feedback ligado à conta do cliente + resposta do restaurante · 2026-10-12
-- Pode rodar mais de uma vez.
alter table public.feedbacks add column if not exists user_id uuid references auth.users(id) on delete set null;
alter table public.feedbacks add column if not exists resposta text;
alter table public.feedbacks add column if not exists respondido_em timestamptz;
alter table public.feedbacks add column if not exists respondido_por text;
create index if not exists feedbacks_user_idx on public.feedbacks (user_id);

-- Feedback: quem está com a conta ligada fica registrado (e o pedido tem de ser dele). Um feedback por pedido e por conta.
CREATE OR REPLACE FUNCTION public.api_add_feedback(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_nota numeric := _num(p->>'nota'); v_dig text := _so_digitos(p->>'telefone'); v_ip text := _ip_cliente(); v_chave text;
        v_venda uuid := _uuid(p->>'vendaId'); v_cli uuid; v_cod text := lower(btrim(coalesce(p->>'codigo','')));
        v_origem text := case when p->>'origem' in ('aviso', 'chat') then p->>'origem' else 'formulario' end;
        c contas_cliente; v_user uuid;
begin
  if v_nota < 1 or v_nota > 5 or v_nota <> floor(v_nota) then return _falha('A nota deve ser de 1 a 5.'); end if;
  if auth.uid() is not null then select * into c from contas_cliente where user_id = auth.uid(); v_user := c.user_id; end if;
  if v_dig = '' and v_user is not null then v_dig := coalesce(_so_digitos(c.telefone), ''); end if;
  if v_dig <> '' and (length(v_dig) < 10 or length(v_dig) > 13) then return _falha('Telefone inválido.'); end if;
  v_chave := 'feedback_' || coalesce(nullif(v_dig, ''), nullif(left(v_user::text, 8), ''), 'anon');
  if _excedeu(v_chave, 5) or _excedeu('feedback_ip_' || v_ip, 10) or _excedeu('feedback_global', 120) then
    return _falha('Muitos feedbacks em sequência. Aguarde alguns minutos.');
  end if;
  if v_venda is null and v_cod ~ '^[0-9a-f]{8}$' then
    select id into v_venda from vendas where right(id::text, 8) = v_cod and data_hora > now() - interval '3 days' order by data_hora desc limit 1;
  end if;
  if v_venda is not null and not exists (select 1 from vendas where id = v_venda) then v_venda := null; end if;
  if v_user is not null and v_venda is not null then
    -- com conta, o pedido precisa ser da conta (mesma regra da lista "Pedidos" de Minha conta)
    if not exists (select 1 from vendas v where v.id = v_venda and (v.id in (select venda_id from contas_pedidos where user_id = v_user)
         or (c.cliente_id is not null and (v.cliente_id = c.cliente_id or (c.telefone <> '' and _so_digitos(v.telefone_cliente) = c.telefone))))) then
      v_venda := null;
    elsif exists (select 1 from feedbacks where venda_id = v_venda and user_id = v_user) then
      return _falha('Você já deu o feedback deste pedido. Obrigado!');
    end if;
  end if;
  if v_dig <> '' then select id into v_cli from clientes where _so_digitos(telefone) = v_dig limit 1; end if;
  if v_cli is null and v_user is not null then v_cli := c.cliente_id; end if;
  insert into feedbacks (venda_id, cliente_id, telefone_cliente, nota, comentario, status, origem, user_id)
  values (v_venda, v_cli, v_dig, v_nota::int, _texto_publico(p->>'comentario', 500), 'Novo', v_origem, v_user);
  perform _registrar_falha(v_chave, 600); perform _registrar_falha('feedback_ip_' || v_ip, 600); perform _registrar_falha('feedback_global', 600);
  perform _auditar_publico('Feedback recebido', 'Nota ' || v_nota::int || case v_origem when 'chat' then ' (pelo chat)' when 'aviso' then ' (pelo aviso)' else '' end || case when v_user is not null then ' (com conta)' else '' end, v_dig);
  return jsonb_build_object('ok', true, 'message', 'Obrigado pelo feedback!');
end $function$;
revoke all on function public.api_add_feedback(p jsonb) from public, anon, authenticated;
grant execute on function public.api_add_feedback(p jsonb) to anon, authenticated;

-- Equipe responde ao feedback. O cliente com conta vê a resposta em Minha conta › Pedidos.
CREATE OR REPLACE FUNCTION public.api_responder_feedback(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id'); v_txt text := left(btrim(coalesce(p->>'resposta', '')), 1000); v_nome text; v_user uuid;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if v_txt = '' then return _falha('Escreva a resposta.'); end if;
  select nome into v_nome from usuarios where id = auth.uid();
  update feedbacks set resposta = v_txt, respondido_em = now(), respondido_por = coalesce(v_nome, ''), status = 'Respondido'
   where id = v_id returning user_id into v_user;
  if not found then return _falha('Feedback não encontrado.'); end if;
  perform _auditar('Feedback respondido', 'Resposta enviada' || case when v_user is null then ' (cliente sem conta)' else '' end);
  return jsonb_build_object('ok', true, 'comConta', v_user is not null);
end $function$;
revoke all on function public.api_responder_feedback(p jsonb) from public, anon, authenticated;
grant execute on function public.api_responder_feedback(p jsonb) to authenticated;

-- Minha conta › Pedidos: cada pedido traz o feedback do cliente (se houver) e a resposta
CREATE OR REPLACE FUNCTION public.api_conta_pedidos()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente := _conta_exigir(); r jsonb;
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  select coalesce(jsonb_agg(x order by (x->>'data') desc), '[]'::jsonb) into r from (
    select jsonb_build_object('id', v.id, 'numero', v.numero_pedido, 'data', v.data_hora, 'status', case when v.status = 'Cancelada' then 'Cancelado' else v.status_pedido::text end,
        'tipo', v.tipo::text, 'total', v.valor_total, 'desconto', v.valor_desconto, 'forma', v.forma_pagamento,
        'itens', coalesce((select jsonb_agg(jsonb_build_object('produtoId', i.produto_id, 'comboId', i.combo_id, 'descricao', i.descricao, 'quantidade', i.quantidade, 'adicionaisIds', to_jsonb(i.adicionais_ids)))
                            from itens_venda i where i.venda_id = v.id), '[]'::jsonb),
        'feedback', (select jsonb_build_object('id', f.id, 'nota', f.nota, 'comentario', f.comentario, 'data', f.data, 'resposta', f.resposta, 'respondidoEm', f.respondido_em)
                       from feedbacks f where f.venda_id = v.id and f.user_id = c.user_id order by f.data desc limit 1)) as x
      from vendas v
     where v.origem::text = 'Cardápio' and v.mesa_id is null
       and (v.id in (select venda_id from contas_pedidos where user_id = c.user_id) or (c.cliente_id is not null and (v.cliente_id = c.cliente_id or (c.telefone <> '' and _so_digitos(v.telefone_cliente) = c.telefone))))
     order by v.data_hora desc limit 30) t;
  return jsonb_build_object('ok', true, 'pedidos', r);
end $function$;

-- "Baixar meus dados" passa a incluir os feedbacks e as respostas
CREATE OR REPLACE FUNCTION public.api_conta_exportar()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente := _conta_exigir(); cl clientes%rowtype;
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  if c.cliente_id is not null then select * into cl from clientes where id = c.cliente_id; end if;
  return jsonb_build_object('ok', true, 'geradoEm', now(),
    'conta', jsonb_build_object('email', c.email, 'nome', c.nome, 'telefone', c.telefone, 'nascimento', c.data_nascimento, 'criadaEm', c.criado_em, 'aceiteEm', c.aceite_em, 'aceiteVersao', c.aceite_versao, 'receberPromocoes', c.promo_ok, 'codigoIndicacao', c.codigo_indicacao),
    'cadastroNoRestaurante', case when cl.id is null then null else jsonb_build_object('nome', cl.nome, 'telefone', cl.telefone, 'primeiroContato', cl.primeiro_contato) end,
    'enderecos', coalesce((select jsonb_agg(jsonb_build_object('apelido', apelido, 'endereco', endereco, 'numero', numero, 'cidade', cidade, 'complemento', complemento, 'referencia', referencia)) from contas_enderecos where user_id = c.user_id), '[]'::jsonb),
    'pedidos', coalesce((select jsonb_agg(jsonb_build_object('numero', v.numero_pedido, 'data', v.data_hora, 'status', v.status_pedido::text, 'cancelado', v.status = 'Cancelada', 'total', v.valor_total, 'forma', v.forma_pagamento, 'endereco', case when v.id in (select venda_id from contas_pedidos where user_id = c.user_id) then v.endereco end,
        'itens', (select coalesce(jsonb_agg(jsonb_build_object('descricao', i.descricao, 'quantidade', i.quantidade, 'valor', i.valor_total_item)), '[]'::jsonb) from itens_venda i where i.venda_id = v.id)) order by v.data_hora)
        from vendas v where v.id in (select venda_id from contas_pedidos where user_id = c.user_id) or (c.cliente_id is not null and (v.cliente_id = c.cliente_id or (c.telefone <> '' and _so_digitos(v.telefone_cliente) = c.telefone)))), '[]'::jsonb),
    'cupons', coalesce((select jsonb_agg(jsonb_build_object('codigo', k.codigo, 'recebidoEm', g.criado_em, 'validoAte', g.valido_ate, 'usadoEm', g.usado_em)) from cupons_concedidos g join cupons k on k.id = g.cupom_id where g.user_id = c.user_id), '[]'::jsonb),
    'feedbacks', coalesce((select jsonb_agg(jsonb_build_object('data', f.data, 'nota', f.nota, 'comentario', f.comentario, 'resposta', f.resposta, 'respondidoEm', f.respondido_em) order by f.data) from feedbacks f where f.user_id = c.user_id), '[]'::jsonb),
    'fidelidade', (select jsonb_build_object('carimbos', f.carimbos, 'premiosResgatados', f.premios_resgatados) from fidelidade f where f.cliente_id = c.cliente_id));
end $function$;
