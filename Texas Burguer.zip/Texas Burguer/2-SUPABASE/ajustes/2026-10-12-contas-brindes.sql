-- Brindes da conta (cartão fidelidade e indicação dentro do pedido, R$ 0 com custo e baixa no estoque) + correção do estoque para cliente com conta · 2026-10-12 · JÁ APLICADO · pode rodar de novo
-- O produto marcado como prêmio de indicação passa a ser o brinde de quem indica (o cupom 'INDICADOR' não é mais entregue).

-- Correção: pedido de cliente com conta falhava ao baixar estoque de produto com receita (usuário do cliente não existe na tabela de usuários da equipe).
CREATE OR REPLACE FUNCTION public._ajustar_estoque(p_itens jsonb, p_dir integer, p_venda uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r record; e estoque%rowtype; v_delta numeric; v_novo numeric;
        v_ref text := case when p_venda is not null then 'Venda #' || left(p_venda::text, 8) else case when p_dir > 0 then 'Venda' else 'Estorno de venda' end end;
        v_uid uuid := (select u.id from usuarios u where u.id = auth.uid());  -- cliente com conta não é da equipe: a movimentação fica sem usuário
begin
  for r in select * from _consumo(p_itens) order by ingrediente_id loop
    select * into e from estoque where id = r.ingrediente_id for update;
    if not found then continue; end if;
    v_delta := p_dir * r.qtd;
    v_novo := round(e.quantidade - v_delta, 3);
    update estoque set quantidade = v_novo where id = e.id;
    if p_dir > 0 and v_novo < 0 then perform _auditar('Estoque negativo', e.ingrediente || ': ' || v_novo || ' (' || v_ref || ')'); end if;
    if v_delta <> 0 then
      insert into movimentacoes_estoque (ingrediente_id, tipo, quantidade, qtd_antes, qtd_depois, motivo_referencia, usuario_id)
      values (e.id, (case when p_dir > 0 then 'Venda' else 'Saída' end)::tipo_mov_estoque, -v_delta, e.quantidade, v_novo, v_ref, v_uid);
    end if;
  end loop;
end $function$
;

create table if not exists public.contas_beneficios (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.contas_cliente(user_id) on delete cascade,
  tipo       text not null check (tipo in ('Fidelidade', 'Indicação')),
  ref        text not null default '',
  status     text not null default 'Disponível' check (status in ('Disponível', 'Usado', 'Anulado')),
  produto_id uuid references public.produtos(id) on delete set null,
  venda_id   uuid references public.vendas(id) on delete set null,
  criado_em  timestamptz not null default now(),
  usado_em   timestamptz
);
alter table public.contas_beneficios enable row level security;
revoke all on public.contas_beneficios from anon, authenticated;
create index if not exists contas_beneficios_user_idx on public.contas_beneficios (user_id, tipo, status);
create index if not exists contas_beneficios_venda_idx on public.contas_beneficios (venda_id) where venda_id is not null;
create unique index if not exists contas_beneficios_ind_uq on public.contas_beneficios (user_id, tipo, ref) where tipo = 'Indicação';

CREATE OR REPLACE FUNCTION public._criar_pedido_publico(p jsonb, p_mesa_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_eh_mesa boolean := p_mesa_id is not null; v_mesa mesas%rowtype;
  v_nome text := _texto_publico(p->>'clienteNome', 80);
  v_tel text := case when p_mesa_id is not null then '' else _texto_publico(p->>'clienteTelefone', 20) end;
  v_dig text := case when p_mesa_id is not null then '' else _so_digitos(p->>'clienteTelefone') end;
  v_obs_troco text := _texto_publico(p->>'observacaoTroco', 200);
  v_de jsonb := case when jsonb_typeof(p->'dadosEntrega') = 'object' then p->'dadosEntrega' else '{}'::jsonb end;
  v_end text := _texto_publico(v_de->>'endereco', 200); v_comp text := _texto_publico(v_de->>'complemento', 100); v_ref text := _texto_publico(v_de->>'referencia', 150);
  v_obs_ent text := _texto_publico(coalesce(nullif(p->>'observacoes', ''), v_de->>'observacoes'), 300);
  v_itens jsonb := p->'itens'; v_tipo_in text := p->>'tipoEntrega'; v_ip text := _ip_cliente();
  v_req text := nullif(left(btrim(coalesce(p->>'requisicaoId', '')), 80), '');
  v_forma formas_pagamento%rowtype; v_caixa uuid; v_tipo venda_tipo; v_ja record; v_prod produtos%rowtype; v_comb combos%rowtype;
  it record; r record; v_prod_id uuid; v_comb_id uuid; v_qtd numeric; v_preco numeric; v_custo_u numeric; v_nome_item text; v_extra numeric; v_n_ad int; v_n_ok int;
  v_ads text; v_obs_item text; v_ads_ids jsonb; v_itens_ok jsonb := '[]'::jsonb; v_orig numeric := 0; v_custo numeric := 0;
  v_cod text := ''; v_cup jsonb; v_desc numeric := 0; v_frete boolean := false; v_taxa numeric := 0; v_pad numeric; v_total numeric;
  v_venda uuid := gen_random_uuid(); v_numero int; v_cli uuid; v_chave text; v_obs_final text; v_bloqueia boolean; v_forma_nome text; v_acr numeric := 0; v_bloq text; v_user uuid := (select cc.user_id from contas_cliente cc where cc.user_id = auth.uid() and cc.aceite_versao > 0);
  v_ben jsonb := case when jsonb_typeof(p->'beneficios') = 'array' then p->'beneficios' else '[]'::jsonb end;
  b record; v_bens jsonb := '[]'::jsonb; v_bc contas_cliente; v_fid fidelidade%rowtype; v_bid uuid; v_pb produtos%rowtype; v_btipo text;
begin
  -- repetição do mesmo envio (duplo toque, nova tentativa): devolve o pedido já criado, sem criar outro
  if v_req is not null then
    perform pg_advisory_xact_lock(hashtext('venda:' || v_req));
    select id, numero_pedido, valor_total into v_ja from vendas where requisicao_id = v_req;
    if found then
      return jsonb_build_object('ok', true, 'duplicado', true, 'id', v_ja.id, 'numero', v_ja.numero_pedido, 'valorTotal', v_ja.valor_total, 'message', 'Pedido já recebido — envio repetido ignorado.');
    end if;
  end if;

  if jsonb_typeof(v_itens) <> 'array' then return _falha('Carrinho vazio.'); end if;
  if jsonb_array_length(v_itens) = 0 and (p_mesa_id is not null or jsonb_array_length(v_ben) = 0) then return _falha('Carrinho vazio.'); end if;
  if jsonb_array_length(v_itens) > 40 then return _falha('Carrinho grande demais.'); end if;
  if v_eh_mesa then
    if v_nome = '' then return _falha('Informe o seu nome.'); end if;
    v_chave := 'pedmesa_' || p_mesa_id::text;
  else
    if v_nome = '' or v_dig = '' then return _falha('Informe nome e telefone.'); end if;
    if length(v_dig) < 10 or length(v_dig) > 13 then return _falha('Informe um telefone válido com DDD.'); end if;
    v_chave := 'pedcard_' || v_dig;
  end if;
  if _excedeu('pedcard_global', 150) then return _falha('Estamos com muitos pedidos no momento. Tente novamente em alguns minutos ou ligue para o restaurante.'); end if;
  if _excedeu('pedcard_ip_' || v_ip, 40) then return _falha('Muitos pedidos em sequência deste local. Aguarde alguns minutos.'); end if;
  if _excedeu(v_chave, case when v_eh_mesa then 8 else 5 end) then
    return _falha(case when v_eh_mesa then 'Muitos pedidos em sequência nesta mesa. Chame o garçom.' else 'Muitos pedidos em sequência. Aguarde alguns minutos.' end);
  end if;

  -- cardápio fechado à mão ou em período programado (pedido de mesa, feito dentro do restaurante, não é bloqueado)
  if not v_eh_mesa then
    v_bloq := _cardapio_bloqueio();
    if v_bloq is not null then return _falha(v_bloq); end if;
  end if;
  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;
  if v_caixa is null then return _falha('Estamos fechados no momento. Tente novamente mais tarde.'); end if;

  if v_eh_mesa then
    select * into v_mesa from mesas where id = p_mesa_id for update;
    if not found then return _falha('Mesa não encontrada.'); end if;
    if v_mesa.status::text not in ('Livre', 'Ocupada') then
      return _falha(case when v_mesa.status::text = 'Aguardando fechamento' then 'A conta desta mesa já foi pedida. Chame o garçom para novos pedidos.' else 'Esta mesa não está disponível para pedidos pelo celular. Chame o garçom.' end);
    end if;
    v_tipo := 'Mesa';
    -- mesa: o cliente não escolhe a forma; vale a primeira forma do cardápio só para o preço (o recebimento é feito no fechamento da conta)
    select * into v_forma from formas_pagamento where ativa and visivel_cardapio order by ordem limit 1;
    v_forma_nome := 'A Receber (Mesa)';
  else
    v_tipo := (case when v_tipo_in = 'Entrega' then 'Entrega' else 'Retirada' end)::venda_tipo;
    if v_tipo = 'Entrega' and v_end = '' then return _falha('Informe o endereço de entrega.'); end if;
    if v_tipo = 'Entrega' then
      declare v_num text := _texto_publico(v_de->>'numero', 20); v_cid text := _texto_publico(v_de->>'cidade', 80);
              v_cid_loc text := _texto_publico(v_de->>'cidadeLocalizacao', 80); v_lista jsonb; v_nomes text;
      begin
        if v_de ? 'numero' and v_num = '' then return _falha('Informe o número da casa (ou "s/n").'); end if;
        if v_de ? 'cidade' and v_cid = '' then return _falha('Informe a cidade da entrega.'); end if;
        if v_num <> '' then v_end := left(v_end || ', nº ' || v_num, 200); end if;
        if v_cid <> '' then v_end := left(v_end || ' — ' || v_cid, 200); end if;
      end;
    end if;
    select * into v_forma from formas_pagamento where id = _uuid(p->>'formaPagamentoId') and ativa and visivel_cardapio;
    v_forma_nome := v_forma.nome;
  end if;
  if v_forma.id is null then return _falha('Forma de pagamento inválida.'); end if;

  -- itens: tudo vem do cadastro (produto/combo ativo, preço da forma escolhida, adicionais ativos e vinculados)
  for it in select value as e from jsonb_array_elements(v_itens) loop
    v_qtd := _num(it.e->>'quantidade');
    if v_qtd <= 0 then continue; end if;
    if v_qtd > 50 or v_qtd <> floor(v_qtd) then return _falha('Quantidade inválida no carrinho.'); end if;
    v_prod_id := _uuid(it.e->>'produtoId'); v_comb_id := _uuid(it.e->>'comboId');
    if (v_prod_id is null) = (v_comb_id is null) then return _falha('Item inválido no carrinho.'); end if;
    if jsonb_typeof(it.e->'adicionaisIds') = 'array' and jsonb_array_length(it.e->'adicionaisIds') > 20 then return _falha('Adicionais demais em um item.'); end if;
    if v_prod_id is not null then
      select * into v_prod from produtos where id = v_prod_id and ativo;
      if not found then return _falha('Um dos produtos não está mais disponível.'); end if;
      v_nome_item := v_prod.nome;
      select preco, custo into v_preco, v_custo_u from produto_precos where produto_id = v_prod_id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_nome_item || '" não tem preço configurado para essa forma de pagamento.'); end if;
    else
      select * into v_comb from combos where id = v_comb_id and ativo;
      if not found then return _falha('Um dos combos não está mais disponível.'); end if;
      if exists (select 1 from combo_itens ci join produtos pr on pr.id = ci.produto_id where ci.combo_id = v_comb_id and not pr.ativo) then
        return _falha('O combo "' || v_comb.nome || '" está temporariamente indisponível.');
      end if;
      v_nome_item := v_comb.nome;
      select preco, custo into v_preco, v_custo_u from combo_precos where combo_id = v_comb_id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_nome_item || '" não tem preço configurado para essa forma de pagamento.'); end if;
    end if;
    select count(*), coalesce(sum(a.preco), 0),
           count(a.id) filter (where a.ativo and ((v_prod_id is not null and exists (select 1 from produto_adicionais pa where pa.produto_id = v_prod_id and pa.adicional_id = a.id)) or (v_comb_id is not null and exists (select 1 from combo_itens ci join produto_adicionais pa on pa.produto_id = ci.produto_id where ci.combo_id = v_comb_id and pa.adicional_id = a.id)))),
           coalesce(string_agg(' + ' || a.nome, '' order by s.ord) filter (where a.id is not null), ''),
           coalesce(jsonb_agg(a.id order by s.ord) filter (where a.id is not null), '[]'::jsonb)
      into v_n_ad, v_extra, v_n_ok, v_ads, v_ads_ids
      from jsonb_array_elements_text(case when jsonb_typeof(it.e->'adicionaisIds') = 'array' then it.e->'adicionaisIds' else '[]'::jsonb end) with ordinality as s(x, ord)
      left join adicionais a on a.id = _uuid(s.x);
    if v_n_ad <> v_n_ok then return _falha('Um adicional escolhido para "' || v_nome_item || '" não está disponível.'); end if;
    v_obs_item := _texto_publico(it.e->>'observacao', 100);
    v_itens_ok := v_itens_ok || jsonb_build_array(jsonb_build_object('produtoId', v_prod_id, 'comboId', v_comb_id,
      'descricao', v_nome_item || v_ads || case when v_obs_item <> '' then ' — Obs: ' || v_obs_item else '' end,
      'quantidade', v_qtd, 'valorUnitario', v_preco + v_extra, 'custoUnitario', v_custo_u, 'adicionaisIds', v_ads_ids));
    v_orig := v_orig + round(v_qtd * (v_preco + v_extra), 2); v_custo := v_custo + v_qtd * v_custo_u;
  end loop;
  if jsonb_array_length(v_itens_ok) = 0 and jsonb_array_length(v_ben) = 0 then return _falha('Carrinho vazio.'); end if;
  -- brindes da conta (cartão fidelidade e indicação): entram como item de R$ 0, com custo e baixa no estoque
  if jsonb_array_length(v_ben) > 0 then
    if v_eh_mesa or v_user is null then return _falha('Entre com a sua conta para resgatar o brinde.'); end if;
    if jsonb_array_length(v_ben) > 5 then return _falha('Brindes demais no mesmo pedido.'); end if;
    select * into v_bc from contas_cliente where user_id = v_user for update;
    for b in select value as e from jsonb_array_elements(v_ben) loop
      v_btipo := b.e->>'tipo';
      select * into v_pb from produtos where id = _uuid(b.e->>'produtoId') and ativo;
      if not found then return _falha('O brinde escolhido não está mais disponível.'); end if;
      select custo into v_custo_u from produto_precos where produto_id = v_pb.id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_pb.nome || '" não está disponível para essa forma de pagamento.'); end if;
      v_bid := null;
      if v_btipo = 'Fidelidade' then
        if not v_pb.premio_fidelidade then return _falha('"' || v_pb.nome || '" não é um prêmio do cartão fidelidade.'); end if;
        if v_bc.cliente_id is null then return _falha('Seu cartão fidelidade ainda não está ligado à sua conta. Ele liga depois do seu primeiro pedido concluído.'); end if;
        if exists (select 1 from jsonb_array_elements(v_bens) x where x->>'tipo' = 'Fidelidade') then return _falha('Só dá para resgatar 1 prêmio do cartão fidelidade por pedido.'); end if;
        select * into v_fid from fidelidade where cliente_id = v_bc.cliente_id for update;
        if v_fid.id is null or v_fid.carimbos < 10 then return _falha('Seu cartão fidelidade ainda não completou as 10 marcas.'); end if;
      elsif v_btipo = 'Indicação' then
        if not v_pb.premio_indicacao then return _falha('"' || v_pb.nome || '" não é um prêmio de indicação.'); end if;
        select id into v_bid from contas_beneficios where id = _uuid(b.e->>'id') and user_id = v_user and tipo = 'Indicação' and status = 'Disponível' for update;
        if v_bid is null or exists (select 1 from jsonb_array_elements(v_bens) x where x->>'id' = v_bid::text) then return _falha('Este brinde de indicação não está mais disponível.'); end if;
      else
        return _falha('Brinde inválido.');
      end if;
      v_bens := v_bens || jsonb_build_array(jsonb_build_object('tipo', v_btipo, 'id', v_bid, 'produtoId', v_pb.id));
      v_itens_ok := v_itens_ok || jsonb_build_array(jsonb_build_object('produtoId', v_pb.id, 'comboId', null,
        'descricao', '🎁 Brinde ' || case when v_btipo = 'Fidelidade' then 'fidelidade' else 'indicação' end || ' — ' || v_pb.nome,
        'quantidade', 1, 'valorUnitario', 0, 'custoUnitario', v_custo_u, 'adicionaisIds', '[]'::jsonb));
      v_custo := v_custo + v_custo_u;
    end loop;
  end if;
  v_orig := round(v_orig, 2); v_custo := round(v_custo, 2);

  select coalesce((select (valor #>> '{}') = 'true' from sistema where chave = 'BLOQUEAR_ESTOQUE_NEGATIVO'), false) into v_bloqueia;
  if v_bloqueia then
    for r in select c.ingrediente_id, c.qtd, e.quantidade from _consumo(v_itens_ok) c join estoque e on e.id = c.ingrediente_id loop
      if r.quantidade + 0.000000001 < r.qtd then return _falha('Um dos itens do pedido acabou. Escolha outro item ou fale com o restaurante.'); end if;
    end loop;
  end if;

  -- cupom (só no cardápio comum; travado por código para dois pedidos simultâneos não estourarem o limite)
  if not v_eh_mesa then
    v_cod := upper(regexp_replace(btrim(coalesce(p->>'codigoCupom', '')), '\s+', '', 'g'));
    if v_cod <> '' then
      if v_orig <= 0 then return _falha('O cupom vale para pedidos com pelo menos um item pago.'); end if;
      perform pg_advisory_xact_lock(hashtext('cupom:' || v_cod));
      v_cup := _cupom_calcular(v_cod, v_tel, v_orig, v_tipo::text, v_user);
      if coalesce(v_cup->>'ok', '') <> 'true' then return v_cup; end if;
      v_desc := (v_cup->>'desconto')::numeric; v_frete := (v_cup->>'freteGratis')::boolean;
    end if;
  end if;

  if v_tipo = 'Entrega' and not v_frete then
    select coalesce(_num(valor #>> '{}'), 0) into v_pad from sistema where chave = 'TaxaEntregaPadrao';
    v_taxa := coalesce(v_pad, 0);
  end if;
  v_total := case when v_orig <= 0 and jsonb_array_length(v_bens) > 0 then round(v_taxa, 2) else greatest(0.01, round(v_orig - v_desc + v_taxa, 2)) end;
  -- acréscimo da forma de pagamento escolhida (mesa: o acréscimo entra no fechamento da conta)
  if not v_eh_mesa and v_orig > 0 then v_acr := _acrescimo_forma(v_forma, greatest(0.01, v_total - v_taxa)); v_total := round(v_total + v_acr, 2); end if;
  v_obs_final := coalesce(concat_ws(' — ', nullif(v_obs_ent, ''), nullif(v_obs_troco, '')), '');

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido,
                      endereco, complemento, referencia, observacoes_entrega, status_pagamento, valor_original, valor_desconto,
                      desconto_detalhe, origem, mesa_id, taxa_entrega, caixa_id, requisicao_id, acrescimo_forma)
  values (v_venda, v_nome, v_tel, v_forma_nome, v_total, v_custo, 'Confirmada', v_tipo, 'Recebido',
          case when v_tipo = 'Entrega' then v_end else '' end, case when v_tipo = 'Entrega' then v_comp else '' end, case when v_tipo = 'Entrega' then v_ref else '' end,
          v_obs_final, (case when v_total <= 0 then 'Pago' else 'A Receber' end)::status_pagamento, v_orig, v_desc, case when v_cod <> '' then 'Cupom ' || (v_cup->>'codigo') else '' end, 'Cardápio',
          case when v_eh_mesa then p_mesa_id else null end, v_taxa, v_caixa, v_req, v_acr)
  returning numero_pedido into v_numero;

  insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
  select v_venda, _uuid(e->>'produtoId'), _uuid(e->>'comboId'), e->>'descricao', _num(e->>'quantidade', 1)::int, _num(e->>'valorUnitario'), _num(e->>'custoUnitario'),
         round(_num(e->>'quantidade', 1) * _num(e->>'valorUnitario'), 2),
         coalesce((select array_agg(_uuid(x)) filter (where _uuid(x) is not null) from jsonb_array_elements_text(e->'adicionaisIds') x), '{}')
  from jsonb_array_elements(v_itens_ok) e;

  insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo)
  values (v_venda, v_forma_nome, v_total, case when v_eh_mesa or v_total <= 0 then 0 else round(v_total * v_forma.taxa_percentual / 100 + v_forma.taxa_fixa, 2) end, v_acr);
  if v_total <= 0 then update vendas set recebido_em = now() where id = v_venda; end if;

  if v_eh_mesa and v_mesa.status::text = 'Livre' then update mesas set status = 'Ocupada' where id = p_mesa_id; end if;
  perform _ajustar_estoque(v_itens_ok, 1, v_venda);
  if v_tel <> '' then v_cli := _upsert_cliente(v_tel, v_nome); end if;
  if v_user is not null and not v_eh_mesa then insert into contas_pedidos (venda_id, user_id) values (v_venda, v_user) on conflict do nothing; end if;
  if jsonb_array_length(v_bens) > 0 then
    for b in select value as e from jsonb_array_elements(v_bens) loop
      if b.e->>'tipo' = 'Fidelidade' then
        update fidelidade set carimbos = 0, premios_resgatados = premios_resgatados + 1, atualizada_em = now() where cliente_id = v_bc.cliente_id;
        insert into contas_beneficios (user_id, tipo, status, produto_id, venda_id, usado_em) values (v_user, 'Fidelidade', 'Usado', _uuid(b.e->>'produtoId'), v_venda, now());
      else
        update contas_beneficios set status = 'Usado', produto_id = _uuid(b.e->>'produtoId'), venda_id = v_venda, usado_em = now() where id = _uuid(b.e->>'id');
      end if;
    end loop;
  end if;
  if v_cod <> '' then
    insert into cupons_usos (cupom_id, codigo, venda_id, cliente_id, telefone, desconto, frete_gratis, requisicao_id, user_id)
    values ((v_cup->>'cupomId')::uuid, v_cup->>'codigo', v_venda, v_cli, v_tel, v_desc, v_frete, v_req, v_user);
    perform _conta_cupom_usado(v_user, (v_cup->>'cupomId')::uuid, v_venda);
  end if;
  perform _registrar_falha(v_chave, 600); perform _registrar_falha('pedcard_global', 300); perform _registrar_falha('pedcard_ip_' || v_ip, 600);
  perform _auditar_publico(case when v_eh_mesa then 'Pedido recebido pelo cliente na mesa ' || v_mesa.numero else 'Pedido recebido pelo Cardápio' end,
    'Total R$ ' || _dinheiro(v_total) || case when jsonb_array_length(v_bens) > 0 then ' | Brindes ' || jsonb_array_length(v_bens) else '' end || case when v_cod <> '' then ' | Cupom ' || (v_cup->>'codigo') else '' end, case when v_eh_mesa then v_nome else v_tel end);

  return jsonb_build_object('ok', true, 'message', 'Pedido enviado! Nº ' || v_numero || '. Total: R$ ' || _dinheiro(v_total) || '.',
    'id', v_venda, 'numero', v_numero, 'valorTotal', v_total, 'valorOriginal', v_orig, 'acrescimo', v_acr, 'valorDesconto', v_desc,
    'cupom', case when v_cod <> '' then v_cup->>'codigo' else '' end, 'freteGratis', v_frete);
end $function$
;

CREATE OR REPLACE FUNCTION public._conta_premiar_indicacao(p_user uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente; ind contas_cliente; v_mes int;
begin
  select * into c from contas_cliente where user_id = p_user;
  if c.user_id is null or c.indicado_por is null or c.indicacao_premiada then return; end if;
  select * into ind from contas_cliente where user_id = c.indicado_por;
  update contas_cliente set indicacao_premiada = true where user_id = p_user;
  if ind.user_id is null or ind.aceite_versao = 0 then return; end if;
  if ind.telefone <> '' and ind.telefone = c.telefone then return; end if;
  select count(*) into v_mes from contas_beneficios where user_id = ind.user_id and tipo = 'Indicação' and criado_em > now() - interval '30 days';
  if v_mes >= 10 then return; end if;
  perform _conceder_cupom_auto('indicacao_indicado', p_user, p_user::text);
  insert into contas_beneficios (user_id, tipo, ref) values (ind.user_id, 'Indicação', p_user::text) on conflict do nothing;
end $function$
;

CREATE OR REPLACE FUNCTION public._trg_conta_cancelada()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare u uuid; bf record;
begin
  begin
    -- devolve o cupom recebido que foi usado neste pedido
    update cupons_concedidos set usado_em = null, venda_id = null where venda_id = new.id;
    update cupons_usos set user_id = null, telefone = '' where venda_id = new.id and cupom_id in (select id from cupons where automatico is not null);
    -- brindes usados neste pedido voltam: o de indicação fica disponível de novo e o cartão fidelidade reabre
    update contas_beneficios set status = 'Disponível', venda_id = null, usado_em = null, produto_id = null where venda_id = new.id and tipo = 'Indicação' and status = 'Usado';
    for bf in select b.id, cc.cliente_id from contas_beneficios b join contas_cliente cc on cc.user_id = b.user_id where b.venda_id = new.id and b.tipo = 'Fidelidade' and b.status = 'Usado' loop
      update fidelidade set carimbos = 10, premios_resgatados = greatest(0, premios_resgatados - 1), atualizada_em = now() where cliente_id = bf.cliente_id;
      update contas_beneficios set status = 'Anulado' where id = bf.id;
    end loop;
    -- indique e ganhe: se o pedido cancelado era o único concluído do indicado, o prêmio ainda não usado perde o efeito
    select user_id into u from contas_pedidos where venda_id = new.id;
    if u is not null and not exists (select 1 from contas_pedidos cp join vendas v on v.id = cp.venda_id
                                      where cp.user_id = u and v.id <> new.id and v.status = 'Confirmada' and v.status_pedido in ('Entregue', 'Retirada', 'Servida')) then
      update contas_beneficios set status = 'Anulado' where tipo = 'Indicação' and ref = u::text and status = 'Disponível';
      update cupons_concedidos set usado_em = now() where ref = u::text and origem in ('indicacao_indicador', 'indicacao_indicado') and usado_em is null and venda_id is null;
    end if;
  exception when others then null;
  end;
  return null;
end $function$
;

create or replace function public.api_conta_beneficios() returns jsonb
 language plpgsql stable security definer set search_path to 'public'
as $function$
declare c contas_cliente := _conta_exigir(); f fidelidade%rowtype;
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  if c.cliente_id is not null then select * into f from fidelidade where cliente_id = c.cliente_id; end if;
  return jsonb_build_object('ok', true, 'vinculada', c.cliente_id is not null, 'carimbos', coalesce(f.carimbos, 0), 'fidelidadeDisponivel', coalesce(f.carimbos, 0) >= 10,
    'indicacao', (select coalesce(jsonb_agg(jsonb_build_object('id', b.id, 'desde', b.criado_em) order by b.criado_em), '[]'::jsonb)
                    from contas_beneficios b where b.user_id = c.user_id and b.tipo = 'Indicação' and b.status = 'Disponível'),
    'produtosFid', (select coalesce(jsonb_agg(jsonb_build_object('id', p.id, 'nome', p.nome, 'descricao', left(coalesce(p.descricao, ''), 160), 'fotoUrl', coalesce(nullif(p.foto_url_principal, ''), p.foto_url_contingencia, '')) order by p.ordem_cardapio, p.nome), '[]'::jsonb)
                      from produtos p where p.ativo and p.premio_fidelidade),
    'produtosInd', (select coalesce(jsonb_agg(jsonb_build_object('id', p.id, 'nome', p.nome, 'descricao', left(coalesce(p.descricao, ''), 160), 'fotoUrl', coalesce(nullif(p.foto_url_principal, ''), p.foto_url_contingencia, '')) order by p.ordem_cardapio, p.nome), '[]'::jsonb)
                      from produtos p where p.ativo and p.premio_indicacao));
end $function$;
revoke all on function public.api_conta_beneficios() from public, anon;
grant execute on function public.api_conta_beneficios() to authenticated;
