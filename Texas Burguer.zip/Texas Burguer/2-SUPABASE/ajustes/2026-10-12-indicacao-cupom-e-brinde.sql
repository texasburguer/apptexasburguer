-- Indique e ganhe: quem indica pode ganhar o cupom automático "quem indicou" (se estiver ligado) E o brinde (se houver produto marcado como prêmio de indicação) · 2026-10-12
-- Cada um funciona sozinho: cupom ligado sem produto-prêmio = só cupom; produto-prêmio sem cupom ligado = só brinde; os dois = os dois.
CREATE OR REPLACE FUNCTION public._conta_premiar_indicacao(p_user uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente; ind contas_cliente; v_mes int;
begin
  select * into c from contas_cliente where user_id = p_user;
  if c.user_id is null or c.indicado_por is null or c.indicacao_premiada then return; end if;
  select * into ind from contas_cliente where user_id = c.indicado_por;
  update contas_cliente set indicacao_premiada = true where user_id = p_user;
  if ind.user_id is null or ind.aceite_versao = 0 then return; end if;
  if ind.telefone <> '' and ind.telefone = c.telefone then return; end if;
  select greatest(
           (select count(*) from contas_beneficios where user_id = ind.user_id and tipo = 'Indicação' and criado_em > now() - interval '30 days'),
           (select count(*) from cupons_concedidos where user_id = ind.user_id and origem = 'indicacao_indicador' and criado_em > now() - interval '30 days')) into v_mes;
  if v_mes >= 10 then return; end if;
  perform _conceder_cupom_auto('indicacao_indicado', p_user, p_user::text);
  perform _conceder_cupom_auto('indicacao_indicador', ind.user_id, p_user::text);
  if exists (select 1 from produtos where ativo and premio_indicacao) then
    insert into contas_beneficios (user_id, tipo, ref) values (ind.user_id, 'Indicação', p_user::text) on conflict do nothing;
  end if;
end $function$;
