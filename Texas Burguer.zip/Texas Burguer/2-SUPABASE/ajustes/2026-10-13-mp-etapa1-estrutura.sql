-- =====================================================================================
-- MERCADO PAGO · ETAPA 1 (estrutura do banco) · 2026-10-13 · NÃO APLICADO
-- Só ADICIONA. Nada existente é apagado e o cardápio continua igual: a integração nasce DESLIGADA.
-- Rode DEPOIS do SUBIR-TUDO-supabase.sql e dos ajustes de 11 e 12/10. Pode rodar de novo (idempotente).
-- Cole inteiro no SQL Editor do Supabase. Para conferir depois, rode testes/teste-mp-etapa1.sql.
-- =====================================================================================
begin;

-- ---------- 1) O Mercado Pago entra no molde das integrações (iFood e Nota fiscal) ----------
do $d$
declare c record;
begin
  for c in select conname from pg_constraint where conrelid = 'public.integracoes_config'::regclass and contype = 'c' and pg_get_constraintdef(oid) like '%provedor%' loop
    execute format('alter table public.integracoes_config drop constraint %I', c.conname);
  end loop;
  alter table public.integracoes_config add constraint integracoes_config_provedor_check
    check (provedor in ('ifood', 'nfce', 'mercadopago'));

  for c in select conname from pg_constraint where conrelid = 'public.integracoes_segredos'::regclass and contype = 'c' and pg_get_constraintdef(oid) like '%chave%' loop
    execute format('alter table public.integracoes_segredos drop constraint %I', c.conname);
  end loop;
  alter table public.integracoes_segredos add constraint integracoes_segredos_chave_check
    check (chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id', 'nfce_token_homologacao', 'nfce_token_producao', 'nfce_csc',
                     'mp_public_key_teste', 'mp_public_key_producao', 'mp_access_token_teste', 'mp_access_token_producao', 'mp_webhook_secret'));
end $d$;

-- modo 'homologacao' = Teste na tela. pixValidadeMin = validade do Pix na tela do cliente (minutos).
-- testeNoCardapio = só com true o cliente vê o pagamento online enquanto o modo for Teste (padrão: não).
insert into public.integracoes_config (provedor, modo, config) values
  ('mercadopago', 'homologacao', '{"pixValidadeMin": 15, "testeNoCardapio": false}'::jsonb)
on conflict (provedor) do nothing;

-- ---------- 2) Formas de pagamento: quais aceitam pagar online (a forma continua valendo na entrega) ----------
alter table public.formas_pagamento
  add column if not exists aceita_online boolean not null default false,
  add column if not exists tipo_online text;

do $d$
begin
  if not exists (select 1 from pg_constraint where conrelid = 'public.formas_pagamento'::regclass and conname = 'formas_pagamento_tipo_online_check') then
    alter table public.formas_pagamento add constraint formas_pagamento_tipo_online_check
      check (tipo_online is null or tipo_online in ('pix', 'credito'));
  end if;
  if not exists (select 1 from pg_constraint where conrelid = 'public.formas_pagamento'::regclass and conname = 'formas_pagamento_online_exige_tipo') then
    alter table public.formas_pagamento add constraint formas_pagamento_online_exige_tipo
      check (not aceita_online or tipo_online is not null);
  end if;
end $d$;

-- ---------- 3) Reserva do pedido (o pedido só vira venda depois do pagamento aprovado) ----------
create table if not exists public.pedidos_reserva (
  id uuid primary key default gen_random_uuid(),
  requisicao_id text unique,                                   -- id da tentativa enviado pela página: repetir não duplica
  user_id uuid not null,                                       -- conta do cliente (pagar online exige login)
  estado text not null default 'ativa' check (estado in ('ativa', 'confirmada', 'expirada', 'cancelada')),
  cliente_nome text not null default '',
  telefone text not null default '',
  tipo_entrega text not null default '',
  forma_pagamento_id uuid references public.formas_pagamento(id) on delete set null,
  dados_entrega jsonb,                                         -- endereço, número, cidade, complemento, referência (como a venda usa)
  observacoes text not null default '',
  itens jsonb not null,                                        -- itens JÁ validados no servidor (preço, custo, adicionais), no formato da venda
  beneficios jsonb not null default '[]'::jsonb,               -- brindes da conta incluídos no pedido
  cupom jsonb,                                                 -- resultado do cálculo do cupom (null = sem cupom)
  valor_original numeric(12,2) not null default 0,
  valor_desconto numeric(12,2) not null default 0,
  taxa_entrega numeric(12,2) not null default 0,
  acrescimo_forma numeric(12,2) not null default 0,
  valor_total numeric(12,2) not null check (valor_total > 0),
  custo_total numeric(12,2) not null default 0,
  estoque_reservado boolean not null default false,            -- true = a baixa de estoque está feita neste momento
  cupom_uso_id uuid,                                           -- linha reservada em cupons_usos (se houver cupom)
  brindes_reservados boolean not null default false,
  venda_id uuid references public.vendas(id) on delete set null,
  motivo_fim text not null default '',
  expira_em timestamptz not null,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
create index if not exists pedidos_reserva_ativas_idx on public.pedidos_reserva (expira_em) where estado = 'ativa';
create index if not exists pedidos_reserva_user_idx on public.pedidos_reserva (user_id, criado_em desc);
create index if not exists pedidos_reserva_venda_idx on public.pedidos_reserva (venda_id);
alter table public.pedidos_reserva enable row level security;   -- sem policy: só funções seguras e a chave de serviço

-- ---------- 4) Pagamentos online (um pedido no Mercado Pago por tentativa) ----------
create table if not exists public.pagamentos_online (
  id uuid primary key default gen_random_uuid(),
  reserva_id uuid not null references public.pedidos_reserva(id),
  venda_id uuid references public.vendas(id) on delete set null,
  user_id uuid,
  metodo text not null check (metodo in ('pix', 'credito')),
  mp_modo text not null check (mp_modo in ('homologacao', 'producao')),   -- modo em que o pagamento foi criado
  mp_order_id text unique,
  mp_payment_id text,
  status text not null default 'aguardando'
    check (status in ('aguardando', 'aprovado', 'recusado', 'expirado', 'cancelado', 'reembolso_parcial', 'reembolsado', 'erro')),
  status_detalhe text not null default '',
  valor numeric(12,2) not null check (valor > 0),
  valor_reembolsado numeric(12,2) not null default 0 check (valor_reembolsado >= 0),
  pix_copia_cola text,
  pix_qr_base64 text,
  pix_expira_em timestamptz,
  cartao_final text,                                            -- só os 4 últimos dígitos, se vierem
  cartao_bandeira text,
  aprovado_em timestamptz,
  decisao_pendente boolean not null default false,              -- "Pagamento a decidir": operador de caixa ou Admin escolhe
  decisao_motivo text not null default '',
  decisao text check (decisao is null or decisao in ('seguir', 'reembolsar')),
  decidido_por uuid,
  decidido_em timestamptz,
  erro text not null default '',
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
create index if not exists pagamentos_online_reserva_idx on public.pagamentos_online (reserva_id);
create index if not exists pagamentos_online_venda_idx on public.pagamentos_online (venda_id);
create index if not exists pagamentos_online_status_idx on public.pagamentos_online (status, criado_em desc);
create index if not exists pagamentos_online_decidir_idx on public.pagamentos_online (criado_em desc) where decisao_pendente and decisao is null;
create index if not exists pagamentos_online_mp_payment_idx on public.pagamentos_online (mp_payment_id);
alter table public.pagamentos_online enable row level security;

-- avisos (webhook) já recebidos: o mesmo aviso repetido não é processado duas vezes
create table if not exists public.pagamentos_online_eventos (
  id bigserial primary key,
  chave text not null unique,                                  -- identifica o aviso (definida na função mp-webhook)
  pagamento_id uuid references public.pagamentos_online(id) on delete cascade,
  tipo text not null default '',
  status_mp text not null default '',
  assinatura_ok boolean not null default false,
  detalhe jsonb,
  recebido_em timestamptz not null default now()
);
create index if not exists pagamentos_online_eventos_pag_idx on public.pagamentos_online_eventos (pagamento_id, recebido_em desc);
alter table public.pagamentos_online_eventos enable row level security;

-- as tabelas novas só são lidas/gravadas por funções seguras (security definer) e pela chave de serviço
revoke all on public.pedidos_reserva, public.pagamentos_online, public.pagamentos_online_eventos from anon, authenticated;
revoke all on sequence public.pagamentos_online_eventos_id_seq from anon, authenticated;

-- ---------- 5) Checklist do cartão Mercado Pago (mesmos itens da Prévia) ----------
-- Atenção: as duas funções abaixo partem das versões mais recentes (SUBIR-TUDO / f4) e só acrescentam o 'mercadopago'.
create or replace function public._integ_checklist_def(p_prov text) returns jsonb
 language sql immutable set search_path to 'public' as $f$
  select case p_prov
    when 'ifood' then '[
      {"id":"conta_dev","titulo":"O dono criou a conta de desenvolvedor no iFood (precisa do CNPJ)"},
      {"id":"acesso","titulo":"Acesso liberado aos módulos Pedidos, Catálogo, Loja, Financeiro e Avaliações"},
      {"id":"chaves","titulo":"Client ID, Client Secret e código da loja digitados aqui","auto":true},
      {"id":"teste_conexao","titulo":"Teste de conexão deu certo","auto":true},
      {"id":"homologacao","titulo":"Homologação do iFood aprovada"},
      {"id":"itens","titulo":"Itens do iFood ligados aos produtos (aba Itens do iFood)"},
      {"id":"equipe","titulo":"Equipe avisada de como o pedido do iFood aparece"}]'::jsonb
    when 'nfce' then '[
      {"id":"contador","titulo":"O contador definiu NCM, CFOP e situação tributária de cada perfil"},
      {"id":"certificado","titulo":"Certificado digital A1 do restaurante pronto"},
      {"id":"sefaz","titulo":"Credenciamento na Sefaz-SP feito e CSC (código de segurança) obtido"},
      {"id":"focus","titulo":"Conta na Focus NFe criada e empresa cadastrada lá (com o certificado)"},
      {"id":"token","titulo":"Token da Focus digitado aqui","auto":true},
      {"id":"empresa","titulo":"Dados fiscais da empresa preenchidos aqui","auto":true},
      {"id":"perfis","titulo":"Todos os produtos têm perfil fiscal","auto":true},
      {"id":"nota_teste","titulo":"Nota de teste (homologação) emitida e conferida pelo contador"}]'::jsonb
    when 'mercadopago' then '[
      {"id":"conta_vendedor","titulo":"Conta de vendedor criada no Mercado Pago (com a verificação de identidade)"},
      {"id":"chaves_teste","titulo":"Chaves de teste coladas","auto":true},
      {"id":"webhook","titulo":"Endereço do aviso (webhook) cadastrado no Mercado Pago","auto":true},
      {"id":"teste_guiado","titulo":"Teste guiado feito (Pix e cartão)","auto":true},
      {"id":"chaves_producao","titulo":"Chaves de produção coladas","auto":true}]'::jsonb
    else '[]'::jsonb end
$f$;

create or replace function public._integ_pendencias(p_prov text, p_modo text) returns text[]
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_out text[] := '{}'; v_item jsonb; v_ck jsonb; v_ok boolean;
begin
  select checklist into v_ck from integracoes_config where provedor = p_prov;
  for v_item in select * from jsonb_array_elements(_integ_checklist_def(p_prov)) loop
    if coalesce((v_item->>'auto')::boolean, false) then
      v_ok := case v_item->>'id'
        when 'chaves' then (select count(*) from integracoes_segredos where chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id')) = 3
        when 'token' then exists (select 1 from integracoes_segredos where chave = 'nfce_token_' || p_modo)
        when 'empresa' then public._fiscal_empresa_ok()
        when 'perfis' then public._fiscal_perfis_ok()
        when 'chaves_teste' then (select count(*) from integracoes_segredos where chave in ('mp_public_key_teste', 'mp_access_token_teste')) = 2
        when 'webhook' then exists (select 1 from integracoes_segredos where chave = 'mp_webhook_secret')
        when 'teste_guiado' then exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'pix' and status in ('aprovado', 'reembolso_parcial', 'reembolsado'))
                             and exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'credito' and status in ('aprovado', 'reembolso_parcial', 'reembolsado'))
        when 'chaves_producao' then (select count(*) from integracoes_segredos where chave in ('mp_public_key_producao', 'mp_access_token_producao')) = 2
        else coalesce((v_ck->>(v_item->>'id'))::boolean, false) end;
    else
      v_ok := coalesce((v_ck->>(v_item->>'id'))::boolean, false);
    end if;
    if not v_ok then v_out := v_out || (v_item->>'titulo'); end if;
  end loop;
  return v_out;
end $f$;

-- ---------- 6) Flags para a equipe: ganha 'mercadopago' (parte da versão mais recente, de imposto-e-ifood) ----------
create or replace function public.api_integracoes_flags(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public'
as $function$
declare v_adm boolean := tem_nivel('Admin');
begin
  if auth_nivel() is null then return _negado(); end if;
  return jsonb_build_object('ok', true, 'ifood', _integracao_ligada('ifood'), 'nfce', _integracao_ligada('nfce'),
    'mercadopago', _integracao_ligada('mercadopago'),
    'nfceModo', (select modo from integracoes_config where provedor = 'nfce'),
    'impostoPct', case when v_adm then _imposto_pct(current_date) else 0 end,
    'impostoPadrao', case when v_adm then coalesce((select aliquota_simples from fiscal_empresa where id), 0) else 0 end,
    'impostoMeses', case when v_adm then coalesce((select valor from sistema where chave = 'ImpostoAliquotasMes' and jsonb_typeof(valor) = 'object'), '{}'::jsonb) else '{}'::jsonb end);
end $function$;

-- ---------- 7) Leitura PÚBLICA para o cardápio (cliente sem login de equipe) ----------
-- Desligado, ou sem chave pública, ou sem forma online: devolve só {ligado:false}. Nunca devolve segredo (só a chave PÚBLICA).
-- Em modo Teste o cliente só vê o pagamento online se "testeNoCardapio" estiver true.
create or replace function public.api_mp_config_publica(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare c integracoes_config%rowtype; v_prod boolean; v_pk text; v_formas jsonb; v_min int;
begin
  select * into c from integracoes_config where provedor = 'mercadopago';
  if c.provedor is null or not c.ligado then return jsonb_build_object('ok', true, 'ligado', false); end if;
  v_prod := (c.modo = 'producao');
  if not v_prod and coalesce((c.config->>'testeNoCardapio')::boolean, false) is not true then return jsonb_build_object('ok', true, 'ligado', false); end if;
  select valor into v_pk from integracoes_segredos where chave = case when v_prod then 'mp_public_key_producao' else 'mp_public_key_teste' end;
  select coalesce(jsonb_agg(jsonb_build_object('id', f.id, 'tipo', f.tipo_online) order by f.ordem), '[]'::jsonb) into v_formas
    from formas_pagamento f where f.ativa and f.visivel_cardapio and f.aceita_online and f.tipo_online is not null;
  if v_pk is null or jsonb_array_length(v_formas) = 0 then return jsonb_build_object('ok', true, 'ligado', false); end if;
  v_min := case when coalesce(c.config->>'pixValidadeMin', '') ~ '^[0-9]{1,3}$' then least(120, greatest(5, (c.config->>'pixValidadeMin')::int)) else 15 end;
  return jsonb_build_object('ok', true, 'ligado', true, 'modo', case when v_prod then 'producao' else 'teste' end,
    'publicKey', v_pk, 'formas', v_formas, 'pixValidadeMin', v_min);
end $f$;
revoke all on function public.api_mp_config_publica(jsonb) from public, anon, authenticated;
grant execute on function public.api_mp_config_publica(jsonb) to anon, authenticated;

commit;
