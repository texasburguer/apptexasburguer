-- MERCADO PAGO — LGPD: dados pessoais das reservas e dos pagamentos online (14/10/2026)
-- COLE NO SQL EDITOR DO SUPABASE (tem "delete from" dentro de uma função, que o conector não aceita; por isso é manual).
-- Rode DEPOIS das etapas 1 e 2 do Mercado Pago e do SQL de contas de clientes (2026-10-12).
-- Problema que isto resolve: as tabelas pedidos_reserva e pagamentos_online guardam nome, telefone, endereço e o QR do Pix,
-- e nem "apagar conta" nem a anonimização automática (3 anos) passavam por elas.
-- Pode rodar mais de uma vez.
begin;

-- 1) anonimiza as reservas de uma conta (p_user) e/ou as encerradas há mais de p_dias dias.
--    Não mexe em pagamento aprovado que ainda espera decisão do restaurante (liberar ou reembolsar).
create or replace function public._mp_anonimizar_reservas(p_user uuid default null, p_dias integer default null) returns integer
 language plpgsql security definer set search_path to 'public' as $f$
declare n integer := 0;
begin
  if p_user is null and p_dias is null then return 0; end if;
  with alvo as (
    select r.id from pedidos_reserva r
     where (r.cliente_nome <> 'Cliente anonimizado' or r.telefone <> '' or r.dados_entrega is not null or r.observacoes <> '')
       and ((p_user is not null and r.user_id = p_user)
         or (p_dias is not null and r.estado <> 'ativa' and r.criado_em < now() - make_interval(days => p_dias)))
       and not exists (select 1 from pagamentos_online g where g.reserva_id = r.id and g.status = 'aprovado' and g.decisao_pendente and g.decisao is null)
  ), a as (
    update pedidos_reserva r set cliente_nome = 'Cliente anonimizado', telefone = '', dados_entrega = null, observacoes = '', atualizado_em = now()
      from alvo where r.id = alvo.id returning r.id
  ), b as (
    update pagamentos_online g set pix_copia_cola = null, pix_qr_base64 = null, cartao_final = null, atualizado_em = now()
     where g.reserva_id in (select id from a) returning g.id
  )
  select count(*) into n from a;
  return n;
end $f$;

-- 2) limpeza diária: QR/copia-e-cola de Pix que já acabou (2 dias) e reservas encerradas há mais de 180 dias
create or replace function public._job_mp_lgpd() returns integer
 language plpgsql security definer set search_path to 'public' as $f$
begin
  update pagamentos_online set pix_copia_cola = null, pix_qr_base64 = null, atualizado_em = now()
   where status <> 'aguardando' and (pix_copia_cola is not null or pix_qr_base64 is not null) and atualizado_em < now() - interval '2 days';
  return public._mp_anonimizar_reservas(null, 180);
end $f$;
revoke all on function public._mp_anonimizar_reservas(uuid, integer), public._job_mp_lgpd() from public, anon, authenticated;
grant execute on function public._mp_anonimizar_reservas(uuid, integer), public._job_mp_lgpd() to service_role;

do $$ begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    if not exists (select 1 from cron.job where jobname = 'mp-lgpd-diario') then
      perform cron.schedule('mp-lgpd-diario', '30 5 * * *', 'select public._job_mp_lgpd()');
    end if;
  end if;
end $$;

-- 3) "apagar conta" passa a anonimizar também as reservas e os pagamentos online da conta
create or replace function public.api_conta_apagar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public'
as $function$
declare c contas_cliente := _conta_exigir(); v_anon boolean := coalesce(p->>'anonimizar', '') in ('true', 't');
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  if v_anon then
    if c.cliente_id is not null then perform _anonimizar_cliente(c.cliente_id); end if;
    update vendas set cliente_nome = 'Cliente anonimizado', telefone_cliente = '', endereco = '', complemento = '', referencia = '', observacoes_entrega = '', cpf_nota = null
     where id in (select venda_id from contas_pedidos where user_id = c.user_id);
  end if;
  perform _mp_anonimizar_reservas(c.user_id);   -- pedidos reservados e pagamentos online da conta (nome, telefone, endereço, QR do Pix)
  update cupons_usos set user_id = null where user_id = c.user_id;
  perform _auditar_publico('Conta de cliente apagada', case when v_anon then 'com anonimização do histórico' else 'histórico mantido' end, '');
  delete from contas_cliente where user_id = c.user_id;
  delete from auth.users where id = c.user_id;
  return jsonb_build_object('ok', true, 'message', 'Conta apagada.');
end $function$;
revoke all on function public.api_conta_apagar(jsonb) from public, anon;
grant execute on function public.api_conta_apagar(jsonb) to authenticated;

commit;
