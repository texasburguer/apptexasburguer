-- Ajuda da IA: brindes (prêmio de fidelidade e de indicação) na conta do cliente (12/10/2026). Pode rodar mais de uma vez.
update public.ai_ajuda
   set passos = replace(passos,
         'o prêmio de indicação ainda não usado também é desfeito.',
         'o brinde (prêmio) usado nele volta para o cliente.')
       || E'\nBrindes: marque os produtos-prêmio em Editar produto › Mais opções (Prêmio de fidelidade / Prêmio de indicação). Com o cartão fidelidade completo, o cliente escolhe o prêmio em "Minha conta" ou no carrinho. Quem indica, quando o amigo conclui o 1º pedido, ganha o cupom automático "quem indicou" (se estiver ligado) e/ou 1 brinde à escolha entre os produtos de prêmio de indicação (se houver algum marcado): cada um vale por si e podem valer os dois. Se esse pedido for cancelado, o cupom e o brinde somem.\nO brinde pode ir junto com outros itens ou sozinho: sai a R$ 0,00 (entra nos relatórios, com o custo, e baixa o estoque) e a entrega, se for entrega, é cobrada. Não há pedido mínimo. Pedido cancelado devolve o brinde. O botão Entrar/Minha conta fica numa faixa abaixo do banner do cardápio.',
       atualizado_em = now()
 where slug = 'man-admin-111-conta-cliente' and passos not like '%Brindes: marque os produtos-prêmio%';
