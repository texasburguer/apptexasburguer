-- Fase 4 · item 6 (opcional): índices nas 16 chaves estrangeiras que não tinham índice (2026-10-16).
-- Só acelera junções e exclusões em cadeia; não muda dado nem regra. Idempotente.
-- NÃO feito de propósito: consolidar políticas RLS duplicadas (mexe em segurança; o ganho é mínimo com o volume atual).
create index if not exists ix_brindes_produto_id on public.brindes (produto_id);
create index if not exists ix_categorias_perfil_fiscal_id on public.categorias (perfil_fiscal_id);
create index if not exists ix_combos_perfil_fiscal_id on public.combos (perfil_fiscal_id);
create index if not exists ix_compra_itens_ingrediente_id on public.compra_itens (ingrediente_id);
create index if not exists ix_compras_criado_por on public.compras (criado_por);
create index if not exists ix_compras_despesa_id on public.compras (despesa_id);
create index if not exists ix_contas_beneficios_produto_id on public.contas_beneficios (produto_id);
create index if not exists ix_contas_cliente_indicado_por on public.contas_cliente (indicado_por);
create index if not exists ix_cupons_cliente_id on public.cupons (cliente_id);
create index if not exists ix_fiscal_empresa_perfil_padrao_id on public.fiscal_empresa (perfil_padrao_id);
create index if not exists ix_fornecedores_criado_por on public.fornecedores (criado_por);
create index if not exists ix_ifood_itens_adicional_id on public.ifood_itens (adicional_id);
create index if not exists ix_ifood_itens_combo_id on public.ifood_itens (combo_id);
create index if not exists ix_ifood_itens_produto_id on public.ifood_itens (produto_id);
create index if not exists ix_pedidos_reserva_forma_pagamento_id on public.pedidos_reserva (forma_pagamento_id);
create index if not exists ix_produtos_perfil_fiscal_id on public.produtos (perfil_fiscal_id);
