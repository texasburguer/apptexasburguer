-- =====================================================================================
-- MERCADO PAGO · ETAPA 4 (painel Admin: card Mercado Pago) · 2026-10-13 · NÃO APLICADO
-- Rode DEPOIS das Etapas 1 e 2. Pode rodar de novo (idempotente). Cole inteiro no SQL Editor do Supabase.
-- Para conferir depois, rode testes/teste-mp-etapa4.sql.
-- Só acrescenta o 'mercadopago' às funções de integração (partindo da versão MAIS RECENTE de cada uma:
-- as de iFood e Nota fiscal ficam idênticas). Nenhum "delete from" dentro de função. Integração segue DESLIGADA.
-- =====================================================================================
begin;

-- ---------- 1) Regra do "Ligar": em TESTE só exige conta, chaves de teste e webhook; em PRODUÇÃO exige os 5 passos ----------
-- (o "teste guiado" só é possível com a integração ligada em teste, por isso não pode ser exigido para ligar em teste)
create or replace function public._integ_pendencias(p_prov text, p_modo text) returns text[]
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_out text[] := '{}'; v_item jsonb; v_ck jsonb; v_ok boolean;
begin
  select checklist into v_ck from integracoes_config where provedor = p_prov;
  for v_item in select * from jsonb_array_elements(_integ_checklist_def(p_prov)) loop
    if p_prov = 'mercadopago' and p_modo = 'homologacao' and (v_item->>'id') in ('teste_guiado', 'chaves_producao') then continue; end if;
    if coalesce((v_item->>'auto')::boolean, false) then
      v_ok := case v_item->>'id'
        when 'chaves' then (select count(*) from integracoes_segredos where chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id')) = 3
        when 'token' then exists (select 1 from integracoes_segredos where chave = 'nfce_token_' || p_modo)
        when 'empresa' then public._fiscal_empresa_ok()
        when 'perfis' then public._fiscal_perfis_ok()
        when 'chaves_teste' then (select count(*) from integracoes_segredos where chave in ('mp_public_key_teste', 'mp_access_token_teste')) = 2
        when 'webhook' then exists (select 1 from integracoes_segredos where chave = 'mp_webhook_secret')
        when 'teste_guiado' then exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'pix' and status in ('aprovado', 'reembolso_parcial', 'reembolsado'))
                             and exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'credito' and status in ('aprovado', 'reembolso_parcial', 'reembolsado'))
        when 'chaves_producao' then (select count(*) from integracoes_segredos where chave in ('mp_public_key_producao', 'mp_access_token_producao')) = 2
        else coalesce((v_ck->>(v_item->>'id'))::boolean, false) end;
    else
      v_ok := coalesce((v_ck->>(v_item->>'id'))::boolean, false);
    end if;
    if not v_ok then v_out := v_out || (v_item->>'titulo'); end if;
  end loop;
  return v_out;
end $f$;

-- ---------- 2) Quem vê o pagamento online no cardápio ----------
-- Produção: todos. Teste: só quem está na lista "emailsTeste" (a conta Google de teste), ou todos se "testeNoCardapio" = true (padrão: não).
-- _mp_publico(user) é o miolo; api_mp_config_publica usa o usuário logado e mp_preparar_pagamento usa o dono da reserva.
create or replace function public._mp_publico(p_user uuid) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare c integracoes_config%rowtype; v_prod boolean; v_pk text; v_formas jsonb; v_min int; v_email text; v_visivel boolean;
begin
  select * into c from integracoes_config where provedor = 'mercadopago';
  if c.provedor is null or not c.ligado then return jsonb_build_object('ok', true, 'ligado', false); end if;
  v_prod := (c.modo = 'producao');
  if not v_prod then
    v_visivel := coalesce((c.config->>'testeNoCardapio')::boolean, false);
    if not v_visivel and p_user is not null and jsonb_typeof(c.config->'emailsTeste') = 'array' then
      select lower(email) into v_email from auth.users where id = p_user;
      v_visivel := v_email is not null and exists (select 1 from jsonb_array_elements_text(c.config->'emailsTeste') x where lower(btrim(x)) = v_email);
    end if;
    if not coalesce(v_visivel, false) then return jsonb_build_object('ok', true, 'ligado', false); end if;
  end if;
  select valor into v_pk from integracoes_segredos where chave = case when v_prod then 'mp_public_key_producao' else 'mp_public_key_teste' end;
  select coalesce(jsonb_agg(jsonb_build_object('id', f.id, 'tipo', f.tipo_online) order by f.ordem), '[]'::jsonb) into v_formas
    from formas_pagamento f where f.ativa and f.visivel_cardapio and f.aceita_online and f.tipo_online is not null;
  if v_pk is null or jsonb_array_length(v_formas) = 0 then return jsonb_build_object('ok', true, 'ligado', false); end if;
  v_min := case when coalesce(c.config->>'pixValidadeMin', '') ~ '^[0-9]{1,3}$' then least(120, greatest(5, (c.config->>'pixValidadeMin')::int)) else 15 end;
  return jsonb_build_object('ok', true, 'ligado', true, 'modo', case when v_prod then 'producao' else 'teste' end,
    'publicKey', v_pk, 'formas', v_formas, 'pixValidadeMin', v_min);
end $f$;

create or replace function public.api_mp_config_publica(p jsonb default '{}'::jsonb) returns jsonb
 language sql stable security definer set search_path to 'public' as $f$ select public._mp_publico(auth.uid()) $f$;
revoke all on function public._mp_publico(uuid) from public, anon, authenticated;
revoke all on function public.api_mp_config_publica(jsonb) from public, anon, authenticated;
grant execute on function public.api_mp_config_publica(jsonb) to anon, authenticated;

-- mp_preparar_pagamento (Etapa 2) com duas mudanças: usa _mp_publico(dono da reserva) e, em modo Teste, o e-mail do pagador pode ser o "emailPagadorTeste" do card
create or replace function public.mp_preparar_pagamento(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; f formas_pagamento%rowtype; g pagamentos_online%rowtype; v_modo text; v_novo uuid; v_email text; v_achou boolean; v_teste_email text;
begin
  select * into r from pedidos_reserva where id = _uuid(p->>'reservaId') for update;
  if not found or r.user_id is distinct from _uuid(p->>'userId') then return _falha('Pedido não encontrado.'); end if;
  if r.estado = 'confirmada' then return _falha('Este pedido já foi pago.'); end if;
  if r.estado <> 'ativa' or r.expira_em < now() then return _falha('O tempo deste pedido acabou. Faça o pedido de novo.'); end if;
  if coalesce((public._mp_publico(r.user_id)->>'ligado')::boolean, false) is not true then return _falha('O pagamento pelo site não está disponível agora.'); end if;
  select * into f from formas_pagamento where id = r.forma_pagamento_id;
  if f.id is null or not f.aceita_online or f.tipo_online is null then return _falha('Forma de pagamento inválida.'); end if;
  if exists (select 1 from pagamentos_online where reserva_id = r.id and status = 'aprovado') then return _falha('Este pedido já foi pago.'); end if;
  if (select count(*) from pagamentos_online where reserva_id = r.id) >= 5 then return _falha('Muitas tentativas de pagamento. Faça o pedido de novo.'); end if;

  select * into g from pagamentos_online
   where reserva_id = r.id and metodo = 'pix' and status = 'aguardando' and pix_copia_cola is not null and (pix_expira_em is null or pix_expira_em > now())
   order by criado_em desc limit 1;
  v_achou := found;
  if v_achou and f.tipo_online = 'pix' then
    return jsonb_build_object('ok', true, 'reaproveitar', true, 'pagamentoId', g.id, 'metodo', 'pix', 'valor', g.valor,
      'pixCopiaCola', g.pix_copia_cola, 'pixQrBase64', g.pix_qr_base64, 'pixExpiraEm', g.pix_expira_em);
  end if;
  if f.tipo_online = 'credito' and exists (select 1 from pagamentos_online where reserva_id = r.id and metodo = 'credito' and status = 'aguardando' and criado_em > now() - interval '2 minutes') then
    return _falha('Seu pagamento está em andamento. Aguarde alguns segundos.');
  end if;

  update pagamentos_online set status = 'cancelado', status_detalhe = 'substituído por nova tentativa', atualizado_em = now() where reserva_id = r.id and status = 'aguardando';
  select case when modo = 'producao' then 'producao' else 'homologacao' end, nullif(btrim(coalesce(config->>'emailPagadorTeste', '')), '')
    into v_modo, v_teste_email from integracoes_config where provedor = 'mercadopago';
  insert into pagamentos_online (reserva_id, user_id, metodo, mp_modo, valor) values (r.id, r.user_id, f.tipo_online, v_modo, r.valor_total) returning id into v_novo;
  select email into v_email from auth.users where id = r.user_id;   -- só é repassado ao Mercado Pago; não é guardado aqui
  if v_modo = 'homologacao' and v_teste_email is not null then v_email := v_teste_email; end if;   -- só em Teste: e-mail de comprador de teste do Mercado Pago
  return jsonb_build_object('ok', true, 'pagamentoId', v_novo, 'metodo', f.tipo_online, 'modo', v_modo, 'valor', r.valor_total, 'expiraEm', r.expira_em,
    'email', v_email, 'nome', r.cliente_nome,
    'itens', (select coalesce(jsonb_agg(jsonb_build_object('titulo', left(coalesce(e->>'descricao', 'Item'), 100), 'quantidade', _num(e->>'quantidade', 1), 'valorUnitario', _num(e->>'valorUnitario'))), '[]'::jsonb)
                from jsonb_array_elements(r.itens) e));
end $f$;
revoke all on function public.mp_preparar_pagamento(jsonb) from public, anon, authenticated;
grant execute on function public.mp_preparar_pagamento(jsonb) to service_role;

-- ---------- 3) Status das integrações (versão mais recente + Mercado Pago) ----------
create or replace function public.api_integracoes_status(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_modo text; v_def jsonb; v_it jsonb; v_pend text[]; v_pt text[]; v_pp text[];
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  for r in select * from integracoes_config order by provedor loop
    v_def := _integ_checklist_def(r.provedor); v_pend := _integ_pendencias(r.provedor, r.modo);
    v := v || (jsonb_build_object('provedor', r.provedor, 'ligado', r.ligado, 'modo', r.modo, 'ligadoEm', r.ligado_em, 'config', r.config,
      'checklist', (select coalesce(jsonb_agg(jsonb_build_object('id', x->>'id', 'titulo', x->>'titulo', 'auto', coalesce((x->>'auto')::boolean, false),
          'feito', not ((x->>'titulo') = any (v_pend))) ), '[]'::jsonb) from jsonb_array_elements(v_def) x),
      'pendencias', to_jsonb(v_pend), 'podeLigar', coalesce(array_length(v_pend, 1), 0) = 0,
      'segredos', (select coalesce(jsonb_object_agg(s.chave, jsonb_build_object('tem', true, 'final', case when length(s.valor) > 8 then right(s.valor, 4) else '' end, 'em', s.atualizado_em)), '{}'::jsonb)
                    from integracoes_segredos s where (r.provedor = 'ifood' and s.chave like 'ifood\_%') or (r.provedor = 'nfce' and s.chave like 'nfce\_%') or (r.provedor = 'mercadopago' and s.chave like 'mp\_%')))
      || case when r.provedor = 'mercadopago' then (
           select jsonb_build_object('pendenciasTeste', to_jsonb(a.t), 'pendenciasProducao', to_jsonb(a.p),
             'podeLigarTeste', coalesce(array_length(a.t, 1), 0) = 0, 'podeLigarProducao', coalesce(array_length(a.p, 1), 0) = 0,
             'formas', (select coalesce(jsonb_agg(jsonb_build_object('id', f.id, 'nome', f.nome, 'aceitaOnline', f.aceita_online, 'tipoOnline', f.tipo_online) order by f.ordem), '[]'::jsonb)
                          from formas_pagamento f where f.ativa and f.visivel_cardapio))
             from (select _integ_pendencias('mercadopago', 'homologacao') as t, _integ_pendencias('mercadopago', 'producao') as p) a)
         else '{}'::jsonb end);
  end loop;
  return jsonb_build_object('ok', true, 'integracoes', v);
end $f$;

-- ---------- 4) Ajustes (config): mercadopago ganha validade do Pix, e-mails de teste e "mostrar a todos em Teste" ----------
create or replace function public.api_integracoes_config(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text := p->>'provedor'; v_cfg jsonb := coalesce(p->'config', '{}'::jsonb); v_atual jsonb; v_chave text; v_novo jsonb := '{}'::jsonb;
        v_re text := '^[^@\s]+@[^@\s]+\.[^@\s]+$';
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_prov not in ('ifood', 'nfce', 'mercadopago') then return _falha('Integração inválida.'); end if;
  select config into v_atual from integracoes_config where provedor = v_prov;
  -- só chaves conhecidas, com valores simples
  for v_chave in select jsonb_object_keys(v_cfg) loop
    if v_prov = 'ifood' and v_chave in ('confirmacaoAutomatica', 'abrirFecharComCaixa', 'pausarSemEstoque', 'enviarPrecos') then v_novo := v_novo || jsonb_build_object(v_chave, coalesce((v_cfg->>v_chave)::boolean, false));
    elsif v_prov = 'ifood' and v_chave = 'baixaEstoque' and (v_cfg->>v_chave) in ('confirmacao', 'entrega') then v_novo := v_novo || jsonb_build_object(v_chave, v_cfg->>v_chave);
    elsif v_prov = 'ifood' and v_chave = 'retencaoClientesDias' and (v_cfg->>v_chave)::int between 7 and 365 then v_novo := v_novo || jsonb_build_object(v_chave, (v_cfg->>v_chave)::int);
    elsif v_prov = 'ifood' and v_chave = 'limitePrecoPct' and (v_cfg->>v_chave)::numeric between 0 and 100 then v_novo := v_novo || jsonb_build_object(v_chave, (v_cfg->>v_chave)::numeric);
    elsif v_prov = 'nfce' and v_chave = 'emitirQuando' and (v_cfg->>v_chave) in ('pagamento', 'entrega') then v_novo := v_novo || jsonb_build_object(v_chave, v_cfg->>v_chave);
    elsif v_prov = 'nfce' and v_chave = 'canais' and jsonb_typeof(v_cfg->v_chave) = 'array' then v_novo := v_novo || jsonb_build_object(v_chave, (select coalesce(jsonb_agg(c), '[]'::jsonb) from jsonb_array_elements_text(v_cfg->v_chave) c where c in ('balcao', 'cardapio', 'ifood', 'mesa')));
    elsif v_prov = 'mercadopago' and v_chave = 'pixValidadeMin' then
      if coalesce(v_cfg->>v_chave, '') !~ '^[0-9]{1,3}$' or (v_cfg->>v_chave)::int not between 5 and 120 then return _falha('A validade do Pix deve ficar entre 5 e 120 minutos.'); end if;
      v_novo := v_novo || jsonb_build_object(v_chave, (v_cfg->>v_chave)::int);
    elsif v_prov = 'mercadopago' and v_chave = 'testeNoCardapio' then v_novo := v_novo || jsonb_build_object(v_chave, coalesce((v_cfg->>v_chave)::boolean, false));
    elsif v_prov = 'mercadopago' and v_chave = 'emailPagadorTeste' then
      if btrim(coalesce(v_cfg->>v_chave, '')) <> '' and (lower(btrim(v_cfg->>v_chave)) !~ v_re or length(v_cfg->>v_chave) > 120) then return _falha('E-mail do comprador de teste inválido.'); end if;
      v_novo := v_novo || jsonb_build_object(v_chave, lower(btrim(coalesce(v_cfg->>v_chave, ''))));
    elsif v_prov = 'mercadopago' and v_chave = 'emailsTeste' and jsonb_typeof(v_cfg->v_chave) = 'array' then
      if exists (select 1 from jsonb_array_elements_text(v_cfg->v_chave) x where btrim(x) <> '' and lower(btrim(x)) !~ v_re) then return _falha('Um dos e-mails de teste é inválido.'); end if;
      v_novo := v_novo || jsonb_build_object(v_chave, (select coalesce(jsonb_agg(q.e), '[]'::jsonb) from (select distinct lower(btrim(x)) as e from jsonb_array_elements_text(v_cfg->v_chave) x where btrim(x) <> '' limit 5) q));
    end if;
  end loop;
  update integracoes_config set config = v_atual || v_novo, atualizado_em = now() where provedor = v_prov;
  perform _auditar('Integração: ajustes salvos', v_prov);
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Ajustes salvos.');
end $f$;

-- ---------- 5) Guardar chaves (versão mais recente, com nfce_csc) + as 5 chaves do Mercado Pago ----------
create or replace function public.api_integracoes_salvar_segredo(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_chave text := p->>'chave'; v_valor text := btrim(coalesce(p->>'valor', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_chave not in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id', 'nfce_token_homologacao', 'nfce_token_producao', 'nfce_csc',
                     'mp_public_key_teste', 'mp_public_key_producao', 'mp_access_token_teste', 'mp_access_token_producao', 'mp_webhook_secret') then return _falha('Campo desconhecido.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  if length(v_valor) < 8 or length(v_valor) > 400 or v_valor ~ '\s' then return _falha('Valor inválido. Copie inteiro, sem espaços.'); end if;
  if v_chave like 'mp\_%' then
    if v_valor !~ '^[A-Za-z0-9_-]+$' then return _falha('Valor inválido. Use só letras, números, - e _ (copie inteiro, sem espaços).'); end if;
    if v_chave = 'mp_webhook_secret' and length(v_valor) < 16 then return _falha('A chave secreta do aviso (webhook) é maior que isso. Copie inteira.'); end if;
    if v_chave like 'mp\_access\_token%' and length(v_valor) < 30 then return _falha('O Access Token é maior que isso. Copie inteiro.'); end if;
  end if;
  insert into integracoes_segredos (chave, valor, atualizado_em) values (v_chave, v_valor, now())
    on conflict (chave) do update set valor = excluded.valor, atualizado_em = now();
  perform _auditar('Integração: chave salva', v_chave);
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Salvo.');
end $f$;

-- ---------- 6) Ligar e desligar ----------
create or replace function public.api_integracoes_ligar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text := p->>'provedor'; v_modo text := coalesce(p->>'modo', 'producao'); v_pend text[]; v_uid text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_prov not in ('ifood', 'nfce', 'mercadopago') then return _falha('Integração inválida.'); end if;
  if v_prov in ('nfce', 'mercadopago') and (nullif(p->>'modo', '') is null or v_modo not in ('homologacao', 'producao')) then return _falha('Escolha o ambiente: teste (homologação) ou produção.'); end if;
  if v_prov = 'ifood' then v_modo := 'producao'; end if;
  v_uid := _exige_admin(p->>'senhaAdmin');
  if coalesce(p->>'senhaAdmin', '') = '' or v_uid is null then return _falha('Senha de administrador incorreta.'); end if;
  v_pend := _integ_pendencias(v_prov, v_modo);
  if coalesce(array_length(v_pend, 1), 0) > 0 then return _falha('Ainda faltam passos: ' || array_to_string(v_pend, '; ')); end if;
  if v_prov = 'mercadopago' and not exists (select 1 from formas_pagamento where ativa and visivel_cardapio and aceita_online and tipo_online is not null) then
    return _falha('Escolha pelo menos uma forma de pagamento online (Pix ou cartão de crédito) antes de ligar.');
  end if;
  update integracoes_config set ligado = true, modo = v_modo, ligado_em = now(), ligado_por = v_uid, atualizado_em = now() where provedor = v_prov;
  perform _auditar('Integração LIGADA', v_prov || ' · ' || v_modo);
  perform _integ_log(v_prov, 'info', 'Integração ligada (' || v_modo || ')');
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Ligado.');
end $f$;

create or replace function public.api_integracoes_desligar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if p->>'provedor' not in ('ifood', 'nfce', 'mercadopago') then return _falha('Integração inválida.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' or _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  update integracoes_config set ligado = false, atualizado_em = now() where provedor = p->>'provedor';
  perform _auditar('Integração DESLIGADA', p->>'provedor');
  perform _integ_log(p->>'provedor', 'aviso', 'Integração desligada');
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Desligado. O sistema voltou a funcionar como antes.');
end $f$;

-- ---------- 7) Formas de pagamento online (Pix / cartão de crédito) ----------
create or replace function public.api_mp_forma_online(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_id uuid := _uuid(p->>'formaId'); v_on boolean := coalesce((p->>'aceitaOnline')::boolean, false); v_tipo text := lower(btrim(coalesce(p->>'tipoOnline', '')));
        f formas_pagamento%rowtype; o formas_pagamento%rowtype;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into f from formas_pagamento where id = v_id;
  if not found then return _falha('Forma de pagamento não encontrada.'); end if;
  if v_on then
    if v_tipo not in ('pix', 'credito') then return _falha('Escolha Pix ou cartão de crédito.'); end if;
    if not f.ativa or not f.visivel_cardapio then return _falha('Esta forma está oculta no cardápio. Deixe-a ativa e visível antes.'); end if;
    if f.permite_troco then return _falha('Forma com troco (dinheiro) não pode ser paga pelo site.'); end if;
    select * into o from formas_pagamento where id <> f.id and aceita_online and tipo_online = v_tipo limit 1;
    if found then return _falha('A forma "' || o.nome || '" já está como ' || case when v_tipo = 'pix' then 'Pix' else 'cartão de crédito' end || ' online. Desmarque-a antes.'); end if;
    update formas_pagamento set aceita_online = true, tipo_online = v_tipo where id = f.id;
  else
    update formas_pagamento set aceita_online = false, tipo_online = null where id = f.id;
  end if;
  perform _auditar('Mercado Pago: forma online', f.nome || ' · ' || case when v_on then v_tipo else 'desligada' end);
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Salvo.');
end $f$;

-- Últimos pagamentos online + situação do teste guiado (a tela do card usa)
create or replace function public.api_mp_pagamentos_recentes(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'itens', (select coalesce(jsonb_agg(jsonb_build_object('em', to_char(x.criado_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI'), 'modo', x.mp_modo, 'metodo', x.metodo,
                'status', x.status, 'valor', x.valor, 'aDecidir', (x.decisao_pendente and x.decisao is null), 'detalhe', left(coalesce(nullif(x.erro, ''), x.status_detalhe, ''), 120)) order by x.criado_em desc), '[]'::jsonb)
              from (select * from pagamentos_online order by criado_em desc limit 15) x),
    'testePix', exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'pix' and status in ('aprovado', 'reembolso_parcial', 'reembolsado')),
    'testeCredito', exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'credito' and status in ('aprovado', 'reembolso_parcial', 'reembolsado')),
    'aDecidir', (select count(*) from pagamentos_online where decisao_pendente and decisao is null));
end $f$;

-- ---------- 8) Saúde do sistema: versão mais recente de _saude_integracoes + bloco do Mercado Pago ----------
create or replace function public._saude_integracoes() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_desc int; e ifood_estado%rowtype; v_min numeric; v_sem int; v_novos int; v_acoes int; v_nivel text; v_txt text; v_urg int;
        v_dec int; v_dec_velho int; v_venc int; v_err int;
begin
  if exists (select 1 from ai_segredos where provedor = 'nvidia') or exists (select 1 from ai_segredos where provedor = 'cloudflare') then
    select count(*) into v_desc from unnest(array['nvidia', 'cloudflare']) x(p) where _ia_provedor_descansando(x.p);
    v := v || jsonb_build_object('id', 'ia_extras', 'titulo', 'IAs de reserva (NVIDIA / Cloudflare)', 'nivel', case when v_desc > 0 then 'atencao' else 'ok' end,
      'texto', (select string_agg(x.rot || ': ' || case when not exists (select 1 from ai_segredos where provedor = x.p) then 'sem chave' when _ia_provedor_descansando(x.p) then 'descansando (erros recentes)' else 'pronta' end, ' · ')
                from (values ('nvidia', 'NVIDIA'), ('cloudflare', 'Cloudflare')) x(p, rot)));
  end if;
  if _integracao_ligada('ifood') then
    select * into e from ifood_estado where id;
    v_min := case when e.ultima_consulta_ok is null then null else extract(epoch from (now() - e.ultima_consulta_ok)) / 60 end;
    select coalesce(sum(itens_sem_ligacao), 0) into v_sem from ifood_pedidos where estado <> 'cancelado' and criado_em > now() - interval '7 days';
    select count(*) into v_novos from ifood_pedidos where estado = 'novo' and not simulado and criado_em < now() - interval '4 minutes';
    select count(*) into v_acoes from ifood_acoes where estado in ('erro', 'duvida') and criado_em > now() - interval '1 day';
    select count(*) into v_urg from ifood_negociacoes where estado = 'aberta' and expira_em > now() and expira_em < now() + interval '3 minutes';
    v_nivel := case when v_min is null or v_min > 2 or e.token_ok is false or v_novos > 0 or v_urg > 0 then 'problema' when v_acoes > 0 or v_sem > 0 or e.ultimo_erro is not null or exists (select 1 from ifood_negociacoes where estado = 'aberta' and expira_em > now()) then 'atencao' else 'ok' end;
    v_txt := case when v_min is null then 'Ligado, mas ainda sem nenhuma consulta bem-sucedida ao iFood.' else 'Última consulta ao iFood há ' || round(v_min, 1) || ' min' end
      || case when e.ultimo_pedido_em is not null then ' · último pedido às ' || to_char(e.ultimo_pedido_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') else ' · nenhum pedido ainda' end
      || case when e.token_ok is false then ' · ACESSO RECUSADO (confira as chaves)' else '' end
      || case when v_novos > 0 then ' · ' || v_novos || ' pedido(s) esperando confirmação há mais de 4 min' else '' end
      || case when v_acoes > 0 then ' · ' || v_acoes || ' ação(ões) não confirmada(s) no iFood' else '' end
      || case when v_sem > 0 then ' · ' || v_sem || ' item(ns) sem ligação' else '' end || public._saude_ifood_extra();
    v := v || jsonb_build_object('id', 'ifood', 'titulo', 'iFood', 'nivel', v_nivel, 'texto', v_txt);
  end if;
  v := v || public._saude_nfce();
  if _integracao_ligada('mercadopago') then
    select count(*) into v_dec from pagamentos_online where decisao_pendente and decisao is null;
    select count(*) into v_dec_velho from pagamentos_online where decisao_pendente and decisao is null and atualizado_em < now() - interval '10 minutes';
    select count(*) into v_venc from pedidos_reserva pr where pr.estado = 'ativa' and pr.expira_em < now() - interval '3 minutes'
      and not exists (select 1 from pagamentos_online g where g.reserva_id = pr.id and (g.status = 'aprovado' or (g.decisao_pendente and g.decisao is null)));
    select count(*) into v_err from pagamentos_online where status = 'erro' and criado_em > now() - interval '1 hour';
    v_nivel := case when v_venc > 0 or v_dec_velho > 0 then 'problema' when v_dec > 0 or v_err > 0 then 'atencao' else 'ok' end;
    v_txt := 'Ligado (' || case when (select modo from integracoes_config where provedor = 'mercadopago') = 'producao' then 'produção' else 'teste' end || ')'
      || case when v_dec > 0 then ' · ' || v_dec || ' pagamento(s) esperando decisão (seguir ou reembolsar)' else '' end
      || case when v_venc > 0 then ' · ' || v_venc || ' reserva(s) vencida(s) não liberada(s) (confira o agendamento mp-expirar-reservas)' else '' end
      || case when v_err > 0 then ' · ' || v_err || ' erro(s) ao criar pagamento na última hora' else '' end;
    v := v || jsonb_build_object('id', 'mercadopago', 'titulo', 'Mercado Pago', 'nivel', v_nivel, 'texto', v_txt);
  end if;
  return v;
end $f$;

-- ---------- 9) Permissões ----------
revoke all on function public._saude_integracoes() from public, anon, authenticated;
revoke all on function public._integ_pendencias(text, text) from public, anon, authenticated;
revoke all on function public.api_integracoes_status(jsonb), public.api_integracoes_config(jsonb), public.api_integracoes_salvar_segredo(jsonb),
  public.api_integracoes_ligar(jsonb), public.api_integracoes_desligar(jsonb), public.api_mp_forma_online(jsonb), public.api_mp_pagamentos_recentes(jsonb) from public, anon;
grant execute on function public.api_integracoes_status(jsonb), public.api_integracoes_config(jsonb), public.api_integracoes_salvar_segredo(jsonb),
  public.api_integracoes_ligar(jsonb), public.api_integracoes_desligar(jsonb), public.api_mp_forma_online(jsonb), public.api_mp_pagamentos_recentes(jsonb) to authenticated;

commit;
