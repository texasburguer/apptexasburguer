-- Ajuda do Tex/manual: a tela "Início do Administrador" foi removida e a tela do Caixa foi reorganizada. Só troca texto; idempotente.
update public.ai_ajuda set atualizado_em = now(), passos = replace(passos,
  $a$Ao entrar, o Início do Administrador mostra as pendências (cada uma abre a tela certa) e as últimas telas vistas. O campo$a$,
  $b$Ao entrar, escolha a tela no menu. O campo$b$)
 where slug = 'man-admin-02-onde-fica-cada-coisa';

update public.ai_ajuda set atualizado_em = now(), passos = replace(replace(replace(passos,
  $a$Fechar: Caixa → "Fechar caixa vencido" (Admin e Operador).$a$,
  $b$Fechar: Caixa → botão "Fechar caixa vencido" no fim da tela (Admin e Operador).$b$),
  $c$aparece na Visão Geral e no Início do Administrador. Expira sozinho.$c$,
  $d$aparece na Visão Geral. Expira sozinho.$d$),
  $e$aparece uma faixa no Início e no Caixa. O Admin ajusta a regra em Caixa → "Regra do caixa vencido".$e$,
  $f$aparece uma faixa no Início (com atalho para o Caixa) e no Caixa. O Admin ajusta a regra em Caixa → "Regra do caixa vencido" (embaixo do botão de fechar).$f$)
 where slug = 'man-admin-114-caixa-vencido';
