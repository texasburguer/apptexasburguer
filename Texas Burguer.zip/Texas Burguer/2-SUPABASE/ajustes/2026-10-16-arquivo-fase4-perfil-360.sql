-- ============================================================================
-- ARQUIVAMENTO / CLIENTES · FASE 4 · Perfil 360 do cliente · 2026-10-16 · seguro para rodar de novo
-- O TELEFONE (só dígitos) é a chave do cliente; cliente_id e conta Google são complementos.
-- Só soma pedidos "Confirmada" (cancelados não contam), juntando o que está ativo + o resumo arquivado.
-- 1) _segmento_cliente: regra única dos segmentos (Sem pedido, Novo, Fiel, VIP, Em risco)
-- 2) api_cliente_360: ficha completa de UM cliente (gasto, frequência, item favorito, conta Google...)
-- 3) api_clientes_segmentos: segmento de TODOS os clientes (selo na lista + filtro), uma consulta só
-- Regras (ajustáveis neste arquivo): Em risco = último pedido há mais de 45 dias (vale p/ qualquer cliente com pedido);
--   VIP = 10+ pedidos OU R$ 800+ gastos; Fiel = 4+ pedidos; Novo = 1 a 3 pedidos; Sem pedido = cadastrado sem compra.
-- ============================================================================

CREATE OR REPLACE FUNCTION public._segmento_cliente(p_pedidos int, p_total numeric, p_ultimo timestamptz, p_dias_risco int DEFAULT 45)
 RETURNS text
 LANGUAGE sql
 STABLE
 SET search_path TO 'public'
AS $function$
  select case
    when coalesce(p_pedidos,0) = 0 then 'Sem pedido'
    when p_ultimo < now() - (greatest(coalesce(p_dias_risco,45),1) || ' days')::interval then 'Em risco'
    when p_pedidos >= 10 or coalesce(p_total,0) >= 800 then 'VIP'
    when p_pedidos >= 4 then 'Fiel'
    else 'Novo' end
$function$;
revoke all on function public._segmento_cliente(int, numeric, timestamptz, int) from public, anon, authenticated;

CREATE OR REPLACE FUNCTION public.api_cliente_360(p_telefone text DEFAULT ''::text, p_cliente_id uuid DEFAULT NULL::uuid, p_dias_risco int DEFAULT 45)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_tel text := _so_digitos(coalesce(p_telefone,''));
  v_cli uuid := p_cliente_id;
  r jsonb;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if v_cli is null and length(v_tel) >= 8 then
    select c.id into v_cli from clientes c where _so_digitos(c.telefone) = v_tel limit 1;
  end if;
  if length(v_tel) < 8 and v_cli is null then
    return jsonb_build_object('ok', true, 'pedidos', 0, 'segmento', 'Sem pedido');
  end if;

  with ped as (
    select v.id, v.data_hora, v.valor_total, v.tipo::text as tipo, coalesce(v.forma_pagamento,'') as forma, false as arq
      from vendas v
     where v.status = 'Confirmada'
       and ((length(v_tel) >= 8 and _so_digitos(v.telefone_cliente) = v_tel) or (v_cli is not null and v.cliente_id = v_cli))
    union all
    select s.venda_id, s.data_hora, s.valor_total, s.tipo, coalesce(s.forma_pagamento,''), true
      from vendas_resumo_arquivo s
     where s.status = 'Confirmada'
       and ((length(v_tel) >= 8 and s.telefone = v_tel) or (v_cli is not null and s.cliente_id = v_cli))
  ),
  est as (
    select count(*)::int n, coalesce(sum(valor_total),0) total, min(data_hora) primeiro, max(data_hora) ultimo,
           count(*) filter (where data_hora >= now() - interval '90 days')::int n90,
           coalesce(sum(valor_total) filter (where data_hora >= now() - interval '90 days'),0) total90,
           count(*) filter (where arq)::int n_arq
      from ped
  ),
  it as (
    select coalesce(i.descricao,'(item)') d, i.quantidade q
      from itens_venda i join ped p on p.id = i.venda_id and not p.arq
    union all
    select coalesce(e->>'descricao','(item)'), coalesce((e->>'quantidade')::int, 1)
      from vendas_resumo_arquivo s
      join ped p on p.id = s.venda_id and p.arq
      cross join lateral jsonb_array_elements(case when jsonb_typeof(s.itens) = 'array' then s.itens else '[]'::jsonb end) e
  ),
  fav as (
    select coalesce(jsonb_agg(jsonb_build_object('item', d, 'qtd', q) order by q desc, d), '[]'::jsonb) lista
      from (select d, sum(q)::int q from it group by d order by sum(q) desc, d limit 3) x
  ),
  tipo_pref as (select tipo from ped group by tipo order by count(*) desc, tipo limit 1),
  forma_pref as (select forma from ped where forma <> '' group by forma order by count(*) desc, forma limit 1),
  conta as (
    select cc.user_id, cc.promo_ok, cc.promo_em, cc.ultimo_acesso, cc.criado_em
      from contas_cliente cc
     where (v_cli is not null and cc.cliente_id = v_cli)
        or (length(v_tel) >= 8 and cc.telefone <> '' and _so_digitos(cc.telefone) = v_tel)
     order by cc.ultimo_acesso desc nulls last limit 1
  )
  select jsonb_build_object(
    'ok', true,
    'telefone', v_tel,
    'clienteId', v_cli,
    'pedidos', est.n,
    'pedidosArquivados', est.n_arq,
    'totalGasto', est.total,
    'ticketMedio', case when est.n > 0 then round(est.total / est.n, 2) else 0 end,
    'primeiroPedido', est.primeiro,
    'ultimoPedido', est.ultimo,
    'diasDesdeUltimo', case when est.ultimo is null then null else floor(extract(epoch from (now() - est.ultimo)) / 86400)::int end,
    'frequenciaDias', case when est.n >= 2 then round((extract(epoch from (est.ultimo - est.primeiro)) / 86400 / (est.n - 1))::numeric, 1) else null end,
    'pedidos90d', est.n90,
    'gasto90d', est.total90,
    'itensFavoritos', fav.lista,
    'tipoPreferido', (select tipo from tipo_pref),
    'formaPreferida', (select forma from forma_pref),
    'segmento', _segmento_cliente(est.n, est.total, est.ultimo, p_dias_risco),
    'diasRisco', greatest(coalesce(p_dias_risco,45),1),
    'conta', case when exists (select 1 from conta) then
               (select jsonb_build_object('temConta', true, 'aceitaPromocoes', coalesce(c.promo_ok,false), 'aceitouEm', c.promo_em,
                                          'ultimoAcesso', c.ultimo_acesso, 'criadaEm', c.criado_em) from conta c)
             else jsonb_build_object('temConta', false, 'aceitaPromocoes', false) end,
    'carimbos', (select f.carimbos from fidelidade f where v_cli is not null and f.cliente_id = v_cli limit 1)
  ) into r
  from est, fav;

  return r;
end $function$;

CREATE OR REPLACE FUNCTION public.api_clientes_segmentos(p_dias_risco int DEFAULT 45)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'diasRisco', greatest(coalesce(p_dias_risco,45),1), 'clientes', coalesce((
    with base as (
      select _so_digitos(v.telefone_cliente) tel, v.valor_total, v.data_hora
        from vendas v where v.status = 'Confirmada' and length(_so_digitos(v.telefone_cliente)) >= 8
      union all
      select s.telefone, s.valor_total, s.data_hora
        from vendas_resumo_arquivo s where s.status = 'Confirmada' and length(s.telefone) >= 8
    ),
    agg as (select tel, count(*)::int n, sum(valor_total) total, max(data_hora) ultimo from base group by tel)
    select jsonb_agg(jsonb_build_object(
             'telefone', a.tel, 'pedidos', a.n, 'total', a.total, 'ultimo', a.ultimo,
             'segmento', _segmento_cliente(a.n, a.total, a.ultimo, p_dias_risco),
             'temConta', exists (select 1 from contas_cliente cc where cc.telefone <> '' and _so_digitos(cc.telefone) = a.tel),
             'aceitaPromocoes', exists (select 1 from contas_cliente cc where cc.promo_ok and cc.telefone <> '' and _so_digitos(cc.telefone) = a.tel)))
      from agg a), '[]'::jsonb));
end $function$;

grant execute on function public.api_cliente_360(text, uuid, int) to authenticated;
grant execute on function public.api_clientes_segmentos(int) to authenticated;
revoke all on function public.api_cliente_360(text, uuid, int) from public, anon;
revoke all on function public.api_clientes_segmentos(int) from public, anon;
