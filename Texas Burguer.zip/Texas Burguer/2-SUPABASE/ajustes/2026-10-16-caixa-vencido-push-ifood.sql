-- JÁ APLICADO no Supabase em 16/10/2026 (migração caixa_vencido_push_ifood). Só rode de novo se refizer o banco.
CREATE OR REPLACE FUNCTION public._ifood_trg_novo()
 RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare v_venc boolean;
begin
  begin v_venc := coalesce(_caixa_vencido(_caixa_aberto_id()), false); exception when others then v_venc := false; end;
  perform _push_enviar('pedido', '🛵 Novo pedido iFood #' || coalesce(new.numero_pedido::text, ''),
    coalesce(new.tipo::text, '') || ' · R$ ' || replace(to_char(coalesce(new.valor_total, 0), 'FM9999990.00'), '.', ',')
      || case when v_venc then ' · ⚠️ caixa vencido: aceite e feche o caixa' else '' end,
    'pedido-' || new.id::text);
  return null;
exception when others then return null;
end $function$;
