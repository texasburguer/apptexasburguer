-- FASE 5b · push das campanhas (Em risco / VIP) + preferências fixas do cliente · seguro para rodar de novo
-- JÁ APLICADO no Supabase em 16/10/2026 (migração "clientes_fase5b_push_campanhas_e_preferencias").
alter table public.clientes add column if not exists preferencias text;
alter table public.vendas add column if not exists preferencias_cliente text;

create or replace function public._trg_vendas_preferencias()
 returns trigger language plpgsql security definer set search_path to 'public'
as $f$
declare v_pref text;
begin
  if coalesce(new.preferencias_cliente, '') <> '' then return new; end if;
  select c.preferencias into v_pref from clientes c
   where coalesce(c.preferencias, '') <> ''
     and ((new.cliente_id is not null and c.id = new.cliente_id)
          or (length(_so_digitos(new.telefone_cliente)) >= 8 and _so_digitos(c.telefone) = _so_digitos(new.telefone_cliente)))
   limit 1;
  new.preferencias_cliente := v_pref;
  return new;
end $f$;
revoke all on function public._trg_vendas_preferencias() from public, anon, authenticated;
drop trigger if exists trg_vendas_preferencias on public.vendas;
create trigger trg_vendas_preferencias before insert on public.vendas
  for each row execute function public._trg_vendas_preferencias();

create or replace function public.api_conta_preferencias(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public'
as $f$
declare c contas_cliente := _conta_exigir(); v_cli uuid; v_txt text;
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  if length(_so_digitos(c.telefone)) < 8 then return _falha('Cadastre o seu telefone na conta para guardar preferências.'); end if;
  v_cli := coalesce(c.cliente_id, _upsert_cliente(c.telefone, c.nome));
  if p ? 'texto' then
    v_txt := _texto_publico(p->>'texto', 300);
    update clientes set preferencias = nullif(v_txt, '') where id = v_cli;
  end if;
  select preferencias into v_txt from clientes where id = v_cli;
  return jsonb_build_object('ok', true, 'preferencias', coalesce(v_txt, ''));
end $f$;
revoke all on function public.api_conta_preferencias(jsonb) from public, anon;
grant execute on function public.api_conta_preferencias(jsonb) to authenticated;

create or replace function public.api_cliente_preferencias(p_cliente uuid, p_texto text)
 returns jsonb language plpgsql security definer set search_path to 'public'
as $f$
declare v_txt text := _texto_publico(p_texto, 300);
begin
  if auth_nivel() is null or auth_nivel()::text not in ('Admin', 'Operador') then return _falha('Sem permissão.'); end if;
  update clientes set preferencias = nullif(v_txt, '') where id = p_cliente;
  if not found then return _falha('Cliente não encontrado.'); end if;
  return jsonb_build_object('ok', true, 'preferencias', v_txt);
end $f$;
revoke all on function public.api_cliente_preferencias(uuid, text) from public, anon;
grant execute on function public.api_cliente_preferencias(uuid, text) to authenticated;

create or replace view public.v_vendas as
 SELECT id, numero_pedido AS numero, data_hora, cliente_nome, telefone_cliente AS cliente_telefone, forma_pagamento, valor_total,
        CASE WHEN (auth_nivel() = ANY (ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso])) THEN custo_total ELSE NULL::numeric END AS custo_total,
        status, motivo_cancelamento, tipo AS tipo_entrega, status_pedido, endereco, complemento, referencia, observacoes_entrega,
        pronta_em, concluida_em, status_pagamento, recebido_em, valor_original, valor_desconto, desconto_detalhe,
        _login_de(entregador_id) AS entregador, saiu_em, origem, mesa_id, taxa_entrega, fechamento_entrega_id,
        _login_de(registrado_por) AS registrado_por, inicio_preparo_em, _mesa_numero_de(mesa_id) AS mesa_numero, acrescimo_forma,
        preferencias_cliente
   FROM vendas v;

create or replace function public._push_campanha_conta(p_user uuid, p_titulo text, p_texto text, p_tag text)
 returns void language plpgsql security definer set search_path to 'public'
as $f$
declare v_venda uuid;
begin
  select v.id into v_venda
    from contas_cliente c
    join vendas v on ((c.cliente_id is not null and v.cliente_id = c.cliente_id)
                      or (length(_so_digitos(c.telefone)) >= 8 and _so_digitos(v.telefone_cliente) = _so_digitos(c.telefone)))
    join push_cliente_pedidos l on l.venda_id = v.id
   where c.user_id = p_user
   order by v.data_hora desc limit 1;
  if v_venda is not null then
    perform _push_cliente_enviar(v_venda, p_titulo, p_texto, './', p_tag || '-' || p_user::text);
  end if;
exception when others then null;
end $f$;
revoke all on function public._push_campanha_conta(uuid, text, text, text) from public, anon, authenticated;

create or replace function public._job_campanhas()
 returns jsonb language plpgsql security definer set search_path to 'public'
as $f$
declare r record; n_risco int := 0; n_vip int := 0; hoje date := _hoje_br();
  v_tri text := extract(year from _hoje_br())::int || '-Q' || extract(quarter from _hoje_br())::int;
begin
  for r in select * from _campanha_candidatos() where segmento in ('Em risco', 'VIP') loop
    if r.segmento = 'Em risco' then
      if not exists (select 1 from cupons_concedidos cc where cc.user_id = r.user_id and cc.origem = 'em_risco' and cc.criado_em > now() - interval '60 days')
         and _conceder_cupom_auto('em_risco', r.user_id, hoje::text) then
        n_risco := n_risco + 1;
        perform _push_campanha_conta(r.user_id, '💌 Sentimos sua falta!', 'Um cupom do Texas Burger está esperando por você em Minha conta › Cupons.', 'campanha-risco');
      end if;
    else
      if _conceder_cupom_auto('vip', r.user_id, v_tri) then
        n_vip := n_vip + 1;
        perform _push_campanha_conta(r.user_id, '⭐ Cupom VIP para você', 'Obrigado por ser cliente VIP! Seu cupom está em Minha conta › Cupons.', 'campanha-vip');
      end if;
    end if;
  end loop;
  return jsonb_build_object('emRisco', n_risco, 'vip', n_vip);
end $f$;
revoke all on function public._job_campanhas() from public, anon, authenticated;
