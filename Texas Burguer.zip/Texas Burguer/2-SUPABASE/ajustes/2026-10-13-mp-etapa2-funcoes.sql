-- =====================================================================================
-- MERCADO PAGO · ETAPA 2 (funções do banco) · 2026-10-13 · NÃO APLICADO
-- Rode DEPOIS da Etapa 1 (2026-10-13-mp-etapa1-estrutura.sql). Pode rodar de novo (idempotente).
-- Cole inteiro no SQL Editor do Supabase. Para conferir depois, rode testes/teste-mp-etapa2.sql.
-- Com a integração DESLIGADA nada muda: o pedido normal do cardápio continua idêntico ao de hoje.
-- Nenhum "delete from" dentro de função (o conector do Supabase cancela): reserva desfeita = marcada, não apagada.
-- =====================================================================================
begin;

-- ---------- 1) Cupom reservado e depois desfeito: a linha fica "anulada" e deixa de contar no limite ----------
alter table public.cupons_usos add column if not exists anulado boolean not null default false;

-- ---------- 2) Cálculo do cupom: versão mais recente (contas-clientes), só com "and not cu.anulado" no limite de usos ----------
CREATE OR REPLACE FUNCTION public._cupom_calcular(p_codigo text, p_tel text, p_subtotal numeric, p_tipo text, p_user uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c cupons%rowtype; v_cod text := upper(regexp_replace(btrim(coalesce(p_codigo, '')), '\s+', '', 'g'));
  v_tel text := _so_digitos(p_tel); v_bruto numeric := round(coalesce(p_subtotal, 0), 2); v_desc numeric := 0;
  v_agora timestamp := now() at time zone 'America/Sao_Paulo'; v_hh int; v_hi int; v_hf int; v_usos int; v_usos_cli int; v_fx record;
  v_conta contas_cliente; v_cc cupons_concedidos;
begin
  if v_cod = '' then return _falha('Informe um cupom.'); end if;
  select * into c from cupons where codigo = v_cod and ativa;
  if not found then return _falha('Cupom inválido ou inativo.'); end if;
  if p_user is not null then select * into v_conta from contas_cliente where user_id = p_user and aceite_versao > 0; end if;
  if (c.somente_conta or c.automatico is not null or c.cliente_id is not null) and v_conta.user_id is null then
    return _falha('Este cupom é para quem tem conta. Entre com a sua conta Google para usar.');
  end if;
  if c.cliente_id is not null and v_conta.cliente_id is distinct from c.cliente_id then
    return _falha('Este cupom não está disponível para a sua conta.');
  end if;
  if (c.data_inicio is not null and v_agora::date < c.data_inicio) or (c.data_fim is not null and v_agora::date > c.data_fim) then
    return _falha('Este cupom está fora do período de validade.');
  end if;
  if c.hora_inicio is not null and c.hora_fim is not null then
    v_hh := extract(hour from v_agora)::int * 60 + extract(minute from v_agora)::int;
    v_hi := extract(hour from c.hora_inicio)::int * 60 + extract(minute from c.hora_inicio)::int;
    v_hf := extract(hour from c.hora_fim)::int * 60 + extract(minute from c.hora_fim)::int;
    if v_hi <= v_hf then
      if v_hh < v_hi or v_hh > v_hf then return _falha('Este cupom está fora do período de validade.'); end if;
    else
      if v_hh < v_hi and v_hh > v_hf then return _falha('Este cupom está fora do período de validade.'); end if;
    end if;
  end if;
  if c.automatico is not null then
    select * into v_cc from cupons_concedidos
     where cupom_id = c.id and user_id = p_user and usado_em is null and (valido_ate is null or valido_ate >= v_agora::date)
     order by valido_ate nulls last, criado_em limit 1;
    if not found then return _falha('Você não tem este cupom disponível (ou ele já venceu).'); end if;
  end if;
  select count(*), count(*) filter (where (v_tel <> '' and _so_digitos(cu.telefone) = v_tel) or (p_user is not null and cu.user_id = p_user))
    into v_usos, v_usos_cli from cupons_usos cu where cu.cupom_id = c.id and not cu.anulado and not exists (select 1 from vendas vv where vv.id = cu.venda_id and vv.status = 'Cancelada');
  if c.limite_total > 0 and v_usos >= c.limite_total then return _falha('O limite de utilizações deste cupom foi atingido.'); end if;
  if c.automatico in ('boas_vindas', 'indicacao_indicado') then
    if v_usos_cli > 0 then return _falha('Este cupom já foi usado (uma vez por cliente).'); end if;
  elsif c.automatico is null and c.limite_por_cliente > 0 and v_usos_cli >= c.limite_por_cliente then
    return _falha('Você já atingiu o limite de uso deste cupom.');
  end if;
  if v_bruto < c.valor_minimo then return _falha('Este cupom exige pedido mínimo de R$ ' || replace(_dinheiro(c.valor_minimo), '.', ',') || '.'); end if;
  if c.tipo = 'percentual' then
    if c.valor <= 0 or c.valor > 100 then return _falha('Cupom configurado com percentual inválido.'); end if;
    v_desc := round(v_bruto * c.valor / 100, 2);
  elsif c.tipo = 'fixo' then
    if c.valor <= 0 then return _falha('Cupom configurado com valor inválido.'); end if;
    v_desc := least(v_bruto, round(c.valor, 2));
  elsif c.tipo = 'progressivo' then
    select (x->>'minimo')::numeric mn, (x->>'desconto')::numeric ds into v_fx from jsonb_array_elements(c.faixas) x where (x->>'minimo')::numeric <= v_bruto order by (x->>'minimo')::numeric desc limit 1;
    if v_fx.mn is null then
      select min((x->>'minimo')::numeric) into v_fx.mn from jsonb_array_elements(c.faixas) x;
      return _falha('Este cupom vale a partir de R$ ' || replace(_dinheiro(coalesce(v_fx.mn, 0)), '.', ',') || ' em pedidos.');
    end if;
    v_desc := least(v_bruto, round(v_fx.ds, 2));
  elsif c.tipo = 'frete' then
    v_desc := 0;
  else
    return _falha('Tipo de cupom não suportado.');
  end if;
  v_desc := round(least(v_desc, greatest(0, v_bruto - 0.01)), 2);
  return jsonb_build_object('ok', true, 'cupomId', c.id, 'codigo', c.codigo, 'nome', c.nome, 'tipo', c.tipo, 'desconto', v_desc,
    'freteGratis', (c.frete_gratis or c.tipo = 'frete'), 'acumula', c.acumula,
    'limiteRestante', case when c.limite_total > 0 then greatest(0, c.limite_total - v_usos - 1) else null end);
end $function$
;

-- ---------- 3) Reservar e soltar (estoque, cupom e brinde) ----------
-- _mp_prender: faz a baixa do estoque e marca cupom e brindes como usados, SEM criar a venda.
--   p_forcar = false: o pedido acabou de ser validado, então qualquer falha aqui é erro (desfaz tudo).
--   p_forcar = true: usado quando o operador decide "seguir" com um pagamento já aprovado: aplica o que der, sem barrar por limite/estoque.
create or replace function public._mp_prender(p_reserva uuid, p_forcar boolean default false) returns void
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; rec record; v_cup jsonb; v_uso uuid; v_cc uuid; v_novo jsonb := '[]'::jsonb;
        v_cli uuid; v_fid fidelidade%rowtype; v_bid uuid; v_tipo text; v_prod uuid;
begin
  select * into r from pedidos_reserva where id = p_reserva for update;
  if not found then raise exception 'Reserva não encontrada.'; end if;

  if not r.estoque_reservado then perform _ajustar_estoque(r.itens, 1, null); end if;

  v_cup := r.cupom; v_uso := r.cupom_uso_id;
  if v_cup is not null and v_uso is null then
    insert into cupons_usos (cupom_id, codigo, venda_id, cliente_id, telefone, desconto, frete_gratis, requisicao_id, user_id)
    values ((v_cup->>'cupomId')::uuid, v_cup->>'codigo', null, null, r.telefone, coalesce((v_cup->>'desconto')::numeric, 0),
            coalesce((v_cup->>'freteGratis')::boolean, false), r.requisicao_id, r.user_id)
    returning id into v_uso;
    -- cupom automático da conta (boas-vindas, aniversário, indicação): segura o cupom recebido enquanto a reserva existir
    select id into v_cc from cupons_concedidos
     where cupom_id = (v_cup->>'cupomId')::uuid and user_id = r.user_id and usado_em is null and (valido_ate is null or valido_ate >= _hoje_br())
     order by valido_ate nulls last, criado_em limit 1 for update;
    if v_cc is not null then update cupons_concedidos set usado_em = now(), venda_id = null where id = v_cc; end if;
    v_cup := v_cup || jsonb_build_object('concedidoId', v_cc);
  end if;

  for rec in select value as e from jsonb_array_elements(r.beneficios) loop
    v_tipo := rec.e->>'tipo'; v_prod := _uuid(rec.e->>'produtoId'); v_bid := _uuid(rec.e->>'id');
    if v_tipo = 'Fidelidade' then
      select cc.cliente_id into v_cli from contas_cliente cc where cc.user_id = r.user_id;
      select * into v_fid from fidelidade where cliente_id = v_cli for update;
      if v_fid.id is not null and v_fid.carimbos >= 10 then
        update fidelidade set carimbos = 0, premios_resgatados = premios_resgatados + 1, atualizada_em = now() where cliente_id = v_cli;
        insert into contas_beneficios (user_id, tipo, status, produto_id, venda_id, usado_em) values (r.user_id, 'Fidelidade', 'Usado', v_prod, null, now())
          returning id into v_bid;
      elsif not p_forcar then
        raise exception 'O cartão fidelidade não está completo.';
      else
        v_bid := null;   -- seguiu à força: o item sai a R$ 0, mas o cartão não é mexido
      end if;
    elsif v_tipo = 'Indicação' then
      update contas_beneficios set status = 'Usado', produto_id = v_prod, usado_em = now()
       where id = v_bid and user_id = r.user_id and status = 'Disponível';
      if not found then
        if not p_forcar then raise exception 'O brinde de indicação não está mais disponível.'; end if;
        v_bid := null;
      end if;
    end if;
    v_novo := v_novo || jsonb_build_array(jsonb_build_object('tipo', v_tipo, 'id', v_bid, 'produtoId', v_prod));
  end loop;

  update pedidos_reserva set estoque_reservado = true, cupom = v_cup, cupom_uso_id = v_uso, beneficios = v_novo,
         brindes_reservados = jsonb_array_length(v_novo) > 0, atualizado_em = now()
   where id = r.id;
end $f$;

-- _mp_soltar: devolve estoque, cupom e brindes e marca a reserva com o estado final (expirada ou cancelada). Nada é apagado.
create or replace function public._mp_soltar(p_reserva uuid, p_estado text, p_motivo text) returns void
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; rec record; v_cc uuid; v_cli uuid;
begin
  if p_estado not in ('expirada', 'cancelada') then raise exception 'Estado final inválido.'; end if;
  select * into r from pedidos_reserva where id = p_reserva for update;
  if not found or r.estado not in ('ativa', 'expirada', 'cancelada') then return; end if;   -- reserva já confirmada nunca é solta

  if r.estoque_reservado then perform _ajustar_estoque(r.itens, -1, null); end if;
  if r.cupom_uso_id is not null then update cupons_usos set anulado = true where id = r.cupom_uso_id and venda_id is null; end if;
  v_cc := _uuid(r.cupom->>'concedidoId');
  if v_cc is not null then update cupons_concedidos set usado_em = null, venda_id = null where id = v_cc and venda_id is null; end if;

  for rec in select value as e from jsonb_array_elements(r.beneficios) loop
    if _uuid(rec.e->>'id') is null then continue; end if;
    if rec.e->>'tipo' = 'Indicação' then
      update contas_beneficios set status = 'Disponível', venda_id = null, usado_em = null, produto_id = null
       where id = _uuid(rec.e->>'id') and venda_id is null and status = 'Usado';
    elsif rec.e->>'tipo' = 'Fidelidade' then
      update contas_beneficios set status = 'Anulado' where id = _uuid(rec.e->>'id') and venda_id is null and status = 'Usado';
      if found then
        select cc.cliente_id into v_cli from contas_cliente cc where cc.user_id = r.user_id;
        update fidelidade set carimbos = 10, premios_resgatados = greatest(0, premios_resgatados - 1), atualizada_em = now() where cliente_id = v_cli;
      end if;
    end if;
  end loop;

  update pedidos_reserva set estado = p_estado, motivo_fim = left(coalesce(p_motivo, ''), 200), estoque_reservado = false, brindes_reservados = false,
         cupom_uso_id = null, cupom = case when cupom is null then null else cupom - 'concedidoId' end, atualizado_em = now()
   where id = r.id;
end $f$;

-- ---------- 4) Pedido do cardápio: versão mais recente (contas-brindes) + modo reserva (p_reserva = true). Com false é IDÊNTICO ao de hoje ----------
CREATE OR REPLACE FUNCTION public._criar_pedido_publico(p jsonb, p_mesa_id uuid, p_reserva boolean)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_eh_mesa boolean := p_mesa_id is not null; v_mesa mesas%rowtype;
  v_nome text := _texto_publico(p->>'clienteNome', 80);
  v_tel text := case when p_mesa_id is not null then '' else _texto_publico(p->>'clienteTelefone', 20) end;
  v_dig text := case when p_mesa_id is not null then '' else _so_digitos(p->>'clienteTelefone') end;
  v_obs_troco text := _texto_publico(p->>'observacaoTroco', 200);
  v_de jsonb := case when jsonb_typeof(p->'dadosEntrega') = 'object' then p->'dadosEntrega' else '{}'::jsonb end;
  v_end text := _texto_publico(v_de->>'endereco', 200); v_comp text := _texto_publico(v_de->>'complemento', 100); v_ref text := _texto_publico(v_de->>'referencia', 150);
  v_obs_ent text := _texto_publico(coalesce(nullif(p->>'observacoes', ''), v_de->>'observacoes'), 300);
  v_itens jsonb := p->'itens'; v_tipo_in text := p->>'tipoEntrega'; v_ip text := _ip_cliente();
  v_req text := nullif(left(btrim(coalesce(p->>'requisicaoId', '')), 80), '');
  v_forma formas_pagamento%rowtype; v_caixa uuid; v_tipo venda_tipo; v_ja record; v_prod produtos%rowtype; v_comb combos%rowtype;
  it record; r record; v_prod_id uuid; v_comb_id uuid; v_qtd numeric; v_preco numeric; v_custo_u numeric; v_nome_item text; v_extra numeric; v_n_ad int; v_n_ok int;
  v_ads text; v_obs_item text; v_ads_ids jsonb; v_itens_ok jsonb := '[]'::jsonb; v_orig numeric := 0; v_custo numeric := 0;
  v_cod text := ''; v_cup jsonb; v_desc numeric := 0; v_frete boolean := false; v_taxa numeric := 0; v_pad numeric; v_total numeric;
  v_venda uuid := gen_random_uuid(); v_numero int; v_cli uuid; v_chave text; v_obs_final text; v_bloqueia boolean; v_forma_nome text; v_acr numeric := 0; v_bloq text; v_user uuid := (select cc.user_id from contas_cliente cc where cc.user_id = auth.uid() and cc.aceite_versao > 0);
  v_ben jsonb := case when jsonb_typeof(p->'beneficios') = 'array' then p->'beneficios' else '[]'::jsonb end;
  b record; v_bens jsonb := '[]'::jsonb; v_bc contas_cliente; v_fid fidelidade%rowtype; v_bid uuid; v_pb produtos%rowtype; v_btipo text;
  v_res uuid; v_min int; v_cfg integracoes_config%rowtype; v_ja_res record;
begin
  -- Mercado Pago (p_reserva = true): valida tudo igual ao pedido normal, mas em vez de criar a venda guarda uma RESERVA até o pagamento ser aprovado
  if p_reserva then
    if p_mesa_id is not null then return _falha('Mesas e balcão não pagam pelo site.'); end if;
    if v_user is null then return _falha('Entre com a sua conta para pagar pelo site.'); end if;
    if v_req is null then return _falha('Não foi possível identificar esta tentativa. Atualize a página e tente de novo.'); end if;
    if coalesce((public.api_mp_config_publica('{}'::jsonb)->>'ligado')::boolean, false) is not true then
      return _falha('O pagamento pelo site não está disponível agora. Escolha pagar na entrega.');
    end if;
    perform pg_advisory_xact_lock(hashtext('reserva:' || v_req));
    select id, estado, valor_total, expira_em into v_ja_res from pedidos_reserva where requisicao_id = v_req;
    if found then
      return jsonb_build_object('ok', true, 'duplicado', true, 'reservaId', v_ja_res.id, 'estado', v_ja_res.estado,
        'valorTotal', v_ja_res.valor_total, 'expiraEm', v_ja_res.expira_em, 'message', 'Pedido já recebido — envio repetido ignorado.');
    end if;
  end if;

  -- repetição do mesmo envio (duplo toque, nova tentativa): devolve o pedido já criado, sem criar outro
  if v_req is not null and not p_reserva then
    perform pg_advisory_xact_lock(hashtext('venda:' || v_req));
    select id, numero_pedido, valor_total into v_ja from vendas where requisicao_id = v_req;
    if found then
      return jsonb_build_object('ok', true, 'duplicado', true, 'id', v_ja.id, 'numero', v_ja.numero_pedido, 'valorTotal', v_ja.valor_total, 'message', 'Pedido já recebido — envio repetido ignorado.');
    end if;
  end if;

  if jsonb_typeof(v_itens) <> 'array' then return _falha('Carrinho vazio.'); end if;
  if jsonb_array_length(v_itens) = 0 and (p_mesa_id is not null or jsonb_array_length(v_ben) = 0) then return _falha('Carrinho vazio.'); end if;
  if jsonb_array_length(v_itens) > 40 then return _falha('Carrinho grande demais.'); end if;
  if v_eh_mesa then
    if v_nome = '' then return _falha('Informe o seu nome.'); end if;
    v_chave := 'pedmesa_' || p_mesa_id::text;
  else
    if v_nome = '' or v_dig = '' then return _falha('Informe nome e telefone.'); end if;
    if length(v_dig) < 10 or length(v_dig) > 13 then return _falha('Informe um telefone válido com DDD.'); end if;
    v_chave := 'pedcard_' || v_dig;
  end if;
  if _excedeu('pedcard_global', 150) then return _falha('Estamos com muitos pedidos no momento. Tente novamente em alguns minutos ou ligue para o restaurante.'); end if;
  if _excedeu('pedcard_ip_' || v_ip, 40) then return _falha('Muitos pedidos em sequência deste local. Aguarde alguns minutos.'); end if;
  if _excedeu(v_chave, case when v_eh_mesa then 8 else 5 end) then
    return _falha(case when v_eh_mesa then 'Muitos pedidos em sequência nesta mesa. Chame o garçom.' else 'Muitos pedidos em sequência. Aguarde alguns minutos.' end);
  end if;

  -- cardápio fechado à mão ou em período programado (pedido de mesa, feito dentro do restaurante, não é bloqueado)
  if not v_eh_mesa then
    v_bloq := _cardapio_bloqueio();
    if v_bloq is not null then return _falha(v_bloq); end if;
  end if;
  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;
  if v_caixa is null then return _falha('Estamos fechados no momento. Tente novamente mais tarde.'); end if;

  if v_eh_mesa then
    select * into v_mesa from mesas where id = p_mesa_id for update;
    if not found then return _falha('Mesa não encontrada.'); end if;
    if v_mesa.status::text not in ('Livre', 'Ocupada') then
      return _falha(case when v_mesa.status::text = 'Aguardando fechamento' then 'A conta desta mesa já foi pedida. Chame o garçom para novos pedidos.' else 'Esta mesa não está disponível para pedidos pelo celular. Chame o garçom.' end);
    end if;
    v_tipo := 'Mesa';
    -- mesa: o cliente não escolhe a forma; vale a primeira forma do cardápio só para o preço (o recebimento é feito no fechamento da conta)
    select * into v_forma from formas_pagamento where ativa and visivel_cardapio order by ordem limit 1;
    v_forma_nome := 'A Receber (Mesa)';
  else
    v_tipo := (case when v_tipo_in = 'Entrega' then 'Entrega' else 'Retirada' end)::venda_tipo;
    if v_tipo = 'Entrega' and v_end = '' then return _falha('Informe o endereço de entrega.'); end if;
    if v_tipo = 'Entrega' then
      declare v_num text := _texto_publico(v_de->>'numero', 20); v_cid text := _texto_publico(v_de->>'cidade', 80);
              v_cid_loc text := _texto_publico(v_de->>'cidadeLocalizacao', 80); v_lista jsonb; v_nomes text;
      begin
        if v_de ? 'numero' and v_num = '' then return _falha('Informe o número da casa (ou "s/n").'); end if;
        if v_de ? 'cidade' and v_cid = '' then return _falha('Informe a cidade da entrega.'); end if;
        if v_num <> '' then v_end := left(v_end || ', nº ' || v_num, 200); end if;
        if v_cid <> '' then v_end := left(v_end || ' — ' || v_cid, 200); end if;
      end;
    end if;
    select * into v_forma from formas_pagamento where id = _uuid(p->>'formaPagamentoId') and ativa and visivel_cardapio;
    v_forma_nome := v_forma.nome;
  end if;
  if v_forma.id is null then return _falha('Forma de pagamento inválida.'); end if;
  if p_reserva and not (v_forma.aceita_online and v_forma.tipo_online is not null) then return _falha('Esta forma de pagamento não é aceita pelo site.'); end if;

  -- itens: tudo vem do cadastro (produto/combo ativo, preço da forma escolhida, adicionais ativos e vinculados)
  for it in select value as e from jsonb_array_elements(v_itens) loop
    v_qtd := _num(it.e->>'quantidade');
    if v_qtd <= 0 then continue; end if;
    if v_qtd > 50 or v_qtd <> floor(v_qtd) then return _falha('Quantidade inválida no carrinho.'); end if;
    v_prod_id := _uuid(it.e->>'produtoId'); v_comb_id := _uuid(it.e->>'comboId');
    if (v_prod_id is null) = (v_comb_id is null) then return _falha('Item inválido no carrinho.'); end if;
    if jsonb_typeof(it.e->'adicionaisIds') = 'array' and jsonb_array_length(it.e->'adicionaisIds') > 20 then return _falha('Adicionais demais em um item.'); end if;
    if v_prod_id is not null then
      select * into v_prod from produtos where id = v_prod_id and ativo;
      if not found then return _falha('Um dos produtos não está mais disponível.'); end if;
      v_nome_item := v_prod.nome;
      select preco, custo into v_preco, v_custo_u from produto_precos where produto_id = v_prod_id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_nome_item || '" não tem preço configurado para essa forma de pagamento.'); end if;
    else
      select * into v_comb from combos where id = v_comb_id and ativo;
      if not found then return _falha('Um dos combos não está mais disponível.'); end if;
      if exists (select 1 from combo_itens ci join produtos pr on pr.id = ci.produto_id where ci.combo_id = v_comb_id and not pr.ativo) then
        return _falha('O combo "' || v_comb.nome || '" está temporariamente indisponível.');
      end if;
      v_nome_item := v_comb.nome;
      select preco, custo into v_preco, v_custo_u from combo_precos where combo_id = v_comb_id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_nome_item || '" não tem preço configurado para essa forma de pagamento.'); end if;
    end if;
    select count(*), coalesce(sum(a.preco), 0),
           count(a.id) filter (where a.ativo and ((v_prod_id is not null and exists (select 1 from produto_adicionais pa where pa.produto_id = v_prod_id and pa.adicional_id = a.id)) or (v_comb_id is not null and exists (select 1 from combo_itens ci join produto_adicionais pa on pa.produto_id = ci.produto_id where ci.combo_id = v_comb_id and pa.adicional_id = a.id)))),
           coalesce(string_agg(' + ' || a.nome, '' order by s.ord) filter (where a.id is not null), ''),
           coalesce(jsonb_agg(a.id order by s.ord) filter (where a.id is not null), '[]'::jsonb)
      into v_n_ad, v_extra, v_n_ok, v_ads, v_ads_ids
      from jsonb_array_elements_text(case when jsonb_typeof(it.e->'adicionaisIds') = 'array' then it.e->'adicionaisIds' else '[]'::jsonb end) with ordinality as s(x, ord)
      left join adicionais a on a.id = _uuid(s.x);
    if v_n_ad <> v_n_ok then return _falha('Um adicional escolhido para "' || v_nome_item || '" não está disponível.'); end if;
    v_obs_item := _texto_publico(it.e->>'observacao', 100);
    v_itens_ok := v_itens_ok || jsonb_build_array(jsonb_build_object('produtoId', v_prod_id, 'comboId', v_comb_id,
      'descricao', v_nome_item || v_ads || case when v_obs_item <> '' then ' — Obs: ' || v_obs_item else '' end,
      'quantidade', v_qtd, 'valorUnitario', v_preco + v_extra, 'custoUnitario', v_custo_u, 'adicionaisIds', v_ads_ids));
    v_orig := v_orig + round(v_qtd * (v_preco + v_extra), 2); v_custo := v_custo + v_qtd * v_custo_u;
  end loop;
  if jsonb_array_length(v_itens_ok) = 0 and jsonb_array_length(v_ben) = 0 then return _falha('Carrinho vazio.'); end if;
  -- brindes da conta (cartão fidelidade e indicação): entram como item de R$ 0, com custo e baixa no estoque
  if jsonb_array_length(v_ben) > 0 then
    if v_eh_mesa or v_user is null then return _falha('Entre com a sua conta para resgatar o brinde.'); end if;
    if jsonb_array_length(v_ben) > 5 then return _falha('Brindes demais no mesmo pedido.'); end if;
    select * into v_bc from contas_cliente where user_id = v_user for update;
    for b in select value as e from jsonb_array_elements(v_ben) loop
      v_btipo := b.e->>'tipo';
      select * into v_pb from produtos where id = _uuid(b.e->>'produtoId') and ativo;
      if not found then return _falha('O brinde escolhido não está mais disponível.'); end if;
      select custo into v_custo_u from produto_precos where produto_id = v_pb.id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_pb.nome || '" não está disponível para essa forma de pagamento.'); end if;
      v_bid := null;
      if v_btipo = 'Fidelidade' then
        if not v_pb.premio_fidelidade then return _falha('"' || v_pb.nome || '" não é um prêmio do cartão fidelidade.'); end if;
        if v_bc.cliente_id is null then return _falha('Seu cartão fidelidade ainda não está ligado à sua conta. Ele liga depois do seu primeiro pedido concluído.'); end if;
        if exists (select 1 from jsonb_array_elements(v_bens) x where x->>'tipo' = 'Fidelidade') then return _falha('Só dá para resgatar 1 prêmio do cartão fidelidade por pedido.'); end if;
        select * into v_fid from fidelidade where cliente_id = v_bc.cliente_id for update;
        if v_fid.id is null or v_fid.carimbos < 10 then return _falha('Seu cartão fidelidade ainda não completou as 10 marcas.'); end if;
      elsif v_btipo = 'Indicação' then
        if not v_pb.premio_indicacao then return _falha('"' || v_pb.nome || '" não é um prêmio de indicação.'); end if;
        select id into v_bid from contas_beneficios where id = _uuid(b.e->>'id') and user_id = v_user and tipo = 'Indicação' and status = 'Disponível' for update;
        if v_bid is null or exists (select 1 from jsonb_array_elements(v_bens) x where x->>'id' = v_bid::text) then return _falha('Este brinde de indicação não está mais disponível.'); end if;
      else
        return _falha('Brinde inválido.');
      end if;
      v_bens := v_bens || jsonb_build_array(jsonb_build_object('tipo', v_btipo, 'id', v_bid, 'produtoId', v_pb.id));
      v_itens_ok := v_itens_ok || jsonb_build_array(jsonb_build_object('produtoId', v_pb.id, 'comboId', null,
        'descricao', '🎁 Brinde ' || case when v_btipo = 'Fidelidade' then 'fidelidade' else 'indicação' end || ' — ' || v_pb.nome,
        'quantidade', 1, 'valorUnitario', 0, 'custoUnitario', v_custo_u, 'adicionaisIds', '[]'::jsonb));
      v_custo := v_custo + v_custo_u;
    end loop;
  end if;
  v_orig := round(v_orig, 2); v_custo := round(v_custo, 2);

  select coalesce((select (valor #>> '{}') = 'true' from sistema where chave = 'BLOQUEAR_ESTOQUE_NEGATIVO'), false) into v_bloqueia;
  if v_bloqueia then
    for r in select c.ingrediente_id, c.qtd, e.quantidade from _consumo(v_itens_ok) c join estoque e on e.id = c.ingrediente_id loop
      if r.quantidade + 0.000000001 < r.qtd then return _falha('Um dos itens do pedido acabou. Escolha outro item ou fale com o restaurante.'); end if;
    end loop;
  end if;

  -- cupom (só no cardápio comum; travado por código para dois pedidos simultâneos não estourarem o limite)
  if not v_eh_mesa then
    v_cod := upper(regexp_replace(btrim(coalesce(p->>'codigoCupom', '')), '\s+', '', 'g'));
    if v_cod <> '' then
      if v_orig <= 0 then return _falha('O cupom vale para pedidos com pelo menos um item pago.'); end if;
      perform pg_advisory_xact_lock(hashtext('cupom:' || v_cod));
      v_cup := _cupom_calcular(v_cod, v_tel, v_orig, v_tipo::text, v_user);
      if coalesce(v_cup->>'ok', '') <> 'true' then return v_cup; end if;
      v_desc := (v_cup->>'desconto')::numeric; v_frete := (v_cup->>'freteGratis')::boolean;
    end if;
  end if;

  if v_tipo = 'Entrega' and not v_frete then
    select coalesce(_num(valor #>> '{}'), 0) into v_pad from sistema where chave = 'TaxaEntregaPadrao';
    v_taxa := coalesce(v_pad, 0);
  end if;
  v_total := case when v_orig <= 0 and jsonb_array_length(v_bens) > 0 then round(v_taxa, 2) else greatest(0.01, round(v_orig - v_desc + v_taxa, 2)) end;
  -- acréscimo da forma de pagamento escolhida (mesa: o acréscimo entra no fechamento da conta)
  if not v_eh_mesa and v_orig > 0 then v_acr := _acrescimo_forma(v_forma, greatest(0.01, v_total - v_taxa)); v_total := round(v_total + v_acr, 2); end if;
  v_obs_final := coalesce(concat_ws(' — ', nullif(v_obs_ent, ''), nullif(v_obs_troco, '')), '');

  -- Mercado Pago: não cria a venda agora. Guarda a reserva (e já segura estoque, cupom e brinde) até o pagamento ser aprovado.
  if p_reserva then
    if v_total <= 0 then return _falha('Este pedido não tem valor a pagar pelo site.'); end if;
    select * into v_cfg from integracoes_config where provedor = 'mercadopago';
    v_min := case when coalesce(v_cfg.config->>'pixValidadeMin', '') ~ '^[0-9]{1,3}$' then least(120, greatest(5, (v_cfg.config->>'pixValidadeMin')::int)) else 15 end;
    insert into pedidos_reserva (requisicao_id, user_id, cliente_nome, telefone, tipo_entrega, forma_pagamento_id, dados_entrega, observacoes,
                                 itens, beneficios, cupom, valor_original, valor_desconto, taxa_entrega, acrescimo_forma, valor_total, custo_total, expira_em)
    values (v_req, v_user, v_nome, v_tel, v_tipo::text, v_forma.id,
            jsonb_build_object('endereco', case when v_tipo = 'Entrega' then v_end else '' end, 'complemento', case when v_tipo = 'Entrega' then v_comp else '' end,
                               'referencia', case when v_tipo = 'Entrega' then v_ref else '' end),
            v_obs_final, v_itens_ok, v_bens, case when v_cod <> '' then v_cup else null end, v_orig, v_desc, v_taxa, v_acr, v_total, v_custo,
            now() + make_interval(mins => v_min))
    returning id into v_res;
    perform _mp_prender(v_res, false);
    perform _registrar_falha(v_chave, 600); perform _registrar_falha('pedcard_global', 300); perform _registrar_falha('pedcard_ip_' || v_ip, 600);
    perform _auditar_publico('Pedido reservado para pagamento pelo site',
      'Total R$ ' || _dinheiro(v_total) || case when jsonb_array_length(v_bens) > 0 then ' | Brindes ' || jsonb_array_length(v_bens) else '' end || case when v_cod <> '' then ' | Cupom ' || (v_cup->>'codigo') else '' end, v_tel);
    return jsonb_build_object('ok', true, 'reservaId', v_res, 'metodo', v_forma.tipo_online, 'valorTotal', v_total, 'valorOriginal', v_orig,
      'acrescimo', v_acr, 'valorDesconto', v_desc, 'taxaEntrega', v_taxa, 'minutos', v_min, 'expiraEm', now() + make_interval(mins => v_min));
  end if;

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido,
                      endereco, complemento, referencia, observacoes_entrega, status_pagamento, valor_original, valor_desconto,
                      desconto_detalhe, origem, mesa_id, taxa_entrega, caixa_id, requisicao_id, acrescimo_forma)
  values (v_venda, v_nome, v_tel, v_forma_nome, v_total, v_custo, 'Confirmada', v_tipo, 'Recebido',
          case when v_tipo = 'Entrega' then v_end else '' end, case when v_tipo = 'Entrega' then v_comp else '' end, case when v_tipo = 'Entrega' then v_ref else '' end,
          v_obs_final, (case when v_total <= 0 then 'Pago' else 'A Receber' end)::status_pagamento, v_orig, v_desc, case when v_cod <> '' then 'Cupom ' || (v_cup->>'codigo') else '' end, 'Cardápio',
          case when v_eh_mesa then p_mesa_id else null end, v_taxa, v_caixa, v_req, v_acr)
  returning numero_pedido into v_numero;

  insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
  select v_venda, _uuid(e->>'produtoId'), _uuid(e->>'comboId'), e->>'descricao', _num(e->>'quantidade', 1)::int, _num(e->>'valorUnitario'), _num(e->>'custoUnitario'),
         round(_num(e->>'quantidade', 1) * _num(e->>'valorUnitario'), 2),
         coalesce((select array_agg(_uuid(x)) filter (where _uuid(x) is not null) from jsonb_array_elements_text(e->'adicionaisIds') x), '{}')
  from jsonb_array_elements(v_itens_ok) e;

  insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo)
  values (v_venda, v_forma_nome, v_total, case when v_eh_mesa or v_total <= 0 then 0 else round(v_total * v_forma.taxa_percentual / 100 + v_forma.taxa_fixa, 2) end, v_acr);
  if v_total <= 0 then update vendas set recebido_em = now() where id = v_venda; end if;

  if v_eh_mesa and v_mesa.status::text = 'Livre' then update mesas set status = 'Ocupada' where id = p_mesa_id; end if;
  perform _ajustar_estoque(v_itens_ok, 1, v_venda);
  if v_tel <> '' then v_cli := _upsert_cliente(v_tel, v_nome); end if;
  if v_user is not null and not v_eh_mesa then insert into contas_pedidos (venda_id, user_id) values (v_venda, v_user) on conflict do nothing; end if;
  if jsonb_array_length(v_bens) > 0 then
    for b in select value as e from jsonb_array_elements(v_bens) loop
      if b.e->>'tipo' = 'Fidelidade' then
        update fidelidade set carimbos = 0, premios_resgatados = premios_resgatados + 1, atualizada_em = now() where cliente_id = v_bc.cliente_id;
        insert into contas_beneficios (user_id, tipo, status, produto_id, venda_id, usado_em) values (v_user, 'Fidelidade', 'Usado', _uuid(b.e->>'produtoId'), v_venda, now());
      else
        update contas_beneficios set status = 'Usado', produto_id = _uuid(b.e->>'produtoId'), venda_id = v_venda, usado_em = now() where id = _uuid(b.e->>'id');
      end if;
    end loop;
  end if;
  if v_cod <> '' then
    insert into cupons_usos (cupom_id, codigo, venda_id, cliente_id, telefone, desconto, frete_gratis, requisicao_id, user_id)
    values ((v_cup->>'cupomId')::uuid, v_cup->>'codigo', v_venda, v_cli, v_tel, v_desc, v_frete, v_req, v_user);
    perform _conta_cupom_usado(v_user, (v_cup->>'cupomId')::uuid, v_venda);
  end if;
  perform _registrar_falha(v_chave, 600); perform _registrar_falha('pedcard_global', 300); perform _registrar_falha('pedcard_ip_' || v_ip, 600);
  perform _auditar_publico(case when v_eh_mesa then 'Pedido recebido pelo cliente na mesa ' || v_mesa.numero else 'Pedido recebido pelo Cardápio' end,
    'Total R$ ' || _dinheiro(v_total) || case when jsonb_array_length(v_bens) > 0 then ' | Brindes ' || jsonb_array_length(v_bens) else '' end || case when v_cod <> '' then ' | Cupom ' || (v_cup->>'codigo') else '' end, case when v_eh_mesa then v_nome else v_tel end);

  return jsonb_build_object('ok', true, 'message', 'Pedido enviado! Nº ' || v_numero || '. Total: R$ ' || _dinheiro(v_total) || '.',
    'id', v_venda, 'numero', v_numero, 'valorTotal', v_total, 'valorOriginal', v_orig, 'acrescimo', v_acr, 'valorDesconto', v_desc,
    'cupom', case when v_cod <> '' then v_cup->>'codigo' else '' end, 'freteGratis', v_frete);
end $function$
;

-- a função de 2 argumentos (usada por api_criar_pedido_cardapio e api_criar_pedido_mesa) continua igual para quem chama: só repassa com p_reserva = false
create or replace function public._criar_pedido_publico(p jsonb, p_mesa_id uuid) returns jsonb
 language sql security definer set search_path to 'public' as $f$ select public._criar_pedido_publico(p, p_mesa_id, false) $f$;

-- ---------- 5) Funções que o cardápio chama (cliente logado) ----------
-- Valida o pedido e RESERVA (não cria venda). Devolve reservaId, valor e quando a reserva vence. Depois a página chama a função mp-criar.
create or replace function public.api_mp_reservar(p jsonb) returns jsonb
 language sql security definer set search_path to 'public' as $f$ select public._criar_pedido_publico(p, null, true) $f$;

-- Situação do pagamento, para a tela do cliente (Pix aguardando, aprovado, recusado...). A tela consulta esta função de tempos em tempos.
create or replace function public.api_mp_status_pagamento(p jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; g pagamentos_online%rowtype; v_est text;
begin
  if auth.uid() is null then return _negado(); end if;
  select * into r from pedidos_reserva where id = _uuid(p->>'reservaId') and user_id = auth.uid();
  if not found then return _falha('Pedido não encontrado.'); end if;
  select * into g from pagamentos_online where reserva_id = r.id order by criado_em desc limit 1;
  v_est := case
    when r.estado = 'confirmada' then 'aprovado'
    when g.id is not null and (g.decisao = 'reembolsar' or g.status in ('reembolso_parcial', 'reembolsado')) then 'reembolso'
    when g.id is not null and g.status = 'aprovado' then 'conferindo'
    when r.estado = 'expirada' then 'expirado'
    when r.estado = 'cancelada' then 'cancelado'
    when g.id is not null and g.status = 'recusado' then 'recusado'
    when g.id is not null and g.status = 'erro' then 'erro'
    else 'aguardando' end;
  return jsonb_build_object('ok', true, 'estado', v_est, 'reservaId', r.id, 'metodo', g.metodo, 'valorTotal', r.valor_total, 'expiraEm', r.expira_em,
    'vendaId', r.venda_id, 'numero', (select v.numero_pedido from vendas v where v.id = r.venda_id), 'detalhe', coalesce(g.status_detalhe, ''),
    'pixCopiaCola', case when v_est = 'aguardando' then g.pix_copia_cola else null end, 'pixQrBase64', case when v_est = 'aguardando' then g.pix_qr_base64 else null end,
    'pixExpiraEm', case when v_est = 'aguardando' then g.pix_expira_em else null end);
end $f$;

-- O cliente desistiu (fechou a tela do Pix, voltou ao carrinho): solta estoque, cupom e brinde na hora.
create or replace function public.api_mp_cancelar_reserva(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype;
begin
  if auth.uid() is null then return _negado(); end if;
  select * into r from pedidos_reserva where id = _uuid(p->>'reservaId') and user_id = auth.uid() for update;
  if not found then return _falha('Pedido não encontrado.'); end if;
  if r.estado <> 'ativa' then return jsonb_build_object('ok', true, 'estado', r.estado); end if;
  if exists (select 1 from pagamentos_online g where g.reserva_id = r.id and (g.status = 'aprovado' or (g.decisao_pendente and g.decisao is null))) then
    return _falha('O pagamento deste pedido já foi aprovado. Fale com o restaurante.');
  end if;
  update pagamentos_online set status = 'cancelado', status_detalhe = 'cancelado pelo cliente', atualizado_em = now() where reserva_id = r.id and status = 'aguardando';
  perform _mp_soltar(r.id, 'cancelada', 'Cancelado pelo cliente');
  return jsonb_build_object('ok', true, 'estado', 'cancelada');
end $f$;

-- ---------- 6) Confirmar o pagamento: a venda nasce PAGA ----------
-- Cria a venda a partir da reserva, no mesmo formato do pedido do cardápio (itens, pagamento, conta, cupom, brindes, fidelidade).
-- Estoque, cupom e brinde já foram segurados na reserva: aqui só se liga tudo à venda.
create or replace function public._mp_criar_venda(p_reserva uuid, p_pag uuid) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; f formas_pagamento%rowtype; v_caixa uuid; v_venda uuid := gen_random_uuid(); v_numero int; v_cli uuid;
        v_cod text; rec record; v_tipo venda_tipo; v_de jsonb; v_nome text; v_cc uuid;
begin
  select * into r from pedidos_reserva where id = p_reserva for update;
  if not found then raise exception 'Reserva não encontrada.'; end if;
  select * into f from formas_pagamento where id = r.forma_pagamento_id;
  v_nome := coalesce(f.nome, 'Pagamento online');
  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;
  if v_caixa is null then raise exception 'Caixa fechado.'; end if;
  v_tipo := (case when r.tipo_entrega = 'Entrega' then 'Entrega' else 'Retirada' end)::venda_tipo;
  v_de := coalesce(r.dados_entrega, '{}'::jsonb);
  v_cod := coalesce(r.cupom->>'codigo', '');

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido,
                      endereco, complemento, referencia, observacoes_entrega, status_pagamento, recebido_em, valor_original, valor_desconto,
                      desconto_detalhe, origem, mesa_id, taxa_entrega, caixa_id, requisicao_id, acrescimo_forma)
  values (v_venda, r.cliente_nome, r.telefone, v_nome, r.valor_total, r.custo_total, 'Confirmada', v_tipo, 'Recebido',
          case when v_tipo = 'Entrega' then coalesce(v_de->>'endereco', '') else '' end, case when v_tipo = 'Entrega' then coalesce(v_de->>'complemento', '') else '' end,
          case when v_tipo = 'Entrega' then coalesce(v_de->>'referencia', '') else '' end, r.observacoes, 'Pago', now(), r.valor_original, r.valor_desconto,
          case when v_cod <> '' then 'Cupom ' || v_cod else '' end, 'Cardápio', null, r.taxa_entrega, v_caixa, r.requisicao_id, r.acrescimo_forma)
  returning numero_pedido into v_numero;

  insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
  select v_venda, _uuid(e->>'produtoId'), _uuid(e->>'comboId'), e->>'descricao', _num(e->>'quantidade', 1)::int, _num(e->>'valorUnitario'), _num(e->>'custoUnitario'),
         round(_num(e->>'quantidade', 1) * _num(e->>'valorUnitario'), 2),
         coalesce((select array_agg(_uuid(x)) filter (where _uuid(x) is not null) from jsonb_array_elements_text(e->'adicionaisIds') x), '{}')
  from jsonb_array_elements(r.itens) e;

  insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo)
  values (v_venda, v_nome, r.valor_total, round(r.valor_total * coalesce(f.taxa_percentual, 0) / 100 + coalesce(f.taxa_fixa, 0), 2), r.acrescimo_forma);

  if r.telefone <> '' then
    v_cli := _upsert_cliente(r.telefone, r.cliente_nome);
    perform _carimbar_fidelidade(r.telefone, r.cliente_nome);   -- como no recebimento manual: pedido pago = marca no cartão fidelidade
  end if;
  insert into contas_pedidos (venda_id, user_id) values (v_venda, r.user_id) on conflict do nothing;

  if r.cupom_uso_id is not null then update cupons_usos set venda_id = v_venda, cliente_id = v_cli where id = r.cupom_uso_id; end if;
  v_cc := _uuid(r.cupom->>'concedidoId');
  if v_cc is not null then update cupons_concedidos set venda_id = v_venda where id = v_cc; end if;
  for rec in select value as e from jsonb_array_elements(r.beneficios) loop
    if _uuid(rec.e->>'id') is not null then update contas_beneficios set venda_id = v_venda where id = _uuid(rec.e->>'id'); end if;
  end loop;

  update pedidos_reserva set estado = 'confirmada', venda_id = v_venda, atualizado_em = now() where id = r.id;
  update pagamentos_online set venda_id = v_venda, atualizado_em = now() where id = p_pag;
  perform _auditar_publico('Pedido pago pelo site (Mercado Pago)', 'Nº ' || v_numero || ' | Total R$ ' || _dinheiro(r.valor_total), r.telefone);
  return jsonb_build_object('vendaId', v_venda, 'numero', v_numero);
end $f$;

-- Marca o pagamento como "Pagamento a decidir": o dinheiro entrou, mas o pedido NÃO vai para a cozinha até o operador de caixa ou o Admin escolher.
create or replace function public._mp_marcar_decidir(p_pag uuid, p_motivo text) returns void
 language plpgsql security definer set search_path to 'public' as $f$
begin
  update pagamentos_online set decisao_pendente = true, decisao = null, decisao_motivo = left(coalesce(p_motivo, ''), 200), atualizado_em = now() where id = p_pag;
  perform _auditar('Pagamento a decidir', 'Pagamento ' || p_pag || ' | ' || coalesce(p_motivo, ''), '');
end $f$;

-- Pagamento aprovado pelo Mercado Pago. Reserva ativa e restaurante aberto: cria a venda Paga.
-- Reserva vencida/cancelada, caixa ou cardápio fechado, pagamento em duplicidade: nunca reembolsa sozinho, marca "Pagamento a decidir".
-- Ordem de trava: sempre reserva primeiro, depois pagamento (evita travar um no outro).
create or replace function public._mp_confirmar_pagamento(p_pag uuid) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare g pagamentos_online%rowtype; r pedidos_reserva%rowtype; v_motivo text; v_v jsonb;
begin
  select * into g from pagamentos_online where id = p_pag;
  if not found then return _falha('Pagamento não encontrado.'); end if;
  select * into r from pedidos_reserva where id = g.reserva_id for update;
  select * into g from pagamentos_online where id = p_pag for update;
  if g.status in ('reembolso_parcial', 'reembolsado') or g.venda_id is not null or g.decisao_pendente or g.decisao is not null then
    return jsonb_build_object('ok', true, 'duplicado', true);
  end if;
  update pagamentos_online set status = 'aprovado', aprovado_em = coalesce(aprovado_em, now()), erro = '', atualizado_em = now() where id = g.id;

  if r.estado = 'confirmada' then v_motivo := 'Já existe um pedido pago nesta reserva (pagamento em duplicidade)';
  elsif r.estado = 'expirada' then v_motivo := case when g.metodo = 'pix' then 'Pix pago depois de vencer' else 'Pagamento aprovado depois de a reserva vencer' end;
  elsif r.estado = 'cancelada' then v_motivo := 'Pagamento aprovado depois de a reserva ser cancelada';
  elsif not exists (select 1 from caixa_sessoes where status = 'Aberto') then v_motivo := 'Caixa fechado quando o pagamento foi aprovado';
  elsif _cardapio_bloqueio() is not null then v_motivo := 'Cardápio fechado quando o pagamento foi aprovado';
  end if;
  if v_motivo is not null then
    perform _mp_marcar_decidir(g.id, v_motivo);
    return jsonb_build_object('ok', true, 'decidir', true, 'motivo', v_motivo);
  end if;

  v_v := _mp_criar_venda(r.id, g.id);
  return jsonb_build_object('ok', true, 'vendaId', v_v->>'vendaId', 'numero', (v_v->>'numero')::int);
end $f$;

-- Operador de caixa ou Admin decide sobre um "Pagamento a decidir": seguir com o pedido ou reembolsar.
-- "reembolsar" só registra a decisão e solta a reserva; quem devolve o dinheiro é a função mp-reembolsar (Etapa 3), que depois avisa o banco.
create or replace function public.api_mp_decidir_pagamento(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare g pagamentos_online%rowtype; r pedidos_reserva%rowtype; v_dec text := lower(btrim(coalesce(p->>'decisao', ''))); v_v jsonb; v_id uuid := _uuid(p->>'pagamentoId');
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  if v_dec not in ('seguir', 'reembolsar') then return _falha('Escolha entre seguir com o pedido ou reembolsar.'); end if;
  select * into g from pagamentos_online where id = v_id;
  if not found then return _falha('Pagamento não encontrado.'); end if;
  select * into r from pedidos_reserva where id = g.reserva_id for update;
  select * into g from pagamentos_online where id = v_id for update;
  if not g.decisao_pendente or g.decisao is not null then return _falha('Este pagamento não está aguardando decisão.'); end if;
  if g.status <> 'aprovado' then return _falha('Só dá para decidir sobre um pagamento aprovado.'); end if;

  if v_dec = 'seguir' then
    if r.estado = 'confirmada' then return _falha('Já existe um pedido pago nesta reserva. Aqui só dá para reembolsar.'); end if;
    if not exists (select 1 from caixa_sessoes where status = 'Aberto') then return _falha('Abra o caixa para seguir com este pedido.'); end if;
    if r.estado <> 'ativa' then perform _mp_prender(r.id, true); end if;   -- reserva já foi solta: segura estoque, cupom e brinde de novo, sem barrar
    update pagamentos_online set decisao = 'seguir', decisao_pendente = false, decidido_por = auth.uid(), decidido_em = now(), atualizado_em = now() where id = g.id;
    v_v := _mp_criar_venda(r.id, g.id);
    perform _auditar('Pagamento online: seguir com o pedido', 'Pagamento ' || g.id || ' | Pedido Nº ' || (v_v->>'numero'), '');
    return jsonb_build_object('ok', true, 'decisao', 'seguir', 'vendaId', v_v->>'vendaId', 'numero', (v_v->>'numero')::int, 'message', 'Pedido liberado para a cozinha.');
  end if;

  if r.estado = 'ativa' then perform _mp_soltar(r.id, 'cancelada', 'Pagamento será reembolsado'); end if;
  update pagamentos_online set decisao = 'reembolsar', decisao_pendente = false, decidido_por = auth.uid(), decidido_em = now(), atualizado_em = now() where id = g.id;
  perform _auditar('Pagamento online: reembolsar', 'Pagamento ' || g.id || ' | R$ ' || _dinheiro(g.valor), '');
  return jsonb_build_object('ok', true, 'decisao', 'reembolsar', 'pagamentoId', g.id, 'valorAReembolsar', round(g.valor - g.valor_reembolsado, 2),
    'message', 'Decisão registrada. Falta devolver o dinheiro pelo Mercado Pago.');
end $f$;

-- ---------- 7) Funções só para as Edge Functions (chave de serviço) ----------
-- Credenciais do modo atual (ou do modo em que o pagamento foi criado). Nunca vão para o navegador.
create or replace function public.mp_credenciais(p_modo text default null) returns jsonb
 language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('ligado', c.ligado, 'modoAtual', case when c.modo = 'producao' then 'producao' else 'homologacao' end,
    'modo', m.modo, 'config', c.config,
    'publicKey', (select valor from integracoes_segredos where chave = case when m.modo = 'producao' then 'mp_public_key_producao' else 'mp_public_key_teste' end),
    'accessToken', (select valor from integracoes_segredos where chave = case when m.modo = 'producao' then 'mp_access_token_producao' else 'mp_access_token_teste' end),
    'webhookSecret', (select valor from integracoes_segredos where chave = 'mp_webhook_secret'))
  from integracoes_config c,
       lateral (select case when coalesce(p_modo, c.modo) = 'producao' then 'producao' else 'homologacao' end as modo) m
  where c.provedor = 'mercadopago'
$f$;

-- mp-criar chama antes de falar com o Mercado Pago. p: {reservaId, userId}. Confere dono, tempo, ligado, tentativas e cria a linha do pagamento.
-- Pix ainda valendo na mesma reserva: devolve o mesmo (reaproveitar = true), sem criar outro.
create or replace function public.mp_preparar_pagamento(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; f formas_pagamento%rowtype; g pagamentos_online%rowtype; v_modo text; v_novo uuid; v_email text; v_achou boolean;
begin
  select * into r from pedidos_reserva where id = _uuid(p->>'reservaId') for update;
  if not found or r.user_id is distinct from _uuid(p->>'userId') then return _falha('Pedido não encontrado.'); end if;
  if r.estado = 'confirmada' then return _falha('Este pedido já foi pago.'); end if;
  if r.estado <> 'ativa' or r.expira_em < now() then return _falha('O tempo deste pedido acabou. Faça o pedido de novo.'); end if;
  if coalesce((public.api_mp_config_publica('{}'::jsonb)->>'ligado')::boolean, false) is not true then return _falha('O pagamento pelo site não está disponível agora.'); end if;
  select * into f from formas_pagamento where id = r.forma_pagamento_id;
  if f.id is null or not f.aceita_online or f.tipo_online is null then return _falha('Forma de pagamento inválida.'); end if;
  if exists (select 1 from pagamentos_online where reserva_id = r.id and status = 'aprovado') then return _falha('Este pedido já foi pago.'); end if;
  if (select count(*) from pagamentos_online where reserva_id = r.id) >= 5 then return _falha('Muitas tentativas de pagamento. Faça o pedido de novo.'); end if;

  select * into g from pagamentos_online
   where reserva_id = r.id and metodo = 'pix' and status = 'aguardando' and pix_copia_cola is not null and (pix_expira_em is null or pix_expira_em > now())
   order by criado_em desc limit 1;
  v_achou := found;
  if v_achou and f.tipo_online = 'pix' then
    return jsonb_build_object('ok', true, 'reaproveitar', true, 'pagamentoId', g.id, 'metodo', 'pix', 'valor', g.valor,
      'pixCopiaCola', g.pix_copia_cola, 'pixQrBase64', g.pix_qr_base64, 'pixExpiraEm', g.pix_expira_em);
  end if;
  if f.tipo_online = 'credito' and exists (select 1 from pagamentos_online where reserva_id = r.id and metodo = 'credito' and status = 'aguardando' and criado_em > now() - interval '2 minutes') then
    return _falha('Seu pagamento está em andamento. Aguarde alguns segundos.');
  end if;

  update pagamentos_online set status = 'cancelado', status_detalhe = 'substituído por nova tentativa', atualizado_em = now() where reserva_id = r.id and status = 'aguardando';
  select case when modo = 'producao' then 'producao' else 'homologacao' end into v_modo from integracoes_config where provedor = 'mercadopago';
  insert into pagamentos_online (reserva_id, user_id, metodo, mp_modo, valor) values (r.id, r.user_id, f.tipo_online, v_modo, r.valor_total) returning id into v_novo;
  select email into v_email from auth.users where id = r.user_id;   -- só é repassado ao Mercado Pago; não é guardado aqui
  return jsonb_build_object('ok', true, 'pagamentoId', v_novo, 'metodo', f.tipo_online, 'modo', v_modo, 'valor', r.valor_total, 'expiraEm', r.expira_em,
    'email', v_email, 'nome', r.cliente_nome,
    'itens', (select coalesce(jsonb_agg(jsonb_build_object('titulo', left(coalesce(e->>'descricao', 'Item'), 100), 'quantidade', _num(e->>'quantidade', 1), 'valorUnitario', _num(e->>'valorUnitario'))), '[]'::jsonb)
                from jsonb_array_elements(r.itens) e));
end $f$;

-- Única porta de entrada do resultado do Mercado Pago (criação, aviso/webhook, consulta ativa, reembolso). O status chega JÁ traduzido pela função da nuvem:
--   status = aguardando | aprovado | recusado | expirado | cancelado | reembolso_parcial | reembolsado | erro
-- p: {pagamentoId ou mpOrderId, status, statusDetalhe, mpOrderId, mpPaymentId, pixCopiaCola, pixQrBase64, pixExpiraEm, cartaoFinal, cartaoBandeira,
--     valorReembolsado, erro, chaveEvento (só aviso), assinaturaOk (só aviso), tipoEvento, statusMp, detalhe}
-- Aviso repetido (mesma chaveEvento) é ignorado. Aviso com assinatura inválida só é registrado e nada mais acontece.
create or replace function public.mp_aplicar_status(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare g pagamentos_online%rowtype; v_chave text := nullif(btrim(coalesce(p->>'chaveEvento', '')), ''); v_ass boolean := coalesce((p->>'assinaturaOk')::boolean, false);
        v_st text := lower(btrim(coalesce(p->>'status', ''))); v_ev bigint; v_vr numeric; v_res jsonb; v_reserva uuid; v_oid text := nullif(btrim(coalesce(p->>'mpOrderId', '')), '');
begin
  if v_chave is not null and not v_ass then
    insert into pagamentos_online_eventos (chave, tipo, status_mp, assinatura_ok, detalhe)
    values ('invalida:' || gen_random_uuid()::text, left(coalesce(p->>'tipoEvento', ''), 60), left(coalesce(p->>'statusMp', ''), 60), false, p->'detalhe');
    return jsonb_build_object('ok', false, 'ignorado', 'assinatura');
  end if;
  if v_st not in ('aguardando', 'aprovado', 'recusado', 'expirado', 'cancelado', 'reembolso_parcial', 'reembolsado', 'erro') then return _falha('Status inválido.'); end if;

  select reserva_id into v_reserva from pagamentos_online where id = _uuid(p->>'pagamentoId');
  if v_reserva is null and v_oid is not null then select reserva_id into v_reserva from pagamentos_online where mp_order_id = v_oid; end if;
  if v_reserva is null then
    if v_chave is not null then
      insert into pagamentos_online_eventos (chave, tipo, status_mp, assinatura_ok, detalhe) values (v_chave, left(coalesce(p->>'tipoEvento', ''), 60), left(coalesce(p->>'statusMp', ''), 60), true, p->'detalhe')
      on conflict (chave) do nothing;
    end if;
    return jsonb_build_object('ok', false, 'ignorado', 'pagamento_desconhecido');
  end if;
  perform 1 from pedidos_reserva where id = v_reserva for update;                 -- trava: reserva primeiro, depois o pagamento
  select * into g from pagamentos_online where id = coalesce(_uuid(p->>'pagamentoId'), (select id from pagamentos_online where mp_order_id = v_oid)) for update;

  if v_chave is not null then
    insert into pagamentos_online_eventos (chave, pagamento_id, tipo, status_mp, assinatura_ok, detalhe)
    values (v_chave, g.id, left(coalesce(p->>'tipoEvento', ''), 60), left(coalesce(p->>'statusMp', ''), 60), true, p->'detalhe')
    on conflict (chave) do nothing returning id into v_ev;
    if v_ev is null then return jsonb_build_object('ok', true, 'duplicado', true); end if;
  end if;

  update pagamentos_online set
    mp_order_id = coalesce(v_oid, mp_order_id), mp_payment_id = coalesce(nullif(p->>'mpPaymentId', ''), mp_payment_id),
    pix_copia_cola = coalesce(nullif(p->>'pixCopiaCola', ''), pix_copia_cola), pix_qr_base64 = coalesce(nullif(p->>'pixQrBase64', ''), pix_qr_base64),
    pix_expira_em = coalesce(nullif(p->>'pixExpiraEm', '')::timestamptz, pix_expira_em),
    cartao_final = case when p->>'cartaoFinal' ~ '^[0-9]{4}$' then p->>'cartaoFinal' else cartao_final end,
    cartao_bandeira = coalesce(left(nullif(p->>'cartaoBandeira', ''), 30), cartao_bandeira),
    status_detalhe = case when p ? 'statusDetalhe' then left(coalesce(p->>'statusDetalhe', ''), 200) else status_detalhe end, atualizado_em = now()
   where id = g.id;
  select * into g from pagamentos_online where id = g.id;

  if v_st = 'aprovado' then
    if g.status not in ('reembolso_parcial', 'reembolsado') then v_res := _mp_confirmar_pagamento(g.id); end if;
  elsif v_st in ('recusado', 'expirado', 'cancelado') then
    if g.status = 'aguardando' then update pagamentos_online set status = v_st, atualizado_em = now() where id = g.id; end if;
  elsif v_st = 'erro' then
    if g.status = 'aguardando' then
      update pagamentos_online set status = 'erro', erro = left(coalesce(p->>'erro', ''), 300), atualizado_em = now() where id = g.id;
      -- não deu nem para criar o pagamento: solta a reserva na hora (a página oferece pagar na entrega)
      if exists (select 1 from pedidos_reserva where id = g.reserva_id and estado = 'ativa')
         and not exists (select 1 from pagamentos_online where reserva_id = g.reserva_id and status = 'aprovado') then
        perform _mp_soltar(g.reserva_id, 'cancelada', 'Erro ao criar o pagamento');
      end if;
    end if;
  elsif v_st in ('reembolso_parcial', 'reembolsado') then
    if g.status in ('aprovado', 'reembolso_parcial', 'reembolsado') then
      v_vr := round(least(g.valor, greatest(g.valor_reembolsado, case when v_st = 'reembolsado' then g.valor else coalesce(_num(p->>'valorReembolsado'), 0) end)), 2);
      update pagamentos_online set valor_reembolsado = v_vr, status = case when v_vr >= g.valor then 'reembolsado' else 'reembolso_parcial' end, atualizado_em = now() where id = g.id;
      if v_vr >= g.valor and g.venda_id is not null then
        update reembolsos set status = 'Devolvido', devolvido_em = now(), observacao = 'Reembolsado pelo Mercado Pago' where venda_id = g.venda_id and status = 'Pendente';
      end if;
      perform _auditar('Reembolso Mercado Pago', 'Pagamento ' || g.id || ' | R$ ' || _dinheiro(v_vr) || ' de R$ ' || _dinheiro(g.valor), '');
    end if;
  end if;

  return jsonb_build_object('ok', true, 'pagamentoId', g.id, 'status', (select status from pagamentos_online where id = g.id), 'resultado', v_res);
end $f$;

-- Rodada a cada minuto (pg_cron): reservas vencidas sem pagamento devolvem estoque, cupom e brinde. Nada é apagado.
-- Reserva com pagamento aprovado ou aguardando decisão NÃO vence: segue até alguém decidir.
create or replace function public.mp_expirar_reservas() returns int
 language plpgsql security definer set search_path to 'public' as $f$
declare r record; n int := 0;
begin
  for r in select id from pedidos_reserva where estado = 'ativa' and expira_em < now() order by expira_em limit 100 for update skip locked loop
    if exists (select 1 from pagamentos_online g where g.reserva_id = r.id and (g.status = 'aprovado' or (g.decisao_pendente and g.decisao is null))) then continue; end if;
    update pagamentos_online set status = 'expirado', status_detalhe = 'reserva vencida', atualizado_em = now() where reserva_id = r.id and status = 'aguardando';
    perform _mp_soltar(r.id, 'expirada', 'Tempo esgotado sem pagamento');
    n := n + 1;
  end loop;
  return n;
end $f$;

do $d$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    if not exists (select 1 from cron.job where jobname = 'mp-expirar-reservas') then
      perform cron.schedule('mp-expirar-reservas', '* * * * *', 'select public.mp_expirar_reservas()');
    end if;
  end if;
end $d$;

-- ---------- 8) Permissões ----------
revoke all on function public._mp_prender(uuid, boolean), public._mp_soltar(uuid, text, text), public._mp_criar_venda(uuid, uuid),
  public._mp_marcar_decidir(uuid, text), public._mp_confirmar_pagamento(uuid), public._criar_pedido_publico(jsonb, uuid, boolean) from public, anon, authenticated;
revoke all on function public.api_mp_reservar(jsonb), public.api_mp_status_pagamento(jsonb), public.api_mp_cancelar_reserva(jsonb), public.api_mp_decidir_pagamento(jsonb) from public, anon;
grant execute on function public.api_mp_reservar(jsonb), public.api_mp_status_pagamento(jsonb), public.api_mp_cancelar_reserva(jsonb), public.api_mp_decidir_pagamento(jsonb) to authenticated;
revoke all on function public.mp_credenciais(text), public.mp_preparar_pagamento(jsonb), public.mp_aplicar_status(jsonb), public.mp_expirar_reservas() from public, anon, authenticated;
grant execute on function public.mp_credenciais(text), public.mp_preparar_pagamento(jsonb), public.mp_aplicar_status(jsonb), public.mp_expirar_reservas() to service_role;

commit;
