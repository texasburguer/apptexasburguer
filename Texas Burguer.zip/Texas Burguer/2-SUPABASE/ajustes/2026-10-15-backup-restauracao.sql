-- 2026-10-15 · Backup completo e restauração em transação única (achados A e B da auditoria)
-- Rode UMA vez no SQL Editor do Supabase, ANTES de publicar as funções criar-backup e restaurar-backup novas.
--
-- O que muda:
--  1) backup_tabelas(): o backup passa a descobrir sozinho as tabelas do schema public (menos as excluídas abaixo).
--     Tabela nova entra no backup sem mexer em código.
--  2) restaurar_backup_dados(): restaura tudo em UMA transação. Se qualquer passo falhar, nada muda.
--     Não apaga e recria as linhas: grava por cima (upsert) e só remove as linhas que NÃO estavam no backup.
--     Assim vendas que existem no backup nunca são apagadas, e o "apagar em cascata" não atinge
--     contas_pedidos, chat_*, entrega_destinos etc. dessas vendas. A ordem pai/filho vem das chaves estrangeiras
--     do próprio banco. No fim confere a contagem de linhas de cada tabela; se não bater, desfaz tudo.

-- Fora do backup: segredos (não gravar em claro num arquivo), dados deriváveis e o próprio controle de backup.
create or replace function public._backup_excluidas() returns text[]
language sql immutable as $$
  select array['backups','arquivo_historico','backup_config',
               'ai_segredos','integracoes_segredos','ifood_token','contas_acessos',
               'fila_sync','ai_cache','ai_log','tentativas','sync_estado','versoes_sync']::text[]
$$;

create or replace function public._pk_cols(p_tabela text) returns text[]
language sql stable set search_path = public, pg_temp as $$
  select array_agg(a.attname::text order by k.ord)
  from pg_index i
  cross join lateral unnest(i.indkey::int2[]) with ordinality as k(attnum, ord)
  join pg_attribute a on a.attrelid = i.indrelid and a.attnum = k.attnum
  where i.indrelid = format('public.%I', p_tabela)::regclass and i.indisprimary
$$;

-- Lista de tabelas do backup, com as colunas de ordenação (chave primária; sem chave, a primeira coluna).
create or replace function public.backup_tabelas() returns jsonb
language sql stable security definer set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object(
           'tabela', c.relname::text,
           'chaves', to_jsonb(coalesce(public._pk_cols(c.relname::text),
              array[(select a.attname::text from pg_attribute a
                      where a.attrelid = c.oid and a.attnum > 0 and not a.attisdropped
                      order by a.attnum limit 1)]))
         ) order by c.relname), '[]'::jsonb)
  from pg_class c
  join pg_namespace n on n.oid = c.relnamespace
  where n.nspname = 'public' and c.relkind in ('r','p') and not c.relispartition
    and c.relname <> all (public._backup_excluidas())
$$;

create or replace function public.restaurar_backup_dados(
  p_dados jsonb,
  p_preservar text[] default array['usuarios','auditoria']
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_todas text[]; v_ordem text[] := '{}'; v_pend text[]; v_pronta text[];
  t text; v_cols text; v_pks text[]; v_pkl text; v_set text; v_xs text; v_bs text;
  v_src text; v_n bigint; v_esp bigint; v_cont jsonb := '{}'::jsonb; i int;
begin
  if p_dados is null or jsonb_typeof(p_dados) <> 'object' then
    raise exception 'Arquivo de backup inválido.';
  end if;
  perform set_config('statement_timeout', '900000', true);   -- só nesta transação (15 min)
  perform set_config('lock_timeout', '30000', true);

  -- Tabelas que existem no banco E estão no arquivo (como lista), menos as preservadas e as excluídas.
  select coalesce(array_agg(c.relname::text order by c.relname), '{}') into v_todas
  from pg_class c join pg_namespace n on n.oid = c.relnamespace
  where n.nspname = 'public' and c.relkind in ('r','p') and not c.relispartition
    and jsonb_typeof(p_dados -> c.relname::text) = 'array'
    and c.relname <> all (p_preservar) and c.relname <> all (public._backup_excluidas());

  -- Ordem pai -> filho pelas chaves estrangeiras entre essas tabelas.
  v_pend := v_todas;
  while coalesce(array_length(v_pend, 1), 0) > 0 loop
    select coalesce(array_agg(u.nome order by u.nome), '{}') into v_pronta
    from unnest(v_pend) as u(nome)
    where not exists (
      select 1 from pg_constraint k
      join pg_class cf on cf.oid = k.conrelid
      join pg_class cp on cp.oid = k.confrelid
      where k.contype = 'f' and cf.relname = u.nome and cf.relnamespace = 'public'::regnamespace
        and cp.relnamespace = 'public'::regnamespace and cp.relname = any (v_pend) and cp.relname <> u.nome);
    if coalesce(array_length(v_pronta, 1), 0) = 0 then v_pronta := v_pend; end if;   -- ciclo: segue em ordem alfabética
    v_ordem := v_ordem || v_pronta;
    select coalesce(array_agg(x), '{}') into v_pend from unnest(v_pend) as x where x <> all (v_pronta);
  end loop;

  -- 1) Grava por cima, pais antes dos filhos.
  foreach t in array v_ordem loop
    select string_agg(format('%I', a.attname), ', ' order by a.attnum) into v_cols
    from pg_attribute a
    where a.attrelid = format('public.%I', t)::regclass and a.attnum > 0 and not a.attisdropped and a.attgenerated = '';
    v_pks := public._pk_cols(t);
    v_src := format('(select * from jsonb_populate_recordset(null::public.%I, $1 -> %L)%s) b', t, t,
                    case when t = 'sistema' then ' where chave <> ''MANUTENCAO''' else '' end);
    if v_pks is null then   -- sem chave primária: troca o conteúdo inteiro
      execute format('delete from public.%I', t);
      execute format('insert into public.%I (%s) overriding system value select %s from %s', t, v_cols, v_cols, v_src) using p_dados;
    else
      select string_agg(format('%I', x), ', ') into v_pkl from unnest(v_pks) as x;
      select string_agg(format('%I = excluded.%I', a.attname, a.attname), ', ') into v_set
      from pg_attribute a
      where a.attrelid = format('public.%I', t)::regclass and a.attnum > 0 and not a.attisdropped
        and a.attgenerated = '' and a.attname::text <> all (v_pks);
      execute format('insert into public.%I (%s) overriding system value select %s from %s on conflict (%s) %s',
                     t, v_cols, v_cols, v_src, v_pkl,
                     case when v_set is null then 'do nothing' else 'do update set ' || v_set end) using p_dados;
    end if;
  end loop;

  -- 2) Remove o que NÃO estava no backup, filhos antes dos pais ("sistema" nunca perde linhas).
  for i in reverse coalesce(array_length(v_ordem, 1), 0) .. 1 loop
    t := v_ordem[i];
    v_pks := public._pk_cols(t);
    if t = 'sistema' or v_pks is null then continue; end if;
    select string_agg('x.' || format('%I', k), ', '), string_agg(format('%I', k), ', ') into v_xs, v_bs from unnest(v_pks) as k;
    execute format('delete from public.%I x where (%s) not in (select %s from jsonb_populate_recordset(null::public.%I, $1 -> %L))',
                   t, v_xs, v_bs, t, t) using p_dados;
  end loop;

  -- 3) Conferência: contagem de cada tabela = contagem do arquivo. Se não bater, a transação inteira é desfeita.
  foreach t in array v_ordem loop
    if t = 'sistema' then continue; end if;
    execute format('select count(*) from public.%I', t) into v_n;
    v_esp := jsonb_array_length(p_dados -> t);
    v_cont := v_cont || jsonb_build_object(t, v_n);
    if v_n <> v_esp then
      raise exception 'Conferência falhou em %: o backup tem % linhas e o banco ficou com %. Nada foi alterado.', t, v_esp, v_n;
    end if;
  end loop;

  return jsonb_build_object('ok', true, 'tabelas', coalesce(array_length(v_ordem, 1), 0), 'linhas', v_cont);
end;
$$;

-- Só a Edge Function (chave de serviço) pode chamar.
revoke all on function public._backup_excluidas() from public, anon, authenticated;
revoke all on function public._pk_cols(text) from public, anon, authenticated;
revoke all on function public.backup_tabelas() from public, anon, authenticated;
revoke all on function public.restaurar_backup_dados(jsonb, text[]) from public, anon, authenticated;
grant execute on function public._backup_excluidas() to service_role;
grant execute on function public._pk_cols(text) to service_role;
grant execute on function public.backup_tabelas() to service_role;
grant execute on function public.restaurar_backup_dados(jsonb, text[]) to service_role;
