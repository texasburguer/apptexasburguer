-- ============================================================================
-- ARQUIVAMENTO · FASE 3 · 2026-10-16 · seguro para rodar de novo
-- 1) fila de anonimização para as linhas que já estão na planilha (LGPD): a função arquivar-antigos esvazia a fila todo dia
-- 2) api_simular_arquivamento: mostra o que seria arquivado, SEM mover nada, e confere resumo x histórico
-- ============================================================================
create table if not exists public.anonimizar_arquivo_fila (
  id         bigserial primary key,
  telefone   text not null default '',
  cliente_id uuid,
  criado_em  timestamptz not null default now(),
  feito_em   timestamptz,
  tentativas integer not null default 0
);
alter table public.anonimizar_arquivo_fila enable row level security;
revoke all on public.anonimizar_arquivo_fila from anon, authenticated;
create index if not exists anon_fila_pendente_idx on public.anonimizar_arquivo_fila (id) where feito_em is null;

CREATE OR REPLACE FUNCTION public._anonimizar_cliente(p_cli uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_dig text;
begin
  if p_cli is null then return; end if;
  select _so_digitos(telefone) into v_dig from clientes where id = p_cli;
  insert into anonimizar_arquivo_fila (telefone, cliente_id) values (coalesce(v_dig, ''), p_cli);   -- linhas já arquivadas na planilha
  update vendas set cliente_nome = 'Cliente anonimizado', telefone_cliente = '', endereco = '', complemento = '', referencia = '', observacoes_entrega = '', cpf_nota = null
   where cliente_id = p_cli or (coalesce(v_dig, '') <> '' and _so_digitos(telefone_cliente) = v_dig);
  update vendas_resumo_arquivo set cliente_nome = 'Cliente anonimizado', telefone = '', endereco = '', complemento = ''
   where cliente_id = p_cli or (coalesce(v_dig, '') <> '' and telefone = v_dig);
  update feedbacks set telefone_cliente = '' where cliente_id = p_cli or (coalesce(v_dig, '') <> '' and _so_digitos(telefone_cliente) = v_dig);
  update clientes set nome = 'Cliente anonimizado', telefone = null, endereco = '', data_nascimento = null, observacoes = '', como_conheceu = '' where id = p_cli;
end $function$;

CREATE OR REPLACE FUNCTION public.api_conta_apagar(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente := _conta_exigir(); v_anon boolean := coalesce(p->>'anonimizar', '') in ('true', 't');
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  if v_anon then
    if c.cliente_id is not null then perform _anonimizar_cliente(c.cliente_id); end if;
    insert into anonimizar_arquivo_fila (telefone)
      select distinct t from (
        select _so_digitos(v.telefone_cliente) t from vendas v where v.id in (select venda_id from contas_pedidos where user_id = c.user_id)
        union select r.telefone from vendas_resumo_arquivo r where r.user_id = c.user_id
        union select nullif(c.telefone, '')) x where coalesce(t, '') <> '';
    update vendas set cliente_nome = 'Cliente anonimizado', telefone_cliente = '', endereco = '', complemento = '', referencia = '', observacoes_entrega = '', cpf_nota = null
     where id in (select venda_id from contas_pedidos where user_id = c.user_id);
    update vendas_resumo_arquivo set cliente_nome = 'Cliente anonimizado', telefone = '', endereco = '', complemento = '' where user_id = c.user_id;
  end if;
  perform _mp_anonimizar_reservas(c.user_id);
  update cupons_usos set user_id = null where user_id = c.user_id;
  perform _auditar_publico('Conta de cliente apagada', case when v_anon then 'com anonimização do histórico' else 'histórico mantido' end, '');
  delete from contas_cliente where user_id = c.user_id;
  delete from auth.users where id = c.user_id;
  return jsonb_build_object('ok', true, 'message', 'Conta apagada.');
end $function$;

-- 2) Simulação (só leitura, só Admin): mesmos critérios do lote real
CREATE OR REPLACE FUNCTION public.api_simular_arquivamento(p_dias integer DEFAULT 90)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_corte timestamptz := now() - (greatest(coalesce(p_dias, 90), 30) || ' days')::interval; r jsonb;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select jsonb_build_object('ok', true, 'dias', greatest(coalesce(p_dias, 90), 30),
    'vendasAntigas', count(*),
    'vendasArquivaveis', count(*) filter (where ok),
    'vendasBloqueadas', count(*) filter (where not ok),
    'bloqReembolso', count(*) filter (where tem_reemb),
    'maisAntiga', min(data_hora) filter (where ok), 'maisNova', max(data_hora) filter (where ok)) into r
  from (
    select v.data_hora,
      exists (select 1 from reembolsos x where x.venda_id = v.id) tem_reemb,
      ((v.status = 'Cancelada' or (v.status_pagamento = 'Pago' and coalesce(v.status_pedido::text,'Entregue') in ('Entregue','Retirada','Servida')))
        and not exists (select 1 from ajustes_pos_venda a where a.venda_id = v.id)
        and not exists (select 1 from entregas_fechadas e where e.venda_id = v.id)
        and not exists (select 1 from reembolsos x where x.venda_id = v.id)
        and not (v.status <> 'Cancelada' and v.tipo::text = 'Entrega' and v.entregador_id is not null and v.fechamento_entrega_id is null)
        and not exists (select 1 from ocorrencias o where o.venda_id = v.id and o.status::text <> 'Resolvida')
        and not exists (select 1 from chat_conversas c where c.venda_id = v.id and c.estado <> 'encerrada')) ok
      from vendas v where v.data_hora < v_corte) t;
  return r || jsonb_build_object(
    'caixasArquivaveis', (select count(*) from caixa_sessoes c where c.status = 'Fechado' and c.fechamento < v_corte and not exists (select 1 from vendas v where v.caixa_id = c.id)),
    'resumoGuardado', (select count(*) from vendas_resumo_arquivo),
    'historicoArquivadas', (select count(*) from arquivo_historico where tabela = 'vendas'),
    'filaAnonimizacao', (select count(*) from anonimizar_arquivo_fila where feito_em is null));
end $function$;
grant execute on function public.api_simular_arquivamento(integer) to authenticated;
revoke all on function public.api_simular_arquivamento(integer) from public, anon;
