-- =====================================================================
-- Fase 3 · Mercado Pago · cancelar no Mercado Pago o Pix de reserva vencida (2026-10-16)
-- Contexto: a reserva vence em minutos, mas o Pix no Mercado Pago dura no mínimo 30 min. Sem isto, o cliente podia pagar um QR
-- "morto" (cobrado sem pedido). Antes só a tela do cliente cancelava lá (mp-status), e só se ela ainda estivesse aberta.
-- Agora: o cron chama a função de nuvem mp-cancelar, que cancela no Mercado Pago os Pix já vencidos/cancelados do nosso lado.
-- Corrida: se o cancelamento falhar porque o cliente acabou de pagar, a função lê o pedido, aplica o status real
-- (mp_aplicar_status) e o banco leva o pagamento para "Pagamento a decidir" (Pix pago depois de vencer), em vez de ignorar.
-- Não muda a regra da reserva. Idempotente. Não apaga nem altera dados existentes.
-- =====================================================================
alter table public.pagamentos_online
  add column if not exists mp_cancelado_em timestamptz,
  add column if not exists mp_cancelar_tentativas int not null default 0;

-- Pix que o nosso banco já encerrou (vencido/cancelado) e que ainda pode estar aberto no Mercado Pago (últimas 3 h, até 5 tentativas)
create or replace function public.mp_pendentes_cancelar() returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', t.id, 'modo', t.mp_modo, 'orderId', t.mp_order_id) order by t.atualizado_em), '[]'::jsonb)
  from (select id, mp_modo, mp_order_id, atualizado_em from pagamentos_online
         where metodo = 'pix' and status in ('expirado', 'cancelado') and mp_order_id is not null
           and mp_cancelado_em is null and mp_cancelar_tentativas < 5 and atualizado_em > now() - interval '3 hours'
         order by atualizado_em limit 20) t
$$;

-- Resultado de cada tentativa (não mexe em atualizado_em, para a janela de 3 h contar a partir do último evento real)
create or replace function public.mp_cancelar_resultado(p_id uuid, p_ok boolean, p_erro text default '') returns void
language sql security definer set search_path = public as $$
  update pagamentos_online
     set mp_cancelado_em = case when p_ok then now() else mp_cancelado_em end,
         mp_cancelar_tentativas = case when p_ok then mp_cancelar_tentativas else mp_cancelar_tentativas + 1 end,
         erro = case when p_ok then erro else left(coalesce(nullif(p_erro, ''), erro), 300) end
   where id = p_id
$$;

revoke all on function public.mp_pendentes_cancelar() from public, anon, authenticated;
revoke all on function public.mp_cancelar_resultado(uuid, boolean, text) from public, anon, authenticated;
grant execute on function public.mp_pendentes_cancelar() to service_role;
grant execute on function public.mp_cancelar_resultado(uuid, boolean, text) to service_role;

-- Cron: todo minuto, só chama a função de nuvem se houver Pix a cancelar
do $$ begin
  if exists (select 1 from cron.job where jobname = 'mp-cancelar-pix') then perform cron.unschedule('mp-cancelar-pix'); end if;
  perform cron.schedule('mp-cancelar-pix', '* * * * *',
    $c$select case when jsonb_array_length(public.mp_pendentes_cancelar()) > 0 then public.chamar_edge('mp-cancelar', '{}'::jsonb) end$c$);
end $$;
