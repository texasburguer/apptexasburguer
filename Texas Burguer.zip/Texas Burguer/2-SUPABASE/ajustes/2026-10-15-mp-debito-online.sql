-- 2026-10-15 · Mercado Pago: cartão de débito online + seletor "Só na entrega / Também online".
-- JÁ APLICADO no Supabase pelo conector (migration mp_debito_online_banco). Guardado aqui só para reconstruir o banco.
-- Depois desta etapa, a função mp-criar também foi republicada (aceita type debit_card).
alter table formas_pagamento drop constraint formas_pagamento_tipo_online_check;
alter table formas_pagamento add constraint formas_pagamento_tipo_online_check check (tipo_online is null or tipo_online = any (array['pix','credito','debito']));
alter table pagamentos_online drop constraint pagamentos_online_metodo_check;
alter table pagamentos_online add constraint pagamentos_online_metodo_check check (metodo = any (array['pix','credito','debito']));

-- api_mp_forma_online(p): liga/desliga a forma no site; o tipo (pix, credito, debito) vem do NOME da forma quando "tipoOnline" não é enviado.
--   Recusa dinheiro/troco, forma oculta ou inativa e nomes que não sejam Pix, Crédito ou Débito; uma forma por tipo.
-- _integ_pendencias(prov, modo): o passo "teste_guiado" do Mercado Pago exige um pagamento de teste aprovado para CADA forma online ligada.
-- api_mp_pagamentos_recentes(p): devolve também testeDebito.
-- mp_preparar_pagamento(p): a trava de "pagamento em andamento (2 min)" vale para crédito e débito.
-- (Os corpos completos das funções estão na migration aplicada; para refazer, peça ao Claude reaplicar pelo conector.)
