-- Visitas ao cardápio eletrônico (11/10/2026). Pode rodar mais de uma vez.
-- 1 visita por aparelho por dia (dia de São Paulo). A página não chama isto em aparelho da equipe.
create table if not exists public.cardapio_visitas (
  dia date not null,
  aparelho text not null,
  criado_em timestamptz not null default now(),
  primary key (dia, aparelho)
);
alter table public.cardapio_visitas enable row level security;
revoke all on table public.cardapio_visitas from public, anon, authenticated;

create or replace function public.api_registrar_visita_cardapio(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public'
as $function$
declare v_ap text := lower(btrim(coalesce(p->>'aparelho', ''))); v_dia date := (now() at time zone 'America/Sao_Paulo')::date;
begin
  if v_ap !~ '^[a-z0-9]{16,40}$' then return jsonb_build_object('ok', false); end if;
  if (select count(*) from cardapio_visitas where dia = v_dia) >= 20000 then return jsonb_build_object('ok', true); end if;
  insert into cardapio_visitas (dia, aparelho) values (v_dia, v_ap) on conflict do nothing;
  return jsonb_build_object('ok', true);
end $function$;
revoke all on function public.api_registrar_visita_cardapio(jsonb) from public;
grant execute on function public.api_registrar_visita_cardapio(jsonb) to anon, authenticated;

create or replace function public.api_visitas_cardapio_hoje(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public'
as $function$
declare v_dia date := (now() at time zone 'America/Sao_Paulo')::date;
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'hoje', (select count(*) from cardapio_visitas where dia = v_dia));
end $function$;
revoke all on function public.api_visitas_cardapio_hoje(jsonb) from public, anon;
grant execute on function public.api_visitas_cardapio_hoje(jsonb) to authenticated;

-- Ajuda da IA
insert into public.ai_ajuda (slug, titulo, grupo, ordem, perfis, ativo, palavras_chave, passos, comuns, atualizado_em)
select 'man-admin-111-visitas-cardapio', 'Tela Início e visitas ao cardápio', 'lista', 111, array['Admin','Operador'], true,
  'visitas cardápio acessos clientes abriram contador início resumo alerta faixa mesas',
  E'No Início: alerta numa faixa fina no topo (só quando há algo), pedidos em andamento, caixa e vendas de hoje, visitas ao cardápio e mesas (com o valor a receber das mesas).\n"Cardápio hoje" conta os clientes que abriram o cardápio eletrônico hoje: cada celular ou computador conta 1 vez por dia. Zera à meia-noite.\nAparelhos da equipe não contam: depois que alguém entra no sistema interno naquele aparelho, ele nunca mais conta.\nÉ uma estimativa: a mesma pessoa em dois aparelhos conta duas vezes; aba anônima ou navegador limpo contam de novo.',
  'Administrador e Operador veem as visitas.', now()
where not exists (select 1 from public.ai_ajuda where slug = 'man-admin-111-visitas-cardapio');
