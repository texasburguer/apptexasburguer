-- JA APLICADO no Supabase (17/10/2026). Serve para refazer o banco.
CREATE OR REPLACE FUNCTION public.api_desvincular_adicionais_em_lote(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_cats uuid[]; v_prod int; v_rem int;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select coalesce(array_agg(_uuid(x)) filter (where _uuid(x) is not null), '{}') into v_cats
    from jsonb_array_elements_text(coalesce(p->'categorias', '[]'::jsonb)) x;
  if coalesce(array_length(v_cats, 1), 0) = 0 then return _falha('Escolha ao menos uma categoria.'); end if;
  select count(*) into v_prod from produtos where categoria_id = any(v_cats);
  with del as (
    delete from produto_adicionais pa using produtos pr
    where pa.produto_id = pr.id and pr.categoria_id = any(v_cats) returning 1)
  select count(*) into v_rem from del;
  perform _auditar('Adicionais desvinculados em lote', v_prod || ' produtos, ' || v_rem || ' vínculos removidos');
  return jsonb_build_object('ok', true, 'message', case when v_rem > 0 then v_rem || ' vínculos removidos de ' || v_prod || ' produtos.' else 'Essas categorias já estavam sem adicionais.' end);
end $function$;
revoke all on function public.api_desvincular_adicionais_em_lote(p jsonb) from public, anon, authenticated;
grant execute on function public.api_desvincular_adicionais_em_lote(p jsonb) to authenticated;
