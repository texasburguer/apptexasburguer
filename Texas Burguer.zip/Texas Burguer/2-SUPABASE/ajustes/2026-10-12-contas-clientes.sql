-- ============================================================================
-- CONTAS DE CLIENTES (login com Google), cupons da conta, LGPD · 2026-10-12 · seguro para rodar de novo
-- Parte 1: tabelas e colunas · Parte 2: funções (cópia do que está no banco) · Parte 3: gatilhos, tarefas agendadas e permissões
-- Funções que APAGAM dados (excluir endereço, apagar conta) ficam no arquivo 2026-10-12-contas-clientes-MANUAL.sql:
-- o conector do Supabase bloqueia "delete" dentro de função, então aquele arquivo é colado à mão no SQL Editor.
-- ============================================================================

-- ============================================================================
-- Contas de clientes (login com Google) — PARTE 1: estrutura
-- Só tabelas, colunas novas e ajustes de segurança. Nada aqui muda o que já funciona.
-- ============================================================================

-- 1) Conta do cliente. Sem acesso direto (nenhuma política): tudo passa pelas funções api_conta_*.
create table if not exists public.contas_cliente (
  user_id            uuid primary key references auth.users(id) on delete cascade,
  email              text not null default '',
  nome               text not null default '',
  telefone           text not null default '',                 -- dígitos; só preenchido ao juntar com o histórico (1º pedido concluído)
  cliente_id         uuid references public.clientes(id) on delete set null,
  data_nascimento    date,
  nasc_alterado_em   timestamptz,
  codigo_indicacao   text unique,
  indicado_por       uuid references public.contas_cliente(user_id) on delete set null,
  indicacao_premiada boolean not null default false,
  aceite_versao      integer not null default 0,
  aceite_em          timestamptz,
  promo_ok           boolean not null default false,           -- aceite SEPARADO para receber promoções
  promo_em           timestamptz,
  criado_em          timestamptz not null default now(),
  ultimo_acesso      timestamptz
);
alter table public.contas_cliente enable row level security;
revoke all on public.contas_cliente from anon, authenticated;
create index if not exists contas_cliente_cliente_idx on public.contas_cliente (cliente_id) where cliente_id is not null;

-- 2) Pedidos feitos com a conta (tabela à parte: a tabela vendas e a cópia para a planilha não mudam).
create table if not exists public.contas_pedidos (
  venda_id  uuid primary key references public.vendas(id) on delete cascade,
  user_id   uuid not null references public.contas_cliente(user_id) on delete cascade,
  criado_em timestamptz not null default now()
);
alter table public.contas_pedidos enable row level security;
revoke all on public.contas_pedidos from anon, authenticated;
create index if not exists contas_pedidos_user_idx on public.contas_pedidos (user_id);

-- 3) Endereços salvos
create table if not exists public.contas_enderecos (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.contas_cliente(user_id) on delete cascade,
  apelido     text not null default '',
  endereco    text not null default '',
  numero      text not null default '',
  cidade      text not null default '',
  complemento text not null default '',
  referencia  text not null default '',
  criado_em   timestamptz not null default now()
);
alter table public.contas_enderecos enable row level security;
revoke all on public.contas_enderecos from anon, authenticated;
create index if not exists contas_enderecos_user_idx on public.contas_enderecos (user_id);

-- 4) Cupons: novas opções (tudo editável na Central de Promoções e Cupons)
alter table public.cupons add column if not exists somente_conta boolean not null default false;
alter table public.cupons add column if not exists cliente_id    uuid references public.clientes(id) on delete set null;
alter table public.cupons add column if not exists mensagem      text not null default '';
alter table public.cupons add column if not exists visivel_conta boolean not null default false;
alter table public.cupons add column if not exists automatico    text;
alter table public.cupons add column if not exists validade_dias integer not null default 30;
do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'cupons_automatico_chk') then
    alter table public.cupons add constraint cupons_automatico_chk check (automatico is null or automatico in ('boas_vindas','aniversario','indicacao_indicador','indicacao_indicado'));
  end if;
  if not exists (select 1 from pg_constraint where conname = 'cupons_validade_dias_chk') then
    alter table public.cupons add constraint cupons_validade_dias_chk check (validade_dias between 1 and 365);
  end if;
end $$;
create unique index if not exists cupons_automatico_uq on public.cupons (automatico) where automatico is not null;
alter table public.cupons_usos add column if not exists user_id uuid;
create index if not exists cupons_usos_user_idx on public.cupons_usos (user_id) where user_id is not null;

-- 5) Cupons recebidos pela conta (boas-vindas, aniversário, indique e ganhe)
create table if not exists public.cupons_concedidos (
  id         uuid primary key default gen_random_uuid(),
  cupom_id   uuid not null references public.cupons(id) on delete cascade,
  user_id    uuid not null references public.contas_cliente(user_id) on delete cascade,
  origem     text not null,
  ref        text not null default '',
  valido_ate date,
  usado_em   timestamptz,
  venda_id   uuid,
  criado_em  timestamptz not null default now(),
  unique (cupom_id, user_id, origem, ref)
);
alter table public.cupons_concedidos enable row level security;
revoke all on public.cupons_concedidos from anon, authenticated;
create index if not exists cupons_concedidos_user_idx on public.cupons_concedidos (user_id);

-- 6) Configurações padrão
insert into public.sistema (chave, valor) select 'LgpdAnosAnonimizar', '3'::jsonb where not exists (select 1 from public.sistema where chave = 'LgpdAnosAnonimizar');
insert into public.sistema (chave, valor) select 'AvisoPrivacidadeVersao', '1'::jsonb where not exists (select 1 from public.sistema where chave = 'AvisoPrivacidadeVersao');

-- 7) Os 4 cupons automáticos já nascem DESLIGADOS (nada é oferecido até o Administrador ativar e ajustar na Central).
insert into public.cupons (codigo, nome, tipo, valor, valor_minimo, ativa, somente_conta, automatico, validade_dias, limite_por_cliente, mensagem)
select 'BOASVINDAS', 'Boas-vindas', 'percentual', 10, 0, false, true, 'boas_vindas', 30, 1, 'Cupom de boas-vindas pela sua conta!'
where not exists (select 1 from public.cupons where automatico = 'boas_vindas' or codigo = 'BOASVINDAS');
insert into public.cupons (codigo, nome, tipo, valor, valor_minimo, ativa, somente_conta, automatico, validade_dias, limite_por_cliente, mensagem)
select 'ANIVERSARIO', 'Aniversário', 'fixo', 10, 30, false, true, 'aniversario', 7, 1, 'Feliz aniversário! Um presente do Texas Burger para você.'
where not exists (select 1 from public.cupons where automatico = 'aniversario' or codigo = 'ANIVERSARIO');
insert into public.cupons (codigo, nome, tipo, valor, valor_minimo, ativa, somente_conta, automatico, validade_dias, limite_por_cliente, mensagem)
select 'INDICADOR', 'Indique e ganhe — quem indicou', 'fixo', 10, 30, false, true, 'indicacao_indicador', 30, 1, 'Seu amigo fez o primeiro pedido! Este cupom é seu.'
where not exists (select 1 from public.cupons where automatico = 'indicacao_indicador' or codigo = 'INDICADOR');
insert into public.cupons (codigo, nome, tipo, valor, valor_minimo, ativa, somente_conta, automatico, validade_dias, limite_por_cliente, mensagem)
select 'INDICADO', 'Indique e ganhe — quem foi indicado', 'fixo', 10, 30, false, true, 'indicacao_indicado', 30, 1, 'Você chegou por indicação de um amigo. Este cupom é seu.'
where not exists (select 1 from public.cupons where automatico = 'indicacao_indicado' or codigo = 'INDICADO');


-- ===================== PARTE 2: funções =====================

CREATE OR REPLACE FUNCTION public._anonimizar_cliente(p_cli uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_dig text;
begin
  if p_cli is null then return; end if;
  select _so_digitos(telefone) into v_dig from clientes where id = p_cli;
  update vendas set cliente_nome = 'Cliente anonimizado', telefone_cliente = '', endereco = '', complemento = '', referencia = '', observacoes_entrega = '', cpf_nota = null
   where cliente_id = p_cli or (coalesce(v_dig, '') <> '' and _so_digitos(telefone_cliente) = v_dig);
  update feedbacks set telefone_cliente = '' where cliente_id = p_cli or (coalesce(v_dig, '') <> '' and _so_digitos(telefone_cliente) = v_dig);
  update clientes set nome = 'Cliente anonimizado', telefone = null, endereco = '', data_nascimento = null, observacoes = '', como_conheceu = '' where id = p_cli;
end $function$
;

CREATE OR REPLACE FUNCTION public._aviso_versao()
 RETURNS integer
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$ select coalesce((select _num(valor #>> '{}')::int from sistema where chave = 'AvisoPrivacidadeVersao'), 1) $function$
;

CREATE OR REPLACE FUNCTION public._conceder_cupom_auto(p_tipo text, p_user uuid, p_ref text)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c cupons%rowtype; n int;
begin
  select * into c from cupons where automatico = p_tipo and ativa;
  if not found then return false; end if;
  insert into cupons_concedidos (cupom_id, user_id, origem, ref, valido_ate) values (c.id, p_user, p_tipo, coalesce(p_ref, ''), _hoje_br() + c.validade_dias)
  on conflict do nothing;
  get diagnostics n = row_count;
  return n > 0;
end $function$
;

CREATE OR REPLACE FUNCTION public._conta_atual()
 RETURNS contas_cliente
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$ select * from contas_cliente where user_id = auth.uid() $function$
;

CREATE OR REPLACE FUNCTION public._conta_cupom_usado(p_user uuid, p_cupom uuid, p_venda uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if p_user is null then return; end if;
  update cupons_concedidos set usado_em = now(), venda_id = p_venda
   where id = (select id from cupons_concedidos where cupom_id = p_cupom and user_id = p_user and usado_em is null and (valido_ate is null or valido_ate >= _hoje_br())
                order by valido_ate nulls last, criado_em limit 1);
end $function$
;

CREATE OR REPLACE FUNCTION public._conta_exigir()
 RETURNS contas_cliente
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente;
begin
  if auth.uid() is null or auth_nivel() is not null then return null; end if;
  select * into c from contas_cliente where user_id = auth.uid() and aceite_versao > 0;
  if c.user_id is null then return null; end if;
  return c;
end $function$
;

CREATE OR REPLACE FUNCTION public._conta_premiar_indicacao(p_user uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente; ind contas_cliente; v_mes int;
begin
  select * into c from contas_cliente where user_id = p_user;
  if c.user_id is null or c.indicado_por is null or c.indicacao_premiada then return; end if;
  select * into ind from contas_cliente where user_id = c.indicado_por;
  update contas_cliente set indicacao_premiada = true where user_id = p_user;
  if ind.user_id is null or ind.aceite_versao = 0 then return; end if;
  if ind.telefone <> '' and ind.telefone = c.telefone then return; end if;
  select count(*) into v_mes from cupons_concedidos where user_id = ind.user_id and origem = 'indicacao_indicador' and criado_em > now() - interval '30 days';
  if v_mes >= 10 then return; end if;
  perform _conceder_cupom_auto('indicacao_indicado', p_user, p_user::text);
  perform _conceder_cupom_auto('indicacao_indicador', ind.user_id, p_user::text);
end $function$
;

CREATE OR REPLACE FUNCTION public._criar_pedido_publico(p jsonb, p_mesa_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_eh_mesa boolean := p_mesa_id is not null; v_mesa mesas%rowtype;
  v_nome text := _texto_publico(p->>'clienteNome', 80);
  v_tel text := case when p_mesa_id is not null then '' else _texto_publico(p->>'clienteTelefone', 20) end;
  v_dig text := case when p_mesa_id is not null then '' else _so_digitos(p->>'clienteTelefone') end;
  v_obs_troco text := _texto_publico(p->>'observacaoTroco', 200);
  v_de jsonb := case when jsonb_typeof(p->'dadosEntrega') = 'object' then p->'dadosEntrega' else '{}'::jsonb end;
  v_end text := _texto_publico(v_de->>'endereco', 200); v_comp text := _texto_publico(v_de->>'complemento', 100); v_ref text := _texto_publico(v_de->>'referencia', 150);
  v_obs_ent text := _texto_publico(coalesce(nullif(p->>'observacoes', ''), v_de->>'observacoes'), 300);
  v_itens jsonb := p->'itens'; v_tipo_in text := p->>'tipoEntrega'; v_ip text := _ip_cliente();
  v_req text := nullif(left(btrim(coalesce(p->>'requisicaoId', '')), 80), '');
  v_forma formas_pagamento%rowtype; v_caixa uuid; v_tipo venda_tipo; v_ja record; v_prod produtos%rowtype; v_comb combos%rowtype;
  it record; r record; v_prod_id uuid; v_comb_id uuid; v_qtd numeric; v_preco numeric; v_custo_u numeric; v_nome_item text; v_extra numeric; v_n_ad int; v_n_ok int;
  v_ads text; v_obs_item text; v_ads_ids jsonb; v_itens_ok jsonb := '[]'::jsonb; v_orig numeric := 0; v_custo numeric := 0;
  v_cod text := ''; v_cup jsonb; v_desc numeric := 0; v_frete boolean := false; v_taxa numeric := 0; v_pad numeric; v_total numeric;
  v_venda uuid := gen_random_uuid(); v_numero int; v_cli uuid; v_chave text; v_obs_final text; v_bloqueia boolean; v_forma_nome text; v_acr numeric := 0; v_bloq text; v_user uuid := (select cc.user_id from contas_cliente cc where cc.user_id = auth.uid() and cc.aceite_versao > 0);
begin
  -- repetição do mesmo envio (duplo toque, nova tentativa): devolve o pedido já criado, sem criar outro
  if v_req is not null then
    perform pg_advisory_xact_lock(hashtext('venda:' || v_req));
    select id, numero_pedido, valor_total into v_ja from vendas where requisicao_id = v_req;
    if found then
      return jsonb_build_object('ok', true, 'duplicado', true, 'id', v_ja.id, 'numero', v_ja.numero_pedido, 'valorTotal', v_ja.valor_total, 'message', 'Pedido já recebido — envio repetido ignorado.');
    end if;
  end if;

  if jsonb_typeof(v_itens) <> 'array' or jsonb_array_length(v_itens) = 0 then return _falha('Carrinho vazio.'); end if;
  if jsonb_array_length(v_itens) > 40 then return _falha('Carrinho grande demais.'); end if;
  if v_eh_mesa then
    if v_nome = '' then return _falha('Informe o seu nome.'); end if;
    v_chave := 'pedmesa_' || p_mesa_id::text;
  else
    if v_nome = '' or v_dig = '' then return _falha('Informe nome e telefone.'); end if;
    if length(v_dig) < 10 or length(v_dig) > 13 then return _falha('Informe um telefone válido com DDD.'); end if;
    v_chave := 'pedcard_' || v_dig;
  end if;
  if _excedeu('pedcard_global', 150) then return _falha('Estamos com muitos pedidos no momento. Tente novamente em alguns minutos ou ligue para o restaurante.'); end if;
  if _excedeu('pedcard_ip_' || v_ip, 40) then return _falha('Muitos pedidos em sequência deste local. Aguarde alguns minutos.'); end if;
  if _excedeu(v_chave, case when v_eh_mesa then 8 else 5 end) then
    return _falha(case when v_eh_mesa then 'Muitos pedidos em sequência nesta mesa. Chame o garçom.' else 'Muitos pedidos em sequência. Aguarde alguns minutos.' end);
  end if;

  -- cardápio fechado à mão ou em período programado (pedido de mesa, feito dentro do restaurante, não é bloqueado)
  if not v_eh_mesa then
    v_bloq := _cardapio_bloqueio();
    if v_bloq is not null then return _falha(v_bloq); end if;
  end if;
  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;
  if v_caixa is null then return _falha('Estamos fechados no momento. Tente novamente mais tarde.'); end if;

  if v_eh_mesa then
    select * into v_mesa from mesas where id = p_mesa_id for update;
    if not found then return _falha('Mesa não encontrada.'); end if;
    if v_mesa.status::text not in ('Livre', 'Ocupada') then
      return _falha(case when v_mesa.status::text = 'Aguardando fechamento' then 'A conta desta mesa já foi pedida. Chame o garçom para novos pedidos.' else 'Esta mesa não está disponível para pedidos pelo celular. Chame o garçom.' end);
    end if;
    v_tipo := 'Mesa';
    -- mesa: o cliente não escolhe a forma; vale a primeira forma do cardápio só para o preço (o recebimento é feito no fechamento da conta)
    select * into v_forma from formas_pagamento where ativa and visivel_cardapio order by ordem limit 1;
    v_forma_nome := 'A Receber (Mesa)';
  else
    v_tipo := (case when v_tipo_in = 'Entrega' then 'Entrega' else 'Retirada' end)::venda_tipo;
    if v_tipo = 'Entrega' and v_end = '' then return _falha('Informe o endereço de entrega.'); end if;
    if v_tipo = 'Entrega' then
      declare v_num text := _texto_publico(v_de->>'numero', 20); v_cid text := _texto_publico(v_de->>'cidade', 80);
              v_cid_loc text := _texto_publico(v_de->>'cidadeLocalizacao', 80); v_lista jsonb; v_nomes text;
      begin
        if v_de ? 'numero' and v_num = '' then return _falha('Informe o número da casa (ou "s/n").'); end if;
        if v_de ? 'cidade' and v_cid = '' then return _falha('Informe a cidade da entrega.'); end if;
        if v_num <> '' then v_end := left(v_end || ', nº ' || v_num, 200); end if;
        if v_cid <> '' then v_end := left(v_end || ' — ' || v_cid, 200); end if;
      end;
    end if;
    select * into v_forma from formas_pagamento where id = _uuid(p->>'formaPagamentoId') and ativa and visivel_cardapio;
    v_forma_nome := v_forma.nome;
  end if;
  if v_forma.id is null then return _falha('Forma de pagamento inválida.'); end if;

  -- itens: tudo vem do cadastro (produto/combo ativo, preço da forma escolhida, adicionais ativos e vinculados)
  for it in select value as e from jsonb_array_elements(v_itens) loop
    v_qtd := _num(it.e->>'quantidade');
    if v_qtd <= 0 then continue; end if;
    if v_qtd > 50 or v_qtd <> floor(v_qtd) then return _falha('Quantidade inválida no carrinho.'); end if;
    v_prod_id := _uuid(it.e->>'produtoId'); v_comb_id := _uuid(it.e->>'comboId');
    if (v_prod_id is null) = (v_comb_id is null) then return _falha('Item inválido no carrinho.'); end if;
    if jsonb_typeof(it.e->'adicionaisIds') = 'array' and jsonb_array_length(it.e->'adicionaisIds') > 20 then return _falha('Adicionais demais em um item.'); end if;
    if v_prod_id is not null then
      select * into v_prod from produtos where id = v_prod_id and ativo;
      if not found then return _falha('Um dos produtos não está mais disponível.'); end if;
      v_nome_item := v_prod.nome;
      select preco, custo into v_preco, v_custo_u from produto_precos where produto_id = v_prod_id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_nome_item || '" não tem preço configurado para essa forma de pagamento.'); end if;
    else
      select * into v_comb from combos where id = v_comb_id and ativo;
      if not found then return _falha('Um dos combos não está mais disponível.'); end if;
      if exists (select 1 from combo_itens ci join produtos pr on pr.id = ci.produto_id where ci.combo_id = v_comb_id and not pr.ativo) then
        return _falha('O combo "' || v_comb.nome || '" está temporariamente indisponível.');
      end if;
      v_nome_item := v_comb.nome;
      select preco, custo into v_preco, v_custo_u from combo_precos where combo_id = v_comb_id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_nome_item || '" não tem preço configurado para essa forma de pagamento.'); end if;
    end if;
    select count(*), coalesce(sum(a.preco), 0),
           count(a.id) filter (where a.ativo and ((v_prod_id is not null and exists (select 1 from produto_adicionais pa where pa.produto_id = v_prod_id and pa.adicional_id = a.id)) or (v_comb_id is not null and exists (select 1 from combo_itens ci join produto_adicionais pa on pa.produto_id = ci.produto_id where ci.combo_id = v_comb_id and pa.adicional_id = a.id)))),
           coalesce(string_agg(' + ' || a.nome, '' order by s.ord) filter (where a.id is not null), ''),
           coalesce(jsonb_agg(a.id order by s.ord) filter (where a.id is not null), '[]'::jsonb)
      into v_n_ad, v_extra, v_n_ok, v_ads, v_ads_ids
      from jsonb_array_elements_text(case when jsonb_typeof(it.e->'adicionaisIds') = 'array' then it.e->'adicionaisIds' else '[]'::jsonb end) with ordinality as s(x, ord)
      left join adicionais a on a.id = _uuid(s.x);
    if v_n_ad <> v_n_ok then return _falha('Um adicional escolhido para "' || v_nome_item || '" não está disponível.'); end if;
    v_obs_item := _texto_publico(it.e->>'observacao', 100);
    v_itens_ok := v_itens_ok || jsonb_build_array(jsonb_build_object('produtoId', v_prod_id, 'comboId', v_comb_id,
      'descricao', v_nome_item || v_ads || case when v_obs_item <> '' then ' — Obs: ' || v_obs_item else '' end,
      'quantidade', v_qtd, 'valorUnitario', v_preco + v_extra, 'custoUnitario', v_custo_u, 'adicionaisIds', v_ads_ids));
    v_orig := v_orig + round(v_qtd * (v_preco + v_extra), 2); v_custo := v_custo + v_qtd * v_custo_u;
  end loop;
  if jsonb_array_length(v_itens_ok) = 0 then return _falha('Carrinho vazio.'); end if;
  v_orig := round(v_orig, 2); v_custo := round(v_custo, 2);

  select coalesce((select (valor #>> '{}') = 'true' from sistema where chave = 'BLOQUEAR_ESTOQUE_NEGATIVO'), false) into v_bloqueia;
  if v_bloqueia then
    for r in select c.ingrediente_id, c.qtd, e.quantidade from _consumo(v_itens_ok) c join estoque e on e.id = c.ingrediente_id loop
      if r.quantidade + 0.000000001 < r.qtd then return _falha('Um dos itens do pedido acabou. Escolha outro item ou fale com o restaurante.'); end if;
    end loop;
  end if;

  -- cupom (só no cardápio comum; travado por código para dois pedidos simultâneos não estourarem o limite)
  if not v_eh_mesa then
    v_cod := upper(regexp_replace(btrim(coalesce(p->>'codigoCupom', '')), '\s+', '', 'g'));
    if v_cod <> '' then
      perform pg_advisory_xact_lock(hashtext('cupom:' || v_cod));
      v_cup := _cupom_calcular(v_cod, v_tel, v_orig, v_tipo::text, v_user);
      if coalesce(v_cup->>'ok', '') <> 'true' then return v_cup; end if;
      v_desc := (v_cup->>'desconto')::numeric; v_frete := (v_cup->>'freteGratis')::boolean;
    end if;
  end if;

  if v_tipo = 'Entrega' and not v_frete then
    select coalesce(_num(valor #>> '{}'), 0) into v_pad from sistema where chave = 'TaxaEntregaPadrao';
    v_taxa := coalesce(v_pad, 0);
  end if;
  v_total := greatest(0.01, round(v_orig - v_desc + v_taxa, 2));
  -- acréscimo da forma de pagamento escolhida (mesa: o acréscimo entra no fechamento da conta)
  if not v_eh_mesa then v_acr := _acrescimo_forma(v_forma, greatest(0.01, v_total - v_taxa)); v_total := round(v_total + v_acr, 2); end if;
  v_obs_final := coalesce(concat_ws(' — ', nullif(v_obs_ent, ''), nullif(v_obs_troco, '')), '');

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido,
                      endereco, complemento, referencia, observacoes_entrega, status_pagamento, valor_original, valor_desconto,
                      desconto_detalhe, origem, mesa_id, taxa_entrega, caixa_id, requisicao_id, acrescimo_forma)
  values (v_venda, v_nome, v_tel, v_forma_nome, v_total, v_custo, 'Confirmada', v_tipo, 'Recebido',
          case when v_tipo = 'Entrega' then v_end else '' end, case when v_tipo = 'Entrega' then v_comp else '' end, case when v_tipo = 'Entrega' then v_ref else '' end,
          v_obs_final, 'A Receber', v_orig, v_desc, case when v_cod <> '' then 'Cupom ' || (v_cup->>'codigo') else '' end, 'Cardápio',
          case when v_eh_mesa then p_mesa_id else null end, v_taxa, v_caixa, v_req, v_acr)
  returning numero_pedido into v_numero;

  insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
  select v_venda, _uuid(e->>'produtoId'), _uuid(e->>'comboId'), e->>'descricao', _num(e->>'quantidade', 1)::int, _num(e->>'valorUnitario'), _num(e->>'custoUnitario'),
         round(_num(e->>'quantidade', 1) * _num(e->>'valorUnitario'), 2),
         coalesce((select array_agg(_uuid(x)) filter (where _uuid(x) is not null) from jsonb_array_elements_text(e->'adicionaisIds') x), '{}')
  from jsonb_array_elements(v_itens_ok) e;

  insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo)
  values (v_venda, v_forma_nome, v_total, case when v_eh_mesa then 0 else round(v_total * v_forma.taxa_percentual / 100 + v_forma.taxa_fixa, 2) end, v_acr);

  if v_eh_mesa and v_mesa.status::text = 'Livre' then update mesas set status = 'Ocupada' where id = p_mesa_id; end if;
  perform _ajustar_estoque(v_itens_ok, 1, v_venda);
  if v_tel <> '' then v_cli := _upsert_cliente(v_tel, v_nome); end if;
  if v_user is not null and not v_eh_mesa then insert into contas_pedidos (venda_id, user_id) values (v_venda, v_user) on conflict do nothing; end if;
  if v_cod <> '' then
    insert into cupons_usos (cupom_id, codigo, venda_id, cliente_id, telefone, desconto, frete_gratis, requisicao_id, user_id)
    values ((v_cup->>'cupomId')::uuid, v_cup->>'codigo', v_venda, v_cli, v_tel, v_desc, v_frete, v_req, v_user);
    perform _conta_cupom_usado(v_user, (v_cup->>'cupomId')::uuid, v_venda);
  end if;
  perform _registrar_falha(v_chave, 600); perform _registrar_falha('pedcard_global', 300); perform _registrar_falha('pedcard_ip_' || v_ip, 600);
  perform _auditar_publico(case when v_eh_mesa then 'Pedido recebido pelo cliente na mesa ' || v_mesa.numero else 'Pedido recebido pelo Cardápio' end,
    'Total R$ ' || _dinheiro(v_total) || case when v_cod <> '' then ' | Cupom ' || (v_cup->>'codigo') else '' end, case when v_eh_mesa then v_nome else v_tel end);

  return jsonb_build_object('ok', true, 'message', 'Pedido enviado! Nº ' || v_numero || '. Total: R$ ' || _dinheiro(v_total) || '.',
    'id', v_venda, 'numero', v_numero, 'valorTotal', v_total, 'valorOriginal', v_orig, 'acrescimo', v_acr, 'valorDesconto', v_desc,
    'cupom', case when v_cod <> '' then v_cup->>'codigo' else '' end, 'freteGratis', v_frete);
end $function$
;

CREATE OR REPLACE FUNCTION public._cupom_calcular(p_codigo text, p_tel text, p_subtotal numeric, p_tipo text)
 RETURNS jsonb
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$ select public._cupom_calcular(p_codigo, p_tel, p_subtotal, p_tipo, null::uuid) $function$
;

CREATE OR REPLACE FUNCTION public._cupom_calcular(p_codigo text, p_tel text, p_subtotal numeric, p_tipo text, p_user uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c cupons%rowtype; v_cod text := upper(regexp_replace(btrim(coalesce(p_codigo, '')), '\s+', '', 'g'));
  v_tel text := _so_digitos(p_tel); v_bruto numeric := round(coalesce(p_subtotal, 0), 2); v_desc numeric := 0;
  v_agora timestamp := now() at time zone 'America/Sao_Paulo'; v_hh int; v_hi int; v_hf int; v_usos int; v_usos_cli int; v_fx record;
  v_conta contas_cliente; v_cc cupons_concedidos;
begin
  if v_cod = '' then return _falha('Informe um cupom.'); end if;
  select * into c from cupons where codigo = v_cod and ativa;
  if not found then return _falha('Cupom inválido ou inativo.'); end if;
  if p_user is not null then select * into v_conta from contas_cliente where user_id = p_user and aceite_versao > 0; end if;
  if (c.somente_conta or c.automatico is not null or c.cliente_id is not null) and v_conta.user_id is null then
    return _falha('Este cupom é para quem tem conta. Entre com a sua conta Google para usar.');
  end if;
  if c.cliente_id is not null and v_conta.cliente_id is distinct from c.cliente_id then
    return _falha('Este cupom não está disponível para a sua conta.');
  end if;
  if (c.data_inicio is not null and v_agora::date < c.data_inicio) or (c.data_fim is not null and v_agora::date > c.data_fim) then
    return _falha('Este cupom está fora do período de validade.');
  end if;
  if c.hora_inicio is not null and c.hora_fim is not null then
    v_hh := extract(hour from v_agora)::int * 60 + extract(minute from v_agora)::int;
    v_hi := extract(hour from c.hora_inicio)::int * 60 + extract(minute from c.hora_inicio)::int;
    v_hf := extract(hour from c.hora_fim)::int * 60 + extract(minute from c.hora_fim)::int;
    if v_hi <= v_hf then
      if v_hh < v_hi or v_hh > v_hf then return _falha('Este cupom está fora do período de validade.'); end if;
    else
      if v_hh < v_hi and v_hh > v_hf then return _falha('Este cupom está fora do período de validade.'); end if;
    end if;
  end if;
  if c.automatico is not null then
    select * into v_cc from cupons_concedidos
     where cupom_id = c.id and user_id = p_user and usado_em is null and (valido_ate is null or valido_ate >= v_agora::date)
     order by valido_ate nulls last, criado_em limit 1;
    if not found then return _falha('Você não tem este cupom disponível (ou ele já venceu).'); end if;
  end if;
  select count(*), count(*) filter (where (v_tel <> '' and _so_digitos(cu.telefone) = v_tel) or (p_user is not null and cu.user_id = p_user))
    into v_usos, v_usos_cli from cupons_usos cu where cu.cupom_id = c.id and not exists (select 1 from vendas vv where vv.id = cu.venda_id and vv.status = 'Cancelada');
  if c.limite_total > 0 and v_usos >= c.limite_total then return _falha('O limite de utilizações deste cupom foi atingido.'); end if;
  if c.automatico in ('boas_vindas', 'indicacao_indicado') then
    if v_usos_cli > 0 then return _falha('Este cupom já foi usado (uma vez por cliente).'); end if;
  elsif c.automatico is null and c.limite_por_cliente > 0 and v_usos_cli >= c.limite_por_cliente then
    return _falha('Você já atingiu o limite de uso deste cupom.');
  end if;
  if v_bruto < c.valor_minimo then return _falha('Este cupom exige pedido mínimo de R$ ' || replace(_dinheiro(c.valor_minimo), '.', ',') || '.'); end if;
  if c.tipo = 'percentual' then
    if c.valor <= 0 or c.valor > 100 then return _falha('Cupom configurado com percentual inválido.'); end if;
    v_desc := round(v_bruto * c.valor / 100, 2);
  elsif c.tipo = 'fixo' then
    if c.valor <= 0 then return _falha('Cupom configurado com valor inválido.'); end if;
    v_desc := least(v_bruto, round(c.valor, 2));
  elsif c.tipo = 'progressivo' then
    select (x->>'minimo')::numeric mn, (x->>'desconto')::numeric ds into v_fx from jsonb_array_elements(c.faixas) x where (x->>'minimo')::numeric <= v_bruto order by (x->>'minimo')::numeric desc limit 1;
    if v_fx.mn is null then
      select min((x->>'minimo')::numeric) into v_fx.mn from jsonb_array_elements(c.faixas) x;
      return _falha('Este cupom vale a partir de R$ ' || replace(_dinheiro(coalesce(v_fx.mn, 0)), '.', ',') || ' em pedidos.');
    end if;
    v_desc := least(v_bruto, round(v_fx.ds, 2));
  elsif c.tipo = 'frete' then
    v_desc := 0;
  else
    return _falha('Tipo de cupom não suportado.');
  end if;
  v_desc := round(least(v_desc, greatest(0, v_bruto - 0.01)), 2);
  return jsonb_build_object('ok', true, 'cupomId', c.id, 'codigo', c.codigo, 'nome', c.nome, 'tipo', c.tipo, 'desconto', v_desc,
    'freteGratis', (c.frete_gratis or c.tipo = 'frete'), 'acumula', c.acumula,
    'limiteRestante', case when c.limite_total > 0 then greatest(0, c.limite_total - v_usos - 1) else null end);
end $function$
;

CREATE OR REPLACE FUNCTION public._cupom_validar(p jsonb, p_id uuid, OUT erro text, OUT c cupons)
 RETURNS record
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
declare v_fx jsonb := '[]'::jsonb; f record; v_ant numeric := 0; v_n int := 0; v_cod text := upper(regexp_replace(btrim(coalesce(p->>'codigo', '')), '\s+', '', 'g'));
        v_tipo text := coalesce(nullif(btrim(p->>'tipo'), ''), 'percentual'); v_val numeric := _num(p->>'valor');
        v_auto text := nullif(btrim(coalesce(p->>'automatico', '')), ''); v_cli uuid := _uuid(nullif(btrim(coalesce(p->>'clienteId', '')), ''));
begin
  if v_cod !~ '^[A-Z0-9_-]{3,40}$' then erro := 'Código inválido. Use letras, números, _ ou -.'; return; end if;
  if btrim(coalesce(p->>'nome', '')) = '' then erro := 'Informe o nome da promoção.'; return; end if;
  if v_tipo <> all (array['percentual','fixo','frete','progressivo']) then erro := 'Tipo de cupom inválido.'; return; end if;
  if v_tipo = 'progressivo' then
    if jsonb_typeof(p->'faixas') <> 'array' or jsonb_array_length(p->'faixas') = 0 then erro := 'Informe ao menos uma faixa de desconto.'; return; end if;
    if jsonb_array_length(p->'faixas') > 10 then erro := 'No máximo 10 faixas.'; return; end if;
    for f in select _num(x->>'minimo') mn, _num(x->>'desconto') ds from jsonb_array_elements(p->'faixas') x order by 1 loop
      v_n := v_n + 1;
      if f.mn <= 0 or f.ds <= 0 then erro := 'Cada faixa precisa de pedido mínimo e desconto maiores que zero.'; return; end if;
      if f.ds >= f.mn then erro := 'O desconto de uma faixa tem que ser menor que o pedido mínimo dela.'; return; end if;
      if f.mn = v_ant then erro := 'Há duas faixas com o mesmo pedido mínimo.'; return; end if;
      v_ant := f.mn;
      v_fx := v_fx || jsonb_build_array(jsonb_build_object('minimo', round(f.mn, 2), 'desconto', round(f.ds, 2)));
    end loop;
    v_val := 0;
  elsif v_tipo <> 'frete' and v_val <= 0 then erro := 'Valor do benefício inválido.'; return; end if;
  if v_tipo = 'percentual' and v_val > 100 then erro := 'Percentual não pode ultrapassar 100%.'; return; end if;
  if exists (select 1 from cupons where codigo = v_cod and id is distinct from p_id) then erro := 'Já existe um cupom com esse código.'; return; end if;
  if v_auto is not null and v_auto <> all (array['boas_vindas','aniversario','indicacao_indicador','indicacao_indicado']) then erro := 'Tipo de cupom automático inválido.'; return; end if;
  if v_auto is not null and exists (select 1 from cupons where automatico = v_auto and id is distinct from p_id) then erro := 'Já existe um cupom automático desse tipo. Edite o que já existe.'; return; end if;
  if nullif(btrim(coalesce(p->>'clienteId', '')), '') is not null and v_cli is null then erro := 'Cliente inválido.'; return; end if;
  if v_cli is not null and not exists (select 1 from clientes where id = v_cli) then erro := 'Cliente não encontrado.'; return; end if;
  c.codigo := v_cod; c.nome := left(btrim(p->>'nome'), 80); c.tipo := v_tipo; c.valor := case when v_tipo = 'frete' then greatest(0, v_val) else round(v_val, 2) end; c.faixas := v_fx;
  c.frete_gratis := coalesce(p->>'freteGratis', '') in ('true', 't', 'Sim');
  c.data_inicio := _data_iso(btrim(coalesce(p->>'dataInicio', ''))); c.data_fim := _data_iso(btrim(coalesce(p->>'dataFim', '')));
  c.hora_inicio := _hora_valida(p->>'horaInicio'); c.hora_fim := _hora_valida(p->>'horaFim');
  c.limite_total := greatest(0, floor(_num(p->>'limiteTotal'))::int); c.limite_por_cliente := greatest(0, floor(_num(p->>'limitePorCliente'))::int);
  c.valor_minimo := greatest(0, round(_num(p->>'valorMinimo'), 2));
  c.ativa := coalesce(p->>'ativa', '') not in ('false', 'f', 'Não'); c.acumula := coalesce(p->>'acumula', '') in ('true', 't', 'Sim');
  c.automatico := v_auto; c.cliente_id := v_cli;
  c.somente_conta := (v_auto is not null) or (v_cli is not null) or coalesce(p->>'somenteConta', '') in ('true', 't', 'Sim');
  c.visivel_conta := (v_auto is null) and coalesce(p->>'visivelConta', '') in ('true', 't', 'Sim');
  c.mensagem := left(btrim(coalesce(p->>'mensagem', '')), 200);
  c.validade_dias := least(365, greatest(1, floor(_num(p->>'validadeDias', 30))::int));
end $function$
;

CREATE OR REPLACE FUNCTION public._hoje_br()
 RETURNS date
 LANGUAGE sql
 STABLE
 SET search_path TO 'public'
AS $function$ select (now() at time zone 'America/Sao_Paulo')::date $function$
;

CREATE OR REPLACE FUNCTION public._job_aniversarios()
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r record; n int := 0; hoje date := _hoje_br(); v_ano text := extract(year from _hoje_br())::text; v_bissexto boolean; v_a int := extract(year from _hoje_br())::int;
begin
  v_bissexto := (v_a % 4 = 0 and (v_a % 100 <> 0 or v_a % 400 = 0));
  for r in select user_id from contas_cliente
            where aceite_versao > 0 and data_nascimento is not null and criado_em < now() - interval '30 days'
              and ((extract(month from data_nascimento) = extract(month from hoje) and extract(day from data_nascimento) = extract(day from hoje))
                   or (not v_bissexto and extract(month from hoje) = 2 and extract(day from hoje) = 28 and extract(month from data_nascimento) = 2 and extract(day from data_nascimento) = 29))
  loop
    if _conceder_cupom_auto('aniversario', r.user_id, v_ano) then n := n + 1; end if;
  end loop;
  return n;
end $function$
;

CREATE OR REPLACE FUNCTION public._job_lgpd_anonimizar()
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r record; n int := 0; v_anos int := coalesce((select _num(valor #>> '{}')::int from sistema where chave = 'LgpdAnosAnonimizar'), 3);
begin
  if v_anos < 1 then return 0; end if;
  for r in select c.id from clientes c
            where c.nome <> 'Cliente anonimizado'
              and greatest(c.criado_em, coalesce((select max(v.data_hora) from vendas v where v.cliente_id = c.id or (_so_digitos(c.telefone) <> '' and _so_digitos(v.telefone_cliente) = _so_digitos(c.telefone))), c.criado_em)) < now() - make_interval(years => v_anos)
              and not exists (select 1 from contas_cliente cc where cc.cliente_id = c.id)
            limit 200
  loop
    perform _anonimizar_cliente(r.id); n := n + 1;
  end loop;
  return n;
end $function$
;

CREATE OR REPLACE FUNCTION public._novo_codigo_indicacao()
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v text; i int; alf text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
begin
  loop
    v := '';
    for i in 1..6 loop v := v || substr(alf, 1 + floor(random() * length(alf))::int, 1); end loop;
    exit when not exists (select 1 from contas_cliente where codigo_indicacao = v);
  end loop;
  return v;
end $function$
;

CREATE OR REPLACE FUNCTION public._trg_conta_cancelada()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare u uuid;
begin
  begin
    -- devolve o cupom recebido que foi usado neste pedido
    update cupons_concedidos set usado_em = null, venda_id = null where venda_id = new.id;
    update cupons_usos set user_id = null, telefone = '' where venda_id = new.id and cupom_id in (select id from cupons where automatico is not null);
    -- indique e ganhe: se o pedido cancelado era o único concluído do indicado, o prêmio ainda não usado perde o efeito
    select user_id into u from contas_pedidos where venda_id = new.id;
    if u is not null and not exists (select 1 from contas_pedidos cp join vendas v on v.id = cp.venda_id
                                      where cp.user_id = u and v.id <> new.id and v.status = 'Confirmada' and v.status_pedido in ('Entregue', 'Retirada', 'Servida')) then
      update cupons_concedidos set usado_em = now() where ref = u::text and origem in ('indicacao_indicador', 'indicacao_indicado') and usado_em is null and venda_id is null;
    end if;
  exception when others then null;
  end;
  return null;
end $function$
;

CREATE OR REPLACE FUNCTION public._trg_conta_vincular()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare u uuid; c contas_cliente; v_cli uuid; v_dig text;
begin
  begin
    select user_id into u from contas_pedidos where venda_id = new.id;
    if u is null then return null; end if;
    select * into c from contas_cliente where user_id = u for update;
    if c.user_id is null or c.cliente_id is not null then return null; end if;
    v_dig := _so_digitos(new.telefone_cliente);
    if length(v_dig) < 10 then return null; end if;
    v_cli := _upsert_cliente(new.telefone_cliente, new.cliente_nome);
    if v_cli is null then return null; end if;
    if exists (select 1 from contas_cliente where cliente_id = v_cli and user_id <> u) then return null; end if;
    update contas_cliente set cliente_id = v_cli, telefone = v_dig, nome = case when nome = '' then left(btrim(coalesce(new.cliente_nome, '')), 80) else nome end where user_id = u;
    perform _conta_premiar_indicacao(u);
  exception when others then
    null;
  end;
  return null;
end $function$
;

CREATE OR REPLACE FUNCTION public.api_aviso_privacidade()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  return jsonb_build_object('ok', true, 'versao', _aviso_versao(),
    'anos', coalesce((select _num(valor #>> '{}')::int from sistema where chave = 'LgpdAnosAnonimizar'), 3),
    'nome', coalesce((select valor #>> '{}' from sistema where chave = 'RestauranteNome'), ''),
    'telefone', coalesce((select valor #>> '{}' from sistema where chave = 'RestauranteTelefone'), ''),
    'endereco', coalesce((select valor #>> '{}' from sistema where chave = 'RestauranteEndereco'), ''),
    'cnpj', coalesce((select valor #>> '{}' from sistema where chave in ('RestauranteCnpj', 'RestauranteCNPJ') limit 1), ''),
    'razaoSocial', coalesce((select valor #>> '{}' from sistema where chave in ('RestauranteRazaoSocial') limit 1), ''));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_conta_aceitar(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare uid uuid := auth.uid(); c contas_cliente; v_nasc date := _data_iso(btrim(coalesce(p->>'nascimento', ''))); v_nome text := _texto_publico(p->>'nome', 80); v_promo boolean := coalesce(p->>'promo', '') in ('true', 't');
begin
  if uid is null or auth_nivel() is not null then return _falha('Entre com a sua conta para continuar.'); end if;
  if coalesce(p->>'aceito', '') not in ('true', 't') then return _falha('É preciso aceitar o Aviso de Privacidade para criar a conta.'); end if;
  select * into c from contas_cliente where user_id = uid for update;
  if c.user_id is null then return _falha('Conta não encontrada. Entre novamente.'); end if;
  if v_nasc is not null and (v_nasc > _hoje_br() or v_nasc < date '1900-01-01') then return _falha('Data de nascimento inválida.'); end if;
  update contas_cliente set aceite_versao = _aviso_versao(), aceite_em = now(),
         nome = case when v_nome <> '' then v_nome else nome end,
         data_nascimento = coalesce(v_nasc, data_nascimento),
         nasc_alterado_em = case when v_nasc is not null and v_nasc is distinct from data_nascimento then now() else nasc_alterado_em end,
         promo_ok = v_promo, promo_em = case when v_promo is distinct from promo_ok then now() else promo_em end
   where user_id = uid;
  if c.aceite_versao = 0 then perform _conceder_cupom_auto('boas_vindas', uid, ''); end if;
  perform _auditar_publico('Conta de cliente: aceite do Aviso de Privacidade', 'versão ' || _aviso_versao() || case when v_promo then ' | aceitou promoções' else '' end, '');
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_conta_cupons()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente := _conta_exigir(); a jsonb; b jsonb;
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  select coalesce(jsonb_agg(jsonb_build_object('codigo', k.codigo, 'nome', k.nome, 'tipo', k.tipo, 'valor', k.valor, 'minimo', k.valor_minimo, 'validoAte', g.valido_ate, 'mensagem', k.mensagem, 'origem', g.origem) order by g.valido_ate), '[]'::jsonb) into a
    from cupons_concedidos g join cupons k on k.id = g.cupom_id
   where g.user_id = c.user_id and g.usado_em is null and k.ativa and (g.valido_ate is null or g.valido_ate >= _hoje_br());
  select coalesce(jsonb_agg(jsonb_build_object('codigo', k.codigo, 'nome', k.nome, 'tipo', k.tipo, 'valor', k.valor, 'minimo', k.valor_minimo, 'validoAte', k.data_fim, 'mensagem', k.mensagem) order by k.nome), '[]'::jsonb) into b
    from cupons k
   where k.ativa and k.automatico is null and (k.visivel_conta or k.cliente_id = c.cliente_id)
     and (k.cliente_id is null or k.cliente_id = c.cliente_id) and (k.data_fim is null or k.data_fim >= _hoje_br())
     and (k.data_inicio is null or k.data_inicio <= _hoje_br());
  return jsonb_build_object('ok', true, 'recebidos', a, 'disponiveis', b,
      'indicacao', jsonb_build_object(
        'indicador', (select jsonb_build_object('nome', k.nome, 'tipo', k.tipo, 'valor', k.valor, 'minimo', k.valor_minimo, 'validadeDias', k.validade_dias) from cupons k where k.automatico = 'indicacao_indicador' and k.ativa),
        'indicado', (select jsonb_build_object('nome', k.nome, 'tipo', k.tipo, 'valor', k.valor, 'minimo', k.valor_minimo, 'validadeDias', k.validade_dias) from cupons k where k.automatico = 'indicacao_indicado' and k.ativa)),
      'boasVindas', exists (select 1 from cupons k where k.automatico = 'boas_vindas' and k.ativa),
      'aniversario', (select jsonb_build_object('tipo', k.tipo, 'valor', k.valor, 'validadeDias', k.validade_dias) from cupons k where k.automatico = 'aniversario' and k.ativa));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_conta_enderecos()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente := _conta_exigir();
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  return jsonb_build_object('ok', true, 'enderecos', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'apelido', apelido, 'endereco', endereco, 'numero', numero, 'cidade', cidade, 'complemento', complemento, 'referencia', referencia) order by criado_em)
     from contas_enderecos where user_id = c.user_id), '[]'::jsonb));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_conta_exportar()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente := _conta_exigir(); cl clientes%rowtype;
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  if c.cliente_id is not null then select * into cl from clientes where id = c.cliente_id; end if;
  return jsonb_build_object('ok', true, 'geradoEm', now(),
    'conta', jsonb_build_object('email', c.email, 'nome', c.nome, 'telefone', c.telefone, 'nascimento', c.data_nascimento, 'criadaEm', c.criado_em, 'aceiteEm', c.aceite_em, 'aceiteVersao', c.aceite_versao, 'receberPromocoes', c.promo_ok, 'codigoIndicacao', c.codigo_indicacao),
    'cadastroNoRestaurante', case when cl.id is null then null else jsonb_build_object('nome', cl.nome, 'telefone', cl.telefone, 'primeiroContato', cl.primeiro_contato) end,
    'enderecos', coalesce((select jsonb_agg(jsonb_build_object('apelido', apelido, 'endereco', endereco, 'numero', numero, 'cidade', cidade, 'complemento', complemento, 'referencia', referencia)) from contas_enderecos where user_id = c.user_id), '[]'::jsonb),
    'pedidos', coalesce((select jsonb_agg(jsonb_build_object('numero', v.numero_pedido, 'data', v.data_hora, 'status', v.status_pedido::text, 'cancelado', v.status = 'Cancelada', 'total', v.valor_total, 'forma', v.forma_pagamento, 'endereco', case when v.id in (select venda_id from contas_pedidos where user_id = c.user_id) then v.endereco end,
        'itens', (select coalesce(jsonb_agg(jsonb_build_object('descricao', i.descricao, 'quantidade', i.quantidade, 'valor', i.valor_total_item)), '[]'::jsonb) from itens_venda i where i.venda_id = v.id)) order by v.data_hora)
        from vendas v where v.id in (select venda_id from contas_pedidos where user_id = c.user_id) or (c.cliente_id is not null and (v.cliente_id = c.cliente_id or (c.telefone <> '' and _so_digitos(v.telefone_cliente) = c.telefone)))), '[]'::jsonb),
    'cupons', coalesce((select jsonb_agg(jsonb_build_object('codigo', k.codigo, 'recebidoEm', g.criado_em, 'validoAte', g.valido_ate, 'usadoEm', g.usado_em)) from cupons_concedidos g join cupons k on k.id = g.cupom_id where g.user_id = c.user_id), '[]'::jsonb),
    'fidelidade', (select jsonb_build_object('carimbos', f.carimbos, 'premiosResgatados', f.premios_resgatados) from fidelidade f where f.cliente_id = c.cliente_id));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_conta_fidelidade()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente := _conta_exigir(); f fidelidade%rowtype;
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  if c.cliente_id is not null then select * into f from fidelidade where cliente_id = c.cliente_id; end if;
  return jsonb_build_object('ok', true, 'vinculada', c.cliente_id is not null, 'carimbos', coalesce(f.carimbos, 0), 'premios', coalesce(f.premios_resgatados, 0));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_conta_iniciar(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare uid uuid := auth.uid(); c contas_cliente; u record; v_ind uuid; v_cod text := upper(left(btrim(coalesce(p->>'indicacao', '')), 12)); v_nome text;
begin
  if uid is null then return _falha('Entre com a sua conta para continuar.'); end if;
  if auth_nivel() is not null then return _falha('Esta é uma conta da equipe. Para pedir como cliente, use outro e-mail.'); end if;
  if _excedeu('conta_ini_' || uid::text, 30) then return _falha('Muitas tentativas. Aguarde alguns minutos.'); end if;
  perform _registrar_falha('conta_ini_' || uid::text, 600);
  select * into c from contas_cliente where user_id = uid;
  if c.user_id is null then
    select id, email, raw_user_meta_data into u from auth.users where id = uid;
    if u.id is null then return _falha('Conta não encontrada.'); end if;
    v_nome := _texto_publico(coalesce(nullif(u.raw_user_meta_data->>'full_name', ''), u.raw_user_meta_data->>'name', ''), 80);
    if v_cod ~ '^[A-Z0-9]{4,12}$' then select user_id into v_ind from contas_cliente where codigo_indicacao = v_cod and aceite_versao > 0 and user_id <> uid; end if;
    insert into contas_cliente (user_id, email, nome, codigo_indicacao, indicado_por)
    values (uid, left(coalesce(u.email, ''), 200), v_nome, _novo_codigo_indicacao(), v_ind)
    on conflict (user_id) do nothing;
    select * into c from contas_cliente where user_id = uid;
  end if;
  update contas_cliente set ultimo_acesso = now() where user_id = uid;
  return jsonb_build_object('ok', true, 'precisaAceite', c.aceite_versao < _aviso_versao(), 'versaoAviso', _aviso_versao(),
    'conta', jsonb_build_object('email', c.email, 'nome', c.nome, 'telefone', c.telefone, 'nascimento', c.data_nascimento,
       'nascimentoEditavel', (c.nasc_alterado_em is null or c.nasc_alterado_em < now() - interval '180 days'),
       'codigoIndicacao', c.codigo_indicacao, 'promoOk', c.promo_ok, 'aceiteVersao', c.aceite_versao, 'vinculada', c.cliente_id is not null));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_conta_pedidos()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente := _conta_exigir(); r jsonb;
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  select coalesce(jsonb_agg(x order by (x->>'data') desc), '[]'::jsonb) into r from (
    select jsonb_build_object('id', v.id, 'numero', v.numero_pedido, 'data', v.data_hora, 'status', case when v.status = 'Cancelada' then 'Cancelado' else v.status_pedido::text end,
        'tipo', v.tipo::text, 'total', v.valor_total, 'desconto', v.valor_desconto, 'forma', v.forma_pagamento,
        'itens', coalesce((select jsonb_agg(jsonb_build_object('produtoId', i.produto_id, 'comboId', i.combo_id, 'descricao', i.descricao, 'quantidade', i.quantidade, 'adicionaisIds', to_jsonb(i.adicionais_ids)))
                            from itens_venda i where i.venda_id = v.id), '[]'::jsonb)) as x
      from vendas v
     where v.origem::text = 'Cardápio' and v.mesa_id is null
       and (v.id in (select venda_id from contas_pedidos where user_id = c.user_id) or (c.cliente_id is not null and (v.cliente_id = c.cliente_id or (c.telefone <> '' and _so_digitos(v.telefone_cliente) = c.telefone))))
     order by v.data_hora desc limit 30) t;
  return jsonb_build_object('ok', true, 'pedidos', r);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_conta_salvar(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente := _conta_exigir(); v_nasc date := _data_iso(btrim(coalesce(p->>'nascimento', ''))); v_nome text := _texto_publico(p->>'nome', 80);
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  if v_nome = '' then return _falha('Informe o seu nome.'); end if;
  if v_nasc is not null and (v_nasc > _hoje_br() or v_nasc < date '1900-01-01') then return _falha('Data de nascimento inválida.'); end if;
  if v_nasc is distinct from c.data_nascimento and c.data_nascimento is not null and c.nasc_alterado_em > now() - interval '180 days' then
    return _falha('A data de nascimento só pode ser alterada uma vez a cada 6 meses.');
  end if;
  update contas_cliente set nome = v_nome, data_nascimento = v_nasc,
         nasc_alterado_em = case when v_nasc is distinct from data_nascimento then now() else nasc_alterado_em end,
         promo_ok = coalesce(case when p ? 'promo' then p->>'promo' in ('true', 't') end, promo_ok),
         promo_em = case when p ? 'promo' and (p->>'promo' in ('true', 't')) is distinct from promo_ok then now() else promo_em end
   where user_id = c.user_id;
  return jsonb_build_object('ok', true, 'message', 'Dados salvos.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_conta_salvar_endereco(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente := _conta_exigir(); v_id uuid := _uuid(p->>'id'); v_end text := _texto_publico(p->>'endereco', 200);
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  if v_end = '' then return _falha('Informe o endereço.'); end if;
  if v_id is null then
    if (select count(*) from contas_enderecos where user_id = c.user_id) >= 5 then return _falha('Você pode guardar até 5 endereços.'); end if;
    insert into contas_enderecos (user_id, apelido, endereco, numero, cidade, complemento, referencia)
    values (c.user_id, _texto_publico(p->>'apelido', 30), v_end, _texto_publico(p->>'numero', 20), _texto_publico(p->>'cidade', 80), _texto_publico(p->>'complemento', 100), _texto_publico(p->>'referencia', 150));
  else
    update contas_enderecos set apelido = _texto_publico(p->>'apelido', 30), endereco = v_end, numero = _texto_publico(p->>'numero', 20), cidade = _texto_publico(p->>'cidade', 80),
           complemento = _texto_publico(p->>'complemento', 100), referencia = _texto_publico(p->>'referencia', 150)
     where id = v_id and user_id = c.user_id;
  end if;
  return jsonb_build_object('ok', true, 'message', 'Endereço salvo.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_cupom(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v record; v_id uuid := _uuid(p->>'id'); o cupons%rowtype;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into o from cupons where id = v_id;
  if not found then return _falha('Cupom não encontrado.'); end if;
  select * into v from _cupom_validar(p, v_id);
  if v.erro is not null then return _falha(v.erro); end if;
  update cupons set codigo = (v.c).codigo, nome = (v.c).nome, tipo = (v.c).tipo, valor = (v.c).valor, frete_gratis = (v.c).frete_gratis,
         data_inicio = (v.c).data_inicio, data_fim = (v.c).data_fim, hora_inicio = (v.c).hora_inicio, hora_fim = (v.c).hora_fim,
         limite_total = (v.c).limite_total, limite_por_cliente = (v.c).limite_por_cliente, valor_minimo = (v.c).valor_minimo, ativa = (v.c).ativa,
         acumula = (v.c).acumula, faixas = (v.c).faixas, somente_conta = (v.c).somente_conta, cliente_id = (v.c).cliente_id,
         mensagem = (v.c).mensagem, visivel_conta = (v.c).visivel_conta, automatico = (v.c).automatico, validade_dias = (v.c).validade_dias
   where id = v_id;
  perform _auditar('Cupom editado', (v.c).codigo, (v.c).nome || ' | benefício ' || (v.c).tipo || ' ' || (v.c).valor || case when o.ativa and not (v.c).ativa then ' | desativado' else '' end);
  return jsonb_build_object('ok', true, 'message', 'Cupom salvo.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_lgpd_config(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_anos int; v_msg text := ''; v_cnpj text; v_razao text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if p ? 'anos' then
    v_anos := floor(_num(p->>'anos'))::int;
    if v_anos < 1 or v_anos > 10 then return _falha('Informe de 1 a 10 anos.'); end if;
    update sistema set valor = to_jsonb(v_anos) where chave = 'LgpdAnosAnonimizar';
    perform _auditar('Privacidade (LGPD): prazo alterado', 'anos', v_anos || ' anos para anonimizar clientes sem pedidos');
    v_msg := 'Prazo salvo.';
  end if;
  if p ? 'cnpj' or p ? 'razaoSocial' then
    v_cnpj := left(btrim(coalesce(p->>'cnpj', '')), 30); v_razao := left(btrim(coalesce(p->>'razaoSocial', '')), 120);
    if v_cnpj <> '' and v_cnpj !~ '^[0-9./ -]{14,20}$' then return _falha('CNPJ inválido. Use só números, pontos, barra e traço.'); end if;
    insert into sistema (chave, valor) values ('RestauranteCnpj', to_jsonb(v_cnpj)) on conflict (chave) do update set valor = excluded.valor;
    insert into sistema (chave, valor) values ('RestauranteRazaoSocial', to_jsonb(v_razao)) on conflict (chave) do update set valor = excluded.valor;
    perform _auditar('Privacidade (LGPD): dados do responsável alterados', 'cnpj', 'Razão social e CNPJ do Aviso de Privacidade');
    v_msg := 'Dados do responsável salvos.';
  end if;
  if coalesce(p->>'novaVersaoAviso', '') in ('true', 't') then
    update sistema set valor = to_jsonb(_aviso_versao() + 1) where chave = 'AvisoPrivacidadeVersao';
    perform _auditar('Privacidade (LGPD): Aviso atualizado', 'versão', 'Clientes com conta precisarão aceitar de novo');
    v_msg := 'Nova versão do Aviso publicada.';
  end if;
  return jsonb_build_object('ok', true, 'message', v_msg,
    'anos', coalesce((select _num(valor #>> '{}')::int from sistema where chave = 'LgpdAnosAnonimizar'), 3), 'versao', _aviso_versao(),
    'cnpj', coalesce((select valor #>> '{}' from sistema where chave = 'RestauranteCnpj'), ''), 'razaoSocial', coalesce((select valor #>> '{}' from sistema where chave = 'RestauranteRazaoSocial'), ''),
    'contas', (select count(*) from contas_cliente where aceite_versao > 0), 'contasPromo', (select count(*) from contas_cliente where promo_ok and aceite_versao > 0),
    'anonimizados', (select count(*) from clientes where nome = 'Cliente anonimizado'));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_salvar_cupom(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v record;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into v from _cupom_validar(p, null);
  if v.erro is not null then return _falha(v.erro); end if;
  insert into cupons (codigo, nome, tipo, valor, frete_gratis, data_inicio, data_fim, hora_inicio, hora_fim, limite_total, limite_por_cliente, valor_minimo, ativa, acumula, faixas, criado_por,
                      somente_conta, cliente_id, mensagem, visivel_conta, automatico, validade_dias)
  values ((v.c).codigo, (v.c).nome, (v.c).tipo, (v.c).valor, (v.c).frete_gratis, (v.c).data_inicio, (v.c).data_fim, (v.c).hora_inicio, (v.c).hora_fim, (v.c).limite_total, (v.c).limite_por_cliente, (v.c).valor_minimo, (v.c).ativa, (v.c).acumula, (v.c).faixas, auth.uid(),
          (v.c).somente_conta, (v.c).cliente_id, (v.c).mensagem, (v.c).visivel_conta, (v.c).automatico, (v.c).validade_dias);
  perform _auditar('Cupom criado', (v.c).codigo, (v.c).nome || ' | benefício ' || (v.c).tipo || ' ' || (v.c).valor);
  return jsonb_build_object('ok', true, 'message', 'Cupom criado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_validar_cupom_cardapio(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_ip text := _ip_cliente(); v_r jsonb;
begin
  if _excedeu('cupomval_ip_' || v_ip, 15) or _excedeu('cupomval_global', 200) then
    return jsonb_build_object('ok', false, 'message', 'Muitas tentativas de cupom. Aguarde alguns minutos.', 'limite', true);
  end if;
  v_r := _cupom_calcular(p->>'codigo', p->>'telefone', _num(p->>'subtotal'), p->>'tipoEntrega', auth.uid());
  if coalesce(v_r->>'ok', '') <> 'true' then
    perform _registrar_falha('cupomval_ip_' || v_ip, 600); perform _registrar_falha('cupomval_global', 600);
  end if;
  return v_r;
end $function$
;

CREATE OR REPLACE FUNCTION public.registrar_erro_cliente(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  uid uuid := auth.uid(); hoje date := (now() at time zone 'America/Sao_Paulo')::date;
  tp text; msg text; ori text; pil text; h text; vezes int; novos int; total int;
begin
  if uid is null or auth_nivel() is null or p is null or jsonb_typeof(p) <> 'object' then return jsonb_build_object('ok', false); end if;
  tp := case when p->>'tipo' = 'promise' then 'promise' else 'error' end;
  msg := erro_limpa_(p->>'mensagem', 300); ori := erro_limpa_(p->>'origem', 120); pil := erro_limpa_(p->>'pilha', 600);
  if msg = '' then return jsonb_build_object('ok', false); end if;
  h := md5(tp || '|' || msg || '|' || ori);
  vezes := case when (p->>'vezes') ~ '^[0-9]{1,2}$' then greatest((p->>'vezes')::int, 1) else 1 end;
  update erros_cliente set ocorrencias = least(ocorrencias + vezes, 9999), ultima_em = now() where hash = h and dia = hoje;
  if found then return jsonb_build_object('ok', true, 'novo', false); end if;
  select count(*) into novos from erros_cliente where usuario_id = uid and criado_em > now() - interval '1 hour';
  select count(*) into total from erros_cliente where dia = hoje;
  if novos >= 20 or total >= 300 then return jsonb_build_object('ok', false, 'motivo', 'limite'); end if;
  insert into erros_cliente (usuario_id, nivel, tipo, mensagem, origem, pilha, tela, versao, aparelho, hash, ocorrencias)
  values (uid, coalesce(ia_nivel_real(), '?'), tp, msg, ori, pil,
          left(regexp_replace(coalesce(p->>'tela', ''), '[^a-zA-Z0-9_-]', '', 'g'), 40),
          left(regexp_replace(coalesce(p->>'versao', ''), '[^a-zA-Z0-9._-]', '', 'g'), 30),
          erro_limpa_(p->>'aparelho', 80), h, vezes)
  on conflict (hash, dia) do update set ocorrencias = least(erros_cliente.ocorrencias + vezes, 9999), ultima_em = now();
  return jsonb_build_object('ok', true, 'novo', true);
end $function$
;

-- ===================== PARTE 3: gatilhos, tarefas agendadas e permissões =====================
drop trigger if exists trg_conta_vincular on public.vendas;
create trigger trg_conta_vincular after update of status_pedido on public.vendas
  for each row when (new.status_pedido in ('Entregue', 'Retirada', 'Servida') and old.status_pedido is distinct from new.status_pedido)
  execute function public._trg_conta_vincular();
drop trigger if exists trg_conta_cancelada on public.vendas;
create trigger trg_conta_cancelada after update of status on public.vendas
  for each row when (new.status = 'Cancelada' and old.status is distinct from new.status)
  execute function public._trg_conta_cancelada();

do $$ begin
  if not exists (select 1 from cron.job where jobname = 'contas-aniversarios') then perform cron.schedule('contas-aniversarios', '10 9 * * *', 'select public._job_aniversarios()'); end if;
  if not exists (select 1 from cron.job where jobname = 'lgpd-anonimizar') then perform cron.schedule('lgpd-anonimizar', '30 4 * * 0', 'select public._job_lgpd_anonimizar()'); end if;
end $$;

-- funções internas: ninguém de fora chama
revoke all on function public._novo_codigo_indicacao() from public, anon, authenticated;
revoke all on function public._conta_atual() from public, anon, authenticated;
revoke all on function public._hoje_br() from public, anon, authenticated;
revoke all on function public._conta_exigir() from public, anon, authenticated;
revoke all on function public._aviso_versao() from public, anon, authenticated;
revoke all on function public._conceder_cupom_auto(text, uuid, text) from public, anon, authenticated;
revoke all on function public._conta_cupom_usado(uuid, uuid, uuid) from public, anon, authenticated;
revoke all on function public._conta_premiar_indicacao(uuid) from public, anon, authenticated;
revoke all on function public._job_aniversarios() from public, anon, authenticated;
revoke all on function public._job_lgpd_anonimizar() from public, anon, authenticated;
revoke all on function public._anonimizar_cliente(uuid) from public, anon, authenticated;
revoke all on function public._trg_conta_vincular() from public, anon, authenticated;
revoke all on function public._trg_conta_cancelada() from public, anon, authenticated;
revoke all on function public._cupom_calcular(text, text, numeric, text, uuid) from public, anon, authenticated;
revoke all on function public._cupom_validar(jsonb, uuid) from public, anon, authenticated;
-- funções do cliente logado (só "authenticated"; cada função confere que não é da equipe)
revoke all on function public.api_conta_iniciar(jsonb) from public, anon;
revoke all on function public.api_conta_aceitar(jsonb) from public, anon;
revoke all on function public.api_conta_salvar(jsonb) from public, anon;
revoke all on function public.api_conta_pedidos() from public, anon;
revoke all on function public.api_conta_fidelidade() from public, anon;
revoke all on function public.api_conta_cupons() from public, anon;
revoke all on function public.api_conta_enderecos() from public, anon;
revoke all on function public.api_conta_salvar_endereco(jsonb) from public, anon;
revoke all on function public.api_conta_exportar() from public, anon;
grant execute on function public.api_conta_iniciar(jsonb), public.api_conta_aceitar(jsonb), public.api_conta_salvar(jsonb), public.api_conta_pedidos(), public.api_conta_fidelidade(), public.api_conta_cupons(), public.api_conta_enderecos(), public.api_conta_salvar_endereco(jsonb), public.api_conta_exportar() to authenticated;
-- público
revoke all on function public.api_aviso_privacidade() from public;
grant execute on function public.api_aviso_privacidade() to anon, authenticated;
revoke all on function public.api_validar_cupom_cardapio(jsonb) from public;
grant execute on function public.api_validar_cupom_cardapio(jsonb) to anon, authenticated;
-- equipe
revoke all on function public.registrar_erro_cliente(jsonb) from public, anon;
grant execute on function public.registrar_erro_cliente(jsonb) to authenticated;
revoke all on function public.api_salvar_cupom(jsonb) from public, anon;
grant execute on function public.api_salvar_cupom(jsonb) to authenticated;
revoke all on function public.api_editar_cupom(jsonb) from public, anon;
grant execute on function public.api_editar_cupom(jsonb) to authenticated;
revoke all on function public.api_lgpd_config(jsonb) from public, anon;
grant execute on function public.api_lgpd_config(jsonb) to authenticated;
