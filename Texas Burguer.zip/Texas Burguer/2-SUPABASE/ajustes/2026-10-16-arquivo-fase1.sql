-- ============================================================================
-- ARQUIVAMENTO SEGURO · FASE 1 · 2026-10-16 · seguro para rodar de novo
-- 1) vendas com reembolso não entram no lote (antes travavam a fila inteira)
-- 2) tabela leve vendas_resumo_arquivo: resumo gravado ANTES de apagar a venda (histórico acessível em todo o sistema)
-- 3) vínculos que sumiam ao arquivar (conta Google, brindes, cupons, feedbacks) passam a sobreviver
-- Nada é apagado por este arquivo.
-- ============================================================================

-- 1) Resumo leve dos pedidos arquivados
create table if not exists public.vendas_resumo_arquivo (
  venda_id       uuid primary key,
  numero_pedido  integer,
  data_hora      timestamptz not null,
  cliente_id     uuid,
  user_id        uuid,                       -- conta Google que fez o pedido (se houve)
  cliente_nome   text not null default '',
  telefone       text not null default '',   -- só dígitos
  valor_total    numeric(10,2) not null default 0,
  status         text not null default '',
  status_pedido  text not null default '',
  status_pagamento text not null default '',
  tipo           text not null default '',
  origem         text not null default '',
  forma_pagamento text not null default '',
  itens_texto    text not null default '',   -- "2x X-Bacon | 1x Coca"
  endereco       text not null default '',
  complemento    text not null default '',
  arquivado_em   timestamptz not null default now()
);
alter table public.vendas_resumo_arquivo enable row level security;
revoke all on public.vendas_resumo_arquivo from anon, authenticated;
create index if not exists vra_cliente_idx  on public.vendas_resumo_arquivo (cliente_id) where cliente_id is not null;
create index if not exists vra_user_idx     on public.vendas_resumo_arquivo (user_id) where user_id is not null;
create index if not exists vra_telefone_idx on public.vendas_resumo_arquivo (telefone) where telefone <> '';
create index if not exists vra_data_idx     on public.vendas_resumo_arquivo (data_hora desc);

-- 2) Vínculos que não podem sumir com a venda arquivada (ficam como uuid solto; o resumo guarda o resto)
alter table public.contas_pedidos   drop constraint if exists contas_pedidos_venda_id_fkey;
alter table public.contas_beneficios drop constraint if exists contas_beneficios_venda_id_fkey;
alter table public.cupons_usos      drop constraint if exists cupons_usos_venda_id_fkey;
alter table public.feedbacks        drop constraint if exists feedbacks_venda_id_fkey;

-- 3) Lote: não pega venda com reembolso (Pendente ou Devolvido); o resto da regra é igual
CREATE OR REPLACE FUNCTION public.api_arquivar_lote_vendas(p_dias integer, p_limite integer DEFAULT 200, p_min_dias integer DEFAULT 30)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_corte timestamptz := now() - (greatest(p_dias, greatest(p_min_dias,1))||' days')::interval; v_ids uuid[];
begin
  select array_agg(id) into v_ids from (
    select v.id from vendas v
    where v.data_hora < v_corte
      and (v.status = 'Cancelada' or (v.status_pagamento = 'Pago' and coalesce(v.status_pedido::text,'Entregue') in ('Entregue','Retirada','Servida')))
      and not exists (select 1 from ajustes_pos_venda a where a.venda_id = v.id)
      and not exists (select 1 from entregas_fechadas e where e.venda_id = v.id)
      and not exists (select 1 from reembolsos r where r.venda_id = v.id)
      and not (v.status <> 'Cancelada' and v.tipo::text = 'Entrega' and v.entregador_id is not null and v.fechamento_entrega_id is null)
      and not exists (select 1 from ocorrencias o where o.venda_id = v.id and o.status::text <> 'Resolvida')
      and not exists (select 1 from chat_conversas c where c.venda_id = v.id and c.estado <> 'encerrada')
    order by v.data_hora limit p_limite) x;
  return jsonb_build_object('ok',true,
    'ids', coalesce(to_jsonb(v_ids),'[]'::jsonb),
    'vendas', (select coalesce(jsonb_agg(to_jsonb(v)),'[]'::jsonb) from vendas v where v.id = any(coalesce(v_ids,'{}'))),
    'itens', (select coalesce(jsonb_agg(to_jsonb(i)),'[]'::jsonb) from itens_venda i where i.venda_id = any(coalesce(v_ids,'{}'))),
    'pagamentos', (select coalesce(jsonb_agg(to_jsonb(p)),'[]'::jsonb) from pagamentos_venda p where p.venda_id = any(coalesce(v_ids,'{}'))));
end $function$;

-- 4) Confirmação: grava o resumo e SÓ DEPOIS apaga a venda (mesma transação: se uma coisa falha, nada muda)
CREATE OR REPLACE FUNCTION public.api_arquivar_confirmar_vendas(p_ids uuid[])
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_n int;
BEGIN
  PERFORM set_config('txb.sem_fila','on',true);
  INSERT INTO vendas_resumo_arquivo (venda_id, numero_pedido, data_hora, cliente_id, user_id, cliente_nome, telefone, valor_total,
      status, status_pedido, status_pagamento, tipo, origem, forma_pagamento, itens_texto, endereco, complemento)
    SELECT v.id, v.numero_pedido, v.data_hora, v.cliente_id,
           (select cp.user_id from contas_pedidos cp where cp.venda_id = v.id),
           coalesce(v.cliente_nome,''), coalesce(_so_digitos(v.telefone_cliente),''), v.valor_total,
           v.status::text, coalesce(v.status_pedido::text,''), v.status_pagamento::text, v.tipo::text, v.origem::text, coalesce(v.forma_pagamento,''),
           coalesce((select string_agg(i.quantidade::text || 'x ' || coalesce(i.descricao,'(item)'), ' | ' order by i.descricao) from itens_venda i where i.venda_id = v.id), ''),
           coalesce(v.endereco,''), coalesce(v.complemento,'')
      FROM vendas v WHERE v.id = ANY(p_ids)
    ON CONFLICT (venda_id) DO NOTHING;
  INSERT INTO arquivo_historico (tabela, registro_id, data_referencia)
    SELECT 'vendas', unnest(p_ids), CURRENT_DATE ON CONFLICT DO NOTHING;
  DELETE FROM itens_venda WHERE venda_id = ANY(p_ids);
  DELETE FROM pagamentos_venda WHERE venda_id = ANY(p_ids);
  WITH d AS (DELETE FROM vendas WHERE id = ANY(p_ids) RETURNING id) SELECT count(*) INTO v_n FROM d;
  RETURN jsonb_build_object('ok',true,'removidos',v_n);
EXCEPTION WHEN foreign_key_violation THEN
  RETURN _falha('Venda ainda referenciada por outra tabela: '||SQLERRM);
END $function$;

revoke all on function public.api_arquivar_lote_vendas(integer, integer, integer) from public, anon, authenticated;
revoke all on function public.api_arquivar_confirmar_vendas(uuid[]) from public, anon, authenticated;
