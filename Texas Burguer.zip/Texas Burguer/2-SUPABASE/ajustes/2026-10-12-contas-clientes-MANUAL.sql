-- ============================================================================
-- CONTAS DE CLIENTES — PARTE QUE APAGA DADOS (colar à mão no SQL Editor do Supabase) · 2026-10-12 · seguro para rodar de novo
-- O conector do Supabase bloqueia "delete" dentro de função; por isso estas funções não foram aplicadas por ele.
-- Cole TUDO de uma vez e toque em Run. Depois disso, "Excluir endereço", "Apagar minha conta" e a limpeza automática passam a funcionar.
-- ============================================================================

-- 1) Cliente exclui um endereço salvo
create or replace function public.api_conta_excluir_endereco(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public'
as $function$
declare c contas_cliente := _conta_exigir();
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  delete from contas_enderecos where id = _uuid(p->>'id') and user_id = c.user_id;
  return jsonb_build_object('ok', true);
end $function$;

-- 2) Cliente apaga a própria conta (LGPD). Com "anonimizar" também tira o nome, telefone e endereço dos pedidos e do cadastro dele no restaurante.
create or replace function public.api_conta_apagar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public'
as $function$
declare c contas_cliente := _conta_exigir(); v_anon boolean := coalesce(p->>'anonimizar', '') in ('true', 't');
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  if v_anon then
    if c.cliente_id is not null then perform _anonimizar_cliente(c.cliente_id); end if;
    update vendas set cliente_nome = 'Cliente anonimizado', telefone_cliente = '', endereco = '', complemento = '', referencia = '', observacoes_entrega = '', cpf_nota = null
     where id in (select venda_id from contas_pedidos where user_id = c.user_id);
  end if;
  update cupons_usos set user_id = null where user_id = c.user_id;
  perform _auditar_publico('Conta de cliente apagada', case when v_anon then 'com anonimização do histórico' else 'histórico mantido' end, '');
  delete from contas_cliente where user_id = c.user_id;
  delete from auth.users where id = c.user_id;
  return jsonb_build_object('ok', true, 'message', 'Conta apagada.');
end $function$;

-- 3) Limpeza: quem entrou com o Google mas não aceitou o Aviso em 7 dias é removido (só ficou o e-mail)
create or replace function public._job_contas_sem_aceite() returns integer
 language plpgsql security definer set search_path to 'public'
as $function$
declare r record; n int := 0;
begin
  for r in select user_id from contas_cliente where aceite_versao = 0 and criado_em < now() - interval '7 days' limit 200 loop
    delete from contas_cliente where user_id = r.user_id;
    delete from auth.users where id = r.user_id;
    n := n + 1;
  end loop;
  return n;
end $function$;

-- 4) Limpeza: conta parada há mais do que o prazo de anonimização (Aviso de Privacidade) é apagada e o histórico anonimizado
create or replace function public._job_contas_inativas() returns integer
 language plpgsql security definer set search_path to 'public'
as $function$
declare r record; n int := 0; v_anos int := coalesce((select _num(valor #>> '{}')::int from sistema where chave = 'LgpdAnosAnonimizar'), 3);
begin
  if v_anos < 1 then return 0; end if;
  for r in select cc.user_id, cc.cliente_id from contas_cliente cc
            left join clientes cl on cl.id = cc.cliente_id
           where cc.aceite_versao > 0
             and greatest(cc.criado_em, coalesce(cc.ultimo_acesso, cc.criado_em)) < now() - make_interval(years => v_anos)
             and not exists (select 1 from contas_pedidos cp join vendas v on v.id = cp.venda_id where cp.user_id = cc.user_id and v.data_hora >= now() - make_interval(years => v_anos))
             and (cl.id is null or not exists (select 1 from vendas v where _so_digitos(coalesce(cl.telefone, '')) <> '' and _so_digitos(v.telefone_cliente) = _so_digitos(cl.telefone) and v.data_hora >= now() - make_interval(years => v_anos)))
           limit 100
  loop
    if r.cliente_id is not null then perform _anonimizar_cliente(r.cliente_id); end if;
    update vendas set cliente_nome = 'Cliente anonimizado', telefone_cliente = '', endereco = '', complemento = '', referencia = '', observacoes_entrega = '', cpf_nota = null
     where id in (select venda_id from contas_pedidos where user_id = r.user_id);
    update cupons_usos set user_id = null where user_id = r.user_id;
    delete from contas_cliente where user_id = r.user_id;
    delete from auth.users where id = r.user_id;
    n := n + 1;
  end loop;
  return n;
end $function$;

-- permissões
revoke all on function public.api_conta_excluir_endereco(jsonb) from public, anon;
revoke all on function public.api_conta_apagar(jsonb) from public, anon;
grant execute on function public.api_conta_excluir_endereco(jsonb), public.api_conta_apagar(jsonb) to authenticated;
revoke all on function public._job_contas_sem_aceite() from public, anon, authenticated;
revoke all on function public._job_contas_inativas() from public, anon, authenticated;

-- tarefas automáticas (toda semana, de madrugada)
do $$ begin
  if not exists (select 1 from cron.job where jobname = 'contas-sem-aceite') then perform cron.schedule('contas-sem-aceite', '40 4 * * 0', 'select public._job_contas_sem_aceite()'); end if;
  if not exists (select 1 from cron.job where jobname = 'contas-inativas') then perform cron.schedule('contas-inativas', '50 4 * * 0', 'select public._job_contas_inativas()'); end if;
end $$;

-- limpeza de uma função de teste que ficou no banco (inofensiva)
drop function if exists public._teste_palavra();
