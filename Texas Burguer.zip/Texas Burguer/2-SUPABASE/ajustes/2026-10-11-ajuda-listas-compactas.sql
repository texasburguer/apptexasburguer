-- Ajuda da IA: listas compactas (ações pela linha / ⋯) e botão do Tex · 2026-10-11 · seguro para rodar de novo
insert into public.ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-97-listas-acoes','Listas: onde ficaram editar, entrada, perda e excluir',
 'editar excluir entrada perda inventário desativar ativar botão sumiu três pontinhos ⋯ lista estoque produtos combos usuários ações assistente tex botão redondo modo desenvolvedor recolher',
 E'Nas listas de Estoque, Produtos, Combos e Usuários, toque na linha (ou no ⋯ no fim dela).\nAbre uma janela com as ações: Editar, Entrada, Perda, Inventário, Excluir (no estoque) ou Editar, Desativar/Ativar, Excluir (nos usuários).\nNo produto e no combo, tocar na linha já abre a edição; o ⋯ mostra também Excluir.\nO botão do Assistente é o rosto do Tex, redondo, no canto de baixo; os avisos aparecem no número 🔔 dele.',
 array['Admin'],true,'lista',97,'A caixa do Modo Desenvolvedor fica recolhida numa linha; toque em ▸ para abrir.'
where not exists (select 1 from ai_ajuda where slug='man-admin-97-listas-acoes');
