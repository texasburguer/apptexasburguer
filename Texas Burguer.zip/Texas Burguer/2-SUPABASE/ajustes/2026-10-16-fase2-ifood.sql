-- =====================================================================
-- Fase 2 · iFood (aplicada no banco em 2026-10-16, migração "fase2_ifood"; esta é a cópia exportada do banco)
--  1) pedido sem itens é recusado (não cria venda vazia)
--  2) pedido INDOOR (consumo no local) vira Retirada, não Entrega
--  3) "levar troco" só aparece quando a entrega é do restaurante (deliveredBy = MERCHANT)
--  4) cancelamento recebido DEPOIS de concluído é ignorado e auditado (não cancela venda já entregue)
--  5) centavos: quando total ÷ quantidade não fecha, o último item recebe a diferença (soma sempre bate com o iFood)
--  6) trava do leitor renovada a cada volta (a função de nuvem usa ifood_trava_pegar de novo com o mesmo dono)
--  7) evento que chega antes do pedido existir não some (a função de nuvem tenta de novo por até 10 min)
--  8) data de agendamento inválida não derruba a criação do pedido
--  9) eventos presos há mais de 1 dia são encerrados com erro (ifood_eventos_vencidos_fechar)
-- Funções: _ifood_gravar_itens, ifood_aplicar_evento, ifood_criar_pedido, ifood_eventos_vencidos_fechar, ifood_trava_pegar.
-- A função de nuvem correspondente está em funcoes/ifood-sync/index.ts (versão 4 publicada).
-- =====================================================================
CREATE OR REPLACE FUNCTION public._ifood_gravar_itens(p_venda uuid, p_order jsonb, p_regravar boolean)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare it jsonb; op jsonb; v_item ifood_itens%rowtype; v_op ifood_itens%rowtype; v_chave text; v_qtd int; v_tot numeric; v_ads uuid[]; v_desc text; v_custo numeric; v_sem int := 0; v_obs text; v_oq int;
        v_u numeric; v_pid uuid; v_cid uuid;
begin
  if p_regravar then
    perform _ajustar_estoque(_itens_da_venda(p_venda), -1, p_venda);
    delete from itens_venda where venda_id = p_venda;
  end if;
  for it in select value from jsonb_array_elements(coalesce(p_order->'items', '[]'::jsonb)) loop
    v_chave := coalesce(nullif(it->>'externalCode', ''), nullif(it->>'id', ''), 'sem-codigo-' || public._ifood_norm(it->>'name'));
    v_qtd := greatest(1, round(public._ifood_n(it->'quantity'))::int);
    v_tot := public._ifood_n(it->'totalPrice');
    if v_tot <= 0 then v_tot := public._ifood_n(it->'price'); end if;
    if v_tot <= 0 then v_tot := (public._ifood_n(it->'unitPrice') + public._ifood_n(it->'optionsPrice')) * v_qtd; end if;
    v_item := public._ifood_item_visto(v_chave, it->>'name', 'produto');
    v_ads := '{}'; v_desc := coalesce(it->>'name', 'Item iFood'); v_obs := nullif(btrim(coalesce(it->>'observations', '')), '');
    for op in select value from jsonb_array_elements(coalesce(it->'options', '[]'::jsonb)) loop
      v_op := public._ifood_item_visto(coalesce(nullif(op->>'externalCode', ''), nullif(op->>'id', ''), 'sem-codigo-' || public._ifood_norm(op->>'name')), op->>'name', 'opcao');
      v_oq := greatest(1, round(public._ifood_n(op->'quantity'))::int);
      v_desc := v_desc || ' + ' || coalesce(op->>'name', 'opção') || case when v_oq > 1 then ' x' || v_oq else '' end;
      if v_op.adicional_id is not null then
        for i in 1..(v_oq * v_qtd) loop v_ads := v_ads || v_op.adicional_id; end loop;
      end if;
    end loop;
    if v_obs is not null then v_desc := v_desc || ' (obs: ' || v_obs || ')'; end if;
    v_custo := 0;
    if v_item.produto_id is not null then select coalesce(min(custo), 0) into v_custo from produto_precos where produto_id = v_item.produto_id;
    elsif v_item.combo_id is not null then select coalesce(min(custo), 0) into v_custo from combo_precos where combo_id = v_item.combo_id;
    end if;
    if v_item.produto_id is null and v_item.combo_id is null and not v_item.ignorar then v_sem := v_sem + 1; v_desc := v_desc || ' [SEM LIGAÇÃO]'; end if;
    v_pid := case when v_item.ignorar then null else v_item.produto_id end; v_cid := case when v_item.ignorar then null else v_item.combo_id end;
    v_u := round(v_tot / v_qtd, 2);
    if v_qtd > 1 and round(v_u * v_qtd, 2) <> round(v_tot, 2) then
      insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
      values (p_venda, v_pid, v_cid, left(v_desc, 300), v_qtd - 1, v_u, round(v_custo, 2), round(v_u * (v_qtd - 1), 2), v_ads);
      insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
      values (p_venda, v_pid, v_cid, left(v_desc, 300), 1, round(v_tot, 2) - round(v_u * (v_qtd - 1), 2), round(v_custo, 2), round(v_tot, 2) - round(v_u * (v_qtd - 1), 2), '{}');
    else
      insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
      values (p_venda, v_pid, v_cid, left(v_desc, 300), v_qtd, v_u, round(v_custo, 2), round(v_tot, 2), v_ads);
    end if;
  end loop;
  perform _ajustar_estoque(_itens_da_venda(p_venda), 1, p_venda);
  return v_sem;
end $function$;

CREATE OR REPLACE FUNCTION public.ifood_aplicar_evento(p_codigo text, p_pedido text, p_motivo text DEFAULT NULL::text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r ifood_pedidos%rowtype; v vendas%rowtype; v_st text;
begin
  select * into r from ifood_pedidos where pedido_ifood = p_pedido for update;
  if not found then return jsonb_build_object('ok', false, 'desconhecido', true); end if;
  if p_codigo in ('CFM', 'CONFIRMED') and r.estado = 'novo' then update ifood_pedidos set estado = 'confirmado', confirmado_em = now(), atualizado_em = now() where pedido_ifood = p_pedido;
  elsif p_codigo in ('RTP', 'READY_TO_PICKUP') and r.estado in ('novo', 'confirmado', 'em_preparo') then update ifood_pedidos set estado = 'pronto', atualizado_em = now() where pedido_ifood = p_pedido;
  elsif p_codigo in ('DSP', 'DISPATCHED') and r.estado <> 'cancelado' then update ifood_pedidos set estado = 'despachado', atualizado_em = now() where pedido_ifood = p_pedido;
  elsif p_codigo in ('CON', 'CONCLUDED') and r.estado <> 'cancelado' then
    update ifood_pedidos set estado = 'concluido', atualizado_em = now() where pedido_ifood = p_pedido;
    update vendas set status_pedido = case when tipo = 'Entrega' then 'Entregue' else 'Retirada' end::status_pedido, concluida_em = coalesce(concluida_em, now())
      where id = r.venda_id and status = 'Confirmada' and status_pedido::text not in ('Entregue', 'Retirada', 'Servida');
  elsif p_codigo in ('CAN', 'CANCELLED') and r.estado = 'concluido' then
    -- o pedido já foi entregue: um cancelamento tardio não pode cancelar a venda sozinho
    perform _integ_log('ifood', 'aviso', 'Pedido #' || r.numero_ifood || ': cancelamento recebido depois de concluído (ignorado)');
    perform _auditar('Cancelamento do iFood ignorado', 'iFood #' || r.numero_ifood || ' · cancelamento recebido depois de concluído' || coalesce(' · ' || nullif(p_motivo, ''), ''));
    return jsonb_build_object('ok', true, 'ignorado', true);
  elsif p_codigo in ('CAN', 'CANCELLED') and r.estado <> 'cancelado' then
    update ifood_pedidos set estado = 'cancelado', atualizado_em = now() where pedido_ifood = p_pedido;
    select * into v from vendas where id = r.venda_id for update;
    if found and v.status = 'Confirmada' then
      v_st := v.status_pedido::text;
      update vendas set status = 'Cancelada', motivo_cancelamento = left('Cancelado pelo iFood' || coalesce(' · ' || nullif(p_motivo, ''), ''), 200) where id = v.id;
      if v_st in ('Recebido', 'Em preparo', 'Suspenso') then perform _ajustar_estoque(_itens_da_venda(v.id), -1, v.id); end if;
      update ifood_acoes set estado = 'pulada', erro = 'pedido cancelado' where pedido_ifood = p_pedido and estado in ('pendente', 'duvida');
      perform _auditar('Pedido do iFood cancelado pelo iFood', 'iFood #' || r.numero_ifood || coalesce(' · ' || nullif(p_motivo, ''), '') || case when v_st not in ('Recebido', 'Em preparo', 'Suspenso') then ' · já estava pronto: estoque NÃO devolvido' else '' end);
      perform _integ_log('ifood', 'aviso', 'Pedido #' || r.numero_ifood || ' cancelado pelo iFood');
      begin perform _push_enviar('pedido', '❌ iFood cancelou o pedido #' || r.numero_ifood, coalesce(nullif(p_motivo, ''), 'Veja o painel'), 'ifood-can-' || r.pedido_ifood); exception when others then null; end;
    end if;
  end if;
  return jsonb_build_object('ok', true);
end $function$;

CREATE OR REPLACE FUNCTION public.ifood_criar_pedido(p_order jsonb, p_simulado boolean DEFAULT false)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_id text := p_order->>'id'; v_disp text := coalesce(nullif(p_order->>'displayId', ''), right(coalesce(p_order->>'id', ''), 4));
  v_venda uuid := gen_random_uuid(); v_tipo venda_tipo; v_nome text; v_tel text; v_end text; v_comp text; v_ref text; v_obs text;
  v_val jsonb; v_total numeric; v_sem int; v_caixa uuid; v_numero int; v_troco numeric; v_agend text; v_forma text; v_pend numeric; v_cash numeric; v_stpag status_pagamento; ad jsonb; v_cpf text; v_okdata timestamptz;
begin
  if v_id is null then return jsonb_build_object('ok', false, 'message', 'Pedido sem id.'); end if;
  if exists (select 1 from ifood_pedidos where pedido_ifood = v_id) then return jsonb_build_object('ok', true, 'duplicado', true); end if;
  if jsonb_typeof(p_order->'items') is distinct from 'array' or jsonb_array_length(p_order->'items') = 0 then return jsonb_build_object('ok', false, 'message', 'Pedido sem itens.'); end if;
  v_tipo := case when upper(coalesce(p_order->>'orderType', '')) in ('TAKEOUT', 'PICKUP', 'INDOOR') then 'Retirada' else 'Entrega' end::venda_tipo;
  v_nome := left(btrim(coalesce(p_order->'customer'->>'name', 'Cliente iFood')), 80) || ' (iFood)';
  v_tel := left(regexp_replace(coalesce(p_order->'customer'->'phone'->>'number', ''), '[^0-9]', '', 'g'), 20);
  ad := coalesce(p_order->'delivery'->'deliveryAddress', '{}'::jsonb);
  v_end := coalesce(nullif(ad->>'formattedAddress', ''), btrim(concat_ws(', ', ad->>'streetName', ad->>'streetNumber', ad->>'neighborhood', ad->>'city')));
  v_comp := coalesce(ad->>'complement', ''); v_ref := coalesce(ad->>'reference', '');
  v_cpf := regexp_replace(coalesce(p_order->'customer'->>'documentNumber', ''), '[^0-9]', '', 'g');
  if not public._cpf_valido(v_cpf) then v_cpf := null; end if;
  v_val := public._ifood_valores(p_order);
  v_total := (v_val->>'total')::numeric;
  v_pend := public._ifood_n(p_order->'payments'->'pending');
  v_cash := case when (v_val->>'entregaIfood')::boolean then 0 else round(least(greatest(v_pend, 0), v_total), 2) end;
  v_stpag := case when v_cash > 0.009 then 'A Receber' else 'Pago' end;
  v_forma := case when v_cash > 0.009 and v_total - v_cash > 0.009 then 'iFood (pago no app) + iFood (pagar na entrega)' when v_cash > 0.009 then 'iFood (pagar na entrega)' else 'iFood (pago no app)' end;
  v_obs := 'iFood #' || v_disp;
  if v_tipo = 'Entrega' and (v_val->>'entregaIfood')::boolean then v_obs := v_obs || ' · ENTREGA PELO iFOOD'; end if;
  select (m->'cash'->>'changeFor') into v_troco from jsonb_array_elements(coalesce(p_order->'payments'->'methods', '[]'::jsonb)) m where m->'cash'->>'changeFor' is not null limit 1;
  if v_troco is not null and public._ifood_n(to_jsonb(v_troco)) > 0 and upper(coalesce(p_order->'delivery'->>'deliveredBy', '')) = 'MERCHANT' then v_obs := v_obs || ' · levar troco para R$ ' || replace(to_char(public._ifood_n(to_jsonb(v_troco)), 'FM9999990.00'), '.', ','); end if;
  if upper(coalesce(p_order->>'orderTiming', '')) = 'SCHEDULED' then
    v_agend := coalesce(p_order->'schedule'->>'deliveryDateTimeStart', p_order->'delivery'->>'deliveryDateTime', p_order->>'preparationStartDateTime', '');
    begin v_okdata := nullif(v_agend, '')::timestamptz; exception when others then v_okdata := null; end;
    v_obs := v_obs || ' · AGENDADO' || case when v_okdata is not null then ' para ' || to_char(v_okdata at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') else '' end;
  end if;
  if nullif(btrim(coalesce(p_order->'delivery'->>'observations', '')), '') is not null then v_obs := v_obs || ' · ' || btrim(p_order->'delivery'->>'observations'); end if;
  if p_simulado then v_obs := v_obs || ' · TESTE (simulação)'; end if;
  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido, endereco, complemento, referencia, observacoes_entrega,
                      status_pagamento, cpf_nota, recebido_em, valor_original, valor_desconto, desconto_detalhe, origem, taxa_entrega, caixa_id, requisicao_id, canal)
  values (v_venda, v_nome, nullif(v_tel, ''), v_forma, v_total, 0, 'Confirmada', v_tipo, 'Recebido',
          case when v_tipo = 'Entrega' then coalesce(v_end, '') else '' end, case when v_tipo = 'Entrega' then v_comp else '' end, case when v_tipo = 'Entrega' then v_ref else '' end, v_obs,
          v_stpag, v_cpf, case when v_stpag = 'Pago' then now() end, (v_val->>'original')::numeric, (v_val->>'descontoLoja')::numeric,
          case when (v_val->>'descontoLoja')::numeric > 0 then 'Desconto/cupom iFood pago pela loja' else '' end, 'Balcão', (v_val->>'taxaEntrega')::numeric, v_caixa, 'ifood:' || v_id, 'iFood')
  returning numero_pedido into v_numero;

  v_sem := public._ifood_gravar_itens(v_venda, p_order, false);
  update vendas set custo_total = coalesce((select sum(custo_unitario * quantidade) from itens_venda where venda_id = v_venda), 0) where id = v_venda;

  perform public._ifood_gravar_pagamentos(v_venda, p_order, v_total, (v_val->>'entregaIfood')::boolean);

  insert into ifood_pedidos (pedido_ifood, venda_id, numero_ifood, estado, expira_em, itens_sem_ligacao, simulado, bruto)
  values (v_id, v_venda, v_disp, 'novo', now() + interval '8 minutes', v_sem, p_simulado, p_order);
  update ifood_estado set ultimo_pedido_em = now(), atualizado_em = now() where id;
  perform _auditar('Pedido do iFood recebido', 'iFood #' || v_disp || ' → venda #' || v_numero || ' · R$ ' || replace(to_char(v_total, 'FM9999990.00'), '.', ',') || case when v_sem > 0 then ' · ' || v_sem || ' item(ns) sem ligação' else '' end || case when p_simulado then ' · SIMULAÇÃO' else '' end, null);
  perform _integ_log('ifood', case when v_sem > 0 then 'aviso' else 'info' end, 'Pedido #' || v_disp || ' recebido' || case when v_sem > 0 then ' (' || v_sem || ' item sem ligação)' else '' end);
  return jsonb_build_object('ok', true, 'vendaId', v_venda, 'numero', v_numero, 'semLigacao', v_sem);
end $function$;

CREATE OR REPLACE FUNCTION public.ifood_eventos_vencidos_fechar()
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare n int;
begin
  update ifood_eventos set processado_em = now(), erro = 'Ficou mais de 1 dia sem processar: encerrado com erro'
   where processado_em is null and recebido_em <= now() - interval '1 day';
  get diagnostics n = row_count;
  if n > 0 then perform _integ_log('ifood', 'aviso', n || ' evento(s) do iFood ficaram mais de 1 dia sem processar e foram encerrados com erro'); end if;
  return n;
end $function$;

CREATE OR REPLACE FUNCTION public.ifood_trava_pegar(p_dono text, p_seg integer)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v int;
begin
  update ifood_estado set trava_dono = p_dono, trava_ate = now() + make_interval(secs => p_seg) where id and (trava_ate is null or trava_ate < now() or trava_dono = p_dono);
  get diagnostics v = row_count;
  return v > 0;
end $function$;
