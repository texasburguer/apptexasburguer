-- 2026-10-15 · Limpeza das sobras do Leitor Fiscal (item 5 do plano de ação)
-- Cole no SQL Editor do Supabase e rode uma vez.
--
-- O que este arquivo faz: remove o bucket "fiscal-notas".
-- Segurança: se o bucket tiver qualquer arquivo dentro, NADA é apagado e aparece um aviso.
--
-- O que este arquivo NÃO faz: apagar as Edge Functions "leitor-fiscal" e "ai-dev-analise".
-- O SQL não alcança Edge Functions. Apague pelo painel (Edge Functions > função > Delete)
-- ou pelo terminal:
--   supabase functions delete leitor-fiscal  --project-ref awryywtgqfaxppayzpca
--   supabase functions delete ai-dev-analise --project-ref awryywtgqfaxppayzpca

do $$
declare v_n bigint;
begin
  if not exists (select 1 from storage.buckets where id = 'fiscal-notas') then
    raise notice 'O bucket fiscal-notas já não existe. Nada a fazer.';
    return;
  end if;

  select count(*) into v_n from storage.objects where bucket_id = 'fiscal-notas';
  if v_n > 0 then
    raise exception 'O bucket fiscal-notas tem % arquivo(s). Nada foi apagado. Confira o conteúdo antes.', v_n;
  end if;

  -- O Supabase bloqueia delete direto em storage.*; esta chave libera só nesta transação.
  perform set_config('storage.allow_delete_query', 'true', true);
  delete from storage.buckets where id = 'fiscal-notas';
  raise notice 'Bucket fiscal-notas removido.';
end $$;

-- Conferência: deve voltar só o bucket "backups".
select id, name, public from storage.buckets order by id;
