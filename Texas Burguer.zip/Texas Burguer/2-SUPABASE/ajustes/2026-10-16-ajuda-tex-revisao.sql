-- Ajuda do Tex: revisão de 16/10/2026 (v1.6). Só texto da ajuda; idempotente (pode rodar mais de uma vez).

-- 1) Entradas novas (assuntos que o Tex não conhecia)
insert into public.ai_ajuda (slug, titulo, palavras_chave, passos, comuns, perfis, grupo, ordem, ativo, atualizado_em)
select v.slug, v.titulo, v.palavras_chave, v.passos, v.comuns, v.perfis, 'lista', v.ordem, true, now()
from (values
 ('man-admin-115-mercado-pago', 'Mercado Pago (pagamento online)',
  'mercado pago pix cartão online crédito débito pagamento online checkout webhook liberar pedido reembolsar chaves teste produção',
  E'Onde: Administrador → Sistema → Integrações e contas → 💳 Mercado Pago. O quadro "👉 Próximo passo" mostra o que falta fazer.\nConfigurar (quem faz é o dono): conta de vendedor verificada; aplicação com Checkout Transparente; chaves de TESTE (Public Key e Access Token); aviso (webhook) com o evento "Order (Mercado Pago)" e a chave secreta; teste guiado com Pix e cartão; só então as chaves de PRODUÇÃO e "Ligar em PRODUÇÃO".\nFormas de pagamento pelo site: cada forma tem só duas opções, "Só na entrega" ou "Também online". Online vale para Pix, crédito e débito. A forma continua valendo na entrega, com os mesmos preços, taxas e acréscimos.\nAjustes: validade do Pix (5 a 120 minutos; combinado 15), e-mails que veem o pagamento online em TESTE e e-mail do comprador de teste.\nNo cardápio, o cliente precisa entrar com a conta para pagar pelo site. O pedido só entra como Pago depois da confirmação do Mercado Pago.\nPagamentos que precisam de decisão: se o dinheiro foi aprovado mas o pedido não entrou sozinho na cozinha, a lista aparece em Mercado Pago ("No dia a dia") e numa faixa discreta no Caixa. "Liberar pedido" envia para a cozinha; "Reembolsar" registra a decisão e chama o Mercado Pago para devolver. Confira o resultado antes de repetir uma tentativa.\nRelatórios → "Mercado Pago — resumo do mês" mostra recebimentos e taxas do mês.',
  E'O pedido de teste aprovado vira pedido de verdade na cozinha e no caixa: avise a equipe e cancele depois.\nDesligada, a integração faz o cardápio voltar a funcionar só com pagamento na entrega. Ligar e desligar pedem a senha de administrador.',
  array['Admin'], 115),
 ('man-admin-116-entregadores-fechamento', 'Entregadores: taxa e fechamento',
  'entregadores taxa de entrega ajuda diária fechamento de entregadores pagar entregador fechar período fechamentos anteriores',
  E'Administrador → Loja e equipe → Entregadores e taxas.\nEm "Taxa e ajuda diária", defina a taxa de entrega padrão e a ajuda diária do entregador e salve. A taxa é do cliente e vai 100% para o entregador. Mudanças valem só para pedidos e fechamentos futuros.\nEm "Fechamento de entregadores", escolha o entregador e o dia e toque em Calcular. O total devido é as taxas das entregas concluídas do dia mais a ajuda diária (uma vez por dia).\nInforme o valor pago e a forma: Dinheiro (sai da gaveta do caixa) ou Pix (não sai da gaveta). Se o valor pago for diferente do devido, a observação é obrigatória.\nToque em "Fechar período". Os fechamentos aparecem em "Fechamentos anteriores" e não mudam mais.',
  E'A ajuda diária conta uma vez por dia e só se houve entrega.\nO valor pago ao entregador entra nas despesas (Entregadores) no DRE.\nSe a conexão cair ao fechar, confira "Fechamentos anteriores" antes de tentar de novo, para não fechar duas vezes.',
  array['Admin'], 116),
 ('man-admin-117-clientes-perfil-360', 'Clientes: Perfil 360, segmentos e preferências fixas',
  'clientes perfil 360 segmento novo fiel vip em risco ticket médio frequência itens favoritos preferências fixas sem cebola alergia conta google filtro',
  E'Clientes → toque no cliente. No topo do perfil, o Perfil 360 mostra o segmento (Novo, Fiel, VIP ou Em risco), gasto total, ticket médio, frequência, itens favoritos e se tem conta Google. Na lista, cada cliente tem o selo do segmento, e os filtros são Em risco, VIP, Fiéis e Novos.\nOs pedidos antigos arquivados entram na conta, pelo telefone do cliente.\nPreferências fixas (ex.: sem cebola, alergias): preencha no perfil do cliente. Cada pedido novo guarda uma cópia, e as preferências aparecem na tela da cozinha, na comanda impressa e nos detalhes do pedido.\nO cliente com conta também edita as dele em Minha conta › Meus dados e as vê no checkout antes de pedir.',
  '',
  array['Admin','Operador'], 117),
 ('man-admin-118-cupons-risco-vip', 'Cupons automáticos: Sentimos sua falta e Cliente VIP',
  'cupom automático sentimos sua falta cliente em risco 45 dias cliente vip aviso push promoções cupons automáticos',
  E'Administrador → Vendas e cardápio → Promoções e cupons → Cupons automáticos.\nHá dois cupons para fidelizar: "Sentimos sua falta" (cliente em risco, mais de 45 dias sem pedir) e "Cliente VIP". Já vêm DESLIGADOS: ajuste o valor e ligue.\nSó recebe quem tem conta Google e aceitou promoções. O cupom aparece em Minha conta do cliente.\nQuem está em Em risco ou VIP também recebe um aviso (push) junto com o cupom, se tiver o aviso ligado no aparelho.',
  '',
  array['Admin'], 118),
 ('man-admin-119-formas-pagamento', 'Formas de pagamento (Taxas e prazos / No cardápio)',
  'formas de pagamento taxas prazos no cardápio acréscimo ifood pagamento cardápio',
  E'Administrador → Vendas e cardápio → Formas de pagamento. É uma tela só, com duas abas: "Taxas e prazos" e "No cardápio" (o que o cliente vê).\nEsta tela substituiu a antiga aba Pagamentos do Cardápio Digital.\nPara pagamento online (Pix, crédito e débito), veja Mercado Pago em Integrações e contas.',
  '',
  array['Admin'], 119)
) as v(slug, titulo, palavras_chave, passos, comuns, perfis, ordem)
where not exists (select 1 from public.ai_ajuda a where a.slug = v.slug);

-- 2) "No computador": tirar a frase antiga "No celular nada muda" e citar os 6 grupos
update public.ai_ajuda set atualizado_em = now(),
  comuns = 'Todas as funções do celular existem no computador: o que muda é só a organização da tela.',
  passos = replace(passos,
    'as telas aparecem num menu ao lado, com todos os grupos abertos.',
    'as telas aparecem num menu ao lado, com os 6 grupos abertos (Hoje, Dinheiro, Produtos, Vendas e cardápio, Loja e equipe, Sistema). O campo "Ir para…" no topo do menu acha uma tela pelo nome.')
 where slug = 'man-admin-110-computador';

-- 3) Caixa (Admin): dividir pagamento, repetir venda, caixa vencido e pagamentos a decidir
update public.ai_ajuda set atualizado_em = now(),
  passos = passos || E'\nPara dividir o pagamento, marque "Dividir pagamento" na etapa 3. "↺ Repetir última venda" recarrega o carrinho anterior.\nCaixa vencido: se o caixa passou do corte, venda nova, sangria e resgate de prêmio ficam bloqueados. Use "Fechar caixa vencido" no fim da tela do Caixa (veja "Caixa vencido").\nSe houver pagamento do Mercado Pago a decidir, aparece uma faixa discreta no Caixa (veja "Mercado Pago").'
 where slug = 'man-admin-08-caixa-abrir-vender-e-fechar' and passos not like '%Repetir última venda%';

-- 4) Arquivamento: botão Simular
update public.ai_ajuda set atualizado_em = now(),
  passos = passos || E'\nEm Backup e espaço, o botão "Simular" no arquivamento mostra quantos pedidos e caixas sairiam do Supabase, quantos ficam e se o resumo guardado confere com a planilha, sem mover nada. Ao anonimizar um cliente (LGPD), os pedidos dele arquivados na planilha também são limpos, de madrugada.'
 where slug = 'man-admin-14-arquivamento-e-uso-do-banco' and passos not like '%botão "Simular" no arquivamento%';
