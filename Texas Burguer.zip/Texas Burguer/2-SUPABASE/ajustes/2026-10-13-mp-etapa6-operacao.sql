-- MERCADO PAGO · ETAPA 6 — operação, decisão pendente e resumo mensal
-- Preparado localmente em 2026-10-13. NÃO APLICADO no Supabase.
-- Depende das Etapas 1, 2 e 4 já aplicadas e da tabela pagamentos_online.

create or replace function public.api_mp_pendencias_decisao(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'itens', (select coalesce(jsonb_agg(jsonb_build_object(
      'pagamentoId', x.id, 'reservaId', x.reserva_id, 'metodo', x.metodo, 'modo', x.mp_modo,
      'valor', x.valor, 'criadoEm', to_char(x.criado_em at time zone 'America/Sao_Paulo', 'DD/MM/YYYY HH24:MI'),
      'motivo', left(coalesce(nullif(x.decisao_motivo, ''), nullif(x.erro, ''), 'Pagamento aprovado sem pedido confirmado.'), 240),
      'clienteNome', coalesce(r.cliente_nome, ''), 'telefone', coalesce(r.telefone, '')
    ) order by x.criado_em), '[]'::jsonb)
    from pagamentos_online x join pedidos_reserva r on r.id = x.reserva_id
    where x.status = 'aprovado' and x.decisao_pendente and x.decisao is null));
end $f$;

create or replace function public.api_mp_resumo_operacional(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_ini timestamptz := date_trunc('month', now()); v_fim timestamptz := date_trunc('month', now()) + interval '1 month';
        v_total numeric(12,2); v_taxas numeric(12,2); v_qtd integer;
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  select coalesce(sum(greatest(x.valor - x.valor_reembolsado, 0)),0), count(*)::int into v_total, v_qtd
    from pagamentos_online x where x.status in ('aprovado','reembolso_parcial','reembolsado') and x.aprovado_em >= v_ini and x.aprovado_em < v_fim;
  select coalesce(sum(pv.taxa_aplicada),0) into v_taxas
    from pagamentos_online x join pagamentos_venda pv on pv.venda_id = x.venda_id
    where x.status in ('aprovado','reembolso_parcial','reembolsado') and x.aprovado_em >= v_ini and x.aprovado_em < v_fim;
  return jsonb_build_object('ok', true, 'periodo', to_char(v_ini at time zone 'America/Sao_Paulo','MM/YYYY'),
    'quantidade', v_qtd, 'total', round(v_total,2), 'taxas', round(v_taxas,2),
    'itens', (select coalesce(jsonb_agg(jsonb_build_object('metodo', q.metodo, 'quantidade', q.quantidade, 'total', q.total, 'taxas', q.taxas) order by q.metodo), '[]'::jsonb)
      from (select x.metodo, count(*)::int as quantidade, round(coalesce(sum(greatest(x.valor - x.valor_reembolsado, 0)),0),2) as total,
                   round(coalesce(sum(pv.taxa_aplicada),0),2) as taxas
              from pagamentos_online x left join (select venda_id, sum(taxa_aplicada) as taxa_aplicada from pagamentos_venda group by venda_id) pv on pv.venda_id = x.venda_id
             where x.status in ('aprovado','reembolso_parcial','reembolsado') and x.aprovado_em >= v_ini and x.aprovado_em < v_fim
             group by x.metodo) q));
end $f$;

revoke all on function public.api_mp_pendencias_decisao(jsonb), public.api_mp_resumo_operacional(jsonb) from public, anon;
grant execute on function public.api_mp_pendencias_decisao(jsonb), public.api_mp_resumo_operacional(jsonb) to authenticated;

-- A função api_mp_decidir_pagamento da Etapa 2 continua sendo a autoridade para liberar/reembolsar.
-- A devolução real só ocorre depois da decisão, chamando a Edge Function mp-reembolsar.


-- A lista de reembolsos identifica as vendas que vieram do checkout online.
-- Assim, o botão de confirmação pode chamar mp-reembolsar em vez de apenas marcar manualmente.
create or replace function public.api_listar_reembolsos(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_st text := nullif(btrim(coalesce(p->>'status','')),'');
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'itens', coalesce((
    select jsonb_agg(jsonb_build_object('id', r.id, 'vendaId', r.venda_id, 'numero', v.numero_pedido, 'cliente', v.cliente_nome,
      'valor', r.valor, 'forma', r.forma_pagamento, 'motivo', r.motivo, 'status', r.status, 'criadoEm', r.criado_em,
      'devolvidoEm', r.devolvido_em, 'observacao', r.observacao, 'pagamentoOnlineId', po.id) order by r.criado_em desc)
    from reembolsos r join vendas v on v.id = r.venda_id left join pagamentos_online po on po.venda_id = r.venda_id
    where v_st is null or r.status = v_st), '[]'::jsonb));
end $f$;
revoke execute on function public.api_listar_reembolsos(jsonb) from public, anon;
grant execute on function public.api_listar_reembolsos(jsonb) to authenticated;
