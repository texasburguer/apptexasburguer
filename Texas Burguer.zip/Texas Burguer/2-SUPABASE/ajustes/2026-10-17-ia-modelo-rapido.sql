-- Plano "IA que busca só o que a pergunta pede" · item 8: modelo pequeno e rápido do Groq para perguntas simples (pedidos, entregas, estoque, caixa).
-- Para desligar: update public.ai_config set modelo_groq_rapido = null where id;
alter table public.ai_config add column if not exists modelo_groq_rapido text default 'llama-3.1-8b-instant';
update public.ai_config set modelo_groq_rapido = 'llama-3.1-8b-instant' where id and modelo_groq_rapido is null;
