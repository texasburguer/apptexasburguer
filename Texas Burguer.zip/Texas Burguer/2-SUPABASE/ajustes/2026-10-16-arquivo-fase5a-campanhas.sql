-- ============================================================================
-- CLIENTES · FASE 5.1 · Campanhas automáticas (Em risco e VIP) · 2026-10-16 · seguro para rodar de novo
-- Dois cupons automáticos NOVOS, já criados DESLIGADOS (como os outros): ajuste e ligue em Promoções.
--   em_risco: cliente que não pede há mais de 45 dias recebe o cupom (no máximo 1 a cada 60 dias)
--   vip:      cliente VIP recebe o cupom (no máximo 1 por trimestre)
-- Só recebe quem tem conta Google E aceitou receber promoções (promo_ok). Aparece em Minha conta › Cupons.
-- O segmento vem da mesma regra do Perfil 360 (_segmento_cliente), pelo telefone/cliente, somando pedidos arquivados.
-- ============================================================================
alter table public.cupons drop constraint if exists cupons_automatico_chk;
alter table public.cupons add constraint cupons_automatico_chk
  check (automatico is null or automatico in ('boas_vindas','aniversario','indicacao_indicador','indicacao_indicado','em_risco','vip'));

insert into public.cupons (codigo, nome, tipo, valor, valor_minimo, ativa, somente_conta, automatico, validade_dias, mensagem)
select 'SAUDADE', 'Sentimos sua falta', 'fixo', 10, 30, false, true, 'em_risco', 14, 'Sentimos sua falta! Um presente do Texas Burger para você voltar.'
where not exists (select 1 from public.cupons where automatico = 'em_risco' or codigo = 'SAUDADE');
insert into public.cupons (codigo, nome, tipo, valor, valor_minimo, ativa, somente_conta, automatico, validade_dias, mensagem)
select 'VIPTEXAS', 'Cliente VIP', 'fixo', 15, 40, false, true, 'vip', 30, 'Obrigado por ser cliente VIP do Texas Burger! Este cupom é seu.'
where not exists (select 1 from public.cupons where automatico = 'vip' or codigo = 'VIPTEXAS');

CREATE OR REPLACE FUNCTION public._campanha_candidatos()
 RETURNS TABLE(user_id uuid, segmento text)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select c.user_id, _segmento_cliente(x.n, x.total, x.ultimo, 45)
    from contas_cliente c
   cross join lateral (
     select count(*)::int n, coalesce(sum(b.valor_total), 0) total, max(b.data_hora) ultimo
       from (select v.valor_total, v.data_hora from vendas v
              where v.status = 'Confirmada'
                and ((c.cliente_id is not null and v.cliente_id = c.cliente_id)
                     or (length(_so_digitos(c.telefone)) >= 8 and _so_digitos(v.telefone_cliente) = _so_digitos(c.telefone)))
             union all
             select s.valor_total, s.data_hora from vendas_resumo_arquivo s
              where s.status = 'Confirmada'
                and ((c.cliente_id is not null and s.cliente_id = c.cliente_id)
                     or (length(_so_digitos(c.telefone)) >= 8 and s.telefone = _so_digitos(c.telefone)))) b) x
   where c.promo_ok and c.aceite_versao > 0 and x.n > 0
$function$;
revoke all on function public._campanha_candidatos() from public, anon, authenticated;

CREATE OR REPLACE FUNCTION public._job_campanhas()
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r record; n_risco int := 0; n_vip int := 0; hoje date := _hoje_br();
  v_tri text := extract(year from _hoje_br())::int || '-Q' || extract(quarter from _hoje_br())::int;
begin
  for r in select * from _campanha_candidatos() where segmento in ('Em risco', 'VIP') loop
    if r.segmento = 'Em risco' then
      if not exists (select 1 from cupons_concedidos cc where cc.user_id = r.user_id and cc.origem = 'em_risco' and cc.criado_em > now() - interval '60 days')
         and _conceder_cupom_auto('em_risco', r.user_id, hoje::text) then n_risco := n_risco + 1; end if;
    else
      if _conceder_cupom_auto('vip', r.user_id, v_tri) then n_vip := n_vip + 1; end if;
    end if;
  end loop;
  return jsonb_build_object('emRisco', n_risco, 'vip', n_vip);
end $function$;
revoke all on function public._job_campanhas() from public, anon, authenticated;

select cron.schedule('contas-campanhas', '20 9 * * *', 'select public._job_campanhas()');
