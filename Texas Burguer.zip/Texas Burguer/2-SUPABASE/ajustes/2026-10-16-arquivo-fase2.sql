-- ============================================================================
-- ARQUIVAMENTO · FASE 2 · 2026-10-16 · seguro para rodar de novo
-- O TELEFONE é o identificador principal do cliente (nem todo cliente tem conta Google); a conta Google e o id do cliente são complementos.
-- 1) resumo guarda também os itens estruturados (para "pedir de novo"), a mesa e o desconto
-- 2) api_historico_cliente_arquivo: pedidos arquivados de um cliente (por telefone e/ou id) — equipe (Admin/Operador)
-- 3) api_clientes_arquivo_resumo: última compra / quantidade / total arquivados por telefone (inativos e ranking)
-- 4) "Meus pedidos" e exportação da conta Google passam a incluir os arquivados
-- 5) LGPD: anonimizar cliente / apagar conta também limpa o resumo arquivado
-- ============================================================================

alter table public.vendas_resumo_arquivo add column if not exists itens jsonb not null default '[]'::jsonb;
alter table public.vendas_resumo_arquivo add column if not exists mesa_id uuid;
alter table public.vendas_resumo_arquivo add column if not exists valor_desconto numeric(10,2) not null default 0;

CREATE OR REPLACE FUNCTION public.api_arquivar_confirmar_vendas(p_ids uuid[])
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_n int;
BEGIN
  PERFORM set_config('txb.sem_fila','on',true);
  INSERT INTO vendas_resumo_arquivo (venda_id, numero_pedido, data_hora, cliente_id, user_id, cliente_nome, telefone, valor_total,
      status, status_pedido, status_pagamento, tipo, origem, forma_pagamento, itens_texto, itens, endereco, complemento, mesa_id, valor_desconto)
    SELECT v.id, v.numero_pedido, v.data_hora, v.cliente_id,
           (select cp.user_id from contas_pedidos cp where cp.venda_id = v.id),
           coalesce(v.cliente_nome,''), coalesce(_so_digitos(v.telefone_cliente),''), v.valor_total,
           v.status::text, coalesce(v.status_pedido::text,''), v.status_pagamento::text, v.tipo::text, v.origem::text, coalesce(v.forma_pagamento,''),
           coalesce((select string_agg(i.quantidade::text || 'x ' || coalesce(i.descricao,'(item)'), ' | ' order by i.descricao) from itens_venda i where i.venda_id = v.id), ''),
           coalesce((select jsonb_agg(jsonb_build_object('produtoId', i.produto_id, 'comboId', i.combo_id, 'descricao', i.descricao, 'quantidade', i.quantidade, 'adicionaisIds', to_jsonb(i.adicionais_ids))) from itens_venda i where i.venda_id = v.id), '[]'::jsonb),
           coalesce(v.endereco,''), coalesce(v.complemento,''), v.mesa_id, coalesce(v.valor_desconto,0)
      FROM vendas v WHERE v.id = ANY(p_ids)
    ON CONFLICT (venda_id) DO NOTHING;
  INSERT INTO arquivo_historico (tabela, registro_id, data_referencia)
    SELECT 'vendas', unnest(p_ids), CURRENT_DATE ON CONFLICT DO NOTHING;
  DELETE FROM itens_venda WHERE venda_id = ANY(p_ids);
  DELETE FROM pagamentos_venda WHERE venda_id = ANY(p_ids);
  WITH d AS (DELETE FROM vendas WHERE id = ANY(p_ids) RETURNING id) SELECT count(*) INTO v_n FROM d;
  RETURN jsonb_build_object('ok',true,'removidos',v_n);
EXCEPTION WHEN foreign_key_violation THEN
  RETURN _falha('Venda ainda referenciada por outra tabela: '||SQLERRM);
END $function$;
revoke all on function public.api_arquivar_confirmar_vendas(uuid[]) from public, anon, authenticated;

-- 2) Pedidos arquivados de um cliente (equipe). Telefone em dígitos é o principal; cliente_id completa.
CREATE OR REPLACE FUNCTION public.api_historico_cliente_arquivo(p_telefone text DEFAULT '', p_cliente_id uuid DEFAULT NULL)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_tel text := _so_digitos(coalesce(p_telefone,''));
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if length(v_tel) < 8 and p_cliente_id is null then return jsonb_build_object('ok', true, 'pedidos', '[]'::jsonb); end if;
  return jsonb_build_object('ok', true, 'pedidos', coalesce((
    select jsonb_agg(to_jsonb(s) order by s.data_hora desc)
      from (select * from vendas_resumo_arquivo r
             where (length(v_tel) >= 8 and r.telefone = v_tel) or (p_cliente_id is not null and r.cliente_id = p_cliente_id)
             order by r.data_hora desc limit 2000) s), '[]'::jsonb));
end $function$;

-- 3) Resumo por telefone dos pedidos arquivados (para "clientes inativos", ranking e valor do cliente)
CREATE OR REPLACE FUNCTION public.api_clientes_arquivo_resumo()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'clientes', coalesce((
    select jsonb_agg(jsonb_build_object('telefone', t.telefone, 'pedidos', t.n, 'total', t.total, 'ultimo', t.ultimo))
      from (select telefone, count(*) filter (where status <> 'Cancelada') n,
                   coalesce(sum(valor_total) filter (where status <> 'Cancelada'), 0) total, max(data_hora) ultimo
              from vendas_resumo_arquivo where telefone <> '' group by telefone) t), '[]'::jsonb));
end $function$;

grant execute on function public.api_historico_cliente_arquivo(text, uuid) to authenticated;
grant execute on function public.api_clientes_arquivo_resumo() to authenticated;
revoke all on function public.api_historico_cliente_arquivo(text, uuid) from public, anon;
revoke all on function public.api_clientes_arquivo_resumo() from public, anon;

-- 4) "Meus pedidos" da conta Google: ativos + arquivados (últimos 30 no total)
CREATE OR REPLACE FUNCTION public.api_conta_pedidos()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente := _conta_exigir(); r jsonb;
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  select coalesce(jsonb_agg(u.x order by (u.x->>'data') desc), '[]'::jsonb) into r from (
    select * from (
      select v.data_hora as d, jsonb_build_object('id', v.id, 'numero', v.numero_pedido, 'data', v.data_hora, 'status', case when v.status = 'Cancelada' then 'Cancelado' else v.status_pedido::text end,
          'tipo', v.tipo::text, 'total', v.valor_total, 'desconto', v.valor_desconto, 'forma', v.forma_pagamento,
          'itens', coalesce((select jsonb_agg(jsonb_build_object('produtoId', i.produto_id, 'comboId', i.combo_id, 'descricao', i.descricao, 'quantidade', i.quantidade, 'adicionaisIds', to_jsonb(i.adicionais_ids)))
                              from itens_venda i where i.venda_id = v.id), '[]'::jsonb),
          'feedback', (select jsonb_build_object('id', f.id, 'nota', f.nota, 'comentario', f.comentario, 'data', f.data, 'resposta', f.resposta, 'respondidoEm', f.respondido_em)
                         from feedbacks f where f.venda_id = v.id and f.user_id = c.user_id order by f.data desc limit 1)) as x
        from vendas v
       where v.origem::text = 'Cardápio' and v.mesa_id is null
         and (v.id in (select venda_id from contas_pedidos where user_id = c.user_id) or (c.cliente_id is not null and (v.cliente_id = c.cliente_id or (c.telefone <> '' and _so_digitos(v.telefone_cliente) = c.telefone))))
      union all
      select s.data_hora, jsonb_build_object('id', s.venda_id, 'numero', s.numero_pedido, 'data', s.data_hora, 'status', case when s.status = 'Cancelada' then 'Cancelado' else s.status_pedido end,
          'tipo', s.tipo, 'total', s.valor_total, 'desconto', s.valor_desconto, 'forma', s.forma_pagamento, 'itens', s.itens, 'arquivado', true,
          'feedback', (select jsonb_build_object('id', f.id, 'nota', f.nota, 'comentario', f.comentario, 'data', f.data, 'resposta', f.resposta, 'respondidoEm', f.respondido_em)
                         from feedbacks f where f.venda_id = s.venda_id and f.user_id = c.user_id order by f.data desc limit 1))
        from vendas_resumo_arquivo s
       where s.origem = 'Cardápio' and s.mesa_id is null
         and (s.user_id = c.user_id or (c.cliente_id is not null and (s.cliente_id = c.cliente_id or (c.telefone <> '' and s.telefone = c.telefone))))
    ) z order by d desc limit 30) u;
  return jsonb_build_object('ok', true, 'pedidos', r);
end $function$;

-- 4b) Exportação dos dados da conta (LGPD) inclui os pedidos arquivados
CREATE OR REPLACE FUNCTION public.api_conta_exportar()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente := _conta_exigir(); cl clientes%rowtype;
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  if c.cliente_id is not null then select * into cl from clientes where id = c.cliente_id; end if;
  return jsonb_build_object('ok', true, 'geradoEm', now(),
    'conta', jsonb_build_object('email', c.email, 'nome', c.nome, 'telefone', c.telefone, 'nascimento', c.data_nascimento, 'criadaEm', c.criado_em, 'aceiteEm', c.aceite_em, 'aceiteVersao', c.aceite_versao, 'receberPromocoes', c.promo_ok, 'codigoIndicacao', c.codigo_indicacao),
    'cadastroNoRestaurante', case when cl.id is null then null else jsonb_build_object('nome', cl.nome, 'telefone', cl.telefone, 'primeiroContato', cl.primeiro_contato) end,
    'enderecos', coalesce((select jsonb_agg(jsonb_build_object('apelido', apelido, 'endereco', endereco, 'numero', numero, 'cidade', cidade, 'complemento', complemento, 'referencia', referencia)) from contas_enderecos where user_id = c.user_id), '[]'::jsonb),
    'pedidos', coalesce((select jsonb_agg(p.j order by p.d) from (
        select v.data_hora d, jsonb_build_object('numero', v.numero_pedido, 'data', v.data_hora, 'status', v.status_pedido::text, 'cancelado', v.status = 'Cancelada', 'total', v.valor_total, 'forma', v.forma_pagamento, 'endereco', case when v.id in (select venda_id from contas_pedidos where user_id = c.user_id) then v.endereco end,
          'itens', (select coalesce(jsonb_agg(jsonb_build_object('descricao', i.descricao, 'quantidade', i.quantidade, 'valor', i.valor_total_item)), '[]'::jsonb) from itens_venda i where i.venda_id = v.id)) j
          from vendas v where v.id in (select venda_id from contas_pedidos where user_id = c.user_id) or (c.cliente_id is not null and (v.cliente_id = c.cliente_id or (c.telefone <> '' and _so_digitos(v.telefone_cliente) = c.telefone)))
        union all
        select s.data_hora, jsonb_build_object('numero', s.numero_pedido, 'data', s.data_hora, 'status', s.status_pedido, 'cancelado', s.status = 'Cancelada', 'total', s.valor_total, 'forma', s.forma_pagamento, 'endereco', case when s.user_id = c.user_id then s.endereco end,
          'itens', (select coalesce(jsonb_agg(jsonb_build_object('descricao', e->>'descricao', 'quantidade', (e->>'quantidade')::numeric)), '[]'::jsonb) from jsonb_array_elements(s.itens) e), 'arquivado', true)
          from vendas_resumo_arquivo s where s.user_id = c.user_id or (c.cliente_id is not null and (s.cliente_id = c.cliente_id or (c.telefone <> '' and s.telefone = c.telefone)))
      ) p), '[]'::jsonb),
    'cupons', coalesce((select jsonb_agg(jsonb_build_object('codigo', k.codigo, 'recebidoEm', g.criado_em, 'validoAte', g.valido_ate, 'usadoEm', g.usado_em)) from cupons_concedidos g join cupons k on k.id = g.cupom_id where g.user_id = c.user_id), '[]'::jsonb),
    'feedbacks', coalesce((select jsonb_agg(jsonb_build_object('data', f.data, 'nota', f.nota, 'comentario', f.comentario, 'resposta', f.resposta, 'respondidoEm', f.respondido_em) order by f.data) from feedbacks f where f.user_id = c.user_id), '[]'::jsonb),
    'fidelidade', (select jsonb_build_object('carimbos', f.carimbos, 'premiosResgatados', f.premios_resgatados) from fidelidade f where f.cliente_id = c.cliente_id));
end $function$;

-- 5) LGPD: anonimizar também o resumo arquivado
CREATE OR REPLACE FUNCTION public._anonimizar_cliente(p_cli uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_dig text;
begin
  if p_cli is null then return; end if;
  select _so_digitos(telefone) into v_dig from clientes where id = p_cli;
  update vendas set cliente_nome = 'Cliente anonimizado', telefone_cliente = '', endereco = '', complemento = '', referencia = '', observacoes_entrega = '', cpf_nota = null
   where cliente_id = p_cli or (coalesce(v_dig, '') <> '' and _so_digitos(telefone_cliente) = v_dig);
  update vendas_resumo_arquivo set cliente_nome = 'Cliente anonimizado', telefone = '', endereco = '', complemento = ''
   where cliente_id = p_cli or (coalesce(v_dig, '') <> '' and telefone = v_dig);
  update feedbacks set telefone_cliente = '' where cliente_id = p_cli or (coalesce(v_dig, '') <> '' and _so_digitos(telefone_cliente) = v_dig);
  update clientes set nome = 'Cliente anonimizado', telefone = null, endereco = '', data_nascimento = null, observacoes = '', como_conheceu = '' where id = p_cli;
end $function$;

CREATE OR REPLACE FUNCTION public.api_conta_apagar(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c contas_cliente := _conta_exigir(); v_anon boolean := coalesce(p->>'anonimizar', '') in ('true', 't');
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  if v_anon then
    if c.cliente_id is not null then perform _anonimizar_cliente(c.cliente_id); end if;
    update vendas set cliente_nome = 'Cliente anonimizado', telefone_cliente = '', endereco = '', complemento = '', referencia = '', observacoes_entrega = '', cpf_nota = null
     where id in (select venda_id from contas_pedidos where user_id = c.user_id);
    update vendas_resumo_arquivo set cliente_nome = 'Cliente anonimizado', telefone = '', endereco = '', complemento = '' where user_id = c.user_id;
  end if;
  perform _mp_anonimizar_reservas(c.user_id);   -- pedidos reservados e pagamentos online da conta (nome, telefone, endereço, QR do Pix)
  update cupons_usos set user_id = null where user_id = c.user_id;
  perform _auditar_publico('Conta de cliente apagada', case when v_anon then 'com anonimização do histórico' else 'histórico mantido' end, '');
  delete from contas_cliente where user_id = c.user_id;
  delete from auth.users where id = c.user_id;
  return jsonb_build_object('ok', true, 'message', 'Conta apagada.');
end $function$;
