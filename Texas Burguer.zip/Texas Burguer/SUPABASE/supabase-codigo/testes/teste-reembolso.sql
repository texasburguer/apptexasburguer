-- TESTE DO REEMBOLSO (não grava nada: termina com erro de propósito e desfaz tudo). Cole no SQL Editor.
-- Esperado: registros_criados=1, status_inicial=Pendente, confirmar.ok=true, confirmar_de_novo.ok=false.
do $$
declare adm uuid; v uuid; reg record; r2 jsonb; r3 jsonb; n1 int; rep jsonb;
begin
  select u.id into adm from usuarios u where u.nivel::text in ('Admin','Desenvolvedor') and u.ativo limit 1;
  perform set_config('request.jwt.claims', json_build_object('sub',adm,'role','authenticated')::text, true);
  perform set_config('role','authenticated', true);
  select id into v from vendas where status::text='Confirmada' and status_pagamento::text='Pago' limit 1;
  update vendas set status='Cancelada', motivo_cancelamento='teste reembolso' where id=v;
  select count(*) into n1 from reembolsos where venda_id=v;
  select * into reg from reembolsos where venda_id=v;
  r2 := api_confirmar_reembolso(jsonb_build_object('id',reg.id,'observacao','devolvido no Pix'));
  r3 := api_confirmar_reembolso(jsonb_build_object('id',reg.id));
  rep := jsonb_build_object('registros_criados',n1,'valor',reg.valor,'forma',reg.forma_pagamento,'status_inicial',reg.status,'confirmar',r2,'confirmar_de_novo',r3);
  raise exception 'RELATORIO %', rep::text;
end $$;
