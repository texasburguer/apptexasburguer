-- TESTE AUTOMÁTICO DE VENDA E SEGURANÇA (não grava nada: termina com erro de propósito e desfaz tudo).
-- Cole no SQL Editor do Supabase. O resultado aparece na mensagem de erro "RELATORIO {...}".
-- Esperado: venda_repetida.duplicado=true; vendas_com_mesma_requisicao=1; quantidade_negativa e preco_adulterado (Operador) com ok=false.
do $$
declare adm uuid; op uuid; pr record; fp text; it jsonb; pags jsonb; r1 jsonb; r2 jsonb; r3 jsonb; r4 jsonb; r5 jsonb; n int; rep jsonb;
begin
  select u.id into adm from usuarios u where u.nivel::text in ('Admin','Desenvolvedor') and u.ativo limit 1;
  select u.id into op from usuarios u where u.nivel::text='Operador' and u.ativo limit 1;
  perform set_config('request.jwt.claims', json_build_object('sub',adm,'role','authenticated')::text, true);
  perform set_config('role','authenticated', true);
  perform api_abrir_caixa('{"valorInicial":0,"saldoInicial":0}'::jsonb);
  select pp.produto_id, pp.preco, pp.custo, p.nome into pr from produto_precos pp join produtos p on p.id=pp.produto_id where pp.preco>0 limit 1;
  select f.nome into fp from formas_pagamento f where f.ativa and coalesce(f.acrescimo_percentual,0)=0 limit 1;
  it := jsonb_build_array(jsonb_build_object('produtoId',pr.produto_id,'descricao',pr.nome,'quantidade',1,'valorUnitario',pr.preco,'custoUnitario',pr.custo,'adicionaisIds','[]'::jsonb));
  pags := jsonb_build_array(jsonb_build_object('forma',fp,'valor',pr.preco));
  r1 := api_iniciar_venda(jsonb_build_object('itens',it,'pagamentos',pags,'tipoEntrega','Retirada','requisicaoId','teste-A'));
  r2 := api_iniciar_venda(jsonb_build_object('itens',it,'pagamentos',pags,'tipoEntrega','Retirada','requisicaoId','teste-A'));
  select count(*) into n from vendas where requisicao_id='teste-A';
  r3 := api_iniciar_venda(jsonb_build_object('itens',jsonb_build_array(jsonb_build_object('produtoId',pr.produto_id,'descricao',pr.nome,'quantidade',-3,'valorUnitario',pr.preco,'custoUnitario',pr.custo)),'pagamentos',pags,'tipoEntrega','Retirada','requisicaoId','teste-C'));
  if op is not null then
    perform set_config('request.jwt.claims', json_build_object('sub',op,'role','authenticated')::text, true);
    r4 := api_iniciar_venda(jsonb_build_object('itens',jsonb_build_array(jsonb_build_object('produtoId',pr.produto_id,'descricao',pr.nome,'quantidade',1,'valorUnitario',0.01,'custoUnitario',pr.custo)),'pagamentos',jsonb_build_array(jsonb_build_object('forma',fp,'valor',0.01)),'tipoEntrega','Retirada','requisicaoId','teste-B'));
  end if;
  r5 := api_cancelar_venda(jsonb_build_object('id',gen_random_uuid(),'motivo','x','senhaAdminConfirmacao','errada'));
  rep := jsonb_build_object('venda1',r1,'venda_repetida',r2,'vendas_com_mesma_requisicao',n,'quantidade_negativa',r3,'preco_adulterado_operador',r4,'cancelar_senha_errada',r5);
  raise exception 'RELATORIO %', rep::text;
end $$;
