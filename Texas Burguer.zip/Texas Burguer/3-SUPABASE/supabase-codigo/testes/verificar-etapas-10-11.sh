#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
WEB="$ROOT/1-SUBIR-NO-GITHUB"
for f in "$WEB"/*.js; do node --check "$f"; done
grep -q 'app-28-leitor-fiscal.js' "$WEB/index.html"
grep -q 'app-28-leitor-fiscal.js' "$WEB/sw.js"
grep -q "ping-2dias" "$ROOT/3-SUPABASE/supabase-codigo/01-estrutura.sql"
grep -q "contingencia-espelho-10min" "$ROOT/3-SUPABASE/supabase-codigo/01-estrutura.sql"
grep -q '30000' "$ROOT/3-SUPABASE/supabase-codigo/funcoes/sync-fila/index.ts"
grep -q '30000' "$ROOT/3-SUPABASE/supabase-codigo/funcoes/planilha-admin/index.ts"
grep -q 'fiscal-notas' "$ROOT/3-SUPABASE/supabase-codigo/ajustes/2026-10-14-etapa10-leitor-fiscal.sql"
printf 'OK: JS syntax, asset/cache wiring, ping/sync schedules, 30 s timeout and fiscal migration references.\n'
