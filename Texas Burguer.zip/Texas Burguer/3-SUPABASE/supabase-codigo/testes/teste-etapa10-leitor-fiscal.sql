-- Teste de fumaça Etapa 10. Executar SOMENTE depois da migração em homologação.
-- Só lê metadados; não cria compra, não mexe em estoque e não apaga nada.
do $test$
begin
  if to_regclass('public.fiscal_leituras') is null then raise exception 'FALHA: tabela fiscal_leituras ausente'; end if;
  if to_regclass('public.compras') is null or to_regclass('public.compra_itens') is null then raise exception 'FALHA: estrutura de compras ausente'; end if;
  if not exists(select 1 from storage.buckets where id='fiscal-notas' and public=false) then raise exception 'FALHA: bucket fiscal-notas ausente ou público'; end if;
  if not exists(select 1 from pg_constraint where conname='ai_segredos_provedor_check') then raise exception 'FALHA: restrição de provedores IA ausente'; end if;
  if not exists(select 1 from pg_indexes where schemaname='public' and indexname='fiscal_leituras_chave_ativa_uq') then raise exception 'FALHA: índice de duplicidade fiscal ausente'; end if;
  raise notice 'OK: estrutura do Leitor Fiscal IA encontrada; bucket privado e trava de duplicidade presentes.';
end $test$;
select id,name,public,file_size_limit from storage.buckets where id='fiscal-notas';
select jobname,schedule,active from cron.job where jobname='fiscal-leituras-limpeza-diaria';
