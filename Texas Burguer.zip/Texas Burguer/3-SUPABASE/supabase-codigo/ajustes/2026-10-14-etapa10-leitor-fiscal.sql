-- TEXAS BURGER — Etapa 10: Leitor Fiscal IA (executar manualmente depois de revisar)
-- Não executar automaticamente. Fotos em bucket privado; histórico e exclusão após 30 dias.

-- Chaves dedicadas para o leitor fiscal, sem reutilizar a chave pública de atendimento.
alter table public.ai_segredos drop constraint if exists ai_segredos_provedor_check;
alter table public.ai_segredos add constraint ai_segredos_provedor_check
  check (provedor = any (array['gemini','groq','nvidia','cloudflare','cloudflare_conta','gemini_fotos','groq_2']));


-- Importa, sem exibir em logs, os segredos que já estavam no Vault com prefixo pendente_.
-- Não apaga os originais automaticamente: remova-os do Vault manualmente depois de validar o leitor.
do $vault$
begin
  begin
    execute $q$
      insert into public.ai_segredos(provedor,chave,atualizado_em)
      select case name when 'pendente_gemini_fotos' then 'gemini_fotos' when 'pendente_groq_2' then 'groq_2' end,
             decrypted_secret, now()
      from vault.decrypted_secrets
      where name in ('pendente_gemini_fotos','pendente_groq_2') and coalesce(decrypted_secret,'') <> ''
      on conflict (provedor) do nothing
    $q$;
  exception when others then raise notice 'Importação do Vault não executada; cadastre gemini_fotos e groq_2 em Contas e acessos depois: %', sqlerrm;
  end;
end $vault$;

-- Inclui as duas chaves fiscais na tela Contas e acessos.
create or replace function public.api_listar_chaves_ia(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok',true,'extrasPublico',coalesce((select extras_publico from ai_config limit 1),false),
    'chaves',coalesce((select jsonb_agg(jsonb_build_object('provedor',v.prov,'temChave',length(coalesce(s.chave,''))>0 and (v.prov<>'cloudflare' or length(coalesce(c.chave,''))>0),'final',case when length(coalesce(s.chave,''))>8 then right(s.chave,4) else '' end,'temConta',length(coalesce(c.chave,''))>0,'descansando',_ia_provedor_descansando(v.prov),'atualizadoEm',s.atualizado_em) order by v.ordem)
    from (values ('gemini',1),('groq',2),('nvidia',3),('cloudflare',4),('gemini_fotos',5),('groq_2',6)) v(prov,ordem)
    left join ai_segredos s on s.provedor=v.prov left join ai_segredos c on c.provedor='cloudflare_conta' and v.prov='cloudflare'),'[]'::jsonb));
end $f$;
create or replace function public.api_ver_chave_ia(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare v text; v_conta text; v_prov text:=lower(coalesce(p->>'provedor',''));
begin
 if not tem_nivel('Admin') then return _negado(); end if;
 if v_prov not in ('gemini','groq','nvidia','cloudflare','gemini_fotos','groq_2') then return _falha('IA desconhecida.'); end if;
 if coalesce(p->>'senhaAdmin','')='' then return _falha('Informe a sua senha de administrador.'); end if;
 if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
 select chave into v from ai_segredos where provedor=v_prov;
 if coalesce(v,'')='' then return _falha('Esta IA não tem chave guardada.'); end if;
 select chave into v_conta from ai_segredos where provedor='cloudflare_conta' and v_prov='cloudflare';
 perform _auditar('Chave de IA visualizada',v_prov);
 return jsonb_build_object('ok',true,'chave',v)||case when v_prov='cloudflare' then jsonb_build_object('contaId',coalesce(v_conta,'')) else '{}'::jsonb end;
end $f$;
create or replace function public.api_salvar_chave_ia(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text:=lower(coalesce(p->>'provedor','')); v_chave text:=btrim(coalesce(p->>'chave','')); v_conta text:=lower(btrim(coalesce(p->>'contaId','')));
begin
 if not tem_nivel('Admin') then return _negado(); end if;
 if v_prov not in ('gemini','groq','nvidia','cloudflare','gemini_fotos','groq_2') then return _falha('IA desconhecida.'); end if;
 if coalesce(p->>'senhaAdmin','')='' then return _falha('Informe a sua senha de administrador.'); end if;
 if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
 if length(v_chave)<20 or length(v_chave)>300 or v_chave ~ '\s' then return _falha('Chave inválida. Copie a chave inteira, sem espaços.'); end if;
 if v_prov='cloudflare' then
  if v_conta='' and not exists(select 1 from ai_segredos where provedor='cloudflare_conta') then return _falha('Informe também o Account ID da Cloudflare.'); end if;
  if v_conta<>'' and v_conta !~ '^[0-9a-f]{32}$' then return _falha('Account ID inválido: são 32 letras e números.'); end if;
  if v_conta<>'' then insert into ai_segredos(provedor,chave,atualizado_em) values('cloudflare_conta',v_conta,now()) on conflict(provedor) do update set chave=excluded.chave,atualizado_em=now(); end if;
 end if;
 insert into ai_segredos(provedor,chave,atualizado_em) values(v_prov,v_chave,now()) on conflict(provedor) do update set chave=excluded.chave,atualizado_em=now();
 perform _auditar('Chave de IA trocada',v_prov);
 return jsonb_build_object('ok',true,'message','Chave salva. O leitor fiscal já pode usá-la.')||api_listar_chaves_ia('{}');
end $f$;

create table if not exists public.fiscal_leituras (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid references public.usuarios(id) on delete set null,
  storage_path text,
  origem text not null check (origem in ('foto','texto','xml')),
  chave_nfe text,
  emitente_cnpj text,
  emitente_nome text not null default '',
  data_emissao date,
  numero_documento text,
  serie text,
  total numeric(12,2) not null default 0 check (total >= 0),
  itens jsonb not null default '[]'::jsonb,
  alertas jsonb not null default '[]'::jsonb,
  estado text not null default 'lida' check (estado in ('lida','confirmada','descartada','duplicada','erro')),
  compra_id uuid references public.compras(id) on delete set null,
  confirmada_por uuid references public.usuarios(id) on delete set null,
  confirmada_em timestamptz,
  criada_em timestamptz not null default now(),
  expira_em timestamptz not null default (now() + interval '30 days'),
  foto_excluida_em timestamptz
);
alter table public.fiscal_leituras add column if not exists foto_excluida_em timestamptz;
create index if not exists fiscal_leituras_data_idx on public.fiscal_leituras(criada_em desc);
create index if not exists fiscal_leituras_expira_idx on public.fiscal_leituras(expira_em);
create unique index if not exists fiscal_leituras_chave_ativa_uq on public.fiscal_leituras(chave_nfe)
  where chave_nfe is not null and chave_nfe <> '' and estado in ('lida','confirmada','duplicada');
alter table public.fiscal_leituras enable row level security;
revoke all on public.fiscal_leituras from anon, authenticated;
grant all on public.fiscal_leituras to service_role;

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('fiscal-notas','fiscal-notas',false,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=false,file_size_limit=5242880,allowed_mime_types=array['image/jpeg','image/png','image/webp'];
-- Upload é permitido somente à equipe (Admin/Operador) e em caminhos prefixados pelo próprio UID. Leitura/remoção só pela service_role.
drop policy if exists fiscal_notas_upload_proprio on storage.objects;
create policy fiscal_notas_upload_proprio on storage.objects for insert to authenticated
  with check (bucket_id='fiscal-notas' and (storage.foldername(name))[1] = auth.uid()::text
              and public.auth_nivel()::text in ('Admin','Operador'));   -- cliente com conta (também 'authenticated') não pode enviar
drop policy if exists fiscal_notas_sem_leitura_publica on storage.objects;
create policy fiscal_notas_sem_leitura_publica on storage.objects for select to authenticated using (false);
drop policy if exists fiscal_notas_sem_update_publico on storage.objects;
create policy fiscal_notas_sem_update_publico on storage.objects for update to authenticated using (false);
drop policy if exists fiscal_notas_sem_delete_publico on storage.objects;
create policy fiscal_notas_sem_delete_publico on storage.objects for delete to authenticated using (false);

-- Só service_role pode chamar; a Edge Function confere a função do usuário antes de inserir/atualizar.
create or replace function public.fiscal_obter_cnpj_empresa()
returns text language sql stable security definer set search_path=public as $f$
  select regexp_replace(coalesce((select cnpj from public.fiscal_empresa where id),''),'\D','','g')
$f$;
revoke all on function public.fiscal_obter_cnpj_empresa() from public,anon,authenticated;
grant execute on function public.fiscal_obter_cnpj_empresa() to service_role;

-- Histórico de confirmação. Idempotente: repetir a mesma confirmação não altera o registro já confirmado.
create or replace function public.fiscal_marcar_confirmada(p_id uuid,p_compra_id uuid,p_usuario uuid)
returns jsonb language plpgsql security definer set search_path=public as $f$
declare v public.fiscal_leituras%rowtype;
begin
  select * into v from public.fiscal_leituras where id=p_id for update;
  if not found then return jsonb_build_object('ok',false,'message','Leitura não encontrada.'); end if;
  if v.estado='confirmada' then return jsonb_build_object('ok',true,'jaConfirmada',true); end if;
  if v.estado<>'lida' then return jsonb_build_object('ok',false,'message','Esta leitura não pode ser confirmada.'); end if;
  update public.fiscal_leituras set estado='confirmada', compra_id=p_compra_id, confirmada_por=p_usuario, confirmada_em=now() where id=p_id;
  return jsonb_build_object('ok',true);
end $f$;
revoke all on function public.fiscal_marcar_confirmada(uuid,uuid,uuid) from public,anon,authenticated;
grant execute on function public.fiscal_marcar_confirmada(uuid,uuid,uuid) to service_role;

create or replace function public.fiscal_marcar_descartada(p_id uuid,p_usuario uuid)
returns jsonb language plpgsql security definer set search_path=public as $f$
begin
  update public.fiscal_leituras set estado='descartada' where id=p_id and estado='lida' and usuario_id=p_usuario;
  if not found then return jsonb_build_object('ok',false,'message','Leitura não encontrada ou já finalizada.'); end if;
  return jsonb_build_object('ok',true);
end $f$;
revoke all on function public.fiscal_marcar_descartada(uuid,uuid) from public,anon,authenticated;
grant execute on function public.fiscal_marcar_descartada(uuid,uuid) to service_role;

-- Executa a limpeza pela Edge Function fiscal-limpar (remove do Storage pela API oficial antes de apagar o histórico).
do $$ begin
  if exists(select 1 from pg_extension where extname='pg_cron') then
    if not exists(select 1 from cron.job where jobname='fiscal-leituras-limpeza-diaria') then
      perform cron.schedule('fiscal-leituras-limpeza-diaria','20 7 * * *', $c$select public.chamar_edge('fiscal-limpar','{"cron":true}'::jsonb);$c$);
    end if;
  end if;
exception when others then raise notice 'Agendamento não criado; configure fiscal-limpar diariamente depois: %', sqlerrm;
end $$;

-- Ajuda do Tex
insert into public.ai_ajuda (slug,titulo,grupo,ordem,perfis,ativo,palavras_chave,passos,comuns,atualizado_em)
values ('man-admin-113-leitor-fiscal','Ler nota fiscal ou cupom pelo Tex','Financeiro',113,array['Admin','Operador'],true,'nota fiscal cupom fiscal foto XML leitor fiscal Tex compra fornecedor estoque despesa financeiro',
'Abra Administrador → Pergunte à IA → Leitor Fiscal IA. Envie uma foto legível, um XML de NF-e ou cole o texto da nota. Confira emitente, CNPJ, data, chave, fornecedor, itens, quantidades e valores. A soma dos itens deve bater com o total. Só toque em Confirmar e lançar compra depois de conferir: a confirmação registra a compra e pode atualizar estoque e financeiro. A foto fica em armazenamento privado e é excluída automaticamente após 30 dias. Se a leitura falhar, digite os dados manualmente.',
'Não lance uma nota do próprio Texas Burger como compra. Nota repetida pela chave fiscal é bloqueada. Pagamento dividido deve ser conferido e lançado manualmente nesta versão.',now())
on conflict (slug) do update set titulo=excluded.titulo,grupo=excluded.grupo,ordem=excluded.ordem,perfis=excluded.perfis,ativo=excluded.ativo,palavras_chave=excluded.palavras_chave,passos=excluded.passos,comuns=excluded.comuns,atualizado_em=now();
