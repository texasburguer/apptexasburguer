-- Etapa 10 — correção de segurança (rode se você JÁ aplicou o SQL do Leitor Fiscal antes de 14/10/2026).
-- Antes, qualquer pessoa com conta (inclusive cliente do cardápio) podia enviar fotos para o bucket fiscal-notas.
-- Agora só Admin e Operador (o Desenvolvedor vale como Admin) enviam, e só na própria pasta. Pode rodar mais de uma vez.
drop policy if exists fiscal_notas_upload_proprio on storage.objects;
create policy fiscal_notas_upload_proprio on storage.objects for insert to authenticated
  with check (bucket_id='fiscal-notas' and (storage.foldername(name))[1] = auth.uid()::text
              and public.auth_nivel()::text in ('Admin','Operador'));
