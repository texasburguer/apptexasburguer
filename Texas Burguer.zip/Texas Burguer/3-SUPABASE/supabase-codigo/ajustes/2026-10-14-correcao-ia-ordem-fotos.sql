-- Texas Burger — correção IA: ordem de provedores e Gemini 2 exclusiva para fotos
-- Já aplicada no projeto Supabase. Este arquivo fica no ZIP como histórico reproduzível.
create or replace function public.api_listar_chaves_ia(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok',true,'extrasPublico',coalesce((select extras_publico from ai_config limit 1),false),
    'chaves',coalesce((select jsonb_agg(jsonb_build_object('provedor',v.prov,'temChave',length(coalesce(s.chave,''))>0 and (v.prov<>'cloudflare' or length(coalesce(c.chave,''))>0),'final',case when length(coalesce(s.chave,''))>8 then right(s.chave,4) else '' end,'temConta',length(coalesce(c.chave,''))>0,'descansando',_ia_provedor_descansando(v.prov),'atualizadoEm',s.atualizado_em) order by v.ordem)
    from (values ('groq',1),('groq_2',2),('nvidia',3),('cloudflare',4),('gemini',5),('gemini_fotos',6)) v(prov,ordem)
    left join ai_segredos s on s.provedor=v.prov left join ai_segredos c on c.provedor='cloudflare_conta' and v.prov='cloudflare'),'[]'::jsonb));
end $f$;
