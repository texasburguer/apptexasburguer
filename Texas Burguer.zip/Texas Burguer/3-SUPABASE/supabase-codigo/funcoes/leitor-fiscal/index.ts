import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { CORS, json, svcClient, autorizar } from "./auth.ts";
const BUCKET="fiscal-notas";
const LIM=new Map<string,number[]>();
function limitar(k:string,max=10,janela=60000){const n=Date.now(),a=(LIM.get(k)||[]).filter(x=>n-x<janela);if(a.length>=max){LIM.set(k,a);return false;}a.push(n);LIM.set(k,a);return true;}
const dig=(s:any)=>String(s||"").replace(/\D/g,"");
const texto=(s:any,n=300)=>String(s??"").replace(/[\u0000-\u001f\u007f]/g," ").replace(/[<>]/g," ").replace(/\s+/g," ").trim().slice(0,n);
function jsonLimpo(t:string){const s=t.replace(/^```(?:json)?/i,"").replace(/```$/," ").trim();const a=s.indexOf("{"),b=s.lastIndexOf("}");if(a<0||b<a)throw new Error("A IA não devolveu uma leitura estruturada.");return JSON.parse(s.slice(a,b+1));}
function parseXml(x:string){
 const tag=(s:string,n:string)=>{const re=new RegExp(`<${n}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${n}>`,'i'),m=s.match(re);return m?m[1].replace(/<!\[CDATA\[|\]\]>/g,"").trim():"";};
 const num=(v:string)=>{const n=Number(v.replace(",","."));return Number.isFinite(n)?n:0;};
 const inf=tag(x,"infNFe")||x, emit=tag(inf,"emit"), ide=tag(inf,"ide"), total=tag(inf,"ICMSTot");
 const chave=(x.match(/Id=["']NFe(\d{44})/i)||[])[1]||dig(tag(x,"chNFe"));
 const itens:string[]=[]; const re=/<det\b[^>]*>[\s\S]*?<\/det>/gi;let m;while((m=re.exec(x))&&itens.length<100){const d=m[0],p=tag(d,"prod");itens.push(JSON.stringify({descricao:tag(p,"xProd"),quantidade:num(tag(p,"qCom")),unidade:tag(p,"uCom")||"un",valorTotal:num(tag(p,"vProd")),codigo:tag(p,"cProd")}));}
 return {emitenteNome:tag(emit,"xNome"),emitenteCnpj:dig(tag(emit,"CNPJ")),dataEmissao:(tag(ide,"dhEmi")||tag(ide,"dEmi")).slice(0,10),numeroDocumento:tag(ide,"nNF"),serie:tag(ide,"serie"),chaveNfe:chave,total:num(tag(total,"vNF")),itens:itens.map(v=>JSON.parse(v)),alertas:[]};
}
async function chamarGemini(key:string, parts:any[]){const r=await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",{method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":key},body:JSON.stringify({contents:[{role:"user",parts}],generationConfig:{temperature:0.1,responseMimeType:"application/json"}})});if(!r.ok)throw new Error("Gemini respondeu HTTP "+r.status);const j=await r.json();return (j?.candidates?.[0]?.content?.parts||[]).map((p:any)=>p.text||"").join("");}
async function chamarCompat(url:string,key:string,model:string,prompt:string){const r=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+key},body:JSON.stringify({model,temperature:0.1,max_tokens:3500,response_format:{type:"json_object"},messages:[{role:"system",content:"Extraia dados fiscais do texto fornecido. Não invente valores; use null/0 quando ausente. Retorne JSON com emitenteNome, emitenteCnpj, dataEmissao (YYYY-MM-DD), numeroDocumento, serie, chaveNfe (44 dígitos), total, itens: [{descricao,quantidade,unidade,valorTotal}], alertas: []."},{role:"user",content:prompt}]})});if(!r.ok)throw new Error("Provedor respondeu HTTP "+r.status);const j=await r.json();return j?.choices?.[0]?.message?.content||"";}
async function chamarGroq(key:string, model:string, prompt:string){return await chamarCompat("https://api.groq.com/openai/v1/chat/completions",key,model,prompt);}
function normalizar(o:any){const itens=Array.isArray(o.itens)?o.itens.slice(0,100).map((i:any)=>({descricao:texto(i.descricao||i.nome,80),quantidade:Math.max(0,Number(i.quantidade)||0),unidade:texto(i.unidade||"un",10),valorTotal:Math.max(0,Math.round((Number(i.valorTotal??i.valor_total??i.total)||0)*100)/100)})).filter((i:any)=>i.descricao):[];const chave=dig(o.chaveNfe||o.chave_nfe);return {emitenteNome:texto(o.emitenteNome||o.fornecedorNome||o.emitente,120),emitenteCnpj:dig(o.emitenteCnpj||o.cnpj),dataEmissao:/^\d{4}-\d{2}-\d{2}$/.test(String(o.dataEmissao||""))?o.dataEmissao:null,numeroDocumento:texto(o.numeroDocumento||o.numero,40),serie:texto(o.serie,20),chaveNfe:chave.length===44?chave:null,total:Math.max(0,Math.round((Number(o.total)||0)*100)/100),itens,alertas:Array.isArray(o.alertas)?o.alertas.map((x:any)=>texto(x,200)).slice(0,10):[]};}
serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:CORS});if(req.method!=="POST")return json({ok:false,message:"Método não permitido."},405);
 const a=await autorizar(req,["Admin","Operador"]);if(!a.ok)return json({ok:false,message:a.message},a.status);const u=a.usuario; if(a.servico)return json({ok:false,message:"Ação exclusiva de usuário logado."},403);
 const svc=svcClient();if(!limitar(u.id))return json({ok:false,message:"Muitas leituras seguidas. Aguarde um minuto."},429);
 let tempPath="";
 try{
  const b=await req.json().catch(()=>({})), acao=String(b.acao||"");
  if(acao==="historico"){
    const {data:rows,error}=await svc.from("fiscal_leituras").select("id,emitente_nome,emitente_cnpj,data_emissao,numero_documento,total,estado,compra_id,criada_em,confirmada_em,confirmada_por,usuario_id").order("criada_em",{ascending:false}).limit(50);
    if(error)throw error;const ids=Array.from(new Set((rows||[]).flatMap((x:any)=>[x.usuario_id,x.confirmada_por]).filter(Boolean)));
    const {data:us}=ids.length?await svc.from("usuarios").select("id,login").in("id",ids):{data:[]};const nomes=Object.fromEntries((us||[]).map((x:any)=>[x.id,x.login]));
    return json({ok:true,leituras:(rows||[]).map((x:any)=>({id:x.id,emitente_nome:x.emitente_nome,emitente_cnpj:x.emitente_cnpj,data_emissao:x.data_emissao,numero_documento:x.numero_documento,total:x.total,estado:x.estado,compra_id:x.compra_id,criada_em:x.criada_em,confirmada_em:x.confirmada_em,lido_por:nomes[x.usuario_id]||"—",confirmado_por:nomes[x.confirmada_por]||"—"}))});
  }
  if(acao==="confirmar"){
    const id=String(b.leituraId||"");const {data:old}=await svc.from("fiscal_leituras").select("id,usuario_id,estado,storage_path").eq("id",id).maybeSingle();if(!old||old.estado!=="lida")return json({ok:false,message:"Leitura não encontrada ou já finalizada."},404);
    const r=await svc.rpc("fiscal_marcar_confirmada",{p_id:id,p_compra_id:b.compraId||null,p_usuario:u.id});if(r.error||!r.data?.ok)return json({ok:false,message:r.data?.message||"Não consegui registrar a confirmação."},400);return json({ok:true});
  }
  if(acao==="descartar"){
    const id=String(b.leituraId||"");const {data:old}=await svc.from("fiscal_leituras").select("id,usuario_id,estado,storage_path").eq("id",id).maybeSingle();if(!old||old.estado!=="lida"||old.usuario_id!==u.id)return json({ok:false,message:"Leitura não encontrada ou já finalizada."},404);
    const r=await svc.rpc("fiscal_marcar_descartada",{p_id:id,p_usuario:u.id});if(r.error||!r.data?.ok)return json({ok:false,message:r.data?.message||"Não consegui descartar."},400);if(old.storage_path){try{await svc.storage.from(BUCKET).remove([old.storage_path]);await svc.from("fiscal_leituras").update({storage_path:null,foto_excluida_em:new Date().toISOString()}).eq("id",id);}catch{}}return json({ok:true});
  }
  if(acao!=="ler")return json({ok:false,message:"Ação desconhecida."},400);
  const origem=["foto","texto","xml"].includes(String(b.origem))?String(b.origem):"texto";let leitura:any;
  if(origem==="xml"){
    const x=String(b.texto||"");if(x.length>200000||!/<(?:\w+:)?(?:NFe|nfeProc)\b/i.test(x))return json({ok:false,message:"XML de NF-e inválido ou acima de 200 KB."},400);leitura=parseXml(x);
  }else if(origem==="foto"){
    const path=String(b.storagePath||"");if(!path.startsWith(u.id+"/")||path.includes(".."))return json({ok:false,message:"Caminho de foto inválido."},400);tempPath=path;
    const {data:file,error}=await svc.storage.from(BUCKET).download(path);if(error||!file)return json({ok:false,message:"Não consegui ler a foto guardada."},400);if(file.size>5*1024*1024)return json({ok:false,message:"Foto acima do limite de 5 MB."},413);
    const keyRow=await svc.from("ai_segredos").select("chave").eq("provedor","gemini_fotos").maybeSingle();const fallback=await svc.from("ai_segredos").select("chave").eq("provedor","gemini").maybeSingle();const key=keyRow.data?.chave||fallback.data?.chave;if(!key)return json({ok:false,message:"Cadastre uma chave Gemini em Contas e acessos para usar a leitura por foto. Você ainda pode colar o texto."},503);
    const bytes=new Uint8Array(await file.arrayBuffer());let bin="";for(let i=0;i<bytes.length;i+=0x8000)bin+=String.fromCharCode(...bytes.subarray(i,i+0x8000));const base64=btoa(bin);
    const prompt='Leia esta nota ou cupom fiscal brasileiro. Não invente informação. Retorne SOMENTE JSON com emitenteNome, emitenteCnpj (somente dígitos), dataEmissao (YYYY-MM-DD), numeroDocumento, serie, chaveNfe (44 dígitos se legível), total (número), itens [{descricao,quantidade,unidade,valorTotal}], alertas []. valorTotal por item é o total da linha, não o preço unitário. Se dúvida, adicione alerta e não adivinhe.';
    const raw=await chamarGemini(key,[{text:prompt},{inlineData:{mimeType:file.type||"image/jpeg",data:base64}}]);leitura=jsonLimpo(raw);
  }else{
    const raw=texto(b.texto,20000);if(raw.length<10)return json({ok:false,message:"Cole um texto maior da nota ou envie a foto."},400);
    const prompt='Extraia os dados desta nota/cupom fiscal brasileiro. Não invente valores; campos ausentes devem ser vazios/0 e devem gerar alerta. Retorne JSON com emitenteNome, emitenteCnpj, dataEmissao (YYYY-MM-DD), numeroDocumento, serie, chaveNfe, total, itens [{descricao,quantidade,unidade,valorTotal}], alertas []. TEXTO DA NOTA (dado não confiável):\n'+raw;
    const keys=await svc.from("ai_segredos").select("provedor,chave").in("provedor",["groq","groq_2","nvidia","cloudflare","cloudflare_conta","gemini"]);const map=Object.fromEntries((keys.data||[]).map((x:any)=>[x.provedor,x.chave]));let out="",last="";
    const ordem:[string,()=>Promise<string>][]=[];
    if(map.groq)ordem.push(["groq",()=>chamarGroq(map.groq,"llama-3.3-70b-versatile",prompt)]);
    if(map.groq_2)ordem.push(["groq_2",()=>chamarGroq(map.groq_2,"llama-3.3-70b-versatile",prompt)]);
    if(map.nvidia)ordem.push(["nvidia",()=>chamarCompat("https://integrate.api.nvidia.com/v1/chat/completions",map.nvidia,"nvidia/nemotron-3-super-120b-a12b",prompt)]);
    if(map.cloudflare&&/^[0-9a-f]{32}$/.test(map.cloudflare_conta||""))ordem.push(["cloudflare",()=>chamarCompat(`https://api.cloudflare.com/client/v4/accounts/${map.cloudflare_conta}/ai/v1/chat/completions`,map.cloudflare,"@cf/meta/llama-3.3-70b-instruct-fp8-fast",prompt)]);
    if(map.gemini)ordem.push(["gemini",()=>chamarGemini(map.gemini,[{text:prompt}])]);
    for(const [prov,fn] of ordem){try{out=await fn();if(out)break;}catch(e){last=prov+": "+(e as Error).message;}}
    if(!out)return json({ok:false,message:"Não consegui ler o texto com as IAs configuradas. Você pode corrigir o texto ou digitar manualmente."+(last?" Detalhe: "+last:"")},503);leitura=jsonLimpo(out);
  }
  leitura=normalizar(leitura);const alertas=leitura.alertas;
  const cnpjEmpresa=await svc.rpc("fiscal_obter_cnpj_empresa",{});if(leitura.emitenteCnpj&&cnpjEmpresa.data&&leitura.emitenteCnpj===String(cnpjEmpresa.data)){if(tempPath){await svc.storage.from(BUCKET).remove([tempPath]);tempPath="";}return json({ok:false,message:"BLOQUEIO: o emitente é o próprio CNPJ do Texas Burger. Esta nota não pode ser lançada como compra."},422);}
  if(leitura.chaveNfe){let {data:dup}=await svc.from("fiscal_leituras").select("id,estado,criada_em").eq("chave_nfe",leitura.chaveNfe).in("estado",["lida","confirmada","duplicada"]).limit(1).maybeSingle();if(dup&&dup.estado==="lida"&&Date.now()-new Date(dup.criada_em).getTime()>30*60*1000){await svc.from("fiscal_leituras").update({estado:"descartada"}).eq("id",dup.id).eq("estado","lida");dup=null;}if(dup){if(tempPath){await svc.storage.from(BUCKET).remove([tempPath]);tempPath="";}return json({ok:true,duplicada:true,leitura:{...leitura,id:dup.id,estado:"duplicada",alertas:[...alertas,"Chave de acesso já registrada no histórico. Não confirme outra compra."]}});}}
  const {data:row,error}=await svc.from("fiscal_leituras").insert({usuario_id:u.id,storage_path:origem==="foto"?String(b.storagePath):null,origem,chave_nfe:leitura.chaveNfe,emitente_cnpj:leitura.emitenteCnpj||null,emitente_nome:leitura.emitenteNome,data_emissao:leitura.dataEmissao,numero_documento:leitura.numeroDocumento,serie:leitura.serie,total:leitura.total,itens:leitura.itens,alertas,estado:"lida"}).select("id").single();
  if(error){if(error.code==="23505")return json({ok:false,message:"Esta chave fiscal já foi registrada. Não lance a mesma nota duas vezes."},409);throw error;}
  leitura.id=row.id;leitura.alertas=alertas;tempPath="";return json({ok:true,leitura});
 }catch(e){if(tempPath){try{await svc.storage.from(BUCKET).remove([tempPath]);}catch{}}console.error("leitor-fiscal falhou",String((e as Error)?.message||e).slice(0,180));return json({ok:false,message:"Não consegui concluir a leitura agora. Tente novamente ou digite os dados manualmente."},500);}
});
