import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { CORS, json, svcClient, autorizar } from "./auth.ts";
serve(async req=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:CORS});
 if(req.method!=="POST")return json({ok:false,message:"Método não permitido."},405);
 const a=await autorizar(req,["Admin"]);if(!a.ok)return json({ok:false,message:a.message},a.status);
 try{
  const s=svcClient(),agora=new Date().toISOString();
  const {data:rows,error}=await s.from("fiscal_leituras").select("id,storage_path").lt("expira_em",agora).not("storage_path","is",null).limit(500);if(error)throw error;
  let fotosRemovidas=0,falhas=0;
  for(const row of (rows||[])){
   const r=await s.storage.from("fiscal-notas").remove([row.storage_path]);
   if(r.error){falhas++;continue;}
   const {error:e}=await s.from("fiscal_leituras").update({storage_path:null,foto_excluida_em:agora}).eq("id",row.id);
   if(e){falhas++;continue;} fotosRemovidas++;
  }
  // Fotos enviadas que nunca viraram leitura (erro da IA, desistência): sem linha no histórico há mais de 1 dia.
  let orfas=0;
  try{
   const corte=Date.now()-24*3600*1000;
   const {data:pastas}=await s.storage.from("fiscal-notas").list("",{limit:100});
   for(const p of (pastas||[])){
    if(p.id) continue;   // pasta vem sem id; arquivo solto na raiz não é esperado
    const {data:arqs}=await s.storage.from("fiscal-notas").list(p.name,{limit:200});
    const velhos=(arqs||[]).filter((a:any)=>a.created_at&&new Date(a.created_at).getTime()<corte).map((a:any)=>p.name+"/"+a.name);
    if(!velhos.length) continue;
    const {data:usados}=await s.from("fiscal_leituras").select("storage_path").in("storage_path",velhos);
    const emUso=new Set((usados||[]).map((x:any)=>x.storage_path));
    const apagar=velhos.filter((v:string)=>!emUso.has(v));
    if(apagar.length){const r=await s.storage.from("fiscal-notas").remove(apagar);if(!r.error)orfas+=apagar.length;}
   }
  }catch(_){ falhas++; }
  // Mantém metadados/histórico da compra e quem confirmou; remove só as fotos privadas após 30 dias.
  return json({ok:true,fotosRemovidas,fotosOrfasRemovidas:orfas,falhas});
 }catch(_){return json({ok:false,message:"Falha ao limpar fotos fiscais antigas."},500);}
});
