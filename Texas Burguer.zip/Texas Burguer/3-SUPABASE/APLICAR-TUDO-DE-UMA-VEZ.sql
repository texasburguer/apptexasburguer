-- =====================================================================
-- TEXAS BURGER — SQL COMPLETO DO PLANO (Mercado Pago + Leitor Fiscal + LGPD) — gerado em 14/10/2026
-- COMO USAR: Supabase → SQL Editor → New query → cole TUDO → Run (uma vez só).
-- • Roda em UMA transação: se algo der erro, NADA é aplicado (e a mensagem diz onde). Pode rodar de novo depois de corrigir.
-- • Supõe que tudo anterior a 13/10/2026 (conta do cliente, brindes, imposto/iFood etc.) já está aplicado.
-- • É seguro repetir: usa "create or replace" e "if not exists".
-- • Depois disto, ainda precisa PUBLICAR as Edge Functions: mp-criar, mp-webhook, mp-status, mp-reembolsar, leitor-fiscal, fiscal-limpar.
-- =====================================================================
begin;

-- =====================================================================
-- PARTE 1 — Mercado Pago: estrutura (tabelas, formas online, config)
-- (arquivo de origem: ajustes/2026-10-13-mp-etapa1-estrutura.sql)
-- =====================================================================
-- =====================================================================================
-- MERCADO PAGO · ETAPA 1 (estrutura do banco) · 2026-10-13 · NÃO APLICADO
-- Só ADICIONA. Nada existente é apagado e o cardápio continua igual: a integração nasce DESLIGADA.
-- Rode DEPOIS do SUBIR-TUDO-supabase.sql e dos ajustes de 11 e 12/10. Pode rodar de novo (idempotente).
-- Cole inteiro no SQL Editor do Supabase. Para conferir depois, rode testes/teste-mp-etapa1.sql.
-- =====================================================================================


-- ---------- 1) O Mercado Pago entra no molde das integrações (iFood e Nota fiscal) ----------
do $d$
declare c record;
begin
  for c in select conname from pg_constraint where conrelid = 'public.integracoes_config'::regclass and contype = 'c' and pg_get_constraintdef(oid) like '%provedor%' loop
    execute format('alter table public.integracoes_config drop constraint %I', c.conname);
  end loop;
  alter table public.integracoes_config add constraint integracoes_config_provedor_check
    check (provedor in ('ifood', 'nfce', 'mercadopago'));

  for c in select conname from pg_constraint where conrelid = 'public.integracoes_segredos'::regclass and contype = 'c' and pg_get_constraintdef(oid) like '%chave%' loop
    execute format('alter table public.integracoes_segredos drop constraint %I', c.conname);
  end loop;
  alter table public.integracoes_segredos add constraint integracoes_segredos_chave_check
    check (chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id', 'nfce_token_homologacao', 'nfce_token_producao', 'nfce_csc',
                     'mp_public_key_teste', 'mp_public_key_producao', 'mp_access_token_teste', 'mp_access_token_producao', 'mp_webhook_secret'));
end $d$;

-- modo 'homologacao' = Teste na tela. pixValidadeMin = validade do Pix na tela do cliente (minutos).
-- testeNoCardapio = só com true o cliente vê o pagamento online enquanto o modo for Teste (padrão: não).
insert into public.integracoes_config (provedor, modo, config) values
  ('mercadopago', 'homologacao', '{"pixValidadeMin": 15, "testeNoCardapio": false}'::jsonb)
on conflict (provedor) do nothing;

-- ---------- 2) Formas de pagamento: quais aceitam pagar online (a forma continua valendo na entrega) ----------
alter table public.formas_pagamento
  add column if not exists aceita_online boolean not null default false,
  add column if not exists tipo_online text;

do $d$
begin
  if not exists (select 1 from pg_constraint where conrelid = 'public.formas_pagamento'::regclass and conname = 'formas_pagamento_tipo_online_check') then
    alter table public.formas_pagamento add constraint formas_pagamento_tipo_online_check
      check (tipo_online is null or tipo_online in ('pix', 'credito'));
  end if;
  if not exists (select 1 from pg_constraint where conrelid = 'public.formas_pagamento'::regclass and conname = 'formas_pagamento_online_exige_tipo') then
    alter table public.formas_pagamento add constraint formas_pagamento_online_exige_tipo
      check (not aceita_online or tipo_online is not null);
  end if;
end $d$;

-- ---------- 3) Reserva do pedido (o pedido só vira venda depois do pagamento aprovado) ----------
create table if not exists public.pedidos_reserva (
  id uuid primary key default gen_random_uuid(),
  requisicao_id text unique,                                   -- id da tentativa enviado pela página: repetir não duplica
  user_id uuid not null,                                       -- conta do cliente (pagar online exige login)
  estado text not null default 'ativa' check (estado in ('ativa', 'confirmada', 'expirada', 'cancelada')),
  cliente_nome text not null default '',
  telefone text not null default '',
  tipo_entrega text not null default '',
  forma_pagamento_id uuid references public.formas_pagamento(id) on delete set null,
  dados_entrega jsonb,                                         -- endereço, número, cidade, complemento, referência (como a venda usa)
  observacoes text not null default '',
  itens jsonb not null,                                        -- itens JÁ validados no servidor (preço, custo, adicionais), no formato da venda
  beneficios jsonb not null default '[]'::jsonb,               -- brindes da conta incluídos no pedido
  cupom jsonb,                                                 -- resultado do cálculo do cupom (null = sem cupom)
  valor_original numeric(12,2) not null default 0,
  valor_desconto numeric(12,2) not null default 0,
  taxa_entrega numeric(12,2) not null default 0,
  acrescimo_forma numeric(12,2) not null default 0,
  valor_total numeric(12,2) not null check (valor_total > 0),
  custo_total numeric(12,2) not null default 0,
  estoque_reservado boolean not null default false,            -- true = a baixa de estoque está feita neste momento
  cupom_uso_id uuid,                                           -- linha reservada em cupons_usos (se houver cupom)
  brindes_reservados boolean not null default false,
  venda_id uuid references public.vendas(id) on delete set null,
  motivo_fim text not null default '',
  expira_em timestamptz not null,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
create index if not exists pedidos_reserva_ativas_idx on public.pedidos_reserva (expira_em) where estado = 'ativa';
create index if not exists pedidos_reserva_user_idx on public.pedidos_reserva (user_id, criado_em desc);
create index if not exists pedidos_reserva_venda_idx on public.pedidos_reserva (venda_id);
alter table public.pedidos_reserva enable row level security;   -- sem policy: só funções seguras e a chave de serviço

-- ---------- 4) Pagamentos online (um pedido no Mercado Pago por tentativa) ----------
create table if not exists public.pagamentos_online (
  id uuid primary key default gen_random_uuid(),
  reserva_id uuid not null references public.pedidos_reserva(id),
  venda_id uuid references public.vendas(id) on delete set null,
  user_id uuid,
  metodo text not null check (metodo in ('pix', 'credito')),
  mp_modo text not null check (mp_modo in ('homologacao', 'producao')),   -- modo em que o pagamento foi criado
  mp_order_id text unique,
  mp_payment_id text,
  status text not null default 'aguardando'
    check (status in ('aguardando', 'aprovado', 'recusado', 'expirado', 'cancelado', 'reembolso_parcial', 'reembolsado', 'erro')),
  status_detalhe text not null default '',
  valor numeric(12,2) not null check (valor > 0),
  valor_reembolsado numeric(12,2) not null default 0 check (valor_reembolsado >= 0),
  pix_copia_cola text,
  pix_qr_base64 text,
  pix_expira_em timestamptz,
  cartao_final text,                                            -- só os 4 últimos dígitos, se vierem
  cartao_bandeira text,
  aprovado_em timestamptz,
  decisao_pendente boolean not null default false,              -- "Pagamento a decidir": operador de caixa ou Admin escolhe
  decisao_motivo text not null default '',
  decisao text check (decisao is null or decisao in ('seguir', 'reembolsar')),
  decidido_por uuid,
  decidido_em timestamptz,
  erro text not null default '',
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
create index if not exists pagamentos_online_reserva_idx on public.pagamentos_online (reserva_id);
create index if not exists pagamentos_online_venda_idx on public.pagamentos_online (venda_id);
create index if not exists pagamentos_online_status_idx on public.pagamentos_online (status, criado_em desc);
create index if not exists pagamentos_online_decidir_idx on public.pagamentos_online (criado_em desc) where decisao_pendente and decisao is null;
create index if not exists pagamentos_online_mp_payment_idx on public.pagamentos_online (mp_payment_id);
alter table public.pagamentos_online enable row level security;

-- avisos (webhook) já recebidos: o mesmo aviso repetido não é processado duas vezes
create table if not exists public.pagamentos_online_eventos (
  id bigserial primary key,
  chave text not null unique,                                  -- identifica o aviso (definida na função mp-webhook)
  pagamento_id uuid references public.pagamentos_online(id) on delete cascade,
  tipo text not null default '',
  status_mp text not null default '',
  assinatura_ok boolean not null default false,
  detalhe jsonb,
  recebido_em timestamptz not null default now()
);
create index if not exists pagamentos_online_eventos_pag_idx on public.pagamentos_online_eventos (pagamento_id, recebido_em desc);
alter table public.pagamentos_online_eventos enable row level security;

-- as tabelas novas só são lidas/gravadas por funções seguras (security definer) e pela chave de serviço
revoke all on public.pedidos_reserva, public.pagamentos_online, public.pagamentos_online_eventos from anon, authenticated;
revoke all on sequence public.pagamentos_online_eventos_id_seq from anon, authenticated;

-- ---------- 5) Checklist do cartão Mercado Pago (mesmos itens da Prévia) ----------
-- Atenção: as duas funções abaixo partem das versões mais recentes (SUBIR-TUDO / f4) e só acrescentam o 'mercadopago'.
create or replace function public._integ_checklist_def(p_prov text) returns jsonb
 language sql immutable set search_path to 'public' as $f$
  select case p_prov
    when 'ifood' then '[
      {"id":"conta_dev","titulo":"O dono criou a conta de desenvolvedor no iFood (precisa do CNPJ)"},
      {"id":"acesso","titulo":"Acesso liberado aos módulos Pedidos, Catálogo, Loja, Financeiro e Avaliações"},
      {"id":"chaves","titulo":"Client ID, Client Secret e código da loja digitados aqui","auto":true},
      {"id":"teste_conexao","titulo":"Teste de conexão deu certo","auto":true},
      {"id":"homologacao","titulo":"Homologação do iFood aprovada"},
      {"id":"itens","titulo":"Itens do iFood ligados aos produtos (aba Itens do iFood)"},
      {"id":"equipe","titulo":"Equipe avisada de como o pedido do iFood aparece"}]'::jsonb
    when 'nfce' then '[
      {"id":"contador","titulo":"O contador definiu NCM, CFOP e situação tributária de cada perfil"},
      {"id":"certificado","titulo":"Certificado digital A1 do restaurante pronto"},
      {"id":"sefaz","titulo":"Credenciamento na Sefaz-SP feito e CSC (código de segurança) obtido"},
      {"id":"focus","titulo":"Conta na Focus NFe criada e empresa cadastrada lá (com o certificado)"},
      {"id":"token","titulo":"Token da Focus digitado aqui","auto":true},
      {"id":"empresa","titulo":"Dados fiscais da empresa preenchidos aqui","auto":true},
      {"id":"perfis","titulo":"Todos os produtos têm perfil fiscal","auto":true},
      {"id":"nota_teste","titulo":"Nota de teste (homologação) emitida e conferida pelo contador"}]'::jsonb
    when 'mercadopago' then '[
      {"id":"conta_vendedor","titulo":"Conta de vendedor criada no Mercado Pago (com a verificação de identidade)"},
      {"id":"chaves_teste","titulo":"Chaves de teste coladas","auto":true},
      {"id":"webhook","titulo":"Endereço do aviso (webhook) cadastrado no Mercado Pago","auto":true},
      {"id":"teste_guiado","titulo":"Teste guiado feito (Pix e cartão)","auto":true},
      {"id":"chaves_producao","titulo":"Chaves de produção coladas","auto":true}]'::jsonb
    else '[]'::jsonb end
$f$;

create or replace function public._integ_pendencias(p_prov text, p_modo text) returns text[]
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_out text[] := '{}'; v_item jsonb; v_ck jsonb; v_ok boolean;
begin
  select checklist into v_ck from integracoes_config where provedor = p_prov;
  for v_item in select * from jsonb_array_elements(_integ_checklist_def(p_prov)) loop
    if coalesce((v_item->>'auto')::boolean, false) then
      v_ok := case v_item->>'id'
        when 'chaves' then (select count(*) from integracoes_segredos where chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id')) = 3
        when 'token' then exists (select 1 from integracoes_segredos where chave = 'nfce_token_' || p_modo)
        when 'empresa' then public._fiscal_empresa_ok()
        when 'perfis' then public._fiscal_perfis_ok()
        when 'chaves_teste' then (select count(*) from integracoes_segredos where chave in ('mp_public_key_teste', 'mp_access_token_teste')) = 2
        when 'webhook' then exists (select 1 from integracoes_segredos where chave = 'mp_webhook_secret')
        when 'teste_guiado' then exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'pix' and status in ('aprovado', 'reembolso_parcial', 'reembolsado'))
                             and exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'credito' and status in ('aprovado', 'reembolso_parcial', 'reembolsado'))
        when 'chaves_producao' then (select count(*) from integracoes_segredos where chave in ('mp_public_key_producao', 'mp_access_token_producao')) = 2
        else coalesce((v_ck->>(v_item->>'id'))::boolean, false) end;
    else
      v_ok := coalesce((v_ck->>(v_item->>'id'))::boolean, false);
    end if;
    if not v_ok then v_out := v_out || (v_item->>'titulo'); end if;
  end loop;
  return v_out;
end $f$;

-- ---------- 6) Flags para a equipe: ganha 'mercadopago' (parte da versão mais recente, de imposto-e-ifood) ----------
create or replace function public.api_integracoes_flags(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public'
as $function$
declare v_adm boolean := tem_nivel('Admin');
begin
  if auth_nivel() is null then return _negado(); end if;
  return jsonb_build_object('ok', true, 'ifood', _integracao_ligada('ifood'), 'nfce', _integracao_ligada('nfce'),
    'mercadopago', _integracao_ligada('mercadopago'),
    'nfceModo', (select modo from integracoes_config where provedor = 'nfce'),
    'impostoPct', case when v_adm then _imposto_pct(current_date) else 0 end,
    'impostoPadrao', case when v_adm then coalesce((select aliquota_simples from fiscal_empresa where id), 0) else 0 end,
    'impostoMeses', case when v_adm then coalesce((select valor from sistema where chave = 'ImpostoAliquotasMes' and jsonb_typeof(valor) = 'object'), '{}'::jsonb) else '{}'::jsonb end);
end $function$;

-- ---------- 7) Leitura PÚBLICA para o cardápio (cliente sem login de equipe) ----------
-- Desligado, ou sem chave pública, ou sem forma online: devolve só {ligado:false}. Nunca devolve segredo (só a chave PÚBLICA).
-- Em modo Teste o cliente só vê o pagamento online se "testeNoCardapio" estiver true.
create or replace function public.api_mp_config_publica(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare c integracoes_config%rowtype; v_prod boolean; v_pk text; v_formas jsonb; v_min int;
begin
  select * into c from integracoes_config where provedor = 'mercadopago';
  if c.provedor is null or not c.ligado then return jsonb_build_object('ok', true, 'ligado', false); end if;
  v_prod := (c.modo = 'producao');
  if not v_prod and coalesce((c.config->>'testeNoCardapio')::boolean, false) is not true then return jsonb_build_object('ok', true, 'ligado', false); end if;
  select valor into v_pk from integracoes_segredos where chave = case when v_prod then 'mp_public_key_producao' else 'mp_public_key_teste' end;
  select coalesce(jsonb_agg(jsonb_build_object('id', f.id, 'tipo', f.tipo_online) order by f.ordem), '[]'::jsonb) into v_formas
    from formas_pagamento f where f.ativa and f.visivel_cardapio and f.aceita_online and f.tipo_online is not null;
  if v_pk is null or jsonb_array_length(v_formas) = 0 then return jsonb_build_object('ok', true, 'ligado', false); end if;
  v_min := case when coalesce(c.config->>'pixValidadeMin', '') ~ '^[0-9]{1,3}$' then least(120, greatest(5, (c.config->>'pixValidadeMin')::int)) else 15 end;
  return jsonb_build_object('ok', true, 'ligado', true, 'modo', case when v_prod then 'producao' else 'teste' end,
    'publicKey', v_pk, 'formas', v_formas, 'pixValidadeMin', v_min);
end $f$;
revoke all on function public.api_mp_config_publica(jsonb) from public, anon, authenticated;
grant execute on function public.api_mp_config_publica(jsonb) to anon, authenticated;

-- =====================================================================
-- PARTE 2 — Mercado Pago: reserva, status e pagamento no banco
-- (arquivo de origem: ajustes/2026-10-13-mp-etapa2-funcoes.sql)
-- =====================================================================
-- =====================================================================================
-- MERCADO PAGO · ETAPA 2 (funções do banco) · 2026-10-13 · NÃO APLICADO
-- Rode DEPOIS da Etapa 1 (2026-10-13-mp-etapa1-estrutura.sql). Pode rodar de novo (idempotente).
-- Cole inteiro no SQL Editor do Supabase. Para conferir depois, rode testes/teste-mp-etapa2.sql.
-- Com a integração DESLIGADA nada muda: o pedido normal do cardápio continua idêntico ao de hoje.
-- Nenhum "delete from" dentro de função (o conector do Supabase cancela): reserva desfeita = marcada, não apagada.
-- =====================================================================================


-- ---------- 1) Cupom reservado e depois desfeito: a linha fica "anulada" e deixa de contar no limite ----------
alter table public.cupons_usos add column if not exists anulado boolean not null default false;

-- ---------- 2) Cálculo do cupom: versão mais recente (contas-clientes), só com "and not cu.anulado" no limite de usos ----------
CREATE OR REPLACE FUNCTION public._cupom_calcular(p_codigo text, p_tel text, p_subtotal numeric, p_tipo text, p_user uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c cupons%rowtype; v_cod text := upper(regexp_replace(btrim(coalesce(p_codigo, '')), '\s+', '', 'g'));
  v_tel text := _so_digitos(p_tel); v_bruto numeric := round(coalesce(p_subtotal, 0), 2); v_desc numeric := 0;
  v_agora timestamp := now() at time zone 'America/Sao_Paulo'; v_hh int; v_hi int; v_hf int; v_usos int; v_usos_cli int; v_fx record;
  v_conta contas_cliente; v_cc cupons_concedidos;
begin
  if v_cod = '' then return _falha('Informe um cupom.'); end if;
  select * into c from cupons where codigo = v_cod and ativa;
  if not found then return _falha('Cupom inválido ou inativo.'); end if;
  if p_user is not null then select * into v_conta from contas_cliente where user_id = p_user and aceite_versao > 0; end if;
  if (c.somente_conta or c.automatico is not null or c.cliente_id is not null) and v_conta.user_id is null then
    return _falha('Este cupom é para quem tem conta. Entre com a sua conta Google para usar.');
  end if;
  if c.cliente_id is not null and v_conta.cliente_id is distinct from c.cliente_id then
    return _falha('Este cupom não está disponível para a sua conta.');
  end if;
  if (c.data_inicio is not null and v_agora::date < c.data_inicio) or (c.data_fim is not null and v_agora::date > c.data_fim) then
    return _falha('Este cupom está fora do período de validade.');
  end if;
  if c.hora_inicio is not null and c.hora_fim is not null then
    v_hh := extract(hour from v_agora)::int * 60 + extract(minute from v_agora)::int;
    v_hi := extract(hour from c.hora_inicio)::int * 60 + extract(minute from c.hora_inicio)::int;
    v_hf := extract(hour from c.hora_fim)::int * 60 + extract(minute from c.hora_fim)::int;
    if v_hi <= v_hf then
      if v_hh < v_hi or v_hh > v_hf then return _falha('Este cupom está fora do período de validade.'); end if;
    else
      if v_hh < v_hi and v_hh > v_hf then return _falha('Este cupom está fora do período de validade.'); end if;
    end if;
  end if;
  if c.automatico is not null then
    select * into v_cc from cupons_concedidos
     where cupom_id = c.id and user_id = p_user and usado_em is null and (valido_ate is null or valido_ate >= v_agora::date)
     order by valido_ate nulls last, criado_em limit 1;
    if not found then return _falha('Você não tem este cupom disponível (ou ele já venceu).'); end if;
  end if;
  select count(*), count(*) filter (where (v_tel <> '' and _so_digitos(cu.telefone) = v_tel) or (p_user is not null and cu.user_id = p_user))
    into v_usos, v_usos_cli from cupons_usos cu where cu.cupom_id = c.id and not cu.anulado and not exists (select 1 from vendas vv where vv.id = cu.venda_id and vv.status = 'Cancelada');
  if c.limite_total > 0 and v_usos >= c.limite_total then return _falha('O limite de utilizações deste cupom foi atingido.'); end if;
  if c.automatico in ('boas_vindas', 'indicacao_indicado') then
    if v_usos_cli > 0 then return _falha('Este cupom já foi usado (uma vez por cliente).'); end if;
  elsif c.automatico is null and c.limite_por_cliente > 0 and v_usos_cli >= c.limite_por_cliente then
    return _falha('Você já atingiu o limite de uso deste cupom.');
  end if;
  if v_bruto < c.valor_minimo then return _falha('Este cupom exige pedido mínimo de R$ ' || replace(_dinheiro(c.valor_minimo), '.', ',') || '.'); end if;
  if c.tipo = 'percentual' then
    if c.valor <= 0 or c.valor > 100 then return _falha('Cupom configurado com percentual inválido.'); end if;
    v_desc := round(v_bruto * c.valor / 100, 2);
  elsif c.tipo = 'fixo' then
    if c.valor <= 0 then return _falha('Cupom configurado com valor inválido.'); end if;
    v_desc := least(v_bruto, round(c.valor, 2));
  elsif c.tipo = 'progressivo' then
    select (x->>'minimo')::numeric mn, (x->>'desconto')::numeric ds into v_fx from jsonb_array_elements(c.faixas) x where (x->>'minimo')::numeric <= v_bruto order by (x->>'minimo')::numeric desc limit 1;
    if v_fx.mn is null then
      select min((x->>'minimo')::numeric) into v_fx.mn from jsonb_array_elements(c.faixas) x;
      return _falha('Este cupom vale a partir de R$ ' || replace(_dinheiro(coalesce(v_fx.mn, 0)), '.', ',') || ' em pedidos.');
    end if;
    v_desc := least(v_bruto, round(v_fx.ds, 2));
  elsif c.tipo = 'frete' then
    v_desc := 0;
  else
    return _falha('Tipo de cupom não suportado.');
  end if;
  v_desc := round(least(v_desc, greatest(0, v_bruto - 0.01)), 2);
  return jsonb_build_object('ok', true, 'cupomId', c.id, 'codigo', c.codigo, 'nome', c.nome, 'tipo', c.tipo, 'desconto', v_desc,
    'freteGratis', (c.frete_gratis or c.tipo = 'frete'), 'acumula', c.acumula,
    'limiteRestante', case when c.limite_total > 0 then greatest(0, c.limite_total - v_usos - 1) else null end);
end $function$
;

-- ---------- 3) Reservar e soltar (estoque, cupom e brinde) ----------
-- _mp_prender: faz a baixa do estoque e marca cupom e brindes como usados, SEM criar a venda.
--   p_forcar = false: o pedido acabou de ser validado, então qualquer falha aqui é erro (desfaz tudo).
--   p_forcar = true: usado quando o operador decide "seguir" com um pagamento já aprovado: aplica o que der, sem barrar por limite/estoque.
create or replace function public._mp_prender(p_reserva uuid, p_forcar boolean default false) returns void
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; rec record; v_cup jsonb; v_uso uuid; v_cc uuid; v_novo jsonb := '[]'::jsonb;
        v_cli uuid; v_fid fidelidade%rowtype; v_bid uuid; v_tipo text; v_prod uuid;
begin
  select * into r from pedidos_reserva where id = p_reserva for update;
  if not found then raise exception 'Reserva não encontrada.'; end if;

  if not r.estoque_reservado then perform _ajustar_estoque(r.itens, 1, null); end if;

  v_cup := r.cupom; v_uso := r.cupom_uso_id;
  if v_cup is not null and v_uso is null then
    insert into cupons_usos (cupom_id, codigo, venda_id, cliente_id, telefone, desconto, frete_gratis, requisicao_id, user_id)
    values ((v_cup->>'cupomId')::uuid, v_cup->>'codigo', null, null, r.telefone, coalesce((v_cup->>'desconto')::numeric, 0),
            coalesce((v_cup->>'freteGratis')::boolean, false), r.requisicao_id, r.user_id)
    returning id into v_uso;
    -- cupom automático da conta (boas-vindas, aniversário, indicação): segura o cupom recebido enquanto a reserva existir
    select id into v_cc from cupons_concedidos
     where cupom_id = (v_cup->>'cupomId')::uuid and user_id = r.user_id and usado_em is null and (valido_ate is null or valido_ate >= _hoje_br())
     order by valido_ate nulls last, criado_em limit 1 for update;
    if v_cc is not null then update cupons_concedidos set usado_em = now(), venda_id = null where id = v_cc; end if;
    v_cup := v_cup || jsonb_build_object('concedidoId', v_cc);
  end if;

  for rec in select value as e from jsonb_array_elements(r.beneficios) loop
    v_tipo := rec.e->>'tipo'; v_prod := _uuid(rec.e->>'produtoId'); v_bid := _uuid(rec.e->>'id');
    if v_tipo = 'Fidelidade' then
      select cc.cliente_id into v_cli from contas_cliente cc where cc.user_id = r.user_id;
      select * into v_fid from fidelidade where cliente_id = v_cli for update;
      if v_fid.id is not null and v_fid.carimbos >= 10 then
        update fidelidade set carimbos = 0, premios_resgatados = premios_resgatados + 1, atualizada_em = now() where cliente_id = v_cli;
        insert into contas_beneficios (user_id, tipo, status, produto_id, venda_id, usado_em) values (r.user_id, 'Fidelidade', 'Usado', v_prod, null, now())
          returning id into v_bid;
      elsif not p_forcar then
        raise exception 'O cartão fidelidade não está completo.';
      else
        v_bid := null;   -- seguiu à força: o item sai a R$ 0, mas o cartão não é mexido
      end if;
    elsif v_tipo = 'Indicação' then
      update contas_beneficios set status = 'Usado', produto_id = v_prod, usado_em = now()
       where id = v_bid and user_id = r.user_id and status = 'Disponível';
      if not found then
        if not p_forcar then raise exception 'O brinde de indicação não está mais disponível.'; end if;
        v_bid := null;
      end if;
    end if;
    v_novo := v_novo || jsonb_build_array(jsonb_build_object('tipo', v_tipo, 'id', v_bid, 'produtoId', v_prod));
  end loop;

  update pedidos_reserva set estoque_reservado = true, cupom = v_cup, cupom_uso_id = v_uso, beneficios = v_novo,
         brindes_reservados = jsonb_array_length(v_novo) > 0, atualizado_em = now()
   where id = r.id;
end $f$;

-- _mp_soltar: devolve estoque, cupom e brindes e marca a reserva com o estado final (expirada ou cancelada). Nada é apagado.
create or replace function public._mp_soltar(p_reserva uuid, p_estado text, p_motivo text) returns void
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; rec record; v_cc uuid; v_cli uuid;
begin
  if p_estado not in ('expirada', 'cancelada') then raise exception 'Estado final inválido.'; end if;
  select * into r from pedidos_reserva where id = p_reserva for update;
  if not found or r.estado not in ('ativa', 'expirada', 'cancelada') then return; end if;   -- reserva já confirmada nunca é solta

  if r.estoque_reservado then perform _ajustar_estoque(r.itens, -1, null); end if;
  if r.cupom_uso_id is not null then update cupons_usos set anulado = true where id = r.cupom_uso_id and venda_id is null; end if;
  v_cc := _uuid(r.cupom->>'concedidoId');
  if v_cc is not null then update cupons_concedidos set usado_em = null, venda_id = null where id = v_cc and venda_id is null; end if;

  for rec in select value as e from jsonb_array_elements(r.beneficios) loop
    if _uuid(rec.e->>'id') is null then continue; end if;
    if rec.e->>'tipo' = 'Indicação' then
      update contas_beneficios set status = 'Disponível', venda_id = null, usado_em = null, produto_id = null
       where id = _uuid(rec.e->>'id') and venda_id is null and status = 'Usado';
    elsif rec.e->>'tipo' = 'Fidelidade' then
      update contas_beneficios set status = 'Anulado' where id = _uuid(rec.e->>'id') and venda_id is null and status = 'Usado';
      if found then
        select cc.cliente_id into v_cli from contas_cliente cc where cc.user_id = r.user_id;
        update fidelidade set carimbos = 10, premios_resgatados = greatest(0, premios_resgatados - 1), atualizada_em = now() where cliente_id = v_cli;
      end if;
    end if;
  end loop;

  update pedidos_reserva set estado = p_estado, motivo_fim = left(coalesce(p_motivo, ''), 200), estoque_reservado = false, brindes_reservados = false,
         cupom_uso_id = null, cupom = case when cupom is null then null else cupom - 'concedidoId' end, atualizado_em = now()
   where id = r.id;
end $f$;

-- ---------- 4) Pedido do cardápio: versão mais recente (contas-brindes) + modo reserva (p_reserva = true). Com false é IDÊNTICO ao de hoje ----------
CREATE OR REPLACE FUNCTION public._criar_pedido_publico(p jsonb, p_mesa_id uuid, p_reserva boolean)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_eh_mesa boolean := p_mesa_id is not null; v_mesa mesas%rowtype;
  v_nome text := _texto_publico(p->>'clienteNome', 80);
  v_tel text := case when p_mesa_id is not null then '' else _texto_publico(p->>'clienteTelefone', 20) end;
  v_dig text := case when p_mesa_id is not null then '' else _so_digitos(p->>'clienteTelefone') end;
  v_obs_troco text := _texto_publico(p->>'observacaoTroco', 200);
  v_de jsonb := case when jsonb_typeof(p->'dadosEntrega') = 'object' then p->'dadosEntrega' else '{}'::jsonb end;
  v_end text := _texto_publico(v_de->>'endereco', 200); v_comp text := _texto_publico(v_de->>'complemento', 100); v_ref text := _texto_publico(v_de->>'referencia', 150);
  v_obs_ent text := _texto_publico(coalesce(nullif(p->>'observacoes', ''), v_de->>'observacoes'), 300);
  v_itens jsonb := p->'itens'; v_tipo_in text := p->>'tipoEntrega'; v_ip text := _ip_cliente();
  v_req text := nullif(left(btrim(coalesce(p->>'requisicaoId', '')), 80), '');
  v_forma formas_pagamento%rowtype; v_caixa uuid; v_tipo venda_tipo; v_ja record; v_prod produtos%rowtype; v_comb combos%rowtype;
  it record; r record; v_prod_id uuid; v_comb_id uuid; v_qtd numeric; v_preco numeric; v_custo_u numeric; v_nome_item text; v_extra numeric; v_n_ad int; v_n_ok int;
  v_ads text; v_obs_item text; v_ads_ids jsonb; v_itens_ok jsonb := '[]'::jsonb; v_orig numeric := 0; v_custo numeric := 0;
  v_cod text := ''; v_cup jsonb; v_desc numeric := 0; v_frete boolean := false; v_taxa numeric := 0; v_pad numeric; v_total numeric;
  v_venda uuid := gen_random_uuid(); v_numero int; v_cli uuid; v_chave text; v_obs_final text; v_bloqueia boolean; v_forma_nome text; v_acr numeric := 0; v_bloq text; v_user uuid := (select cc.user_id from contas_cliente cc where cc.user_id = auth.uid() and cc.aceite_versao > 0);
  v_ben jsonb := case when jsonb_typeof(p->'beneficios') = 'array' then p->'beneficios' else '[]'::jsonb end;
  b record; v_bens jsonb := '[]'::jsonb; v_bc contas_cliente; v_fid fidelidade%rowtype; v_bid uuid; v_pb produtos%rowtype; v_btipo text;
  v_res uuid; v_min int; v_cfg integracoes_config%rowtype; v_ja_res record;
begin
  -- Mercado Pago (p_reserva = true): valida tudo igual ao pedido normal, mas em vez de criar a venda guarda uma RESERVA até o pagamento ser aprovado
  if p_reserva then
    if p_mesa_id is not null then return _falha('Mesas e balcão não pagam pelo site.'); end if;
    if v_user is null then return _falha('Entre com a sua conta para pagar pelo site.'); end if;
    if v_req is null then return _falha('Não foi possível identificar esta tentativa. Atualize a página e tente de novo.'); end if;
    if coalesce((public.api_mp_config_publica('{}'::jsonb)->>'ligado')::boolean, false) is not true then
      return _falha('O pagamento pelo site não está disponível agora. Escolha pagar na entrega.');
    end if;
    perform pg_advisory_xact_lock(hashtext('reserva:' || v_req));
    select id, estado, valor_total, expira_em into v_ja_res from pedidos_reserva where requisicao_id = v_req;
    if found then
      return jsonb_build_object('ok', true, 'duplicado', true, 'reservaId', v_ja_res.id, 'estado', v_ja_res.estado,
        'valorTotal', v_ja_res.valor_total, 'expiraEm', v_ja_res.expira_em, 'message', 'Pedido já recebido — envio repetido ignorado.');
    end if;
  end if;

  -- repetição do mesmo envio (duplo toque, nova tentativa): devolve o pedido já criado, sem criar outro
  if v_req is not null and not p_reserva then
    perform pg_advisory_xact_lock(hashtext('venda:' || v_req));
    select id, numero_pedido, valor_total into v_ja from vendas where requisicao_id = v_req;
    if found then
      return jsonb_build_object('ok', true, 'duplicado', true, 'id', v_ja.id, 'numero', v_ja.numero_pedido, 'valorTotal', v_ja.valor_total, 'message', 'Pedido já recebido — envio repetido ignorado.');
    end if;
  end if;

  if jsonb_typeof(v_itens) <> 'array' then return _falha('Carrinho vazio.'); end if;
  if jsonb_array_length(v_itens) = 0 and (p_mesa_id is not null or jsonb_array_length(v_ben) = 0) then return _falha('Carrinho vazio.'); end if;
  if jsonb_array_length(v_itens) > 40 then return _falha('Carrinho grande demais.'); end if;
  if v_eh_mesa then
    if v_nome = '' then return _falha('Informe o seu nome.'); end if;
    v_chave := 'pedmesa_' || p_mesa_id::text;
  else
    if v_nome = '' or v_dig = '' then return _falha('Informe nome e telefone.'); end if;
    if length(v_dig) < 10 or length(v_dig) > 13 then return _falha('Informe um telefone válido com DDD.'); end if;
    v_chave := 'pedcard_' || v_dig;
  end if;
  if _excedeu('pedcard_global', 150) then return _falha('Estamos com muitos pedidos no momento. Tente novamente em alguns minutos ou ligue para o restaurante.'); end if;
  if _excedeu('pedcard_ip_' || v_ip, 40) then return _falha('Muitos pedidos em sequência deste local. Aguarde alguns minutos.'); end if;
  if _excedeu(v_chave, case when v_eh_mesa then 8 else 5 end) then
    return _falha(case when v_eh_mesa then 'Muitos pedidos em sequência nesta mesa. Chame o garçom.' else 'Muitos pedidos em sequência. Aguarde alguns minutos.' end);
  end if;

  -- cardápio fechado à mão ou em período programado (pedido de mesa, feito dentro do restaurante, não é bloqueado)
  if not v_eh_mesa then
    v_bloq := _cardapio_bloqueio();
    if v_bloq is not null then return _falha(v_bloq); end if;
  end if;
  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;
  if v_caixa is null then return _falha('Estamos fechados no momento. Tente novamente mais tarde.'); end if;

  if v_eh_mesa then
    select * into v_mesa from mesas where id = p_mesa_id for update;
    if not found then return _falha('Mesa não encontrada.'); end if;
    if v_mesa.status::text not in ('Livre', 'Ocupada') then
      return _falha(case when v_mesa.status::text = 'Aguardando fechamento' then 'A conta desta mesa já foi pedida. Chame o garçom para novos pedidos.' else 'Esta mesa não está disponível para pedidos pelo celular. Chame o garçom.' end);
    end if;
    v_tipo := 'Mesa';
    -- mesa: o cliente não escolhe a forma; vale a primeira forma do cardápio só para o preço (o recebimento é feito no fechamento da conta)
    select * into v_forma from formas_pagamento where ativa and visivel_cardapio order by ordem limit 1;
    v_forma_nome := 'A Receber (Mesa)';
  else
    v_tipo := (case when v_tipo_in = 'Entrega' then 'Entrega' else 'Retirada' end)::venda_tipo;
    if v_tipo = 'Entrega' and v_end = '' then return _falha('Informe o endereço de entrega.'); end if;
    if v_tipo = 'Entrega' then
      declare v_num text := _texto_publico(v_de->>'numero', 20); v_cid text := _texto_publico(v_de->>'cidade', 80);
              v_cid_loc text := _texto_publico(v_de->>'cidadeLocalizacao', 80); v_lista jsonb; v_nomes text;
      begin
        if v_de ? 'numero' and v_num = '' then return _falha('Informe o número da casa (ou "s/n").'); end if;
        if v_de ? 'cidade' and v_cid = '' then return _falha('Informe a cidade da entrega.'); end if;
        if v_num <> '' then v_end := left(v_end || ', nº ' || v_num, 200); end if;
        if v_cid <> '' then v_end := left(v_end || ' — ' || v_cid, 200); end if;
      end;
    end if;
    select * into v_forma from formas_pagamento where id = _uuid(p->>'formaPagamentoId') and ativa and visivel_cardapio;
    v_forma_nome := v_forma.nome;
  end if;
  if v_forma.id is null then return _falha('Forma de pagamento inválida.'); end if;
  if p_reserva and not (v_forma.aceita_online and v_forma.tipo_online is not null) then return _falha('Esta forma de pagamento não é aceita pelo site.'); end if;

  -- itens: tudo vem do cadastro (produto/combo ativo, preço da forma escolhida, adicionais ativos e vinculados)
  for it in select value as e from jsonb_array_elements(v_itens) loop
    v_qtd := _num(it.e->>'quantidade');
    if v_qtd <= 0 then continue; end if;
    if v_qtd > 50 or v_qtd <> floor(v_qtd) then return _falha('Quantidade inválida no carrinho.'); end if;
    v_prod_id := _uuid(it.e->>'produtoId'); v_comb_id := _uuid(it.e->>'comboId');
    if (v_prod_id is null) = (v_comb_id is null) then return _falha('Item inválido no carrinho.'); end if;
    if jsonb_typeof(it.e->'adicionaisIds') = 'array' and jsonb_array_length(it.e->'adicionaisIds') > 20 then return _falha('Adicionais demais em um item.'); end if;
    if v_prod_id is not null then
      select * into v_prod from produtos where id = v_prod_id and ativo;
      if not found then return _falha('Um dos produtos não está mais disponível.'); end if;
      v_nome_item := v_prod.nome;
      select preco, custo into v_preco, v_custo_u from produto_precos where produto_id = v_prod_id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_nome_item || '" não tem preço configurado para essa forma de pagamento.'); end if;
    else
      select * into v_comb from combos where id = v_comb_id and ativo;
      if not found then return _falha('Um dos combos não está mais disponível.'); end if;
      if exists (select 1 from combo_itens ci join produtos pr on pr.id = ci.produto_id where ci.combo_id = v_comb_id and not pr.ativo) then
        return _falha('O combo "' || v_comb.nome || '" está temporariamente indisponível.');
      end if;
      v_nome_item := v_comb.nome;
      select preco, custo into v_preco, v_custo_u from combo_precos where combo_id = v_comb_id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_nome_item || '" não tem preço configurado para essa forma de pagamento.'); end if;
    end if;
    select count(*), coalesce(sum(a.preco), 0),
           count(a.id) filter (where a.ativo and ((v_prod_id is not null and exists (select 1 from produto_adicionais pa where pa.produto_id = v_prod_id and pa.adicional_id = a.id)) or (v_comb_id is not null and exists (select 1 from combo_itens ci join produto_adicionais pa on pa.produto_id = ci.produto_id where ci.combo_id = v_comb_id and pa.adicional_id = a.id)))),
           coalesce(string_agg(' + ' || a.nome, '' order by s.ord) filter (where a.id is not null), ''),
           coalesce(jsonb_agg(a.id order by s.ord) filter (where a.id is not null), '[]'::jsonb)
      into v_n_ad, v_extra, v_n_ok, v_ads, v_ads_ids
      from jsonb_array_elements_text(case when jsonb_typeof(it.e->'adicionaisIds') = 'array' then it.e->'adicionaisIds' else '[]'::jsonb end) with ordinality as s(x, ord)
      left join adicionais a on a.id = _uuid(s.x);
    if v_n_ad <> v_n_ok then return _falha('Um adicional escolhido para "' || v_nome_item || '" não está disponível.'); end if;
    v_obs_item := _texto_publico(it.e->>'observacao', 100);
    v_itens_ok := v_itens_ok || jsonb_build_array(jsonb_build_object('produtoId', v_prod_id, 'comboId', v_comb_id,
      'descricao', v_nome_item || v_ads || case when v_obs_item <> '' then ' — Obs: ' || v_obs_item else '' end,
      'quantidade', v_qtd, 'valorUnitario', v_preco + v_extra, 'custoUnitario', v_custo_u, 'adicionaisIds', v_ads_ids));
    v_orig := v_orig + round(v_qtd * (v_preco + v_extra), 2); v_custo := v_custo + v_qtd * v_custo_u;
  end loop;
  if jsonb_array_length(v_itens_ok) = 0 and jsonb_array_length(v_ben) = 0 then return _falha('Carrinho vazio.'); end if;
  -- brindes da conta (cartão fidelidade e indicação): entram como item de R$ 0, com custo e baixa no estoque
  if jsonb_array_length(v_ben) > 0 then
    if v_eh_mesa or v_user is null then return _falha('Entre com a sua conta para resgatar o brinde.'); end if;
    if jsonb_array_length(v_ben) > 5 then return _falha('Brindes demais no mesmo pedido.'); end if;
    select * into v_bc from contas_cliente where user_id = v_user for update;
    for b in select value as e from jsonb_array_elements(v_ben) loop
      v_btipo := b.e->>'tipo';
      select * into v_pb from produtos where id = _uuid(b.e->>'produtoId') and ativo;
      if not found then return _falha('O brinde escolhido não está mais disponível.'); end if;
      select custo into v_custo_u from produto_precos where produto_id = v_pb.id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_pb.nome || '" não está disponível para essa forma de pagamento.'); end if;
      v_bid := null;
      if v_btipo = 'Fidelidade' then
        if not v_pb.premio_fidelidade then return _falha('"' || v_pb.nome || '" não é um prêmio do cartão fidelidade.'); end if;
        if v_bc.cliente_id is null then return _falha('Seu cartão fidelidade ainda não está ligado à sua conta. Ele liga depois do seu primeiro pedido concluído.'); end if;
        if exists (select 1 from jsonb_array_elements(v_bens) x where x->>'tipo' = 'Fidelidade') then return _falha('Só dá para resgatar 1 prêmio do cartão fidelidade por pedido.'); end if;
        select * into v_fid from fidelidade where cliente_id = v_bc.cliente_id for update;
        if v_fid.id is null or v_fid.carimbos < 10 then return _falha('Seu cartão fidelidade ainda não completou as 10 marcas.'); end if;
      elsif v_btipo = 'Indicação' then
        if not v_pb.premio_indicacao then return _falha('"' || v_pb.nome || '" não é um prêmio de indicação.'); end if;
        select id into v_bid from contas_beneficios where id = _uuid(b.e->>'id') and user_id = v_user and tipo = 'Indicação' and status = 'Disponível' for update;
        if v_bid is null or exists (select 1 from jsonb_array_elements(v_bens) x where x->>'id' = v_bid::text) then return _falha('Este brinde de indicação não está mais disponível.'); end if;
      else
        return _falha('Brinde inválido.');
      end if;
      v_bens := v_bens || jsonb_build_array(jsonb_build_object('tipo', v_btipo, 'id', v_bid, 'produtoId', v_pb.id));
      v_itens_ok := v_itens_ok || jsonb_build_array(jsonb_build_object('produtoId', v_pb.id, 'comboId', null,
        'descricao', '🎁 Brinde ' || case when v_btipo = 'Fidelidade' then 'fidelidade' else 'indicação' end || ' — ' || v_pb.nome,
        'quantidade', 1, 'valorUnitario', 0, 'custoUnitario', v_custo_u, 'adicionaisIds', '[]'::jsonb));
      v_custo := v_custo + v_custo_u;
    end loop;
  end if;
  v_orig := round(v_orig, 2); v_custo := round(v_custo, 2);

  select coalesce((select (valor #>> '{}') = 'true' from sistema where chave = 'BLOQUEAR_ESTOQUE_NEGATIVO'), false) into v_bloqueia;
  if v_bloqueia then
    for r in select c.ingrediente_id, c.qtd, e.quantidade from _consumo(v_itens_ok) c join estoque e on e.id = c.ingrediente_id loop
      if r.quantidade + 0.000000001 < r.qtd then return _falha('Um dos itens do pedido acabou. Escolha outro item ou fale com o restaurante.'); end if;
    end loop;
  end if;

  -- cupom (só no cardápio comum; travado por código para dois pedidos simultâneos não estourarem o limite)
  if not v_eh_mesa then
    v_cod := upper(regexp_replace(btrim(coalesce(p->>'codigoCupom', '')), '\s+', '', 'g'));
    if v_cod <> '' then
      if v_orig <= 0 then return _falha('O cupom vale para pedidos com pelo menos um item pago.'); end if;
      perform pg_advisory_xact_lock(hashtext('cupom:' || v_cod));
      v_cup := _cupom_calcular(v_cod, v_tel, v_orig, v_tipo::text, v_user);
      if coalesce(v_cup->>'ok', '') <> 'true' then return v_cup; end if;
      v_desc := (v_cup->>'desconto')::numeric; v_frete := (v_cup->>'freteGratis')::boolean;
    end if;
  end if;

  if v_tipo = 'Entrega' and not v_frete then
    select coalesce(_num(valor #>> '{}'), 0) into v_pad from sistema where chave = 'TaxaEntregaPadrao';
    v_taxa := coalesce(v_pad, 0);
  end if;
  v_total := case when v_orig <= 0 and jsonb_array_length(v_bens) > 0 then round(v_taxa, 2) else greatest(0.01, round(v_orig - v_desc + v_taxa, 2)) end;
  -- acréscimo da forma de pagamento escolhida (mesa: o acréscimo entra no fechamento da conta)
  if not v_eh_mesa and v_orig > 0 then v_acr := _acrescimo_forma(v_forma, greatest(0.01, v_total - v_taxa)); v_total := round(v_total + v_acr, 2); end if;
  v_obs_final := coalesce(concat_ws(' — ', nullif(v_obs_ent, ''), nullif(v_obs_troco, '')), '');

  -- Mercado Pago: não cria a venda agora. Guarda a reserva (e já segura estoque, cupom e brinde) até o pagamento ser aprovado.
  if p_reserva then
    if v_total <= 0 then return _falha('Este pedido não tem valor a pagar pelo site.'); end if;
    select * into v_cfg from integracoes_config where provedor = 'mercadopago';
    v_min := case when coalesce(v_cfg.config->>'pixValidadeMin', '') ~ '^[0-9]{1,3}$' then least(120, greatest(5, (v_cfg.config->>'pixValidadeMin')::int)) else 15 end;
    insert into pedidos_reserva (requisicao_id, user_id, cliente_nome, telefone, tipo_entrega, forma_pagamento_id, dados_entrega, observacoes,
                                 itens, beneficios, cupom, valor_original, valor_desconto, taxa_entrega, acrescimo_forma, valor_total, custo_total, expira_em)
    values (v_req, v_user, v_nome, v_tel, v_tipo::text, v_forma.id,
            jsonb_build_object('endereco', case when v_tipo = 'Entrega' then v_end else '' end, 'complemento', case when v_tipo = 'Entrega' then v_comp else '' end,
                               'referencia', case when v_tipo = 'Entrega' then v_ref else '' end),
            v_obs_final, v_itens_ok, v_bens, case when v_cod <> '' then v_cup else null end, v_orig, v_desc, v_taxa, v_acr, v_total, v_custo,
            now() + make_interval(mins => v_min))
    returning id into v_res;
    perform _mp_prender(v_res, false);
    perform _registrar_falha(v_chave, 600); perform _registrar_falha('pedcard_global', 300); perform _registrar_falha('pedcard_ip_' || v_ip, 600);
    perform _auditar_publico('Pedido reservado para pagamento pelo site',
      'Total R$ ' || _dinheiro(v_total) || case when jsonb_array_length(v_bens) > 0 then ' | Brindes ' || jsonb_array_length(v_bens) else '' end || case when v_cod <> '' then ' | Cupom ' || (v_cup->>'codigo') else '' end, v_tel);
    return jsonb_build_object('ok', true, 'reservaId', v_res, 'metodo', v_forma.tipo_online, 'valorTotal', v_total, 'valorOriginal', v_orig,
      'acrescimo', v_acr, 'valorDesconto', v_desc, 'taxaEntrega', v_taxa, 'minutos', v_min, 'expiraEm', now() + make_interval(mins => v_min));
  end if;

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido,
                      endereco, complemento, referencia, observacoes_entrega, status_pagamento, valor_original, valor_desconto,
                      desconto_detalhe, origem, mesa_id, taxa_entrega, caixa_id, requisicao_id, acrescimo_forma)
  values (v_venda, v_nome, v_tel, v_forma_nome, v_total, v_custo, 'Confirmada', v_tipo, 'Recebido',
          case when v_tipo = 'Entrega' then v_end else '' end, case when v_tipo = 'Entrega' then v_comp else '' end, case when v_tipo = 'Entrega' then v_ref else '' end,
          v_obs_final, (case when v_total <= 0 then 'Pago' else 'A Receber' end)::status_pagamento, v_orig, v_desc, case when v_cod <> '' then 'Cupom ' || (v_cup->>'codigo') else '' end, 'Cardápio',
          case when v_eh_mesa then p_mesa_id else null end, v_taxa, v_caixa, v_req, v_acr)
  returning numero_pedido into v_numero;

  insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
  select v_venda, _uuid(e->>'produtoId'), _uuid(e->>'comboId'), e->>'descricao', _num(e->>'quantidade', 1)::int, _num(e->>'valorUnitario'), _num(e->>'custoUnitario'),
         round(_num(e->>'quantidade', 1) * _num(e->>'valorUnitario'), 2),
         coalesce((select array_agg(_uuid(x)) filter (where _uuid(x) is not null) from jsonb_array_elements_text(e->'adicionaisIds') x), '{}')
  from jsonb_array_elements(v_itens_ok) e;

  insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo)
  values (v_venda, v_forma_nome, v_total, case when v_eh_mesa or v_total <= 0 then 0 else round(v_total * v_forma.taxa_percentual / 100 + v_forma.taxa_fixa, 2) end, v_acr);
  if v_total <= 0 then update vendas set recebido_em = now() where id = v_venda; end if;

  if v_eh_mesa and v_mesa.status::text = 'Livre' then update mesas set status = 'Ocupada' where id = p_mesa_id; end if;
  perform _ajustar_estoque(v_itens_ok, 1, v_venda);
  if v_tel <> '' then v_cli := _upsert_cliente(v_tel, v_nome); end if;
  if v_user is not null and not v_eh_mesa then insert into contas_pedidos (venda_id, user_id) values (v_venda, v_user) on conflict do nothing; end if;
  if jsonb_array_length(v_bens) > 0 then
    for b in select value as e from jsonb_array_elements(v_bens) loop
      if b.e->>'tipo' = 'Fidelidade' then
        update fidelidade set carimbos = 0, premios_resgatados = premios_resgatados + 1, atualizada_em = now() where cliente_id = v_bc.cliente_id;
        insert into contas_beneficios (user_id, tipo, status, produto_id, venda_id, usado_em) values (v_user, 'Fidelidade', 'Usado', _uuid(b.e->>'produtoId'), v_venda, now());
      else
        update contas_beneficios set status = 'Usado', produto_id = _uuid(b.e->>'produtoId'), venda_id = v_venda, usado_em = now() where id = _uuid(b.e->>'id');
      end if;
    end loop;
  end if;
  if v_cod <> '' then
    insert into cupons_usos (cupom_id, codigo, venda_id, cliente_id, telefone, desconto, frete_gratis, requisicao_id, user_id)
    values ((v_cup->>'cupomId')::uuid, v_cup->>'codigo', v_venda, v_cli, v_tel, v_desc, v_frete, v_req, v_user);
    perform _conta_cupom_usado(v_user, (v_cup->>'cupomId')::uuid, v_venda);
  end if;
  perform _registrar_falha(v_chave, 600); perform _registrar_falha('pedcard_global', 300); perform _registrar_falha('pedcard_ip_' || v_ip, 600);
  perform _auditar_publico(case when v_eh_mesa then 'Pedido recebido pelo cliente na mesa ' || v_mesa.numero else 'Pedido recebido pelo Cardápio' end,
    'Total R$ ' || _dinheiro(v_total) || case when jsonb_array_length(v_bens) > 0 then ' | Brindes ' || jsonb_array_length(v_bens) else '' end || case when v_cod <> '' then ' | Cupom ' || (v_cup->>'codigo') else '' end, case when v_eh_mesa then v_nome else v_tel end);

  return jsonb_build_object('ok', true, 'message', 'Pedido enviado! Nº ' || v_numero || '. Total: R$ ' || _dinheiro(v_total) || '.',
    'id', v_venda, 'numero', v_numero, 'valorTotal', v_total, 'valorOriginal', v_orig, 'acrescimo', v_acr, 'valorDesconto', v_desc,
    'cupom', case when v_cod <> '' then v_cup->>'codigo' else '' end, 'freteGratis', v_frete);
end $function$
;

-- a função de 2 argumentos (usada por api_criar_pedido_cardapio e api_criar_pedido_mesa) continua igual para quem chama: só repassa com p_reserva = false
create or replace function public._criar_pedido_publico(p jsonb, p_mesa_id uuid) returns jsonb
 language sql security definer set search_path to 'public' as $f$ select public._criar_pedido_publico(p, p_mesa_id, false) $f$;

-- ---------- 5) Funções que o cardápio chama (cliente logado) ----------
-- Valida o pedido e RESERVA (não cria venda). Devolve reservaId, valor e quando a reserva vence. Depois a página chama a função mp-criar.
create or replace function public.api_mp_reservar(p jsonb) returns jsonb
 language sql security definer set search_path to 'public' as $f$ select public._criar_pedido_publico(p, null, true) $f$;

-- Situação do pagamento, para a tela do cliente (Pix aguardando, aprovado, recusado...). A tela consulta esta função de tempos em tempos.
create or replace function public.api_mp_status_pagamento(p jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; g pagamentos_online%rowtype; v_est text;
begin
  if auth.uid() is null then return _negado(); end if;
  select * into r from pedidos_reserva where id = _uuid(p->>'reservaId') and user_id = auth.uid();
  if not found then return _falha('Pedido não encontrado.'); end if;
  select * into g from pagamentos_online where reserva_id = r.id order by criado_em desc limit 1;
  v_est := case
    when r.estado = 'confirmada' then 'aprovado'
    when g.id is not null and (g.decisao = 'reembolsar' or g.status in ('reembolso_parcial', 'reembolsado')) then 'reembolso'
    when g.id is not null and g.status = 'aprovado' then 'conferindo'
    when r.estado = 'expirada' then 'expirado'
    when r.estado = 'cancelada' then 'cancelado'
    when g.id is not null and g.status = 'recusado' then 'recusado'
    when g.id is not null and g.status = 'erro' then 'erro'
    else 'aguardando' end;
  return jsonb_build_object('ok', true, 'estado', v_est, 'reservaId', r.id, 'metodo', g.metodo, 'valorTotal', r.valor_total, 'expiraEm', r.expira_em,
    'vendaId', r.venda_id, 'numero', (select v.numero_pedido from vendas v where v.id = r.venda_id), 'detalhe', coalesce(g.status_detalhe, ''),
    'pixCopiaCola', case when v_est = 'aguardando' then g.pix_copia_cola else null end, 'pixQrBase64', case when v_est = 'aguardando' then g.pix_qr_base64 else null end,
    'pixExpiraEm', case when v_est = 'aguardando' then g.pix_expira_em else null end);
end $f$;

-- O cliente desistiu (fechou a tela do Pix, voltou ao carrinho): solta estoque, cupom e brinde na hora.
create or replace function public.api_mp_cancelar_reserva(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype;
begin
  if auth.uid() is null then return _negado(); end if;
  select * into r from pedidos_reserva where id = _uuid(p->>'reservaId') and user_id = auth.uid() for update;
  if not found then return _falha('Pedido não encontrado.'); end if;
  if r.estado <> 'ativa' then return jsonb_build_object('ok', true, 'estado', r.estado); end if;
  if exists (select 1 from pagamentos_online g where g.reserva_id = r.id and (g.status = 'aprovado' or (g.decisao_pendente and g.decisao is null))) then
    return _falha('O pagamento deste pedido já foi aprovado. Fale com o restaurante.');
  end if;
  update pagamentos_online set status = 'cancelado', status_detalhe = 'cancelado pelo cliente', atualizado_em = now() where reserva_id = r.id and status = 'aguardando';
  perform _mp_soltar(r.id, 'cancelada', 'Cancelado pelo cliente');
  return jsonb_build_object('ok', true, 'estado', 'cancelada');
end $f$;

-- ---------- 6) Confirmar o pagamento: a venda nasce PAGA ----------
-- Cria a venda a partir da reserva, no mesmo formato do pedido do cardápio (itens, pagamento, conta, cupom, brindes, fidelidade).
-- Estoque, cupom e brinde já foram segurados na reserva: aqui só se liga tudo à venda.
create or replace function public._mp_criar_venda(p_reserva uuid, p_pag uuid) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; f formas_pagamento%rowtype; v_caixa uuid; v_venda uuid := gen_random_uuid(); v_numero int; v_cli uuid;
        v_cod text; rec record; v_tipo venda_tipo; v_de jsonb; v_nome text; v_cc uuid;
begin
  select * into r from pedidos_reserva where id = p_reserva for update;
  if not found then raise exception 'Reserva não encontrada.'; end if;
  select * into f from formas_pagamento where id = r.forma_pagamento_id;
  v_nome := coalesce(f.nome, 'Pagamento online');
  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;
  if v_caixa is null then raise exception 'Caixa fechado.'; end if;
  v_tipo := (case when r.tipo_entrega = 'Entrega' then 'Entrega' else 'Retirada' end)::venda_tipo;
  v_de := coalesce(r.dados_entrega, '{}'::jsonb);
  v_cod := coalesce(r.cupom->>'codigo', '');

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido,
                      endereco, complemento, referencia, observacoes_entrega, status_pagamento, recebido_em, valor_original, valor_desconto,
                      desconto_detalhe, origem, mesa_id, taxa_entrega, caixa_id, requisicao_id, acrescimo_forma)
  values (v_venda, r.cliente_nome, r.telefone, v_nome, r.valor_total, r.custo_total, 'Confirmada', v_tipo, 'Recebido',
          case when v_tipo = 'Entrega' then coalesce(v_de->>'endereco', '') else '' end, case when v_tipo = 'Entrega' then coalesce(v_de->>'complemento', '') else '' end,
          case when v_tipo = 'Entrega' then coalesce(v_de->>'referencia', '') else '' end, r.observacoes, 'Pago', now(), r.valor_original, r.valor_desconto,
          case when v_cod <> '' then 'Cupom ' || v_cod else '' end, 'Cardápio', null, r.taxa_entrega, v_caixa, r.requisicao_id, r.acrescimo_forma)
  returning numero_pedido into v_numero;

  insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
  select v_venda, _uuid(e->>'produtoId'), _uuid(e->>'comboId'), e->>'descricao', _num(e->>'quantidade', 1)::int, _num(e->>'valorUnitario'), _num(e->>'custoUnitario'),
         round(_num(e->>'quantidade', 1) * _num(e->>'valorUnitario'), 2),
         coalesce((select array_agg(_uuid(x)) filter (where _uuid(x) is not null) from jsonb_array_elements_text(e->'adicionaisIds') x), '{}')
  from jsonb_array_elements(r.itens) e;

  insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo)
  values (v_venda, v_nome, r.valor_total, round(r.valor_total * coalesce(f.taxa_percentual, 0) / 100 + coalesce(f.taxa_fixa, 0), 2), r.acrescimo_forma);

  if r.telefone <> '' then
    v_cli := _upsert_cliente(r.telefone, r.cliente_nome);
    perform _carimbar_fidelidade(r.telefone, r.cliente_nome);   -- como no recebimento manual: pedido pago = marca no cartão fidelidade
  end if;
  insert into contas_pedidos (venda_id, user_id) values (v_venda, r.user_id) on conflict do nothing;

  if r.cupom_uso_id is not null then update cupons_usos set venda_id = v_venda, cliente_id = v_cli where id = r.cupom_uso_id; end if;
  v_cc := _uuid(r.cupom->>'concedidoId');
  if v_cc is not null then update cupons_concedidos set venda_id = v_venda where id = v_cc; end if;
  for rec in select value as e from jsonb_array_elements(r.beneficios) loop
    if _uuid(rec.e->>'id') is not null then update contas_beneficios set venda_id = v_venda where id = _uuid(rec.e->>'id'); end if;
  end loop;

  update pedidos_reserva set estado = 'confirmada', venda_id = v_venda, atualizado_em = now() where id = r.id;
  update pagamentos_online set venda_id = v_venda, atualizado_em = now() where id = p_pag;
  perform _auditar_publico('Pedido pago pelo site (Mercado Pago)', 'Nº ' || v_numero || ' | Total R$ ' || _dinheiro(r.valor_total), r.telefone);
  return jsonb_build_object('vendaId', v_venda, 'numero', v_numero);
end $f$;

-- Marca o pagamento como "Pagamento a decidir": o dinheiro entrou, mas o pedido NÃO vai para a cozinha até o operador de caixa ou o Admin escolher.
create or replace function public._mp_marcar_decidir(p_pag uuid, p_motivo text) returns void
 language plpgsql security definer set search_path to 'public' as $f$
begin
  update pagamentos_online set decisao_pendente = true, decisao = null, decisao_motivo = left(coalesce(p_motivo, ''), 200), atualizado_em = now() where id = p_pag;
  perform _auditar('Pagamento a decidir', 'Pagamento ' || p_pag || ' | ' || coalesce(p_motivo, ''), '');
end $f$;

-- Pagamento aprovado pelo Mercado Pago. Reserva ativa e restaurante aberto: cria a venda Paga.
-- Reserva vencida/cancelada, caixa ou cardápio fechado, pagamento em duplicidade: nunca reembolsa sozinho, marca "Pagamento a decidir".
-- Ordem de trava: sempre reserva primeiro, depois pagamento (evita travar um no outro).
create or replace function public._mp_confirmar_pagamento(p_pag uuid) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare g pagamentos_online%rowtype; r pedidos_reserva%rowtype; v_motivo text; v_v jsonb;
begin
  select * into g from pagamentos_online where id = p_pag;
  if not found then return _falha('Pagamento não encontrado.'); end if;
  select * into r from pedidos_reserva where id = g.reserva_id for update;
  select * into g from pagamentos_online where id = p_pag for update;
  if g.status in ('reembolso_parcial', 'reembolsado') or g.venda_id is not null or g.decisao_pendente or g.decisao is not null then
    return jsonb_build_object('ok', true, 'duplicado', true);
  end if;
  update pagamentos_online set status = 'aprovado', aprovado_em = coalesce(aprovado_em, now()), erro = '', atualizado_em = now() where id = g.id;

  if r.estado = 'confirmada' then v_motivo := 'Já existe um pedido pago nesta reserva (pagamento em duplicidade)';
  elsif r.estado = 'expirada' then v_motivo := case when g.metodo = 'pix' then 'Pix pago depois de vencer' else 'Pagamento aprovado depois de a reserva vencer' end;
  elsif r.estado = 'cancelada' then v_motivo := 'Pagamento aprovado depois de a reserva ser cancelada';
  elsif not exists (select 1 from caixa_sessoes where status = 'Aberto') then v_motivo := 'Caixa fechado quando o pagamento foi aprovado';
  elsif _cardapio_bloqueio() is not null then v_motivo := 'Cardápio fechado quando o pagamento foi aprovado';
  end if;
  if v_motivo is not null then
    perform _mp_marcar_decidir(g.id, v_motivo);
    return jsonb_build_object('ok', true, 'decidir', true, 'motivo', v_motivo);
  end if;

  v_v := _mp_criar_venda(r.id, g.id);
  return jsonb_build_object('ok', true, 'vendaId', v_v->>'vendaId', 'numero', (v_v->>'numero')::int);
end $f$;

-- Operador de caixa ou Admin decide sobre um "Pagamento a decidir": seguir com o pedido ou reembolsar.
-- "reembolsar" só registra a decisão e solta a reserva; quem devolve o dinheiro é a função mp-reembolsar (Etapa 3), que depois avisa o banco.
create or replace function public.api_mp_decidir_pagamento(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare g pagamentos_online%rowtype; r pedidos_reserva%rowtype; v_dec text := lower(btrim(coalesce(p->>'decisao', ''))); v_v jsonb; v_id uuid := _uuid(p->>'pagamentoId');
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  if v_dec not in ('seguir', 'reembolsar') then return _falha('Escolha entre seguir com o pedido ou reembolsar.'); end if;
  select * into g from pagamentos_online where id = v_id;
  if not found then return _falha('Pagamento não encontrado.'); end if;
  select * into r from pedidos_reserva where id = g.reserva_id for update;
  select * into g from pagamentos_online where id = v_id for update;
  if not g.decisao_pendente or g.decisao is not null then return _falha('Este pagamento não está aguardando decisão.'); end if;
  if g.status <> 'aprovado' then return _falha('Só dá para decidir sobre um pagamento aprovado.'); end if;

  if v_dec = 'seguir' then
    if r.estado = 'confirmada' then return _falha('Já existe um pedido pago nesta reserva. Aqui só dá para reembolsar.'); end if;
    if not exists (select 1 from caixa_sessoes where status = 'Aberto') then return _falha('Abra o caixa para seguir com este pedido.'); end if;
    if r.estado <> 'ativa' then perform _mp_prender(r.id, true); end if;   -- reserva já foi solta: segura estoque, cupom e brinde de novo, sem barrar
    update pagamentos_online set decisao = 'seguir', decisao_pendente = false, decidido_por = auth.uid(), decidido_em = now(), atualizado_em = now() where id = g.id;
    v_v := _mp_criar_venda(r.id, g.id);
    perform _auditar('Pagamento online: seguir com o pedido', 'Pagamento ' || g.id || ' | Pedido Nº ' || (v_v->>'numero'), '');
    return jsonb_build_object('ok', true, 'decisao', 'seguir', 'vendaId', v_v->>'vendaId', 'numero', (v_v->>'numero')::int, 'message', 'Pedido liberado para a cozinha.');
  end if;

  if r.estado = 'ativa' then perform _mp_soltar(r.id, 'cancelada', 'Pagamento será reembolsado'); end if;
  update pagamentos_online set decisao = 'reembolsar', decisao_pendente = false, decidido_por = auth.uid(), decidido_em = now(), atualizado_em = now() where id = g.id;
  perform _auditar('Pagamento online: reembolsar', 'Pagamento ' || g.id || ' | R$ ' || _dinheiro(g.valor), '');
  return jsonb_build_object('ok', true, 'decisao', 'reembolsar', 'pagamentoId', g.id, 'valorAReembolsar', round(g.valor - g.valor_reembolsado, 2),
    'message', 'Decisão registrada. Falta devolver o dinheiro pelo Mercado Pago.');
end $f$;

-- ---------- 7) Funções só para as Edge Functions (chave de serviço) ----------
-- Credenciais do modo atual (ou do modo em que o pagamento foi criado). Nunca vão para o navegador.
create or replace function public.mp_credenciais(p_modo text default null) returns jsonb
 language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('ligado', c.ligado, 'modoAtual', case when c.modo = 'producao' then 'producao' else 'homologacao' end,
    'modo', m.modo, 'config', c.config,
    'publicKey', (select valor from integracoes_segredos where chave = case when m.modo = 'producao' then 'mp_public_key_producao' else 'mp_public_key_teste' end),
    'accessToken', (select valor from integracoes_segredos where chave = case when m.modo = 'producao' then 'mp_access_token_producao' else 'mp_access_token_teste' end),
    'webhookSecret', (select valor from integracoes_segredos where chave = 'mp_webhook_secret'))
  from integracoes_config c,
       lateral (select case when coalesce(p_modo, c.modo) = 'producao' then 'producao' else 'homologacao' end as modo) m
  where c.provedor = 'mercadopago'
$f$;

-- mp-criar chama antes de falar com o Mercado Pago. p: {reservaId, userId}. Confere dono, tempo, ligado, tentativas e cria a linha do pagamento.
-- Pix ainda valendo na mesma reserva: devolve o mesmo (reaproveitar = true), sem criar outro.
create or replace function public.mp_preparar_pagamento(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; f formas_pagamento%rowtype; g pagamentos_online%rowtype; v_modo text; v_novo uuid; v_email text; v_achou boolean;
begin
  select * into r from pedidos_reserva where id = _uuid(p->>'reservaId') for update;
  if not found or r.user_id is distinct from _uuid(p->>'userId') then return _falha('Pedido não encontrado.'); end if;
  if r.estado = 'confirmada' then return _falha('Este pedido já foi pago.'); end if;
  if r.estado <> 'ativa' or r.expira_em < now() then return _falha('O tempo deste pedido acabou. Faça o pedido de novo.'); end if;
  if coalesce((public.api_mp_config_publica('{}'::jsonb)->>'ligado')::boolean, false) is not true then return _falha('O pagamento pelo site não está disponível agora.'); end if;
  select * into f from formas_pagamento where id = r.forma_pagamento_id;
  if f.id is null or not f.aceita_online or f.tipo_online is null then return _falha('Forma de pagamento inválida.'); end if;
  if exists (select 1 from pagamentos_online where reserva_id = r.id and status = 'aprovado') then return _falha('Este pedido já foi pago.'); end if;
  if (select count(*) from pagamentos_online where reserva_id = r.id) >= 5 then return _falha('Muitas tentativas de pagamento. Faça o pedido de novo.'); end if;

  select * into g from pagamentos_online
   where reserva_id = r.id and metodo = 'pix' and status = 'aguardando' and pix_copia_cola is not null and (pix_expira_em is null or pix_expira_em > now())
   order by criado_em desc limit 1;
  v_achou := found;
  if v_achou and f.tipo_online = 'pix' then
    return jsonb_build_object('ok', true, 'reaproveitar', true, 'pagamentoId', g.id, 'metodo', 'pix', 'valor', g.valor,
      'pixCopiaCola', g.pix_copia_cola, 'pixQrBase64', g.pix_qr_base64, 'pixExpiraEm', g.pix_expira_em);
  end if;
  if f.tipo_online = 'credito' and exists (select 1 from pagamentos_online where reserva_id = r.id and metodo = 'credito' and status = 'aguardando' and criado_em > now() - interval '2 minutes') then
    return _falha('Seu pagamento está em andamento. Aguarde alguns segundos.');
  end if;

  update pagamentos_online set status = 'cancelado', status_detalhe = 'substituído por nova tentativa', atualizado_em = now() where reserva_id = r.id and status = 'aguardando';
  select case when modo = 'producao' then 'producao' else 'homologacao' end into v_modo from integracoes_config where provedor = 'mercadopago';
  insert into pagamentos_online (reserva_id, user_id, metodo, mp_modo, valor) values (r.id, r.user_id, f.tipo_online, v_modo, r.valor_total) returning id into v_novo;
  select email into v_email from auth.users where id = r.user_id;   -- só é repassado ao Mercado Pago; não é guardado aqui
  return jsonb_build_object('ok', true, 'pagamentoId', v_novo, 'metodo', f.tipo_online, 'modo', v_modo, 'valor', r.valor_total, 'expiraEm', r.expira_em,
    'email', v_email, 'nome', r.cliente_nome,
    'itens', (select coalesce(jsonb_agg(jsonb_build_object('titulo', left(coalesce(e->>'descricao', 'Item'), 100), 'quantidade', _num(e->>'quantidade', 1), 'valorUnitario', _num(e->>'valorUnitario'))), '[]'::jsonb)
                from jsonb_array_elements(r.itens) e));
end $f$;

-- Única porta de entrada do resultado do Mercado Pago (criação, aviso/webhook, consulta ativa, reembolso). O status chega JÁ traduzido pela função da nuvem:
--   status = aguardando | aprovado | recusado | expirado | cancelado | reembolso_parcial | reembolsado | erro
-- p: {pagamentoId ou mpOrderId, status, statusDetalhe, mpOrderId, mpPaymentId, pixCopiaCola, pixQrBase64, pixExpiraEm, cartaoFinal, cartaoBandeira,
--     valorReembolsado, erro, chaveEvento (só aviso), assinaturaOk (só aviso), tipoEvento, statusMp, detalhe}
-- Aviso repetido (mesma chaveEvento) é ignorado. Aviso com assinatura inválida só é registrado e nada mais acontece.
create or replace function public.mp_aplicar_status(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare g pagamentos_online%rowtype; v_chave text := nullif(btrim(coalesce(p->>'chaveEvento', '')), ''); v_ass boolean := coalesce((p->>'assinaturaOk')::boolean, false);
        v_st text := lower(btrim(coalesce(p->>'status', ''))); v_ev bigint; v_vr numeric; v_res jsonb; v_reserva uuid; v_oid text := nullif(btrim(coalesce(p->>'mpOrderId', '')), '');
begin
  if v_chave is not null and not v_ass then
    insert into pagamentos_online_eventos (chave, tipo, status_mp, assinatura_ok, detalhe)
    values ('invalida:' || gen_random_uuid()::text, left(coalesce(p->>'tipoEvento', ''), 60), left(coalesce(p->>'statusMp', ''), 60), false, p->'detalhe');
    return jsonb_build_object('ok', false, 'ignorado', 'assinatura');
  end if;
  if v_st not in ('aguardando', 'aprovado', 'recusado', 'expirado', 'cancelado', 'reembolso_parcial', 'reembolsado', 'erro') then return _falha('Status inválido.'); end if;

  select reserva_id into v_reserva from pagamentos_online where id = _uuid(p->>'pagamentoId');
  if v_reserva is null and v_oid is not null then select reserva_id into v_reserva from pagamentos_online where mp_order_id = v_oid; end if;
  if v_reserva is null then
    if v_chave is not null then
      insert into pagamentos_online_eventos (chave, tipo, status_mp, assinatura_ok, detalhe) values (v_chave, left(coalesce(p->>'tipoEvento', ''), 60), left(coalesce(p->>'statusMp', ''), 60), true, p->'detalhe')
      on conflict (chave) do nothing;
    end if;
    return jsonb_build_object('ok', false, 'ignorado', 'pagamento_desconhecido');
  end if;
  perform 1 from pedidos_reserva where id = v_reserva for update;                 -- trava: reserva primeiro, depois o pagamento
  select * into g from pagamentos_online where id = coalesce(_uuid(p->>'pagamentoId'), (select id from pagamentos_online where mp_order_id = v_oid)) for update;

  if v_chave is not null then
    insert into pagamentos_online_eventos (chave, pagamento_id, tipo, status_mp, assinatura_ok, detalhe)
    values (v_chave, g.id, left(coalesce(p->>'tipoEvento', ''), 60), left(coalesce(p->>'statusMp', ''), 60), true, p->'detalhe')
    on conflict (chave) do nothing returning id into v_ev;
    if v_ev is null then return jsonb_build_object('ok', true, 'duplicado', true); end if;
  end if;

  update pagamentos_online set
    mp_order_id = coalesce(v_oid, mp_order_id), mp_payment_id = coalesce(nullif(p->>'mpPaymentId', ''), mp_payment_id),
    pix_copia_cola = coalesce(nullif(p->>'pixCopiaCola', ''), pix_copia_cola), pix_qr_base64 = coalesce(nullif(p->>'pixQrBase64', ''), pix_qr_base64),
    pix_expira_em = coalesce(nullif(p->>'pixExpiraEm', '')::timestamptz, pix_expira_em),
    cartao_final = case when p->>'cartaoFinal' ~ '^[0-9]{4}$' then p->>'cartaoFinal' else cartao_final end,
    cartao_bandeira = coalesce(left(nullif(p->>'cartaoBandeira', ''), 30), cartao_bandeira),
    status_detalhe = case when p ? 'statusDetalhe' then left(coalesce(p->>'statusDetalhe', ''), 200) else status_detalhe end, atualizado_em = now()
   where id = g.id;
  select * into g from pagamentos_online where id = g.id;

  if v_st = 'aprovado' then
    if g.status not in ('reembolso_parcial', 'reembolsado') then v_res := _mp_confirmar_pagamento(g.id); end if;
  elsif v_st in ('recusado', 'expirado', 'cancelado') then
    if g.status = 'aguardando' then update pagamentos_online set status = v_st, atualizado_em = now() where id = g.id; end if;
  elsif v_st = 'erro' then
    if g.status = 'aguardando' then
      update pagamentos_online set status = 'erro', erro = left(coalesce(p->>'erro', ''), 300), atualizado_em = now() where id = g.id;
      -- não deu nem para criar o pagamento: solta a reserva na hora (a página oferece pagar na entrega)
      if exists (select 1 from pedidos_reserva where id = g.reserva_id and estado = 'ativa')
         and not exists (select 1 from pagamentos_online where reserva_id = g.reserva_id and status = 'aprovado') then
        perform _mp_soltar(g.reserva_id, 'cancelada', 'Erro ao criar o pagamento');
      end if;
    end if;
  elsif v_st in ('reembolso_parcial', 'reembolsado') then
    if g.status in ('aprovado', 'reembolso_parcial', 'reembolsado') then
      v_vr := round(least(g.valor, greatest(g.valor_reembolsado, case when v_st = 'reembolsado' then g.valor else coalesce(_num(p->>'valorReembolsado'), 0) end)), 2);
      update pagamentos_online set valor_reembolsado = v_vr, status = case when v_vr >= g.valor then 'reembolsado' else 'reembolso_parcial' end, atualizado_em = now() where id = g.id;
      if v_vr >= g.valor and g.venda_id is not null then
        update reembolsos set status = 'Devolvido', devolvido_em = now(), observacao = 'Reembolsado pelo Mercado Pago' where venda_id = g.venda_id and status = 'Pendente';
      end if;
      perform _auditar('Reembolso Mercado Pago', 'Pagamento ' || g.id || ' | R$ ' || _dinheiro(v_vr) || ' de R$ ' || _dinheiro(g.valor), '');
    end if;
  end if;

  return jsonb_build_object('ok', true, 'pagamentoId', g.id, 'status', (select status from pagamentos_online where id = g.id), 'resultado', v_res);
end $f$;

-- Rodada a cada minuto (pg_cron): reservas vencidas sem pagamento devolvem estoque, cupom e brinde. Nada é apagado.
-- Reserva com pagamento aprovado ou aguardando decisão NÃO vence: segue até alguém decidir.
create or replace function public.mp_expirar_reservas() returns int
 language plpgsql security definer set search_path to 'public' as $f$
declare r record; n int := 0;
begin
  for r in select id from pedidos_reserva where estado = 'ativa' and expira_em < now() order by expira_em limit 100 for update skip locked loop
    if exists (select 1 from pagamentos_online g where g.reserva_id = r.id and (g.status = 'aprovado' or (g.decisao_pendente and g.decisao is null))) then continue; end if;
    update pagamentos_online set status = 'expirado', status_detalhe = 'reserva vencida', atualizado_em = now() where reserva_id = r.id and status = 'aguardando';
    perform _mp_soltar(r.id, 'expirada', 'Tempo esgotado sem pagamento');
    n := n + 1;
  end loop;
  return n;
end $f$;

do $d$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    if not exists (select 1 from cron.job where jobname = 'mp-expirar-reservas') then
      perform cron.schedule('mp-expirar-reservas', '* * * * *', 'select public.mp_expirar_reservas()');
    end if;
  end if;
end $d$;

-- ---------- 8) Permissões ----------
revoke all on function public._mp_prender(uuid, boolean), public._mp_soltar(uuid, text, text), public._mp_criar_venda(uuid, uuid),
  public._mp_marcar_decidir(uuid, text), public._mp_confirmar_pagamento(uuid), public._criar_pedido_publico(jsonb, uuid, boolean) from public, anon, authenticated;
revoke all on function public.api_mp_reservar(jsonb), public.api_mp_status_pagamento(jsonb), public.api_mp_cancelar_reserva(jsonb), public.api_mp_decidir_pagamento(jsonb) from public, anon;
grant execute on function public.api_mp_reservar(jsonb), public.api_mp_status_pagamento(jsonb), public.api_mp_cancelar_reserva(jsonb), public.api_mp_decidir_pagamento(jsonb) to authenticated;
revoke all on function public.mp_credenciais(text), public.mp_preparar_pagamento(jsonb), public.mp_aplicar_status(jsonb), public.mp_expirar_reservas() from public, anon, authenticated;
grant execute on function public.mp_credenciais(text), public.mp_preparar_pagamento(jsonb), public.mp_aplicar_status(jsonb), public.mp_expirar_reservas() to service_role;

-- =====================================================================
-- PARTE 3 — Mercado Pago: painel do Admin (ligar, chaves)
-- (arquivo de origem: ajustes/2026-10-13-mp-etapa4-painel.sql)
-- =====================================================================
-- =====================================================================================
-- MERCADO PAGO · ETAPA 4 (painel Admin: card Mercado Pago) · 2026-10-13 · NÃO APLICADO
-- Rode DEPOIS das Etapas 1 e 2. Pode rodar de novo (idempotente). Cole inteiro no SQL Editor do Supabase.
-- Para conferir depois, rode testes/teste-mp-etapa4.sql.
-- Só acrescenta o 'mercadopago' às funções de integração (partindo da versão MAIS RECENTE de cada uma:
-- as de iFood e Nota fiscal ficam idênticas). Nenhum "delete from" dentro de função. Integração segue DESLIGADA.
-- =====================================================================================


-- ---------- 1) Regra do "Ligar": em TESTE só exige conta, chaves de teste e webhook; em PRODUÇÃO exige os 5 passos ----------
-- (o "teste guiado" só é possível com a integração ligada em teste, por isso não pode ser exigido para ligar em teste)
create or replace function public._integ_pendencias(p_prov text, p_modo text) returns text[]
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_out text[] := '{}'; v_item jsonb; v_ck jsonb; v_ok boolean;
begin
  select checklist into v_ck from integracoes_config where provedor = p_prov;
  for v_item in select * from jsonb_array_elements(_integ_checklist_def(p_prov)) loop
    if p_prov = 'mercadopago' and p_modo = 'homologacao' and (v_item->>'id') in ('teste_guiado', 'chaves_producao') then continue; end if;
    if coalesce((v_item->>'auto')::boolean, false) then
      v_ok := case v_item->>'id'
        when 'chaves' then (select count(*) from integracoes_segredos where chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id')) = 3
        when 'token' then exists (select 1 from integracoes_segredos where chave = 'nfce_token_' || p_modo)
        when 'empresa' then public._fiscal_empresa_ok()
        when 'perfis' then public._fiscal_perfis_ok()
        when 'chaves_teste' then (select count(*) from integracoes_segredos where chave in ('mp_public_key_teste', 'mp_access_token_teste')) = 2
        when 'webhook' then exists (select 1 from integracoes_segredos where chave = 'mp_webhook_secret')
        when 'teste_guiado' then exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'pix' and status in ('aprovado', 'reembolso_parcial', 'reembolsado'))
                             and exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'credito' and status in ('aprovado', 'reembolso_parcial', 'reembolsado'))
        when 'chaves_producao' then (select count(*) from integracoes_segredos where chave in ('mp_public_key_producao', 'mp_access_token_producao')) = 2
        else coalesce((v_ck->>(v_item->>'id'))::boolean, false) end;
    else
      v_ok := coalesce((v_ck->>(v_item->>'id'))::boolean, false);
    end if;
    if not v_ok then v_out := v_out || (v_item->>'titulo'); end if;
  end loop;
  return v_out;
end $f$;

-- ---------- 2) Quem vê o pagamento online no cardápio ----------
-- Produção: todos. Teste: só quem está na lista "emailsTeste" (a conta Google de teste), ou todos se "testeNoCardapio" = true (padrão: não).
-- _mp_publico(user) é o miolo; api_mp_config_publica usa o usuário logado e mp_preparar_pagamento usa o dono da reserva.
create or replace function public._mp_publico(p_user uuid) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare c integracoes_config%rowtype; v_prod boolean; v_pk text; v_formas jsonb; v_min int; v_email text; v_visivel boolean;
begin
  select * into c from integracoes_config where provedor = 'mercadopago';
  if c.provedor is null or not c.ligado then return jsonb_build_object('ok', true, 'ligado', false); end if;
  v_prod := (c.modo = 'producao');
  if not v_prod then
    v_visivel := coalesce((c.config->>'testeNoCardapio')::boolean, false);
    if not v_visivel and p_user is not null and jsonb_typeof(c.config->'emailsTeste') = 'array' then
      select lower(email) into v_email from auth.users where id = p_user;
      v_visivel := v_email is not null and exists (select 1 from jsonb_array_elements_text(c.config->'emailsTeste') x where lower(btrim(x)) = v_email);
    end if;
    if not coalesce(v_visivel, false) then return jsonb_build_object('ok', true, 'ligado', false); end if;
  end if;
  select valor into v_pk from integracoes_segredos where chave = case when v_prod then 'mp_public_key_producao' else 'mp_public_key_teste' end;
  select coalesce(jsonb_agg(jsonb_build_object('id', f.id, 'tipo', f.tipo_online) order by f.ordem), '[]'::jsonb) into v_formas
    from formas_pagamento f where f.ativa and f.visivel_cardapio and f.aceita_online and f.tipo_online is not null;
  if v_pk is null or jsonb_array_length(v_formas) = 0 then return jsonb_build_object('ok', true, 'ligado', false); end if;
  v_min := case when coalesce(c.config->>'pixValidadeMin', '') ~ '^[0-9]{1,3}$' then least(120, greatest(5, (c.config->>'pixValidadeMin')::int)) else 15 end;
  return jsonb_build_object('ok', true, 'ligado', true, 'modo', case when v_prod then 'producao' else 'teste' end,
    'publicKey', v_pk, 'formas', v_formas, 'pixValidadeMin', v_min);
end $f$;

create or replace function public.api_mp_config_publica(p jsonb default '{}'::jsonb) returns jsonb
 language sql stable security definer set search_path to 'public' as $f$ select public._mp_publico(auth.uid()) $f$;
revoke all on function public._mp_publico(uuid) from public, anon, authenticated;
revoke all on function public.api_mp_config_publica(jsonb) from public, anon, authenticated;
grant execute on function public.api_mp_config_publica(jsonb) to anon, authenticated;

-- mp_preparar_pagamento (Etapa 2) com duas mudanças: usa _mp_publico(dono da reserva) e, em modo Teste, o e-mail do pagador pode ser o "emailPagadorTeste" do card
create or replace function public.mp_preparar_pagamento(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r pedidos_reserva%rowtype; f formas_pagamento%rowtype; g pagamentos_online%rowtype; v_modo text; v_novo uuid; v_email text; v_achou boolean; v_teste_email text;
begin
  select * into r from pedidos_reserva where id = _uuid(p->>'reservaId') for update;
  if not found or r.user_id is distinct from _uuid(p->>'userId') then return _falha('Pedido não encontrado.'); end if;
  if r.estado = 'confirmada' then return _falha('Este pedido já foi pago.'); end if;
  if r.estado <> 'ativa' or r.expira_em < now() then return _falha('O tempo deste pedido acabou. Faça o pedido de novo.'); end if;
  if coalesce((public._mp_publico(r.user_id)->>'ligado')::boolean, false) is not true then return _falha('O pagamento pelo site não está disponível agora.'); end if;
  select * into f from formas_pagamento where id = r.forma_pagamento_id;
  if f.id is null or not f.aceita_online or f.tipo_online is null then return _falha('Forma de pagamento inválida.'); end if;
  if exists (select 1 from pagamentos_online where reserva_id = r.id and status = 'aprovado') then return _falha('Este pedido já foi pago.'); end if;
  if (select count(*) from pagamentos_online where reserva_id = r.id) >= 5 then return _falha('Muitas tentativas de pagamento. Faça o pedido de novo.'); end if;

  select * into g from pagamentos_online
   where reserva_id = r.id and metodo = 'pix' and status = 'aguardando' and pix_copia_cola is not null and (pix_expira_em is null or pix_expira_em > now())
   order by criado_em desc limit 1;
  v_achou := found;
  if v_achou and f.tipo_online = 'pix' then
    return jsonb_build_object('ok', true, 'reaproveitar', true, 'pagamentoId', g.id, 'metodo', 'pix', 'valor', g.valor,
      'pixCopiaCola', g.pix_copia_cola, 'pixQrBase64', g.pix_qr_base64, 'pixExpiraEm', g.pix_expira_em);
  end if;
  if f.tipo_online = 'credito' and exists (select 1 from pagamentos_online where reserva_id = r.id and metodo = 'credito' and status = 'aguardando' and criado_em > now() - interval '2 minutes') then
    return _falha('Seu pagamento está em andamento. Aguarde alguns segundos.');
  end if;

  update pagamentos_online set status = 'cancelado', status_detalhe = 'substituído por nova tentativa', atualizado_em = now() where reserva_id = r.id and status = 'aguardando';
  select case when modo = 'producao' then 'producao' else 'homologacao' end, nullif(btrim(coalesce(config->>'emailPagadorTeste', '')), '')
    into v_modo, v_teste_email from integracoes_config where provedor = 'mercadopago';
  insert into pagamentos_online (reserva_id, user_id, metodo, mp_modo, valor) values (r.id, r.user_id, f.tipo_online, v_modo, r.valor_total) returning id into v_novo;
  select email into v_email from auth.users where id = r.user_id;   -- só é repassado ao Mercado Pago; não é guardado aqui
  if v_modo = 'homologacao' and v_teste_email is not null then v_email := v_teste_email; end if;   -- só em Teste: e-mail de comprador de teste do Mercado Pago
  return jsonb_build_object('ok', true, 'pagamentoId', v_novo, 'metodo', f.tipo_online, 'modo', v_modo, 'valor', r.valor_total, 'expiraEm', r.expira_em,
    'email', v_email, 'nome', r.cliente_nome,
    'itens', (select coalesce(jsonb_agg(jsonb_build_object('titulo', left(coalesce(e->>'descricao', 'Item'), 100), 'quantidade', _num(e->>'quantidade', 1), 'valorUnitario', _num(e->>'valorUnitario'))), '[]'::jsonb)
                from jsonb_array_elements(r.itens) e));
end $f$;
revoke all on function public.mp_preparar_pagamento(jsonb) from public, anon, authenticated;
grant execute on function public.mp_preparar_pagamento(jsonb) to service_role;

-- ---------- 3) Status das integrações (versão mais recente + Mercado Pago) ----------
create or replace function public.api_integracoes_status(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_modo text; v_def jsonb; v_it jsonb; v_pend text[]; v_pt text[]; v_pp text[];
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  for r in select * from integracoes_config order by provedor loop
    v_def := _integ_checklist_def(r.provedor); v_pend := _integ_pendencias(r.provedor, r.modo);
    v := v || (jsonb_build_object('provedor', r.provedor, 'ligado', r.ligado, 'modo', r.modo, 'ligadoEm', r.ligado_em, 'config', r.config,
      'checklist', (select coalesce(jsonb_agg(jsonb_build_object('id', x->>'id', 'titulo', x->>'titulo', 'auto', coalesce((x->>'auto')::boolean, false),
          'feito', not ((x->>'titulo') = any (v_pend))) ), '[]'::jsonb) from jsonb_array_elements(v_def) x),
      'pendencias', to_jsonb(v_pend), 'podeLigar', coalesce(array_length(v_pend, 1), 0) = 0,
      'segredos', (select coalesce(jsonb_object_agg(s.chave, jsonb_build_object('tem', true, 'final', case when length(s.valor) > 8 then right(s.valor, 4) else '' end, 'em', s.atualizado_em)), '{}'::jsonb)
                    from integracoes_segredos s where (r.provedor = 'ifood' and s.chave like 'ifood\_%') or (r.provedor = 'nfce' and s.chave like 'nfce\_%') or (r.provedor = 'mercadopago' and s.chave like 'mp\_%')))
      || case when r.provedor = 'mercadopago' then (
           select jsonb_build_object('pendenciasTeste', to_jsonb(a.t), 'pendenciasProducao', to_jsonb(a.p),
             'podeLigarTeste', coalesce(array_length(a.t, 1), 0) = 0, 'podeLigarProducao', coalesce(array_length(a.p, 1), 0) = 0,
             'formas', (select coalesce(jsonb_agg(jsonb_build_object('id', f.id, 'nome', f.nome, 'aceitaOnline', f.aceita_online, 'tipoOnline', f.tipo_online) order by f.ordem), '[]'::jsonb)
                          from formas_pagamento f where f.ativa and f.visivel_cardapio))
             from (select _integ_pendencias('mercadopago', 'homologacao') as t, _integ_pendencias('mercadopago', 'producao') as p) a)
         else '{}'::jsonb end);
  end loop;
  return jsonb_build_object('ok', true, 'integracoes', v);
end $f$;

-- ---------- 4) Ajustes (config): mercadopago ganha validade do Pix, e-mails de teste e "mostrar a todos em Teste" ----------
create or replace function public.api_integracoes_config(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text := p->>'provedor'; v_cfg jsonb := coalesce(p->'config', '{}'::jsonb); v_atual jsonb; v_chave text; v_novo jsonb := '{}'::jsonb;
        v_re text := '^[^@\s]+@[^@\s]+\.[^@\s]+$';
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_prov not in ('ifood', 'nfce', 'mercadopago') then return _falha('Integração inválida.'); end if;
  select config into v_atual from integracoes_config where provedor = v_prov;
  -- só chaves conhecidas, com valores simples
  for v_chave in select jsonb_object_keys(v_cfg) loop
    if v_prov = 'ifood' and v_chave in ('confirmacaoAutomatica', 'abrirFecharComCaixa', 'pausarSemEstoque', 'enviarPrecos') then v_novo := v_novo || jsonb_build_object(v_chave, coalesce((v_cfg->>v_chave)::boolean, false));
    elsif v_prov = 'ifood' and v_chave = 'baixaEstoque' and (v_cfg->>v_chave) in ('confirmacao', 'entrega') then v_novo := v_novo || jsonb_build_object(v_chave, v_cfg->>v_chave);
    elsif v_prov = 'ifood' and v_chave = 'retencaoClientesDias' and (v_cfg->>v_chave)::int between 7 and 365 then v_novo := v_novo || jsonb_build_object(v_chave, (v_cfg->>v_chave)::int);
    elsif v_prov = 'ifood' and v_chave = 'limitePrecoPct' and (v_cfg->>v_chave)::numeric between 0 and 100 then v_novo := v_novo || jsonb_build_object(v_chave, (v_cfg->>v_chave)::numeric);
    elsif v_prov = 'nfce' and v_chave = 'emitirQuando' and (v_cfg->>v_chave) in ('pagamento', 'entrega') then v_novo := v_novo || jsonb_build_object(v_chave, v_cfg->>v_chave);
    elsif v_prov = 'nfce' and v_chave = 'canais' and jsonb_typeof(v_cfg->v_chave) = 'array' then v_novo := v_novo || jsonb_build_object(v_chave, (select coalesce(jsonb_agg(c), '[]'::jsonb) from jsonb_array_elements_text(v_cfg->v_chave) c where c in ('balcao', 'cardapio', 'ifood', 'mesa')));
    elsif v_prov = 'mercadopago' and v_chave = 'pixValidadeMin' then
      if coalesce(v_cfg->>v_chave, '') !~ '^[0-9]{1,3}$' or (v_cfg->>v_chave)::int not between 5 and 120 then return _falha('A validade do Pix deve ficar entre 5 e 120 minutos.'); end if;
      v_novo := v_novo || jsonb_build_object(v_chave, (v_cfg->>v_chave)::int);
    elsif v_prov = 'mercadopago' and v_chave = 'testeNoCardapio' then v_novo := v_novo || jsonb_build_object(v_chave, coalesce((v_cfg->>v_chave)::boolean, false));
    elsif v_prov = 'mercadopago' and v_chave = 'emailPagadorTeste' then
      if btrim(coalesce(v_cfg->>v_chave, '')) <> '' and (lower(btrim(v_cfg->>v_chave)) !~ v_re or length(v_cfg->>v_chave) > 120) then return _falha('E-mail do comprador de teste inválido.'); end if;
      v_novo := v_novo || jsonb_build_object(v_chave, lower(btrim(coalesce(v_cfg->>v_chave, ''))));
    elsif v_prov = 'mercadopago' and v_chave = 'emailsTeste' and jsonb_typeof(v_cfg->v_chave) = 'array' then
      if exists (select 1 from jsonb_array_elements_text(v_cfg->v_chave) x where btrim(x) <> '' and lower(btrim(x)) !~ v_re) then return _falha('Um dos e-mails de teste é inválido.'); end if;
      v_novo := v_novo || jsonb_build_object(v_chave, (select coalesce(jsonb_agg(q.e), '[]'::jsonb) from (select distinct lower(btrim(x)) as e from jsonb_array_elements_text(v_cfg->v_chave) x where btrim(x) <> '' limit 5) q));
    end if;
  end loop;
  update integracoes_config set config = v_atual || v_novo, atualizado_em = now() where provedor = v_prov;
  perform _auditar('Integração: ajustes salvos', v_prov);
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Ajustes salvos.');
end $f$;

-- ---------- 5) Guardar chaves (versão mais recente, com nfce_csc) + as 5 chaves do Mercado Pago ----------
create or replace function public.api_integracoes_salvar_segredo(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_chave text := p->>'chave'; v_valor text := btrim(coalesce(p->>'valor', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_chave not in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id', 'nfce_token_homologacao', 'nfce_token_producao', 'nfce_csc',
                     'mp_public_key_teste', 'mp_public_key_producao', 'mp_access_token_teste', 'mp_access_token_producao', 'mp_webhook_secret') then return _falha('Campo desconhecido.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  if length(v_valor) < 8 or length(v_valor) > 400 or v_valor ~ '\s' then return _falha('Valor inválido. Copie inteiro, sem espaços.'); end if;
  if v_chave like 'mp\_%' then
    if v_valor !~ '^[A-Za-z0-9_-]+$' then return _falha('Valor inválido. Use só letras, números, - e _ (copie inteiro, sem espaços).'); end if;
    if v_chave = 'mp_webhook_secret' and length(v_valor) < 16 then return _falha('A chave secreta do aviso (webhook) é maior que isso. Copie inteira.'); end if;
    if v_chave like 'mp\_access\_token%' and length(v_valor) < 30 then return _falha('O Access Token é maior que isso. Copie inteiro.'); end if;
  end if;
  insert into integracoes_segredos (chave, valor, atualizado_em) values (v_chave, v_valor, now())
    on conflict (chave) do update set valor = excluded.valor, atualizado_em = now();
  perform _auditar('Integração: chave salva', v_chave);
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Salvo.');
end $f$;

-- ---------- 6) Ligar e desligar ----------
create or replace function public.api_integracoes_ligar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text := p->>'provedor'; v_modo text := coalesce(p->>'modo', 'producao'); v_pend text[]; v_uid text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_prov not in ('ifood', 'nfce', 'mercadopago') then return _falha('Integração inválida.'); end if;
  if v_prov in ('nfce', 'mercadopago') and (nullif(p->>'modo', '') is null or v_modo not in ('homologacao', 'producao')) then return _falha('Escolha o ambiente: teste (homologação) ou produção.'); end if;
  if v_prov = 'ifood' then v_modo := 'producao'; end if;
  v_uid := _exige_admin(p->>'senhaAdmin');
  if coalesce(p->>'senhaAdmin', '') = '' or v_uid is null then return _falha('Senha de administrador incorreta.'); end if;
  v_pend := _integ_pendencias(v_prov, v_modo);
  if coalesce(array_length(v_pend, 1), 0) > 0 then return _falha('Ainda faltam passos: ' || array_to_string(v_pend, '; ')); end if;
  if v_prov = 'mercadopago' and not exists (select 1 from formas_pagamento where ativa and visivel_cardapio and aceita_online and tipo_online is not null) then
    return _falha('Escolha pelo menos uma forma de pagamento online (Pix ou cartão de crédito) antes de ligar.');
  end if;
  update integracoes_config set ligado = true, modo = v_modo, ligado_em = now(), ligado_por = v_uid, atualizado_em = now() where provedor = v_prov;
  perform _auditar('Integração LIGADA', v_prov || ' · ' || v_modo);
  perform _integ_log(v_prov, 'info', 'Integração ligada (' || v_modo || ')');
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Ligado.');
end $f$;

create or replace function public.api_integracoes_desligar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if p->>'provedor' not in ('ifood', 'nfce', 'mercadopago') then return _falha('Integração inválida.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' or _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  update integracoes_config set ligado = false, atualizado_em = now() where provedor = p->>'provedor';
  perform _auditar('Integração DESLIGADA', p->>'provedor');
  perform _integ_log(p->>'provedor', 'aviso', 'Integração desligada');
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Desligado. O sistema voltou a funcionar como antes.');
end $f$;

-- ---------- 7) Formas de pagamento online (Pix / cartão de crédito) ----------
create or replace function public.api_mp_forma_online(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_id uuid := _uuid(p->>'formaId'); v_on boolean := coalesce((p->>'aceitaOnline')::boolean, false); v_tipo text := lower(btrim(coalesce(p->>'tipoOnline', '')));
        f formas_pagamento%rowtype; o formas_pagamento%rowtype;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into f from formas_pagamento where id = v_id;
  if not found then return _falha('Forma de pagamento não encontrada.'); end if;
  if v_on then
    if v_tipo not in ('pix', 'credito') then return _falha('Escolha Pix ou cartão de crédito.'); end if;
    if not f.ativa or not f.visivel_cardapio then return _falha('Esta forma está oculta no cardápio. Deixe-a ativa e visível antes.'); end if;
    if f.permite_troco then return _falha('Forma com troco (dinheiro) não pode ser paga pelo site.'); end if;
    select * into o from formas_pagamento where id <> f.id and aceita_online and tipo_online = v_tipo limit 1;
    if found then return _falha('A forma "' || o.nome || '" já está como ' || case when v_tipo = 'pix' then 'Pix' else 'cartão de crédito' end || ' online. Desmarque-a antes.'); end if;
    update formas_pagamento set aceita_online = true, tipo_online = v_tipo where id = f.id;
  else
    update formas_pagamento set aceita_online = false, tipo_online = null where id = f.id;
  end if;
  perform _auditar('Mercado Pago: forma online', f.nome || ' · ' || case when v_on then v_tipo else 'desligada' end);
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Salvo.');
end $f$;

-- Últimos pagamentos online + situação do teste guiado (a tela do card usa)
create or replace function public.api_mp_pagamentos_recentes(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'itens', (select coalesce(jsonb_agg(jsonb_build_object('em', to_char(x.criado_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI'), 'modo', x.mp_modo, 'metodo', x.metodo,
                'status', x.status, 'valor', x.valor, 'aDecidir', (x.decisao_pendente and x.decisao is null), 'detalhe', left(coalesce(nullif(x.erro, ''), x.status_detalhe, ''), 120)) order by x.criado_em desc), '[]'::jsonb)
              from (select * from pagamentos_online order by criado_em desc limit 15) x),
    'testePix', exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'pix' and status in ('aprovado', 'reembolso_parcial', 'reembolsado')),
    'testeCredito', exists (select 1 from pagamentos_online where mp_modo = 'homologacao' and metodo = 'credito' and status in ('aprovado', 'reembolso_parcial', 'reembolsado')),
    'aDecidir', (select count(*) from pagamentos_online where decisao_pendente and decisao is null));
end $f$;

-- ---------- 8) Saúde do sistema: versão mais recente de _saude_integracoes + bloco do Mercado Pago ----------
create or replace function public._saude_integracoes() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_desc int; e ifood_estado%rowtype; v_min numeric; v_sem int; v_novos int; v_acoes int; v_nivel text; v_txt text; v_urg int;
        v_dec int; v_dec_velho int; v_venc int; v_err int;
begin
  if exists (select 1 from ai_segredos where provedor = 'nvidia') or exists (select 1 from ai_segredos where provedor = 'cloudflare') then
    select count(*) into v_desc from unnest(array['nvidia', 'cloudflare']) x(p) where _ia_provedor_descansando(x.p);
    v := v || jsonb_build_object('id', 'ia_extras', 'titulo', 'IAs de reserva (NVIDIA / Cloudflare)', 'nivel', case when v_desc > 0 then 'atencao' else 'ok' end,
      'texto', (select string_agg(x.rot || ': ' || case when not exists (select 1 from ai_segredos where provedor = x.p) then 'sem chave' when _ia_provedor_descansando(x.p) then 'descansando (erros recentes)' else 'pronta' end, ' · ')
                from (values ('nvidia', 'NVIDIA'), ('cloudflare', 'Cloudflare')) x(p, rot)));
  end if;
  if _integracao_ligada('ifood') then
    select * into e from ifood_estado where id;
    v_min := case when e.ultima_consulta_ok is null then null else extract(epoch from (now() - e.ultima_consulta_ok)) / 60 end;
    select coalesce(sum(itens_sem_ligacao), 0) into v_sem from ifood_pedidos where estado <> 'cancelado' and criado_em > now() - interval '7 days';
    select count(*) into v_novos from ifood_pedidos where estado = 'novo' and not simulado and criado_em < now() - interval '4 minutes';
    select count(*) into v_acoes from ifood_acoes where estado in ('erro', 'duvida') and criado_em > now() - interval '1 day';
    select count(*) into v_urg from ifood_negociacoes where estado = 'aberta' and expira_em > now() and expira_em < now() + interval '3 minutes';
    v_nivel := case when v_min is null or v_min > 2 or e.token_ok is false or v_novos > 0 or v_urg > 0 then 'problema' when v_acoes > 0 or v_sem > 0 or e.ultimo_erro is not null or exists (select 1 from ifood_negociacoes where estado = 'aberta' and expira_em > now()) then 'atencao' else 'ok' end;
    v_txt := case when v_min is null then 'Ligado, mas ainda sem nenhuma consulta bem-sucedida ao iFood.' else 'Última consulta ao iFood há ' || round(v_min, 1) || ' min' end
      || case when e.ultimo_pedido_em is not null then ' · último pedido às ' || to_char(e.ultimo_pedido_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') else ' · nenhum pedido ainda' end
      || case when e.token_ok is false then ' · ACESSO RECUSADO (confira as chaves)' else '' end
      || case when v_novos > 0 then ' · ' || v_novos || ' pedido(s) esperando confirmação há mais de 4 min' else '' end
      || case when v_acoes > 0 then ' · ' || v_acoes || ' ação(ões) não confirmada(s) no iFood' else '' end
      || case when v_sem > 0 then ' · ' || v_sem || ' item(ns) sem ligação' else '' end || public._saude_ifood_extra();
    v := v || jsonb_build_object('id', 'ifood', 'titulo', 'iFood', 'nivel', v_nivel, 'texto', v_txt);
  end if;
  v := v || public._saude_nfce();
  if _integracao_ligada('mercadopago') then
    select count(*) into v_dec from pagamentos_online where decisao_pendente and decisao is null;
    select count(*) into v_dec_velho from pagamentos_online where decisao_pendente and decisao is null and atualizado_em < now() - interval '10 minutes';
    select count(*) into v_venc from pedidos_reserva pr where pr.estado = 'ativa' and pr.expira_em < now() - interval '3 minutes'
      and not exists (select 1 from pagamentos_online g where g.reserva_id = pr.id and (g.status = 'aprovado' or (g.decisao_pendente and g.decisao is null)));
    select count(*) into v_err from pagamentos_online where status = 'erro' and criado_em > now() - interval '1 hour';
    v_nivel := case when v_venc > 0 or v_dec_velho > 0 then 'problema' when v_dec > 0 or v_err > 0 then 'atencao' else 'ok' end;
    v_txt := 'Ligado (' || case when (select modo from integracoes_config where provedor = 'mercadopago') = 'producao' then 'produção' else 'teste' end || ')'
      || case when v_dec > 0 then ' · ' || v_dec || ' pagamento(s) esperando decisão (seguir ou reembolsar)' else '' end
      || case when v_venc > 0 then ' · ' || v_venc || ' reserva(s) vencida(s) não liberada(s) (confira o agendamento mp-expirar-reservas)' else '' end
      || case when v_err > 0 then ' · ' || v_err || ' erro(s) ao criar pagamento na última hora' else '' end;
    v := v || jsonb_build_object('id', 'mercadopago', 'titulo', 'Mercado Pago', 'nivel', v_nivel, 'texto', v_txt);
  end if;
  return v;
end $f$;

-- ---------- 9) Permissões ----------
revoke all on function public._saude_integracoes() from public, anon, authenticated;
revoke all on function public._integ_pendencias(text, text) from public, anon, authenticated;
revoke all on function public.api_integracoes_status(jsonb), public.api_integracoes_config(jsonb), public.api_integracoes_salvar_segredo(jsonb),
  public.api_integracoes_ligar(jsonb), public.api_integracoes_desligar(jsonb), public.api_mp_forma_online(jsonb), public.api_mp_pagamentos_recentes(jsonb) from public, anon;
grant execute on function public.api_integracoes_status(jsonb), public.api_integracoes_config(jsonb), public.api_integracoes_salvar_segredo(jsonb),
  public.api_integracoes_ligar(jsonb), public.api_integracoes_desligar(jsonb), public.api_mp_forma_online(jsonb), public.api_mp_pagamentos_recentes(jsonb) to authenticated;

-- =====================================================================
-- PARTE 4 — Mercado Pago: pendências, resumo do mês e reembolsos
-- (arquivo de origem: ajustes/2026-10-13-mp-etapa6-operacao.sql)
-- =====================================================================
-- MERCADO PAGO · ETAPA 6 — operação, decisão pendente e resumo mensal
-- Preparado localmente em 2026-10-13. NÃO APLICADO no Supabase.
-- Depende das Etapas 1, 2 e 4 já aplicadas e da tabela pagamentos_online.

create or replace function public.api_mp_pendencias_decisao(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'itens', (select coalesce(jsonb_agg(jsonb_build_object(
      'pagamentoId', x.id, 'reservaId', x.reserva_id, 'metodo', x.metodo, 'modo', x.mp_modo,
      'valor', x.valor, 'criadoEm', to_char(x.criado_em at time zone 'America/Sao_Paulo', 'DD/MM/YYYY HH24:MI'),
      'motivo', left(coalesce(nullif(x.decisao_motivo, ''), nullif(x.erro, ''), 'Pagamento aprovado sem pedido confirmado.'), 240),
      'clienteNome', coalesce(r.cliente_nome, ''), 'telefone', coalesce(r.telefone, '')
    ) order by x.criado_em), '[]'::jsonb)
    from pagamentos_online x join pedidos_reserva r on r.id = x.reserva_id
    where x.status = 'aprovado' and x.decisao_pendente and x.decisao is null));
end $f$;

create or replace function public.api_mp_resumo_operacional(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_ini timestamptz := date_trunc('month', now()); v_fim timestamptz := date_trunc('month', now()) + interval '1 month';
        v_total numeric(12,2); v_taxas numeric(12,2); v_qtd integer;
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  select coalesce(sum(greatest(x.valor - x.valor_reembolsado, 0)),0), count(*)::int into v_total, v_qtd
    from pagamentos_online x where x.status in ('aprovado','reembolso_parcial','reembolsado') and x.aprovado_em >= v_ini and x.aprovado_em < v_fim;
  select coalesce(sum(pv.taxa_aplicada),0) into v_taxas
    from pagamentos_online x join pagamentos_venda pv on pv.venda_id = x.venda_id
    where x.status in ('aprovado','reembolso_parcial','reembolsado') and x.aprovado_em >= v_ini and x.aprovado_em < v_fim;
  return jsonb_build_object('ok', true, 'periodo', to_char(v_ini at time zone 'America/Sao_Paulo','MM/YYYY'),
    'quantidade', v_qtd, 'total', round(v_total,2), 'taxas', round(v_taxas,2),
    'itens', (select coalesce(jsonb_agg(jsonb_build_object('metodo', q.metodo, 'quantidade', q.quantidade, 'total', q.total, 'taxas', q.taxas) order by q.metodo), '[]'::jsonb)
      from (select x.metodo, count(*)::int as quantidade, round(coalesce(sum(greatest(x.valor - x.valor_reembolsado, 0)),0),2) as total,
                   round(coalesce(sum(pv.taxa_aplicada),0),2) as taxas
              from pagamentos_online x left join (select venda_id, sum(taxa_aplicada) as taxa_aplicada from pagamentos_venda group by venda_id) pv on pv.venda_id = x.venda_id
             where x.status in ('aprovado','reembolso_parcial','reembolsado') and x.aprovado_em >= v_ini and x.aprovado_em < v_fim
             group by x.metodo) q));
end $f$;

revoke all on function public.api_mp_pendencias_decisao(jsonb), public.api_mp_resumo_operacional(jsonb) from public, anon;
grant execute on function public.api_mp_pendencias_decisao(jsonb), public.api_mp_resumo_operacional(jsonb) to authenticated;

-- A função api_mp_decidir_pagamento da Etapa 2 continua sendo a autoridade para liberar/reembolsar.
-- A devolução real só ocorre depois da decisão, chamando a Edge Function mp-reembolsar.


-- A lista de reembolsos identifica as vendas que vieram do checkout online.
-- Assim, o botão de confirmação pode chamar mp-reembolsar em vez de apenas marcar manualmente.
create or replace function public.api_listar_reembolsos(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_st text := nullif(btrim(coalesce(p->>'status','')),'');
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'itens', coalesce((
    select jsonb_agg(jsonb_build_object('id', r.id, 'vendaId', r.venda_id, 'numero', v.numero_pedido, 'cliente', v.cliente_nome,
      'valor', r.valor, 'forma', r.forma_pagamento, 'motivo', r.motivo, 'status', r.status, 'criadoEm', r.criado_em,
      'devolvidoEm', r.devolvido_em, 'observacao', r.observacao, 'pagamentoOnlineId', po.id) order by r.criado_em desc)
    from reembolsos r join vendas v on v.id = r.venda_id left join pagamentos_online po on po.venda_id = r.venda_id
    where v_st is null or r.status = v_st), '[]'::jsonb));
end $f$;
revoke execute on function public.api_listar_reembolsos(jsonb) from public, anon;
grant execute on function public.api_listar_reembolsos(jsonb) to authenticated;

-- =====================================================================
-- PARTE 5 — Leitor Fiscal IA: bucket privado, histórico, limpeza, chaves das IAs
-- (arquivo de origem: ajustes/2026-10-14-etapa10-leitor-fiscal.sql)
-- =====================================================================
-- TEXAS BURGER — Etapa 10: Leitor Fiscal IA (executar manualmente depois de revisar)
-- Não executar automaticamente. Fotos em bucket privado; histórico e exclusão após 30 dias.

-- Chaves dedicadas para o leitor fiscal, sem reutilizar a chave pública de atendimento.
alter table public.ai_segredos drop constraint if exists ai_segredos_provedor_check;
alter table public.ai_segredos add constraint ai_segredos_provedor_check
  check (provedor = any (array['gemini','groq','nvidia','cloudflare','cloudflare_conta','gemini_fotos','groq_2']));


-- Importa, sem exibir em logs, os segredos que já estavam no Vault com prefixo pendente_.
-- Não apaga os originais automaticamente: remova-os do Vault manualmente depois de validar o leitor.
do $vault$
begin
  begin
    execute $q$
      insert into public.ai_segredos(provedor,chave,atualizado_em)
      select case name when 'pendente_gemini_fotos' then 'gemini_fotos' when 'pendente_groq_2' then 'groq_2' end,
             decrypted_secret, now()
      from vault.decrypted_secrets
      where name in ('pendente_gemini_fotos','pendente_groq_2') and coalesce(decrypted_secret,'') <> ''
      on conflict (provedor) do nothing
    $q$;
  exception when others then raise notice 'Importação do Vault não executada; cadastre gemini_fotos e groq_2 em Contas e acessos depois: %', sqlerrm;
  end;
end $vault$;

-- Inclui as duas chaves fiscais na tela Contas e acessos.
create or replace function public.api_listar_chaves_ia(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok',true,'extrasPublico',coalesce((select extras_publico from ai_config limit 1),false),
    'chaves',coalesce((select jsonb_agg(jsonb_build_object('provedor',v.prov,'temChave',length(coalesce(s.chave,''))>0 and (v.prov<>'cloudflare' or length(coalesce(c.chave,''))>0),'final',case when length(coalesce(s.chave,''))>8 then right(s.chave,4) else '' end,'temConta',length(coalesce(c.chave,''))>0,'descansando',_ia_provedor_descansando(v.prov),'atualizadoEm',s.atualizado_em) order by v.ordem)
    from (values ('gemini',1),('groq',2),('nvidia',3),('cloudflare',4),('gemini_fotos',5),('groq_2',6)) v(prov,ordem)
    left join ai_segredos s on s.provedor=v.prov left join ai_segredos c on c.provedor='cloudflare_conta' and v.prov='cloudflare'),'[]'::jsonb));
end $f$;
create or replace function public.api_ver_chave_ia(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare v text; v_conta text; v_prov text:=lower(coalesce(p->>'provedor',''));
begin
 if not tem_nivel('Admin') then return _negado(); end if;
 if v_prov not in ('gemini','groq','nvidia','cloudflare','gemini_fotos','groq_2') then return _falha('IA desconhecida.'); end if;
 if coalesce(p->>'senhaAdmin','')='' then return _falha('Informe a sua senha de administrador.'); end if;
 if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
 select chave into v from ai_segredos where provedor=v_prov;
 if coalesce(v,'')='' then return _falha('Esta IA não tem chave guardada.'); end if;
 select chave into v_conta from ai_segredos where provedor='cloudflare_conta' and v_prov='cloudflare';
 perform _auditar('Chave de IA visualizada',v_prov);
 return jsonb_build_object('ok',true,'chave',v)||case when v_prov='cloudflare' then jsonb_build_object('contaId',coalesce(v_conta,'')) else '{}'::jsonb end;
end $f$;
create or replace function public.api_salvar_chave_ia(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text:=lower(coalesce(p->>'provedor','')); v_chave text:=btrim(coalesce(p->>'chave','')); v_conta text:=lower(btrim(coalesce(p->>'contaId','')));
begin
 if not tem_nivel('Admin') then return _negado(); end if;
 if v_prov not in ('gemini','groq','nvidia','cloudflare','gemini_fotos','groq_2') then return _falha('IA desconhecida.'); end if;
 if coalesce(p->>'senhaAdmin','')='' then return _falha('Informe a sua senha de administrador.'); end if;
 if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
 if length(v_chave)<20 or length(v_chave)>300 or v_chave ~ '\s' then return _falha('Chave inválida. Copie a chave inteira, sem espaços.'); end if;
 if v_prov='cloudflare' then
  if v_conta='' and not exists(select 1 from ai_segredos where provedor='cloudflare_conta') then return _falha('Informe também o Account ID da Cloudflare.'); end if;
  if v_conta<>'' and v_conta !~ '^[0-9a-f]{32}$' then return _falha('Account ID inválido: são 32 letras e números.'); end if;
  if v_conta<>'' then insert into ai_segredos(provedor,chave,atualizado_em) values('cloudflare_conta',v_conta,now()) on conflict(provedor) do update set chave=excluded.chave,atualizado_em=now(); end if;
 end if;
 insert into ai_segredos(provedor,chave,atualizado_em) values(v_prov,v_chave,now()) on conflict(provedor) do update set chave=excluded.chave,atualizado_em=now();
 perform _auditar('Chave de IA trocada',v_prov);
 return jsonb_build_object('ok',true,'message','Chave salva. O leitor fiscal já pode usá-la.')||api_listar_chaves_ia('{}');
end $f$;

create table if not exists public.fiscal_leituras (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid references public.usuarios(id) on delete set null,
  storage_path text,
  origem text not null check (origem in ('foto','texto','xml')),
  chave_nfe text,
  emitente_cnpj text,
  emitente_nome text not null default '',
  data_emissao date,
  numero_documento text,
  serie text,
  total numeric(12,2) not null default 0 check (total >= 0),
  itens jsonb not null default '[]'::jsonb,
  alertas jsonb not null default '[]'::jsonb,
  estado text not null default 'lida' check (estado in ('lida','confirmada','descartada','duplicada','erro')),
  compra_id uuid references public.compras(id) on delete set null,
  confirmada_por uuid references public.usuarios(id) on delete set null,
  confirmada_em timestamptz,
  criada_em timestamptz not null default now(),
  expira_em timestamptz not null default (now() + interval '30 days'),
  foto_excluida_em timestamptz
);
alter table public.fiscal_leituras add column if not exists foto_excluida_em timestamptz;
create index if not exists fiscal_leituras_data_idx on public.fiscal_leituras(criada_em desc);
create index if not exists fiscal_leituras_expira_idx on public.fiscal_leituras(expira_em);
create unique index if not exists fiscal_leituras_chave_ativa_uq on public.fiscal_leituras(chave_nfe)
  where chave_nfe is not null and chave_nfe <> '' and estado in ('lida','confirmada','duplicada');
alter table public.fiscal_leituras enable row level security;
revoke all on public.fiscal_leituras from anon, authenticated;
grant all on public.fiscal_leituras to service_role;

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('fiscal-notas','fiscal-notas',false,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public=false,file_size_limit=5242880,allowed_mime_types=array['image/jpeg','image/png','image/webp'];
-- Upload é permitido somente à equipe (Admin/Operador) e em caminhos prefixados pelo próprio UID. Leitura/remoção só pela service_role.
drop policy if exists fiscal_notas_upload_proprio on storage.objects;
create policy fiscal_notas_upload_proprio on storage.objects for insert to authenticated
  with check (bucket_id='fiscal-notas' and (storage.foldername(name))[1] = auth.uid()::text
              and public.auth_nivel()::text in ('Admin','Operador'));   -- cliente com conta (também 'authenticated') não pode enviar
drop policy if exists fiscal_notas_sem_leitura_publica on storage.objects;
create policy fiscal_notas_sem_leitura_publica on storage.objects for select to authenticated using (false);
drop policy if exists fiscal_notas_sem_update_publico on storage.objects;
create policy fiscal_notas_sem_update_publico on storage.objects for update to authenticated using (false);
drop policy if exists fiscal_notas_sem_delete_publico on storage.objects;
create policy fiscal_notas_sem_delete_publico on storage.objects for delete to authenticated using (false);

-- Só service_role pode chamar; a Edge Function confere a função do usuário antes de inserir/atualizar.
create or replace function public.fiscal_obter_cnpj_empresa()
returns text language sql stable security definer set search_path=public as $f$
  select regexp_replace(coalesce((select cnpj from public.fiscal_empresa where id),''),'\D','','g')
$f$;
revoke all on function public.fiscal_obter_cnpj_empresa() from public,anon,authenticated;
grant execute on function public.fiscal_obter_cnpj_empresa() to service_role;

-- Histórico de confirmação. Idempotente: repetir a mesma confirmação não altera o registro já confirmado.
create or replace function public.fiscal_marcar_confirmada(p_id uuid,p_compra_id uuid,p_usuario uuid)
returns jsonb language plpgsql security definer set search_path=public as $f$
declare v public.fiscal_leituras%rowtype;
begin
  select * into v from public.fiscal_leituras where id=p_id for update;
  if not found then return jsonb_build_object('ok',false,'message','Leitura não encontrada.'); end if;
  if v.estado='confirmada' then return jsonb_build_object('ok',true,'jaConfirmada',true); end if;
  if v.estado<>'lida' then return jsonb_build_object('ok',false,'message','Esta leitura não pode ser confirmada.'); end if;
  update public.fiscal_leituras set estado='confirmada', compra_id=p_compra_id, confirmada_por=p_usuario, confirmada_em=now() where id=p_id;
  return jsonb_build_object('ok',true);
end $f$;
revoke all on function public.fiscal_marcar_confirmada(uuid,uuid,uuid) from public,anon,authenticated;
grant execute on function public.fiscal_marcar_confirmada(uuid,uuid,uuid) to service_role;

create or replace function public.fiscal_marcar_descartada(p_id uuid,p_usuario uuid)
returns jsonb language plpgsql security definer set search_path=public as $f$
begin
  update public.fiscal_leituras set estado='descartada' where id=p_id and estado='lida' and usuario_id=p_usuario;
  if not found then return jsonb_build_object('ok',false,'message','Leitura não encontrada ou já finalizada.'); end if;
  return jsonb_build_object('ok',true);
end $f$;
revoke all on function public.fiscal_marcar_descartada(uuid,uuid) from public,anon,authenticated;
grant execute on function public.fiscal_marcar_descartada(uuid,uuid) to service_role;

-- Executa a limpeza pela Edge Function fiscal-limpar (remove do Storage pela API oficial antes de apagar o histórico).
do $$ begin
  if exists(select 1 from pg_extension where extname='pg_cron') then
    if not exists(select 1 from cron.job where jobname='fiscal-leituras-limpeza-diaria') then
      perform cron.schedule('fiscal-leituras-limpeza-diaria','20 7 * * *', $c$select public.chamar_edge('fiscal-limpar','{"cron":true}'::jsonb);$c$);
    end if;
  end if;
exception when others then raise notice 'Agendamento não criado; configure fiscal-limpar diariamente depois: %', sqlerrm;
end $$;

-- Ajuda do Tex
insert into public.ai_ajuda (slug,titulo,grupo,ordem,perfis,ativo,palavras_chave,passos,comuns,atualizado_em)
values ('man-admin-113-leitor-fiscal','Ler nota fiscal ou cupom pelo Tex','Financeiro',113,array['Admin','Operador'],true,'nota fiscal cupom fiscal foto XML leitor fiscal Tex compra fornecedor estoque despesa financeiro',
'Abra Administrador → Pergunte à IA → Leitor Fiscal IA. Envie uma foto legível, um XML de NF-e ou cole o texto da nota. Confira emitente, CNPJ, data, chave, fornecedor, itens, quantidades e valores. A soma dos itens deve bater com o total. Só toque em Confirmar e lançar compra depois de conferir: a confirmação registra a compra e pode atualizar estoque e financeiro. A foto fica em armazenamento privado e é excluída automaticamente após 30 dias. Se a leitura falhar, digite os dados manualmente.',
'Não lance uma nota do próprio Texas Burger como compra. Nota repetida pela chave fiscal é bloqueada. Pagamento dividido deve ser conferido e lançado manualmente nesta versão.',now())
on conflict (slug) do update set titulo=excluded.titulo,grupo=excluded.grupo,ordem=excluded.ordem,perfis=excluded.perfis,ativo=excluded.ativo,palavras_chave=excluded.palavras_chave,passos=excluded.passos,comuns=excluded.comuns,atualizado_em=now();

-- =====================================================================
-- PARTE 6 — LGPD: reservas e pagamentos online (inclui "apagar conta")
-- (arquivo de origem: ajustes/2026-10-14-mp-lgpd-reservas-MANUAL.sql)
-- =====================================================================
-- MERCADO PAGO — LGPD: dados pessoais das reservas e dos pagamentos online (14/10/2026)
-- COLE NO SQL EDITOR DO SUPABASE (tem "delete from" dentro de uma função, que o conector não aceita; por isso é manual).
-- Rode DEPOIS das etapas 1 e 2 do Mercado Pago e do SQL de contas de clientes (2026-10-12).
-- Problema que isto resolve: as tabelas pedidos_reserva e pagamentos_online guardam nome, telefone, endereço e o QR do Pix,
-- e nem "apagar conta" nem a anonimização automática (3 anos) passavam por elas.
-- Pode rodar mais de uma vez.


-- 1) anonimiza as reservas de uma conta (p_user) e/ou as encerradas há mais de p_dias dias.
--    Não mexe em pagamento aprovado que ainda espera decisão do restaurante (liberar ou reembolsar).
create or replace function public._mp_anonimizar_reservas(p_user uuid default null, p_dias integer default null) returns integer
 language plpgsql security definer set search_path to 'public' as $f$
declare n integer := 0;
begin
  if p_user is null and p_dias is null then return 0; end if;
  with alvo as (
    select r.id from pedidos_reserva r
     where (r.cliente_nome <> 'Cliente anonimizado' or r.telefone <> '' or r.dados_entrega is not null or r.observacoes <> '')
       and ((p_user is not null and r.user_id = p_user)
         or (p_dias is not null and r.estado <> 'ativa' and r.criado_em < now() - make_interval(days => p_dias)))
       and not exists (select 1 from pagamentos_online g where g.reserva_id = r.id and g.status = 'aprovado' and g.decisao_pendente and g.decisao is null)
  ), a as (
    update pedidos_reserva r set cliente_nome = 'Cliente anonimizado', telefone = '', dados_entrega = null, observacoes = '', atualizado_em = now()
      from alvo where r.id = alvo.id returning r.id
  ), b as (
    update pagamentos_online g set pix_copia_cola = null, pix_qr_base64 = null, cartao_final = null, atualizado_em = now()
     where g.reserva_id in (select id from a) returning g.id
  )
  select count(*) into n from a;
  return n;
end $f$;

-- 2) limpeza diária: QR/copia-e-cola de Pix que já acabou (2 dias) e reservas encerradas há mais de 180 dias
create or replace function public._job_mp_lgpd() returns integer
 language plpgsql security definer set search_path to 'public' as $f$
begin
  update pagamentos_online set pix_copia_cola = null, pix_qr_base64 = null, atualizado_em = now()
   where status <> 'aguardando' and (pix_copia_cola is not null or pix_qr_base64 is not null) and atualizado_em < now() - interval '2 days';
  return public._mp_anonimizar_reservas(null, 180);
end $f$;
revoke all on function public._mp_anonimizar_reservas(uuid, integer), public._job_mp_lgpd() from public, anon, authenticated;
grant execute on function public._mp_anonimizar_reservas(uuid, integer), public._job_mp_lgpd() to service_role;

do $$ begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    if not exists (select 1 from cron.job where jobname = 'mp-lgpd-diario') then
      perform cron.schedule('mp-lgpd-diario', '30 5 * * *', 'select public._job_mp_lgpd()');
    end if;
  end if;
end $$;

-- 3) "apagar conta" passa a anonimizar também as reservas e os pagamentos online da conta
create or replace function public.api_conta_apagar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public'
as $function$
declare c contas_cliente := _conta_exigir(); v_anon boolean := coalesce(p->>'anonimizar', '') in ('true', 't');
begin
  if c.user_id is null then return _falha('Entre com a sua conta para continuar.'); end if;
  if v_anon then
    if c.cliente_id is not null then perform _anonimizar_cliente(c.cliente_id); end if;
    update vendas set cliente_nome = 'Cliente anonimizado', telefone_cliente = '', endereco = '', complemento = '', referencia = '', observacoes_entrega = '', cpf_nota = null
     where id in (select venda_id from contas_pedidos where user_id = c.user_id);
  end if;
  perform _mp_anonimizar_reservas(c.user_id);   -- pedidos reservados e pagamentos online da conta (nome, telefone, endereço, QR do Pix)
  update cupons_usos set user_id = null where user_id = c.user_id;
  perform _auditar_publico('Conta de cliente apagada', case when v_anon then 'com anonimização do histórico' else 'histórico mantido' end, '');
  delete from contas_cliente where user_id = c.user_id;
  delete from auth.users where id = c.user_id;
  return jsonb_build_object('ok', true, 'message', 'Conta apagada.');
end $function$;
revoke all on function public.api_conta_apagar(jsonb) from public, anon;
grant execute on function public.api_conta_apagar(jsonb) to authenticated;

-- =====================================================================
-- CONFERÊNCIA FINAL (só leitura): mostra o que ficou pronto
-- =====================================================================
commit;
select 'tabelas mercado pago' as item, count(*)::text as resultado from information_schema.tables where table_schema='public' and table_name in ('pedidos_reserva','pagamentos_online','pagamentos_online_eventos','fiscal_leituras')
union all select 'bucket fiscal-notas privado', (select (not b.public)::text from storage.buckets b where b.id='fiscal-notas')
union all select 'agendamentos', coalesce((select string_agg(jobname, ', ' order by jobname) from cron.job where jobname in ('mp-expirar-reservas','fiscal-leituras-limpeza-diaria','mp-lgpd-diario')),'pg_cron indisponível')
union all select 'chaves das IAs', coalesce((select string_agg(provedor, ', ' order by provedor) from public.ai_segredos where provedor in ('gemini_fotos','groq_2')),'nenhuma');
