# Supabase — o que tem aqui e como usar

**Para aplicar tudo de uma vez:** cole `APLICAR-TUDO-DE-UMA-VEZ.sql` no SQL Editor (uma transação só; se der erro, nada é aplicado). Reúne Mercado Pago, Leitor Fiscal e LGPD, sem as chaves das IAs (cadastre em Administrador → Contas e acessos). Depois, publique as Edge Functions.

Pasta `supabase-codigo/`:
- `01-estrutura.sql` — estrutura completa do banco (para refazer do zero).
- `ajustes/` — mudanças por data. Rode só as que ainda não rodou, em ordem de data. Mercado Pago, nesta ordem: `2026-10-13-mp-etapa1-estrutura.sql`, `...etapa2-funcoes.sql`, `...etapa4-painel.sql`, `...etapa6-operacao.sql`; leitor fiscal: `2026-10-14-etapa10-leitor-fiscal.sql` (se já aplicou antes de 14/10, rode só `2026-10-14-etapa10-correcao-bucket.sql`); por último, LGPD: `2026-10-14-mp-lgpd-reservas-MANUAL.sql`. A ordem completa está em `4-DOCUMENTOS/revisao-do-plano-completo/`.
- `funcoes/` — Edge Functions (uma pasta por função; Mercado Pago: `mp-criar`, `mp-webhook`, `mp-status`, `mp-reembolsar`). Publique pela pasta inteira.
- `testes/` — testes do banco e verificações (não vão ao Supabase em produção).
- Leia também `LEIAME.md` e `LEIA-MERCADO-PAGO-ETAPAS-1-A-5.md` dentro de `supabase-codigo/`.

Também aqui: `supabase-codigo.zip` (a mesma pasta compactada) e `Código do Supabase.html` (leitura e cópia dos arquivos).
