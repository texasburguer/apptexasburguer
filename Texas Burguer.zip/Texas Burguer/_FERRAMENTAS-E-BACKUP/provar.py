import re,sys,os
pasta=sys.argv[1]; orig=sys.argv[2]
H=open(os.path.join(pasta,'index.html'),encoding='utf-8').read()
def js(m):
    nome=m.group(1); org=m.group(2)
    c=open(os.path.join(pasta,nome),encoding='utf-8',newline='').read()
    return ('<script%s>'%(' id="%s"'%org if org and not org.startswith('__big') else ''))+c+'</script>'
def css(m):
    nome=m.group(1); org=m.group(2)
    c=open(os.path.join(pasta,nome),encoding='utf-8',newline='').read()
    assert c.startswith('@charset "utf-8";\n'); c=c[len('@charset "utf-8";\n'):]
    return ('<style%s>'%(' id="%s"'%org if org else ''))+c+'</style>'
R=re.sub(r'<script src="([^"?]+)\?v=[0-9a-f]{8}" charset="utf-8" data-origem="([^"]*)"></script>',js,H)
R=re.sub(r'<link rel="stylesheet" href="([^"?]+)\?v=[0-9a-f]{8}" data-origem="([^"]*)">',css,R)
# os pedaços do script grande ficam em tags consecutivas separadas por \n: junta num só <script>
R=re.sub(r'</script>\n<script>','',R)
O=open(orig,encoding='utf-8').read()
print('IDÊNTICO ao original' if R==O else 'DIFERENTE', len(R),len(O))
if R!=O:
    for i,(a,b) in enumerate(zip(R,O)):
        if a!=b: print('1ª diferença em',i,repr(R[i-60:i+60]),'||',repr(O[i-60:i+60])); break
