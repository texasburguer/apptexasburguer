# Notas para o Claude (leia ao receber este zip)

Estrutura: `SUBIR-NO-GITHUB/` tem a página dividida (index.html só com telas + `app-NN-*.js` + `estilo-NN-*.css` soltos, mesma pasta).
O usuário sobe pelo celular, por isso NÃO há subpastas no que vai ao GitHub.

## Regras de trabalho
- Editar o código direto no arquivo do assunto (ex.: caixa -> `app-06-caixa.js`). Não recriar o monólito.
- Ordem de carregamento = ordem das tags `<script src>` no index.html (parser-blocking, sem defer/async). Não reordenar.
- Funções/variáveis são globais (scripts clássicos). Código que roda no carregamento NÃO pode depender de símbolo de arquivo posterior
  (`app-01` ... `app-16` são o antigo script grande; `app-17` ... `app-23` vêm depois). Funções chamadas só em evento/intervalo podem estar em qualquer arquivo.
- Arquivo novo: criar `app-NN-assunto.js` ou `estilo-NN-assunto.css`, acrescentar a tag no index.html na posição certa
  (`<script src="app-NN-x.js?v=00000000" charset="utf-8"></script>` / `<link rel="stylesheet" href="estilo-NN-x.css?v=00000000">`).
- Ao terminar QUALQUER mudança, rodar `python3 _FERRAMENTAS-E-BACKUP/selar.py SUBIR-NO-GITHUB`: recalcula o `?v=` de cada arquivo no index.html
  e a LISTA do sw.js. Isso faz o aviso "Nova versão disponível" funcionar e impede mistura de versões no cache. Depois subir o SHELL do sw.js
  (`texas-shell-vNN`) como sempre.
- CSS dos arquivos `estilo-*.css` começa com `@charset "utf-8";` (não remover). Scripts levam `charset="utf-8"` na tag.
- sw.js: navegação = cópia guardada + confere a rede (aviso quando o index.html muda); `app-*.js` e `estilo-*.css` = cache primeiro pelo endereço
  completo (com `?v=`), cache `texas-codigo-v1` limpo no activate pelos itens da LISTA.
- O SW só é registrado em https (a página testa isso). Para testar localmente com Playwright, registrar manualmente.

## Verificações feitas na divisão (v22), refazer se mexer na estrutura
- Reconstrução: `python3 provar.py SUBIR-NO-GITHUB index-monolito-v21.html` (só vale para a v21 vs divisão original).
- Playwright: mesmas funções globais (1076) e símbolos léxicos (1274), mesmos erros de console, 558 handlers onclick resolvem, offline OK, update OK.
- Análise estática (acorn): nenhum código de carregamento referencia símbolo de arquivo posterior.

## Entregas
Sempre entregar UM zip `Texas Burguer.zip` com a mesma estrutura (pastas SUBIR-NO-GITHUB, SUPABASE, PLANILHAS, EXTRAS, _FERRAMENTAS-E-BACKUP),
com `SUPABASE/supabase-codigo` (pasta + .zip) e `Código do Supabase.html` atualizados. Manter o artifact "Código do Supabase" em sincronia.

## Antes de entregar (plano 10/10)
- Rodar `python3 _FERRAMENTAS-E-BACKUP/selar.py SUBIR-NO-GITHUB` e depois `python3 _FERRAMENTAS-E-BACKUP/verificar.py SUBIR-NO-GITHUB` (tem que dar APROVADO).
- `app-24-acessibilidade.js` liga cada <label> ao campo ao lado e dá nome a botões sem texto (não muda o visual). Carrega por último.
- Testes do banco em `SUPABASE/supabase-codigo/testes/` (venda/segurança e perguntas da IA). O teste SQL desfaz tudo no fim (erro de propósito "RELATORIO").
- Estado auditado em 2026-10-11: 98 tabelas com RLS; ver `ajustes/2026-10-11-seguranca-etapa1.sql`.
- Reembolso de venda paga cancelada: tabela `reembolsos` + gatilho no banco; tela em Administrador → Financeiro → Ajustes pós-venda (app-08). SQL em `ajustes/2026-10-11-reembolsos.sql`.
- Cadastro fácil (2026-10-11): `app-25-cadastro-facil.js` + `estilo-12-cadastro-facil.css`. Produto em 3 tipos (receita / comprado pronto / sem controle), receita com busca e "+ criar", copiar receita, g/ml para ingrediente em kg/l (a receita guarda em kg/l), preços em lote, abas do Estoque (ingredientes × bebidas = estoque próprio de produto), aviso "cadastro incompleto", repetição da venda quando "O custo de ... não confere".
- No banco: gatilhos de custo (`ajustes/2026-10-11-custo-automatico.sql`). Produto com receita: custo = receita (o custo enviado pela tela é ignorado). Combo com itens: soma dos produtos. `api_editar_produto` grava a receita ANTES dos preços.
- Zip: gerar SEM compressão (ZIP_STORED) e com `CONFERIR-TAMANHOS.txt` na raiz — o extrator do celular dele zerou arquivos em zips comprimidos.
- Visual (2026-10-11): `app-26-visual.js` + `estilo-13-visual.css`. Janela de ações `vsAcoes(titulo,[{t,fn,perigo}])`; listas de estoque/produtos/combos/usuários usam linha clicável + "⋯". Botão do Tex compacto nas telas internas (`.balao-ia:not(.so-icone)`); `#mainWrap` com padding-bottom 168px no celular. `#devBar` recolhível (localStorage `texas_devbar_recolhida`).
- Pente fino (2026-10-11):
  - Não usar `prompt()` do navegador: use `vsForm({ titulo, texto, ok, perigo, campos:[...] })` (app-26-visual.js), que devolve os valores ou null. Tipos: texto (com `sugestoes` = botões de motivo pronto), numero (aceita vírgula; `maiorQueZero`, `minimo`), data, escolha (`opcoes`) e `mostrarSe`.
  - Produto novo: adicionais pré-marcados pela categoria (`cfAdicionaisNovo_` em app-25); "Comprado pronto" vem sem adicionais.
  - Sistema tem 5 telas: "Backup e espaço" (`tab-armazenamento`: sb410Bk, sb410Esp e `driveCard`, nessa ordem) e "Sincronização e contingência". `abrirAdministrador('drive')` cai em armazenamento. Fotos sempre `destino:'ambos'`.
  - Planilha principal enxuta: só `acaoServidorSb_` + ajudantes (cerca de 970 linhas). A lista `SB_TABELAS_ESPELHO_` do .gs tem de bater com a lista do `enfileirar_sync()` no banco. Gatilhos antigos se apagam sozinhos (`removerGatilhosAntigosUmaVez_`). Versões antigas dos .gs ficam aqui em `_FERRAMENTAS-E-BACKUP/*-antes-do-pente-fino.gs`.
  - Contingência enxuta: sem `syncLote`/abas SB_, `getEspelho` e `guardarBackup`; `getEspelhoInterno` continua (usado por `conferirChavesContingencia` da principal).
  - O caminho antigo da página para a planilha (`postApi_`) saiu: com `USAR_SUPABASE_`, o que não estiver no `sbRotear_` devolve "não migrada".
- Imposto e iFood (2026-10-11, sw v28):
  - Imposto estimado NÃO depende da nota fiscal: `impostoPctYm_('AAAA-MM')` (app-10) lê `INTEG_.impostoMeses` (mês ≤ pedido, o mais recente) e, sem nenhum, `INTEG_.impostoPadrao` (= `fiscal_empresa.aliquota_simples`). Banco: `_imposto_pct(data)` e `sistema.ImpostoAliquotasMes`. Só o Admin recebe os valores (`api_integracoes_flags`).
  - `calcularDRE(ano, mes)` (mes 1–12) e `resumoPeriodo(p)` usam `impostoDoPeriodo_` (cada venda pela alíquota do seu mês) e tiram o DAS já estimado (`dasJaEstimado_`: categoria "Imposto das vendas (DAS)", mês = competência ou o anterior ao pagamento). O custo do produto não muda; margens de cadastro/combo usam `impostoPctHoje_()`.
  - iFood: `vendas.valor_total` = itens − desconto da loja + entrega (só se a loja entrega); comissão em `pagamentos_venda.taxa_aplicada` (estimada pela forma "iFood", trocada pela real em `ifood_repasses_gravar`). A migração com `delete` dentro de função foi cancelada pelo Supabase: `_ifood_gravar_pagamentos` zera/atualiza linhas em vez de apagar.
  - SQL: `SUPABASE/supabase-codigo/ajustes/2026-10-11-imposto-e-ifood.sql`; teste `testes/teste-imposto-e-ifood.sql`.
- Computador (2026-10-11, sw v29): `estilo-14-computador.css` (tudo em `@media (min-width:900px)`, menos `th[align=right]`).
  - Topo numa linha + `nav.tabs` sticky. Admin: `<nav id="adminLateral">` (filho direto de `#mainWrap`, antes das seções) preenchido em `montarBarrasAdmin_`; `ativarApenasSecao_` liga `body.adm-ativo` e o `#mainWrap` vira grade (menu | seção). As seções têm de continuar filhas diretas de `#mainWrap`.
  - Caixa: divs `cx-2col` / `cx-col` / `cx-lado` nos painéis Cliente, Itens e Finalizar (no celular são divs sem estilo). Pedidos: `#pedidosLista`, `#entregasLista`, `#mesasAtendimentoLista` e as concluídas em grade.
  - Visão Geral: `.vg-stats` com `--vg-cols` (4 ou 5). Gráfico do DRE usa a largura real do `#rGrafico`.
  - `formatarMoeda` com ponto de milhar e "−R$" (U+2212) no negativo.
  - Para testar no PC: `scratchpad/pc/shots.py <pasta> <saida> <largura>` com dados de exemplo em `pc/mock.js` (não vão no zip).
- Visitas ao cardápio (2026-10-11, sw v30): `cdContarVisita_` (app-15) → `api_registrar_visita_cardapio`; Início (app-05) busca `visitasCardapioHoje` (no máx. 1×/min). Aparelho da equipe marcado em `entrarNoApp` (`cdAparelhoEquipe`). SQL em `ajustes/2026-10-11-visitas-cardapio.sql` (o conector do Supabase perdeu permissão nesta etapa: o usuário roda o SQL).
