# Notas para o Claude (leia ao receber este zip)

Estrutura: `SUBIR-NO-GITHUB/` tem a página dividida (index.html só com telas + `app-NN-*.js` + `estilo-NN-*.css` soltos, mesma pasta).
O usuário sobe pelo celular, por isso NÃO há subpastas no que vai ao GitHub.

## Regras de trabalho
- Editar o código direto no arquivo do assunto (ex.: caixa -> `app-06-caixa.js`). Não recriar o monólito.
- Ordem de carregamento = ordem das tags `<script src>` no index.html (parser-blocking, sem defer/async). Não reordenar.
- Funções/variáveis são globais (scripts clássicos). Código que roda no carregamento NÃO pode depender de símbolo de arquivo posterior
  (`app-01` ... `app-16` são o antigo script grande; `app-17` ... `app-23` vêm depois). Funções chamadas só em evento/intervalo podem estar em qualquer arquivo.
- Arquivo novo: criar `app-NN-assunto.js` ou `estilo-NN-assunto.css`, acrescentar a tag no index.html na posição certa
  (`<script src="app-NN-x.js?v=00000000" charset="utf-8"></script>` / `<link rel="stylesheet" href="estilo-NN-x.css?v=00000000">`).
- Ao terminar QUALQUER mudança, rodar `python3 _FERRAMENTAS-E-BACKUP/selar.py SUBIR-NO-GITHUB`: recalcula o `?v=` de cada arquivo no index.html
  e a LISTA do sw.js. Isso faz o aviso "Nova versão disponível" funcionar e impede mistura de versões no cache. Depois subir o SHELL do sw.js
  (`texas-shell-vNN`) como sempre.
- CSS dos arquivos `estilo-*.css` começa com `@charset "utf-8";` (não remover). Scripts levam `charset="utf-8"` na tag.
- sw.js: navegação = cópia guardada + confere a rede (aviso quando o index.html muda); `app-*.js` e `estilo-*.css` = cache primeiro pelo endereço
  completo (com `?v=`), cache `texas-codigo-v1` limpo no activate pelos itens da LISTA.
- O SW só é registrado em https (a página testa isso). Para testar localmente com Playwright, registrar manualmente.

## Verificações feitas na divisão (v22), refazer se mexer na estrutura
- Reconstrução: `python3 provar.py SUBIR-NO-GITHUB index-monolito-v21.html` (só vale para a v21 vs divisão original).
- Playwright: mesmas funções globais (1076) e símbolos léxicos (1274), mesmos erros de console, 558 handlers onclick resolvem, offline OK, update OK.
- Análise estática (acorn): nenhum código de carregamento referencia símbolo de arquivo posterior.

## Entregas
Sempre entregar UM zip `Texas Burguer.zip` com a mesma estrutura (pastas SUBIR-NO-GITHUB, SUPABASE, PLANILHAS, EXTRAS, _FERRAMENTAS-E-BACKUP),
com `SUPABASE/supabase-codigo` (pasta + .zip) e `Código do Supabase.html` atualizados. Manter o artifact "Código do Supabase" em sincronia.

## Antes de entregar (plano 10/10)
- Rodar `python3 _FERRAMENTAS-E-BACKUP/selar.py SUBIR-NO-GITHUB` e depois `python3 _FERRAMENTAS-E-BACKUP/verificar.py SUBIR-NO-GITHUB` (tem que dar APROVADO).
- `app-24-acessibilidade.js` liga cada <label> ao campo ao lado e dá nome a botões sem texto (não muda o visual). Carrega por último.
- Testes do banco em `SUPABASE/supabase-codigo/testes/` (venda/segurança e perguntas da IA). O teste SQL desfaz tudo no fim (erro de propósito "RELATORIO").
- Estado auditado em 2026-10-11: 98 tabelas com RLS; ver `ajustes/2026-10-11-seguranca-etapa1.sql`.
- Reembolso de venda paga cancelada: tabela `reembolsos` + gatilho no banco; tela em Administrador → Financeiro → Ajustes pós-venda (app-08). SQL em `ajustes/2026-10-11-reembolsos.sql`.
