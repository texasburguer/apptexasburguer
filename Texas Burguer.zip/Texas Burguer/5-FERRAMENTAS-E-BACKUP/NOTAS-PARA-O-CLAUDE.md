# Notas para o Claude (leia ao receber este zip)

Estrutura: `1-SUBIR-NO-GITHUB/` tem a página dividida (index.html só com telas + `app-NN-*.js` + `estilo-NN-*.css` soltos, mesma pasta).
O usuário sobe pelo celular, por isso NÃO há subpastas no que vai ao GitHub.

## Regras de trabalho
- Editar o código direto no arquivo do assunto (ex.: caixa -> `app-06-caixa.js`). Não recriar o monólito.
- Ordem de carregamento = ordem das tags `<script src>` no index.html (parser-blocking, sem defer/async). Não reordenar.
- Funções/variáveis são globais (scripts clássicos). Código que roda no carregamento NÃO pode depender de símbolo de arquivo posterior
  (`app-01` ... `app-16` são o antigo script grande; `app-17` ... `app-23` vêm depois). Funções chamadas só em evento/intervalo podem estar em qualquer arquivo.
- Arquivo novo: criar `app-NN-assunto.js` ou `estilo-NN-assunto.css`, acrescentar a tag no index.html na posição certa
  (`<script src="app-NN-x.js?v=00000000" charset="utf-8"></script>` / `<link rel="stylesheet" href="estilo-NN-x.css?v=00000000">`).
- Ao terminar QUALQUER mudança, rodar `python3 5-FERRAMENTAS-E-BACKUP/selar.py 1-SUBIR-NO-GITHUB`: recalcula o `?v=` de cada arquivo no index.html
  e a LISTA do sw.js. Isso faz o aviso "Nova versão disponível" funcionar e impede mistura de versões no cache. Depois subir o SHELL do sw.js
  (`texas-shell-vNN`) como sempre.
- CSS dos arquivos `estilo-*.css` começa com `@charset "utf-8";` (não remover). Scripts levam `charset="utf-8"` na tag.
- sw.js: navegação = cópia guardada + confere a rede (aviso quando o index.html muda); `app-*.js` e `estilo-*.css` = cache primeiro pelo endereço
  completo (com `?v=`), cache `texas-codigo-v1` limpo no activate pelos itens da LISTA.
- O SW só é registrado em https (a página testa isso). Para testar localmente com Playwright, registrar manualmente.

## Verificações feitas na divisão (v22), refazer se mexer na estrutura
- Reconstrução: `python3 provar.py 1-SUBIR-NO-GITHUB index-monolito-v21.html` (só vale para a v21 vs divisão original).
- Playwright: mesmas funções globais (1076) e símbolos léxicos (1274), mesmos erros de console, 558 handlers onclick resolvem, offline OK, update OK.
- Análise estática (acorn): nenhum código de carregamento referencia símbolo de arquivo posterior.

## Entregas
Sempre entregar UM zip `Texas Burguer.zip` com a mesma estrutura (pastas 1-SUBIR-NO-GITHUB, 2-PLANILHAS-GOOGLE, 3-SUPABASE, 4-DOCUMENTOS, 5-FERRAMENTAS-E-BACKUP, 6-EXTRAS),
com `3-SUPABASE/supabase-codigo` (pasta + .zip) e `Código do Supabase.html` atualizados. Manter o artifact "Código do Supabase" em sincronia.

## Antes de entregar (plano 10/10)
- Rodar `python3 5-FERRAMENTAS-E-BACKUP/selar.py 1-SUBIR-NO-GITHUB` e depois `python3 5-FERRAMENTAS-E-BACKUP/verificar.py 1-SUBIR-NO-GITHUB` (tem que dar APROVADO).
- `app-24-acessibilidade.js` liga cada <label> ao campo ao lado e dá nome a botões sem texto (não muda o visual). Carrega por último.
- Testes do banco em `3-SUPABASE/supabase-codigo/testes/` (venda/segurança e perguntas da IA). O teste SQL desfaz tudo no fim (erro de propósito "RELATORIO").
- Estado auditado em 2026-10-11: 98 tabelas com RLS; ver `ajustes/2026-10-11-seguranca-etapa1.sql`.
- Reembolso de venda paga cancelada: tabela `reembolsos` + gatilho no banco; tela em Administrador → Financeiro → Ajustes pós-venda (app-08). SQL em `ajustes/2026-10-11-reembolsos.sql`.
- Cadastro fácil (2026-10-11): `app-25-cadastro-facil.js` + `estilo-12-cadastro-facil.css`. Produto em 3 tipos (receita / comprado pronto / sem controle), receita com busca e "+ criar", copiar receita, g/ml para ingrediente em kg/l (a receita guarda em kg/l), preços em lote, abas do Estoque (ingredientes × bebidas = estoque próprio de produto), aviso "cadastro incompleto", repetição da venda quando "O custo de ... não confere".
- No banco: gatilhos de custo (`ajustes/2026-10-11-custo-automatico.sql`). Produto com receita: custo = receita (o custo enviado pela tela é ignorado). Combo com itens: soma dos produtos. `api_editar_produto` grava a receita ANTES dos preços.
- Zip: gerar SEM compressão (ZIP_STORED) e com `CONFERIR-TAMANHOS.txt` na raiz — o extrator do celular dele zerou arquivos em zips comprimidos.
- Visual (2026-10-11): `app-26-visual.js` + `estilo-13-visual.css`. Janela de ações `vsAcoes(titulo,[{t,fn,perigo}])`; listas de estoque/produtos/combos/usuários usam linha clicável + "⋯". Botão do Tex compacto nas telas internas (`.balao-ia:not(.so-icone)`); `#mainWrap` com padding-bottom 168px no celular. `#devBar` recolhível (localStorage `texas_devbar_recolhida`).
- Pente fino (2026-10-11):
  - Não usar `prompt()` do navegador: use `vsForm({ titulo, texto, ok, perigo, campos:[...] })` (app-26-visual.js), que devolve os valores ou null. Tipos: texto (com `sugestoes` = botões de motivo pronto), numero (aceita vírgula; `maiorQueZero`, `minimo`), data, escolha (`opcoes`) e `mostrarSe`.
  - Produto novo: adicionais pré-marcados pela categoria (`cfAdicionaisNovo_` em app-25); "Comprado pronto" vem sem adicionais.
  - Sistema tem 5 telas: "Backup e espaço" (`tab-armazenamento`: sb410Bk, sb410Esp e `driveCard`, nessa ordem) e "Sincronização e contingência". `abrirAdministrador('drive')` cai em armazenamento. Fotos sempre `destino:'ambos'`.
  - Planilha principal enxuta: só `acaoServidorSb_` + ajudantes (cerca de 970 linhas). A lista `SB_TABELAS_ESPELHO_` do .gs tem de bater com a lista do `enfileirar_sync()` no banco. Gatilhos antigos se apagam sozinhos (`removerGatilhosAntigosUmaVez_`). Versões antigas dos .gs ficam aqui em `5-FERRAMENTAS-E-BACKUP/*-antes-do-pente-fino.gs`.
  - Contingência enxuta: sem `syncLote`/abas SB_, `getEspelho` e `guardarBackup`; `getEspelhoInterno` continua (usado por `conferirChavesContingencia` da principal).
  - O caminho antigo da página para a planilha (`postApi_`) saiu: com `USAR_SUPABASE_`, o que não estiver no `sbRotear_` devolve "não migrada".
- Imposto e iFood (2026-10-11, sw v28):
  - Imposto estimado NÃO depende da nota fiscal: `impostoPctYm_('AAAA-MM')` (app-10) lê `INTEG_.impostoMeses` (mês ≤ pedido, o mais recente) e, sem nenhum, `INTEG_.impostoPadrao` (= `fiscal_empresa.aliquota_simples`). Banco: `_imposto_pct(data)` e `sistema.ImpostoAliquotasMes`. Só o Admin recebe os valores (`api_integracoes_flags`).
  - `calcularDRE(ano, mes)` (mes 1–12) e `resumoPeriodo(p)` usam `impostoDoPeriodo_` (cada venda pela alíquota do seu mês) e tiram o DAS já estimado (`dasJaEstimado_`: categoria "Imposto das vendas (DAS)", mês = competência ou o anterior ao pagamento). O custo do produto não muda; margens de cadastro/combo usam `impostoPctHoje_()`.
  - iFood: `vendas.valor_total` = itens − desconto da loja + entrega (só se a loja entrega); comissão em `pagamentos_venda.taxa_aplicada` (estimada pela forma "iFood", trocada pela real em `ifood_repasses_gravar`). A migração com `delete` dentro de função foi cancelada pelo Supabase: `_ifood_gravar_pagamentos` zera/atualiza linhas em vez de apagar.
  - SQL: `3-SUPABASE/supabase-codigo/ajustes/2026-10-11-imposto-e-ifood.sql`; teste `testes/teste-imposto-e-ifood.sql`.
- Computador (2026-10-11, sw v29): `estilo-14-computador.css` (tudo em `@media (min-width:900px)`, menos `th[align=right]`).
  - Topo numa linha + `nav.tabs` sticky. Admin: `<nav id="adminLateral">` (filho direto de `#mainWrap`, antes das seções) preenchido em `montarBarrasAdmin_`; `ativarApenasSecao_` liga `body.adm-ativo` e o `#mainWrap` vira grade (menu | seção). As seções têm de continuar filhas diretas de `#mainWrap`.
  - Caixa: divs `cx-2col` / `cx-col` / `cx-lado` nos painéis Cliente, Itens e Finalizar (no celular são divs sem estilo). Pedidos: `#pedidosLista`, `#entregasLista`, `#mesasAtendimentoLista` e as concluídas em grade.
  - Visão Geral: `.vg-stats` com `--vg-cols` (4 ou 5). Gráfico do DRE usa a largura real do `#rGrafico`.
  - `formatarMoeda` com ponto de milhar e "−R$" (U+2212) no negativo.
  - Para testar no PC: `scratchpad/pc/shots.py <pasta> <saida> <largura>` com dados de exemplo em `pc/mock.js` (não vão no zip).
- Visitas ao cardápio (2026-10-11, sw v30): `cdContarVisita_` (app-15) → `api_registrar_visita_cardapio`; Início (app-05) busca `visitasCardapioHoje` (no máx. 1×/min). Aparelho da equipe marcado em `entrarNoApp` (`cdAparelhoEquipe`). SQL em `ajustes/2026-10-11-visitas-cardapio.sql` (o conector do Supabase perdeu permissão nesta etapa: o usuário roda o SQL).
- (FEITO em 2026-10-12, sw v31) Ajuste do "flash" do cardápio ao abrir logado: `txbSplash` no topo do index.html + `txbSplashFim_()` em app-01/app-16. Receita em `4-DOCUMENTOS/receitas-de-outros-projetos/2026-10-12-flash-cardapio`.
- Conta de cliente (2026-10-12, sw v31): login Google opcional. Front: `app-27-conta-cliente.js` + `estilo-15-conta.css`; sessão do cliente em `txbContaSb_v1` (separada da equipe `texasBurgerSb_v1`); pedido/cupom do cardápio vão com o token do cliente (`contaTokenOuNull_`, em `sbRpcPublico_` no app-01). Central de Promoções ampliada no app-02 (`renderCuponsUI`, `CUP_AUTO_`, cartão LGPD).
  - Banco: tabelas `contas_cliente`, `contas_pedidos`, `contas_enderecos`, `cupons_concedidos` (RLS sem políticas; só funções `api_conta_*`, que recusam a equipe). Cupons automáticos (`cupons.automatico`) nascem desligados. Cancelamento: devolve cupom, ignora venda cancelada na contagem e anula prêmio de indicação não usado. Anonimização após `LgpdAnosAnonimizar` (3) anos, casando também por telefone (`vendas.cliente_id` do cardápio vem nulo).
  - O conector do Supabase CANCELA qualquer SQL com `delete from` dentro de função: esse trecho vai em `ajustes/2026-10-12-contas-clientes-MANUAL.sql` para o usuário colar (excluir endereço, apagar conta, limpezas, `drop function _teste_palavra`). Apagar conta não foi testado automaticamente.
  - LIMITAÇÃO: telefone não verificado. Aviso de Privacidade sem CNPJ/razão social até o usuário informar (cartão Privacidade em Promoções). Contato = WhatsApp do Texas.
  - Teste: `testes/teste-contas-clientes.sql` (22 verificações, termina em "RELATORIO"). Receita: `4-DOCUMENTOS/receitas-de-outros-projetos/2026-10-12-conta-cliente`.
  - Fora desta entrega (combinado): responder feedbacks pela página e acompanhamento melhorado com conta; fidelidade configurável.
- Brindes da conta + ajustes (2026-10-12, sw v32): produtos marcados `premio_fidelidade`/`premio_indicacao` são os brindes. Banco: `contas_beneficios`, `api_conta_beneficios()`, `api_criar_pedido_cardapio` com `beneficios:[{tipo,id,produtoId}]` (item a R$ 0 com custo, baixa estoque, entrega cobrada, sem despesa extra; cancelar devolve). Quem indica ganha brinde (se há produto prêmio de indicação) E/OU cupom `indicacao_indicador` (se ligado); `_conta_premiar_indicacao` dá os dois, cada um só se ativo. Cliente logado NÃO está em `usuarios` (guarda em `_ajustar_estoque`). Front: faixa `#cdContaBar` abaixo do banner (botão `#cdContaBtn`), brindes em `window.contaBrindesEscolhidos_` (app-27) lidos por `cdBrindes_()` (app-15; carrinho, FAB, total, payload; pedido com brinde não usa contingência), cartão `.punch` na Minha conta, data com `color-scheme`. Testes: `testes/teste-brindes-conta.sql`. Receita: `4-DOCUMENTOS/receitas-de-outros-projetos/2026-10-12-brindes-e-ajustes-da-conta`.
- Conector do Supabase também cancelou UPDATE em `ai_ajuda` (12/10): texto da ajuda vai em `ajustes/2026-10-12-ajuda-brindes.sql` e o SQL é dado ao usuário no chat.
- Feedback na conta (2026-10-12, sw v33): `feedbacks.user_id/resposta/respondido_em/respondido_por`; `api_add_feedback` pega a conta por `auth.uid()` (front manda o token do cliente para ela em `sbRpcPublico_`), um feedback por pedido/conta; `api_responder_feedback` (Admin/Operador, status vira Respondido); `api_conta_pedidos` traz `feedback`. Front: botão "⭐ Feedback" nos pedidos (app-27), tela de resposta em `responderFeedback` (app-12, usa `vsForm` com campo `longo`), WhatsApp para feedback sem conta. O feedback do rodapé continua aceitando anônimos. Receita: `4-DOCUMENTOS/receitas-de-outros-projetos/2026-10-12-feedback-na-conta-e-resposta`.

- Mercado Pago, revisão (2026-10-13, sw v37): telas em `estilo-16-pagamento.css` (classes `mp-*`; vale também para o card do Admin em `mpCardHtml_`, app-11). Em `app-15`: botões de forma (`cdRenderFormas_`, o `<select id="cdFormaPagamento">` continua existindo escondido e é ele quem guarda o valor), resumo (`cdRenderResumoPag_`), rótulo do botão (`cdRotuloEnviar_`), acompanhamento pela `mp-status` (`cdMpAcompanhar_`, com `cdMpPollId_` para parar de verdade), tela de aprovado (`cdMpAprovar_`) e `cdWaPedido_` (monta a mensagem do WhatsApp). A CSP do index.html libera `*.mercadopago.com`, `*.mercadolibre.com` e `*.mlstatic.com` (script, frame, connect, style, font): se trocar o provedor, revisar. Cada forma de pagamento é só online ou só entrega (`formas_pagamento.tipo_online`). Ver `4-DOCUMENTOS/revisao-do-plano-completo/REVISAO-DO-PLANO-COMPLETO.md`.

- Organização (2026-10-14): o zip tem 6 pastas numeradas: 1 = o que vai ao GitHub, 2 = planilhas do Google, 3 = Supabase (SQL e funções), 4 = documentos (planos, relatórios, receitas), 5 = ferramentas e backup, 6 = extras. As ferramentas e os scripts de verificação já usam esses nomes. Os documentos antigos dos textos citam os nomes antigos das pastas (SUBIR-NO-GITHUB, SUPABASE, PLANILHAS).
- Revisão do plano completo (2026-10-14): Leitor Fiscal (bucket só da equipe, fotos órfãs, leitura esquecida, descartar apaga foto), resumo operacional sem contagem em dobro e LGPD das reservas (`ajustes/2026-10-14-mp-lgpd-reservas-MANUAL.sql`). `Código do Supabase.html` agora inclui Mercado Pago e Leitor Fiscal.

- Contas e acessos em sub-menus (2026-10-15, sw v40): `tab-contas` usa `abaInterna_('tab-contas', 'contas'|'ias'|'ifood'|'nfce'|'mercadopago')` (cards com `data-painel`). Cada integração renderiza em `#integLista_<provedor>` e mostra mensagens em `#integMsg_<provedor>` (`integMsgId_()` escolhe pela aba aberta). `integResumoHtml_` desenha o quadro "👉 Próximo passo" (iFood/NFC-e em `integCardHtml_`, Mercado Pago dentro de `mpCardHtml_`). `ifoodExtraHtml_(it,'setup'|'dia')` e `fiscalExtraHtml_(it,'setup'|'dia')` separam cadastro de uso diário. Atalho: `abrirAdministrador('ifood'|'nfce'|'mercadopago'|'ias')`. CSS em `estilo-17-contas.css`.
- Mercado Pago no banco (2026-10-15): aplicadas via conector as Etapas 4 e 6 (migrations mp_etapa4_parte1/2/3 e mp_etapa6) que estavam só locais. As 4 Edge Functions mp-criar, mp-webhook, mp-status e mp-reembolsar foram PUBLICADAS no Supabase em 15/10/2026 pelo conector (verify_jwt=false, código igual ao das pastas funcoes/mp-*). Ainda sem chaves do Mercado Pago cadastradas e sem teste real.

- Cartão de débito online (2026-10-15): `formas_pagamento.tipo_online` e `pagamentos_online.metodo` aceitam 'pix' | 'credito' | 'debito'. Na Admin, cada forma tem só 2 opções (Só na entrega / Também online); o tipo é deduzido do NOME da forma (Pix, Crédito, Débito) no banco (`api_mp_forma_online`) e na tela (`mpTipoDoNome_`). Cardápio: `cdMpAbrirCartao_(reserva,cfg,tipo)` abre o Brick só com crédito OU só com débito; `mp-criar` (v2) manda `type: debit_card` quando a forma é débito. Teste guiado exige teste aprovado de CADA forma online ligada. Ainda não testado com o Mercado Pago de verdade.
