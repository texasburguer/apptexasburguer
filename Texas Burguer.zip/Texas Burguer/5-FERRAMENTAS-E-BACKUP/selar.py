#!/usr/bin/env python3
"""Selar: recalcula a impressão digital (?v=) de cada app-*.js e estilo-*.css no index.html e regrava a LISTA do sw.js.
Uso (na pasta 1-SUBIR-NO-GITHUB):  python3 selar.py"""
import re,hashlib,os,sys
pasta=sys.argv[1] if len(sys.argv)>1 else '.'
ih=os.path.join(pasta,'index.html'); sw=os.path.join(pasta,'sw.js')
H=open(ih,encoding='utf-8').read(); usados=[]
def h8(nome):
    return hashlib.sha1(open(os.path.join(pasta,nome),encoding='utf-8',newline='').read().encode('utf-8')).hexdigest()[:8]
def f(m):
    nome=m.group(2); usados.append('%s?v=%s'%(nome,h8(nome))); return '%s%s?v=%s'%(m.group(1),nome,h8(nome))
H2=re.sub(r'((?:src|href)=")((?:app|estilo)-[^"?]+\.(?:js|css))\?v=[0-9a-f]{8}',f,H)
if H2!=H: open(ih,'w',encoding='utf-8',newline='').write(H2)
S=open(sw,encoding='utf-8').read()
lista='/*LISTA-INICIO*/\n'+''.join("  '%s',\n"%u for u in usados)+'/*LISTA-FIM*/'
S2=re.sub(r'/\*LISTA-INICIO\*/.*?/\*LISTA-FIM\*/',lambda m:lista,S,flags=re.S)
if S2!=S: open(sw,'w',encoding='utf-8',newline='').write(S2)
print('selado:',len(usados),'arquivos; index.html',('atualizado' if H2!=H else 'sem mudança'),'; sw.js',('atualizado' if S2!=S else 'sem mudança'))
