-- Teste do feedback ligado à conta + resposta da equipe · 2026-10-12 · NÃO deixa nada no banco (termina com o erro de propósito "RELATORIO")
-- Como usar: Supabase → SQL Editor → cole tudo → Run. Leia o relatório que aparece no erro.
do $t$
declare
  u uuid := gen_random_uuid(); r text := ''; x jsonb; v1 uuid; v2 uuid; adm uuid; fid uuid; fid2 uuid;
  forma uuid; prod uuid;
begin
  select f.id, pp.produto_id into forma, prod
    from formas_pagamento f join produto_precos pp on pp.forma_pagamento_id = f.id join produtos p on p.id = pp.produto_id and p.ativo
   where f.ativa and f.visivel_cardapio order by f.ordem limit 1;
  if forma is null then raise exception 'RELATORIO sem forma/produto para testar'; end if;
  select id into adm from usuarios where nivel = 'Admin' and ativo limit 1;
  if adm is null then raise exception 'RELATORIO sem usuário Admin para testar'; end if;
  insert into caixa_sessoes (status) select 'Aberto' where not exists (select 1 from caixa_sessoes where status = 'Aberto');
  insert into auth.users (id, email, aud, role, raw_user_meta_data) values (u, 'teste-fb@example.com', 'authenticated', 'authenticated', '{"full_name":"Cliente Teste"}');
  perform set_config('request.jwt.claims', json_build_object('sub', u, 'role', 'authenticated')::text, true);
  set local role authenticated;
  perform api_conta_iniciar('{}'::jsonb); perform api_conta_aceitar('{"aceito":true}'::jsonb);
  x := api_criar_pedido_cardapio(jsonb_build_object('clienteNome','Cliente Teste','clienteTelefone','17999001122','tipoEntrega','Retirada','formaPagamentoId',forma,'requisicaoId','tf1','itens',jsonb_build_array(jsonb_build_object('produtoId',prod,'quantidade',1))));
  v1 := (x->>'id')::uuid; r := concat(r, '1 pedido da conta (esperado true): ', (x->>'ok'), E'\n');
  x := api_add_feedback(jsonb_build_object('vendaId', v1, 'nota', 4, 'comentario', 'Muito bom', 'origem', 'formulario'));
  r := concat(r, '2 feedback com conta (esperado true): ', (x->>'ok'), E'\n');
  reset role;
  select id into fid from feedbacks where venda_id = v1 and user_id = u;
  r := concat(r, '3 gravou a conta, o pedido e o telefone da conta (esperado 1 | telefone vazio, pois a conta ainda não tem telefone): ', (select count(*) from feedbacks where venda_id = v1 and user_id = u), ' | ', (select coalesce(telefone_cliente, '-') from feedbacks where id = fid), E'\n');
  set local role authenticated;
  x := api_add_feedback(jsonb_build_object('vendaId', v1, 'nota', 5));
  r := concat(r, '4 segundo feedback do mesmo pedido (esperado false): ', (x->>'ok'), E'\n');
  select id into v2 from vendas where id <> v1 and origem::text = 'Cardápio' limit 1;
  x := api_add_feedback(jsonb_build_object('vendaId', v2, 'nota', 2, 'comentario', 'pedido de outra pessoa'));
  r := concat(r, '5 feedback citando pedido que não é da conta (esperado true, sem pedido ligado): ', (x->>'ok'), E'\n');
  x := api_conta_pedidos();
  r := concat(r, '6 Pedidos traz o feedback (esperado nota 4, sem resposta): ', (x->'pedidos'->0->'feedback'->>'nota'), ' / ', coalesce(x->'pedidos'->0->'feedback'->>'resposta', 'sem resposta'), E'\n');
  x := api_responder_feedback(jsonb_build_object('id', fid, 'resposta', 'tentando'));
  r := concat(r, '7 cliente respondendo feedback (esperado false): ', (x->>'ok'), E'\n');
  reset role;
  select id into fid2 from feedbacks where user_id = u and venda_id is null;
  r := concat(r, '8 pedido de outra pessoa ficou sem venda_id (esperado 1): ', (select count(*) from feedbacks where id = fid2 and venda_id is null), E'\n');
  -- equipe responde
  perform set_config('request.jwt.claims', json_build_object('sub', adm, 'role', 'authenticated')::text, true);
  set local role authenticated;
  x := api_responder_feedback(jsonb_build_object('id', fid, 'resposta', ''));
  r := concat(r, '9 resposta vazia (esperado false): ', (x->>'ok'), E'\n');
  x := api_responder_feedback(jsonb_build_object('id', fid, 'resposta', 'Obrigado, Cliente! Volte sempre.'));
  r := concat(r, '10 equipe responde (esperado true e comConta true): ', (x->>'ok'), ' / ', (x->>'comConta'), E'\n');
  reset role;
  r := concat(r, '11 status virou Respondido e guardou quem respondeu: ', (select status || ' por ' || coalesce(nullif(respondido_por, ''), '(sem nome)') from feedbacks where id = fid), E'\n');
  perform set_config('request.jwt.claims', json_build_object('sub', u, 'role', 'authenticated')::text, true);
  set local role authenticated;
  x := api_conta_pedidos();
  r := concat(r, '12 cliente vê a resposta (esperado o texto): ', (x->'pedidos'->0->'feedback'->>'resposta'), E'\n');
  x := api_conta_exportar();
  r := concat(r, '13 exportar inclui feedbacks (esperado 2): ', jsonb_array_length(x->'feedbacks'), E'\n');
  reset role;
  -- visitante
  perform set_config('request.jwt.claims', '', true);
  set local role anon;
  x := api_add_feedback(jsonb_build_object('nota', 5, 'telefone', '17988776655', 'comentario', 'visitante'));
  r := concat(r, '14 visitante sem conta envia feedback (esperado true): ', (x->>'ok'), E'\n');
  reset role;
  r := concat(r, '15 feedback de visitante sem conta ligada (esperado 1 sem user_id): ', (select count(*) from feedbacks where telefone_cliente = '17988776655' and user_id is null), E'\n');
  perform set_config('request.jwt.claims', json_build_object('sub', adm, 'role', 'authenticated')::text, true);
  set local role authenticated;
  x := api_responder_feedback(jsonb_build_object('id', (select id from feedbacks where telefone_cliente = '17988776655' limit 1), 'resposta', 'Valeu!'));
  r := concat(r, '16 responder visitante (esperado true e comConta false): ', (x->>'ok'), ' / ', (x->>'comConta'), E'\n');
  reset role;
  raise exception E'RELATORIO\n%', r;
end $t$;
