# Receita: feedback ligado à conta do cliente + resposta da equipe

Complementa `2026-10-12-conta-cliente` e `2026-10-12-brindes-e-ajustes-da-conta` (aplique antes).

## O que muda para o cliente
- Em Minha conta › Pedidos, cada pedido (menos cancelado) tem o botão "⭐ Feedback": nota 1–5 + comentário. Um feedback por pedido e por conta; o pedido precisa ser da conta.
- Depois de enviado, o pedido mostra a nota, o comentário e, quando a equipe responder, "💬 Resposta do restaurante".
- O botão de feedback do rodapé continua igual e aceita anônimos e quem não fez login. Se a pessoa estiver logada, o feedback do rodapé também fica ligado à conta.
- "Baixar meus dados" inclui os feedbacks e respostas.

## O que muda para a equipe
- Painel → Feedbacks (e Operação → Feedbacks): marca "👤 com conta" / "sem conta", botão "💬 Responder" (até 1000 letras, editável) e, sem conta e com telefone, botão "WhatsApp". Responder marca como "Respondido" e guarda quem respondeu e quando.

## Regras técnicas
- `feedbacks` ganha `user_id` (FK auth.users, ON DELETE SET NULL), `resposta`, `respondido_em`, `respondido_por`.
- `api_add_feedback` descobre a conta por `auth.uid()` (o front manda o token do cliente também para esta função: ver `sbRpcPublico_`). Sem conta nada muda.
- `api_responder_feedback` (Admin/Operador). `api_conta_pedidos` devolve `feedback` por pedido. `api_conta_exportar` inclui `feedbacks`.
- `vsForm` ganhou o tipo de campo `longo` (textarea).
- Resposta só aparece para o cliente se o feedback foi dado logado (com `user_id`).

## Passo a passo
1. Rode `2-banco/2026-10-12-feedback-conta.sql` e `2-banco/2026-10-12-ajuda-feedback-conta.sql`. Teste: `teste-feedback-conta.sql` (16 verificações, não grava nada).
2. Front: copie `3-arquivos-novos/*` (app-27 e estilo-15 completos) e aplique os `.diff` de `1-mudancas-nos-arquivos/`.
3. `selar.py` → `verificar.py` (APROVADO) → suba o SHELL do `sw.js`.
