# Receita: sem "flash" do cardápio ao abrir o sistema já logado

## Problema
Na equipe, ao abrir o app com a sessão salva, o cardápio do cliente aparecia por um instante antes do sistema.

## Solução (3 pontos, sem banco)
1. `index.html`, logo depois da meta Content-Security-Policy, bloco `txbSplashCss` + `txbSplash`: se existir `localStorage['texasBurgerSessao_v2']` (troque pela SESSAO_KEY do projeto), a tag `<html>` ganha a classe `txb-equipe`, que cobre a tela com o fundo e a logo (troque o arquivo da logo). Trava de 8 s tira a cobertura se algo falhar.
2. `app-01` (`entrarNoApp`): ao terminar, dois `requestAnimationFrame` e `txbSplashFim_()`, para a logo sair só com o sistema já desenhado.
3. `app-16` (`tentarRestaurarSessao`): se a sessão salva não vale, chama `txbSplashFim_()` antes de `carregarCardapioPublico()`.
Cliente sem sessão da equipe: nada muda.

## Como fazer
Aplique os trechos abaixo (copiados dos diffs da conta de cliente), rode `selar.py` e suba o SHELL do `sw.js`.

## Como testar
Entre como equipe, feche e reabra o app: deve aparecer só a logo e depois o sistema, sem o cardápio no meio.

## Código
### index.html (colar após a meta CSP)
<!-- Aparelho da equipe com sessão salva: mostra só o fundo e a logo até o sistema abrir (o cardápio público não "pisca" antes do login). Cliente sem login: nada muda. -->
<style id="txbSplashCss">html.txb-equipe::before{content:"";position:fixed;left:0;top:0;right:0;bottom:0;z-index:2147483000;background:#0b0705 url(logo-texas-burger.webp) center center/min(52vw,210px) auto no-repeat;}</style>
<script id="txbSplash">(function(){var h=document.documentElement;window.txbSplashFim_=function(){try{h.classList.remove('txb-equipe');}catch(e){}};try{if(localStorage.getItem('texasBurgerSessao_v2')){h.classList.add('txb-equipe');setTimeout(window.txbSplashFim_,8000);}}catch(e){}})();</script>

### app-01 (final de entrarNoApp)
  try{ requestAnimationFrame(()=>requestAnimationFrame(()=>{ if(window.txbSplashFim_) window.txbSplashFim_(); })); }catch(e){ if(window.txbSplashFim_) window.txbSplashFim_(); }

### app-16 (em tentarRestaurarSessao, antes de carregarCardapioPublico)
  if(window.txbSplashFim_) window.txbSplashFim_();
