# Receita: visual mais limpo (listas compactas, botão do assistente, Modo Desenvolvedor)

## O que mudou
- Listas de Estoque, Produtos, Combos e Usuários: no lugar de vários botões por linha, um "⋯". Tocar na linha (ou no ⋯) abre uma janela com as ações. Produto e combo: tocar na linha já abre a edição.
- Botão do assistente nas telas da equipe: vira só o ícone redondo (sem o texto), com o número de avisos; a página ganha espaço no fim para ele não cobrir botões.
- Caixa do Modo Desenvolvedor recolhível (lembra a escolha no aparelho).
- Visão Geral: aviso quando há produto sem custo (lucro e margem ficariam maiores que a realidade). Depende da receita "cadastro fácil" (função cfProdutosSemCusto_).

## Onde
- Arquivos novos: `1-arquivos-novos/app-26-visual.js` e `estilo-13-visual.css`.
- Mudanças: `2-mudancas-nos-arquivos/*.diff` (app-03: linhas das listas; app-11: usuários; app-14: aviso na Visão Geral; index.html: inclui os 2 arquivos e um texto; app-09/app-01: ajuda e novidades).
- Banco (ajuda da IA): `2026-10-11-ajuda-listas-compactas.sql`.

## Como fazer
1. Copie os 2 arquivos novos e acrescente no index.html, depois do último script:
   `<link rel="stylesheet" href="estilo-13-visual.css?v=00000000">` e `<script src="app-26-visual.js?v=00000000" charset="utf-8"></script>`.
2. Aplique os `.diff` (linhas `-` saem, `+` entram). Adapte os textos de ajuda ao nome do assistente do projeto.
3. Rode o SQL da ajuda no SQL Editor.
4. `selar.py`, suba a versão do SHELL do `sw.js` e envie todos os arquivos juntos.

## Cuidados
- O CSS do botão usa `.balao-ia:not(.so-icone)`: no cardápio público ele continua como estava.
- O ID da caixa do desenvolvedor precisa ser `devBar` com o select `devVerComo`.

## Como testar
1. Estoque: toque num ingrediente → abre a janela com Editar, Entrada, Perda, Inventário, Excluir.
2. Produtos: toque num produto → abre a edição; o ⋯ mostra Excluir.
3. O botão do assistente aparece redondo e não cobre o botão "Salvar" no fim das telas.
