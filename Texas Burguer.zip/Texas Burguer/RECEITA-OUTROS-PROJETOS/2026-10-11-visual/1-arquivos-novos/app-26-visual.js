/* ============================================================
   VISUAL (Entrega 2): listas compactas com janela de ações, caixa do Modo Desenvolvedor recolhível.
   O botão do Tex compacto e o espaço no fim da página ficam no estilo-13-visual.css.
   ============================================================ */
function vsAcoes(titulo, acoes){
  let ov = document.getElementById('vsAcoesModal');
  if(!ov){
    ov = document.createElement('div'); ov.className = 'modal-overlay'; ov.id = 'vsAcoesModal';
    ov.innerHTML = '<div class="modal-box vs-acoes" role="dialog" aria-modal="true" aria-labelledby="vsAcoesTit"><div class="modal-header"><h2 id="vsAcoesTit"></h2><button class="close-btn" type="button" aria-label="Fechar" onclick="vsAcoesFechar()">✕</button></div><div id="vsAcoesLista"></div></div>';
    ov.addEventListener('click', e => { if(e.target === ov) vsAcoesFechar(); });
    document.body.appendChild(ov);
  }
  document.getElementById('vsAcoesTit').textContent = titulo;
  window.__vsAcoes = acoes || [];
  document.getElementById('vsAcoesLista').innerHTML = window.__vsAcoes.map((a, i) => `<button type="button" class="vs-acao${a.perigo ? ' perigo' : ''}" onclick="vsAcoesExec(${i})">${a.t}</button>`).join('');
  ov.classList.add('open');
  const b = ov.querySelector('.vs-acao'); if(b){ try{ b.focus(); }catch(err){} }
}
function vsAcoesExec(i){ const a = (window.__vsAcoes || [])[i]; vsAcoesFechar(); if(a && typeof a.fn === 'function') setTimeout(a.fn, 30); }
function vsAcoesFechar(){ const ov = document.getElementById('vsAcoesModal'); if(ov) ov.classList.remove('open'); }
document.addEventListener('keydown', e => { if(e.key === 'Escape') vsAcoesFechar(); });

function vsAcoesEstoque(id){
  const i = (estoque || []).find(x => x.id === id); if(!i) return;
  vsAcoes(i.nome + ' · ' + i.quantidade + ' ' + (i.unidade || 'un'), [
    { t:'✏️ Editar (nome, unidade, preço)', fn:() => editarEstoquePrompt(id) },
    { t:'➕ Entrada (chegou mercadoria)', fn:() => entradaEstoquePrompt(id) },
    { t:'➖ Perda (estragou, caiu, venceu)', fn:() => perdaEstoquePrompt(id) },
    { t:'📋 Inventário (contei, corrigir)', fn:() => inventarioEstoquePrompt(id) },
    { t:'🗑️ Excluir', fn:() => excluirEstoqueConfirm(id), perigo:true }
  ]);
}
function vsAcoesProduto(id){
  const p = (produtos || []).find(x => x.id === id); if(!p) return;
  vsAcoes(p.nome, [
    { t:'✏️ Editar', fn:() => abrirEditarProduto(id) },
    { t:'🗑️ Excluir', fn:() => excluirProdutoConfirm(id), perigo:true }
  ]);
}
function vsAcoesCombo(id){
  const c = (combos || []).find(x => x.id === id); if(!c) return;
  vsAcoes(c.nome, [
    { t:'✏️ Editar', fn:() => abrirEditarCombo(id) },
    { t:'🗑️ Excluir', fn:() => excluirComboConfirm(id), perigo:true }
  ]);
}
function vsAcoesUsuario(idx){
  const u = (usuarios || [])[idx]; if(!u) return;
  const ac = [{ t:'✏️ Editar', fn:() => editarUsuarioPrompt(u.login) },
              { t: u.ativo ? '⏸️ Desativar (não entra mais)' : '▶️ Ativar', fn:() => toggleAtivoUsuario(u.login, !!u.ativo) }];
  if(u.nivel !== 'Desenvolvedor') ac.push({ t:'🗑️ Excluir', fn:() => excluirUsuarioPrompt(u.login), perigo:true });
  vsAcoes(u.login + ' · ' + u.nivel, ac);
}

/* Caixa do Modo Desenvolvedor: recolhe para uma linha (lembra a escolha neste aparelho) */
(function(){
  const CHAVE = 'texas_devbar_recolhida';
  function resumo(){
    const sel = document.getElementById('devVerComo'), r = document.getElementById('devBarResumo');
    if(sel && r){ const o = sel.options[sel.selectedIndex]; r.textContent = o ? o.textContent : ''; }
  }
  function aplicar(rec){
    const bar = document.getElementById('devBar'), bt = document.getElementById('devBarBtn'); if(!bar) return;
    bar.classList.toggle('recolhida', rec);
    if(bt){ bt.textContent = rec ? '▸' : '▾'; bt.setAttribute('aria-expanded', rec ? 'false' : 'true'); bt.setAttribute('aria-label', rec ? 'Mostrar opções do Modo Desenvolvedor' : 'Recolher Modo Desenvolvedor'); }
    resumo();
  }
  function iniciar(){
    const bar = document.getElementById('devBar'); if(!bar || document.getElementById('devBarBtn')) return;
    const bt = document.createElement('button'); bt.type = 'button'; bt.id = 'devBarBtn'; bt.className = 'vs-dev-btn';
    const r = document.createElement('span'); r.id = 'devBarResumo'; r.className = 'vs-dev-resumo';
    bar.insertBefore(r, bar.querySelector('#devVerComo'));
    bar.insertBefore(bt, bar.firstChild);
    bt.addEventListener('click', () => { const rec = !bar.classList.contains('recolhida'); try{ localStorage.setItem(CHAVE, rec ? '1' : '0'); }catch(err){} aplicar(rec); });
    const sel = document.getElementById('devVerComo'); if(sel) sel.addEventListener('change', resumo);
    let rec = true; try{ rec = localStorage.getItem(CHAVE) !== '0'; }catch(err){}
    aplicar(rec);
    try{ new MutationObserver(resumo).observe(sel, { childList:true }); }catch(err){}
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})();
