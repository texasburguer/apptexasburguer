-- Teste do pente fino (11/10/2026): só as tabelas usadas pela planilha entram na fila. Não grava nada (termina com erro de propósito).
do $$
declare n0 bigint; n1 bigint; n2 bigint; e uuid; p uuid;
begin
  select count(*) into n0 from fila_sync;
  select id into e from estoque limit 1;
  update estoque set quantidade = quantidade where id = e;      -- estoque: NÃO vai para a planilha
  select count(*) into n1 from fila_sync;
  select id into p from produtos limit 1;
  update produtos set nome = nome where id = p;                 -- produtos: vai para a planilha
  select count(*) into n2 from fila_sync;
  raise exception 'RELATORIO estoque_enfileirou=% (esperado 0) produto_enfileirou=% (esperado 1)', n1-n0, n2-n1;
end $$;
