# Receita: pente fino (menos burocracia, planilhas enxutas, sobras removidas)

## O que mudou
1. **Janelas no lugar das caixinhas do navegador (`prompt`)**: entrada, perda e inventário do estoque, suspender e recusar pedido, receber e cancelar compra, meta de vendas, fechar o cardápio, marcar reembolso devolvido, inutilizar NFC-e e cancelar evento/ajuste. Cada uma abre UMA janela (função `vsForm`), com motivos prontos para tocar. Receber compra: botões "Já paguei" / "Vou pagar depois" + calendário (antes: OK/Cancelar confuso + data digitada).
2. **Adicionais do produto novo**: já vêm marcados os que a maioria dos produtos da mesma categoria tem; "Comprado pronto" (bebida) vem sem nenhum. No banco, bebidas (produto com estoque próprio) perdem os adicionais.
3. **Saiu "Importar cardápio inicial"** (botão, código da página e função do banco).
4. **Sistema com 5 telas**: "Backup" + "Espaço e fotos" viraram "Backup e espaço". Saíram a escolha de onde salvar a foto (sempre os dois Drives), o botão "Copiar fotos antigas", a caixinha do espelho das 3h (o Supabase já atualiza a cada 10 min e às 3h), os números da contingência que nunca mudavam e as confirmações de "Fazer backup agora" e "Enviar ao Drive".
5. **Página sem o caminho antigo da planilha** (`postApi_`, tempos/repetições, leitura do cardápio pela planilha, funções que ninguém chamava).
6. **Planilha principal enxuta** (só o que o Supabase chama: cópia SB_, arquivo, fotos, backup no Drive, espelho da contingência). Os gatilhos antigos se apagam sozinhos. A cópia SB_ fica só com 14 tabelas. Ferramenta `limparAbasAntigas` apaga as abas antigas e as SB_ que não são mais copiadas (com cópia da planilha antes).
7. **Contingência enxuta**: sem `syncLote`/abas SB_, `getEspelho` e `guardarBackup`; as abas SB_ antigas se apagam sozinhas.
8. **Banco**: `enfileirar_sync` filtra as 14 tabelas; `ia_diag_codigo` sem a análise de código antiga; remove tabelas/funções sem uso. Função `planilha-admin` sem `sincAutoStatus`, `sincAutoDefinir` e `arquivoPedido`.

## Onde
- `1-codigo-novo/`: o trecho para colar no FIM do `app-26-visual.js` (função `vsForm`) e do `estilo-13-visual.css`. Depende da receita "visual" (app-26 / estilo-13).
- `2-mudancas-nos-arquivos/`: um `.diff` por arquivo (linhas `-` saem, `+` entram; os `?v=` foram zerados). O `app-16` tem um `.LEIA.txt` (só apagar um bloco).
- `3-planilhas/`: `planilha-principal-enxuta.gs`, `contingencia-enxuta.gs` e a lista `funcoes-que-ficam-na-planilha-principal.txt`.
- `4-banco-e-funcoes/`: `pente-fino-banco.sql` e `planilha-admin-index.ts` (a função inteira).

## Como fazer
1. **Página**: cole o código novo no fim do `app-26-visual.js` e do `estilo-13-visual.css`; aplique os `.diff`; apague o bloco do `app-16`. Nos textos (ajuda e novidades), use o nome do projeto. Rode `selar.py`, suba o SHELL do `sw.js` e envie tudo junto.
2. **Planilha principal** (antes, guarde uma cópia do código atual):
   - No `planilha-principal-enxuta.gs`, troque os 4 `COLE_AQUI_...` pelos valores do SEU arquivo atual (endereço `CONTINGENCIA_API_URL`, as duas chaves de `configurarContingencia` e `SB_CHAVE_SERVIDOR_PADRAO_`) e `NOME_DO_RESTAURANTE` pelo nome usado nas pastas do Drive (veja `obterPastaFotos_` no arquivo atual).
   - Se o seu módulo Supabase (`acaoServidorSb_`) tiver ações a mais que este, compare com a lista `funcoes-que-ficam-na-planilha-principal.txt` antes de trocar.
   - Cole por cima, salve, Implantar > Gerenciar implantações > lápis > "Nova versão" > Implantar (o endereço não muda).
   - Depois, na lista de funções, `previaLimpezaAbas` (só mostra) e `limparAbasAntigas` (faz a cópia e apaga).
3. **Contingência**: no `contingencia-enxuta.gs` troque `NOME_DO_RESTAURANTE` (pastas e textos), cole por cima e publique "Nova versão" na mesma implantação.
4. **Banco**: rode `pente-fino-banco.sql` no SQL Editor, parte por parte. A lista de 14 tabelas do `enfileirar_sync` TEM de ser igual à `SB_TABELAS_ESPELHO_` do `.gs`.
5. **Função**: publique `planilha-admin` com o `index.ts` novo (o `auth.ts` não muda; verify_jwt desligado).
6. Se existir a função `ai-dev-analise` (desligada), apague-a no painel do Supabase (Edge Functions → ai-dev-analise → Delete).

## Cuidados
- Faça a planilha principal e o banco no mesmo dia: o `.gs` novo ignora as tabelas fora da lista (contam como recebidas) e o banco novo para de mandá-las.
- O `.gs` novo responde "Ação desconhecida" para o sistema antigo (login, vendas pela planilha). Confira que o `USAR_SUPABASE_` da página está `true` antes.
- Não apague as chaves da contingência escritas no `.gs` (`configurarContingencia`).
- `getEspelhoInterno` continua na contingência: a `conferirChavesContingencia` da principal usa.

## Como testar
1. Estoque → toque num ingrediente → "Perda": abre uma janela com quantidade e botões de motivo; sem motivo, avisa e não grava.
2. Compras → marque um pedido como recebido → "Vou pagar depois" mostra o calendário.
3. Produto novo de uma categoria que já tem lanches: em "⚙️ Mais opções" os adicionais da categoria aparecem marcados; trocando para "Comprado pronto" ficam desmarcados.
4. Admin → Sistema: aparecem Usuários, Auditoria, Backup e espaço, Sincronização e contingência, Contas e acessos. No SQL Editor, rode `4-banco-e-funcoes/teste-pente-fino.sql` (estoque não entra na fila, produto entra).
