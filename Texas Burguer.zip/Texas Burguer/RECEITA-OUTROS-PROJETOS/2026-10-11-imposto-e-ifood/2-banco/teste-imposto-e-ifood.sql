-- Teste do imposto e do iFood (11/10/2026). NÃO grava nada: termina com erro de propósito ("RELATORIO") e desfaz tudo.
-- Cole no SQL Editor. Esperado (com a comissão do iFood em 12% só dentro do teste e alíquota 6,5% no mês atual):
--   p1: total 52 (50 − 6 da loja + 8 de entrega), desc 6, taxa 6,24 · p2 (entregador do iFood): total 40, entrega 0, "Pago"
--   p3 (dinheiro, loja entrega): "A Receber", forma "iFood (pagar na entrega)" · p1 alterado: 62, uma linha de pagamento só
--   depois do repasse: taxa 7,50 · reembolso_ifood = 0 · pct_set 4, pct_ago 0 · aliq_invalida = mensagem de erro
--   rel_ifood: margem = total − custo − taxas − impostos · sim.impostos = 2,60 (40 × 6,5%)
do $$
declare adm uuid; r1 jsonb; r2 jsonb; r3 jsonb; v1 uuid; v2 uuid; v3 uuid; o1 jsonb; o2 jsonb; o3 jsonb;
        rep jsonb := '{}'::jsonb; n int; rel jsonb; fin jsonb; fl jsonb; sim jsonb; pr uuid; fp uuid; o1b jsonb; up jsonb;
begin
  select u.id into adm from usuarios u where u.nivel::text in ('Admin','Desenvolvedor') and u.ativo limit 1;
  rep := rep || jsonb_build_object('cat_das', public._categoria_despesa('Imposto das vendas (DAS)'));
  -- comissão estimada do iFood: 12% (só dentro do teste)
  update formas_pagamento set taxa_percentual = 12 where id = public._ifood_forma();
  rep := rep || jsonb_build_object('forma_ifood', (select nome from formas_pagamento where id = public._ifood_forma()));

  -- 1) loja entrega, pago no app, cupom dividido (6 loja + 4 iFood), taxa de serviço do iFood 0,99
  o1 := jsonb_build_object('id','teste-ifood-1','displayId','T001','orderType','DELIVERY',
        'customer', jsonb_build_object('name','Cliente Teste'),
        'delivery', jsonb_build_object('deliveredBy','MERCHANT','deliveryAddress', jsonb_build_object('formattedAddress','Rua Teste, 1')),
        'items', jsonb_build_array(jsonb_build_object('name','Item X','quantity',1,'unitPrice',50,'totalPrice',50)),
        'total', jsonb_build_object('subTotal',50,'deliveryFee',8,'benefits',10,'additionalFees',0.99,'orderAmount',48.99),
        'benefits', jsonb_build_array(jsonb_build_object('value',10,'sponsorshipValues', jsonb_build_array(jsonb_build_object('name','MERCHANT','value',6), jsonb_build_object('name','IFOOD','value',4)))),
        'payments', jsonb_build_object('prepaid',48.99,'pending',0));
  r1 := public.ifood_criar_pedido(o1, true); v1 := (r1->>'vendaId')::uuid;
  rep := rep || jsonb_build_object('p1', (select jsonb_build_object('total',valor_total,'original',valor_original,'desc',valor_desconto,'taxaEnt',taxa_entrega,'stPag',status_pagamento,'forma',forma_pagamento) from vendas where id = v1),
                                   'p1_pag', (select jsonb_agg(jsonb_build_object('f',forma_pagamento,'v',valor,'tx',taxa_aplicada)) from pagamentos_venda where venda_id = v1));

  -- 2) iFood entrega, cliente paga em dinheiro ao entregador do iFood
  o2 := jsonb_build_object('id','teste-ifood-2','displayId','T002','orderType','DELIVERY',
        'customer', jsonb_build_object('name','Cliente Dois'),
        'delivery', jsonb_build_object('deliveredBy','IFOOD','deliveryAddress', jsonb_build_object('formattedAddress','Rua Teste, 2')),
        'items', jsonb_build_array(jsonb_build_object('name','Item Y','quantity',2,'unitPrice',20,'totalPrice',40)),
        'total', jsonb_build_object('subTotal',40,'deliveryFee',7,'benefits',0,'orderAmount',47),
        'payments', jsonb_build_object('prepaid',0,'pending',47,'methods', jsonb_build_array(jsonb_build_object('method','CASH','cash', jsonb_build_object('changeFor',50)))));
  r2 := public.ifood_criar_pedido(o2, true); v2 := (r2->>'vendaId')::uuid;
  rep := rep || jsonb_build_object('p2', (select jsonb_build_object('total',valor_total,'taxaEnt',taxa_entrega,'stPag',status_pagamento,'forma',forma_pagamento,'obs',observacoes_entrega) from vendas where id = v2),
                                   'p2_pag', (select jsonb_agg(jsonb_build_object('f',forma_pagamento,'v',valor,'tx',taxa_aplicada)) from pagamentos_venda where venda_id = v2));

  -- 3) loja entrega, dinheiro na entrega (loja recebe)
  o3 := jsonb_build_object('id','teste-ifood-3','displayId','T003','orderType','DELIVERY',
        'customer', jsonb_build_object('name','Cliente Tres'),
        'delivery', jsonb_build_object('deliveredBy','MERCHANT','deliveryAddress', jsonb_build_object('formattedAddress','Rua Teste, 3')),
        'items', jsonb_build_array(jsonb_build_object('name','Item Z','quantity',1,'unitPrice',25,'totalPrice',25)),
        'total', jsonb_build_object('subTotal',25,'deliveryFee',5,'benefits',0,'orderAmount',30),
        'payments', jsonb_build_object('prepaid',0,'pending',30));
  r3 := public.ifood_criar_pedido(o3, true); v3 := (r3->>'vendaId')::uuid;
  rep := rep || jsonb_build_object('p3', (select jsonb_build_object('total',valor_total,'stPag',status_pagamento,'forma',forma_pagamento) from vendas where id = v3),
                                   'p3_pag', (select jsonb_agg(jsonb_build_object('f',forma_pagamento,'v',valor,'tx',taxa_aplicada)) from pagamentos_venda where venda_id = v3));

  -- 4) cliente alterou o pedido 1 (subTotal 60): refaz valores e pagamentos sem duplicar linhas
  o1b := jsonb_set(o1, '{total,subTotal}', '60'::jsonb);
  up := public.ifood_atualizar_pedido(o1b);
  rep := rep || jsonb_build_object('p1_alterado', (select jsonb_build_object('total',valor_total,'original',valor_original) from vendas where id = v1),
                                   'p1_alt_pag', (select jsonb_agg(jsonb_build_object('f',forma_pagamento,'v',valor,'tx',taxa_aplicada)) from pagamentos_venda where venda_id = v1));

  -- 5) repasse com comissão real do pedido 1 (7,50) substitui a estimada
  n := public.ifood_repasses_gravar(jsonb_build_array(jsonb_build_object('id','teste-repasse-1','paymentDate','2026-10-11','amount',40,
        'orders', jsonb_build_array(jsonb_build_object('orderId','teste-ifood-1','commission',7.5)))));
  rep := rep || jsonb_build_object('repasse_n', n, 'p1_pos_repasse', (select jsonb_agg(jsonb_build_object('f',forma_pagamento,'v',valor,'tx',taxa_aplicada)) from pagamentos_venda where venda_id = v1));

  -- 6) cancelar o pedido 2 (já "Pago"): NÃO pode gerar reembolso para a loja devolver
  update vendas set status = 'Cancelada', motivo_cancelamento = 'teste' where id = v2;
  rep := rep || jsonb_build_object('reembolso_ifood', (select count(*) from reembolsos where venda_id = v2));

  -- 7) como Admin: alíquota por mês, flags, relatório, a receber, simulador
  perform set_config('request.jwt.claims', json_build_object('sub',adm,'role','authenticated')::text, true);
  perform set_config('role','authenticated', true);
  perform public.api_salvar_aliquota_mes(jsonb_build_object('competencia','2026-09','aliquota','4'));
  fl := public.api_salvar_aliquota_mes(jsonb_build_object('competencia', to_char(current_date,'YYYY-MM'),'aliquota','6,5'));
  rep := rep || jsonb_build_object('flags', fl - 'message', 'pct_set', public._imposto_pct('2026-09-15'), 'pct_ago', public._imposto_pct('2026-08-01'),
                                   'pct_futuro', public._imposto_pct((current_date + 60)), 'aliq_invalida', public.api_salvar_aliquota_mes(jsonb_build_object('competencia','2026-10','aliquota','40'))->>'message');
  rel := public.api_ifood_relatorio('{"dias":2}'::jsonb);
  rep := rep || jsonb_build_object('rel_ifood', (select x from jsonb_array_elements(rel->'canais') x where x->>'canal' = 'iFood'));
  fin := public.api_ifood_financeiro('{}'::jsonb);
  rep := rep || jsonb_build_object('fin_aReceber', fin->'aReceber');
  select pp.produto_id, pp.forma_pagamento_id into pr, fp from produto_precos pp join formas_pagamento f on f.id = pp.forma_pagamento_id and f.ativa where pp.preco > 0 limit 1;
  sim := public.api_simular_precificacao(jsonb_build_object('produtoId', pr, 'formaPagamentoId', fp, 'precoSimulado', 40));
  rep := rep || jsonb_build_object('sim', jsonb_build_object('impostos', sim->'impostos', 'pct', sim->'impostosPct', 'custoTotal', sim->'custoTotal', 'ok', sim->'ok'));
  raise exception 'RELATORIO %', rep::text;
end $$;
