-- =====================================================================
-- IMPOSTO NOS RELATÓRIOS e REVISÃO DO iFOOD (11/10/2026)
-- Rode no SQL Editor DEPOIS das integrações (iFood/Nota fiscal) e do reembolso automático já estarem no banco. Pode rodar mais de uma vez.
-- O que muda:
--   1) alíquota do imposto por mês (sistema.ImpostoAliquotasMes), com ou sem a nota fiscal ligada;
--   2) categoria de despesa "Imposto das vendas (DAS)" (e "Brindes", que o banco trocava por "Outros");
--   3) Calculadora de preço com o imposto;
--   4) iFood: venda grava o valor que é da loja, comissão nas taxas (estimada e depois a real do repasse),
--      cancelamento sem reembolso, "despachar" só quando a loja entrega, relatório por canal e "a receber" sem comissão;
--   5) textos da ajuda da IA.
-- =====================================================================

-- ---------- 1) Alíquota do imposto (Simples) por mês ----------
-- A alíquota de cada mês fica em sistema.ImpostoAliquotasMes ({"2026-10": 6.0, ...}). Mês sem valor usa o último mês
-- anterior que tem; sem nenhum, a alíquota padrão de Dados fiscais. Vale com ou sem a Nota fiscal ligada.
create or replace function public._imposto_pct(p_data date default current_date)
 returns numeric language sql stable security definer set search_path to 'public'
as $function$
  select coalesce(
    (select _num(e.value #>> '{}', 0) from sistema s
       cross join lateral jsonb_each(case when jsonb_typeof(s.valor) = 'object' then s.valor else '{}'::jsonb end) e
      where s.chave = 'ImpostoAliquotasMes' and e.key <= to_char(coalesce(p_data, current_date), 'YYYY-MM')
      order by e.key desc limit 1),
    (select aliquota_simples from fiscal_empresa where id), 0)
$function$;

create or replace function public.api_integracoes_flags(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public'
as $function$
declare v_adm boolean := tem_nivel('Admin');
begin
  if auth_nivel() is null then return _negado(); end if;
  return jsonb_build_object('ok', true, 'ifood', _integracao_ligada('ifood'), 'nfce', _integracao_ligada('nfce'),
    'nfceModo', (select modo from integracoes_config where provedor = 'nfce'),
    'impostoPct', case when v_adm then _imposto_pct(current_date) else 0 end,
    'impostoPadrao', case when v_adm then coalesce((select aliquota_simples from fiscal_empresa where id), 0) else 0 end,
    'impostoMeses', case when v_adm then coalesce((select valor from sistema where chave = 'ImpostoAliquotasMes' and jsonb_typeof(valor) = 'object'), '{}'::jsonb) else '{}'::jsonb end);
end $function$;

create or replace function public.api_salvar_aliquota_mes(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public'
as $function$
declare v_comp text := btrim(coalesce(p->>'competencia', '')); v_txt text := btrim(coalesce(p->>'aliquota', '')); v_val numeric; v_atual jsonb;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_comp !~ '^\d{4}-(0[1-9]|1[0-2])$' then return _falha('Mês inválido.'); end if;
  select case when jsonb_typeof(valor) = 'object' then valor end into v_atual from sistema where chave = 'ImpostoAliquotasMes';
  v_atual := coalesce(v_atual, '{}'::jsonb);
  if v_txt = '' then
    v_atual := v_atual - v_comp;
  else
    v_val := _num(replace(v_txt, ',', '.'), -1);
    if v_val < 0 or v_val > 33 then return _falha('Alíquota inválida: use um número de 0 a 33 (%).'); end if;
    v_atual := v_atual || jsonb_build_object(v_comp, round(v_val, 2));
  end if;
  perform _cfg_gravar('ImpostoAliquotasMes', v_atual);
  perform _auditar('Alíquota do imposto alterada', v_comp || ': ' || coalesce(nullif(v_txt, ''), 'sem alíquota própria (usa a anterior)'), null);
  return public.api_integracoes_flags('{}'::jsonb) || jsonb_build_object('message', case when v_txt = '' then 'Alíquota do mês removida.' else 'Alíquota salva.' end);
end $function$;
revoke all on function public.api_salvar_aliquota_mes(jsonb) from public, anon;
grant execute on function public.api_salvar_aliquota_mes(jsonb) to authenticated;
revoke all on function public._imposto_pct(date) from public, anon;
grant execute on function public._imposto_pct(date) to authenticated;

-- ---------- 2) Categoria de despesa própria para o DAS ----------
-- "Imposto das vendas (DAS)": o pagamento do imposto que os relatórios já estimam (não é descontado de novo).
-- "Brindes" já existia na tela e o banco trocava por "Outros".
create or replace function public._categoria_despesa(v text, padrao text default 'Outros'::text)
 returns text language sql immutable set search_path to 'public'
as $function$
  select case when v = any (array['Insumos','Aluguel','Energia','Água','Gás','Internet/Telefone','Salários','Impostos','Imposto das vendas (DAS)','Manutenção','Marketing','Embalagens','Entregadores','Brindes','Outros'])
              then v else padrao end
$function$;

-- ---------- 3) Calculadora: o imposto entra na conta do preço ----------
create or replace function public.api_simular_precificacao(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public'
as $function$
declare pr produtos%rowtype; f formas_pagamento%rowtype; pp produto_precos%rowtype; v_tec numeric; v_preco numeric := _num(p->>'precoSimulado', 0);
        v_emb numeric := greatest(0, _num(p->>'embalagem')); v_out numeric := greatest(0, _num(p->>'outrosCustos')); v_mp numeric := greatest(0, _num(p->>'taxaMarketplace'));
        v_taxa numeric; v_taxa_mp numeric; v_total numeric; v_res numeric; v_imp_pct numeric := public._imposto_pct(current_date); v_imp numeric;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into pr from produtos where id = _uuid(p->>'produtoId');
  if pr.id is null then return _falha('Produto não encontrado.'); end if;
  select * into f from formas_pagamento where id = _uuid(p->>'formaPagamentoId') and ativa;
  if f.id is null then return _falha('Forma de pagamento não encontrada.'); end if;
  select * into pp from produto_precos where produto_id = pr.id and forma_pagamento_id = f.id;
  if pp.id is null then return _falha('Preço do produto para esta forma de pagamento não encontrado.'); end if;
  select coalesce(sum(e.custo_unitario * pi.quantidade_por_unidade), 0) into v_tec
    from produto_ingredientes pi join estoque e on e.id = pi.ingrediente_id where pi.produto_id = pr.id;
  if v_tec <= 0 then v_tec := coalesce(pp.custo, 0); end if;
  if not (v_preco > 0) then return _falha('Preço simulado inválido.'); end if;
  v_taxa := round(v_preco * f.taxa_percentual / 100 + f.taxa_fixa, 2);
  v_taxa_mp := round(v_preco * v_mp / 100, 2);
  v_imp := round(v_preco * v_imp_pct / 100, 2);
  v_total := round(v_tec + v_emb + v_out + v_taxa + v_taxa_mp + v_imp, 2);
  v_res := round(v_preco - v_total, 2);
  return jsonb_build_object('ok', true, 'produto', pr.nome, 'formaPagamento', f.nome, 'precoAtual', pp.preco, 'precoSimulado', v_preco,
    'custoTecnico', round(v_tec, 2), 'embalagem', v_emb, 'outrosCustos', v_out, 'taxaPagamento', v_taxa, 'taxaPagamentoPct', f.taxa_percentual,
    'taxaPagamentoFixa', f.taxa_fixa, 'taxaMarketplace', v_taxa_mp, 'taxaMarketplacePct', v_mp, 'impostos', v_imp, 'impostosPct', v_imp_pct,
    'custoTotal', v_total, 'resultado', v_res,
    'margem', round(v_res / v_preco * 100, 2), 'markup', case when v_total > 0 then round(v_preco / v_total, 2) else 0 end);
end $function$;

-- ---------- 4) iFood: valor que é da loja ----------
-- Receita da loja = itens − desconto PAGO PELA LOJA + taxa de entrega SÓ quando a loja entrega.
-- Fica de fora: desconto pago pelo iFood (o iFood repassa), taxa de entrega quando o iFood entrega e taxas extras do iFood (additionalFees).
create or replace function public._ifood_valores(p_order jsonb)
 returns jsonb language plpgsql immutable set search_path to 'public'
as $function$
declare v_sub numeric; v_fee numeric; v_ben numeric; v_loja numeric := 0; v_tem boolean := false; b jsonb; s jsonb; v_ifood boolean; v_total numeric;
begin
  v_sub := public._ifood_n(p_order->'total'->'subTotal');
  if v_sub <= 0 then
    select coalesce(sum(public._ifood_n(x->'totalPrice')), 0) into v_sub from jsonb_array_elements(case when jsonb_typeof(p_order->'items') = 'array' then p_order->'items' else '[]'::jsonb end) x;
  end if;
  v_fee := public._ifood_n(p_order->'total'->'deliveryFee');
  v_ben := public._ifood_n(p_order->'total'->'benefits');
  for b in select value from jsonb_array_elements(case when jsonb_typeof(p_order->'benefits') = 'array' then p_order->'benefits' else '[]'::jsonb end) loop
    for s in select value from jsonb_array_elements(case when jsonb_typeof(b->'sponsorshipValues') = 'array' then b->'sponsorshipValues' else '[]'::jsonb end) loop
      v_tem := true;
      if upper(coalesce(s->>'name', s->>'sponsor', '')) in ('MERCHANT', 'LOJA', 'RESTAURANT', 'RESTAURANTE') then v_loja := v_loja + public._ifood_n(s->'value'); end if;
    end loop;
  end loop;
  if not v_tem then v_loja := v_ben; end if;   -- sem o detalhe de quem pagou o desconto: conta como desconto da loja (lado seguro)
  v_ifood := upper(coalesce(p_order->'delivery'->>'deliveredBy', '')) = 'IFOOD';
  if v_ifood then v_fee := 0; end if;
  if v_sub <= 0 then v_sub := greatest(public._ifood_n(p_order->'total'->'orderAmount') - v_fee + v_loja, 0); end if;
  v_total := greatest(round(v_sub - v_loja + v_fee, 2), 0.01);
  return jsonb_build_object('original', round(v_sub, 2), 'descontoLoja', round(v_loja, 2), 'descontoIfood', round(greatest(v_ben - v_loja, 0), 2),
    'taxaEntrega', round(v_fee, 2), 'total', v_total, 'entregaIfood', v_ifood);
end $function$;

-- Pagamentos do pedido do iFood: "pagar na entrega" só quando a LOJA entrega (o entregador da loja recebe);
-- o resto o iFood repassa ("pago no app"). A comissão é estimada pela taxa da forma "iFood" (Pagamentos) até chegar o repasse real.
-- Não apaga linhas: reaproveita as que existem; a que deixou de valer fica com valor 0.
create or replace function public._ifood_gravar_pagamentos(p_venda uuid, p_order jsonb, p_total numeric, p_entrega_ifood boolean)
 returns text language plpgsql security definer set search_path to 'public'
as $function$
declare v_pend numeric := public._ifood_n(p_order->'payments'->'pending'); v_dinheiro numeric; v_app numeric; v_pct numeric := 0; v_fixa numeric := 0;
        v_tx_app numeric; v_tx_din numeric;
begin
  select coalesce(taxa_percentual, 0), coalesce(taxa_fixa, 0) into v_pct, v_fixa from formas_pagamento where id = public._ifood_forma();
  v_pct := coalesce(v_pct, 0); v_fixa := coalesce(v_fixa, 0);
  v_dinheiro := case when p_entrega_ifood then 0 else round(least(greatest(v_pend, 0), p_total), 2) end;
  v_app := round(p_total - v_dinheiro, 2);
  v_tx_app := round(v_app * v_pct / 100 + v_fixa, 2);
  v_tx_din := round(v_dinheiro * v_pct / 100 + case when v_app > 0.009 then 0 else v_fixa end, 2);
  update pagamentos_venda set valor = 0, taxa_aplicada = 0 where venda_id = p_venda and forma_pagamento in ('iFood (pago no app)', 'iFood (pagar na entrega)');
  if v_app > 0.009 then
    update pagamentos_venda set valor = v_app, taxa_aplicada = v_tx_app where venda_id = p_venda and forma_pagamento = 'iFood (pago no app)';
    if not found then insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo) values (p_venda, 'iFood (pago no app)', v_app, v_tx_app, 0); end if;
  end if;
  if v_dinheiro > 0.009 then
    update pagamentos_venda set valor = v_dinheiro, taxa_aplicada = v_tx_din where venda_id = p_venda and forma_pagamento = 'iFood (pagar na entrega)';
    if not found then insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo) values (p_venda, 'iFood (pagar na entrega)', v_dinheiro, v_tx_din, 0); end if;
  end if;
  return case when v_dinheiro > 0.009 and v_app > 0.009 then 'iFood (pago no app) + iFood (pagar na entrega)' when v_dinheiro > 0.009 then 'iFood (pagar na entrega)' else 'iFood (pago no app)' end;
end $function$;

-- Comissão real (do repasse) substitui a estimada, dividida entre os pagamentos da venda.
create or replace function public._ifood_aplicar_comissao(p_venda uuid, p_comissao numeric)
 returns void language plpgsql security definer set search_path to 'public'
as $function$
declare v_tot numeric; v_soma numeric; v_maior uuid;
begin
  if p_venda is null or p_comissao is null or p_comissao < 0 then return; end if;
  select coalesce(sum(valor), 0) into v_tot from pagamentos_venda where venda_id = p_venda;
  if v_tot <= 0 then return; end if;
  update pagamentos_venda set taxa_aplicada = round(p_comissao * valor / v_tot, 2) where venda_id = p_venda;
  select coalesce(sum(taxa_aplicada), 0) into v_soma from pagamentos_venda where venda_id = p_venda;
  if round(p_comissao - v_soma, 2) <> 0 then
    select id into v_maior from pagamentos_venda where venda_id = p_venda order by valor desc limit 1;
    update pagamentos_venda set taxa_aplicada = taxa_aplicada + round(p_comissao - v_soma, 2) where id = v_maior;
  end if;
end $function$;

-- ---------- 5) iFood: criar a venda com o valor que é da loja ----------
create or replace function public.ifood_criar_pedido(p_order jsonb, p_simulado boolean default false)
 returns jsonb language plpgsql security definer set search_path to 'public'
as $function$
declare
  v_id text := p_order->>'id'; v_disp text := coalesce(nullif(p_order->>'displayId', ''), right(coalesce(p_order->>'id', ''), 4));
  v_venda uuid := gen_random_uuid(); v_tipo venda_tipo; v_nome text; v_tel text; v_end text; v_comp text; v_ref text; v_obs text;
  v_val jsonb; v_total numeric; v_sem int; v_caixa uuid; v_numero int; v_troco numeric; v_agend text; v_forma text; v_pend numeric; v_cash numeric; v_stpag status_pagamento; ad jsonb;
begin
  if v_id is null then return jsonb_build_object('ok', false, 'message', 'Pedido sem id.'); end if;
  if exists (select 1 from ifood_pedidos where pedido_ifood = v_id) then return jsonb_build_object('ok', true, 'duplicado', true); end if;
  v_tipo := case when upper(coalesce(p_order->>'orderType', '')) in ('TAKEOUT', 'PICKUP') then 'Retirada' else 'Entrega' end::venda_tipo;
  v_nome := left(btrim(coalesce(p_order->'customer'->>'name', 'Cliente iFood')), 80) || ' (iFood)';
  v_tel := left(regexp_replace(coalesce(p_order->'customer'->'phone'->>'number', ''), '[^0-9]', '', 'g'), 20);
  ad := coalesce(p_order->'delivery'->'deliveryAddress', '{}'::jsonb);
  v_end := coalesce(nullif(ad->>'formattedAddress', ''), btrim(concat_ws(', ', ad->>'streetName', ad->>'streetNumber', ad->>'neighborhood', ad->>'city')));
  v_comp := coalesce(ad->>'complement', ''); v_ref := coalesce(ad->>'reference', '');
  v_val := public._ifood_valores(p_order);
  v_total := (v_val->>'total')::numeric;
  v_pend := public._ifood_n(p_order->'payments'->'pending');
  -- dinheiro na entrega só é recebido pela loja quando ela mesma entrega; o resto vem no repasse do iFood
  v_cash := case when (v_val->>'entregaIfood')::boolean then 0 else round(least(greatest(v_pend, 0), v_total), 2) end;
  v_stpag := case when v_cash > 0.009 then 'A Receber' else 'Pago' end;
  v_forma := case when v_cash > 0.009 and v_total - v_cash > 0.009 then 'iFood (pago no app) + iFood (pagar na entrega)' when v_cash > 0.009 then 'iFood (pagar na entrega)' else 'iFood (pago no app)' end;
  v_obs := 'iFood #' || v_disp;
  if v_tipo = 'Entrega' and (v_val->>'entregaIfood')::boolean then v_obs := v_obs || ' · ENTREGA PELO iFOOD'; end if;
  select (m->'cash'->>'changeFor') into v_troco from jsonb_array_elements(coalesce(p_order->'payments'->'methods', '[]'::jsonb)) m where m->'cash'->>'changeFor' is not null limit 1;
  if v_troco is not null and public._ifood_n(to_jsonb(v_troco)) > 0 then v_obs := v_obs || ' · levar troco para R$ ' || replace(to_char(public._ifood_n(to_jsonb(v_troco)), 'FM9999990.00'), '.', ','); end if;
  if upper(coalesce(p_order->>'orderTiming', '')) = 'SCHEDULED' then
    v_agend := coalesce(p_order->'schedule'->>'deliveryDateTimeStart', p_order->'delivery'->>'deliveryDateTime', p_order->>'preparationStartDateTime', '');
    v_obs := v_obs || ' · AGENDADO' || case when v_agend <> '' then ' para ' || to_char((v_agend::timestamptz) at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') else '' end;
  end if;
  if nullif(btrim(coalesce(p_order->'delivery'->>'observations', '')), '') is not null then v_obs := v_obs || ' · ' || btrim(p_order->'delivery'->>'observations'); end if;
  if p_simulado then v_obs := v_obs || ' · TESTE (simulação)'; end if;
  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido, endereco, complemento, referencia, observacoes_entrega,
                      status_pagamento, recebido_em, valor_original, valor_desconto, desconto_detalhe, origem, taxa_entrega, caixa_id, requisicao_id, canal)
  values (v_venda, v_nome, nullif(v_tel, ''), v_forma, v_total, 0, 'Confirmada', v_tipo, 'Recebido',
          case when v_tipo = 'Entrega' then coalesce(v_end, '') else '' end, case when v_tipo = 'Entrega' then v_comp else '' end, case when v_tipo = 'Entrega' then v_ref else '' end, v_obs,
          v_stpag, case when v_stpag = 'Pago' then now() end, (v_val->>'original')::numeric, (v_val->>'descontoLoja')::numeric,
          case when (v_val->>'descontoLoja')::numeric > 0 then 'Desconto/cupom iFood pago pela loja' else '' end, 'Balcão', (v_val->>'taxaEntrega')::numeric, v_caixa, 'ifood:' || v_id, 'iFood')
  returning numero_pedido into v_numero;

  v_sem := public._ifood_gravar_itens(v_venda, p_order, false);
  update vendas set custo_total = coalesce((select sum(custo_unitario * quantidade) from itens_venda where venda_id = v_venda), 0) where id = v_venda;

  perform public._ifood_gravar_pagamentos(v_venda, p_order, v_total, (v_val->>'entregaIfood')::boolean);

  insert into ifood_pedidos (pedido_ifood, venda_id, numero_ifood, estado, expira_em, itens_sem_ligacao, simulado, bruto)
  values (v_id, v_venda, v_disp, 'novo', now() + interval '8 minutes', v_sem, p_simulado, p_order);
  update ifood_estado set ultimo_pedido_em = now(), atualizado_em = now() where id;
  perform _auditar('Pedido do iFood recebido', 'iFood #' || v_disp || ' → venda #' || v_numero || ' · R$ ' || replace(to_char(v_total, 'FM9999990.00'), '.', ',') || case when v_sem > 0 then ' · ' || v_sem || ' item(ns) sem ligação' else '' end || case when p_simulado then ' · SIMULAÇÃO' else '' end, null);
  perform _integ_log('ifood', case when v_sem > 0 then 'aviso' else 'info' end, 'Pedido #' || v_disp || ' recebido' || case when v_sem > 0 then ' (' || v_sem || ' item sem ligação)' else '' end);
  return jsonb_build_object('ok', true, 'vendaId', v_venda, 'numero', v_numero, 'semLigacao', v_sem);
end $function$;

-- Pedido alterado pelo cliente: refaz itens, valores e pagamentos com a mesma regra (mantém a comissão real, se já veio)
create or replace function public.ifood_atualizar_pedido(p_order jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public'
as $function$
declare r ifood_pedidos%rowtype; v_sem int; v_val jsonb; v_total numeric; v_forma text;
begin
  select * into r from ifood_pedidos where pedido_ifood = p_order->>'id' for update;
  if not found then return public.ifood_criar_pedido(p_order, false); end if;
  if r.venda_id is null or r.estado = 'cancelado' then return jsonb_build_object('ok', true, 'ignorado', true); end if;
  v_sem := public._ifood_gravar_itens(r.venda_id, p_order, true);
  v_val := public._ifood_valores(p_order);
  v_total := (v_val->>'total')::numeric;
  v_forma := public._ifood_gravar_pagamentos(r.venda_id, p_order, v_total, (v_val->>'entregaIfood')::boolean);
  if r.comissao is not null and r.comissao > 0 then perform public._ifood_aplicar_comissao(r.venda_id, r.comissao); end if;
  update vendas set valor_total = v_total, valor_original = (v_val->>'original')::numeric, valor_desconto = (v_val->>'descontoLoja')::numeric,
         desconto_detalhe = case when (v_val->>'descontoLoja')::numeric > 0 then 'Desconto/cupom iFood pago pela loja' else '' end,
         taxa_entrega = (v_val->>'taxaEntrega')::numeric, forma_pagamento = v_forma,
         custo_total = coalesce((select sum(custo_unitario * quantidade) from itens_venda where venda_id = r.venda_id), 0)
   where id = r.venda_id;
  update ifood_pedidos set bruto = p_order, itens_sem_ligacao = v_sem, atualizado_em = now() where pedido_ifood = r.pedido_ifood;
  perform _auditar('Pedido do iFood alterado pelo cliente', 'iFood #' || r.numero_ifood, null);
  perform _integ_log('ifood', 'aviso', 'Pedido #' || r.numero_ifood || ' foi alterado pelo cliente');
  return jsonb_build_object('ok', true, 'semLigacao', v_sem);
end $function$;

-- Repasse do iFood: grava a comissão real em cada venda (substitui a estimada)
create or replace function public.ifood_repasses_gravar(p_lista jsonb)
 returns integer language plpgsql security definer set search_path to 'public'
as $function$
declare e jsonb; o jsonb; v_n int := 0; v_ped int; v_venda uuid; v_com numeric;
begin
  for e in select value from jsonb_array_elements(coalesce(p_lista, '[]'::jsonb)) loop
    if nullif(e->>'id', '') is null then continue; end if;
    v_ped := 0;
    for o in select value from jsonb_array_elements(case when jsonb_typeof(e->'orders') = 'array' then e->'orders' else '[]'::jsonb end) loop
      v_venda := null; v_com := null;
      update ifood_pedidos set repassado_em = coalesce(repassado_em, now()), repasse_id = e->>'id', comissao = coalesce(nullif(public._ifood_n(o->'commission'), 0), nullif(public._ifood_n(o->'fees'), 0), comissao)
       where pedido_ifood = coalesce(o->>'orderId', o->>'id')
       returning venda_id, comissao into v_venda, v_com;
      if found then
        v_ped := v_ped + 1;
        if v_com is not null and v_com > 0 then perform public._ifood_aplicar_comissao(v_venda, v_com); end if;
      end if;
    end loop;
    insert into ifood_repasses (id, pago_em, periodo_ini, periodo_fim, valor, pedidos, bruto)
    values (e->>'id', nullif(e->>'paymentDate', '')::date, nullif(e->>'periodStart', '')::date, nullif(e->>'periodEnd', '')::date, public._ifood_n(coalesce(e->'amount', e->'value')), v_ped, e)
    on conflict (id) do update set valor = excluded.valor, pedidos = excluded.pedidos, pago_em = excluded.pago_em, bruto = excluded.bruto;
    v_n := v_n + 1;
  end loop;
  return v_n;
end $function$;

-- ---------- 6) iFood: cancelamento NÃO gera reembolso para a loja devolver (quem devolve ao cliente é o iFood) ----------
create or replace function public._reembolso_ao_cancelar()
 returns trigger language plpgsql security definer set search_path to 'public'
as $function$
begin
  if new.status::text = 'Cancelada' and old.status::text <> 'Cancelada' and new.status_pagamento::text = 'Pago'
     and new.canal is distinct from 'iFood' then
    insert into public.reembolsos (venda_id, valor, forma_pagamento, motivo, cancelado_por)
    values (new.id, new.valor_total, coalesce(new.forma_pagamento,''), coalesce(new.motivo_cancelamento,''), auth.uid())
    on conflict (venda_id) do nothing;
  end if;
  return new;
end $function$;

-- ---------- 7) iFood: "Saiu para entrega" só avisa o iFood quando a LOJA entrega ----------
create or replace function public._ifood_trg_status()
 returns trigger language plpgsql security definer set search_path to 'public'
as $function$
declare r ifood_pedidos%rowtype;
begin
  if new.canal is distinct from 'iFood' then return null; end if;
  if not public._integracao_ligada('ifood') then return null; end if;
  select * into r from ifood_pedidos where venda_id = new.id;
  if not found or r.simulado or r.estado in ('cancelado', 'concluido') then return null; end if;
  if new.status = 'Cancelada' and old.status is distinct from 'Cancelada' then
    perform public._ifood_enfileirar(r.pedido_ifood, 'cancelar', jsonb_build_object('motivo', new.motivo_cancelamento));
  elsif new.status_pedido is distinct from old.status_pedido and new.status = 'Confirmada' then
    if new.status_pedido::text = 'Em preparo' then
      if r.estado = 'novo' then perform public._ifood_enfileirar(r.pedido_ifood, 'confirmar'); end if;
      perform public._ifood_enfileirar(r.pedido_ifood, 'iniciar_preparo');
    elsif new.status_pedido::text = 'Pronta' then
      perform public._ifood_enfileirar(r.pedido_ifood, 'pronto');
    elsif new.status_pedido::text = 'Saiu para entrega' and upper(coalesce(r.bruto->'delivery'->>'deliveredBy', '')) <> 'IFOOD' then
      perform public._ifood_enfileirar(r.pedido_ifood, 'despachar');
    end if;
  end if;
  return null;
end $function$;

-- ---------- 8) Relatório por canal: margem tira custo, taxas/comissão e imposto ----------
create or replace function public.api_ifood_relatorio(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public'
as $function$
declare v_dias int := least(greatest(coalesce(nullif(p->>'dias', '')::int, 30), 1), 365);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'dias', v_dias,
    'canais', coalesce((select jsonb_agg(jsonb_build_object('canal', c, 'pedidos', n, 'total', t, 'ticket', case when n > 0 then round(t / n, 2) else 0 end,
          'custo', k, 'taxas', tx, 'impostos', round(imp, 2), 'margem', round(t - k - tx - imp, 2),
          'margemPct', case when t > 0 then round((t - k - tx - imp) / t * 100, 1) else 0 end, 'cancelados', cx) order by t desc)
      from (select case when v.canal = 'iFood' then 'iFood' when v.origem::text = 'Cardápio' then 'Cardápio' when v.origem::text = 'Garçom' then 'Garçom' else 'Balcão' end c,
                   count(*) filter (where v.status = 'Confirmada') n, coalesce(sum(v.valor_total) filter (where v.status = 'Confirmada'), 0) t,
                   coalesce(sum(v.custo_total) filter (where v.status = 'Confirmada'), 0) k,
                   coalesce(sum((select coalesce(sum(pv.taxa_aplicada), 0) from pagamentos_venda pv where pv.venda_id = v.id)) filter (where v.status = 'Confirmada'), 0) tx,
                   coalesce(sum(v.valor_total * public._imposto_pct((v.data_hora at time zone 'America/Sao_Paulo')::date) / 100) filter (where v.status = 'Confirmada'), 0) imp,
                   count(*) filter (where v.status = 'Cancelada') cx
            from vendas v where v.data_hora > now() - make_interval(days => v_dias) group by 1) x), '[]'::jsonb),
    'ifood', jsonb_build_object(
      'confirmacaoMediaMin', (select round(avg(extract(epoch from (confirmado_em - criado_em)) / 60)::numeric, 1) from ifood_pedidos where confirmado_em is not null and not simulado and criado_em > now() - make_interval(days => v_dias)),
      'itensSemLigacao', (select coalesce(sum(itens_sem_ligacao), 0) from ifood_pedidos where criado_em > now() - make_interval(days => v_dias) and estado <> 'cancelado'),
      'comissaoReal', (select coalesce(sum(comissao), 0) from ifood_pedidos where comissao is not null and criado_em > now() - make_interval(days => v_dias)),
      'cancelamentos', coalesce((select jsonb_agg(jsonb_build_object('motivo', m, 'qtd', q) order by q desc) from (select coalesce(nullif(motivo_cancelamento, ''), 'sem motivo') m, count(*) q from vendas where canal = 'iFood' and status = 'Cancelada' and data_hora > now() - make_interval(days => v_dias) group by 1) y), '[]'::jsonb),
      'maisVendidos', coalesce((select jsonb_agg(jsonb_build_object('nome', n, 'qtd', q) order by q desc) from (select left(iv.descricao, 60) n, sum(iv.quantidade) q from itens_venda iv join vendas v on v.id = iv.venda_id where v.canal = 'iFood' and v.status = 'Confirmada' and v.data_hora > now() - make_interval(days => v_dias) group by 1 order by 2 desc limit 8) z), '[]'::jsonb)));
end $function$;

-- ---------- 9) A receber do iFood: já sem a comissão ----------
create or replace function public.api_ifood_financeiro(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public'
as $function$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'aReceber', (select jsonb_build_object('pedidos', count(distinct v.id), 'valor', coalesce(sum(pv.valor - coalesce(pv.taxa_aplicada, 0)), 0), 'bruto', coalesce(sum(pv.valor), 0))
       from ifood_pedidos i join vendas v on v.id = i.venda_id join pagamentos_venda pv on pv.venda_id = v.id and pv.forma_pagamento = 'iFood (pago no app)'
       where not i.simulado and v.status = 'Confirmada' and i.repassado_em is null and i.estado <> 'cancelado'),
    'recebido30d', (select jsonb_build_object('repasses', count(*), 'valor', coalesce(sum(valor), 0)) from ifood_repasses where coalesce(pago_em, criado_em::date) >= current_date - 30),
    'comissao30d', (select coalesce(sum(comissao), 0) from ifood_pedidos where repassado_em > now() - interval '30 days'),
    'repasses', coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'pagoEm', r.pago_em, 'valor', r.valor, 'pedidos', r.pedidos) order by r.pago_em desc nulls last) from (select * from ifood_repasses order by coalesce(pago_em, criado_em::date) desc limit 15) r), '[]'::jsonb));
end $function$;

-- funções internas: ninguém chama direto pela internet
revoke all on function public._ifood_valores(jsonb) from public, anon, authenticated;
revoke all on function public._ifood_gravar_pagamentos(uuid, jsonb, numeric, boolean) from public, anon, authenticated;
revoke all on function public._ifood_aplicar_comissao(uuid, numeric) from public, anon, authenticated;

-- ---------- 10) Ajuda da IA: imposto sobre vendas ----------
insert into public.ai_ajuda (slug, titulo, grupo, ordem, perfis, ativo, palavras_chave, passos, comuns, atualizado_em)
select 'man-admin-109-imposto-vendas', 'Imposto sobre vendas (estimado) e DAS', 'lista', 109, array['Admin'], true,
  'imposto alíquota aliquota simples das dre resultado margem lucro estimado contador taxa de entrega imposto das vendas',
  E'Administrador → Painel → Relatórios → cartão "DRE e relatório mensal": escolha o mês e, em "Imposto sobre vendas deste mês", digite a alíquota que o contador informar (ex.: 6 ou 6,5) e toque em Salvar.\nA alíquota vale para aquele mês e para os seguintes, até salvar outra. Mês sem alíquota própria usa a do mês anterior mais próximo; sem nenhuma, usa a dos dados fiscais da empresa.\nO imposto é calculado sobre tudo o que foi faturado no mês (vendas e eventos) e aparece no DRE, na Visão Geral (IMPOSTOS), nos relatórios e na margem do cadastro de produto, de combo e da Calculadora. Funciona com ou sem a nota fiscal ligada. O custo do produto não muda.\nDAS: lance o pagamento como despesa na categoria "Imposto das vendas (DAS)". Com alíquota cadastrada, ele não entra de novo nas despesas (o imposto já foi estimado); o DRE mostra quanto foi pago para comparar. Sem alíquota, o DAS entra como despesa comum.\nO DRE mostra também a linha "Taxa de entrega e acréscimos cobrados": a taxa cobrada do cliente entra na receita e o repasse ao entregador entra nas despesas (Entregadores).',
  'Só o Administrador vê e altera a alíquota. É uma estimativa; o valor oficial é o DAS calculado pelo contador.', now()
where not exists (select 1 from public.ai_ajuda where slug = 'man-admin-109-imposto-vendas');

-- ---------- 11) Ajuda da IA: textos do iFood e da nota fiscal atualizados ----------
update public.ai_ajuda set passos = passos || E'\nValor da venda: a venda grava o que fica para a loja — itens menos o desconto que a loja paga, mais a taxa de entrega só quando a loja entrega. Cupom pago pelo iFood e a taxa de serviço do iFood ficam fora. Entregador do iFood: o pedido mostra "ENTREGA PELO iFOOD" e "Saiu para entrega" não é enviado ao iFood.\nPedido do iFood cancelado não gera reembolso para a loja devolver: quem devolve ao cliente é o iFood.', atualizado_em = now()
 where slug = 'man-admin-103-ifood' and passos not like '%ENTREGA PELO iFOOD%';

update public.ai_ajuda set passos = replace(replace(passos,
  'Financeiro: mostra quanto falta receber do iFood (pedidos pagos no app ainda sem repasse), os repasses recebidos e a comissão real.',
  'Financeiro: mostra quanto falta receber do iFood (pedidos pagos no app ainda sem repasse, já sem a comissão), os repasses recebidos e a comissão real. Comissão: cadastre o % do iFood em Operação → Pagamentos, forma "iFood"; ela entra nas taxas de cada pedido e é trocada pela comissão real quando o repasse chega.'),
  'Relatório por canal: vendas, ticket, margem e cancelamentos de balcão, cardápio e iFood.',
  'Relatório por canal: vendas, ticket, margem (já sem custo, taxas e comissão e imposto estimado) e cancelamentos de balcão, cardápio e iFood.'),
  palavras_chave = palavras_chave || ' margem imposto', atualizado_em = now()
 where slug = 'man-admin-105-ifood-inteligencia' and passos not like '%já sem a comissão%';

update public.ai_ajuda set passos = replace(passos,
  'Com a nota fiscal ligada, o resultado do período (DRE) passa a mostrar a linha "Impostos sobre vendas (estimado)". Desligada, nada muda.',
  'A alíquota dos dados fiscais é a padrão do imposto estimado; a de cada mês fica em Painel → Relatórios, cartão DRE (veja "Imposto sobre vendas"). O imposto aparece no resultado com ou sem a nota fiscal ligada.'), atualizado_em = now()
 where slug = 'man-admin-106-fiscal-cadastro' and passos like '%Desligada, nada muda.%';

update public.ai_ajuda set comuns = trim(coalesce(comuns, '') || ' Pedido do iFood cancelado não gera reembolso: quem devolve ao cliente é o iFood.'), atualizado_em = now()
 where slug = 'man-admin-98-reembolsos' and coalesce(comuns, '') not like '%iFood%';
