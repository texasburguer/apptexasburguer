# Receita: imposto sobre vendas nos relatórios e iFood revisado

## O que mudou
1. **Imposto estimado com ou sem nota fiscal.** Antes ele só aparecia com a NFC-e ligada. Agora a alíquota é guardada **por mês** (`sistema.ImpostoAliquotasMes`). Um mês sem alíquota própria usa a do mês anterior mais próximo; sem nenhuma, usa a de "Dados fiscais da empresa".
2. **Caixa "Imposto sobre vendas deste mês"** no cartão DRE (Painel → Relatórios). Só o Admin vê.
3. **Onde o imposto entra:**
   - DRE (linha com o %), Visão Geral (caixa IMPOSTOS);
   - relatórios: Resultado, Margem por forma (coluna Imposto), Ponto de equilíbrio e Projeção;
   - margem do cadastro de produto, do combo e da Calculadora.
   O **custo do produto não muda**.
4. **DAS sem contar duas vezes.** Há uma categoria de despesa nova, "Imposto das vendas (DAS)". Se o mês a que o DAS se refere tem alíquota, a despesa sai do total e o DRE mostra quanto foi pago. Esse mês é a competência, se preenchida; senão, o mês anterior ao pagamento. Sem alíquota, o DAS conta como despesa comum. "Brindes" também passou a ser aceita no banco (antes virava "Outros").
5. **DRE corrigido:**
   - linha nova "Taxa de entrega e acréscimos cobrados", porque a receita já tinha a taxa;
   - nota de rodapé corrigida;
   - os eventos do mês agora são os do mês certo (antes caíam no mês seguinte);
   - "Taxas de pagamento" agora se chama "Taxas de pagamento e comissões".
6. **iFood:**
   - **Valor da venda** é o que fica para a loja: itens − desconto pago pela loja + taxa de entrega só quando a loja entrega. Ficam fora o cupom pago pelo iFood, as taxas de serviço do iFood (`additionalFees`) e a entrega feita pelo iFood.
   - **Comissão:** é estimada pela taxa % da forma "iFood" e gravada em `pagamentos_venda.taxa_aplicada`. Quando o repasse chega, troca pela comissão real.
   - **Pagamento:** "pagar na entrega" só quando a loja entrega. Pedido alterado refaz valores e pagamentos sem duplicar.
   - **Cancelamento** de pedido do iFood não cria reembolso.
   - **"Despachar"** não é enviado quando o entregador é do iFood. O pedido mostra "ENTREGA PELO iFOOD".
   - **Relatório por canal:** margem = total − custo − taxas − imposto.
   - **"A receber do iFood"** já sem a comissão.
   - **Aviso** no cartão do iFood quando a forma "iFood" está sem comissão.

## Onde
- `1-mudancas-nos-arquivos/`: um `.diff` por arquivo da página (linhas `-` saem, `+` entram; `?v=` zerados).
  - `app-10` traz os ajudantes do imposto: `impostoPctYm_`, `impostoDoPeriodo_`, `dasJaEstimado_`, `calcularDRE`/`renderDRE` novos e `salvarAliquotaMes_`.
  - `app-14`: relatórios e Visão Geral. `app-11`: flags e textos do iFood.
  - `app-25` e `app-03`: margem. `app-02`: calculadora. `app-01` e `app-08`: categoria nova, rota e novidades. `app-09`: ajuda.
  - `index.html`: caixa da alíquota.
- `2-banco/imposto-e-ifood-banco.sql`: funções do banco, ajuda da IA (linha nova e textos). `teste-imposto-e-ifood.sql`: teste que não grava nada.

## Como fazer
1. **Banco:** cole `2-banco/imposto-e-ifood-banco.sql` no SQL Editor e rode.
   - Precisa já ter as integrações (iFood/Nota fiscal) e o reembolso automático no banco.
   - Se o Supabase recusar alguma parte, rode por blocos (cada `create or replace function` é independente; as partes 10 e 11 são só textos da ajuda).
2. **Página:**
   - Aplique os `.diff`.
   - Nos textos novos (ajuda e novidades) não há nome de restaurante.
   - Rode `selar.py` e suba o SHELL do `sw.js`. Envie tudo junto.
3. **No app (Admin):**
   - Painel → Relatórios → cartão DRE → digite a alíquota do mês que o contador passar e toque em Salvar.
   - Operação → Pagamentos → forma "iFood" → taxa % = comissão do contrato do iFood.

## Cuidados
- `RESERVA_INDISPONIVEL_` e `SB_RPC_DIRETO_` (app-01) precisam ter `salvarAliquotaMes`, senão a tela não salva.
- A forma do iFood é achada pelo nome "ifood" (`_ifood_forma()`). Se o projeto usa outro nome, ajuste antes.
- O DAS é lançado na categoria nova. Lançado em "Impostos", ele conta como despesa comum e o imposto entra duas vezes.
- Vendas antigas do iFood ficam como estavam; só os pedidos novos (ou alterados) usam a regra nova.
- A margem do cadastro usa a alíquota do mês atual. Para quem não é Admin ela vem 0 (o banco só manda a alíquota ao Admin).

## Como testar
1. No SQL Editor, rode `2-banco/teste-imposto-e-ifood.sql`. Ele termina com "RELATORIO {...}" e não grava nada. Confira:
   - p1 total 52 e taxa 6,24;
   - p2 com entrega 0 e "Pago";
   - p3 "A Receber";
   - depois do repasse, taxa 7,50;
   - reembolso_ifood 0.
2. Admin → Painel → Relatórios → DRE: salve 6 no mês atual.
   - Aparecem a linha "Imposto sobre vendas (estimado, 6%)" e, na Visão Geral, a caixa IMPOSTOS.
   - Apague, salve e confira que o mês volta a usar a alíquota anterior.
3. Lance uma despesa "Imposto das vendas (DAS)" paga hoje. Com alíquota no mês passado, ela não soma nas despesas e o DRE mostra "DAS pago neste mês".
4. Produto novo com preço 20 e custo 8, com 6,5%: a margem mostra "R$ 10,70 (53%) · já tirado o imposto de 6,5%".
