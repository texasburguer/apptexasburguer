# Receita: visitas ao cardápio na tela Início

## O que mudou
1. **Contador "Cardápio hoje" na tela Início** (Admin e Operador): mostra quantos aparelhos de clientes abriram o cardápio eletrônico hoje.
   - Cada aparelho conta 1 vez por dia, pelo horário de São Paulo, e zera à meia-noite.
   - Aparelho da equipe nunca conta. Ele fica marcado ao entrar no sistema interno (`cdAparelhoEquipe`) ou quando tem sessão salva.
2. **Nova ordem do Início**, de cima para baixo:
   - alerta numa faixa fina no topo, que só aparece quando há algo (mostra o primeiro e "+N");
   - pedidos em andamento;
   - Caixa | Vendas hoje;
   - Cardápio hoje | Mesas. O cartão "Contas das mesas" saiu e o valor a receber foi para dentro do cartão Mesas.

## Onde
- `2-banco/visitas-cardapio.sql`: tabela `cardapio_visitas` (RLS sem acesso direto), `api_registrar_visita_cardapio` (pública) e `api_visitas_cardapio_hoje` (Admin/Operador), mais a linha da ajuda da IA.
- `1-mudancas-nos-arquivos/` (o `?v=` está zerado):
  - `app-15`: `cdContarVisita_()`, chamada uma vez em `carregarCardapioPublico`, 3 s depois.
  - `app-01`: marca o aparelho em `entrarNoApp`; `visitasCardapioHoje` em `SB_RPC_DIRETO_` e em `RESERVA_INDISPONIVEL_`; novidades.
  - `app-05`: `renderInicio` reordenado e `inicioCarregarVisitas_()` (busca no máximo 1 vez por minuto).
  - `estilo-14-computador.css`: estilo `.resumo-faixa`. Vale no celular também.
  - `app-09`: ajuda "Tela Início e visitas ao cardápio".

## Como fazer
1. Rode `2-banco/visitas-cardapio.sql` no SQL Editor.
2. Aplique os `.diff`. Se o projeto ainda não tem o `estilo-14-computador.css`, cole o bloco `.resumo-faixa` no fim do CSS que ele usa.
3. Nos textos novos não há nome de restaurante. Rode `selar.py`, suba o SHELL do `sw.js` e envie tudo junto.

## Cuidados
- A visita usa a chave pública (`sbRpcPublico_`). A função só aceita um código de aparelho de 16 a 40 letras/números e para de contar acima de 20.000 por dia.
- A contagem conta aparelhos, não pessoas: dois aparelhos da mesma pessoa contam duas vezes, e aba anônima ou navegador limpo contam de novo.
- Os nomes das chaves no aparelho são `cdAparelhoId`, `cdVisitaDia` e `cdAparelhoEquipe`. Se o projeto tiver outra chave de sessão, a checagem usa a `SESSAO_KEY` dele.

## Como testar
1. Num celular que nunca entrou no sistema, abra o cardápio e espere 5 s. No Início (Admin), "Cardápio hoje" sobe 1 em até 1 minuto.
2. Recarregue o cardápio no mesmo celular: o número não muda.
3. Abra o cardápio num aparelho em que você entrou no sistema: não conta.
4. Com estoque no mínimo, o alerta aparece como faixa fina no topo; ao tocar, abre os avisos.
