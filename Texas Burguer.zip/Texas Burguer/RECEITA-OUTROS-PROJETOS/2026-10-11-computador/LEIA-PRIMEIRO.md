# Receita: aparência no computador e ponto de milhar

## O que mudou
Vale só para telas a partir de 900 px de largura. No celular nada muda, com duas exceções que valem para todos os aparelhos: o alinhamento dos títulos de tabela e os valores em reais.

1. **Topo numa linha:** logo pequeno à esquerda, usuário e botões ("Ajuda" e "Senha" com o nome) à direita. As abas ficam grudadas no alto ao rolar a página.
2. **Administrador com menu lateral:** mostra todos os grupos e telas (um clique). As barras de grupo e de tela dentro de cada seção somem no computador. A tela inicial do Admin mostra "👈 Escolha uma tela no menu ao lado." Para o Operador, o menu tem as telas de atendimento.
3. **Área mais larga em tela grande:** até 1240 px, deixando espaço para o botão do assistente no canto.
4. **Pedidos lado a lado:** Retiradas, Entregas e Mesas em grade de 2 ou 3 colunas. As concluídas também ficam em grade.
5. **Caixa em duas colunas:**
   - Cliente: busca à esquerda; retirada, entrega ou mesa à direita.
   - Itens: adicionar à esquerda; carrinho fixo à direita.
   - Pagamento: forma, desconto e quando recebe à esquerda; pagamento e "Finalizar venda" fixos à direita.
6. **Acabamento:**
   - Visão Geral com todos os números numa faixa (4 ou 5 por linha).
   - Avisos com • no mesmo tamanho de letra do resto.
   - Linha da tabela acende sob o mouse; cursor de mão no que é clicável.
   - Gráfico "Vendas por dia" do DRE desenhado no tamanho real (não fica gigante). O rótulo do dia 30 some em mês de 31 dias, para não encavalar com o 31.
7. **Para todos os aparelhos:**
   - Título de coluna alinhado com os números: `th[align=right]`. O CSS deixava todos os títulos à esquerda.
   - Valores com ponto de milhar e sinal na frente: "R$ 1.475,90" e "−R$ 3.691,11". Valem `formatarMoeda`, o `R$_` das integrações e o preço do cardápio.

## Onde
- `1-codigo-novo/estilo-14-computador.css`: arquivo novo, inteiro.
- `2-mudancas-nos-arquivos/*.diff`:
  - `index.html`: link do CSS novo, `<nav id="adminLateral">`, dica do Admin e divisões `cx-2col` / `cx-col` / `cx-lado` no Caixa.
  - `app-02`: menu lateral em `montarBarrasAdmin_` e classe `adm-ativo` em `ativarApenasSecao_`.
  - `app-14`: bloco `vg-stats` na Visão Geral.
  - `app-10`: gráfico do DRE.
  - `app-01`: `formatarMoeda` e novidades.
  - `app-11`: `R$_`.
  - `app-15`: `cdFormatarPreco`.
  - `app-09`: ajuda "No computador".
  - O `?v=` está zerado nos diffs.
- `3-banco/ajuda-computador.sql`: linha nova da ajuda da IA.

## Como fazer
1. Copie `estilo-14-computador.css` para a pasta da página. No `index.html`, logo depois da linha do `estilo-13-visual.css`, ponha `<link rel="stylesheet" href="estilo-14-computador.css?v=00000000" data-origem="">`.
2. Aplique os `.diff`. No Caixa, confira que cada `<div class="cx-2col"><div class="cx-col">` fecha com `</div></div>` no lugar certo: os IDs dos campos não mudam.
3. Nos textos novos (ajuda e novidades), use o nome do projeto onde precisar. Não há nome de restaurante neles.
4. Rode `selar.py` (ele põe o CSS novo na LISTA do `sw.js`), suba o SHELL do `sw.js` e envie tudo junto.
5. No SQL Editor, rode `3-banco/ajuda-computador.sql`.

## Cuidados
- Tudo de computador está dentro de `@media (min-width:900px)`. Não tire isso, senão o celular muda.
- O menu lateral usa a lista `ADMIN_SUBABAS` e o rótulo de `ADMIN_SUBABAS_ROTULOS`. Tela nova do Admin entra sozinha se estiver nessas listas.
- As seções da página precisam continuar filhas diretas de `#mainWrap`, porque o menu lateral usa a grade do `#mainWrap`.
- `formatarMoeda` agora devolve "−R$" (sinal de menos de verdade, U+2212) para negativo. Onde o código já escreve "− " na frente, passe o valor positivo (`Math.abs`).

## Como testar
1. No computador, abra o Admin: aparece o menu ao lado com todos os grupos. Clicar em "Relatórios" abre a tela sem passar pelo grupo.
2. Em Relatórios → "Vendas por dia", os títulos PEDIDOS, FATURAMENTO e TICKET MÉDIO ficam em cima dos números. O gráfico do DRE fica baixo, com números pequenos.
3. No Caixa, adicione 2 itens: o carrinho e o total ficam à direita. Em "3. Pagamento", o botão "Finalizar venda" fica à direita.
4. No celular (ou janela estreita), confira que tudo está igual a antes, só com o ponto de milhar nos valores.
