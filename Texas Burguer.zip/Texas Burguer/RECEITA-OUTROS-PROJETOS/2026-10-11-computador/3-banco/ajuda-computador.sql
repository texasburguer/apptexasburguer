-- Ajuda da IA: como fica o sistema no computador (11/10/2026). Pode rodar mais de uma vez.
insert into public.ai_ajuda (slug, titulo, grupo, ordem, perfis, ativo, palavras_chave, passos, comuns, atualizado_em)
select 'man-admin-110-computador', 'No computador (notebook ou monitor)', 'lista', 110, array['Admin','Operador'], true,
  'computador notebook monitor pc tela grande menu lateral topo abas pedidos lado a lado caixa carrinho direita milhar',
  E'Em tela a partir de 900 px de largura, o topo fica numa linha só (logo à esquerda, usuário e botões à direita) e as abas ficam sempre à vista no alto, mesmo rolando a página.\nAdministrador: as telas aparecem num menu ao lado, com todos os grupos abertos. Um clique abre a tela; se o menu não couber, role dentro dele. Para o Operador, a aba Operação mostra Ocorrências e Feedbacks no menu ao lado.\nPedidos: os pedidos ficam lado a lado (2 ou 3 por linha). Caixa: a escolha fica à esquerda; carrinho, total e pagamento ficam à direita.\nValores aparecem com ponto de milhar (R$ 1.475,90) e o negativo com o sinal na frente (−R$ 3.691,11).',
  'No celular nada muda.', now()
where not exists (select 1 from public.ai_ajuda where slug = 'man-admin-110-computador');
