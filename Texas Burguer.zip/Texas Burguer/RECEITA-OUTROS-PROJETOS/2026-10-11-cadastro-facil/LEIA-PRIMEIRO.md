# Receita: cadastro fácil de produtos + custo automático

## O que mudou
- Produto em 3 tipos ("Como é feito?"): **Preparado aqui** (receita), **Comprado pronto** (bebida, com estoque próprio), **Sem controle** (custo digitado).
- Receita com busca por digitação, "+ criar" ingrediente na hora, "Copiar receita de outro produto"; ingrediente em kg/l pede g/ml (a receita guarda em kg/l).
- Ingrediente: "Paguei R$ __ por __" calcula o custo; tela "💲 Preços em lote".
- Banco recalcula sozinho o custo de produtos (receita) e combos (soma dos produtos) quando o preço de um ingrediente muda (edição, lote, compra recebida). Troca kg↔g / l↔ml converte as receitas.
- Estoque com abas Ingredientes × Bebidas e itens prontos; bebidas somem da receita.
- Aviso "Cadastro incompleto" (produtos sem custo, ingredientes sem preço); lista de produtos mostra "custo não informado".
- Compras: busca do item, aviso quando não entra no estoque, "Embalagens × Unidades em cada", liga sozinho texto igual ao nome de um ingrediente.
- Venda/edição de venda: se o banco responder "O custo de ... não confere", a tela atualiza os custos e tenta UMA vez (o preço nunca muda).

## Onde
- Banco: `1-banco/2026-10-11-custo-automatico.sql` (gatilhos, `api_editar_produto` grava a receita antes dos preços, `api_salvar_precos_lote`).
- Página: arquivos novos `2-arquivos-novos/app-25-cadastro-facil.js` e `estilo-12-cadastro-facil.css`; mudanças exatas em `3-mudancas-nos-arquivos/*.diff` (index.html, app-01, app-03, app-06, app-08, app-09, app-12).

## Como fazer
1. SQL Editor do Supabase: rode `1-banco/2026-10-11-custo-automatico.sql` inteiro.
2. Rode `1-banco/teste-custo-automatico.sql`: a mensagem "RELATORIO {...}" deve mostrar cada valor igual ao do nome da chave (ex.: `1_produto_receita_esperado_7.50: 7.50`) e `9_...recusa: false`, `10_...true: true`. Ele não grava nada.
3. Copie os 2 arquivos novos para a pasta da página e, no index.html, depois do último `<script src="app-...">`, acrescente:
   `<link rel="stylesheet" href="estilo-12-cadastro-facil.css?v=00000000">` e `<script src="app-25-cadastro-facil.js?v=00000000" charset="utf-8"></script>`.
4. Aplique os trechos dos `.diff` (linhas com `-` saem, com `+` entram). Os pop-ups Novo produto, Editar produto, Novo ingrediente, Editar ingrediente e o novo "Preços em lote" estão inteiros no `index.html.diff`.
5. Rode `selar.py`, suba o `sw.js` com a versão do SHELL aumentada e envie todos os arquivos juntos.

## Cuidados
- Nomes de tabelas/colunas iguais aos deste sistema: `produto_precos.custo`, `estoque.custo_unitario (numeric 10,4)`, `produto_ingredientes.quantidade_por_unidade (numeric 12,3)`, `produtos.estoque_proprio_ingrediente_id`.
- Produto com receita: o custo digitado é ignorado (vale o da receita). Produto sem receita mantém o custo digitado.
- A conversão automática só vale kg↔g e l↔ml. "un"→kg não converte: a tela avisa quais receitas revisar.
- Não copie nomes, cardápio nem textos do restaurante de origem.

## Como testar
1. Estoque → "💲 Preços em lote": dê preço a um ingrediente usado numa receita. O custo do produto muda na lista de produtos.
2. Produtos → + Novo produto → "Preparado aqui": digite um ingrediente, informe gramas e veja o custo aparecer sozinho.
3. "Comprado pronto": "Paguei 30 por 12" → custo R$ 2,50; a bebida aparece em Estoque → "Bebidas e itens prontos".
4. Compras: digite um item que não existe → aparece o aviso laranja; escolha um ingrediente → "✓ Entra no estoque".
