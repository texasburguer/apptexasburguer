-- TESTE DO CUSTO AUTOMÁTICO (não grava nada: termina com erro de propósito e desfaz tudo). Cole no SQL Editor.
-- Esperado: cada chave mostra o valor esperado no nome (ex.: 1_produto_receita_esperado_7.50 = 7.50) e a venda com custo velho é recusada.
do $$
declare adm uuid; op uuid; r jsonb; rep jsonb := '{}'::jsonb; carne uuid; pao uuid; prod uuid; combo uuid; lata uuid; forn uuid; precos jsonb; c numeric; cc numeric; fp text;
begin
  select u.id into adm from usuarios u where u.nivel::text in ('Admin','Desenvolvedor') and u.ativo limit 1;
  select u.id into op from usuarios u where u.nivel::text='Operador' and u.ativo limit 1;
  select id into forn from fornecedores where ativo limit 1;
  if forn is null then insert into fornecedores (nome, ativo) values ('zzFornTeste', true) returning id into forn; end if;
  select f.nome into fp from formas_pagamento f where f.ativa and coalesce(f.acrescimo_percentual,0)=0 limit 1;
  perform set_config('request.jwt.claims', json_build_object('sub',adm,'role','authenticated')::text, true);
  perform set_config('role','authenticated', true);
  perform api_add_ingrediente('{"nome":"zzTesteCarne","unidade":"kg","custo":40}');
  perform api_add_ingrediente('{"nome":"zzTestePao","unidade":"un","custo":1.5}');
  select id into carne from estoque where ingrediente='zzTesteCarne'; select id into pao from estoque where ingrediente='zzTestePao';
  r := api_add_produto(jsonb_build_object('nome','zzTesteBurger','precoBase',30,'custoBase',0,'ingredientes',jsonb_build_array(jsonb_build_object('ingredienteId',carne,'quantidadePorUnidade',0.15),jsonb_build_object('ingredienteId',pao,'quantidadePorUnidade',1))));
  prod := (r->>'id')::uuid;
  select max(custo) into c from produto_precos where produto_id=prod; rep := rep || jsonb_build_object('1_produto_receita_esperado_7.50', c);
  r := api_add_combo(jsonb_build_object('nome','zzTesteCombo','precoBase',50,'custoBase',0,'itens',jsonb_build_array(jsonb_build_object('produtoId',prod,'quantidade',2))));
  combo := (r->>'id')::uuid;
  select max(custo) into cc from combo_precos where combo_id=combo; rep := rep || jsonb_build_object('2_combo_esperado_15.00', cc);
  r := api_editar_ingrediente(jsonb_build_object('id',carne,'nome','zzTesteCarne','quantidade',0,'minimo',0,'unidade','kg','custo',50));
  select max(custo) into c from produto_precos where produto_id=prod; select max(custo) into cc from combo_precos where combo_id=combo;
  rep := rep || jsonb_build_object('3_ingrediente_50_produto_esperado_9.00', c, '3_combo_esperado_18.00', cc);
  r := api_salvar_precos_lote(jsonb_build_object('itens',jsonb_build_array(jsonb_build_object('id',carne,'unidade','g'))));
  select max(custo) into c from produto_precos where produto_id=prod;
  rep := rep || jsonb_build_object('4_receita_carne_esperado_150', (select quantidade_por_unidade from produto_ingredientes where produto_id=prod and ingrediente_id=carne), '4_custo_g_esperado_0.05', (select custo_unitario from estoque where id=carne), '4_produto_esperado_9.00', c);
  r := api_registrar_compra(jsonb_build_object('fornecedorId',forn,'status','Recebida','pagamento','Pago','itens',jsonb_build_array(jsonb_build_object('ingredienteId',carne,'quantidade',1,'unidade','kg','valorTotal',60))));
  select max(custo) into c from produto_precos where produto_id=prod; select max(custo) into cc from combo_precos where combo_id=combo;
  rep := rep || jsonb_build_object('5_estoque_carne_g_esperado_1000', (select quantidade from estoque where id=carne), '5_produto_esperado_10.50', c, '5_combo_esperado_21.00', cc);
  select jsonb_agg(jsonb_build_object('formaPagamentoId',f.id,'preco',30,'custo',5)) into precos from formas_pagamento f;
  r := api_editar_produto(jsonb_build_object('id',prod,'nome','zzTesteBurger','precos',precos,'ingredientes','[]'::jsonb));
  select max(custo) into c from produto_precos where produto_id=prod; select max(custo) into cc from combo_precos where combo_id=combo;
  rep := rep || jsonb_build_object('6_sem_receita_manual_esperado_5.00', c, '6_combo_esperado_10.00', cc);
  r := api_add_produto(jsonb_build_object('nome','zzTesteLata','precoBase',6,'custoBase',2.5,'estoqueProprio',jsonb_build_object('ativo',true,'unidade','un','quantidade',24,'minimo',6,'custo',2.5)));
  lata := (r->>'id')::uuid;
  select max(custo) into c from produto_precos where produto_id=lata; rep := rep || jsonb_build_object('7_lata_esperado_2.50', c);
  select jsonb_agg(jsonb_build_object('formaPagamentoId',f.id,'preco',6,'custo',0)) into precos from formas_pagamento f;
  r := api_editar_produto(jsonb_build_object('id',lata,'nome','zzTesteLata','precos',precos,'ingredientes','[]'::jsonb,'estoqueProprio',jsonb_build_object('ativo',true,'unidade','un','minimo',6,'custo',3)));
  select max(custo) into c from produto_precos where produto_id=lata; rep := rep || jsonb_build_object('8_lata_custo3_esperado_3.00', c);
  perform api_abrir_caixa('{"valorInicial":0}');
  if op is not null then perform set_config('request.jwt.claims', json_build_object('sub',op,'role','authenticated')::text, true); end if;
  r := api_iniciar_venda(jsonb_build_object('itens',jsonb_build_array(jsonb_build_object('produtoId',lata,'descricao','zzTesteLata','quantidade',1,'valorUnitario',6,'custoUnitario',2.5)),'pagamentos',jsonb_build_array(jsonb_build_object('forma',fp,'valor',6)),'tipoEntrega','Retirada','requisicaoId','zz-t1'));
  rep := rep || jsonb_build_object('9_venda_custo_velho_espera_recusa', r->>'ok');
  r := api_iniciar_venda(jsonb_build_object('itens',jsonb_build_array(jsonb_build_object('produtoId',lata,'descricao','zzTesteLata','quantidade',1,'valorUnitario',6,'custoUnitario',3)),'pagamentos',jsonb_build_array(jsonb_build_object('forma',fp,'valor',6)),'tipoEntrega','Retirada','requisicaoId','zz-t2'));
  rep := rep || jsonb_build_object('10_venda_custo_novo_espera_true', r->>'ok', '10_estoque_lata_esperado_23', (select e.quantidade from estoque e join produtos p on p.estoque_proprio_ingrediente_id=e.id where p.id=lata));
  raise exception 'RELATORIO %', rep::text;
end $$;
