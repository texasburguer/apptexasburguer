# Receita: brindes (prêmio de fidelidade e de indicação) na conta do cliente + ajustes do cardápio

Complementa a receita `2026-10-12-conta-cliente` (aplique aquela primeiro).

## O que muda para o cliente
- O botão Entrar/Minha conta saiu de cima do banner e virou uma FAIXA própria logo abaixo dele (`#cdContaBar`): "Entre para usar cupons…" + botão; logado mostra "Olá, Nome · 🎁 N brindes" e "Minha conta".
- Campo de data (nascimento): ícone do calendário visível no tema escuro (`color-scheme` + `::-webkit-calendar-picker-indicator`).
- Minha conta › Fidelidade usa o MESMO cartão do sistema (`.punch/.hole/.filled`, do estilo-01-base.css).
- Brindes: cartão completo (10 marcas) ou brinde de indicação → o cliente escolhe o produto-prêmio na Minha conta ou no carrinho (caixa `#cdContaBrindes`). Vai junto com itens ou sozinho; sai a R$ 0,00; a entrega é cobrada; sem pedido mínimo; cancelar devolve o brinde.
- Quem indica agora ganha o produto-prêmio (não mais cupom) quando o amigo conclui o 1º pedido. O cupom do indicado continua.

## O que muda para o Admin
- Os produtos marcados em Editar produto › Mais opções (Prêmio de fidelidade / Prêmio de indicação) são os brindes disponíveis. Sem produto marcado, não há brinde.
- Central de Promoções: o cupom automático "quem indicou" saiu da lista (cartão explicativo no lugar).
- O brinde entra como item a R$ 0,00 na venda, com o custo (vai para o custo total, relatórios e baixa de estoque). Não cria despesa extra (evita contar o custo duas vezes).

## Regras técnicas
- Tabela `contas_beneficios` (tipo Fidelidade/Indicação, status Disponível/Usado/Cancelado; usa UPDATE de status, nunca DELETE — o conector do Supabase cancela `delete from` em função).
- `api_criar_pedido_cardapio` aceita `beneficios:[{tipo,id,produtoId}]` (só com token de cliente logado). `_criar_pedido_publico` valida produto marcado como prêmio, cartão completo/benefício disponível, e consome na hora; cancelar a venda devolve (`_trg_conta_cancelada`).
- `api_conta_beneficios()` devolve carimbos, fidelidadeDisponivel, benefícios de indicação e as listas de produtos-prêmio.
- Cliente logado NÃO está em `usuarios`: qualquer FK para usuarios com auth.uid() precisa de guarda (ver `_ajustar_estoque`; sem isso o pedido de produto com receita falha).
- Pedido com brinde não passa pela contingência (fila): se o sistema principal estiver instável, o cliente é avisado para tentar de novo ou tirar o brinde.

## Passo a passo
1. Banco: rode `2-banco/2026-10-12-contas-brindes.sql` (já traz as duas alterações de função) e `2-banco/2026-10-12-ajuda-brindes.sql` (texto da ajuda da IA; é UPDATE, cole no SQL Editor se o conector cancelar). Teste: `teste-brindes-conta.sql` (18 verificações) e o `teste-contas-clientes.sql` atualizado (item 13 agora espera 1 e 2).
2. Front: copie `3-arquivos-novos/*` (versões COMPLETAS de app-27 e estilo-15) e aplique os `.diff` de `1-mudancas-nos-arquivos/` nos demais arquivos (index.html: tira o botão do banner e coloca a faixa `#cdContaBar` antes de `#cdAvisosPedido`).
3. Marque os produtos-prêmio. 4. `selar.py` → `verificar.py` (APROVADO) → suba o SHELL do `sw.js`.
