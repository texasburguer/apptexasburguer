-- Teste dos brindes da conta (fidelidade e indicação dentro do pedido) · 2026-10-12 · NÃO deixa nada no banco (termina com o erro de propósito "RELATORIO")
-- Como usar: Supabase → SQL Editor → cole tudo → Run. Leia o relatório que aparece no erro.
do $t$
declare
  u uuid := gen_random_uuid(); ind uuid := gen_random_uuid(); r text := ''; x jsonb; cod text; v1 uuid; v2 uuid; v3 uuid; v4 uuid;
  forma uuid; prod uuid; ing uuid; est0 numeric; est1 numeric; est2 numeric; ben uuid; cli uuid; taxa numeric; preco numeric; naoflag uuid;
begin
  select f.id, pp.produto_id, pp.preco, pi.ingrediente_id into forma, prod, preco, ing
    from formas_pagamento f join produto_precos pp on pp.forma_pagamento_id = f.id join produtos p on p.id = pp.produto_id and p.ativo
    join produto_ingredientes pi on pi.produto_id = p.id
   where f.ativa and f.visivel_cardapio and pp.preco > 0 order by f.ordem limit 1;
  if forma is null then raise exception 'RELATORIO sem forma/produto com receita para testar'; end if;
  select id into naoflag from produtos where ativo and id <> prod and not premio_fidelidade and not premio_indicacao limit 1;
  select coalesce(_num(valor #>> '{}'), 0) into taxa from sistema where chave = 'TaxaEntregaPadrao';
  insert into caixa_sessoes (status) select 'Aberto' where not exists (select 1 from caixa_sessoes where status = 'Aberto');
  update produtos set premio_fidelidade = true, premio_indicacao = true where id = prod;
  update cupons set ativa = false where automatico in ('boas_vindas','indicacao_indicado','indicacao_indicador');
  insert into auth.users (id, email, aud, role, raw_user_meta_data) values (u, 'teste-b1@example.com', 'authenticated', 'authenticated', '{"full_name":"Cliente Teste"}'), (ind, 'teste-b2@example.com', 'authenticated', 'authenticated', '{"full_name":"Indicador Teste"}');
  perform set_config('request.jwt.claims', json_build_object('sub', ind, 'role', 'authenticated')::text, true);
  set local role authenticated;
  perform api_conta_iniciar('{}'::jsonb); perform api_conta_aceitar('{"aceito":true}'::jsonb);
  reset role;
  select codigo_indicacao into cod from contas_cliente where user_id = ind;
  perform set_config('request.jwt.claims', json_build_object('sub', u, 'role', 'authenticated')::text, true);
  set local role authenticated;
  perform api_conta_iniciar(jsonb_build_object('indicacao', cod)); perform api_conta_aceitar('{"aceito":true}'::jsonb);
  x := api_criar_pedido_cardapio(jsonb_build_object('clienteNome','Cliente Teste','clienteTelefone','17999001122','tipoEntrega','Retirada','formaPagamentoId',forma,'requisicaoId','tb1','itens',jsonb_build_array(jsonb_build_object('produtoId',prod,'quantidade',1))));
  r := concat(r, '1 pedido normal (esperado true): ', (x->>'ok'), E'\n'); v1 := (x->>'id')::uuid;
  reset role;
  update vendas set status_pedido = 'Retirada' where id = v1;
  r := concat(r, '2 indicador ganhou 1 brinde de indicação (esperado 1): ', (select count(*) from contas_beneficios where user_id = ind and tipo = 'Indicação' and status = 'Disponível'), E'\n');
  select id into ben from contas_beneficios where user_id = ind and tipo = 'Indicação' limit 1;
  select quantidade into est0 from estoque where id = ing;
  -- indicador resgata sozinho (retirada)
  perform set_config('request.jwt.claims', json_build_object('sub', ind, 'role', 'authenticated')::text, true);
  set local role authenticated;
  x := api_conta_beneficios(); r := concat(r, '3 api_conta_beneficios: indicação ', jsonb_array_length(x->'indicacao'), ' / produtos de indicação ', jsonb_array_length(x->'produtosInd'), E'\n');
  x := api_criar_pedido_cardapio(jsonb_build_object('clienteNome','Indicador Teste','clienteTelefone','17999003344','tipoEntrega','Retirada','formaPagamentoId',forma,'requisicaoId','tb2','itens','[]'::jsonb,'beneficios',jsonb_build_array(jsonb_build_object('tipo','Indicação','id',ben,'produtoId',prod))));
  r := concat(r, '4 pedido só com o brinde de indicação (esperado true, total 0): ', (x->>'ok'), ' total ', coalesce(x->>'valorTotal', x->>'message'), E'\n'); v2 := (x->>'id')::uuid;
  reset role;
  select quantidade into est1 from estoque where id = ing;
  r := concat(r, '5 baixa no estoque (esperado > 0): ', round(est0 - est1, 3), E'\n');
  r := concat(r, '6 item a R$ 0 com custo, pago: ', (select count(*) || ' item(ns), valor ' || coalesce(sum(valor_total_item), 0) || ', custo venda ' || max(v.custo_total) || ', ' || max(v.status_pagamento::text) from itens_venda i join vendas v on v.id = i.venda_id where i.venda_id = v2), E'\n');
  perform set_config('request.jwt.claims', json_build_object('sub', ind, 'role', 'authenticated')::text, true);
  set local role authenticated;
  x := api_criar_pedido_cardapio(jsonb_build_object('clienteNome','Indicador Teste','clienteTelefone','17999003344','tipoEntrega','Retirada','formaPagamentoId',forma,'requisicaoId','tb3','itens','[]'::jsonb,'beneficios',jsonb_build_array(jsonb_build_object('tipo','Indicação','id',ben,'produtoId',prod))));
  r := concat(r, '7 usar o mesmo brinde de novo (esperado false): ', (x->>'ok'), E'\n');
  reset role;
  update vendas set status = 'Cancelada' where id = v2;
  r := concat(r, '8 cancelar devolve o brinde (esperado 1 disponível): ', (select count(*) from contas_beneficios where id = ben and status = 'Disponível'), E'\n');
  perform set_config('request.jwt.claims', json_build_object('sub', ind, 'role', 'authenticated')::text, true);
  set local role authenticated;
  x := api_criar_pedido_cardapio(jsonb_build_object('clienteNome','Indicador Teste','clienteTelefone','17999003344','tipoEntrega','Retirada','formaPagamentoId',forma,'requisicaoId','tb4','itens','[]'::jsonb,'beneficios',jsonb_build_array(jsonb_build_object('tipo','Indicação','id',ben,'produtoId',naoflag))));
  r := concat(r, '9 produto que não é prêmio de indicação (esperado false): ', (x->>'ok'), E'\n');
  x := api_criar_pedido_cardapio(jsonb_build_object('clienteNome','Indicador Teste','clienteTelefone','17999003344','tipoEntrega','Entrega','formaPagamentoId',forma,'requisicaoId','tb5','dadosEntrega',jsonb_build_object('endereco','Rua Teste','numero','1','cidade','Jaboticabal'),'itens','[]'::jsonb,'beneficios',jsonb_build_array(jsonb_build_object('tipo','Indicação','id',ben,'produtoId',prod))));
  r := concat(r, '10 brinde sozinho com entrega (esperado true, total = taxa ', taxa, '): ', (x->>'ok'), ' total ', coalesce(x->>'valorTotal', '-'), E'\n'); v3 := (x->>'id')::uuid;
  reset role;
  update vendas set status = 'Cancelada' where id = v3;
  -- fidelidade do cliente u (conta já ligada ao histórico)
  select cliente_id into cli from contas_cliente where user_id = u;
  r := concat(r, '11 conta ligada ao cartão fidelidade (esperado true): ', (cli is not null), E'\n');
  perform set_config('request.jwt.claims', json_build_object('sub', u, 'role', 'authenticated')::text, true);
  set local role authenticated;
  x := api_criar_pedido_cardapio(jsonb_build_object('clienteNome','Cliente Teste','clienteTelefone','17999001122','tipoEntrega','Retirada','formaPagamentoId',forma,'requisicaoId','tb6','itens','[]'::jsonb,'beneficios',jsonb_build_array(jsonb_build_object('tipo','Fidelidade','produtoId',prod))));
  r := concat(r, '12 resgatar fidelidade com cartão incompleto (esperado false): ', (x->>'ok'), E'\n');
  reset role;
  insert into fidelidade (cliente_id, carimbos) values (cli, 10) on conflict (cliente_id) do update set carimbos = 10;
  perform set_config('request.jwt.claims', json_build_object('sub', u, 'role', 'authenticated')::text, true);
  set local role authenticated;
  x := api_criar_pedido_cardapio(jsonb_build_object('clienteNome','Cliente Teste','clienteTelefone','17999001122','tipoEntrega','Entrega','formaPagamentoId',forma,'requisicaoId','tb7','dadosEntrega',jsonb_build_object('endereco','Rua Teste','numero','1','cidade','Jaboticabal'),'itens',jsonb_build_array(jsonb_build_object('produtoId',prod,'quantidade',1)),'beneficios',jsonb_build_array(jsonb_build_object('tipo','Fidelidade','produtoId',prod))));
  r := concat(r, '13 pedido com item pago + brinde fidelidade (esperado true): ', (x->>'ok'), ' total ', coalesce(x->>'valorTotal', x->>'message'), ' (preço ', preco, ' + taxa ', taxa, ')', E'\n'); v4 := (x->>'id')::uuid;
  reset role;
  r := concat(r, '14 cartão zerou e prêmio contado (esperado 0 e +1): ', (select carimbos || ' / ' || premios_resgatados from fidelidade where cliente_id = cli), E'\n');
  r := concat(r, '15 itens do pedido: ', (select string_agg(descricao || ' R$' || valor_total_item, ' | ') from itens_venda where venda_id = v4), E'\n');
  update vendas set status = 'Cancelada' where id = v4;
  r := concat(r, '16 cancelar reabre o cartão (esperado 10): ', (select carimbos from fidelidade where cliente_id = cli), E'\n');
  perform set_config('request.jwt.claims', '', true);
  set local role anon;
  x := api_criar_pedido_cardapio(jsonb_build_object('clienteNome','Visitante','clienteTelefone','17999005566','tipoEntrega','Retirada','formaPagamentoId',forma,'requisicaoId','tb8','itens','[]'::jsonb,'beneficios',jsonb_build_array(jsonb_build_object('tipo','Fidelidade','produtoId',prod))));
  r := concat(r, '17 visitante tentando brinde (esperado false): ', (x->>'ok'), ' — ', coalesce(x->>'message', ''), E'\n');
  begin x := api_conta_beneficios(); r := concat(r, '18 visitante em api_conta_beneficios: ', x::text, E'\n'); exception when others then r := concat(r, '18 visitante barrado (esperado): ', sqlerrm, E'\n'); end;
  reset role;
  raise exception E'RELATORIO\n%', r;
end $t$;
