-- Ajuda da IA: brindes (prêmio de fidelidade e de indicação) na conta do cliente (12/10/2026). Pode rodar mais de uma vez.
update public.ai_ajuda
   set passos = replace(replace(passos,
         'Os 4 cupons automáticos (boas-vindas, aniversário, indique e ganhe para quem indicou e para quem foi indicado) começam desligados',
         'Os cupons automáticos (boas-vindas, aniversário e indique e ganhe para quem foi indicado) começam desligados'),
         'o prêmio de indicação ainda não usado também é desfeito.',
         'o brinde (prêmio) usado nele volta para o cliente.')
       || E'\nBrindes: marque os produtos-prêmio em Editar produto › Mais opções (Prêmio de fidelidade / Prêmio de indicação). Com o cartão fidelidade completo, o cliente escolhe o prêmio em "Minha conta" ou no carrinho. Quem indica ganha 1 brinde (a escolher entre os produtos marcados como prêmio de indicação) quando o amigo conclui o 1º pedido; se esse pedido for cancelado, o brinde some.\nO brinde pode ir junto com outros itens ou sozinho: sai a R$ 0,00 (entra nos relatórios, com o custo, e baixa o estoque) e a entrega, se for entrega, é cobrada. Não há pedido mínimo. Pedido cancelado devolve o brinde. O botão Entrar/Minha conta fica numa faixa abaixo do banner do cardápio.',
       atualizado_em = now()
 where slug = 'man-admin-111-conta-cliente' and passos not like '%Brindes: marque os produtos-prêmio%';
