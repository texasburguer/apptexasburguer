# Receita: conta de cliente com login Google (opcional) + LGPD + Minha conta + cupons de conta

## O que muda para o cliente
- Botão "👤 Entrar" no cardápio. Entrar com Google é OPCIONAL: sem conta o pedido funciona como sempre (e o modo reserva continua sem login).
- Na primeira entrada: aceite do Aviso de Privacidade/Termos (obrigatório) e aceite SEPARADO para receber promoções.
- "Minha conta": pedidos (repetir com 1 toque), cartão fidelidade, cupons, promoções, endereços salvos, indique e ganhe, privacidade (exportar dados, apagar conta).
- No carrinho, dados, endereço e cupons da conta já vêm preenchidos.

## O que muda para o Admin (Promoções e Cupons)
- Botão Editar em todo cupom; cupom "só para quem tem conta", "só para um cliente", "mostrar em Minha conta" e texto para o cliente.
- 4 cupons automáticos (boas-vindas, aniversário, indique e ganhe: indicador e indicado). Nascem DESLIGADOS.
- Cartão Privacidade (LGPD): razão social/CNPJ (em branco = não aparece no aviso), prazo de anonimização (3 anos) e "publicar nova versão do Aviso".

## Regras importantes
- Banco: RLS ligada e SEM políticas nas tabelas novas; tudo por funções `api_conta_*` (security definer). Equipe (`auth_nivel()` não nulo) é barrada nessas funções.
- A conta só se junta ao histórico (por telefone) depois do 1º pedido entregue/retirado feito logado.
- Cancelar pedido: devolve o cupom de conta, não conta como uso e anula o prêmio de indicação ainda não usado.
- "1 por cliente" é real (conta o uso por conta e por telefone, ignorando vendas canceladas).
- Pedido e validação de cupom do cardápio vão com o token do cliente (`txbContaSb_v1`, separado da sessão da equipe `texasBurgerSb_v1`).
- LIMITAÇÃO: o telefone não é verificado.
- O conector do Supabase cancela SQL com `delete from` dentro de função: esse trecho está em `2-banco/2026-10-12-contas-clientes-MANUAL.sql` (cole no SQL Editor).

## Passo a passo
1. Google Cloud (credencial OAuth) e Supabase → Auth → Providers → Google (Client ID/Secret). Manter "Allow new users to sign up" ligado. Em Auth → URL Configuration, inclua a URL do site em Redirect URLs.
2. Rode `2-banco/2026-10-12-contas-clientes.sql`, depois `2-banco/2026-10-12-contas-clientes-MANUAL.sql`. Rode também `2-banco/2026-10-12-ajuda-contas-clientes.sql` (texto da ajuda da IA, ordem 112; troque o número se já houver outro igual). Teste com `2-banco/teste-contas-clientes.sql` (22 verificações, não grava nada; termina em erro "RELATORIO" de propósito).
3. Copie `3-arquivos-novos/*` para a pasta do front e aplique os `.diff` de `1-mudancas-nos-arquivos/` (o `?v=` do index.html é refeito pelo `selar.py`). No `index.html` entram `<link href="estilo-15-conta.css">` e, logo depois, `<script src="app-27-conta-cliente.js">` (ambos depois do app-26).
4. Troque nomes de restaurante/URLs: o projeto Supabase e o domínio (redirect do Google) estão no app-27; o WhatsApp de contato do aviso vem dos dados do restaurante.
5. Rode `selar.py` → `verificar.py` (APROVADO), suba o SHELL do `sw.js` e envie tudo junto.
6. No Google Branding, use como links de privacidade/termos: `https://SEU-SITE/?privacidade=1`.
7. Ative os cupons automáticos na Central de Promoções só depois de ajustar o benefício.

## Como testar
1. Entre com Google no cardápio, aceite, veja o cupom de boas-vindas (se ligado).
2. Faça um pedido logado, cancele no sistema: o cupom volta. Faça outro e marque Entregue: "Minha conta" mostra o histórico.
3. Com o link "indique e ganhe" de uma conta, crie outra, conclua um pedido: os dois recebem o cupom (se ligados).
4. Em "Privacidade", exporte os dados.

## Anexos
- `RECEITA-COMPLETA-conta-cliente.txt` tem TODO o código (SQL, arquivos novos e diffs) em um arquivo só.
- A correção do "flash" do cardápio ao abrir logado está em `../2026-10-12-flash-cardapio/`.
