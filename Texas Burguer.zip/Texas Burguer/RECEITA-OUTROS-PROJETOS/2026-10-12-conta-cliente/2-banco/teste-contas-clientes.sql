-- Teste das contas de clientes · 2026-10-12 · NÃO deixa nada no banco (termina com erro de propósito "RELATORIO", que desfaz tudo)
-- Como usar: Supabase → SQL Editor → cole tudo → Run. Leia o relatório que aparece no erro.
-- Cobre: conta + aceite + boas-vindas, regras do cupom (só conta, 1 por cliente), pedido com conta, cancelamento devolve o cupom,
--        ligação da conta ao histórico só após o 1º pedido concluído, indique e ganhe (e perda do prêmio se o pedido é cancelado),
--        bloqueio de visitante e de cliente nas funções da equipe, exportar dados, anonimização.
do $t$
declare
  u uuid := gen_random_uuid(); ind uuid := gen_random_uuid(); r text := ''; x jsonb; cod text; v1 uuid; v2 uuid;
  forma uuid; prod uuid;
begin
  select f.id, pp.produto_id into forma, prod
    from formas_pagamento f join produto_precos pp on pp.forma_pagamento_id = f.id join produtos p on p.id = pp.produto_id and p.ativo
   where f.ativa and f.visivel_cardapio order by f.ordem limit 1;
  if forma is null then raise exception 'RELATORIO sem forma/produto para testar'; end if;
  insert into caixa_sessoes (status) select 'Aberto' where not exists (select 1 from caixa_sessoes where status = 'Aberto');
  insert into auth.users (id, email, aud, role, raw_user_meta_data) values (u, 'teste-conta@example.com', 'authenticated', 'authenticated', '{"full_name":"Cliente Teste"}'), (ind, 'indicador@example.com', 'authenticated', 'authenticated', '{}');
  update cupons set ativa = true where automatico in ('boas_vindas', 'indicacao_indicador', 'indicacao_indicado');

  -- indicador cria a conta
  perform set_config('request.jwt.claims', json_build_object('sub', ind, 'role', 'authenticated')::text, true);
  set local role authenticated;
  perform api_conta_iniciar('{}'::jsonb); perform api_conta_aceitar('{"aceito":true,"promo":true}'::jsonb);
  reset role;
  select codigo_indicacao into cod from contas_cliente where user_id = ind;

  -- cliente novo, indicado
  perform set_config('request.jwt.claims', json_build_object('sub', u, 'role', 'authenticated')::text, true);
  set local role authenticated;
  x := api_conta_iniciar(jsonb_build_object('indicacao', cod)); r := r || '1 iniciar precisaAceite=' || (x->>'precisaAceite') || E'\n';
  x := api_conta_pedidos(); r := r || '2 sem aceite não lê pedidos (esperado false): ' || (x->>'ok') || E'\n';
  x := api_conta_aceitar('{"aceito":false}'::jsonb); r := r || '3 sem marcar o aceite (esperado false): ' || (x->>'ok') || E'\n';
  x := api_conta_aceitar('{"aceito":true}'::jsonb); r := r || '4 aceite: ' || (x->>'ok') || E'\n';
  x := api_conta_cupons(); r := r || '5 cupom de boas-vindas recebido (esperado 1): ' || jsonb_array_length(x->'recebidos') || E'\n';
  x := api_validar_cupom_cardapio('{"codigo":"BOASVINDAS","telefone":"17999887766","subtotal":50,"tipoEntrega":"Retirada"}'::jsonb); r := r || '6 valida boas-vindas (esperado true): ' || (x->>'ok') || E'\n';
  x := api_criar_pedido_cardapio(jsonb_build_object('clienteNome', 'Cliente Teste', 'clienteTelefone', '17999887766', 'tipoEntrega', 'Retirada', 'formaPagamentoId', forma, 'codigoCupom', 'BOASVINDAS', 'requisicaoId', 'tc1', 'itens', jsonb_build_array(jsonb_build_object('produtoId', prod, 'quantidade', 1))));
  r := r || '7 pedido com cupom (esperado true): ' || (x->>'ok') || ' desconto ' || coalesce(x->>'valorDesconto', '-') || E'\n'; v1 := (x->>'id')::uuid;
  x := api_validar_cupom_cardapio('{"codigo":"BOASVINDAS","telefone":"17999887766","subtotal":50,"tipoEntrega":"Retirada"}'::jsonb); r := r || '8 reuso do boas-vindas (esperado false): ' || (x->>'ok') || E'\n';
  reset role;
  r := r || '9 conta ainda NÃO ligada ao histórico antes de concluir o pedido (esperado false): ' || (select (cliente_id is not null)::text from contas_cliente where user_id = u) || E'\n';
  update vendas set status = 'Cancelada' where id = v1;
  r := r || '10 cancelar devolve o cupom (esperado 1 livre): ' || (select count(*) from cupons_concedidos where user_id = u and usado_em is null and origem = 'boas_vindas') || E'\n';

  perform set_config('request.jwt.claims', json_build_object('sub', u, 'role', 'authenticated')::text, true);
  set local role authenticated;
  x := api_criar_pedido_cardapio(jsonb_build_object('clienteNome', 'Cliente Teste', 'clienteTelefone', '17999887766', 'tipoEntrega', 'Retirada', 'formaPagamentoId', forma, 'codigoCupom', 'BOASVINDAS', 'requisicaoId', 'tc2', 'itens', jsonb_build_array(jsonb_build_object('produtoId', prod, 'quantidade', 1))));
  r := r || '11 novo pedido com o cupom devolvido (esperado true): ' || (x->>'ok') || E'\n'; v2 := (x->>'id')::uuid;
  reset role;
  update vendas set status_pedido = 'Retirada' where id = v2;
  r := r || '12 conta ligada ao histórico após o pedido concluído (esperado true): ' || (select (cliente_id is not null)::text from contas_cliente where user_id = u) || E'\n';
  r := r || '13 indique e ganhe: cupons do indicador / do indicado (esperado 2 e 2 com o boas-vindas): ' || (select count(*) from cupons_concedidos where user_id = ind) || ' / ' || (select count(*) from cupons_concedidos where user_id = u) || E'\n';
  perform set_config('request.jwt.claims', json_build_object('sub', u, 'role', 'authenticated')::text, true);
  set local role authenticated;
  x := api_conta_pedidos(); r := r || '14 histórico: ' || jsonb_array_length(x->'pedidos') || ' pedidos' || E'\n';
  x := api_conta_exportar(); r := r || '15 exportar ok: ' || (x->>'ok') || E'\n';
  x := api_lgpd_config('{}'::jsonb); r := r || '16 cliente chamando função do Admin (esperado false): ' || (x->>'ok') || E'\n';
  x := api_editar_cupom('{}'::jsonb); r := r || '17 cliente editando cupom (esperado false): ' || (x->>'ok') || E'\n';
  reset role;
  update vendas set status = 'Cancelada' where id = v2;
  r := r || '18 cancelar o único pedido concluído tira o prêmio de indicação não usado (esperado 0 / 0 livres): ' ||
     (select count(*) from cupons_concedidos where user_id = ind and usado_em is null and origem = 'indicacao_indicador') || ' / ' || (select count(*) from cupons_concedidos where user_id = u and usado_em is null and origem = 'indicacao_indicado') || E'\n';

  -- visitante (sem login)
  perform set_config('request.jwt.claims', '', true);
  set local role anon;
  begin x := api_conta_iniciar('{}'::jsonb); r := r || '19 visitante em api_conta_iniciar: ' || x::text || E'\n'; exception when others then r := r || '19 visitante barrado (esperado): ' || sqlerrm || E'\n'; end;
  x := api_aviso_privacidade(); r := r || '20 Aviso de Privacidade público (esperado true): ' || (x->>'ok') || E'\n';
  x := api_validar_cupom_cardapio('{"codigo":"BOASVINDAS","telefone":"17999887766","subtotal":50,"tipoEntrega":"Retirada"}'::jsonb); r := r || '21 visitante usando cupom de conta (esperado false): ' || (x->>'ok') || E'\n';
  reset role;

  -- anonimização
  perform _anonimizar_cliente((select cliente_id from contas_cliente where user_id = u));
  r := r || '22 anonimização: ' || (select nome from clientes where id = (select cliente_id from contas_cliente where user_id = u)) || ' | pedido: ' || (select cliente_nome || '|' || coalesce(nullif(telefone_cliente, ''), 'sem telefone') from vendas where id = v2) || E'\n';
  raise exception E'RELATORIO\n%', r;
end $t$;
