# Texas Burger — Plano unificado (correções + caixa vencido + menu do Administrador)

Data: 16/10/2026 · Projeto Supabase: `texas-burger` (`awryywtgqfaxppayzpca`)

Este documento junta, sem cortar nada, o **plano consolidado de correções (15/10)** e o **plano do menu do Administrador + caixa vencido (16/10)**. Onde os dois diziam coisas diferentes, vale o mais novo (marcado como **[Revisado]**).

Origem de cada item: **[P]** plano original · **[C]** achado na leitura do código · **[B]** achado na auditoria do banco real · **[Você]** decisão sua.

Legenda de andamento: ✅ feito e entregue em zip · ⏳ pendente.

---

## 0. Situação atual (resumo)

- iFood, Mercado Pago e NFC-e estão **desligados** e sem credenciais cadastradas: nada disso afeta dado real ainda. Dá para corrigir tudo antes de ligar.
- 24 agendamentos ativos, sem falha em 24 h. Fila de sincronização zerada. Integridade diária "ok" nos últimos 3 dias. Backup com 18 h (limite de alerta: 26 h).
- RLS ligada em todas as tabelas; funções internas só para `service_role`; funções públicas (cardápio, mesa, chat, cupom) com limite de tentativas.
- Dados financeiros das 29 vendas consistentes (total × itens × pagamentos).
- O código no banco é o mesmo dos arquivos do zip.
- Não foi rodado nada em Postgres de teste; a auditoria do banco foi só leitura.
- O sistema ainda não está em uso pela equipe (por isso não há necessidade de manter nomes antigos de telas).

**Andamento (atualizado em 16/10, fim do dia):** aplicados no banco real e/ou na nuvem: Fase 1 (itens 1 a 5), Fase 2 (9 itens, `ifood-sync` v4), Fase 3 (função `mp-cancelar` + cron `mp-cancelar-pix`), Fase 4 (item 0 e itens 1 a 5 e 7), mais a correção do botão "Sincronizar agora" (`sync-fila` v8: Desenvolvedor vale como Admin). Menu do Administrador (Fase 6): 6.1, 6.2, 6.3, 6.5, 6.6, 6.7 e 6.8 feitos; **6.4 (Início do Administrador) foi REMOVIDO por decisão sua** (ficou só o menu). Tela do Caixa reorganizada: "Fechar caixa vencido" só no botão de baixo. Pendente: Fase 0 (suas ações), Fase 1 item 6 (homologação), Fase 4 item 6 (opcional, não aplicado), testes reais de iFood, Mercado Pago e NFC-e quando ligar.

---

## Fase 0 — Ações suas, agora (cliques, sem código) ⏳

| # | Ação | Origem |
|---|------|--------|
| 0.1 | **Fechar o caixa aberto desde 12/10 (22:50)** e abrir um novo. Há ~4 dias numa sessão só, o que distorce fechamento e saldo. O sistema **não fecha o caixa sozinho** (regra na Fase 4, item 0). | B |
| 0.2 | Ligar **proteção contra senhas vazadas** (Auth → Providers). | B |
| 0.3 | Apagar as Edge Functions **`leitor-fiscal`** e **`ai-dev-analise`** no painel (a segunda ainda está com `verify_jwt` ligado). | P/B |
| 0.4 | Apagar do Vault o segredo sobrando **`pendente_groq_2`** (a chave `groq_2` já está em `ai_segredos`). | B |
| 0.5 | Testar a **planilha de contingência**: `contingencia_ultimo_ok` está vazio, mesmo com o job de 10 min rodando. | B |
| 0.6 | Conferir a URL/implantação do **Apps Script** principal: houve erro em 11/10 (resposta HTML em vez de JSON). Hoje sincroniza normal. | B |
| 0.7 | Preencher o **estoque**: dos 43 itens, 39 estão com quantidade 0 e 6 sem custo. Sem isso, custo/margem e o alerta de mínimo (40 itens alertando) não valem. | B |

---

## Fase 1 — Dinheiro e fiscal (maior risco) ✅ (itens 1 a 5 aplicados no banco em 16/10; item 6 é da homologação)

1. **[P] CPF do iFood na nota.** Em `ifood_criar_pedido`, gravar `customer.documentNumber` em `vendas.cpf_nota` **só se** `_cpf_valido`; se inválido, ignorar. Gravar já no `INSERT` da venda.
2. **[C] LGPD do CPF.** Incluir `cpf_nota` na limpeza de retenção do iFood (`ifood_limpar`), junto com nome, telefone e endereço. A nota autorizada já guarda o CPF no XML.
3. **[P] Nota com item sem ligação.** Em `nfce_montar`: bloquear a nota (pendência) se o item tiver `[SEM LIGAÇÃO]`, em vez de usar o perfil padrão; remover da descrição fiscal a observação do cliente e o texto interno.
4. **[P] Pagamento "99" na nota.** Em `_nfce_forma_codigo`, mapear o iFood pago no app para o código correto e enviar a descrição do pagamento quando for 99 (campos a conferir na documentação da Focus).
5. **[P] Reembolso feito no painel do Mercado Pago.** Em `mp_aplicar_status`, quando chegar "reembolsado" de venda ainda paga: inserir em `reembolsos` com status `Devolvido` (o dinheiro já saiu), valor realmente reembolsado e observação, e avisar a equipe por push (`_push_enviar`) para decidir se cancela a venda. `reembolsos.venda_id` é único e o gatilho de cancelamento usa `on conflict do nothing`, então é seguro.
6. **[C] Para a homologação:** confirmar com a Focus/contador se venda pelo iFood com entrega exige informar o intermediário (CNPJ do iFood). O payload atual não envia. *Não verificado.*

**Achados da leitura das funções no banco real (16/10):**
- `ifood_criar_pedido` não grava `cpf_nota` e `ifood_limpar` não limpa esse campo (itens 1 e 2 confirmados).
- `nfce_montar` só barra item sem perfil fiscal, mas `_perfil_fiscal_efetivo` cai no perfil padrão; item sem ligação do iFood passa, e a descrição fiscal ainda leva `(obs: ...)` do cliente e `[SEM LIGAÇÃO]` (item 3 confirmado).
- `_nfce_forma_codigo` já cai em `99` para o iFood pago no app, sem descrição (item 4 confirmado). O nome do campo da descrição na Focus precisa ser conferido na homologação.
- `reembolsos`: colunas `venda_id` (único), `valor`, `forma_pagamento`, `motivo`, `status` (`Pendente` ou `Devolvido`), `devolvido_em`, `observacao`. O item 5 é viável com `on conflict do nothing`.

**Feito (16/10):** `ajustes/2026-10-16-fase1-dinheiro-e-fiscal.sql`, teste `testes/teste-fase1.sql` (13 verificações, todas OK, com rollback), aplicado no banco real. O campo da Focus para a descrição do pagamento 99 é `descricao_pagamento` (2 a 60 letras; só com forma 99). Item 5: só o reembolso **total** vira registro em `reembolsos`; o **parcial** só avisa por push.

---

## Fase 2 — Pedidos do iFood ✅ (itens 1 a 9 aplicados em 16/10: `ajustes/2026-10-16-fase2-ifood.sql` + `ifood-sync` v4; teste do banco em `testes/teste-fase2.sql`, 14 verificações OK com rollback; os itens 6 e 7 também dependem da função de nuvem, que não foi testada; nada foi testado com o iFood de verdade)

1. **[P] Pedido sem itens:** `ifood_criar_pedido` recusa; o `ifood-sync` marca o evento com erro em vez de confirmar.
2. **[P] INDOOR:** mapear para Retirada (ou mesa, se existir tipo equivalente).
3. **[P] Troco:** escrever "levar troco" só quando `deliveredBy` for a loja.
4. **[P] Cancelamento depois do concluído:** em `ifood_aplicar_evento`, ignorar CAN se o pedido já estiver concluído e registrar aviso.
5. **[P] Centavos:** em `_ifood_gravar_itens`, ajustar o valor unitário para quantidade × unitário bater com o total do item.
6. **[P] Trava do iFood:** renovar a trava a cada volta do ciclo no `ifood-sync` (preferível a fixar 170 s; `ifood_trava_pegar` já aceita renovar com o mesmo dono).
7. **[C] Evento perdido.** Se o CAN/CON/CFM chega antes de a venda existir (PLC repetindo por 404), `ifood_aplicar_evento` devolve `desconhecido` e o `ifood-sync` marca como concluído: o evento some e um cancelamento perdido deixa a venda ativa. Correção: tratar `desconhecido` como "tentar de novo" por até 10 min.
8. **[C] Data de agendamento inválida.** O `v_agend::timestamptz` não é validado: formato estranho derruba o pedido inteiro e o evento repete 30 vezes. Correção: envolver a conversão em bloco com tratamento de erro e omitir só a data.
9. **[C] Eventos presos.** `ifood_eventos_pendentes` só olha 1 dia e 50 eventos; o que passar disso fica sem processar, sem alerta. Correção: marcar como erro e registrar no log.

---

## Fase 3 — Mercado Pago ✅ (aplicado em 16/10: `ajustes/2026-10-16-fase3-mp-cancelar-pix.sql`, função `mp-cancelar`, cron `mp-cancelar-pix`, `testes/teste-fase3.sql` com cenários reais e rollback, 9 verificações OK, só o lado do banco; a função `mp-cancelar` nunca falou com o Mercado Pago de verdade)

1. **[P] Pix depois da reserva:** nova função de nuvem, chamada pelo cron, que cancela o pedido no Mercado Pago quando a reserva vence (não muda a regra da reserva; o Pix tem mínimo de 30 min).
2. **[C] Corrida no cancelamento.** Se o cliente pagar no mesmo instante, o cancelamento pode falhar. Nesse caso, deixar cair em "Pagamento a decidir" em vez de ignorar.

---

## Fase 4 — Banco (caixa vencido, fuso, limpeza, endurecimento) ✅ (item 0 e itens 1 a 7 aplicados em 16/10). SQL: itens 1 a 5 em `ajustes/2026-10-16-fase4-banco-itens-1-a-5.sql` (teste em `testes/teste-fase4.sql`); item 6 em `ajustes/2026-10-16-fase4-item6-indices-chaves-estrangeiras.sql` (16 índices; consolidar políticas RLS duplicadas ficou de fora de propósito, porque mexe em segurança e o ganho é mínimo)

### Item 0 — Caixa vencido **[Revisado — substitui o item 0 do plano de 15/10]**

O caixa nunca é fechado automaticamente (a contagem do dinheiro é humana). Hoje o código já exige caixa aberto (`api_iniciar_venda`, fechar conta da mesa, sangria, resgate de prêmio), mas **aceita sessão de qualquer idade**. A mudança é acrescentar o vencimento.

1. **Pedido externo nunca trava.** iFood e cardápio entram como "Recebido" e o botão de aceitar funciona mesmo com caixa vencido. Aparece aviso forte na tela e push para a equipe. O iFood cancela sozinho em ~8 min, então bloquear o aceite perderia o pedido.
2. **O que trava:** só venda nova de balcão e de mesa (`api_iniciar_venda`, fechar conta da mesa). Sangria e resgate de prêmio seguem a regra de hoje (exigem caixa aberto) mais o vencimento. Preparar, despachar, entregar e receber pedidos já aceitos continuam livres.
3. **Vencimento pelo dia operacional.** A sessão vence no primeiro corte (padrão 06:00, horário de Brasília, configurável) depois do início. Teto absoluto de 24 h.
   - O corte só vale se a sessão já tem pelo menos 6 h de vida. Sem isso, um caixa aberto às 05:30 venceria às 06:00.
   - Caixa aberto às 18h e esquecido vence às 06:00 do dia seguinte, antes de abrir o serviço. O turno que passa da meia-noite segue livre.
   - Cálculo sempre em `America/Sao_Paulo` (o banco roda em UTC).
4. **Saída de emergência.** "Liberar por X horas" (padrão 4 h, máximo 12 h), só Admin, com motivo obrigatório. Grava em auditoria, expira sozinho e manda push aos Admins. Enquanto estiver ativa, aparece um cartão na Visão Geral com quem liberou, o motivo e até quando.
5. **Fechamento rápido.** Botão "Fechar caixa vencido" pede só o valor contado. A diferença vira divergência registrada com a marca "fechamento atrasado" e o motivo. A contagem completa pode ser feita depois. A marca aparece no Histórico de sessões de caixa. Quem fecha: Admin e Operador. Garçom e Cozinha veem "caixa vencido, chame o responsável".
6. **Aviso antecipado.** Banner a partir de 2 h antes do corte, no topo do Início e do Caixa (o Início do Admin foi removido).
7. **Testes:**
   - caixa aberto 18h, agora 07h → bloqueia venda nova;
   - mesmo caixa, 02h → passa;
   - caixa com 25 h → bloqueia mesmo sem cruzar corte;
   - pedido do iFood entra e é aceito com caixa vencido;
   - liberação por 4 h → vende; depois expira;
   - fechamento rápido registra divergência;
   - Garçom não vê o botão de fechar; a liberação ativa aparece na Visão Geral; o fechamento rápido aparece marcado no Histórico de sessões de caixa.

### Itens 1 a 7

1. **[B/C] Fuso horário.** O banco roda em UTC. Usar `America/Sao_Paulo` em:
   - `api_mp_resumo_operacional` (mês fecha 3 h antes: vendas das 21h às 24h do último dia caem no mês seguinte);
   - cota diária de IA do cliente (`current_date`, zera às 21h);
   - `_imposto_pct(current_date)`;
   - `recebido30d` do iFood (`criado_em::date`).
2. **[B] Revogar `TRUNCATE`** do papel `authenticated` nas tabelas (não é alcançável pela API, mas não deve existir).
3. **[B] `_nfce_traduzir`:** fixar `search_path`.
4. **[B] Índice duplicado** em `ai_ajuda` (`ai_ajuda_slug_key` × `ai_ajuda_slug_uq`): manter um.
5. **[B] Timeout do `chamar_edge`:** ~5 chamadas/hora estouram os 5 s padrão do `pg_net` (a função continua rodando, só a resposta se perde). Subir o prazo na chamada.
6. **[B] Opcional/baixa prioridade:** índices nas 16 chaves estrangeiras sem índice e consolidar políticas RLS duplicadas. Não pesa com 29 vendas.
7. **[B] Conferir** que as 14 views do cardápio (Security Definer, intencional) não ganhem coluna sensível no futuro.

---

## Fase 5 — Validação (parcial: testes de banco feitos; faltam navegador, simulação das funções de nuvem e integrações reais)

- **SQL:** teste que desfaz tudo no fim (rollback), com antes e depois, na linha dos testes já feitos (ex.: `testes/teste-reembolso.sql`). Rodar o mínimo no banco real (os testes gastam números de pedido).
- **Funções de nuvem:** ampliar a simulação local existente (hoje 106 checks) com os casos novos: evento antes da venda, pedido sem itens, data inválida, Pix após reserva, reembolso no painel.
- **Caixa vencido:** os 7 testes do item 0 da Fase 4.
- **Menu:** script que confirma os mesmos ids de tela antes e depois, cada id em um único grupo; todos os `abrirAdministrador(...)` resolvem; Operador só vê Atendimento; permissões da `MATRIZ-PERMISSOES-2026-10-15.md` iguais; abrir as telas no celular e no PC sem erro de console.
- **Pacote:** um zip só, com SQL, funções e `Código do Supabase.html` atualizados. Se algum `.js` mudar, refazer os selos `?v=` no `index.html` e no `sw.js` (`selar.py`), rodar `verificar.py` (APROVADO) e subir o `SHELL` do `sw.js`.

---

## Fase 6 — Menu do Administrador

> Atualização: o caixa vencido completo (Fase 4, item 0), o Início do Admin (6.4) e a ajuda do Tex (6.8) já foram feitos nas etapas 8 a 10 (16/10). Os itens 1 a 7 da Fase 4 foram feitos depois, e o 6.4 foi removido por decisão do Lucas.

### Problemas que existiam

São 6 grupos e 25 telas (24 do menu + "Pergunte à IA", acrescentada ao primeiro grupo pelo `app-19`):
- "Contas e despesas" e "Contas e acessos" pareciam a mesma coisa; a segunda guarda IAs, iFood, Nota fiscal, Mercado Pago e as contas do sistema.
- Formas de pagamento em dois lugares (Operação → Pagamentos e Cardápio Digital → Pagamentos).
- Categorias, Produtos, Combos e Adicionais em dois lugares (Catálogo e Cardápio Digital).
- Grupos misturados (Relatórios no Painel; Pagamentos e notificações em Operação; Usuários em Sistema).
- Saúde e backup espalhados; tela inicial vazia; sem atalho para achar telas.

### Menu novo (nenhuma tela some; os ids das telas não mudam)

| Grupo | Telas |
|---|---|
| **Hoje** | Visão Geral · Ocorrências · Feedbacks · Pergunte à IA |
| **Dinheiro** | Contas a pagar e despesas · Histórico · Reembolsos e ajustes · Previsto e metas · Relatórios e DRE |
| **Produtos** | Produtos, combos e adicionais · Estoque · Compras e fornecedores · Custos e precificação |
| **Vendas e cardápio** | Cardápio Digital · Formas de pagamento · Promoções e cupons · Eventos |
| **Loja e equipe** | Mesas e QR Codes · Entregadores e taxas · Usuários e permissões · Configurar avisos |
| **Sistema** | Integrações e contas · Backup e espaço · Sincronização e contingência · Auditoria |

Operador continua vendo só **Atendimento** (Ocorrências, Feedbacks e Pergunte à IA).

### Etapas

- ✅ **6.1 Renomear e reagrupar.** `ADMIN_GRUPOS` e `ADMIN_SUBABAS_ROTULOS` em `app-02-abas.js`; caminhos citados na ajuda, nos avisos e nas mensagens atualizados; versão 1.2 e "Novidades". *Diferença:* a tela `contas` chama "Integrações e contas" (e não só "Integrações"), porque a aba "Contas" guarda e-mails, links e senhas das contas do sistema.
- ✅ **6.5 Campo "Ir para…".** Filtra por nome, grupo e palavras parecidas; aparece no celular e no PC; não aparece para o Operador.
- ✅ **6.6 Uma linha de explicação por tela** embaixo de cada nome no menu (celular e PC).
- ✅ **6.2 Formas de pagamento numa tela só**, com duas abas: "Taxas e prazos" e "No cardápio". A aba Pagamentos saiu do Cardápio Digital. *Diferença:* "Só na entrega / Também online" continua no cartão do Mercado Pago (Integrações e contas); a aba "No cardápio" tem um botão de atalho para ele.
- ✅ **6.3 Produtos e cardápio sem repetição.** Abas do Cardápio Digital renomeadas para "... no cardápio", cada uma com o botão "Editar cadastro" que abre Produtos já na aba certa. Nenhum cadastro foi movido.
- ✅ **6.7 Sistema mais claro.** Botão "Ver saúde do sistema" em Backup e espaço e em Sincronização e contingência. *Diferença:* as duas telas **não** foram unidas, porque o `app-17` injeta os cartões de Backup e Uso do Supabase em `tab-armazenamento`; unir exigiria mexer nesse gancho.
- ❌ **6.4 Início do Admin útil — REMOVIDO em 16/10 por decisão do Lucas (não gostou da tela).** Era: Trocar "Escolha uma tela" por:
  - cartões de pendências, cada um abrindo a tela certa: caixa vencido/aviso antecipado e liberação ativa, pedidos aguardando aceite, estoque baixo, ocorrências abertas, feedbacks sem resposta;
  - os 6 grupos como botões grandes;
  - "Vistas por último": as 3 telas mais recentes, guardadas no aparelho (`texas_admin_recentes`).
  Os dados dos cartões já existem na tela de Avisos (`tab-notificacoes`). O cartão de caixa vencido só entra depois do item 0 da Fase 4.
- ✅ **6.8 Ajuda do Tex no banco (feito em 16/10; textos que citavam o Início do Administrador também foram trocados).** A ajuda do Tex (tabela `ai_ajuda`) e os SQLs antigos ainda citam os nomes velhos das telas. Atualizar só depois que nomes e caminhos estiverem finais. O conector costuma cancelar `UPDATE` nessa tabela; se cancelar, entrego o SQL em `ajustes/` para você colar no Supabase.

---

## Ordem de aplicação (unificada)

1. **Fase 0** (você, agora): cliques no painel, sem código.
2. ✅ **Menu sem banco (Fase 6):** 6.1 → 6.5 → 6.6 → 6.2 → 6.3 → 6.7. Já feito, 6 zips entregues.
3. ✅ **Fase 1** (dinheiro e fiscal) → **Fase 2** (iFood) → **Fase 3** (Mercado Pago). Cada uma: SQL e/ou função de nuvem, teste com rollback, aplicação no banco real e um zip.
4. ✅ **Fase 4** (banco): itens 1 a 7 e, junto, o **item 0 (caixa vencido) completo**, com a parte de tela: banner, fechamento rápido, liberação, cartão da liberação e marca no Histórico.
5. ❌ **6.4 Início do Admin**: removido por decisão sua.
6. ✅ **6.8 Ajuda do Tex no banco**, depois que nomes e caminhos estão finais.
7. ⏳ **Fase 5 (validação final):** FEITO: testes de banco das Fases 1 a 4 e do caixa vencido (todos com rollback), `selar.py`, `verificar.py` (APROVADO). FALTA: abrir as telas novas no celular e no PC; ampliar a simulação local das funções de nuvem (não há `deno` neste ambiente); testar iFood, Mercado Pago e NFC-e de verdade quando forem ligados.
8. ✅ **Um zip final** na estrutura de 6 pastas, com `Código do Supabase.html` atualizado.
9. Só depois: homologação com iFood, Focus e Mercado Pago e, por fim, ligar as integrações.

---

## Fica de fora (depende de você ou do provedor)

- Custos e receitas, taxas de Pix, crédito e iFood, perfis fiscais.
- A confirmação em homologação com iFood, Focus e Mercado Pago (inclui o campo da descrição do pagamento `99` e o intermediário do iFood).
- O teste real de restauração de backup (o pacote diz que ainda não foi feito).
- A leitura a fundo dos `app-*.js` e das funções `ai-*`.
- Mudar o que cada tela faz, permissões do banco e o menu de Caixa, Pedidos e Clientes (no menu só o Administrador foi tratado).
