# Matriz de permissões do banco — 15/10/2026 (item 12, parte do banco)

Fonte: políticas RLS e permissões do schema `public` lidas direto do Supabase (só leitura). Isto mostra o que o BANCO permite por leitura direta; as gravações da equipe passam pelas funções `api_*`. **Falta validar com uma conta de cada perfil no app.**

## Sem login (anon)
- Lê só: `faq_publico` (linhas ativas) e as 11 views `v_cardapio_*` (nome, preço, foto, formas, status).
- Escreve só pelas funções públicas do cardápio, mesa, chat e push (25 funções).

## Cliente com login Google
- Nenhuma política o reconhece (`auth_nivel()` é nulo para ele): não lê nem grava tabela. Só as funções `api_conta_*`.

## Equipe (leitura direta)
| Acesso | Tabelas |
|---|---|
| Qualquer perfil da equipe lê | adicionais, categorias, combos, combo_itens, combo_precos, produtos, produto_*, promocoes, sistema, configuracoes_fotos |
| Admin e Operador leem | brindes, caixa_sessoes, cupons_usos, feedbacks, fidelidade, formas_pagamento, fotos_historico, indicacoes, movimentacoes_estoque, reembolsos, estoque, chat_*, entregador_posicoes, fechamentos_entrega, sangrias, ai_config |
| Só Admin lê | ai_log, ai_uso, ajustes_pos_venda, arquivo_historico, auditoria, backups, contingencia_reconciliada, cupons, despesas_recorrentes, eventos*, fila_sync, integridade_checks |
| Só Admin escreve direto (ALL) | produtos e tabelas do cardápio, estoque, formas_pagamento, backup_config, contingencia_config, sync_estado, faq_publico |
| Por perfil/dono | vendas, itens_venda, pagamentos_venda, mesas, ocorrencias, usuarios (próprio ou Admin/Operador), entregas_fechadas e fechamentos_entrega (Entregador só os seus), pedido_destinos |
| Só Desenvolvedor lê | erros_cliente |
| Sem política (só funções/Edge) | 43 tabelas: ifood_*, nfce_*, fiscal_*, integracoes_*, contas_*, compras*, pagamentos_online*, chat_tokens, ai_segredos etc. |

## Achado
- O papel `authenticated` tem permissão de `TRUNCATE`, `TRIGGER` e `REFERENCES` em quase todas as tabelas. A API do Supabase não expõe TRUNCATE e a RLS cobre SELECT/INSERT/UPDATE/DELETE, então não vi caminho de ataque. Mas é permissão a mais. Sugestão (não aplicada): `revoke truncate, trigger, references on all tables in schema public from anon, authenticated;`, com teste no app depois.

## Falta (precisa de você)
- Logar com Admin, Operador, Garçom, Cozinha e Entregador e tentar o que NÃO deveria funcionar (ex.: Garçom abrir Financeiro, Cozinha ver caixa, Entregador ver pedido de outro).
