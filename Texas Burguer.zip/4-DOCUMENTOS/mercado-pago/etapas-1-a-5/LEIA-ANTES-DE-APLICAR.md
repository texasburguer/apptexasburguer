# Mercado Pago — etapas 1 a 5 (pacote local)

**Este pacote não foi publicado nem aplicado remotamente.** Nenhum SQL foi executado no Supabase, nenhuma Edge Function foi implantada e nada foi enviado ao GitHub. Os arquivos foram apenas organizados e atualizados dentro desta cópia do `Texas Burguer.zip`.

## O que está incluído

1. **Etapa 1 — Estrutura do banco:** `SUPABASE/supabase-codigo/ajustes/2026-10-13-mp-etapa1-estrutura.sql` e teste estrutural correspondente.
2. **Etapa 2 — RPCs e fluxo de reserva/pagamento:** `SUPABASE/supabase-codigo/ajustes/2026-10-13-mp-etapa2-funcoes.sql`.
3. **Etapa 3 — Edge Functions:** `mp-criar`, `mp-webhook`, `mp-status` e `mp-reembolsar`, junto dos helpers e testes locais em `SUPABASE/supabase-codigo/funcoes/` e `SUPABASE/supabase-codigo/testes/mp-etapa3/`.
4. **Etapa 4 — Painel administrativo:** SQL `2026-10-13-mp-etapa4-painel.sql`, teste `teste-mp-etapa4.sql` e os arquivos atuais do painel em `SUBIR-NO-GITHUB/`.
5. **Etapa 5 — Checkout:** Pix com QR/copia-e-cola, consulta de status, reserva/cancelamento e formulário de cartão de crédito usando o SDK do Mercado Pago; arquivos `index.html`, `sw.js` e `app-15-cardapio-cliente.js` atualizados.

## Ordem recomendada para aplicar depois

1. Faça backup do banco e confira que os SQLs correspondem à versão atual do projeto.
2. No SQL Editor do Supabase, revise e aplique a Etapa 1.
3. Revise e aplique a Etapa 2.
4. Revise e aplique a Etapa 4 depois das Etapas 1 e 2.
5. Rode os testes SQL disponíveis e confira resultados antes de continuar.
6. Configure os secrets/credenciais conforme o manual, mantendo a integração desligada.
7. Implante as quatro Edge Functions da Etapa 3 pelo procedimento do seu projeto e configure o webhook com a URL correta.
8. Publique os arquivos de `SUBIR-NO-GITHUB/` somente depois de passar pelos testes em modo de teste.
9. Faça testes manuais de Pix pendente/aprovado/expirado, cartão aprovado/recusado, sessão expirada, cancelamento, pagamento na entrega e indisponibilidade de rede.

**Não cole todos os SQLs de uma vez sem revisar.** As Etapas 1, 2 e 4 são arquivos separados e devem ser executadas na ordem acima. Não coloque `access token` ou segredo de webhook no front-end.

## Limitações e estado de validação

- A sintaxe JavaScript dos arquivos atualizados foi verificada localmente com `node --check`.
- Os testes simulados das Edge Functions foram executados localmente quando disponíveis; eles não comprovam que credenciais, permissões, webhook, banco real ou conta Mercado Pago estejam corretamente configurados.
- Os SQLs não foram executados contra um PostgreSQL/Supabase real nesta preparação.
- O cartão usa o SDK público do Mercado Pago e envia ao backend somente o token do cartão, identificador do método e CPF para validação. Não foi feito teste de pagamento real.
- Antes de produção, revisar o fluxo completo, a compatibilidade da Orders API da conta e as exigências vigentes do Mercado Pago.
- A configuração inicial continua desligada por padrão; não habilite produção até concluir a homologação.
