# Etapa 0 — Mapeamento do sistema atual

Base: `Texas_Burguer.zip` (versão v34 do `sw.js`), `Plano___Mercado_Pago_no_Texas_Burger.md` e `Prévia_Mercado_Pago.html` (a aparência que você quer).

Nada foi alterado e nada foi aplicado no Supabase. Esta etapa só leu o pacote.

## 1. Como o pedido do cardápio funciona hoje

**Tela (front-end, `app-15-cardapio-cliente.js`)**

- A forma de pagamento é um `<select id="cdFormaPagamento">` (um item por forma cadastrada). Várias partes leem esse campo: acréscimo da forma, total do carrinho, preços e o texto do WhatsApp.
- `finalizarPedidoPublico()` valida nome, telefone, endereço, número e cidade, depois chama `criarPedidoCardapio`.
- Troco: hoje é **opcional** (caixa "Precisa de troco?"). Só vira obrigatório se o cliente marcar.
- Se o sistema estiver em contingência ou lento, o pedido vai pela planilha (`modoContingenciaAtivo` / `_preventivoPublico`). Pedido com brinde já pula esse caminho; o pagamento online vai seguir o mesmo padrão.
- Depois de criado, `mostrarBotaoWhatsappPedido()` monta a mensagem e abre o WhatsApp em 3 segundos (com opção de cancelar). Hoje a mensagem tem a linha "Pagamento: <forma>" e não tem aviso de "PAGO".

**Banco (`_criar_pedido_publico`, chamada por `api_criar_pedido_cardapio`, liberada para `anon`)**

A versão mais recente está em `ajustes/2026-10-12-contas-brindes.sql`. Numa única transação ela:

1. Valida tudo no servidor (produtos ativos, preço da forma escolhida, adicionais, brindes da conta).
2. Confere estoque (se `BLOQUEAR_ESTOQUE_NEGATIVO` estiver ligado) e o cupom (com trava por código).
3. Calcula total, taxa de entrega e acréscimo da forma.
4. Cria a venda (`status Confirmada`, `status_pedido Recebido`, `status_pagamento A Receber`), os itens e `pagamentos_venda`.
5. **Baixa o estoque na hora** (`_ajustar_estoque`), grava o uso do cupom e marca os brindes como usados.

Pontos úteis:

- `pagamentos_venda.taxa_aplicada` já é calculada com `formas_pagamento.taxa_percentual` e `taxa_fixa`. O plano de "usar a taxa de cada forma" já está coberto; basta cadastrar a taxa certa em cada forma.
- `cupons_usos.venda_id` aceita nulo, o que ajuda a reservar cupom antes da venda existir.
- O status do pagamento só tem dois valores: `Pago` e `A Receber`.

## 2. Molde das integrações (iFood e Nota fiscal)

Já existem `integracoes_config`, `integracoes_segredos`, `integracoes_log`, `_integ_checklist_def`, `_integ_pendencias` e as funções `api_integracoes_status/marcar/config/salvar_segredo/ligar/flags`. O front (`app-11-admin-integracoes.js`) desenha os cards a partir de `INTEG_INFO_` e `renderIntegracoes_`.

Para entrar o `mercadopago` é preciso mexer em listas fixas que hoje só aceitam `ifood` e `nfce`:

- restrição de `provedor` em `integracoes_config` e de `chave` em `integracoes_segredos`;
- `api_integracoes_salvar_segredo`, `api_integracoes_ligar`, `api_integracoes_config` e `api_integracoes_status` (filtro `ifood\_%` / `nfce\_%`);
- `_integ_checklist_def`, `_integ_pendencias` e `api_integracoes_flags`;
- no front: `INTEG_INFO_`, `carregarIntegFlags_` e a regra do botão Ligar (hoje o Ligar tem um caso especial para a Nota fiscal por causa do ambiente).

Essas funções foram redefinidas várias vezes (por exemplo, `api_integracoes_salvar_segredo` aparece duas vezes no `SUBIR-TUDO-supabase.sql`, e a última inclui `nfce_csc`). Vou sempre partir da **última** definição, para não perder nada.

Edge Functions: `nfce-emitir` e `ifood-sync` rodam pelo cron com a chave de serviço, com `verify_jwt` desligado, e leem segredos pelo banco. As nossas `mp-criar`, `mp-webhook`, `mp-status` e `mp-reembolsar` **não** terão chave de serviço (quem chama é o cliente ou o Mercado Pago), então cada uma precisa de proteção própria. O modelo mais parecido é `ai-publico-atendente`, que é pública.

## 3. Cancelamento e reembolso hoje

Já existe a tabela `reembolsos`, o gatilho `trg_reembolso_ao_cancelar` (cancelar uma venda **Paga** cria uma linha "Pendente"), `api_listar_reembolsos` e `api_confirmar_reembolso`, com tela em Administrador → Financeiro → Ajustes pós-venda.

Isso encaixa na decisão de nunca reembolsar sozinho: vamos reaproveitar. Cancelar pedido pago online cria a linha pendente; ao confirmar, o sistema chama `mp-reembolsar`.

Detalhe: `api_confirmar_reembolso` hoje é **só Admin**, e a decisão fala em "operador de caixa ou Admin".

## 4. Prévia × sistema atual

O visual bate: `estilo-01-base.css` já usa as mesmas cores (`--bg #0b0705`, `--gold #e0b53a`, `--red #d20807`) e a fonte Alfa Slab One. A Prévia também usa a Barlow no corpo, e o `index.html` hoje só carrega a Alfa Slab One.

Diferenças que exigem trabalho:

| Na Prévia | No sistema hoje |
| --- | --- |
| Formas em botões, em dois grupos ("Pagar agora, pelo site" e "Pagar na entrega") | Um `<select>` simples |
| Pix e cartão aparecem nos **dois** grupos | Cada forma aparece uma vez |
| Cartão: "débito ou crédito" numa opção só | Débito e Crédito são formas separadas, cada uma com seu preço, taxa e acréscimo |
| Troco obrigatório (valor ou "Não preciso de troco") | Troco opcional |
| Telas de Pix, cartão e "Pagamento aprovado" | Não existem |
| Alelo mostra os preços do Alelo e um aviso | Já existe preço por forma; falta o aviso na tela |

## 5. Achados que mudam o plano

1. **A chave "ligado" não chega ao cardápio.** `api_integracoes_flags` exige login, e o cardápio é público (anônimo). Preciso de uma leitura pública (função para `anon` ou chave em `v_cardapio_config`) com: ligado, modo, formas online, validade do Pix e a Public Key (a Public Key pode ir ao navegador).
2. **"Pagar online" não pode ser uma coluna exclusiva em `formas_pagamento`.** O Pix existe nos dois grupos da Prévia. A coluna nova deve ser "aceita online" (além de continuar aceitando na entrega), e o pedido grava qual modo o cliente escolheu.
3. **Reserva do pedido: recomendo tabela própria.** O pedido de hoje baixa estoque, cupom e brinde na criação e dispara vários gatilhos (aviso de novo pedido para a equipe, cozinha, sincronização com a planilha `vendas_sync`, fidelidade, gatilho da nota fiscal, relatórios). Uma venda "fantasma" acionaria tudo isso antes do pagamento. Com tabela própria, a reserva segura estoque, cupom e brinde, e a venda só nasce na aprovação.
4. **A função do pedido é grande e foi reescrita várias vezes.** Para criar a venda a partir da reserva, o caminho mais seguro é aceitar um parâmetro novo (reserva aprovada) na mesma função, mantendo o comportamento atual idêntico quando o parâmetro não vier. Com o Mercado Pago desligado, nada muda.
5. **Manter o `<select>` escondido.** Para os botões da Prévia não quebrarem acréscimo, total e WhatsApp, o `<select id="cdFormaPagamento">` fica oculto e sincronizado com os botões.
6. **Cliente logado:** a sessão do cliente fica em `txbContaSb_v1`, separada da equipe. `mp-criar` precisa validar o token do cliente e usar o e-mail da conta. O pedido aprovado entra em `contas_pedidos`, como já acontece.
7. **Contingência:** pagamento online pula o caminho da planilha (igual ao brinde). Se o banco cair, só pagar na entrega, como decidido.
8. **Cuidados do pacote:** o conector do Supabase cancela SQL com `delete from` dentro de função e `UPDATE` em `ai_ajuda`. Nas funções novas vou marcar status (como o iFood faz) em vez de apagar, e o texto da ajuda vai em arquivo SQL separado. Antes de entregar: `selar.py` e `verificar.py`, zip sem compressão e `CONFERIR-TAMANHOS.txt`.

## 6. Dúvidas

Se você não responder, aplico a sugestão de cada linha.

| # | Dúvida | Sugestão |
| --- | --- | --- |
| 1 | Cartão online = só crédito (decidido), mas a Prévia chama de "débito ou crédito". Na entrega, "Cartão de débito ou crédito" é uma opção só: qual forma cadastrada (preço, taxa, acréscimo) o pedido usa, Débito ou Crédito? | Online: título "Cartão de crédito", usa a forma Crédito. Na entrega: uma opção só, que usa a forma Crédito. Se Débito e Crédito têm preços iguais, não faz diferença |
| 2 | O troco obrigatório vale também com o Mercado Pago **desligado**? Hoje ele é opcional, então mudaria o "igual a hoje" | Vale sempre (o entregador sempre sabe quanto levar) |
| 3 | O operador de caixa também confirma o reembolso? Hoje só o Admin confirma | Operador e Admin |
| 4 | Fonte do corpo: Barlow (da Prévia) ou a que o cardápio já usa? | A que o cardápio já usa |

## 7. Próximo passo: Etapa 1 (Banco: estrutura)

Quando você aprovar esta etapa, entrego o SQL da estrutura, sem aplicar nada:

- tabela `pagamentos_online` e tabela de reserva do pedido;
- coluna "aceita online" e tipo (Pix ou cartão) em `formas_pagamento`;
- linha `mercadopago` desligada em `integracoes_config` e novos itens em `integracoes_segredos`;
- passos do checklist do Mercado Pago;
- a leitura pública da chave "ligado" (achado 1).
