> **Atualização 15/10/2026:** o Leitor Fiscal IA foi removido do sistema. Os trechos sobre ele neste documento são histórico e não valem mais.

# Etapa 11 — Auditoria estática do sistema (13/10/2026)

## Escopo e limites
Revisão estática do pacote local, JavaScript do navegador, Edge Functions, SQL, Service Worker e Apps Script. Nenhum SQL foi executado no banco e nenhuma função foi implantada. Não foi possível simular compras, pagamentos, autenticação ou sincronização contra os serviços reais.

## Correções aplicadas
1. **Sincronização da planilha:** `sync-fila` e `planilha-admin` agora têm timeout explícito de 30 s, leitura robusta da resposta e erro claro para HTTP não-2xx/JSON inválido. Em timeout, a função não considera a sincronização concluída; a fila é marcada com erro e segue o mecanismo de nova tentativa existente; não é marcada como sincronizada. Isso substitui o comportamento sem limite explícito de espera no `fetch` da Edge Function.
2. **Ping do Supabase:** o pacote já possui `ping-2dias` em `01-estrutura.sql`, agendado a cada dois dias às 12:00 (timezone do cron/projeto). O endpoint `ping` faz uma consulta leve à tabela `sistema`. A presença no SQL não prova que o job está ativo no projeto remoto; precisa conferir `cron.job` após deploy.
3. **Espelho de contingência:** o SQL agenda `contingencia-espelho-10min` nos minutos 3,13,23,33,43,53. O Apps Script principal contém endpoint de ping e a sincronização é disparada pelo cron; a execução real depende do job e da URL/chave configuradas.
4. **Leitor Fiscal:** adicionado acesso limitado a Admin/Operador, upload privado com redução no navegador, validação de CNPJ próprio, verificação de chave duplicada, bloqueio server-side do CNPJ próprio, confirmação explícita e identificador idempotente antes de registrar compra e limpeza das fotos após 30 dias, preservando metadados e histórico de confirmação.

## Achados que ainda exigem ambiente real
- O erro de “tempo esgotado de 5 segundos” relatado não foi reproduzido no código local: não havia timeout de 5 s nos dois `fetch` da sincronização server-side. O timeout explícito agora é 30 s e deverá ser comparado ao log do job real para confirmar se resolve o sintoma.
- Não há prova local de que `ping-2dias`, `sync-fila-2min` e `contingencia-espelho-10min` estejam ativos no Supabase remoto.
- A conta/planilha de contingência deve ser testada com lote grande, resposta lenta, JSON inválido, HTTP 5xx e repetição de lote; observar se a fila continua pendente e não duplica vendas.
- O Leitor Fiscal necessita do SQL de Etapa 10 e das Edge Functions implantadas. Testar foto ruim, nota repetida, CNPJ da própria loja, XML, ausência de chave, fornecedor não cadastrado e os 4 modos de pagamento.
- **Pagamento dividido** no Leitor Fiscal fica deliberadamente bloqueado para lançamento automático nesta versão: o esquema de compras existente suporta apenas `Pago` ou `A pagar`. A interface pede conferência manual para não distorcer caixa/contas a pagar.
- O botão de confirmação de compra continua usando a função de compra já existente. O histórico fiscal é marcado após a compra; se a chamada de histórico falhar, conferir Compras recentes antes de repetir a compra para evitar duplicidade.
- Auditoria funcional completa de pedidos, caixa, brindes, fidelidade, feedback, iFood, NFC-e, Mercado Pago e permissões depende de testes de ponta a ponta no ambiente de homologação.

## Testes locais executados
- Verificação de sintaxe JavaScript com `node --check` para todos os `.js` do app.
- Verificação de estrutura ZIP e presença dos novos arquivos.
- Busca estática pelo agendamento `ping-2dias` e sincronização de 10 minutos.
- Nenhuma transação real, deploy ou execução SQL remota.

## Checklist de homologação (obrigatório antes de produção)
- [ ] Aplicar SQL Etapa 10 em homologação.
- [ ] Cadastrar `gemini_fotos` e `groq_2` em Contas e acessos.
- [ ] Publicar `leitor-fiscal` e `fiscal-limpar` com `verify_jwt=false` (a função valida o JWT/perfil internamente).
- [ ] Confirmar que o bucket `fiscal-notas` está privado.
- [ ] Testar chave fiscal repetida e CNPJ da própria loja.
- [ ] Confirmar compra recebida: estoque, custo médio, despesa e registro “Lida pelo Tex”.
- [ ] Testar exclusão da foto após 30 dias e confirmar que o histórico permanece.
- [ ] Conferir no Supabase Dashboard os jobs `ping-2dias`, `sync-fila-2min`, `contingencia-espelho-10min` e `fiscal-leituras-limpeza-diaria`.
- [ ] Forçar timeout da planilha e verificar a fila; depois confirmar que sincroniza sem duplicar.
- [ ] Executar cenários do Mercado Pago das Etapas 1–9 em conta de teste.
