# Etapa 7 — Textos, LGPD e pacote v35

- Service Worker atualizado para `texas-shell-v35`.
- Versão de interface atualizada para 1.1, data 13/10/2026 e nota de novidades do Mercado Pago.
- Aviso de Privacidade agora cita o Mercado Pago como operador de pagamento e explica que e-mail e, no cartão, CPF são enviados para processar/verificar a transação; informa que o Texas Burger não recebe nem armazena o número completo do cartão.
- Ajuda inclui orientação sobre pagamento online, pendências e reembolso.
- A pasta `SUPABASE/supabase-codigo` inclui SQL, testes e documentação das etapas 1 a 6.

O texto é uma atualização informativa, não substitui revisão jurídica específica.
