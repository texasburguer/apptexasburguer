# Etapa 6 — Operação

## Entregue localmente
- Nova RPC `api_mp_pendencias_decisao`: lista pagamentos aprovados que não geraram venda automática, restrita a Admin/Operador.
- Ação de caixa para atualizar pendências e decidir entre liberar pedido ou reembolsar.
- Ao escolher reembolsar, o app registra a decisão na RPC existente e chama a Edge Function `mp-reembolsar`; erros deixam aviso para conferir o painel antes de repetir.
- Nova RPC `api_mp_resumo_operacional`: resumo do mês atual por Pix/cartão, recebimentos aprovados e taxas registradas em `pagamentos_venda`.
- A área Relatórios ganhou o resumo do Mercado Pago; a área Caixa ganhou o painel de pendências.

## Ainda depende de ambiente real
- Aplicar `ajustes/2026-10-13-mp-etapa6-operacao.sql` no Supabase, depois das etapas anteriores.
- Testar permissões de Admin e Operador.
- Confirmar o cálculo contábil de taxas e como reembolsos devem aparecer no relatório mensal.
- Validar cancelamento de venda paga e criação/baixa do reembolso pendente no fluxo existente.
