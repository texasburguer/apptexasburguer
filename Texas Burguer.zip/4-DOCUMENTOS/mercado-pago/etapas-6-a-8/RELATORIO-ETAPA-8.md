# Etapa 8 — Relatório de testes e conferência (local)

Data da preparação: 13/10/2026.

## Limites do ambiente

- Nenhum SQL foi executado no Supabase.
- Nenhuma Edge Function foi implantada.
- Não foram usadas credenciais reais nem criada transação no Mercado Pago.
- Por isso, os cenários que dependem de Supabase/Mercado Pago estão **pendentes de teste integrado**, e não podem ser declarados aprovados aqui.

## Verificações locais executadas

- `node --check` em todos os arquivos JavaScript do diretório `SUBIR-NO-GITHUB`: **passou**.
- `bash SUPABASE/supabase-codigo/testes/mp-etapa3/rodar.sh` (Node 22+, simulado, sem internet): **42 testes de funções puras e 64 testes de fluxo, zero falhas**.
- `bash SUPABASE/supabase-codigo/testes/verificar-etapas-6-a-8.sh`: **passou** (sintaxe JS, versão do Service Worker, existência dos pontos de integração).
- `psql` não está disponível neste ambiente; portanto, o SQL não foi analisado/rodado contra um PostgreSQL real.
- Integridade do ZIP será conferida depois da montagem do pacote final.

## Testes integrados obrigatórios antes de produção

| Cenário | Resultado neste pacote |
|---|---|
| Mercado Pago desligado: pedido normal, cupom, brinde e fidelidade | Pendente no navegador/Supabase real |
| Pix aprovado | Pendente em conta de teste |
| Pix expirado | Pendente em conta de teste |
| Cartão aprovado | Pendente em conta de teste |
| Cartão recusado | Pendente em conta de teste |
| Webhook repetido/idempotência | Coberto parcialmente pelos testes simulados existentes; confirmar no ambiente integrado |
| Assinatura de webhook inválida | Coberto por teste puro/simulado; confirmar deployment/configuração real |
| Reembolso total e parcial | Pendente em conta de teste |
| Cancelamento restaura estoque/cupom/brinde | Pendente no banco de teste |
| Celular: QR Pix e Brick de cartão | Pendente em navegador móvel |
| Pagamento aprovado quando caixa/cardápio fechado | Validar pendência e decidir entre liberar/reembolsar |

## Correções e riscos registrados

- O resumo mensal depende de `aprovado_em` e de `pagamentos_venda.taxa_aplicada`; conferir a consistência com reembolsos e com a política contábil antes de usar como fechamento financeiro.
- O botão Reembolsar registra primeiro a decisão e depois chama a Edge Function `mp-reembolsar`. Se a função retornar erro ou perder conexão, conferir o status no painel do Mercado Pago antes de repetir; não presumir que o dinheiro voltou.
- A integração só deve ser ligada em Produção depois de todas as etapas de teste passarem com contas de teste.
