# Estado das etapas 6 a 8

- Etapa 6: código local de operação, decisões pendentes, reembolso e resumo mensal preparado.
- Etapa 7: aviso de privacidade, Ajuda, novidades e cache v35 atualizados.
- Etapa 8: verificações locais e relatório de testes adicionados.

**Não aplicado no Supabase, não implantado e sem transações reais.** Os testes de integração real seguem pendentes até configurar ambiente de homologação.
