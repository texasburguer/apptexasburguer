# Mercado Pago — etapas 6 a 8

Arquivos desta pasta: operação (Etapa 6), privacidade e versão v35 (Etapa 7), e relatório de testes (Etapa 8).

**Estado:** preparado localmente; não aplicado no Supabase e não implantado no GitHub.

Para executar as verificações locais, rode `bash SUPABASE/supabase-codigo/testes/verificar-etapas-6-a-8.sh` a partir da raiz `Texas Burguer/`. Os testes de integração real continuam pendentes.
