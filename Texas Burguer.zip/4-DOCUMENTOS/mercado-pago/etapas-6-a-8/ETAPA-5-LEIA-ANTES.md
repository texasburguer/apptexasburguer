# Etapa 5 — Checkout Mercado Pago (prévia local)

O checkout foi ampliado para Pix e cartão de crédito online. Pix utiliza reserva, QR Code/copia-e-cola e consulta de status; cartão usa o SDK público do Mercado Pago (Card Payment Brick), coleta CPF somente para cartão e envia o token do cartão à Edge Function `mp-criar`. O fluxo tradicional de pagamento na entrega foi preservado.

O pagamento depende das Etapas 1, 2 e 4 aplicadas e das Edge Functions da Etapa 3 implantadas e configuradas. Nenhuma dessas ações foi executada remotamente durante esta preparação.

## Validação local
- `node --check` no JavaScript atualizado.
- Os testes locais simulados das Edge Functions ficam em `SUPABASE/supabase-codigo/testes/mp-etapa3/rodar.sh`.
- Não houve execução de SQL, acesso ao banco, pagamento de teste real, publicação no GitHub ou implantação de funções.

**Não considerar produção pronta antes de concluir testes reais em modo de teste do Mercado Pago.**
