> **Atualização 16/10/2026:** a tela "Pergunte à IA" NÃO existe mais no Administrador. O menu tem 24 telas em 6 grupos; a IA só é acessada pelo balão do Tex. Onde este plano citar a tela `ia`, ignore.

# Texas Burger — Plano do menu do Administrador + caixa vencido (v2)

Data: 16/10/2026 · Base: `Texas_Burguer.zip` (código lido: `app-02-abas.js` e `index.html`).

Este plano tem duas partes: **A)** a regra do caixa vencido (Fase 4, item 0), já com os seus ajustes; **B)** a nova Fase 6, que reorganiza o menu do Administrador sem tirar nenhuma função. No fim, a ordem de aplicação.

---

## A) Fase 4, item 0 revisado — caixa vencido

1. **Pedido externo nunca trava.** iFood e cardápio entram como "Recebido" e o botão de aceitar funciona mesmo com caixa vencido. Aparece aviso forte na tela e push para a equipe. O iFood cancela sozinho em ~8 min, então bloquear o aceite perderia o pedido.
2. **O que trava:** só venda nova de balcão e de mesa (`api_iniciar_venda`, fechar conta da mesa). Sangria e resgate de prêmio seguem a regra de hoje (exigem caixa aberto) mais o vencimento. Preparar, despachar, entregar e receber pedidos já aceitos continuam livres.
3. **Vencimento pelo dia operacional.** A sessão vence no primeiro corte (padrão 06:00, horário de Brasília, configurável) depois do início. Teto absoluto de 24 h.
   - Ajuste que sugiro: o corte só vale se a sessão já tem pelo menos 6 h de vida. Sem isso, um caixa aberto às 05:30 venceria às 06:00.
   - Caixa aberto às 18h e esquecido vence às 06:00 do dia seguinte, antes de abrir o serviço. O turno que passa da meia-noite segue livre.
   - Cálculo sempre em `America/Sao_Paulo` (o banco roda em UTC).
4. **Saída de emergência.** "Liberar por X horas" (padrão 4 h, máximo 12 h), só Admin, com motivo obrigatório. Grava em auditoria, expira sozinho e manda push aos Admins. Enquanto estiver ativa, aparece um cartão na Visão Geral com quem liberou, o motivo e até quando, para a saída de emergência não virar hábito silencioso.
5. **Fechamento rápido.** Botão "Fechar caixa vencido" pede só o valor contado. A diferença vira divergência registrada com a marca "fechamento atrasado" e o motivo. A contagem completa pode ser feita depois. A marca de fechamento atrasado aparece no Histórico de sessões de caixa, para o Admin ver quais foram feitos às pressas. Quem fecha: Admin e Operador. Garçom e Cozinha veem "caixa vencido, chame o responsável".
6. **Aviso antecipado.** Banner a partir de 2 h antes do corte, no topo do Início do Admin e do Caixa.
7. **Testes:**
   - caixa aberto 18h, agora 07h → bloqueia venda nova;
   - mesmo caixa, 02h → passa;
   - caixa com 25 h → bloqueia mesmo sem cruzar corte;
   - pedido do iFood entra e é aceito com caixa vencido;
   - liberação por 4 h → vende; depois expira;
   - fechamento rápido registra divergência;
   - Garçom não vê o botão de fechar; a liberação ativa aparece na Visão Geral; o fechamento rápido aparece marcado no Histórico de sessões de caixa.

---

## B) Fase 6 — Menu do Administrador

### O que encontrei hoje

São 6 grupos e 25 telas (24 do menu + "Pergunte à IA", que o `app-19` acrescenta ao primeiro grupo). Pontos que atrapalham:

- **Nomes que confundem.** "Contas e despesas" (Financeiro) e "Contas e acessos" (Sistema) parecem a mesma coisa. A segunda, na verdade, guarda IAs, iFood, Nota fiscal e Mercado Pago.
- **Formas de pagamento em dois lugares.** Operação → Pagamentos e Cardápio Digital → aba Pagamentos.
- **Categorias, Produtos, Combos e Adicionais em dois lugares.** Catálogo → Produtos e Cardápio Digital. A segunda é a versão "o que aparece no cardápio", mas o nome não deixa isso claro.
- **Grupos misturados.**
  - Painel tem Relatórios (dinheiro) junto de Ocorrências e Feedbacks (atendimento).
  - Operação tem Pagamentos e Configurar notificações, que não são operação do dia.
  - Usuários e Permissões está em Sistema, longe de Entregadores e Mesas.
- **Saúde e backup espalhados.** "Backup e espaço", "Sincronização e contingência" e a bolinha de "Conexão e servidores" tratam do mesmo assunto em três lugares.
- **Tela inicial vazia.** Ao entrar no Admin aparece só "Escolha uma tela no menu ao lado".
- **Sem atalho.** Para achar uma tela é preciso saber o grupo.

### Menu novo (nenhuma tela some, só muda de grupo ou de nome)

| Grupo | Telas (id atual → nome novo) |
|---|---|
| **Hoje** | `visaogeral` Visão Geral · `ocorrencias` Ocorrências · `feedbacks` Feedbacks · `ia` Pergunte à IA |
| **Dinheiro** | `financeiro` Contas a pagar e despesas · `historico` Histórico (vendas, despesas, caixas) · `ajustes` Reembolsos e ajustes · `analise` Previsto e metas · `relatorios` Relatórios e DRE |
| **Produtos** | `produtos` Produtos, combos e adicionais · `estoque` Estoque · `compras` Compras e fornecedores · `custosprecificacao` Custos e precificação |
| **Vendas e cardápio** | `cardapiodigital` Cardápio Digital · `pagamentos` Formas de pagamento · `promocoes` Promoções e cupons · `eventos` Eventos |
| **Loja e equipe** | `restaurante` Mesas e QR Codes · `taxasentregas` Entregadores e taxas · `usuarios` Usuários e permissões · `notifadmin` Configurar avisos |
| **Sistema** | `contas` Integrações (IAs, iFood, Nota fiscal, Mercado Pago) · `armazenamento` Backup e espaço · `integridade` Sincronização e contingência · `auditoria` Auditoria |

Os **ids das telas não mudam**. Por isso `abrirAdministrador('ifood')`, `('nfce')`, `('mercadopago')`, `('ias')`, `('drive')` e todos os botões que já chamam telas continuam funcionando.

Operador continua vendo só **Atendimento** (Ocorrências, Feedbacks e Pergunte à IA). Garçom, Cozinha e Entregador não mudam.

### Etapas

**6.1 Renomear e reagrupar (risco baixo).**
- Editar só `ADMIN_GRUPOS` e `ADMIN_SUBABAS_ROTULOS` em `app-02-abas.js`.
- O `app-19` faz `ADMIN_GRUPOS[0].subs.push('ia')`, então "Hoje" tem que continuar sendo o primeiro grupo.
- Atualizar os ícones (`IC_SVG_`) dos grupos novos, reaproveitando os existentes.
- Atualizar o texto do manual (`app-09-ajuda.js`) que cita nomes de telas, e as mensagens que dizem "vá em Administrador → ...".

**6.2 Uma tela só para pagamentos.**
- Conferir no código que a aba "Pagamentos" do Cardápio Digital e a tela "Pagamentos" falam da mesma lista (`formas_pagamento`).
- Se sim, uma tela "Formas de pagamento" com duas abas internas (`abaInterna_`): **Taxas e prazos** e **No cardápio e online** (Só na entrega / Também online).
- Se forem dados diferentes, manter as duas e só ligar uma à outra com um botão de atalho.

**6.3 Produtos e cardápio sem repetição.**
- Em "Produtos, combos e adicionais": abas Produtos / Combos / Categorias / Adicionais (já existem).
- No Cardápio Digital: renomear as abas para "Aparece no cardápio: ..." e pôr em cada uma um botão "Editar cadastro" que abre a aba correspondente.
- Nada é removido: só o nome e o caminho entre as duas ficam claros.

**6.4 Início do Admin útil.** Trocar "Escolha uma tela" por:
- cartões de pendências, cada um abrindo a tela certa: caixa vencido/aviso antecipado, pedidos aguardando aceite, estoque baixo, ocorrências abertas, feedbacks sem resposta;
- os 6 grupos como botões grandes;
- "Vistas por último": as 3 telas mais recentes, guardadas no aparelho (`texas_admin_recentes`).

Os dados dos cartões já existem na tela de Avisos (`tab-notificacoes`); é reaproveitar. O cartão de caixa vencido só entra depois do item 0 da Fase 4 (depende da regra no banco), por isso esta etapa vem por último entre as de menu.

**6.5 Campo "Ir para…".** Caixa de busca no topo do menu que filtra os rótulos de `ADMIN_SUBABAS_ROTULOS`. Ex.: digitar "cupom" mostra Promoções e cupons. No celular fica acima dos grupos.

**6.6 Uma linha de explicação por tela.** Embaixo de cada nome no menu (celular e lateral do PC), em cinza, o que a tela faz. Ex.: "Integrações — iFood, Nota fiscal, Mercado Pago e chaves das IAs".

**6.7 Sistema mais claro.**
- Dentro de "Backup e espaço" e "Sincronização e contingência", um aviso curto com atalho "Ver saúde do sistema" (a bolinha de Conexão e servidores).
- Se a conferência da etapa 6.2 mostrar que dá, unir as duas telas numa só com 2 abas, mantendo os ids antigos como atalho.

**6.8 Ajuda do Tex no banco (por último).**
- A ajuda do Tex (tabela `ai_ajuda`) também cita nomes de telas. Só depois que nomes e caminhos estiverem finais, atualizar esse texto.
- O conector do Supabase costuma cancelar `UPDATE` nessa tabela. Se cancelar, entrego o SQL em `ajustes/` para você colar no Supabase, como já foi feito antes.

### Teste de que nada se perdeu (antes de entregar)

1. Script que compara a lista de ids de `ADMIN_SUBABAS` antes e depois: tem que ter os mesmos 25.
2. Cada id aparece em exatamente um grupo.
3. Todos os `onclick` que chamam `abrirAdministrador(...)` resolvem para uma tela existente (o repositório já checa 558 handlers).
4. Operador só vê Atendimento, e as permissões da `MATRIZ-PERMISSOES-2026-10-15.md` seguem iguais (o menu só esconde, o banco decide).
5. Playwright no celular e no PC: abrir as 25 telas e confirmar que carregam sem erro de console.
6. Rodar `selar.py` e depois `verificar.py` (tem que dar APROVADO) e subir o novo `sw.js` (`texas-shell-vNN`).

---

## Ordem de aplicação

1. **Fase 0** (você, agora): cliques no painel, sem código.
2. **Menu do Administrador, parte sem banco:** 6.1 → 6.5 → 6.6 → 6.2 → 6.3 → 6.7. Só mexe no front, não toca em dinheiro e deixa os nomes finais prontos.
3. **Fases 1 a 3** (dinheiro e fiscal, iFood, Mercado Pago) e **Fase 4** (banco). O item 0 (caixa vencido) entra na Fase 4 completo, com a parte de tela: banner, fechamento rápido, liberação, cartão da liberação e marca no Histórico.
4. **6.4 Início do Admin**, depois do item 0, para o cartão de caixa vencido já ter o que mostrar.
5. **6.8 Ajuda do Tex no banco**, depois que nomes e caminhos estão finais. Antes disso o texto teria de ser refeito.
6. **Fase 5 (validação):** testes SQL com rollback, funções, teste de que nenhuma tela se perdeu, e então `selar.py` e `verificar.py`.
7. Um zip só, na estrutura de 6 pastas, com `Código do Supabase.html` atualizado. Só depois: homologação com iFood, Focus e Mercado Pago e ligar as integrações.

## Fica de fora

Mudar o que cada tela faz, permissões do banco e o menu de Caixa, Pedidos e Clientes (só o Administrador foi tratado).
