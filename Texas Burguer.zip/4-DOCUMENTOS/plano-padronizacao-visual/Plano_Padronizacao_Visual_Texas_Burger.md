# Plano de Ação — Padronização Visual e Usabilidade (Texas Burger)

Base: análise do código da pasta `1-SUBIR-NO-GITHUB` (index.html, 27 arquivos `app-*.js`, 17 arquivos `estilo-*.css`).
Observação: a análise foi feita lendo o código, sem ver as telas renderizadas. Antes de cada fase, conferir no celular e no computador.

---

## Andamento

| Fase | Situação |
|------|----------|
| 0 Preparação | Concluída (cópia de trabalho; original preservado) |
| 1 Variáveis | **Concluída** (zip Fase 1+2) |
| 2 Componentes | **Concluída** (zip Fase 1+2) |
| 3 Janelas e mensagens | **Concluída** (sw v43) |
| 4 Estilo solto | **Concluída**, com ressalvas (sw v44) |
| 5 Consolidar CSS | **Concluída**, com ressalvas (sw v45) |
| 6 Usabilidade | **Concluída** (sw v46; ajustes finais no v47) |
| 7 Conferência final | **Em andamento**: auditoria automática de 31 telas e 49 janelas feita (celular e PC); falta o teste com login no celular |

Observações da Fase 1+2: letras de 9–11,5px viraram 11px (provisório; Fase 6 sobe para 12px); os 45 botões "sem classe" do index já eram estilizados pelos seus contêineres, então o ajuste real foi unificar botões, abas internas, campos, etiquetas e alvos de toque no CSS.

---

## 1. Objetivo

1. Todo o sistema (equipe, cardápio do cliente, conta, pagamento, janelas) com **um único estilo**.
2. Telas mais **fáceis e intuitivas** no celular (uso no balcão/cozinha) e no computador.
3. Fazer isso **sem quebrar** o que já funciona (caixa, pedidos, impressão, pagamento).

## 2. Diagnóstico resumido (o que foi encontrado)

| # | Problema | Evidência no código |
|---|----------|---------------------|
| D1 | Botões com dois visuais | Base define cantos de 4px; estilos posteriores sobrescrevem para 10px. 45 botões do index não têm classe (rodapé do cardápio, − / +, Buscar, Sair, abas internas) |
| D2 | Fonte diferente no pagamento | `estilo-16-pagamento.css` usa `Barlow`, que nunca é carregada |
| D3 | Cores de status soltas | 3 verdes e 5 vermelhos/rosas diferentes |
| D4 | Cantos arredondados sem padrão | ~20 valores de `border-radius` (2px a 20px, 999px) |
| D5 | Tamanhos de letra sem escala | 25 tamanhos (9px a 34px), muitos "meios" (12.5, 13.5…) |
| D6 | Mensagens nativas do navegador | ~70 `alert()`, ~58 `confirm()`, 3 `prompt()`. `toast()` da conta do cliente chama `alert()` |
| D7 | Estilo escrito dentro do HTML/JS | ~400 `style=""` no index, ~440 nos JS (margens 6/8/10/12/14px variando) |
| D8 | CSS empilhado | 17 arquivos, um sobrescrevendo o outro (ex.: `button.ghost` em mais de um) |
| U1 | Confirmações pouco claras | OK/Cancelar genérico em ações de apagar/cancelar |
| U2 | Menu | Celular mostra 4 abas + "Mais"; Administrador tem ~20 telas sem agrupamento |
| U3 | Alvos de toque pequenos | `ghost` / `small-gold` com 6px de preenchimento e 12px de letra na base |
| U4 | Letras muito pequenas | ~40 usos entre 9 e 11px |
| U5 | Contraste fraco | `--red-dim` (#8c0a08) sobre o painel = 1.9:1 |
| U6 | Foco de teclado | Só 4 regras `focus-visible` no sistema |
| U7 | Ícones misturados | Navegação inferior em SVG; resto em emoji (muda entre Android/iOS/PC) |
| U8 | Carregando/vazio/erro | Esqueleto animado só no cardápio; resto usa texto solto |
| U9 | Tabelas no celular | Rolam para o lado sem indicativo |

## 3. Regras para não quebrar nada

- Trabalhar sempre numa **cópia** do zip; manter o original como backup.
- Uma fase por vez; testar e só então seguir.
- Não mudar nomes de **ids**, **funções** e **classes usadas pelo JS** (apenas acrescentar classes novas).
- Depois de editar CSS/JS, **trocar o `?v=` dos arquivos** no `index.html` e atualizar o `sw.js`, senão o celular continua com a versão antiga em cache.
- Impressão (`app-07-impressao.js`, logos `logo-impressao-*`) fica **fora** do escopo visual, salvo pedido.
- Teste mínimo ao final de cada fase: login, abrir caixa, lançar venda, pedido pelo cardápio, pagar, imprimir, abrir 3 janelas diferentes.

---

## 4. Fases

### Fase 0 — Preparação (rápida)
- [ ] Copiar o zip, extrair e anotar a versão atual.
- [ ] Listar telas/janelas para conferência (Início, Caixa, Pedidos, Clientes, Administrador e subtelas, Cardápio do cliente, Conta, Pagamento).
- [ ] Tirar prints "antes" (celular e computador) para comparar.

**Pronto quando:** existe backup e a lista de telas de teste.

### Fase 1 — Variáveis do sistema (base de tudo)
Em `estilo-01-base.css`, dentro de `:root`, criar e usar:

- **Cores de status:** `--ok`, `--erro`, `--aviso`, `--info` (e versões de fundo suave). Trocar os verdes/vermelhos soltos (`#6dbb2e`, `#2e9e5b`, `#4cc35f`, `#4caf50`, `#ffb3ab`, `#e0443a`, `#ff9d92`, `#ff8a80`…) por elas.
- **Cantos:** `--raio-controle: 10px` (botões, campos), `--raio-card: 14px` (cards, janelas), `--raio-pilula: 999px`.
- **Escala de letra:** `--fs-xs: 12px`, `--fs-sm: 13px`, `--fs-md: 15px`, `--fs-lg: 18px`, `--fs-xl: 22px` (títulos em Alfa Slab One mantidos).
- **Espaçamento:** `--esp-1: 4px`, `--esp-2: 8px`, `--esp-3: 12px`, `--esp-4: 16px`.
- **Fonte do corpo:** definir uma única variável e remover `Barlow` do pagamento (usar a mesma do resto).

**Pronto quando:** nenhum `border-radius`, `font-size` ou cor de status fixo fora das variáveis (exceto casos justificados, como o botão do WhatsApp `#25d366`).

### Fase 2 — Componentes base (botões, campos, cartões, etiquetas)
- [ ] **Botões:** definir uma vez só `primary` (vermelho), `secondary`/`ghost`, `small-gold`, `perigo`, `icone`. Remover as definições duplicadas dos arquivos 07, 10 e 13.
- [ ] **Botões sem classe:** dar classe aos 45 botões do index (rodapé do cardápio, − / +, Buscar, Sair, abas internas, `toggle-mode`, `atalho-btn`).
- [ ] **Alvo de toque:** altura mínima de 44px em celular; 36px no computador.
- [ ] **Campos:** um único estilo para `input/select/textarea` (hoje há regras em duas partes do arquivo base, linhas ~125 e ~375), com 16px no celular (evita zoom do iPhone).
- [ ] **Badges/etiquetas:** um padrão (`.badge.ok/.erro/.aviso/.neutro`) e usar nas mesas, pedidos, pagamento e integrações.
- [ ] **Foco de teclado:** regra global `:focus-visible` (contorno dourado) para todos os controles.

**Pronto quando:** qualquer botão/campo de qualquer tela tem o mesmo visual, inclusive Pagamento e Conta do cliente.

### Fase 3 — Janelas e mensagens (maior ganho de uso)
- [x] Criar **um componente de janela** de confirmação reaproveitando o `vsForm` (`app-26-visual.js`) e o `.modal-box`.
- [x] Criar `confirmar({titulo, texto, acao, perigo})`: botão da ação com o **nome da ação** ("Excluir produto"), vermelho quando destrutivo, e "Voltar" ao lado.
- [x] Criar `avisar(texto, tipo)` (toast no tema escuro, some sozinho) e fazer o `toast()` do `app-27` usar isso em vez de `alert()`.
- [x] Trocar `alert/confirm/prompt` por esses componentes, **por arquivo**, na ordem do volume: `app-11` (16 alert, 17 confirm) → `app-03` → `app-17` → `app-10` → `app-06` → `app-12` → `app-02` → restantes.
- [x] Atenção: `confirm()` é síncrono e o novo é assíncrono — cada trocar exige ajustar o trecho de código que vem depois (`await`/callback). Testar cada ação.
- [x] Padronizar cabeçalho das 49 janelas (título + ✕ no mesmo lugar, mesmo tamanho) e fechamento por Esc / toque fora.

**Pronto quando:** não resta `alert/confirm/prompt` nativo nas telas de uso comum; ações destrutivas têm botão nomeado.

**FEITO em 2026-10-15 (sw v43):** `app-28-dialogos.js` + `estilo-18-dialogos.css`. Nenhum `alert/confirm/prompt` nativo resta no código (129 trocas em 17 arquivos). 
- `confirmar({titulo, texto, ok, voltar, perigo, somenteOk})` → Promise<boolean>; `confirmarTxt_(texto, ok, perigo, titulo, voltar)` é a forma curta usada nas trocas (sem `ok`, o botão é deduzido do texto: "Excluir esta mesa?" → botão vermelho "Excluir mesa"; o foco inicial fica em "Voltar" nas ações perigosas).
- `avisar(texto, tipo?, ms?)`: aviso no tema escuro que some sozinho (ok/erro/aviso/info, deduzido pelo texto); texto muito longo abre janela com "Entendi". `toast()` da conta do cliente passou a usar `avisar`.
- Funções que passaram a ser `async` por causa do `await`: excluirModalCliente, fecharContaMesaUI, oferecerRecuperarCarrinho_, filaDescartar_, excluirUsuarioPrompt, ligarInteg_, desligarInteg_, sb410BkRestaurar, sb410BkExcluir, cfRwCopiar (nenhum chamador usa o retorno).
- Onde o `alert` vinha antes de recarregar a página (servidor voltou; backup restaurado) agora é janela "Entendi" e só recarrega depois do toque.
- As 49 janelas do index.html já tinham o mesmo cabeçalho (título + ✕). Agora **Esc** fecha a de cima e **toque fora** fecha as que não têm campos (as com campos não fecham por toque fora, para ninguém perder o que digitou).

### Fase 4 — Limpeza de estilo solto
- [x] Criar classes utilitárias: `.mt-1/.mt-2/.mt-3`, `.mb-2`, `.sem-margem`, `.oculto`, `.largura-auto`.
- [x] Trocar os `style=""` mais repetidos no index: `display:none` (41), `width:auto` (28), `margin-top:8/10/12/14px` (~65).
- [x] Nos JS, trocar os `style` repetidos nos HTMLs gerados (por arquivo, mesmo critério).
- [ ] Deixar `style=""` só para valores realmente dinâmicos (cor vinda de dado, largura de barra de progresso).

**Pronto quando:** `style=""` no index cai para poucas dezenas e o espaçamento segue a escala.

**FEITO em 2026-10-15 (sw v44), com ressalvas:** utilitários no fim do `estilo-01-base.css` (`.mt-0…4`, `.mb-*`, `.ml-*`, `.mr-*`, `.sem-margem`, `.largura-auto`, `.oculto`, `.d-flex`, `.ai-centro`, `.jc-centro`, `.fx-wrap`, `.gap-1…4`, `.txt-dir/centro/muted/ouro`, `.fw-7`, `.fs-2xs…md`; todos com `!important` para valer como o `style=""` que trocaram). Convertidos 213 no index.html (402 → 189) e ~150 nos JS (menos `app-07-impressao.js`, que é impressão).
- Espaços foram encaixados na escala 4/8/12/16 (6→8, 10→12, 14→12). Comparação no navegador (celular e computador): de 881 elementos, só 19 mudaram, todos 2px de espaço ou 0,5px de letra.
- **Ficou de fora de propósito:** todo `display:none` (o JS liga e desliga com `style.display`, inclusive `= ''`; uma classe quebraria isso) e o `display:flex` do `#cdAvisosPedido` (uma regra do CSS lê o atributo `style`). Também ficaram valores únicos (larguras, cores de dado, barras de progresso). Por isso o index.html não chegou a "poucas dezenas".

### Fase 5 — Consolidar o CSS
- [x] Unificar os 17 arquivos em poucos, por assunto: `base` (variáveis + componentes), `equipe` (telas internas), `cardapio` (cliente + conta + pagamento), `ia` (Tex + balões), `computador` (≥900px).
- [ ] Eliminar regras repetidas/anuladas (principalmente botões e janelas).
- [x] Ajustar a ordem dos `<link>` no `index.html` e os `?v=`; atualizar `sw.js`.

**Pronto quando:** cada componente é definido em um único lugar e o visual não muda em relação à Fase 4.

**FEITO em 2026-10-15 (sw v45), com ressalvas:** 18 arquivos viraram 4, **na mesma ordem de antes** (assim a cascata não muda): `estilo-base.css` (antigos 01+02), `estilo-ia-cardapio.css` (03–08), `estilo-equipe.css` (09–14: navegação inferior, polimento, janelas, cadastro fácil, visual, computador) e `estilo-conta-pagamento.css` (15–18). Cada trecho tem um comentário `(de estilo-NN-….css)` para achar a origem. Comparei o estilo calculado de 2.856 elementos antes/depois (celular e computador, normal e com todas as janelas abertas): 0 diferenças.
- **Não feito:** agrupar por assunto (equipe × cardápio × IA) e apagar regras repetidas/anuladas. Isso exige reordenar regras, e a ordem decide quem vence; fica como limpeza futura, feita aos poucos e com a mesma comparação.
- **No GitHub:** apagar os 18 `estilo-NN-*.css` antigos do repositório (o `index.html` novo não usa mais nenhum).

### Fase 6 — Usabilidade (navegação e leitura)
- [x] **Administrador:** agrupar as ~20 telas em seções (Vendas, Cardápio, Compras/Estoque, Financeiro, Sistema), com ícone e título de seção, no celular e no menu lateral do computador.
- [x] **Menu inferior do celular:** revisar quais abas ficam fixas (Início, Caixa, Pedidos, Meus ganhos) e o que vai para "Mais", com indicador de alerta visível no "Mais".
- [x] **Letras mínimas:** nada abaixo de 12px (hoje ~40 usos de 9–11px), exceto selos muito curtos.
- [x] **Contraste:** trocar `--red-dim` em textos/badges por tom mais claro (mínimo 4.5:1); conferir `--gold-dim` em texto pequeno.
- [x] **Ícones:** adotar um único conjunto (SVG, como na navegação inferior) nos botões principais; emoji só em textos de conversa/avisos.
- [x] **Carregando / vazio / erro:** reaproveitar o esqueleto animado do cardápio (`cdPulse`) e criar "estado vazio" com texto + botão de ação.
- [x] **Tabelas no celular:** em Vendas, Despesas e Sessões, usar cartões por linha (ou sombra/indicador de rolagem lateral).
- [x] **Formulários:** rótulos legíveis (≥13px), agrupar campos relacionados, botão principal sempre no fim e visível.

**Pronto quando:** as 5 tarefas mais comuns (vender, abrir/fechar caixa, ver pedido, cadastrar produto, ver relatório) levam menos toques e nenhuma exige "procurar" o botão.


**FEITO em 2026-10-15 (sw v46/v47):** ver `FASE6_RELATORIO.md`. Ajustes do v47: a faixa "pagamentos online aguardando decisão" do Caixa ficou bem discreta (uma linha fina com contorno, 32px) e só aparece com o Mercado Pago ligado **e** pagamento esperando decisão (Admin/Operador/Desenvolvedor); lista vazia de Produtos e Clientes com texto próprio (`estadoVazio_`, com botão "+ Novo produto" em Produtos); o cartão de pendência mostra "Cartão de débito" quando for débito.
**Emojis em botões montados por JS (sw v48):** `app-29-usabilidade.js` troca sozinho o emoji do COMEÇO do texto de um botão pelo SVG do sistema (mapa `ICONES`; novos desenhos em `IC_SVG_`, `app-02-abas.js`). Vale para botão novo ou com texto trocado depois. Emoji em avisos, conversa e ajuda não é tocado (é permitido pelo plano).

### Fase 7 — Conferência final
**Feito (automático, Playwright, celular 390px e computador 1280px):** 31 telas e 49 janelas abertas uma a uma: nenhuma letra abaixo de 12px, nenhum estouro de largura, nenhum botão baixo demais no celular (o link "Agora não" foi corrigido); página abre sem erro de console, sem rolagem lateral, nenhuma letra visível abaixo de 12px, faixa de pagamento escondida sem Mercado Pago ou sem pendência e visível com os dois, `verificar.py` APROVADO (33 arquivos), 44 arquivos conferidos com `CONFERIR-TAMANHOS.txt`, nenhum `alert/confirm/prompt` nativo.
**Falta (só você, logado no celular):** o teste mínimo abaixo, na ordem, anotando o que falhar:
- [ ] Comparar com os prints "antes" em celular (pequeno e grande) e computador.
- [ ] Rodar o teste mínimo completo (seção 3), incluindo pagamento e impressão.
- [ ] Testar com e sem internet (modo de contingência) e após limpar o cache do app instalado.
- [ ] Gerar o zip final atualizado e anotar o que mudou.

---

## 5. Ordem e esforço estimado

| Fase | O que entrega | Risco | Esforço |
|------|---------------|-------|---------|
| 0 | Backup e lista de teste | Baixo | Pequeno |
| 1 | Variáveis | Baixo | Pequeno |
| 2 | Botões/campos/etiquetas iguais | Médio (visual muda em todo lugar) | Médio |
| 3 | Janelas e mensagens próprias | **Alto** (muda o fluxo do código) | **Grande** |
| 4 | Menos `style=""` | Baixo/Médio | Médio |
| 5 | CSS consolidado | Médio | Médio |
| 6 | Menu, leitura, ícones, estados | Médio | Médio/Grande |
| 7 | Conferência | — | Pequeno |

Sugestão de entrega: **Fases 1+2 juntas** (já dá a sensação de "um só estilo"), depois **Fase 3** em lotes por arquivo, depois 4–6.

## 6. Riscos e cuidados

- **Cache do celular:** esquecer o `?v=`/`sw.js` faz parecer que nada mudou.
- **`confirm()` → janela própria** é a troca mais delicada; fazer por arquivo e testar a ação (excluir, cancelar venda, fechar caixa, restaurar backup).
- **Pagamento (Mercado Pago):** mexer só na aparência; não alterar ids nem fluxo.
- **Telas de equipe vs. cliente:** o cardápio do cliente usa o mesmo tema; mudanças nos botões base afetam os dois — conferir ambos.
- **Backup e restauração:** telas de backup/restaurar (`app-10`) têm vários `confirm()` — manter a mesma clareza do aviso ao trocar.

## 7. Critérios de aceite (checklist final)

- [ ] Mesmo botão primário/secundário/perigo em todas as telas.
- [ ] Mesma fonte e escala de letras em equipe, cardápio, conta e pagamento.
- [ ] 1 verde, 1 vermelho, 1 amarelo de status em todo o sistema.
- [ ] 3 raios de canto no máximo.
- [ ] Sem `alert/confirm/prompt` nativos nas telas de uso comum.
- [ ] Alvos de toque ≥ 44px no celular; letras ≥ 12px.
- [ ] Contraste de texto ≥ 4.5:1.
- [ ] Administrador agrupado por assunto.
- [ ] Teste mínimo passando e zip final gerado.
