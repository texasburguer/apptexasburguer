# Fase 6 — Usabilidade (navegação e leitura) — relatório

Feito (sw v46):
- Administrador: 6 grupos mantidos, agora com ícone SVG (celular e menu lateral do computador).
- Menu de baixo: Início, Caixa, Pedidos, Ganhos + Mais; aviso do "Mais" maior e pulsando.
- Letras: mínimo de 12px em todo o sistema (impressão fora do escopo); rótulos de formulário 13px.
- Contraste: vermelho escuro só como fundo; dourado apagado nos textos com 5:1 ou mais.
- Ícones: 97 botões e títulos fixos do index.html trocados de emoji para SVG (mesmo traço do menu de baixo).
- Carregando / vazio / erro: `esqueletoLista_`, `estadoVazio_`, `estadoErro_` (app-29) e visual novo do `.notif-empty`; esqueleto aplicado nas telas de integrações (Contas e acessos).
- Tabelas no celular: Vendas, Despesas e Sessões viram cartões; as outras ganham sombra de rolagem lateral.
- Formulários: rótulos 13px; botão principal da janela fica fixo no fim.

Fica para depois (não mexi): emojis dentro de HTML gerado pelos app-*.js; usar `estadoVazio_` com botão nas listas vazias de Clientes/Produtos/Estoque.
