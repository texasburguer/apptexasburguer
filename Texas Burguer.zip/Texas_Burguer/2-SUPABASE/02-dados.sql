-- =====================================================================
-- TEXAS BURGER · 02-dados.sql  (cópia do Supabase em 18/10/2026)
-- Dados de todas as tabelas (menos auditoria, logs, caches e segredos) + logins (auth.users / auth.identities) + contadores.
-- Rode DEPOIS do 01-estrutura.sql. Gatilhos e chaves estrangeiras ficam desligados durante a carga (replica).
-- As vendas até 16/10/2026 são de TESTE (uso real a partir de 17/10/2026).
-- =====================================================================
set session_replication_role = replica;

--
-- PostgreSQL database dump
--


-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: postgres
--

INSERT INTO auth.identities (id, provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at) VALUES
	('3c5eba96-bc7c-4deb-95c0-d2bd48111d6b', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', '{"sub": "98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1", "email": "jonatan@usuarios.texasburger.app", "email_verified": true, "phone_verified": false}', 'email', '2026-10-03 17:03:53.449332+00', '2026-10-03 17:03:53.449332+00', '2026-10-03 17:03:53.449332+00'),
	('c79c6230-1200-4c89-a7d9-dd52a2e3e65a', 'a7fb2364-a458-439d-b92d-e7e9933bfba5', 'a7fb2364-a458-439d-b92d-e7e9933bfba5', '{"sub": "a7fb2364-a458-439d-b92d-e7e9933bfba5", "email": "caixa@usuarios.texasburger.app", "email_verified": true, "phone_verified": false}', 'email', '2026-10-03 17:03:53.449332+00', '2026-10-03 17:03:53.449332+00', '2026-10-03 17:03:53.449332+00'),
	('84c7139d-1b1b-4ad2-848e-7865bafd3b6f', '6d7fc99c-2ef1-4a53-b9eb-7bf3904573af', '6d7fc99c-2ef1-4a53-b9eb-7bf3904573af', '{"sub": "6d7fc99c-2ef1-4a53-b9eb-7bf3904573af", "email": "garcom@usuarios.texasburger.app", "email_verified": true, "phone_verified": false}', 'email', '2026-10-03 17:03:53.449332+00', '2026-10-03 17:03:53.449332+00', '2026-10-03 17:03:53.449332+00'),
	('5d2ceb76-182d-4bff-aed1-035626a0daea', 'a1c0b864-b517-4c9e-995c-42394e88fe93', 'a1c0b864-b517-4c9e-995c-42394e88fe93', '{"sub": "a1c0b864-b517-4c9e-995c-42394e88fe93", "email": "cozinha@usuarios.texasburger.app", "email_verified": true, "phone_verified": false}', 'email', '2026-10-03 17:03:53.449332+00', '2026-10-03 17:03:53.449332+00', '2026-10-03 17:03:53.449332+00'),
	('6329a6fb-d7e1-4775-abfd-33c1d24b6780', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '{"sub": "8e442ee3-af30-4da0-ae6c-0312d2ba9223", "email": "entregador@usuarios.texasburger.app", "email_verified": true, "phone_verified": false}', 'email', '2026-10-03 17:03:53.449332+00', '2026-10-03 17:03:53.449332+00', '2026-10-03 17:03:53.449332+00'),
	('9571a325-2fce-4173-8eff-d396d9aba053', '9866c7ad-b231-458d-aed3-34daa4d28268', '9866c7ad-b231-458d-aed3-34daa4d28268', '{"sub": "9866c7ad-b231-458d-aed3-34daa4d28268", "email": "lucas@usuarios.texasburger.app", "email_verified": true, "phone_verified": false}', 'email', '2026-10-04 22:57:55.168608+00', '2026-10-04 22:57:55.168608+00', '2026-10-04 22:57:55.168608+00'),
	('c216946a-5412-445a-9b68-fc3de4f661e4', '102969556962029107643', 'f6020864-6292-4584-979e-4f63db3b1560', '{"iss": "https://accounts.google.com", "sub": "102969556962029107643", "name": "Lucas Ricardo", "email": "lucassricardo95@gmail.com", "picture": "https://lh3.googleusercontent.com/a/ACg8ocIVbDwSnfmJDltHolRg2In30O9jiEOKtwfxU1qhlrUl_t_mofc=s96-c", "full_name": "Lucas Ricardo", "avatar_url": "https://lh3.googleusercontent.com/a/ACg8ocIVbDwSnfmJDltHolRg2In30O9jiEOKtwfxU1qhlrUl_t_mofc=s96-c", "provider_id": "102969556962029107643", "email_verified": true, "phone_verified": false}', 'google', '2026-10-12 01:48:27.953824+00', '2026-10-12 01:48:27.953881+00', '2026-10-12 01:51:58.37876+00');


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: postgres
--

INSERT INTO auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at, last_sign_in_at, phone, is_anonymous, banned_until, deleted_at, is_sso_user) VALUES
	('00000000-0000-0000-0000-000000000000', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'authenticated', 'authenticated', 'jonatan@usuarios.texasburger.app', '$2a$06$AO6DJV2vwevXxEPar8H94errqXYFtm2eE9UjLfcBqVHPAplVasHFa', '2026-10-03 17:03:53.449332+00', '{"provider": "email", "providers": ["email"]}', '{}', '2026-10-03 17:03:53.449332+00', '2026-10-18 02:33:32.868031+00', '2026-10-17 22:54:16.935555+00', NULL, false, NULL, NULL, false),
	('00000000-0000-0000-0000-000000000000', '6d7fc99c-2ef1-4a53-b9eb-7bf3904573af', 'authenticated', 'authenticated', 'garcom@usuarios.texasburger.app', '$2a$06$o0zsFRhZcb.pqgMOkF.lmONqO64U79I7AU6UfSyE.RIDWatXrsXYa', '2026-10-03 17:03:53.449332+00', '{"provider": "email", "providers": ["email"]}', '{}', '2026-10-03 17:03:53.449332+00', '2026-10-03 17:03:53.449332+00', NULL, NULL, false, NULL, NULL, false),
	('00000000-0000-0000-0000-000000000000', '9866c7ad-b231-458d-aed3-34daa4d28268', 'authenticated', 'authenticated', 'lucas@usuarios.texasburger.app', '$2a$06$8c6bENRKhaIN3rC0as6h5O.Lvye8NxA0FbuJVrgnIWS7qAyl4XUGS', '2026-10-04 22:57:55.168608+00', '{"provider": "email", "providers": ["email"]}', '{}', '2026-10-04 22:57:55.168608+00', '2026-10-18 03:17:56.079375+00', '2026-10-18 02:08:52.171322+00', NULL, false, NULL, NULL, false),
	('00000000-0000-0000-0000-000000000000', 'f6020864-6292-4584-979e-4f63db3b1560', 'authenticated', 'authenticated', 'lucassricardo95@gmail.com', NULL, '2026-10-12 01:48:27.961016+00', '{"provider": "google", "providers": ["google"]}', '{"iss": "https://accounts.google.com", "sub": "102969556962029107643", "name": "Lucas Ricardo", "email": "lucassricardo95@gmail.com", "picture": "https://lh3.googleusercontent.com/a/ACg8ocIVbDwSnfmJDltHolRg2In30O9jiEOKtwfxU1qhlrUl_t_mofc=s96-c", "full_name": "Lucas Ricardo", "avatar_url": "https://lh3.googleusercontent.com/a/ACg8ocIVbDwSnfmJDltHolRg2In30O9jiEOKtwfxU1qhlrUl_t_mofc=s96-c", "provider_id": "102969556962029107643", "email_verified": true, "phone_verified": false}', '2026-10-12 01:48:27.928393+00', '2026-10-18 02:04:35.033883+00', '2026-10-12 01:51:58.409668+00', NULL, false, NULL, NULL, false),
	('00000000-0000-0000-0000-000000000000', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 'authenticated', 'authenticated', 'entregador@usuarios.texasburger.app', '$2a$06$q/kLxaqNA74zseBBYo28jeJh3syIhC/Gfg9GxqDeyZTjhEgjJBxEK', '2026-10-03 17:03:53.449332+00', '{"provider": "email", "providers": ["email"]}', '{}', '2026-10-03 17:03:53.449332+00', '2026-10-11 11:01:53.709956+00', '2026-10-11 00:25:33.433484+00', NULL, false, NULL, NULL, false),
	('00000000-0000-0000-0000-000000000000', 'a1c0b864-b517-4c9e-995c-42394e88fe93', 'authenticated', 'authenticated', 'cozinha@usuarios.texasburger.app', '$2a$06$Nx0xkodde008AxiKki7P5uXHy9maawASwSbAbwPnNZ.LHPyHc3hTS', '2026-10-03 17:03:53.449332+00', '{"provider": "email", "providers": ["email"]}', '{}', '2026-10-03 17:03:53.449332+00', '2026-10-09 01:23:52.900368+00', '2026-10-08 22:13:54.829091+00', NULL, false, NULL, NULL, false),
	('00000000-0000-0000-0000-000000000000', 'a7fb2364-a458-439d-b92d-e7e9933bfba5', 'authenticated', 'authenticated', 'caixa@usuarios.texasburger.app', '$2a$06$Lo5P6nmXhPd0ey75rCQwrOBUzccDjQ7qsx5e2nsxoV028p5/ezyBK', '2026-10-03 17:03:53.449332+00', '{"provider": "email", "providers": ["email"]}', '{}', '2026-10-03 17:03:53.449332+00', '2026-10-07 23:07:17.401338+00', '2026-10-07 22:00:41.809472+00', NULL, false, NULL, NULL, false);


--
-- PostgreSQL database dump complete
--




--
-- PostgreSQL database dump
--


-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: estoque; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.estoque (id, ingrediente, quantidade, quantidade_minima, unidade, custo_unitario, status) VALUES
	('00ccbdd1-3e61-4e0c-b467-04abb8c9f9fc', 'Frango', 8.000, 3.000, 'kg', 18.0000, 'Ativo'),
	('0502d2f5-70c8-44f3-920b-ee10f22c8ef3', 'Coca Cola 1L', 0.000, 0.000, 'un', 8.0000, 'Ativo'),
	('0e3054a3-96c8-43dd-b2cc-3bf7ce8769ca', 'Pão de cachorro-quente', 30.000, 10.000, 'un', 2.5000, 'Ativo'),
	('102e626e-de6c-4354-8a68-108f3639a677', 'Picles', 30.000, 10.000, 'kg', 32.0000, 'Ativo'),
	('13f5cd01-df2c-402c-aa1d-d58c4b7340b5', 'Batata palha', 0.000, 0.000, 'kg', 18.0000, 'Ativo'),
	('18d885f8-2f6f-43db-b6ef-b3a5af5f6387', 'Cream Cheese', 1.000, 0.400, 'kg', 48.0000, 'Ativo'),
	('18ded61d-073a-4c0f-bea8-30b95b40cbdf', 'Rúcula', 0.000, 0.000, 'un', 8.0000, 'Ativo'),
	('22c85853-8043-4ea8-9ff7-39c7562c0102', 'Maionese Caseira', 15.000, 10.000, 'un', 0.7143, 'Ativo'),
	('29aa2b4d-ee2d-4f82-a8ea-96c1032f3a28', 'Cebola Crispy', 0.000, 0.000, 'kg', 28.0000, 'Ativo'),
	('2b9518fb-7248-48dc-a3fb-9d1553f2b058', 'Cebola Roxa', 0.000, 0.000, 'kg', 13.0000, 'Ativo'),
	('328dfe6e-8b6d-4b40-9d19-8439038f9647', 'Ketchup', 0.000, 0.000, 'un', 0.2500, 'Ativo'),
	('32e9ad52-3c43-4b4a-985b-48e9762a59fd', 'Mostarda com mel', 0.000, 0.000, 'un', 18.0000, 'Ativo'),
	('435cdc1d-1800-4d38-84ad-3ba22fc809eb', 'Coca Cola 2L', 0.000, 0.000, 'un', 10.0000, 'Ativo'),
	('46354a04-75b6-47f8-8044-6395ff26e2fd', 'Cebola Caramelizada', -0.030, 0.000, 'kg', 39.0000, 'Ativo'),
	('4d1aed3a-dd06-4519-bbf4-db2c174db59a', 'Coca Cola Zero 1L', 0.000, 0.000, 'un', 8.0000, 'Ativo'),
	('4dae510c-cc28-483d-80c8-32d2592f4d9f', 'Anel de Cebola', 0.000, 0.000, 'kg', 18.0000, 'Ativo'),
	('52c73474-5488-4404-8887-65a706905f3e', 'Coca Cola Zero Lata 350ml', 0.000, 0.000, 'un', 3.2000, 'Ativo'),
	('53b91edb-66fa-4b11-a1c5-674a78d08750', 'Brócolis', 0.000, 0.000, 'kg', 18.0000, 'Ativo'),
	('5b3f3d17-4928-445f-8150-6a8ab3e45c94', 'Molho da casa', 0.000, 0.000, 'un', 1.0000, 'Ativo'),
	('5f964547-cf55-411a-8ba7-b4b2585e0c32', 'Carne para Hamburguer', 5.920, 1.000, 'kg', 38.0000, 'Ativo'),
	('60186adc-05ed-4ade-8165-634077433346', 'Pão com gergelim', 0.000, 0.000, 'un', 2.5000, 'Ativo'),
	('60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 'Bacon', 0.000, 0.000, 'kg', 32.0000, 'Ativo'),
	('774de063-d27a-44b3-9600-62929ab39a51', 'Pão', 0.000, 0.000, 'un', 2.5000, 'Ativo'),
	('826e891d-c682-427a-a7c6-d53c14f06ece', 'Molho Barbecue', 0.000, 0.000, 'l', 34.0000, 'Ativo'),
	('8c352f67-b128-4eb6-b112-38ea50440b03', 'Catupiry', 1.000, 0.400, 'kg', 49.0000, 'Ativo'),
	('95f24215-1057-4ca2-97ed-f9e2aadc60f4', 'Geleia de Pimenta', 0.000, 0.000, 'kg', 41.0000, 'Ativo'),
	('a00860db-8d18-4c79-af74-783b3025f6d3', 'Coca Cola Zero 2L', 0.000, 0.000, 'un', 10.0000, 'Ativo'),
	('a0571d1c-21ff-49ac-a040-cbe78dc15944', 'Salsicha', 0.000, 0.000, 'un', 1.0000, 'Ativo'),
	('a193d8e1-f087-49a5-b078-e5fa4990aedc', 'Presunto', 0.000, 0.000, 'kg', 18.0000, 'Ativo'),
	('aa6bd6a9-6065-43c2-8a57-406616c6edf0', 'Pão Brioche', -1.000, 0.000, 'un', 2.5000, 'Ativo'),
	('b3a46cc2-6b6c-4304-bfac-52e2c3e1de79', 'Frango crocante', 0.000, 0.000, 'kg', 18.0000, 'Ativo'),
	('b6855458-ccb8-4799-b714-cf7a0e77a894', 'Cebola', 0.000, 0.000, 'kg', 6.0000, 'Ativo'),
	('b8511ba5-b6ff-43ec-adc8-1cee823ac124', 'Batata frita', 0.000, 0.000, 'kg', 23.0000, 'Ativo'),
	('bfaa5579-33fc-4327-85d8-7a76f7ebeb5b', 'Ovo', 0.000, 0.000, 'un', 0.6000, 'Ativo'),
	('c2c6531b-dc84-41d1-a45c-259c979c7cd9', 'Maionese', 0.000, 0.000, 'un', 0.2500, 'Ativo'),
	('ce47359c-271c-4d58-a9e1-018a38340282', 'Batata', 0.000, 0.000, 'kg', 6.0000, 'Ativo'),
	('d146b503-920a-4b79-9814-521148ed2d8c', 'Milho', 0.000, 0.000, 'un', 3.5000, 'Ativo'),
	('d5b72b65-a2c0-43cb-a59c-4bb3bb79035a', 'Cheddar cremoso', 0.960, 0.400, 'kg', 62.0000, 'Ativo'),
	('d5f83abb-06fc-4c50-aae2-c54c9b3eea35', 'Alface', 0.000, 0.000, 'un', 8.0000, 'Ativo'),
	('d77e9f66-dc34-4636-ab5d-96fbb51b21fa', 'Coca Cola Lata 350ml', 0.000, 0.000, 'un', 3.2000, 'Ativo'),
	('e0e0d601-c3d4-4276-9799-aa54eca3d07e', 'Hambúrguer de Costela', 0.000, 0.000, 'kg', 36.6700, 'Ativo'),
	('e8d06141-538b-4bc0-a08c-ec3f40048387', 'Creme de leite', 0.000, 0.000, 'un', 2.0000, 'Ativo'),
	('eb106229-8c07-465b-9129-24cadf4c7c00', 'Queijo Mussarela', 0.000, 0.000, 'kg', 41.0000, 'Ativo'),
	('f39adc02-af43-46eb-b2b5-50c14c2558cf', 'Hambúrguer de Picanha', 0.000, 0.000, 'kg', 36.6700, 'Ativo'),
	('f43cc40f-3a3b-40a3-b253-adf393569879', 'Tomate', 0.000, 0.000, 'kg', 10.9000, 'Ativo'),
	('f5be099f-f6d4-4cc2-a203-b98c8eff04ae', 'Linguiça', 0.000, 0.000, 'kg', 22.0000, 'Ativo'),
	('fb24c49d-a4a4-4d4a-9446-1969b8440ebc', 'Carne Contra Filé', 0.000, 0.000, 'kg', 60.0000, 'Ativo');


--
-- Data for Name: adicionais; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.adicionais (id, nome, preco, ativo, ingrediente_id, quantidade_descontar) VALUES
	('081a3274-b818-4fe1-908a-32a8f752e302', 'Cheddar', 8.00, true, 'd5b72b65-a2c0-43cb-a59c-4bb3bb79035a', 0.100),
	('1d9cc231-ec6a-4425-9571-1da72ea37d0b', 'Hambúrguer (150g)', 7.00, true, '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.150),
	('375fb3e2-36f3-47be-9d78-7d0d11882a35', 'Frango', 7.00, true, '00ccbdd1-3e61-4e0c-b467-04abb8c9f9fc', 0.200),
	('527e67ca-6eca-4b95-ba76-7fa0dd557594', 'Ovo', 2.00, true, 'bfaa5579-33fc-4327-85d8-7a76f7ebeb5b', 1.000),
	('6861e324-b899-48fe-8854-a42e33113ecb', 'Queijo extra (mussarela)', 2.00, true, 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.030),
	('a526737c-cfd1-4169-a2fa-d9c62819fd16', 'Maionese Caseira', 2.00, true, '22c85853-8043-4ea8-9ff7-39c7562c0102', 1.000),
	('aeec0c9c-2f3c-4db0-9bce-b625018c7149', 'Bacon', 3.00, true, '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.100),
	('c06e9235-09d1-45d3-ad09-e347d8da6c75', 'Catupiry', 5.00, true, '8c352f67-b128-4eb6-b112-38ea50440b03', 0.100),
	('dc16b7c5-3a49-44a3-ada1-4caeddaf6f88', 'Cream Cheese', 5.00, true, '18d885f8-2f6f-43db-b6ef-b3a5af5f6387', 0.100);


--
-- Data for Name: ai_ajuda; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ai_ajuda (id, slug, titulo, palavras_chave, passos, perfis, ativo, atualizado_em, grupo, ordem, comuns) OVERRIDING SYSTEM VALUE VALUES
	(10, 'clientes-fidelidade', 'Cadastrar cliente e ver fidelidade', 'cliente cadastrar novo fidelidade cartão histórico indicação telefone', 'Clientes → “+ Novo cliente”: só nome e telefone são obrigatórios.
Toque no cliente para ver histórico, total gasto, indicação e cartão fidelidade.', '{Admin,Operador}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(11, 'internet-caiu', 'Internet caiu ou sistema fora do ar (contingência)', 'internet caiu sem conexão offline contingência plano b queda fora do ar', 'Venda no Caixa: se você já entrou neste aparelho, o sistema oferece guardar a venda na CONTINGÊNCIA (só retirada ou entrega, sem desconto, sem mesa). Ela entra no sistema sozinha quando o servidor voltar; estoque e total do caixa só atualizam depois.
Não confirme a venda de novo se ela já apareceu.
Fechar caixa, cancelar, pagar e lançar despesa exigem conexão e nunca ficam guardados: espere o 🟢 e refaça.
Se nem a contingência responder, anote a venda e lance depois.', '{Admin,Operador}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(12, 'caixa-fechado-erro', 'Aparece que o caixa está fechado', 'caixa fechado abra o caixa antes erro venda não registra', 'Venda, despesa, sangria e fechar conta de mesa exigem caixa aberto, e o Cardápio Digital para de receber pedidos.
Abra o caixa pela aba Caixa → “Abrir caixa”.', '{Admin,Operador}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(9, 'pedido-qr-mesa', 'Cliente pedindo pela mesa (QR Code)', 'qr code mesa cliente pedir celular chamar garçom pedir a conta aceitar', 'O cliente aponta a câmera para o QR da mesa, escolhe os itens e envia.
O pedido chega em Pedidos como “Recebido” (📱 Cliente). Toque em ✅ Aceitar para ir ao preparo, ou ❌ Rejeitar.
Se o cliente tocar em “Chamar garçom”, a mesa aparece em 🍽️ Mesas com 🔔; toque em ✔ Atendido quando for lá.
Se tocar em “Pedir a conta”, a mesa vira “Pediu a conta” e você fecha como sempre.
O pedido de mesa feito pelo cliente nunca vai ao preparo sem o aceite.', '{Admin,Operador}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(13, 'criar-usuario', 'Criar usuário, trocar senha ou editar acesso', 'usuário criar acesso login senha perfil garçom cozinha entregador operador desenvolvedor esqueci senha redefinir', 'Administrador → Sistema → Usuários e Permissões.
Em “Criar acesso”, preencha Login e Senha e escolha o perfil (Operador de caixa, Garçom, Cozinha, Entregador, Admin ou Desenvolvedor).
Digite “Sua senha de administrador” e toque em “Criar acesso”.
Para mudar nome, telefone, perfil, situação ou redefinir a senha de alguém, toque em “editar” na lista “Usuários cadastrados”. Tudo fica na Auditoria. No seu próprio acesso o perfil fica travado e a senha se troca em “🔑 Senha”.
Funcionário esqueceu a senha: só o Administrador troca. Entregador que não aparece na escolha: está inativo ou sem o perfil Entregador.', '{Admin}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(14, 'cadastrar-produto', 'Cadastrar produto e estoque', 'produto cadastrar cardápio preço custo margem estoque ingrediente ficha técnica categoria', 'Administrador → Catálogo → Produtos → “Cadastrar produto”.
Informe nome, categoria, preço e custo (a margem aparece sozinha). O preço vale para todas as formas de pagamento.
Só abra “⚙️ Opções avançadas” para preço diferente numa forma (ex.: iFood) ou para a ficha técnica (ingredientes).
Se o item tem estoque próprio (bebida, por exemplo), marque a opção e informe quantidade e mínimo.
Cada venda baixa o estoque pela ficha técnica. Ingrediente no mínimo gera aviso em Notificações, sem bloquear a venda.', '{Admin}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(15, 'qr-code-mesas', 'Imprimir ou renovar o QR Code das mesas', 'qr code mesas imprimir baixar png novo código', 'Administrador → Operação → Mesas e QR Codes → “📲 QR Codes das mesas”.
Escolha a mesa e toque em “🖨️ Imprimir esta mesa” (ou “Imprimir todas”). Também dá para “⬇️ Baixar PNG”.
Se alguém espalhar o QR, use “🔄 Gerar novo código” e imprima o QR novo daquela mesa.', '{Admin}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(16, 'cardapio-digital', 'Configurar o Cardápio Digital', 'cardápio digital cliente destaques ordem esgotado categorias observação', 'Administrador → Catálogo → Cardápio Digital: escolha o que aparece para o cliente, destaques, ordem e frase de abertura. “Mais Pedidos” é automático.
Item “Esgotado”: se “bloquear venda sem estoque” estiver ligado (Catálogo → Estoque), o cardápio mostra “Esgotado” no que o estoque não cobre mais.
O cliente pode escrever uma observação em cada item (ex.: “sem cebola”); ela aparece na comanda da cozinha.', '{Admin}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(17, 'entregadores-taxas', 'Taxa de entrega e fechamento de entregadores', 'entregador taxa ajuda diária fechamento pagar acerto entrega', 'Administrador → Operação → Entregadores e taxas.
Defina a taxa padrão e a ajuda diária e salve.
No fechamento, escolha entregador e data, confira o total (taxas + ajuda diária) e informe o valor pago.
Confirme. A diferença fica registrada e o período fechado não muda mais, mesmo que a taxa mude depois.
A ajuda diária conta uma vez por dia e só se houve entrega. Se a conexão cair ao fechar, confira o histórico antes de tentar de novo, para não fechar duas vezes.', '{Admin}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(18, 'ajustes-pos-venda', 'Ajuste pós-venda: reembolso, crédito, cortesia', 'ajuste pós-venda reembolso crédito cortesia desconto retroativo devolução', 'Administrador → Financeiro → Ajustes pós-venda.
Busque a venda (nº do pedido, nome ou telefone); só aparecem pedidos já entregues.
Escolha o tipo (Reembolso em dinheiro, Crédito para próxima compra, Cortesia ou Desconto retroativo), o valor e o motivo.
Em reembolso e desconto retroativo, escolha se o dinheiro sai do caixa (o caixa precisa estar aberto) ou fora dele (Pix, estorno no cartão).
Toque em “Registrar ajuste”. Para desfazer, use “cancelar” na lista, com o motivo.
A venda original não muda. Reembolso e desconto retroativo não passam do valor da venda.', '{Admin}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(19, 'financeiro-relatorios', 'Financeiro, relatórios e auditoria', 'financeiro contas a pagar despesas mensais dre relatório auditoria fluxo lucro histórico', 'Financeiro: contas a pagar, despesas mensais, previsto × pago, fluxo de 30 dias, metas. Formas de pagamento: Operação → Pagamentos. Histórico: resumo de hoje, vendas, despesas e sessões de caixa.
O DRE fica em Relatórios (com a linha “Ajustes pós-venda”). Só despesa paga entra no lucro.
Relatórios imprimem em A4, 80mm ou 58mm.
Auditoria: descontos, cancelamentos, preços, estoque, usuários, restaurações e acessos negados.', '{Admin}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(20, 'backup', 'Fazer backup e restaurar', 'backup restaurar copia drive armazenamento espaço automático', 'Administrador → Sistema → Backup → “Fazer backup agora”.
Ative o backup automático e escolha a frequência.
Para restaurar, escolha o backup no histórico e confirme com sua senha de administrador.
Confira o uso do Drive: até 70% normal, 70–90% atenção, acima de 90% crítico. Drive cheio pode fazer backups e fotos falharem.', '{Admin}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(84, 'err-entregador-04-esqueci-de-marcar-entregue', 'Esqueci de marcar "Entregue"', 'esqueci de marcar "entregue"', 'Avise o Caixa ou o Administrador: eles marcam manualmente pelo pedido.', '{Entregador}', true, '2026-10-09 10:18:49.28704+00', 'erro', 103, ''),
	(134, 'man-operador-11-modo-emergencia-planilha-fora-do-ar', 'Modo emergência (servidor fora do ar)', 'modo emergência (planilha fora do ar)', 'Só funciona no mesmo aparelho em que você já fez login normal nos últimos 30 dias.
Quando o sistema não conseguir falar com o servidor (Supabase), oferece "Entrar em MODO EMERGÊNCIA como [seu login]".
Dá para: registrar venda de retirada/entrega pela contingência.
Não dá para: abrir/fechar caixa, cancelar, receber pagamento, mexer em estoque, ver financeiro.
Quando o servidor voltar, o app avisa e pede login de novo.', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'lista', 11, ''),
	(29, 'man-admin-08-cliente-cancelou-o-pedido-cardapio', 'Cliente cancelou o pedido (Cardápio)', 'cliente cancelou o pedido (cardápio) admin', 'Nos primeiros 3 minutos, e só enquanto o pedido está “aguardando aceite”, o cliente pode cancelar sozinho pelo acompanhamento do pedido. O estoque volta e o motivo fica como “Cancelado pelo cliente (cardápio, até 3 min)”.
Depois de aceito, ou passados os 3 minutos, o cliente precisa ligar. Cancelar ou editar passa a ser com o Caixa/Administrador.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'lista', 50, ''),
	(30, 'man-admin-09-pedidos-e-entregas', 'Pedidos e entregas', 'pedidos e entregas admin', 'Pedido do Cardápio chega como “novo — aguardando aceite”: toque em “✅ Aceitar” ou “❌ Rejeitar”.
Quando o pedido ficar “Pronta” (retirada ou entrega) ou “Saiu para entrega”, e o cliente tiver telefone, toque em “📲 Avisar cliente”: abre o WhatsApp com a mensagem pronta e você só envia. Depois aparece “✔ avisado às…”.
Avance com “Marcar como…”: Em preparo → Pronta → Retirada (Servida, se for mesa).
Em Entregas, escolha o entregador no campo “Entregador” do pedido; ele avança até “Entregue”.
“⏸ Suspender” pausa o pedido (toque num motivo pronto, como "Cliente não atende", ou escreva). Recusar pedido também tem motivos prontos e “▶️ Retomar pedido” volta.
Venda “A Receber” só entra no caixa quando você toca em “marcar como recebido”.
Com só um entregador ativo, toda entrega já fica no nome dele. Com mais de um, escolha no campo "Entregador".
Depois de imprimir a comanda, fica um botão "🔁 Não saiu? Reimprimir" por 10 minutos; não precisa confirmar quando saiu certo.', '{Admin}', false, '2026-10-11 16:31:19.325087+00', 'secao', 51, 'Só dá para editar os itens com o pedido “Em preparo”.
Entregador esqueceu de marcar: marque você mesmo pelo botão do pedido.
Sem aviso de pedido novo: no Início, toque em “🔔 Ativar avisos” e “🔊 Testar som”. O aviso só chega com o app aberto e a tela ligada.'),
	(31, 'man-admin-10-entregas-taxas-e-fechamento-de-entregado', 'Entregas: taxas e fechamento de entregadores', 'entregas: taxas e fechamento de entregadores admin', 'Administrador → Operação → Entregadores e taxas.
Defina a taxa padrão e a ajuda diária e salve.
No fechamento, escolha entregador e data, confira o total (taxas + ajuda diária) e informe o valor pago.
Confirme. A diferença fica registrada e o período fechado não muda mais, mesmo que a taxa mude depois.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'secao', 52, 'A ajuda diária conta uma vez por dia e só se houve entrega.
Se a conexão cair ao fechar, confira o histórico antes de tentar de novo, para não fechar duas vezes.'),
	(32, 'man-admin-11-ocorrencias-e-notificacoes', 'Ocorrências e notificações', 'ocorrências e notificações admin', 'Ocorrências: Administrador → Painel → Ocorrências → “Tratar” para acompanhar e resolver. As abertas também aparecem no mural Notificações, onde o Caixa e o Administrador também têm o botão “Tratar”.
Administrador → Avisos (config): ligue ou desligue cada aviso e escolha quais perfis o recebem (Administrador, Operador ou Cozinha).', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'lista', 11, ''),
	(33, 'man-admin-12-financeiro-relatorios-e-auditoria', 'Financeiro, relatórios e auditoria', 'financeiro, relatórios e auditoria admin', 'Financeiro: contas a pagar, despesas mensais, previsto × pago, fluxo de 30 dias, metas. As formas de pagamento ficam em Operação → Pagamentos. Histórico: resumo de hoje, vendas, despesas e sessões de caixa. O DRE fica em Relatórios (com a linha “Ajustes pós-venda”). Só despesa paga entra no lucro.
Relatórios imprimem em A4, 80mm ou 58mm. Visão Geral e Relatórios atualizam ao abrir.
Auditoria: descontos, cancelamentos, preços, estoque, usuários, restaurações e acessos negados.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'lista', 53, ''),
	(34, 'man-admin-13-ajustes-pos-venda-reembolso-credito-cort', 'Ajustes pós-venda (reembolso, crédito, cortesia)', 'ajustes pós-venda (reembolso, crédito, cortesia) admin', 'Administrador → Financeiro → Ajustes pós-venda.
Busque a venda (nº do pedido, nome ou telefone) — só aparecem pedidos já entregues.
Escolha o tipo (Reembolso em dinheiro, Crédito para próxima compra, Cortesia ou Desconto retroativo), o valor e o motivo. Se o motivo for “Outro”, descreva.
Em reembolso e desconto retroativo, escolha se o dinheiro sai do caixa (o caixa precisa estar aberto) ou fora dele (Pix, estorno no cartão).
Toque em “Registrar ajuste”. Para desfazer, use “cancelar” na lista, com o motivo.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'secao', 13, 'A venda original NÃO muda e continua como Confirmada. No DRE o ajuste aparece na linha “Ajustes pós-venda”, separado das despesas.
Crédito não reduz o resultado na hora: quando o cliente usar, aplique como desconto no Caixa. Ele aparece como aviso abaixo do DRE.
Reembolso e desconto retroativo não passam do valor da venda (somando os ajustes já feitos nela).
Devolução que saiu do caixa de um turno já fechado não pode ser cancelada pelo sistema.'),
	(35, 'man-admin-14-backup-e-armazenamento', 'Backup e armazenamento', 'backup e armazenamento admin', 'Administrador → Sistema → Backup → “Fazer backup agora”.
Ative o backup automático e escolha a frequência.
Para restaurar, escolha o backup no histórico e confirme com sua senha de administrador.
Confira o uso do Drive: até 70% normal, 70–90% atenção, acima de 90% crítico.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'secao', 14, 'Drive cheio: backups e fotos podem falhar. Libere espaço.
A conferência de integridade aponta duplicidades, estoque negativo, caixa esquecido aberto e vendas paradas na contingência.'),
	(36, 'man-admin-15-contingencia-plano-b', 'Contingência (plano B)', 'contingência (plano b) admin', 'Administrador → Sistema → Sincronização e contingência → cartão “Contingência”. 🟢 = acessível (mostra quando o espelho foi atualizado e quantas vendas estão pendentes); 🔴 = não respondeu.
Toque em “🔄 Sincronizar espelho agora” para copiar produtos, preços e clientes para a contingência.
Toque uma vez em “Ativar sincronização automática diária (3h)”. Com ela ligada, o espelho se atualiza todo dia de madrugada e o sistema confere a cada 30 minutos se há vendas pendentes para trazer.
Se o Supabase ficou fora do ar e houve vendas na contingência, toque em “⬇️ Trazer vendas pendentes da contingência” e confirme.
Backups: cada backup (manual ou automático) também é copiado para o Drive da conta da contingência. No histórico de backups, a coluna “Cópia” mostra ✅ quando deu certo e ⚠️ quando falhou (o backup local continua valendo).
Fotos: ao sincronizar o espelho, as fotos do cardápio também ganham cópia na conta da contingência. Se a mensagem disser “faltam N”, toque em sincronizar de novo ou aguarde a sincronização das 3h.
Espaço: o cartão mostra quanto da conta da contingência está usado. Acima de 90% aparece um alerta em Notificações → Sistema; libere espaço nessa conta.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'secao', 54, 'Depois de trocar as chaves da contingência, peça a todos para sair e entrar de novo: a chave interna é buscada no login.
Troque as chaves só com a fila vazia (sem vendas pendentes), senão elas podem ficar presas.
Garçom, Cozinha e Entregador não usam a fila da contingência.'),
	(21, 'contingencia-admin', 'Contingência: sincronizar e trazer vendas pendentes', 'contingência sincronizar espelho vendas pendentes chaves planilha fora do ar', 'Administrador → Sistema → Sincronização e contingência → cartão “Contingência”. 🟢 = acessível; 🔴 = não respondeu.
Toque em “🔄 Sincronizar espelho agora” para copiar produtos, preços e clientes para a contingência.
Toque uma vez em “Ativar sincronização automática diária (3h)”.
Se o Supabase ficou fora do ar e houve vendas na contingência, toque em “⬇️ Trazer vendas pendentes da contingência” e confirme.
Depois de trocar as chaves da contingência, peça a todos para sair e entrar de novo, e troque as chaves só com a fila vazia.', '{Admin}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(22, 'man-admin-01-entrar-sair-e-status', 'Entrar, sair e status', 'entrar, sair e status, “login ou senha incorretos”, “sua sessão expirou”, “muitas tentativas erradas”', 'Digite Login e Senha e toque em “Entrar”.
Olhe o status no topo: 🟢 Online = tudo certo · 🟡 Sincronizando = aguarde · 🔴 Sem conexão = veja “E se der errado?” · 🟠 Contingência = o servidor está lento ou fora do ar e o app usa a reserva. Toque na bolinha colorida do topo para ver o estado do Supabase, da planilha principal e da contingência.
Para sair, toque em “Sair” no topo. Para trocar a sua senha, toque em “🔑 Senha” (precisa da senha atual e de ao menos 8 caracteres).
Suas abas: Início, Caixa, Pedidos (com Retiradas, Entregas e Mesas), Clientes e Administrador. Os avisos ficam no botão ✨ Assistente, na aba 🔔 Avisos. Um ponto dourado numa aba avisa que há algo novo.', '{Admin}', true, '2026-10-09 10:20:30.45071+00', 'secao', 1, '“Login ou senha incorretos”: confira os dados. Se esqueceu a senha, só o Administrador pode redefinir.
“Sua sessão expirou”: entre de novo; o que você estava digitando pode se perder.
“Muitas tentativas erradas”: depois de 5 erros o login fica bloqueado por 10 minutos, contados a partir do primeiro erro. Espere e tente de novo, sem insistir.'),
	(23, 'man-admin-02-onde-fica-cada-coisa', 'Onde fica cada coisa', 'onde fica cada coisa', 'A aba Administrador tem uma barra dividida em 6 grupos: Hoje (Visão Geral, Ocorrências, Feedbacks); Dinheiro (Contas a pagar e despesas, Histórico, Reembolsos e ajustes, Previsto e metas, Relatórios e DRE); Produtos (Produtos, combos e adicionais, Estoque, Compras e fornecedores, Custos e precificação); Vendas e cardápio (Cardápio Digital, Formas de pagamento, Promoções e cupons, Eventos); Loja e equipe (Mesas e QR Codes, Entregadores e taxas, Usuários e permissões, Configurar avisos); Sistema (Integrações e contas, Backup e espaço, Sincronização e contingência, Auditoria).
Ao entrar, escolha a tela no menu. O campo "Ir para…" no topo do menu acha uma tela pelo nome (ex.: cupom, estoque, iFood).
Caixa, Pedidos, Entregas e Clientes funcionam como nos outros perfis, e você pode tudo.', '{Admin}', true, '2026-10-16 21:46:37.03337+00', 'lista', 2, ''),
	(24, 'man-admin-03-criar-usuario-e-trocar-senha', 'Criar usuário e trocar senha', 'criar usuário e trocar senha, entregador não aparece na escolha de ent, funcionário esqueceu a senha, você esqueceu a sua', 'Administrador → Loja e equipe → Usuários e permissões.
Em "Criar acesso", preencha Login e Senha e escolha o perfil (Operador, Garçom, Cozinha, Entregador, Admin ou Desenvolvedor).
Digite "Sua senha de administrador" e toque em "Criar acesso".
Perfil Desenvolvedor: você cria como qualquer outro, mas depois de criado fica travado — só o próprio Desenvolvedor edita ou troca a senha. Nem você nem ele excluem esse acesso.
Para mudar nome, telefone, perfil, situação ou redefinir a senha de alguém, toque em "editar" na lista "Usuários cadastrados". Mudar perfil, situação ou senha, e também ativar, desativar ou excluir, pede a SUA senha de administrador (conferida de verdade). No seu próprio acesso o perfil fica travado e a senha se troca em "🔑 Senha".', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'secao', 3, 'Entregador não aparece na escolha de entregas: usuário inativo ou sem o perfil Entregador.
Funcionário esqueceu a senha: só você troca — não existe "esqueci minha senha".
Você esqueceu a sua: rode redefinirSenhaAdminEmergencia no editor do Apps Script.'),
	(25, 'man-admin-04-cadastrar-produtos-e-estoque', 'Cadastrar produtos e estoque', 'cadastrar produto novo produto receita ficha técnica ingrediente custo margem preparado aqui comprado pronto sem controle bebida estoque próprio copiar receita criar ingrediente gramas kg litro ml preços em lote paguei cadastro incompleto combo custo automático', 'Administrador → Produtos → Produtos, combos e adicionais → "+ Novo produto". Preencha nome, categoria, preço de venda e, se quiser, foto e descrição.
Em "Como é feito?" escolha: 🍳 Preparado aqui (lanches, porções), 🥤 Comprado pronto (bebidas, sobremesa embalada) ou ✍️ Sem controle.
Preparado aqui: digite o ingrediente, toque nele e diga quanto vai em cada um (kg/litro pedem gramas/ml). Não existe? Toque em "+ criar" ali mesmo. Use "📋 Copiar receita de outro produto" e só ajuste. O custo aparece sozinho.
Comprado pronto: "Paguei R$ __ por __ unidades" (ex.: 30 por 12 = R$ 2,50 por lata), quanto tem agora e o mínimo. Cada venda baixa 1 do estoque.
Sem controle: digite o custo se souber.
Em "⚙️ Mais opções": preço próprio do iFood, adicionais, destaque e prêmio.
Ingredientes: Produtos → Estoque → "+ Novo ingrediente" (nome, como compra, "Paguei R$ __ por __") ou "💲 Preços em lote" para vários de uma vez.
Produto novo já vem com os adicionais que os outros produtos da mesma categoria têm ("Comprado pronto", como bebida, vem sem nenhum). Desmarque o que não vale.', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'secao', 4, 'O custo dos produtos e combos se atualiza sozinho quando o preço de um ingrediente muda (edição, lote ou compra recebida); combo = soma dos produtos. Trocar kg↔g ou l↔ml converte as receitas; trocar "un"↔kg não converte e o sistema avisa quais receitas revisar. O Estoque tem as abas Ingredientes e Bebidas e itens prontos; bebidas não aparecem na receita. "Cadastro incompleto" mostra produtos sem custo e ingredientes sem preço. Cada venda baixa o estoque pela receita; ingrediente no mínimo gera aviso. Bebida e item comprado pronto não têm adicionais.'),
	(26, 'man-admin-05-qr-code-das-mesas', 'QR Code das mesas', 'qr code das mesas admin', 'Administrador → Operação → Mesas e QR Codes → "📲 QR Codes das mesas".
Escolha a mesa e toque em "🖨️ Imprimir esta mesa" (ou "Imprimir todas"). Também dá para "⬇️ Baixar PNG".
Plastifique e deixe na mesa. O cliente pede pelo celular e você aceita o pedido em Pedidos.
Se alguém espalhar o QR, use "🔄 Gerar novo código" e imprima o QR novo daquela mesa.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'secao', 5, 'O endereço do site está fixo nos QR: https://texasburguer.github.io/apptexasburguer/ — se mudar, é preciso imprimir de novo.'),
	(27, 'man-admin-06-cardapio-digital-promocoes-e-eventos', 'Cardápio Digital, promoções e eventos', 'cardápio digital, promoções e eventos admin', 'Cardápio Digital: escolha o que aparece para o cliente, destaques, ordem e frase de abertura. "Mais Pedidos" é automático.
Se o cliente pedir mais de 1 lanche com adicionais, os adicionais valem para todos — o cardápio avisa.
O cliente pode escrever uma observação em cada item; ela aparece na comanda da cozinha e no pedido.
Item "Esgotado": se "bloquear venda sem estoque" estiver ligado (Catálogo → Estoque), o cardápio mostra "Esgotado" no que o estoque não cobre.
O cardápio abre rápido porque guarda cópia no aparelho do cliente. Mudanças suas aparecem em instantes.
O cardápio só recebe pedidos com o caixa aberto; fechado, aparece "Estamos fechados no momento".
Promoções: cupons. Eventos: custos e recebimentos por evento. Custos e Precificação: simulador de preço.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'lista', 6, ''),
	(28, 'man-admin-07-caixa-abrir-vender-e-fechar', 'Caixa: abrir, vender e fechar', 'caixa: abrir, vender e fechar admin', 'Aba Caixa → "Abrir caixa" e informe o fundo de troco.
Em "Iniciar venda": 1. Cliente → 2. Itens → 3. Pagamento → 4. Finalizar.
Depois escolha 58mm, 80mm ou A4 e toque em Imprimir, Copiar ou WhatsApp.
Para encerrar, feche o caixa, informe o dinheiro contado e confira a diferença.
Mesas: o botão "🍽️ Mesas" mostra todas as mesas e quem pediu a conta.
Pedido de mesa no Caixa: "Pagar ao sair" deixa na conta; "Pagar agora" cobra na hora.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'secao', 7, '"Abra o caixa antes de registrar uma venda".
"A soma dos pagamentos precisa bater com o total".
Desconto nunca pode zerar a venda; no Caixa pede a sua senha.'),
	(1, 'abrir-caixa', 'Abrir o caixa', 'abrir caixa fundo de troco iniciar turno caixa fechado', 'Aba Caixa → “Abrir caixa”.
Informe o fundo de troco e confirme.
Sem caixa aberto não há venda, despesa nem sangria, e o Cardápio Digital não recebe pedidos.
Se aparecer “Já existe um caixa aberto”, feche o anterior (conte o dinheiro) antes de abrir outro.', '{Admin,Operador}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(2, 'fazer-venda', 'Fazer uma venda no Caixa', 'venda vender balcão retirada entrega mesa pedido pagamento dividir pagar troco finalizar imprimir a receber repetir', 'Abra o caixa antes, se ainda não estiver aberto.
1. Cliente: busque por nome ou telefone, ou toque em “Venda sem cadastro”. Escolha Retirada, Entrega (endereço, complemento, referência) ou Mesa.
2. Itens: toque nos produtos; os adicionais abrem numa janela.
3. Pagamento: escolha a forma. Em dinheiro, informe o valor recebido e veja o troco. Para dividir, marque “Dividir pagamento”. “A Receber” deixa a venda pendente.
4. Finalizar: confira o total e finalize. Escolha 58mm, 80mm ou A4 e toque em Imprimir, Copiar ou WhatsApp.
“↺ Repetir última venda” recarrega o carrinho anterior.
Erros comuns: “Abra o caixa antes de registrar uma venda” (abra o caixa); “A soma dos pagamentos precisa bater com o total” (ajuste os valores). Desconto nunca pode zerar a venda; o Operador precisa da senha do administrador para dar desconto.', '{Admin,Operador}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(3, 'fechar-caixa', 'Fechar o caixa', 'fechar caixa fechamento dinheiro contado diferença encerrar turno sair', 'Aba Caixa → fechar caixa.
Informe o dinheiro contado.
Confira o total por forma de pagamento, despesas, sangrias e a diferença; copie ou envie por WhatsApp.
Ao tocar em “Sair” com o caixa aberto, o sistema pergunta se você quer mesmo sair.', '{Admin,Operador}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(4, 'cancelar-editar-venda', 'Cancelar ou editar uma venda', 'cancelar venda excluir editar errei valor item lançamentos duplicado pedido duplicado estoque', 'Caixa → “Lançamentos desde a abertura”.
Toque em “editar” ou “excluir” na venda.
Cancelar pede o motivo (e a senha do administrador para o Operador). Se o pedido já estava pronto, diga se a mercadoria foi perdida ou volta ao estoque.
Itens de pedido só mudam enquanto ele está “Em preparo”.
Pedido duplicado: duplo toque não duplica (o sistema avisa que já foi registrado). Se o cliente pediu duas vezes de verdade, exclua um com o motivo “Pedido duplicado”.', '{Admin,Operador}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(5, 'despesa-sangria', 'Lançar despesa ou sangria', 'despesa sangria retirada dinheiro caixa gasto', 'Caixa → “+ Despesa” ou “− Sangria”.
Informe valor e motivo e confirme.
Sangria é retirada de dinheiro do caixa e não conta como despesa. As duas exigem caixa aberto.', '{Admin,Operador}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(6, 'fechar-conta-mesa', 'Fechar a conta de uma mesa', 'mesa conta fechar conta receber garçom pediu a conta aguardando fechamento dividir pagamento', 'O caixa precisa estar aberto.
Toque em “🍽️ Mesas” (topo do Caixa ou tela Início). Quem pediu a conta aparece primeiro, em destaque.
Em cada mesa você vê garçom, tempo, pedidos e total. “Ver pedidos” mostra o detalhe.
Toque em “💳 Fechar conta”, confira o total e escolha a forma de pagamento. Para dividir, marque “Dividir em duas formas” e informe o valor da primeira.
Erros comuns: “Abra o caixa antes de fechar a conta da mesa”; “A soma dos pagamentos não bate com a conta” (refaça com o total exato).', '{Admin,Operador}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(7, 'pedidos-aceitar-entregas', 'Aceitar pedidos, avançar status e atribuir entregador', 'pedido aceitar rejeitar cardápio status em preparo pronta entrega entregador avisar cliente whatsapp suspender retomar a receber recebido', 'Pedido do Cardápio chega como “novo — aguardando aceite”: toque em “✅ Aceitar” ou “❌ Rejeitar”.
Avance com “Marcar como…”: Em preparo → Pronta → Retirada (Servida, se for mesa).
Quando ficar “Pronta” ou “Saiu para entrega” e o cliente tiver telefone, toque em “📲 Avisar cliente” (abre o WhatsApp com a mensagem pronta).
Em Entregas, escolha o entregador no campo “Entregador” do pedido.
“⏸ Suspender” pausa o pedido (toque num motivo pronto, como "Cliente não atende", ou escreva). Recusar pedido também tem motivos prontos e “▶️ Retomar pedido” volta.
Venda “A Receber” só entra no caixa quando você toca em “marcar como recebido”.
Só dá para editar os itens com o pedido “Em preparo”. Se o entregador esqueceu de marcar, marque você pelo botão do pedido.
Com só um entregador ativo, toda entrega já fica no nome dele. Com mais de um, escolha no campo "Entregador".', '{Admin,Operador}', false, '2026-10-11 16:31:19.325087+00', 'secao', 0, ''),
	(8, 'cliente-cancelou-cardapio', 'Cliente cancelou o pedido feito pelo Cardápio', 'cliente cancelar pedido cardapio 3 minutos aguardando aceite', 'Nos primeiros 3 minutos, e só enquanto o pedido está “aguardando aceite”, o cliente cancela sozinho pelo acompanhamento do pedido. O estoque volta.
Depois de aceito, ou passados os 3 minutos, o cliente precisa ligar, e cancelar ou editar passa a ser com o Caixa/Administrador.', '{Admin,Operador}', false, '2026-10-07 23:36:19.985882+00', 'secao', 0, ''),
	(48, 'man-operador-08-editar-ou-cancelar-uma-venda', 'Editar ou cancelar uma venda', 'editar ou cancelar uma venda', 'Caixa → "Lançamentos desde a abertura".
Toque em "editar" ou "excluir".
Cancelar pede motivo e a senha do administrador. Se o pedido já estava pronto, diga se a mercadoria foi perdida ou volta ao estoque.', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'secao', 8, ''),
	(49, 'man-operador-09-despesa-e-sangria', 'Despesa e sangria', 'despesa e sangria, sangria é retirada de dinheiro do caixa ', 'Caixa → "+ Despesa" ou "− Sangria".
Informe valor e motivo e confirme.', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'secao', 9, 'Sangria é retirada de dinheiro do caixa e não conta como despesa.'),
	(50, 'man-operador-10-fechar-o-caixa', 'Fechar o caixa', 'fechar o caixa, ao tocar em "sair" com o caixa aberto, o', 'Caixa → fechar caixa.
Informe o dinheiro contado.
Confira o total por forma, despesas, sangrias e a diferença.', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'secao', 10, 'Ao tocar em "Sair" com o caixa aberto, o sistema pergunta se você quer mesmo sair.'),
	(51, 'man-operador-11-clientes-e-fidelidade', 'Clientes e fidelidade', 'clientes e fidelidade operador', 'Clientes → “+ Novo cliente”: só nome e telefone são obrigatórios.
Toque no cliente para ver histórico, total gasto, indicação e cartão fidelidade.', '{Operador}', false, '2026-10-09 10:20:59.387621+00', 'secao', 11, ''),
	(52, 'man-operador-12-registrar-um-problema-ocorrencia', 'Registrar um problema (Ocorrência)', 'registrar um problema (ocorrência) operador', 'No cartão do pedido, toque em “⚠️ Ocorrência”.
Escolha o tipo, descreva o que aconteceu e confirme.
Ela aparece no mural Notificações e o Administrador resolve.', '{Operador}', false, '2026-10-09 10:20:59.387621+00', 'secao', 12, ''),
	(120, 'man-garcom-10-registrar-um-problema-ocorrencia', 'Registrar um problema (Ocorrência)', 'registrar um problema (ocorrência) garcom', 'No cartão do pedido, toque em “⚠️ Ocorrência”.
Escolha o tipo, descreva o que aconteceu e confirme.
O Administrador e o Operador são avisados e resolvem.', '{Garçom}', false, '2026-10-09 10:20:59.387621+00', 'secao', 10, ''),
	(37, 'err-admin-01-a-internet-caiu', 'A internet caiu', 'a internet caiu', 'Venda no Caixa: se você já entrou neste aparelho, o sistema oferece guardar a venda na CONTINGÊNCIA (só retirada ou entrega, sem desconto, sem mesa). Ela entra sozinha quando voltar. Não confirme se já apareceu. Caixa, cancelamento, pagamentos e estoque exigem conexão e nunca ficam guardados. Clientes, feedbacks e ocorrências ficam salvos no aparelho.', '{Admin}', true, '2026-10-09 10:20:30.45071+00', 'erro', 100, ''),
	(38, 'err-admin-02-o-caixa-esta-fechado', 'O caixa está fechado', 'o caixa está fechado erro problema admin', 'Venda, despesa e sangria exigem caixa aberto, e o Cardápio Digital para de receber pedidos. Abra o caixa pela aba Caixa. Se aparecer “Já existe um caixa aberto”, feche o anterior (conte o dinheiro) antes de abrir outro.', '{Admin}', true, '2026-10-08 00:57:18.607627+00', 'erro', 105, ''),
	(39, 'err-admin-03-pedido-duplicado', 'Pedido duplicado', 'pedido duplicado erro problema admin', 'Duplo toque ou internet lenta não duplicam: o sistema reconhece a repetição e avisa que já foi registrado. Se o cliente fez dois pedidos de verdade, cancele um: Caixa → “Lançamentos desde a abertura” → excluir, com o motivo “Pedido duplicado”. Se já estava pronto, diga se a mercadoria foi perdida ou volta ao estoque.', '{Admin}', false, '2026-10-08 00:57:18.607627+00', 'erro', 102, ''),
	(40, 'err-admin-04-alguem-alterou-este-registro', '"Alguém alterou este registro"', '"alguém alterou este registro"', 'Outra pessoa editou o mesmo cadastro antes de você. O sistema recarrega os dados reais; confira e refaça a edição.', '{Admin}', true, '2026-10-09 10:20:30.45071+00', 'erro', 103, ''),
	(41, 'man-operador-01-entrar-sair-e-status', 'Entrar, sair e status', 'entrar, sair e status, “login ou senha incorretos”, “sua sessão expirou”, “muitas tentativas erradas”', 'Digite Login e Senha e toque em “Entrar”.
Olhe o status no topo: 🟢 Online = tudo certo · 🟡 Sincronizando = aguarde · 🔴 Sem conexão = veja “E se der errado?” · 🟠 Contingência = o servidor está lento ou fora do ar e o app usa a reserva. Toque na bolinha colorida do topo para ver o estado do Supabase, da planilha principal e da contingência.
Para sair, toque em “Sair” no topo. Para trocar a sua senha, toque em “🔑 Senha” (precisa da senha atual e de ao menos 8 caracteres).
Suas abas: Início, Caixa, Pedidos (com Retiradas, Entregas e Mesas), Clientes e Operação (Ocorrências e Feedbacks). Os avisos ficam no botão ✨ Assistente, na aba 🔔 Avisos. Um ponto dourado numa aba avisa que há algo novo.', '{Operador}', true, '2026-10-16 03:03:49.796886+00', 'secao', 1, '“Login ou senha incorretos”: confira os dados. Se esqueceu a senha, só o Administrador pode redefinir.
“Sua sessão expirou”: entre de novo; o que você estava digitando pode se perder.
“Muitas tentativas erradas”: depois de 5 erros o login fica bloqueado por 10 minutos, contados a partir do primeiro erro. Espere e tente de novo, sem insistir.'),
	(42, 'man-operador-02-abrir-o-caixa', 'Abrir o caixa', 'abrir o caixa, sem caixa aberto não há venda, despesa n, "já existe um caixa aberto"', 'Aba Caixa → "Abrir caixa".
Informe o fundo de troco e confirme.', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'secao', 2, 'Sem caixa aberto não há venda, despesa nem sangria, e o Cardápio Digital não recebe pedidos.
"Já existe um caixa aberto": feche o anterior antes.'),
	(43, 'man-operador-03-fazer-uma-venda', 'Fazer uma venda', 'fazer uma venda, "abra o caixa antes de registrar uma ven, "a soma dos pagamentos precisa bater com, desconto (% ou r$) pede a senha do admin', '1. Cliente: busque por nome ou telefone, ou "Venda sem cadastro". Escolha Retirada, Entrega ou Mesa.
2. Itens: toque nos produtos; adicionais abrem numa janela.
3. Pagamento e finalizar: escolha a forma. Em dinheiro, informe o recebido e veja o troco. Para dividir, marque "Dividir pagamento". Confira o total, escolha 58mm, 80mm ou A4 e toque em Imprimir, Copiar ou WhatsApp.
"↺ Repetir última venda" recarrega o carrinho anterior.
Se a forma de pagamento tem acréscimo (ex.: iFood), o Caixa mostra o valor a mais e já soma no total e no comprovante. Em pagamento dividido, o acréscimo vale só para a parte paga naquela forma.', '{Operador}', true, '2026-10-09 10:42:24.469108+00', 'secao', 3, '"Abra o caixa antes de registrar uma venda."
"A soma dos pagamentos precisa bater com o total".
Desconto (% ou R$) pede a senha do administrador.'),
	(44, 'man-operador-04-cliente-cancelou-o-pedido-cardapio', 'Cliente cancelou o pedido (Cardápio)', 'cliente cancelou o pedido (cardápio)', 'Nos primeiros 3 minutos, e só enquanto o pedido está "aguardando aceite", o cliente cancela sozinho. O estoque volta.
Depois de aceito, ou passados os 3 minutos, o cliente precisa ligar. Cancelar ou editar passa a ser com você ou o Admin.', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'lista', 4, ''),
	(45, 'man-operador-05-pedidos-e-entregas', 'Pedidos e entregas', 'pedidos e entregas, só dá para editar os itens com o pedido , o entregador esqueceu de marcar, sem aviso de pedido novo', 'Pedido do Cardápio chega como "novo — aguardando aceite": toque em "✅ Aceitar" ou "❌ Rejeitar".
Quando ficar "Pronta" (retirada ou entrega) ou "Saiu para entrega", e o cliente tiver telefone, toque em "📲 Avisar cliente".
Avance com "Marcar como…": Em preparo → Pronta → Retirada (Servida, se for mesa).
Em Entregas, escolha o entregador no campo "Entregador".
Venda "A Receber": quando o cliente pagar, toque em "marcar como recebido".
"⏸ Suspender" pausa o pedido (toque num motivo pronto, como "Cliente não atende", ou escreva). Recusar pedido também tem motivos prontos e "▶️ Retomar" volta.
Com só um entregador ativo, toda entrega já fica no nome dele. Com mais de um, escolha no campo "Entregador".
Depois de imprimir a comanda, fica um botão "🔁 Não saiu? Reimprimir" por 10 minutos; não precisa confirmar quando saiu certo.', '{Operador}', true, '2026-10-11 16:31:19.325087+00', 'secao', 5, 'Só dá para editar os itens com o pedido "Em preparo".
O entregador esqueceu de marcar: marque você pelo botão do pedido.
Sem aviso de pedido novo: no Início, toque em "🔔 Ativar avisos" e "🔊 Testar som".'),
	(46, 'man-operador-06-cliente-pedindo-pela-mesa-qr-code', 'Cliente pedindo pela mesa (QR Code)', 'cliente pedindo pela mesa (qr code), o cliente só cancela enquanto o pedido e, pedido de mesa pelo cliente nunca vai ao', 'O cliente aponta a câmera para o QR da mesa, escolhe os itens e envia.
O pedido chega em Pedidos como "Recebido" (📱 Cliente). Toque em ✅ Aceitar, ou ❌ Rejeitar.
Se o cliente tocar em "Chamar garçom", a mesa aparece em 🍽️ Mesas com 🔔 — toque em ✔ Atendido quando for lá.
Se tocar em "Pedir a conta", a mesa vira "Pediu a conta" e você fecha como sempre.', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'secao', 6, 'O cliente só cancela enquanto o pedido está "Recebido".
Pedido de mesa pelo cliente nunca vai ao preparo sem o aceite.'),
	(47, 'man-operador-07-fechar-a-conta-de-uma-mesa', 'Fechar a conta de uma mesa', 'fechar a conta de uma mesa, "abra o caixa antes de fechar a conta da, "a soma dos pagamentos não bate com a co', 'Quando o garçom pede a conta, a mesa fica "Aguardando fechamento".
Toque em "🍽️ Mesas". Quem pediu a conta aparece primeiro, com pontinho de aviso e som.
Em cada mesa: garçom, tempo, pedidos e total. "Ver pedidos" mostra o detalhe; "💳 Fechar conta" abre o pagamento.
Para dividir, marque "Dividir em duas formas" e informe o valor da primeira.
Se a forma escolhida tem acréscimo, ele é somado no fechamento e aparece no total a cobrar.', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'secao', 7, '"Abra o caixa antes de fechar a conta da mesa".
"A soma dos pagamentos não bate com a conta".'),
	(53, 'err-operador-01-a-internet-caiu', 'A internet caiu', 'a internet caiu', 'O botão de finalizar trava com "Sem conexão". Se você já entrou neste aparelho, o sistema oferece guardar a venda na CONTINGÊNCIA (só retirada ou entrega, sem desconto, sem mesa): ela entra sozinha quando voltar. Fechar caixa, cancelar, pagar e lançar despesa exigem conexão.', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'erro', 100, ''),
	(54, 'err-operador-02-o-caixa-esta-fechado', 'O caixa está fechado', 'o caixa está fechado erro problema operador', 'Abra o caixa (aba Caixa → “Abrir caixa”) antes de vender, lançar despesa ou sangria. Enquanto estiver fechado, o Cardápio Digital também não recebe pedidos.', '{Operador}', false, '2026-10-08 00:57:18.607627+00', 'erro', 101, ''),
	(55, 'err-operador-03-pedido-duplicado', 'Pedido duplicado', 'pedido duplicado erro problema operador', 'Duplo toque não duplica: o sistema avisa que a venda já foi registrada. Se o cliente pediu duas vezes, cancele um em “Lançamentos desde a abertura” → excluir, motivo “Pedido duplicado” (precisa da senha do administrador).', '{Operador}', false, '2026-10-08 00:57:18.607627+00', 'erro', 102, ''),
	(56, 'err-operador-04-errei-o-valor-ou-um-item', 'Errei o valor ou um item', 'errei o valor ou um item erro problema operador', 'Use “editar” em “Lançamentos desde a abertura”. Itens de pedido só mudam enquanto ele está “Em preparo”.', '{Operador}', false, '2026-10-08 00:57:18.607627+00', 'erro', 103, ''),
	(57, 'man-garcom-01-entrar-sair-e-status', 'Entrar, sair e status', 'entrar, sair e status, “login ou senha incorretos”, “sua sessão expirou”, “muitas tentativas erradas”', 'Digite Login e Senha e toque em “Entrar”.
Olhe o status no topo: 🟢 Online = tudo certo · 🟡 Sincronizando = aguarde · 🔴 Sem conexão = veja “E se der errado?” · 🟠 Contingência = o servidor está lento ou fora do ar e o app usa a reserva. Toque na bolinha colorida do topo para ver o estado do Supabase, da planilha principal e da contingência.
Para sair, toque em “Sair” no topo. Para trocar a sua senha, toque em “🔑 Senha” (precisa da senha atual e de ao menos 8 caracteres).
Suas abas: Início, Atendimento, Pedidos (com Retiradas, Entregas e Mesas) e Clientes. Um ponto dourado numa aba avisa que há algo novo.', '{Garçom}', true, '2026-10-09 10:19:05.884579+00', 'secao', 1, '“Login ou senha incorretos”: confira os dados. Se esqueceu a senha, só o Administrador pode redefinir.
“Sua sessão expirou”: entre de novo; o que você estava digitando pode se perder.
“Muitas tentativas erradas”: depois de 5 erros o login fica bloqueado por 10 minutos, contados a partir do primeiro erro. Espere e tente de novo, sem insistir.'),
	(58, 'man-garcom-02-lancar-pedido-de-uma-mesa', 'Lançar pedido de uma mesa', 'lançar pedido de uma mesa, abrir mesa, mesa não aceita novos itens, mesa de outro garçom', 'Aba Caixa → etapa "1. Cliente" → escolha a mesa. Se estiver Livre, toque em "Abrir mesa".
Vá em "2. Itens", toque nos itens e escolha os adicionais.
Toque em "Lançar na mesa (enviar à cozinha)". Repita quantas vezes o cliente pedir mais.', '{Garçom}', true, '2026-10-09 10:19:05.884579+00', 'secao', 2, '"A mesa N está … — não aceita novos itens": já está aguardando fechamento.
"Esta mesa está sob responsabilidade de outro garçom": a mesa é de quem a abriu; peça ao Caixa.
Você lança pedido de mesa, sem desconto e sem receber pagamento.'),
	(59, 'man-garcom-03-pedir-a-conta', 'Pedir a conta', 'pedir a conta, pedir fechamento de mesa', 'Caixa → escolha a mesa (ou toque em "🍽️ Mesas").
Toque em "Pedir fechamento" e confirme.
A mesa passa para "Aguardando fechamento". O Caixa recebe — ou você mesmo, com "💳 Receber conta".', '{Garçom}', true, '2026-10-09 10:19:05.884579+00', 'secao', 3, 'Só dá para pedir fechamento de mesa "Ocupada".'),
	(60, 'man-garcom-04-cliente-pedindo-pela-mesa-qr-code', 'Cliente pedindo pela mesa (QR Code)', 'cliente pedindo pela mesa, qr code, chamar garçom', 'O cliente pode pedir pelo celular. Quem aceita o pedido é o Caixa.
Se ele tocar em "Chamar garçom", a mesa aparece em 🍽️ Mesas com 🔔 e o aparelho avisa.
Depois de atender, toque em ✔ Atendido.', '{Garçom}', true, '2026-10-09 10:19:05.884579+00', 'secao', 4, 'Se a mesa pedir a conta, ela vira "Pediu a conta".'),
	(61, 'man-garcom-05-receber-a-conta-garcom', 'Receber a conta (garçom)', 'receber a conta, caixa fechado, mesa não é sua', 'Toque em "🍽️ Mesas" e ache a sua mesa.
Toque em "💳 Receber conta", confira o total e escolha a forma.
Para dividir, marque "Dividir em duas formas".
Confirme. A mesa fica livre e o valor entra no caixa.', '{Garçom}', true, '2026-10-09 10:19:05.884579+00', 'secao', 5, '"O caixa está fechado": peça ao caixa para abrir.
"Esta mesa não está sob a sua responsabilidade": só quem abriu a mesa recebe.'),
	(62, 'man-garcom-06-acompanhar-e-servir', 'Acompanhar e servir', 'acompanhar e servir, servida', 'Aba Pedidos: veja o andamento de cada pedido.
Quando estiver "Pronta", leve à mesa e toque em "Marcar como “Servida”".', '{Garçom}', true, '2026-10-09 10:26:30.365372+00', 'secao', 6, ''),
	(63, 'man-garcom-07-aviso-de-pedido-pronto', 'Aviso de pedido pronto', 'aviso de pedido pronto, som', 'Na primeira vez, toque em "🔔 Ativar avisos e som".
Quando um pedido das SUAS mesas ficar "Pronta", o aparelho toca, vibra e o título da aba mostra "Pedido pronto".
A checagem roda mesmo com o app em segundo plano.', '{Garçom}', true, '2026-10-09 10:19:05.884579+00', 'lista', 7, ''),
	(64, 'man-garcom-08-clientes', 'Clientes', 'clientes, novo cliente', 'Aba Clientes → "+ Novo cliente".
Só nome e telefone são obrigatórios.', '{Garçom}', true, '2026-10-09 10:19:05.884579+00', 'secao', 8, ''),
	(65, 'man-garcom-09-registrar-um-problema-ocorrencia', 'Registrar um problema (Ocorrência)', 'registrar um problema, ocorrência', 'No cartão do pedido, toque em “⚠️ Ocorrência”.
Escolha o tipo, descreva o que aconteceu e confirme.
O Administrador e o Operador são avisados e resolvem.', '{Garçom}', true, '2026-10-09 10:19:05.884579+00', 'secao', 9, ''),
	(66, 'err-garcom-01-a-internet-caiu', 'A internet caiu', 'a internet caiu', 'Você não tem fila de envio: se aparecer "Sem conexão — a mesa não foi aberta" (ou o fechamento não foi solicitado), nada foi gravado. Espere o 🟢, confira em Pedidos se o pedido já entrou e só então repita.', '{Garçom}', true, '2026-10-09 10:19:05.884579+00', 'erro', 100, ''),
	(67, 'err-garcom-02-o-caixa-esta-fechado', 'O caixa está fechado', 'o caixa está fechado', 'Quem abre e fecha o caixa é o Caixa. Se a conta da mesa não puder ser recebida, avise o responsável.', '{Garçom}', true, '2026-10-09 10:19:05.884579+00', 'erro', 101, ''),
	(68, 'err-garcom-03-pedido-duplicado-ou-item-errado', 'Pedido duplicado ou item errado', 'pedido duplicado ou item errado', 'Duplo toque não duplica. Se lançou item errado ou em dobro, peça ao Caixa para editar ou cancelar (itens só mudam com o pedido "Em preparo").', '{Garçom}', true, '2026-10-09 10:19:05.884579+00', 'erro', 102, ''),
	(82, 'err-entregador-02-o-cliente-nao-atende', 'O cliente não atende', 'o cliente não atende', 'Avise o Caixa: ele pode usar "⏸ Suspender" no pedido (com motivo) e retomar depois. Registre uma Ocorrência para ficar anotado.', '{Entregador}', true, '2026-10-09 10:18:49.28704+00', 'erro', 101, ''),
	(83, 'err-entregador-03-pedido-duplicado', 'Pedido duplicado', 'pedido duplicado', 'Se aparecerem dois cartões iguais, entregue só um e avise o Caixa, que cancela o repetido.', '{Entregador}', true, '2026-10-09 10:18:49.28704+00', 'erro', 102, ''),
	(69, 'man-cozinha-01-entrar-sair-e-status', 'Entrar, sair e status', 'entrar, sair e status, “login ou senha incorretos”, “sua sessão expirou”, “muitas tentativas erradas”', 'Digite Login e Senha e toque em “Entrar”.
Olhe o status no topo: 🟢 Online = tudo certo · 🟡 Sincronizando = aguarde · 🔴 Sem conexão = veja “E se der errado?” · 🟠 Contingência = o servidor está lento ou fora do ar e o app usa a reserva. Toque na bolinha colorida do topo para ver o estado do Supabase, da planilha principal e da contingência.
Para sair, toque em “Sair” no topo. Para trocar a sua senha, toque em “🔑 Senha” (precisa da senha atual e de ao menos 8 caracteres).
Suas abas: Início, Cozinha (os pedidos) e Notificações. Um ponto dourado numa aba avisa que há algo novo.', '{Cozinha}', true, '2026-10-09 10:17:28.988364+00', 'secao', 1, '“Login ou senha incorretos”: confira os dados. Se esqueceu a senha, só o Administrador pode redefinir.
“Sua sessão expirou”: entre de novo; o que você estava digitando pode se perder.
“Muitas tentativas erradas”: depois de 5 erros o login fica bloqueado por 10 minutos, contados a partir do primeiro erro. Espere e tente de novo, sem insistir.'),
	(70, 'man-cozinha-02-preparar-os-pedidos', 'Preparar os pedidos', 'preparar os pedidos, sem beep, o sistema mantém a tela ligada enquanto ', 'Aba Pedidos: três colunas (Novos, Em preparo, Prontos) com itens, adicionais e observações.
Observação do cliente em um item aparece em destaque com 📝 abaixo do item.
Para imprimir: "🖨️ Comanda" no pedido ou "🖨️ Imprimir novos". Marque "Imprimir sozinho quando chegar pedido" para imprimir automático (o navegador precisa estar em modo quiosque de impressão).
No Início, "🔊 Testar som" confere se o celular toca e "🔔 Ativar avisos" libera notificações.
Pedido novo chega com beep e piscada (o sistema confere a cada poucos segundos com o app aberto e online).
Toque em "▶️ Iniciar preparo" (no pedido do Cardápio: "Aceitar e iniciar preparo").
Terminou? Toque em "✅ Pronto".
No fim da tela, "📜 Concluídos neste turno" mostra o que já saiu (retirado, entregue ou servido), com o horário. A lista zera quando o caixa fecha.', '{Cozinha}', true, '2026-10-09 10:17:28.988364+00', 'secao', 2, 'Sem beep: toque em "🔊 Testar som" no Início, aumente o volume de mídia e tire o modo silencioso.
O sistema mantém a tela ligada enquanto o app está aberto. Se aparecer "⚠️ A tela NÃO está sendo mantida ligada", toque em "📱 Manter a tela ligada".'),
	(71, 'man-cozinha-03-registrar-um-problema-ocorrencia', 'Registrar um problema (Ocorrência)', 'registrar um problema (ocorrência) cozinha', 'No cartão do pedido, toque em “⚠️ Ocorrência”.
Escolha o tipo, descreva o que aconteceu e confirme.
O Administrador e o Caixa são avisados. Use para falta de ingrediente ou pedido que não pode ser produzido.', '{Cozinha}', false, '2026-10-09 10:20:59.387621+00', 'secao', 3, ''),
	(72, 'man-cozinha-04-notificacoes', 'Notificações', 'notificações cozinha', 'É o mural de avisos do dia a dia. Você só vê os que o Administrador liberou para a Cozinha.', '{Cozinha}', false, '2026-10-09 10:20:59.387621+00', 'lista', 4, ''),
	(73, 'err-cozinha-01-a-internet-caiu', 'A internet caiu', 'a internet caiu', 'O topo mostra "⚠️ Sem conexão com o servidor — tentando de novo em 3 min." Continue os pedidos já visíveis. Se tocar em "Iniciar preparo" e aparecer "Sem conexão — o preparo não foi registrado", repita quando voltar o 🟢.', '{Cozinha}', true, '2026-10-09 10:17:28.988364+00', 'erro', 100, ''),
	(74, 'err-cozinha-02-nao-chega-nenhum-pedido', 'Não chega nenhum pedido', 'não chega nenhum pedido', 'Confira o status no topo (🟢). Com o caixa fechado, o Cardápio Digital não recebe pedidos; avise o Caixa. Toque em "↻ Verificar agora".', '{Cozinha}', true, '2026-10-09 10:17:28.988364+00', 'erro', 101, ''),
	(75, 'err-cozinha-03-pedido-duplicado', 'Pedido duplicado', 'pedido duplicado', 'Se aparecerem dois iguais, faça só um e avise o Caixa para cancelar o repetido. Você também pode registrar uma Ocorrência no pedido.', '{Cozinha}', true, '2026-10-09 10:17:28.988364+00', 'erro', 102, ''),
	(76, 'man-entregador-01-entrar-sair-e-status', 'Entrar, sair e status', 'entrar, sair e status, “login ou senha incorretos”, “sua sessão expirou”, “muitas tentativas erradas”', 'Digite Login e Senha e toque em “Entrar”.
Olhe o status no topo: 🟢 Online = tudo certo · 🟡 Sincronizando = aguarde · 🔴 Sem conexão = veja “E se der errado?” · 🟠 Contingência = o servidor está lento ou fora do ar e o app usa a reserva. Toque na bolinha colorida do topo para ver o estado do Supabase, da planilha principal e da contingência.
Para sair, toque em “Sair” no topo. Para trocar a sua senha, toque em “🔑 Senha” (precisa da senha atual e de ao menos 8 caracteres).
Suas abas: Início, Minhas entregas e Meus ganhos. Um ponto dourado numa aba avisa que há algo novo.', '{Entregador}', true, '2026-10-09 10:18:49.28704+00', 'secao', 1, '“Login ou senha incorretos”: confira os dados. Se esqueceu a senha, só o Administrador pode redefinir.
“Sua sessão expirou”: entre de novo; o que você estava digitando pode se perder.
“Muitas tentativas erradas”: depois de 5 erros o login fica bloqueado por 10 minutos, contados a partir do primeiro erro. Espere e tente de novo, sem insistir.'),
	(77, 'man-entregador-02-fazer-uma-entrega', 'Fazer uma entrega', 'fazer uma entrega, não aparece nada, pedido "aguardando aceite"', 'Aba Minhas entregas: aparecem só as suas. Uma nova toca um aviso sonoro.
O cartão mostra itens, endereço, referência, telefone, total, taxa e "📍 Ver no Maps".
Quem marca o pedido como "Pronta" é a Cozinha. Quando pegar o pedido (status "Pronta"), toque em "Marcar como “Saiu para entrega”". Nesse momento o app começa a enviar sua localização.
Ao entregar, toque em "✅ Já entreguei". O envio de localização para sozinho.
Se o cartão diz "A receber", cobre o valor do cliente; quem registra o recebimento é o Caixa.', '{Entregador}', true, '2026-10-09 10:18:49.28704+00', 'secao', 2, 'Não aparece nada: ainda não atribuíram entrega a você. Avise o Caixa.
Pedido "aguardando aceite": o botão só aparece depois que o Caixa aceitar.'),
	(78, 'man-entregador-03-aviso-de-entrega-nova', 'Aviso de entrega nova', 'aviso de entrega nova', 'Na primeira vez, toque em "🔔 Ativar avisos e som" (canto da tela).
Quando o Caixa atribuir uma entrega, o aparelho toca, vibra e a aba mostra "Nova entrega".
A checagem roda com o app aberto, mesmo em segundo plano.', '{Entregador}', true, '2026-10-09 10:18:49.28704+00', 'lista', 3, ''),
	(79, 'man-entregador-04-meu-dia', 'Meu dia', 'meu dia entregador', 'Em Minhas entregas, “💰 Meu dia” mostra suas entregas de hoje, as taxas e a ajuda diária.
O total previsto é taxas + ajuda diária (uma vez por dia). O acerto oficial é feito pelo Administrador.', '{Entregador}', false, '2026-10-09 10:20:59.387621+00', 'lista', 4, ''),
	(80, 'man-entregador-05-registrar-um-problema-ocorrencia', 'Registrar um problema (Ocorrência)', 'registrar um problema (ocorrência) entregador', 'No cartão do pedido, toque em “⚠️ Ocorrência”.
Escolha o tipo, descreva o que aconteceu e confirme.
O Administrador é avisado. Use para cliente ausente, endereço errado ou problema na entrega.', '{Entregador}', false, '2026-10-09 10:20:59.387621+00', 'secao', 5, ''),
	(81, 'err-entregador-01-a-internet-caiu', 'A internet caiu', 'a internet caiu', 'O celular mostra o último estado salvo. Se o toque em "Saiu para entrega" ou "Já entreguei" falhar, confira o status no cartão e toque de novo quando voltar a conexão — o sistema não duplica.', '{Entregador}', true, '2026-10-09 10:18:49.28704+00', 'erro', 100, ''),
	(85, 'man-todos-90-balao', 'Usar o assistente (botão ✨ no canto da tela)', 'balao assistente ia ajuda perguntar texto como faco', 'Toque no balão 💬/✨ no canto inferior direito da tela.
Escreva o que precisa, em uma frase (ex.: “como abro o caixa?”). Não há botões de função: o sistema entende pelo texto.
A resposta vem do manual do seu perfil. Se não houver o passo, aparece “Não encontrei esse passo no manual do sistema.”
Perguntas financeiras só o Administrador consegue; para os demais perfis aparece o aviso fixo.
O balão não aparece na tela de login.
Dentro do assistente há duas abas: "✨ Conversa" e "🔔 Avisos". Em Avisos ficam os alertas que antes estavam em Notificações (pedidos aguardando, ocorrências, entregas, contas vencidas, falhas do sistema, estoque baixo, fidelidade, indicações, aniversariantes e clientes inativos). Toque num grupo para abrir.', '{Admin,Operador,Desenvolvedor}', true, '2026-10-09 10:21:12.959495+00', 'secao', 90, ''),
	(86, 'man-equipe-91-atendimento', 'Atender um cliente pelo balão', 'atendimento cliente chat assumir encerrar fila aguardando antes de pedir', 'Quando um cliente toca em “Falar com a equipe”, o balão mostra um contador e a linha “N clientes aguardando”.
Abra o balão, toque na linha e leia o resumo feito pela recepção automática (nome, telefone e pedido vinculado, ou “Pedido não localizado”).
Toque em “Assumir”, converse com o cliente e, ao terminar, toque em “Encerrar” e registre a solução.
Depois de encerrar, a mesma caixa de texto volta a responder suas perguntas normais.
“Antes de pedir” é cliente que ainda vai pedir: não gera ocorrência.
Abra o assistente na aba "✨ Conversa". A aba "🔔 Avisos" mostra os alertas do restaurante.', '{Admin,Operador}', true, '2026-10-09 10:21:12.959495+00', 'secao', 91, ''),
	(87, 'man-entregador-92-localizacao', 'Localização na entrega (GPS)', 'localizacao gps entrega mapa posicao permitir', 'Ao tocar em “Saiu para entrega”, permita a localização quando o celular perguntar.
Mantenha o app aberto na tela durante a entrega: o GPS só é enviado assim, a cada cerca de 18 segundos.
Ao marcar “Já entreguei”, o envio para e a posição é apagada.
Se negar o GPS, a entrega continua normal; só a equipe e o cliente deixam de ver a localização.', '{Entregador}', false, '2026-10-08 00:57:18.607627+00', 'secao', 92, ''),
	(88, 'man-caixa-93-ver-localizacao', 'Ver onde está o entregador', 'localizacao entregador mapa distancia ver onde esta', 'Em Pedidos → Entregas, nos pedidos “Saiu para entrega”, toque em “📍 Ver localização”.
A janela mostra há quanto tempo a posição foi atualizada e, se o cliente compartilhou o destino, a distância aproximada.
Toque em “Abrir no mapa” para ver o ponto no Google Maps.
Se aparecer “Posição indisponível”, o entregador está sem GPS ou com o app fechado.', '{Admin,Operador}', false, '2026-10-08 00:57:18.607627+00', 'secao', 93, ''),
	(91, 'man-cozinha-03-confirmar-impressao-da-comanda', 'Confirmar impressão da comanda', 'confirmar impressão da comanda', 'Depois de mandar imprimir, fica um botão discreto "🔁 Não saiu? Reimprimir" por 10 minutos. Se saiu certo, ninguém precisa confirmar nada.
🔁 Não saiu? Reimprimir: o sistema tira o pedido de "impressos" e manda de novo.
✖ Saiu, ocultar: esconde o botão.', '{Cozinha}', true, '2026-10-09 10:17:28.988364+00', 'lista', 3, ''),
	(92, 'man-cozinha-04-pedido-alterado-depois-de-impresso', 'Pedido alterado depois de impresso', 'pedido alterado depois de impresso', 'O aparelho guarda uma "foto" da comanda quando você imprime ou quando o pedido aparece na tela.
Se um Admin/Operador editar o pedido, a foto deixa de bater. O cartão ganha faixa vermelha "PEDIDO ALTERADO" e toca dois bipes uma vez.
Para resolver: "🖨️ Reimprimir comanda atualizada" ou "👍 Ciente".', '{Cozinha}', true, '2026-10-09 10:17:28.988364+00', 'lista', 4, ''),
	(93, 'man-cozinha-05-registrar-um-problema-ocorrencia', 'Registrar um problema (Ocorrência)', 'registrar um problema (ocorrência)', 'No cartão do pedido, toque em “⚠️ Ocorrência”.
Escolha o tipo, descreva o que aconteceu e confirme.
O Administrador e o Operador são avisados. Use para falta de ingrediente ou pedido que não pode ser produzido.', '{Cozinha}', true, '2026-10-09 10:17:28.988364+00', 'secao', 5, ''),
	(94, 'man-cozinha-06-notificacoes', 'Notificações', 'notificações', 'Mural de avisos. Você só vê os que o Administrador liberou para a Cozinha.', '{Cozinha}', true, '2026-10-09 10:17:28.988364+00', 'lista', 6, ''),
	(98, 'err-cozinha-04-nao-sei-se-a-comanda-saiu', 'Não sei se a comanda saiu', 'não sei se a comanda saiu', 'O botão "🔁 Não saiu? Reimprimir" fica visível por 10 minutos depois de imprimir. Se a comanda não saiu, toque nele. Se saiu certo, não precisa fazer nada.', '{Cozinha}', true, '2026-10-09 10:17:28.988364+00', 'erro', 103, ''),
	(102, 'man-entregador-04-localizacao-sua-privacidade', 'Localização (sua privacidade)', 'localização (sua privacidade)', 'O envio só liga quando você tem entrega em "Saiu para entrega" — não fica rodando o dia inteiro.
Não guarda histórico: a posição é atualizada em cima da anterior e o banco limpa ao sair do status.
Precisa do GPS permitido no navegador. Se negar, a entrega continua normal; só o mapa do restaurante fica sem sua posição.
Ao marcar "Já entreguei", o envio para automaticamente.', '{Entregador}', true, '2026-10-09 10:18:49.28704+00', 'lista', 4, ''),
	(103, 'man-entregador-05-meu-dia', 'Meu dia', 'meu dia', 'Em Minhas entregas, "💰 Meu dia" mostra suas entregas de hoje, as taxas e a ajuda diária.
O total previsto é taxas + ajuda diária (uma vez por dia). O acerto oficial é feito pelo Administrador.', '{Entregador}', true, '2026-10-09 10:18:49.28704+00', 'lista', 5, ''),
	(104, 'man-entregador-06-balao-de-atendimento', 'Balão de atendimento', 'balão de atendimento entregador', 'Toque no botão do canto para perguntar ao assistente.
Exemplos: "quantas entregas fiz hoje?", "como marco que saiu para entrega?".
Se houver cliente esperando atendimento, aparece um contador vermelho no botão.', '{Entregador}', false, '2026-10-09 10:20:59.387621+00', 'lista', 6, ''),
	(105, 'man-entregador-07-registrar-um-problema-ocorrencia', 'Registrar um problema (Ocorrência)', 'registrar um problema (ocorrência) entregador', 'No cartão do pedido, toque em “⚠️ Ocorrência”.
Escolha o tipo, descreva o que aconteceu e confirme.
O Administrador e o Operador são avisados. Use para cliente ausente, endereço errado ou problema na entrega.', '{Entregador}', false, '2026-10-09 10:20:59.387621+00', 'secao', 7, ''),
	(110, 'err-entregador-05-o-mapa-nao-mostra-minha-posicao', 'O mapa não mostra minha posição', 'o mapa não mostra minha posição', 'Confira se o GPS está ligado e se o navegador tem permissão de localização para o site.', '{Entregador}', true, '2026-10-09 10:18:49.28704+00', 'erro', 104, '');
INSERT INTO public.ai_ajuda (id, slug, titulo, palavras_chave, passos, perfis, ativo, atualizado_em, grupo, ordem, comuns) OVERRIDING SYSTEM VALUE VALUES
	(118, 'man-garcom-08-balao-de-atendimento', 'Balão de atendimento', 'balão de atendimento garcom', 'Toque no botão do canto para perguntar ao assistente.
Exemplos: "como abro uma mesa?", "como pedir a conta?", "tem cliente aguardando?".
Se houver cliente esperando, aparece um contador vermelho no botão.', '{Garçom}', false, '2026-10-09 10:20:59.387621+00', 'lista', 8, ''),
	(119, 'man-garcom-09-clientes', 'Clientes', 'clientes garcom', 'Aba Clientes → "+ Novo cliente".
Só nome e telefone são obrigatórios.', '{Garçom}', false, '2026-10-09 10:20:59.387621+00', 'secao', 9, ''),
	(135, 'man-operador-12-fila-de-envio', 'Fila de envio', 'fila de envio', 'Cadastro de cliente, fidelidade, feedback e ocorrência podem ficar guardados no aparelho quando a internet cai. Aparece "na fila" no topo.
Toque para ver estado, tentativas e motivo. Você pode tentar de novo, descartar ou enviar agora.
Venda, pagamento, sangria, cancelamento e estoque NUNCA ficam na fila.', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'lista', 12, ''),
	(136, 'man-operador-13-balao-de-atendimento', 'Balão de atendimento', 'balão de atendimento', 'O botão no canto é o assistente quando você está logado. Para o cliente ele é o atendente virtual (IA); quando o problema é com a equipe, o chamado chega aqui.
Escreva perguntas como: "como faço uma venda?", "quanto tem de pão no estoque?", "tem cliente aguardando?".
Se houver cliente esperando, o botão mostra um contador vermelho. Toque para ver a fila e assumir um atendimento.', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'lista', 13, ''),
	(137, 'man-operador-14-localizacao-do-entregador', 'Localização do entregador', 'localização do entregador', 'Em Entregas, quando o pedido estiver "Saiu para entrega" e tiver entregador atribuído, aparece "📍 Ver localização".
Abre um mapa com a última posição (o entregador envia a cada ~18 s, só enquanto estiver na rua).', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'lista', 14, ''),
	(138, 'man-operador-15-o-que-voce-tem-em-administrador', 'O que você tem em Administrador', 'o que você tem em administrador', 'A aba aparece com o nome "Operação". A barra é reduzida: só o grupo "💬 Atendimento", com duas telas — Ocorrências e Feedbacks.
Ocorrências: filtro Abertas/Todas e botão "Tratar". Você pode mudar status (Aberta → Em andamento → Resolvida), anotar responsável e descrever a solução.
Feedbacks: tudo o que os clientes enviaram. Você pode marcar como Visto ou Respondido.
Atalho mais rápido no dia a dia: no Assistente, a aba "🔔 Avisos" mostra as ocorrências abertas, com botão "Tratar" direto.
Você NÃO tem acesso às outras telas do Administrador (financeiro, usuários, backup, catálogo etc.).', '{Operador}', true, '2026-10-16 03:03:49.796886+00', 'lista', 15, ''),
	(139, 'man-operador-16-clientes-e-fidelidade', 'Clientes e fidelidade', 'clientes e fidelidade, "nenhum prêmio cadastrado"', 'Clientes → "+ Novo cliente": só nome e telefone são obrigatórios.
Toque no cliente para ver histórico, total gasto, indicação e cartão fidelidade.
Com as 10 marcas, ou com uma indicação pendente, escolha o prêmio e toque em "🎁 Resgatar". Precisa do caixa aberto; o estoque baixa e o cliente não paga.', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'secao', 16, '"Nenhum prêmio cadastrado": peça ao Administrador para marcar um produto como prêmio.'),
	(140, 'man-operador-17-registrar-um-problema-ocorrencia', 'Registrar um problema (Ocorrência)', 'registrar um problema (ocorrência)', 'No cartão do pedido, toque em “⚠️ Ocorrência”.
Escolha o tipo, descreva o que aconteceu e confirme.
Ela aparece na aba "🔔 Avisos" do Assistente e você pode tratar direto pelo botão "Tratar".', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'secao', 17, ''),
	(142, 'err-operador-02-supabase-fora-do-ar-faixa-laranja', 'Supabase fora do ar (faixa laranja)', 'supabase fora do ar (faixa laranja)', 'Modo reserva automático. O cartão "Pedidos na reserva" fica em Pedidos (somente consulta). Você pode continuar registrando retirada/entrega na contingência — sem desconto, sem mesa, sem cupom.', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'erro', 101, ''),
	(143, 'err-operador-03-o-caixa-esta-fechado', 'O caixa está fechado', 'o caixa está fechado', 'Abra o caixa antes de vender, lançar despesa ou sangria. Enquanto estiver fechado, o Cardápio Digital também não recebe pedidos.', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'erro', 102, ''),
	(144, 'err-operador-04-pedido-duplicado', 'Pedido duplicado', 'pedido duplicado', 'Duplo toque não duplica. Se o cliente pediu duas vezes, cancele um em "Lançamentos desde a abertura" → excluir, motivo "Pedido duplicado".', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'erro', 103, ''),
	(145, 'err-operador-05-errei-o-valor-ou-um-item', 'Errei o valor ou um item', 'errei o valor ou um item', 'Use "editar" em "Lançamentos desde a abertura". Itens de pedido só mudam enquanto o pedido está "Em preparo".', '{Operador}', true, '2026-10-09 10:19:39.43679+00', 'erro', 104, ''),
	(153, 'man-admin-08-modo-emergencia-planilha-fora-do-ar', 'Modo emergência (servidor fora do ar)', 'modo emergência (planilha fora do ar) admin', 'Só funciona no mesmo aparelho em que você já fez login normal ao menos uma vez nos últimos 30 dias. Cada login novo renova o prazo.
Quando o sistema não consegue falar com o servidor (Supabase), aparece a pergunta: "Entrar em MODO EMERGÊNCIA como [seu login]?". A senha é conferida no aparelho.
O que dá: registrar venda de retirada/entrega pela contingência, usando o catálogo da última sincronização. Sem mesa, sem desconto.
O que NÃO dá: abrir/fechar caixa, cancelar, receber pagamento, mexer em estoque, ver financeiro.
Um aviso laranja fixo no topo mostra "MODO EMERGÊNCIA". Um vigia testa o servidor a cada 30 s. Assim que ele responde, o app pede login de novo.
Errar a senha 5 vezes no modo emergência bloqueia por 5 minutos.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'lista', 8, ''),
	(154, 'man-admin-09-contingencia-e-modo-reserva', 'Contingência e modo reserva', 'contingência e modo reserva admin', 'O Supabase é o servidor principal; a planilha principal é a reserva e a planilha de contingência é o último recurso. Se o Supabase cai, o modo reserva segura o app e a contingência segura o cardápio e as vendas.
No modo reserva: faixa laranja no topo e cartão "Pedidos na reserva (somente consulta)" em Pedidos. Mostra o que estava em andamento no último espelho e o que entrou na fila da contingência.
Ao voltar, o Admin recebe sozinho as vendas da contingência. Falhas ficam na tela de Contingência.
Tempo real (WebSocket) e modo reserva são automáticos.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'lista', 9, ''),
	(155, 'man-admin-10-fila-de-envio-e-erros-de-sincronizacao', 'Fila de envio e erros de sincronização', 'fila de envio e erros de sincronização admin', 'Itens como cadastro de cliente, fidelidade, feedback e ocorrência podem ficar guardados no aparelho quando a internet cai. Aparece o botão "na fila" no topo.
Toque nele para ver estado, tentativas e motivo. Você pode tentar de novo, descartar ou enviar agora.
Venda, pagamento, sangria, cancelamento e estoque NUNCA ficam na fila.
Se a sessão expirar com itens na fila, eles viram "com erro" e voltam só quando alguém entrar de novo e tocar em "Tentar de novo".', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'lista', 10, ''),
	(156, 'man-admin-11-localizacao-do-entregador', 'Localização do entregador', 'localização do entregador admin', 'No cartão da entrega, se o status for "Saiu para entrega" e houver entregador atribuído, aparece "📍 Ver localização".
Abre um mapa embutido (Leaflet local) e um botão "Abrir no mapa".
A posição só existe se o entregador estiver com o app aberto e GPS permitido. O envio é a cada ~18 s e só enquanto houver entrega em "Saiu para entrega".
O cliente vê apenas a distância aproximada.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'lista', 11, ''),
	(157, 'man-admin-12-balao-de-atendimento-e-assistente-de-ia', 'Balão de atendimento e assistente de IA', 'balão de atendimento e assistente de ia admin', 'No canto da tela tem um botão único. Para o cliente, é o atendimento. Para funcionário logado, é o assistente.
Assistente (Admin e Operador): escreva em português. Exemplos: "como faço uma venda?", "quanto tem de pão no estoque?", "tem cliente aguardando?", "qual produto vendeu mais hoje?".
Período: reconhece "hoje", "ontem", "7 dias", "30 dias", "mês". Pergunta de mês anterior avisa que os dados estão arquivados (veja Relatórios).
A IA é somente leitura. Não altera preço, não cancela, não muda status.
Se você for Desenvolvedor real (sem "Ver como"), o balão aceita comandos: "atualizar código", "enviar apps script", "analise o index.html", "o que mudou", "testar ajuda".
Quando o Supabase cai (ou a IA falha seguidas vezes), o balão avisa e o sistema segue normal.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'lista', 12, ''),
	(158, 'man-admin-13-arquivamento-e-uso-do-banco', 'Arquivamento e uso do banco', 'arquivamento e uso do banco admin', 'Administrador → Sistema → Espaço e fotos → bloco "Uso do Supabase".
Por padrão, vendas e caixas fechados com mais de 90 dias saem do Supabase e vão para a planilha (abas Arquivo_*), de madrugada. Você pode mudar a regra (90/60/30 dias) e forçar "Mandar para a planilha agora".
Relatórios e Visão Geral buscam esse arquivo automaticamente quando o período pedido é antigo.
Fotos: só no Google Drive. Administrador → Espaço e fotos → "Copiar fotos antigas para a contingência".', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'lista', 13, ''),
	(159, 'man-admin-14-exemplos-de-pergunta-ao-assistente', 'Exemplos de pergunta ao assistente', 'exemplos de pergunta ao assistente admin', '"Resumo de hoje" — faturamento, pedidos, ticket.
"Como estão as vendas comparadas com ontem?"
"Qual produto vendeu mais nos últimos 7 dias?"
"Em que horário vendemos mais?"
"Tem algo fora do normal?" — anomalias do dia.
"O que precisa comprar?" — sugestão de compras pelo consumo.
"Como cancelo uma venda?" / "Como fecho o caixa?" — passo a passo do manual.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'lista', 14, ''),
	(160, 'man-admin-15-backup-e-armazenamento', 'Backup e armazenamento', 'backup e armazenamento admin', 'Administrador → Sistema → Backup → "Fazer backup agora".
Ative o backup automático e escolha a frequência e a retenção.
Para restaurar, escolha o backup no histórico e confirme com sua senha de administrador.
Confira o uso do Drive: até 70% normal, 70–90% atenção, acima de 90% crítico.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'secao', 15, 'Drive cheio: backups e fotos podem falhar.
A conferência de integridade aponta duplicidades, estoque negativo, caixa esquecido aberto e vendas paradas na contingência.'),
	(161, 'man-admin-16-ocorrencias', 'Ocorrências', 'ocorrências admin', 'Você trata direto pelo mural Notificações, no cartão "⚠️ Ocorrências abertas" → botão "Tratar".
A tela completa (com filtro Abertas/Todas) continua em Administrador → Painel → Ocorrências.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'lista', 16, ''),
	(162, 'man-admin-17-ajustes-pos-venda-reembolso-credito-cort', 'Ajustes pós-venda (reembolso, crédito, cortesia)', 'ajustes pós-venda (reembolso, crédito, cortesia) admin', 'Administrador → Financeiro → Ajustes pós-venda.
Busque a venda (nº do pedido, nome ou telefone) — só aparecem pedidos já entregues.
Escolha o tipo (Reembolso em dinheiro, Crédito para próxima compra, Cortesia ou Desconto retroativo), o valor e o motivo.
Em reembolso e desconto retroativo, escolha se o dinheiro sai do caixa (o caixa precisa estar aberto) ou fora dele.
Toque em "Registrar ajuste". Para desfazer, use "cancelar" na lista, com o motivo.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'secao', 17, 'A venda original NÃO muda. No DRE o ajuste aparece como "Ajustes pós-venda".
Crédito não reduz o resultado na hora: quando o cliente usar, aplique como desconto no Caixa.
Reembolso e desconto retroativo não passam do valor da venda (somando ajustes já feitos).'),
	(163, 'man-admin-18-desenvolvedor-exclusivo', '🛠️ Desenvolvedor (exclusivo)', '🛠️ desenvolvedor (exclusivo) admin', 'Esta seção só aparece para quem entrou com acesso de nível Desenvolvedor (e sem "Ver como"). Ninguém mais vê.
Barra "Modo Desenvolvedor — vendo o sistema como:". Escolha um perfil (Operador, Garçom, Cozinha, Entregador) ou uma PESSOA específica e a tela muda para a dela. Suas ações continuam com acesso total.
Voltar para a visão normal: selecione "Admin (visão normal)".
Comandos exclusivos no balão: "atualizar código" envia o index.html desta página, "enviar apps script" abre o seletor de arquivos .gs, "analise o index.html" / "analise o apps script" roda a auditoria, "o que mudou" compara blocos entre versões, "testar ajuda" roda o auto-teste dos manuais.
Auto-teste da Ajuda (também no console): testarAjuda_() — valida os 6 manuais em sequência e devolve o resultado.
Painel de uso da IA: dentro do balão de status (✨) → "Uso da IA".
Diagnóstico do sistema: Administrador → Sistema → Sincronização e contingência → "Conferência de integridade". Somente leitura.
Ao criar/editar usuário Desenvolvedor: você cria como qualquer outro, mas depois de criado o acesso fica travado. Nem você nem ele excluem. Só o próprio Desenvolvedor edita a senha.
Se um funcionário comum tentar um comando de Dev no balão, o servidor recusa (checagem dupla).', '{Desenvolvedor}', false, '2026-10-09 10:20:59.387621+00', 'lista', 18, ''),
	(164, 'man-admin-19-i-sobre-o-sistema', 'ℹ️ Sobre o sistema', 'ℹ️ sobre o sistema admin', 'A Ajuda é atualizada junto com o sistema. Se algum passo aqui não bater com a tela, recarregue a página (Ctrl+Shift+R no computador, ou feche e reabra o app no celular).
Para dúvida ou problema: use o balão de atendimento (canto da tela) ou fale com o responsável técnico.
O app registra erros de JavaScript deste aparelho e envia para o Supabase (com o login de quem estava usando). Nada de dado pessoal de cliente sai por esse caminho.', '{Admin}', false, '2026-10-09 10:20:59.387621+00', 'lista', 19, ''),
	(166, 'err-admin-02-supabase-fora-do-ar-faixa-laranja', 'Supabase fora do ar (faixa laranja)', 'supabase fora do ar (faixa laranja)', 'Modo reserva automático: o app para o tempo real, volta às atualizações de 3 min, abre o cartão "Pedidos na reserva" em Pedidos e libera o Caixa para registrar venda na contingência. Ao voltar, a fila é reenviada e as vendas da contingência são reconciliadas sozinhas.', '{Admin}', true, '2026-10-09 10:20:30.45071+00', 'erro', 101, ''),
	(167, 'err-admin-03-sua-sessao-expirou', '"Sua sessão expirou"', '"sua sessão expirou"', 'Entre de novo. Itens que estavam na fila viram "com erro" e voltam pelo botão "na fila" no topo → "Tentar de novo".', '{Admin}', true, '2026-10-09 10:20:30.45071+00', 'erro', 102, ''),
	(169, 'err-admin-05-pedido-duplicado', 'Pedido duplicado', 'pedido duplicado', 'Duplo toque ou internet lenta não duplicam. Se o cliente fez dois pedidos de verdade, cancele um: Caixa → "Lançamentos desde a abertura" → excluir, motivo "Pedido duplicado".', '{Admin}', true, '2026-10-09 10:20:30.45071+00', 'erro', 104, ''),
	(186, 'man-entregador-06-registrar-um-problema-ocorrencia', 'Registrar um problema (Ocorrência)', 'registrar um problema (ocorrência)', 'No cartão do pedido, toque em “⚠️ Ocorrência”.
Escolha o tipo, descreva o que aconteceu e confirme.
O Administrador e o Operador são avisados. Use para cliente ausente, endereço errado ou problema na entrega.', '{Entregador}', true, '2026-10-09 10:18:49.28704+00', 'secao', 6, ''),
	(230, 'man-admin-05-premios-fidelidade-e-indicacao', 'Prêmios: fidelidade e indicação', 'prêmios: fidelidade e indicação, o caixa precisa estar aberto, "nenhum prêmio cadastrado", as indicações pendentes também aparecem ', 'Marque os produtos que podem ser prêmio em Produtos → Produtos, combos e adicionais → Editar → "🎁 Este produto é um prêmio".
Clientes → toque no cliente. Com as 10 marcas do cartão, ou com uma indicação pendente, aparece o prêmio para escolher e o botão "🎁 Resgatar prêmio" (ou "Resgatar indicação").
Confirme. O cartão zera (ou a indicação é marcada), o estoque do produto baixa e o custo entra no financeiro. O cliente não paga nada.', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'secao', 5, 'O caixa precisa estar aberto: o prêmio fica registrado no turno.
"Nenhum prêmio cadastrado": nenhum produto ativo está marcado como prêmio daquele tipo.
As indicações pendentes também aparecem em 🔔 Avisos (no Assistente).'),
	(231, 'man-admin-06-qr-code-das-mesas', 'QR Code das mesas', 'qr code das mesas, o endereço do site está fixo nos qr', 'Administrador → Loja e equipe → Mesas e QR Codes → "📲 QR Codes das mesas".
Escolha a mesa e toque em "🖨️ Imprimir esta mesa" (ou "Imprimir todas"). Também dá para "⬇️ Baixar PNG".
Plastifique e deixe na mesa. O cliente pede pelo celular e você aceita o pedido em Pedidos.
Se alguém espalhar o QR, use "🔄 Gerar novo código" e imprima o QR novo daquela mesa.', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'secao', 6, 'O endereço do site está fixo nos QR: https://texasburguer.github.io/apptexasburguer/ — se mudar, é preciso imprimir de novo.'),
	(232, 'man-admin-07-cardapio-digital-promocoes-e-eventos', 'Cardápio Digital, promoções e eventos', 'cardápio digital, promoções e eventos', 'Cardápio Digital: escolha o que aparece para o cliente, destaques, ordem e frase de abertura. "Mais Pedidos" é automático.
Se o cliente pedir mais de 1 lanche com adicionais, os adicionais valem para todos — o cardápio avisa.
O cliente pode escrever uma observação em cada item; ela aparece na comanda da cozinha e no pedido.
Item "Esgotado": se "bloquear venda sem estoque" estiver ligado (Produtos → Estoque), o cardápio mostra "Esgotado" no que o estoque não cobre.
No celular, "Mais pedidos", "Destaques" e cada categoria rolam para o lado. O cliente toca no botão vermelho "+" para adicionar e na foto para ver o item ampliado. O botão redondo de balão abre o Atendimento.
Na entrega, o endereço vem com rua e bairro preenchidos pela localização do cliente (só se ele permitir). O número da casa é sempre digitado por ele e o pedido não segue sem ele.
O cardápio abre rápido porque guarda cópia no aparelho do cliente. Mudanças suas aparecem em instantes.
O cardápio só recebe pedidos com o caixa aberto; fechado, aparece "Estamos fechados no momento".
Promoções: cupons. Eventos: custos e recebimentos por evento. Custos e Precificação: simulador de preço ("Aplicar como preço base" vale para todas as formas de pagamento).
Abrir ou fechar o cardápio: use o botão "🌐 Cardápio aberto" em Início ou no Caixa. Um toque fecha (com mensagem opcional para o cliente) e outro reabre, sem fechar o caixa. Pedido de mesa por QR Code continua valendo.
Dados do restaurante: nome, endereço, telefone, horário e redes sociais (texto livre) aparecem no rodapé do cardápio do cliente e nas mensagens de WhatsApp e relatórios.
Cupom progressivo: em Promoções → novo cupom, tipo "Progressivo (por faixa)", uma faixa por linha (ex.: "50 5" e "100 10" = R$ 5 a partir de R$ 50 e R$ 10 a partir de R$ 100). Vale a maior faixa alcançada, contando só os itens (sem taxa de entrega).', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'lista', 7, ''),
	(233, 'man-admin-08-caixa-abrir-vender-e-fechar', 'Caixa: abrir, vender e fechar', 'caixa: abrir, vender e fechar, "abra o caixa antes de registrar uma ven, "a soma dos pagamentos precisa bater com, desconto nunca pode zerar a venda; no ca', 'Aba Caixa → "Abrir caixa" e informe o fundo de troco.
Em "Iniciar venda": 1. Cliente → 2. Itens → 3. Pagamento e finalizar.
Na etapa 3, escolha 58mm, 80mm ou A4 e toque em Imprimir, Copiar ou WhatsApp.
Para encerrar, feche o caixa, informe o dinheiro contado e confira a diferença.
Mesas: o botão "🍽️ Mesas" mostra todas as mesas e quem pediu a conta.
Pedido de mesa no Caixa: "Pagar ao sair" deixa na conta; "Pagar agora" cobra na hora.
Imprimir o pedido: em Pedidos, nos cartões de Retirada e de Mesa, o botão "🖨️ Imprimir pedido da retirada" (ou "da mesa") imprime o cliente, os itens, o total e se já está pago ou se é para cobrar. Nas entregas, "🖨️ Imprimir para o entregador" traz também o endereço. O botão só aparece depois que o pedido foi aceito. O tamanho do papel dessas três impressões se escolhe em Pedidos → Entregas ("Papel da impressão").
Se a forma de pagamento tem acréscimo (ex.: iFood), o Caixa mostra o valor a mais e já soma no total e no comprovante. Em pagamento dividido, o acréscimo vale só para a parte paga naquela forma.
Para dividir o pagamento, marque "Dividir pagamento" na etapa 3. "↺ Repetir última venda" recarrega o carrinho anterior.
Caixa vencido: se o caixa passou do corte, venda nova, sangria e resgate de prêmio ficam bloqueados. Use "Fechar caixa vencido" no fim da tela do Caixa (veja "Caixa vencido").
Se houver pagamento do Mercado Pago a decidir, aparece uma faixa discreta no Caixa (veja "Mercado Pago").', '{Admin}', true, '2026-10-17 09:27:56.719023+00', 'secao', 8, '"Abra o caixa antes de registrar uma venda".
"A soma dos pagamentos precisa bater com o total".
Desconto nunca pode zerar a venda; no Caixa pede a sua senha.'),
	(234, 'man-admin-09-modo-emergencia-planilha-fora-do-ar', 'Modo emergência (servidor fora do ar)', 'modo emergência (planilha fora do ar)', 'Só funciona no mesmo aparelho em que você já fez login normal ao menos uma vez nos últimos 30 dias. Cada login novo renova o prazo.
Quando o sistema não consegue falar com o servidor (Supabase), aparece a pergunta: "Entrar em MODO EMERGÊNCIA como [seu login]?". A senha é conferida no aparelho.
O que dá: registrar venda de retirada/entrega pela contingência, usando o catálogo da última sincronização. Sem mesa, sem desconto.
O que NÃO dá: abrir/fechar caixa, cancelar, receber pagamento, mexer em estoque, ver financeiro.
Um aviso laranja fixo no topo mostra "MODO EMERGÊNCIA". Um vigia testa o servidor a cada 30 s. Assim que ele responde, o app pede login de novo.
Errar a senha 5 vezes no modo emergência bloqueia por 5 minutos.', '{Admin}', true, '2026-10-09 10:20:30.45071+00', 'lista', 9, ''),
	(235, 'man-admin-10-contingencia-e-modo-reserva', 'Contingência e modo reserva', 'contingência e modo reserva', 'O Supabase é o servidor principal; a planilha principal é a reserva e a planilha de contingência é o último recurso. Se o Supabase cai, o modo reserva segura o app e a contingência segura o cardápio e as vendas.
No modo reserva: faixa laranja no topo e cartão "Pedidos na reserva (somente consulta)" em Pedidos. Mostra o que estava em andamento no último espelho e o que entrou na fila da contingência.
Ao voltar, o Admin recebe sozinho as vendas da contingência. Falhas ficam na tela de Contingência.
Tempo real (WebSocket) e modo reserva são automáticos.
Administrador → Sistema → Sincronização e contingência: mostra o uso de espaço da planilha de contingência, "🔄 Sincronizar espelho agora" e "⬇️ Trazer vendas pendentes da contingência".
O espelho da contingência (cardápio, preços, clientes e pedidos em andamento) se atualiza sozinho a cada 10 minutos e por completo todo dia às 3h. Não há nada para ligar.', '{Admin}', true, '2026-10-11 16:31:19.325087+00', 'lista', 10, ''),
	(236, 'man-admin-11-fila-de-envio-e-erros-de-sincronizacao', 'Fila de envio e erros de sincronização', 'fila de envio e erros de sincronização', 'Itens como cadastro de cliente, fidelidade, feedback e ocorrência podem ficar guardados no aparelho quando a internet cai. Aparece o botão "na fila" no topo.
Toque nele para ver estado, tentativas e motivo. Você pode tentar de novo, descartar ou enviar agora.
Venda, pagamento, sangria, cancelamento e estoque NUNCA ficam na fila.
Se a sessão expirar com itens na fila, eles viram "com erro" e voltam só quando alguém entrar de novo e tocar em "Tentar de novo".', '{Admin}', true, '2026-10-09 10:20:30.45071+00', 'lista', 11, ''),
	(237, 'man-admin-12-localizacao-do-entregador', 'Localização do entregador', 'localização do entregador', 'No cartão da entrega, se o status for "Saiu para entrega" e houver entregador atribuído, aparece "📍 Ver localização".
Abre um mapa embutido (Leaflet local) e um botão "Abrir no mapa".
A posição só existe se o entregador estiver com o app aberto e GPS permitido. O envio é a cada ~18 s e só enquanto houver entrega em "Saiu para entrega".
O cliente vê apenas a distância aproximada.', '{Admin}', true, '2026-10-09 10:20:30.45071+00', 'lista', 12, ''),
	(238, 'man-admin-13-balao-de-atendimento-e-assistente-de-ia', 'Balão de atendimento e assistente de IA', 'balão de atendimento e assistente de ia', 'No canto da tela tem um botão único. Para o cliente, é o atendimento. Para funcionário logado, é o assistente.
Dentro do assistente há duas abas: "✨ Conversa" (perguntas à IA e atendimento de clientes) e "🔔 Avisos" (o que antes ficava em Notificações). O botão do canto mostra "🔔 n" quando há aviso.
Em Avisos aparecem só os itens que precisam de você, em grupos que se abrem ao toque: pedidos aguardando aceite, ocorrências, entregas com problema, contas vencidas, falhas do sistema, estoque baixo, cartão fidelidade quase completo, indicações pendentes, aniversariantes do mês e clientes inativos. O que está em dia fica numa linha só ("✅ Em dia: …").
Quais avisos aparecem para cada perfil se escolhe em Administrador → Loja e equipe → Configurar avisos. Botões como "Tratar" abrem a tela da ocorrência por cima.
Assistente (Admin e Operador, só leitura): escreva em português. Exemplos: "como faço uma venda?", "quanto tem de pão no estoque?", "tem cliente aguardando?", "qual produto vendeu mais hoje?".
Período: reconhece "hoje", "ontem", "7 dias", "30 dias", "mês". Pergunta de mês anterior avisa que os dados estão arquivados (veja Relatórios).
A IA é somente leitura. Não altera preço, não cancela, não muda status. Ela só responde assuntos do restaurante e nunca mostra senha nem dados de contato de clientes. O Operador recebe só o que é da função de Caixa.
Para o cliente, o balão é o atendente virtual: responde cardápio, preços, promoções, formas de pagamento e andamento do pedido (pelo celular dele). Se for problema, oferece "Falar com a equipe"; aí o chamado aparece para você no balão (aba Conversa).
Se a IA ficar sem cota ou fora do ar, o cliente continua vendo o botão para falar com a equipe, que não depende da IA.
Quando o Supabase cai (ou a IA falha seguidas vezes), o balão avisa e o sistema segue normal.', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'lista', 13, ''),
	(239, 'man-admin-14-arquivamento-e-uso-do-banco', 'Arquivamento e uso do banco', 'arquivamento e uso do banco', 'Administrador → Sistema → Backup e espaço → bloco "Uso do Supabase".
Por padrão, vendas e caixas fechados com mais de 90 dias saem do Supabase e vão para a planilha (abas Arquivo_*), de madrugada. Você pode mudar a regra (90/60/30 dias) e forçar "Mandar para a planilha agora".
"Proteção de espaço": se o uso chegar a 90%, 95% ou 98% do limite (você escolhe), o sistema manda para a planilha as vendas e caixas já encerrados, mesmo com menos de 30 dias. O que tem menos de 1 dia, os pedidos em andamento e o caixa aberto nunca saem; só apaga o que a planilha confirmou. Verifica de hora em hora.
Relatórios e Visão Geral buscam esse arquivo automaticamente quando o período pedido é antigo.
Fotos: ficam no Google Drive principal, com cópia no Drive da contingência. É automático.
Em Backup e espaço, o botão "Simular" no arquivamento mostra quantos pedidos e caixas sairiam do Supabase, quantos ficam e se o resumo guardado confere com a planilha, sem mover nada. Ao anonimizar um cliente (LGPD), os pedidos dele arquivados na planilha também são limpos, de madrugada.', '{Admin}', true, '2026-10-17 09:27:56.719023+00', 'lista', 14, ''),
	(240, 'man-admin-15-exemplos-de-pergunta-ao-assistente', 'Exemplos de pergunta ao assistente', 'exemplos de pergunta ao assistente', '"Resumo de hoje" — faturamento, pedidos, ticket.
"Como estão as vendas comparadas com ontem?"
"Qual produto vendeu mais nos últimos 7 dias?"
"Em que horário vendemos mais?"
"Tem algo fora do normal?" — anomalias do dia.
"O que precisa comprar?" — sugestão de compras pelo consumo.
"Como cancelo uma venda?" / "Como fecho o caixa?" — passo a passo do manual.', '{Admin}', true, '2026-10-09 10:20:30.45071+00', 'lista', 15, ''),
	(241, 'man-admin-16-backup-e-armazenamento', 'Backup e armazenamento', 'backup e armazenamento, drive cheio, a conferência de integridade aponta dupl', 'Administrador → Sistema → Backup e espaço → "Fazer backup agora" (começa na hora, sem pergunta).
Ative o backup automático e escolha o horário e a retenção (por quantos dias guardar).
Para restaurar, escolha o backup no histórico e confirme com sua senha de administrador.
Para apagar um backup, toque em "Excluir" no histórico e confirme com a sua senha de administrador.
Se o backup ficou sem cópia no Drive, aparece o motivo e o botão "Enviar ao Drive" para tentar de novo. O backup tenta até 3 vezes sozinho.
Na mesma tela ficam "Uso do Supabase" (arquivamento) e "Google Drive" (espaço: até 70% normal, 70–90% atenção, acima de 90% crítico).', '{Admin}', true, '2026-10-11 16:31:19.325087+00', 'secao', 16, 'Drive cheio: backups e fotos podem falhar.
A conferência de integridade aponta duplicidades, estoque negativo, caixa esquecido aberto e vendas paradas na contingência.'),
	(242, 'man-admin-17-ocorrencias', 'Ocorrências', 'ocorrências', 'Você trata direto pelo Assistente: aba "🔔 Avisos" → "⚠️ Ocorrências abertas" → botão "Tratar".
A tela completa (com filtro Abertas/Todas) continua em Administrador → Hoje → Ocorrências.', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'lista', 17, ''),
	(243, 'man-admin-18-ajustes-pos-venda-reembolso-credito-cortesia', 'Ajustes pós-venda (reembolso, crédito, cortesia)', 'ajustes pós-venda (reembolso, crédito, cortesia), a venda original não muda. no dre o ajus, crédito não reduz o resultado na hora, reembolso e desconto retroativo não pass', 'Administrador → Dinheiro → Reembolsos e ajustes.
Busque a venda (nº do pedido, nome ou telefone) — só aparecem pedidos já entregues.
Escolha o tipo (Reembolso em dinheiro, Crédito para próxima compra, Cortesia ou Desconto retroativo), o valor e o motivo.
Em reembolso e desconto retroativo, escolha se o dinheiro sai do caixa (o caixa precisa estar aberto) ou fora dele.
Toque em "Registrar ajuste". Para desfazer, use "cancelar" na lista, com o motivo.', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'secao', 18, 'A venda original NÃO muda. No DRE o ajuste aparece como "Ajustes pós-venda".
Crédito não reduz o resultado na hora: quando o cliente usar, aplique como desconto no Caixa.
Reembolso e desconto retroativo não passam do valor da venda (somando ajustes já feitos).'),
	(244, 'man-admin-19-desenvolvedor-exclusivo', '🛠️ Desenvolvedor (exclusivo)', '🛠️ desenvolvedor (exclusivo)', 'Esta seção só aparece para quem entrou com acesso de nível Desenvolvedor (e sem "Ver como"). Ninguém mais vê.
Barra "Modo Desenvolvedor — vendo o sistema como:". Escolha um perfil (Operador, Garçom, Cozinha, Entregador) ou uma PESSOA específica e a tela muda para a dela. Suas ações continuam com acesso total.
Voltar para a visão normal: selecione "Admin (visão normal)".
Auto-teste da Ajuda (também no console): testarAjuda_() — valida os 7 manuais em sequência e devolve o resultado.
Painel de uso da IA (custo, erros e cota): dentro do balão (✨) → "Uso da IA". A IA de análise de código do Desenvolvedor foi retirada.
Diagnóstico do sistema: Administrador → Sistema → Sincronização e contingência → "Conferência de integridade". Somente leitura.
Ao criar/editar usuário Desenvolvedor: você cria como qualquer outro, mas depois de criado o acesso fica travado. Nem você nem ele excluem. Só o próprio Desenvolvedor edita a senha.
O servidor sempre confere o nível de quem pede; não adianta forçar "Ver como" para ganhar acesso.', '{Desenvolvedor}', true, '2026-10-16 03:03:49.796886+00', 'lista', 19, ''),
	(245, 'man-admin-20-sobre-o-sistema', 'ℹ️ Sobre o sistema', 'ℹ️ sobre o sistema', 'Versão em uso neste aparelho: v-etapa-13 — publicada em 09/10/2026.
A Ajuda é atualizada junto com o sistema. Se algum passo aqui não bater com a tela, recarregue a página (Ctrl+Shift+R no computador, ou feche e reabra o app no celular).
Esta versão inclui: aviso de pedido novo em segundos, modo reserva automático (Supabase), modo emergência (planilha), fila de envio para cadastros, confirmação de impressão da comanda + alerta "PEDIDO ALTERADO", localização do entregador, balão único com IA, arquivamento automático (por idade e por espaço), prêmios de fidelidade e indicação, atendente virtual no cardápio e backup com exclusão e reenvio ao Drive.
Para dúvida ou problema: use o balão de atendimento (canto da tela) ou fale com o responsável técnico.
O app registra erros de JavaScript deste aparelho e envia para o Supabase (com o login de quem estava usando). Nada de dado pessoal de cliente sai por esse caminho.', '{Admin}', true, '2026-10-09 10:20:30.45071+00', 'lista', 20, ''),
	(251, 'man-admin-90-buscar', 'Buscar (lupa no topo)', 'buscar busca lupa cliente pedido produto linha do tempo', 'Toque na lupa 🔍 no topo, digite pelo menos 2 letras ou números e veja clientes (nome sem precisar de acento, ou telefone), pedidos (número, nome ou telefone do cliente) e produtos/combos.
No cliente, toque em "abrir". No pedido, toque em "ver pedido completo": aparece a Linha do tempo (feito, aceito, pronto, saiu, entregue e o tempo de cada etapa).', '{Admin}', true, '2026-10-09 16:18:22.325986+00', 'lista', 90, ''),
	(252, 'man-operador-90-buscar', 'Buscar (lupa no topo)', 'buscar busca lupa cliente pedido produto linha do tempo', 'Toque na lupa 🔍 no topo, digite pelo menos 2 letras ou números e veja clientes (nome sem precisar de acento, ou telefone), pedidos (número, nome ou telefone do cliente) e produtos/combos.
No cliente, toque em "abrir". No pedido, toque em "ver pedido completo": aparece a Linha do tempo (feito, aceito, pronto, saiu, entregue e o tempo de cada etapa).', '{Operador}', true, '2026-10-09 16:18:22.325986+00', 'lista', 90, ''),
	(253, 'man-garcom-90-buscar', 'Buscar (lupa no topo)', 'buscar busca lupa cliente pedido produto', 'Toque na lupa 🔍 no topo e digite o nome do cliente, o número do pedido ou o nome de um produto. Você não vê valores nem telefone dos pedidos.', '{Garçom}', false, '2026-10-09 16:18:22.325986+00', 'lista', 90, ''),
	(254, 'man-cozinha-90-buscar', 'Buscar (lupa no topo)', 'buscar busca lupa pedido produto', 'Toque na lupa 🔍 no topo e digite o número do pedido, o nome do cliente ou o nome de um produto para achar um pedido rápido.', '{Cozinha}', false, '2026-10-09 16:18:22.325986+00', 'lista', 90, ''),
	(255, 'man-admin-91-baixar-csv-excel', 'Baixar para o Excel (CSV)', 'csv excel exportar baixar relatório vendas itens despesas planilha', 'Administrador → Dinheiro → Relatórios e DRE: escolha o período e toque em "Baixar este relatório (CSV)".
Em "Dados completos do período" baixe Vendas, Itens vendidos ou Despesas. Meses arquivados entram sozinhos (as despesas só se estiverem no app). O arquivo abre direto no Excel.', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'lista', 91, ''),
	(256, 'man-operador-92-cep-e-filtros', 'CEP na entrega e filtros do histórico do cliente', 'cep endereço entrega viacep histórico cliente filtro', 'No Caixa, em Entrega, digite o CEP (opcional) para preencher rua e bairro; confira e digite o número.
No perfil do cliente, o histórico tem filtros de período, entrega/retirada e pago/a receber.', '{Admin,Operador}', true, '2026-10-09 16:27:54.399428+00', 'lista', 92, ''),
	(257, 'man-admin-93-compras-fornecedores', 'Compras, fornecedores e análises avançadas', 'compra comprei fornecedor picanha estoque custo despesa recebida pedido margem forma de pagamento dia da semana ano passado 90 dias 12 meses fardo embalagens unidades em cada não entra no estoque aviso laranja digitar item compra bebida', 'Compras e fornecedores (só Administrador): Administrador → Produtos → "Compras e fornecedores". Cadastre o fornecedor, depois registre a compra: itens do estoque (ou "outro item"), quantidade, unidade e valor total pago por item.
Compra "Recebida" soma no estoque e atualiza o custo médio do insumo; "Pedido" só guarda e você marca como recebida quando chegar. Toda compra recebida vira uma despesa (Paga ou A pagar, com vencimento).
Marque "saiu do caixa" só se o dinheiro saiu da gaveta. Compra recebida não é cancelada: corrija pelo estoque ou pela despesa. Pedido não recebido pode ser cancelado com motivo.
Assistente: diga "comprei 30kg de picanha do fornecedor X por R$ 900". A IA só monta um cartão; nada é gravado até tocar em "Confirmar e gravar". "Revisar na tela" permite ajustar antes. Fornecedor ou item não encontrado bloqueia o botão: cadastre antes.
Relatórios → "Análise avançada": margem líquida por forma de pagamento, vendas por dia da semana e comparação com o mesmo período do ano passado. Há também os períodos "Últimos 90 dias" e "Últimos 12 meses".
Ao marcar um pedido de compra como recebido, escolha "✅ Já paguei" ou "🕒 Vou pagar depois" (aí aparece o calendário do vencimento).', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'lista', 93, 'Compras e a gravação pela IA são só do Administrador e do Desenvolvedor.'),
	(258, 'man-admin-94-auditoria-ip', 'Auditoria e acessos (IP)', 'auditoria ip login acesso falha de login senha errada sessão quem entrou aparelho', 'Administrador → Sistema → Auditoria: lista ações sensíveis (descontos, cancelamentos, preços, estoque, usuários, compras), entradas no sistema ("Login") e tentativas com senha errada ("Falha de login").
Cada linha mostra quem fez, o perfil, o aparelho e o IP de origem. Use o período e a busca (nome, ação ou IP); mostra até 300 linhas.
Vários "Falha de login" seguidos do mesmo IP podem ser tentativa de adivinhar a senha: troque a senha do usuário e encerre as sessões dele.
O IP é apagado após 90 dias (o restante do registro fica). Em Usuários → sessões abertas, cada aparelho também mostra o IP da entrada.', '{Admin}', true, '2026-10-09 17:01:33.814217+00', 'lista', 94, 'Auditoria e IPs são só do Administrador e do Desenvolvedor.'),
	(259, 'man-admin-95-avisos-app-fechado', 'Avisos com o app fechado', 'aviso notificação push app fechado novo pedido cliente atendimento celular sino iphone', 'Toque no sino 🔔 do topo e em "Ligar avisos com o app fechado". Permita as notificações quando o navegador pedir.
Depois o celular avisa "Novo pedido" (do cardápio) e "Cliente no atendimento" mesmo com o app fechado ou a tela bloqueada. O aviso não mostra nome nem telefone do cliente.
No iPhone: abra no Safari, Compartilhar → "Adicionar à Tela de Início" e abra o app por esse ícone antes de ligar. No Android basta ligar.
Para desligar, toque no mesmo botão. Ao sair do sistema, o aparelho deixa de receber os avisos de quem saiu.', '{Admin,Operador}', true, '2026-10-09 17:07:16.519729+00', 'lista', 95, 'O som e a vibração do app aberto continuam como antes.'),
	(260, 'man-admin-96-modo-reserva', 'Modo reserva (quando o sistema cai)', 'modo reserva caiu fora do ar faixa laranja contingência supabase indisponível fila queda', 'Uma faixa laranja "Modo reserva" no topo avisa que o servidor principal está fora.
Funciona: venda do Caixa (retirada ou entrega, sem desconto e sem cupom), pedido do cardápio e consulta dos pedidos em Pedidos.
Na fila (seguem sozinhos na volta): cadastro de cliente, fidelidade, feedback e ocorrência. Não repita a ação.
Espera a volta (aparece "indisponível até o Supabase voltar" e nada é gravado): mudar status, estoque, compras, relatórios, avisos e Assistente. Anote à mão e lance depois.', '{Admin,Operador}', true, '2026-10-09 17:26:31.435849+00', 'lista', 96, 'Quando a faixa sumir, confira se os pedidos feitos na queda aparecem em Pedidos.'),
	(261, 'man-admin-97-saude-sistema', 'Saúde do sistema', 'saúde sistema conexão servidores backup conferência vendas tarefas automáticas bolinha verde vermelha', 'A "Saúde do sistema" fica dentro de "Conexão e servidores": toque na bolinha colorida do topo.
Lá aparecem os servidores e, logo abaixo, cada item: cópia para a planilha, backup (diário às 04:00), cópia no Drive, conferência diária de vendas, tarefas automáticas e Assistente.
A própria bolinha do topo muda de cor: verde = tudo certo, amarela = atenção, rosa = precisa de cuidado (se a conexão cair, ela fica vermelha ou laranja). Amarelo pede atenção; vermelho pede ação (ex.: backup com mais de 48 h ou vendas diferentes entre Supabase e planilha).
Desenvolvedor: o botão "Simular queda (treino)" fica em "Conexão e servidores" e finge a queda só neste aparelho. "Encerrar simulação" volta ao normal.', '{Admin}', true, '2026-10-09 17:26:31.435849+00', 'lista', 97, 'Só Admin e Desenvolvedor veem a Saúde do sistema.'),
	(262, 'man-admin-98-botao-abrir-fechar-cardapio', 'Abrir ou fechar o cardápio em um toque', 'abrir fechar cardápio botão cardápio fechado clientes pedir início caixa reabrir', 'Em Início e no Caixa há um botão discreto "🌐 Cardápio aberto".
Toque para fechar: o app pede uma mensagem opcional para o cliente. Os clientes deixam de conseguir pedir.
Quando estiver fechado o botão vira "🌐 Cardápio fechado"; toque para liberar.
O cardápio só recebe pedidos com o caixa aberto, mesmo reaberto.', '{Admin,Operador}', true, '2026-10-09 18:03:35.303879+00', 'lista', 98, 'Disponível para Administrador, Operador e Desenvolvedor.'),
	(263, 'man-admin-99-menu-de-baixo', 'Menu de baixo no celular', 'menu barra embaixo celular navegação abas início caixa pedidos mais bolinha vermelha', 'No celular, o menu fica fixo na parte de baixo da tela: Início, Caixa, Pedidos e as outras telas do seu perfil. A aba aberta fica em dourado.
Quando há mais telas do que cabem, aparece "Mais" com as demais. Uma bolinha vermelha avisa que há algo novo naquela aba.
No computador o menu continua no topo.', '{Admin,Operador}', true, '2026-10-09 18:47:29.517141+00', 'lista', 99, 'O botão do Assistente sobe um pouco para não ficar em cima do menu.'),
	(264, 'man-admin-100-endereco-cidades-entrega', 'Endereço de entrega (número e cidade)', 'endereço número casa cidade entrega cep localização distrito', 'No cardápio, o cliente preenche Rua e bairro, NÚMERO e CIDADE. A localização do celular e o CEP preenchem rua, bairro e cidade sozinhos.
Sem o número (ou "s/n") o pedido não é enviado.
No pedido, o endereço aparece como "Rua, Bairro, nº 123 — Cidade".', '{Admin}', true, '2026-10-09 21:45:20.546817+00', 'lista', 100, 'Se a localização preencher a cidade errada, o cliente pode corrigir no campo Cidade.'),
	(265, 'man-admin-101-contas-e-acessos', 'Contas e acessos', 'contas acessos email senha link supabase github planilha apps script cofre ver senha chave ia gemini groq nvidia cloudflare reserva', 'Administrador → Sistema → Integrações e contas: lista das contas do sistema (Supabase, GitHub, planilhas…) com e-mail, link e observação.
"+ Nova conta" cadastra; "Editar" muda os dados ou a senha; "Excluir" apaga a conta e a senha guardada.
A senha fica no cofre criptografado do Supabase. Para ver, toque em "Ver senha" e digite a SUA senha de administrador; ela aparece por 30 segundos e fica registrado na Auditoria.
Chaves das IAs (Gemini, Groq, NVIDIA e Cloudflare): na mesma tela. "Ver chave" e "Trocar chave" pedem a senha de administrador; a chave nova vale na hora. NVIDIA e Cloudflare são IAs de reserva: sem chave, nada muda; com chave, entram quando o Gemini e a Groq falham ou esgotam o limite grátis.', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'lista', 101, 'Nunca mande senhas por mensagem: digite direto nesta tela.'),
	(266, 'man-admin-102-avisos-cliente', 'Avisos do pedido para o cliente e feedbacks', 'aviso notificacao celular cliente status pedido confirmado pronto saiu entrega entregue como foi seu pedido feedback chat origem', 'O cliente que aceita os avisos (convite no topo do cardápio ou no cartão "Pedido enviado") recebe no celular: confirmado (Em preparo), pronto (só retirada), saiu para entrega, entregue/retirado e cancelado.
O aviso sai sozinho quando a equipe muda o status. Mostra só o número do pedido, nunca nome, telefone ou endereço.
30 minutos depois de entregue (até 3 horas) chega "Como foi seu pedido?", se o cliente ainda não deu feedback daquele pedido.
Em Hoje → Feedbacks aparece de onde veio: "veio pelo aviso do pedido", "veio pelo chat" ou sem marca (rodapé).', '{Admin,Operador}', true, '2026-10-16 03:03:49.796886+00', 'lista', 102, 'Pedido de mesa (QR Code) não recebe aviso. No iPhone o cliente precisa instalar o app (Adicionar à Tela de Início).'),
	(267, 'man-admin-102-integracoes', 'Integrações: iFood e Nota fiscal', 'integrações ifood nota fiscal nfce focus ligar desligar interruptor chaves guia checklist', 'Administrador → Sistema → Integrações e contas → cartão "Integrações": o iFood e a Nota fiscal já vêm prontos no sistema, mas DESLIGADOS. Desligado, o sistema funciona exatamente como antes.
Cada integração tem um guia passo a passo na própria tela e um checklist. Só dá para ligar quando todos os passos estiverem prontos; ligar pede a senha de administrador.
As chaves são digitadas só nesta tela, ficam guardadas com segurança e só aparecem com a sua senha. Nunca envie chaves por mensagem.
Para desligar, toque em "Desligar" e confirme com a senha: o sistema volta a funcionar como antes, e o que já foi gravado fica guardado.', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'lista', 102, 'Só Administrador e Desenvolvedor veem esta tela.'),
	(268, 'man-admin-103-ifood', 'iFood: pedidos, itens ligados e simulação', 'ifood pedido itens ligar ligação produto sem ligação reprocessar simulação teste confirmar', 'Com o iFood ligado (Integrações e contas → Integrações), os pedidos entram sozinhos como venda normal, com a marca "iFood #número", aviso no celular e baixa dos ingredientes.
Itens do iFood: cada item do cardápio do iFood precisa ser ligado a um produto do sistema (Integrações e contas → Integrações → Itens do iFood). O sistema sugere pelo nome; você confirma. Item sem ligação entra no pedido mesmo assim, com o aviso "SEM LIGAÇÃO"; depois de ligar, toque em "Refazer pedidos sem ligação".
O andamento (em preparo, pronta, saiu para entrega) é avisado ao iFood automaticamente quando você muda o status do pedido. Se o iFood não confirmar uma ação, aparece um alerta na lista de pedidos do iFood.
Desenvolvedor: "Simular pedido do iFood (treino)" cria um pedido de mentira, sem enviar nada ao iFood; cancele a venda depois do treino.
Valor da venda: a venda grava o que fica para a loja — itens menos o desconto que a loja paga, mais a taxa de entrega só quando a loja entrega. Cupom pago pelo iFood e a taxa de serviço do iFood ficam fora. Entregador do iFood: o pedido mostra "ENTREGA PELO iFOOD" e "Saiu para entrega" não é enviado ao iFood.
Pedido do iFood cancelado não gera reembolso para a loja devolver: quem devolve ao cliente é o iFood.', '{Admin,Operador}', true, '2026-10-16 03:03:49.796886+00', 'lista', 103, 'Itens do iFood e simulação: só Administrador/Desenvolvedor.'),
	(269, 'man-admin-104-ifood-operacao', 'iFood: negociação de cancelamento e loja', 'ifood cancelamento negociação reembolso aceitar recusar alternativa pausar loja abrir fechar', 'Quando o cliente pede cancelamento ou reembolso no iFood, a equipe recebe um aviso no celular. Abra Integrações e contas → Integrações → iFood → "Negociações": veja o pedido e o prazo, e toque em Aceitar, Recusar ou, quando houver, em uma alternativa. Se o prazo acabar, o iFood decide.
Loja no iFood: o mesmo cartão tem os botões "Pausar 30 min / 1 h", "Retomar", "Fechar" e "Abrir". Com o ajuste "Abrir e fechar a loja no iFood junto com o caixa" ligado, abrir o caixa abre a loja e fechar o caixa fecha.
O painel de Saúde mostra se a loja está aberta ou indisponível no iFood.', '{Admin,Operador}', true, '2026-10-16 03:03:49.796886+00', 'lista', 104, 'Pausar, abrir e fechar: Administrador e Operador.'),
	(270, 'man-admin-105-ifood-inteligencia', 'iFood: preços, estoque, repasses, avaliações e relatório', 'ifood preço importar enviar desfazer pausar estoque repasse receber comissão avaliação relatório canal margem imposto', 'Preços (Integrações → iFood → Preços): "Importar cardápio" traz os preços do iFood; a tabela mostra preço no sistema × preço no iFood × diferença. "Gravar no sistema" grava o preço do iFood no campo "Preço no iFood". "Enviar ao iFood" só funciona com o ajuste "Enviar nossos preços ao iFood" ligado, bloqueia variações acima do limite e guarda histórico com botão Desfazer.
Pausa por estoque: com o ajuste ligado, o item some do iFood quando um ingrediente acaba e volta quando repõe.
Financeiro: mostra quanto falta receber do iFood (pedidos pagos no app ainda sem repasse, já sem a comissão), os repasses recebidos e a comissão real. Comissão: cadastre o % do iFood em Vendas e cardápio → Formas de pagamento, forma "iFood"; ela entra nas taxas de cada pedido e é trocada pela comissão real quando o repasse chega.
Avaliações: as notas do iFood aparecem aqui e em Feedbacks; nota baixa avisa a equipe; você responde pelo painel.
Relatório por canal: vendas, ticket, margem (já sem custo, taxas e comissão e imposto estimado) e cancelamentos de balcão, cardápio e iFood.', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'lista', 105, 'Só Administrador.'),
	(271, 'man-admin-106-fiscal-cadastro', 'Nota fiscal: dados da empresa e perfis fiscais', 'nota fiscal nfc-e cadastro fiscal perfil ncm csosn cfop contador cnpj csc imposto simples', 'Integrações e contas → Integrações → Nota fiscal → "Dados fiscais": preencha razão social, CNPJ, inscrição estadual, endereço, código do município (7 números), regime, número do CSC e a alíquota efetiva do Simples (o contador informa). O código secreto do CSC é digitado no botão do próprio cartão, nunca por mensagem.
Perfis fiscais: cada perfil reúne NCM, CFOP e CSOSN (ou CST). Crie poucos (ex.: Lanches, Bebidas, Sobremesas), marque um como padrão e ligue categorias/itens que sejam exceção. "Itens sem perfil" lista o que ainda falta.
Planilha do contador: "Baixar planilha" gera um arquivo com todos os produtos; o contador preenche perfil, NCM, CSOSN e CFOP, e "Enviar planilha" aplica tudo de uma vez.
A alíquota dos dados fiscais é a padrão do imposto estimado; a de cada mês fica em Dinheiro → Relatórios e DRE, cartão DRE (veja "Imposto sobre vendas"). O imposto aparece no resultado com ou sem a nota fiscal ligada.', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'lista', 106, 'Só Administrador.'),
	(272, 'man-admin-107-nfce-emissao', 'Nota fiscal: emissão automática, CPF na nota e lista de notas', 'nota fiscal nfc-e emitir emissão cpf rejeitada reemitir danfe focus lista notas contingência', 'Com a nota fiscal ligada (Integrações e contas → Integrações → Nota fiscal), cada venda do canal escolhido gera a nota sozinha: ao pagar (balcão) ou na entrega (delivery/iFood). A nota sai cerca de 1 minuto depois da venda, para dar tempo de informar o CPF.
CPF na nota: só se o cliente pedir. No Caixa, antes de finalizar, digite o CPF no campo "CPF na nota". Depois que a nota sai não dá mais para incluir.
Lista "Notas fiscais": filtre por situação (autorizada, rejeitada, pendência, em contingência). Se uma nota foi rejeitada, o texto explica o motivo em português; corrija (ex.: perfil fiscal do produto) e toque em "Reemitir". "Abrir DANFE" mostra o cupom com QR Code; "Enviar ao cliente" abre o WhatsApp com o link.
Nunca é emitida nota de item sem perfil fiscal: a nota fica como pendência até você definir o perfil.
Desenvolvedor: "Nota de treino" cria uma nota de mentira, sem falar com a Focus.', '{Admin,Operador,Garçom}', true, '2026-10-16 03:03:49.796886+00', 'lista', 107, 'Lista de notas e reemissão: só Administrador. CPF na nota: quem faz a venda.'),
	(273, 'man-admin-108-nfce-fechamento', 'Nota fiscal: cancelamento, numeração pulada, conferência e pacote do contador', 'nota fiscal nfc-e cancelar cancelamento inutilizar inutilização conferência vendas sem nota pacote contador limite plano 500', 'Cancelamento: se você cancela uma venda que já tem nota, o sistema cancela a nota sozinho desde que sejam menos de 30 minutos da emissão. Passou do prazo, a nota fica marcada "cancelamento para o contador orientar" (nada é apagado) e aparece na Saúde do sistema.
Conferência (Integrações → Nota fiscal → Conferência): lista as vendas que deveriam ter nota e não têm (com botão Emitir), notas com problema e números pulados. Para número pulado, toque em Inutilizar (pede sua senha) e informe o motivo.
Pacote do contador: escolha o mês e baixe a planilha com número, série, chave, valor e situação de cada nota, mais a lista de links dos XML. A Focus também baixa todos os XML do mês no painel dela.
Limite do plano: a tela mostra quantas notas já foram emitidas no mês (plano de 500); a 80% aparece um aviso na Saúde do sistema.', '{Admin}', true, '2026-10-11 05:34:21.230964+00', 'lista', 108, 'Só Administrador.'),
	(274, 'man-admin-99-assistente-grava-mais', 'Assistente: registrar coisas pelo chat', 'assistente ia registrar lançar despesa pagar estoque entrada perda inventário contagem ingrediente cliente ocorrência sangria compra receber cancelar ajuste pós-venda brinde confirmar cartão', 'Peça em frase normal, por exemplo: "comprei 3 kg de farinha do fornecedor X por R$ 20", "perdi 2 kg de farinha", "paguei R$ 120 de luz", "contei 12 kg de açúcar", "sangria de R$ 50 para troco".
O Assistente nunca grava sozinho: aparece um cartão com o que será gravado. Se faltar algo ou não achar o nome, o cartão avisa em laranja e o botão Confirmar fica travado.
Toque em "Confirmar e gravar" para gravar ou em "Descartar" para não gravar nada.
Pode registrar: compra, receber ou cancelar pedido de compra, fornecedor, despesa nova, pagar despesa, cancelar despesa, entrada/perda/contagem de estoque, cadastrar ou editar ingrediente, cliente, ocorrência, sangria, ajuste pós-venda e brinde.
Cancelar despesa e ajuste pós-venda pedem a senha de administrador no cartão.
Nunca pelo Assistente: excluir qualquer coisa, cancelar ou editar venda, abrir ou fechar caixa, usuários e senhas, contas e acessos, preços, cardápio e configurações. Faça nas telas.', '{Admin}', true, '2026-10-11 05:34:30.809322+00', 'lista', 99, 'Só Administrador e Desenvolvedor. Sangria e despesa do caixa exigem o caixa aberto.'),
	(275, 'man-admin-98-reembolsos', 'Reembolsos de vendas canceladas', 'reembolso reembolsos devolver devolução estorno venda cancelada paga pix dinheiro cartão pendente devolvido', 'Cancelou uma venda que já estava paga? O sistema cria sozinho um reembolso pendente.
Administrador → Dinheiro → Reembolsos e ajustes → "Reembolsos de vendas canceladas".
Devolva o dinheiro ao cliente (Pix, dinheiro ou estorno no cartão).
Toque em "marcar devolvido" e, se quiser, toque em como foi devolvido (Pix, Dinheiro ou Estorno no cartão).', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'lista', 98, 'Só o Administrador marca como devolvido; o Operador consegue ver a lista. Venda cancelada que ainda não estava paga não gera reembolso. Pedido do iFood cancelado não gera reembolso: quem devolve ao cliente é o iFood.'),
	(276, 'man-admin-97-listas-acoes', 'Listas: onde ficaram editar, entrada, perda e excluir', 'editar excluir entrada perda inventário desativar ativar botão sumiu três pontinhos ⋯ lista estoque produtos combos usuários ações assistente tex botão redondo modo desenvolvedor recolher', 'Nas listas de Estoque, Produtos, Combos e Usuários, toque na linha (ou no ⋯ no fim dela).
Abre uma janela com as ações: Editar, Entrada, Perda, Inventário, Excluir (no estoque) ou Editar, Desativar/Ativar, Excluir (nos usuários).
No produto e no combo, tocar na linha já abre a edição; o ⋯ mostra também Excluir.
O botão do Assistente é o rosto do Tex, redondo, no canto de baixo; os avisos aparecem no número 🔔 dele.
Entrada, perda e inventário abrem uma janela só, com a quantidade e o motivo juntos. Na perda, toque num motivo pronto (Estragou, Venceu…) ou escreva o seu.', '{Admin}', true, '2026-10-11 16:31:19.325087+00', 'lista', 97, 'A caixa do Modo Desenvolvedor fica recolhida numa linha; toque em ▸ para abrir.'),
	(277, 'man-admin-109-imposto-vendas', 'Imposto sobre vendas (estimado) e DAS', 'imposto alíquota aliquota simples das dre resultado margem lucro estimado contador taxa de entrega imposto das vendas', 'Administrador → Dinheiro → Relatórios e DRE → cartão "DRE e relatório mensal": escolha o mês e, em "Imposto sobre vendas deste mês", digite a alíquota que o contador informar (ex.: 6 ou 6,5) e toque em Salvar.
A alíquota vale para aquele mês e para os seguintes, até salvar outra. Mês sem alíquota própria usa a do mês anterior mais próximo; sem nenhuma, usa a dos dados fiscais da empresa.
O imposto é calculado sobre tudo o que foi faturado no mês (vendas e eventos) e aparece no DRE, na Visão Geral (IMPOSTOS), nos relatórios e na margem do cadastro de produto, de combo e da Calculadora. Funciona com ou sem a nota fiscal ligada. O custo do produto não muda.
DAS: lance o pagamento como despesa na categoria "Imposto das vendas (DAS)". Com alíquota cadastrada, ele não entra de novo nas despesas (o imposto já foi estimado); o DRE mostra quanto foi pago para comparar. Sem alíquota, o DAS entra como despesa comum.
O DRE mostra também a linha "Taxa de entrega e acréscimos cobrados": a taxa cobrada do cliente entra na receita e o repasse ao entregador entra nas despesas (Entregadores).', '{Admin}', true, '2026-10-16 03:03:49.796886+00', 'lista', 109, 'Só o Administrador vê e altera a alíquota. É uma estimativa; o valor oficial é o DAS calculado pelo contador.'),
	(278, 'man-admin-110-computador', 'No computador (notebook ou monitor)', 'computador notebook monitor pc tela grande menu lateral topo abas pedidos lado a lado caixa carrinho direita milhar', 'Em tela a partir de 900 px de largura, o topo fica numa linha só (logo à esquerda, usuário e botões à direita) e as abas ficam sempre à vista no alto, mesmo rolando a página.
Administrador: as telas aparecem num menu ao lado, com os 6 grupos abertos (Hoje, Dinheiro, Produtos, Vendas e cardápio, Loja e equipe, Sistema). O campo "Ir para…" no topo do menu acha uma tela pelo nome. Um clique abre a tela; se o menu não couber, role dentro dele. Para o Operador, a aba Operação mostra Ocorrências e Feedbacks no menu ao lado.
Pedidos: os pedidos ficam lado a lado (2 ou 3 por linha). Caixa: a escolha fica à esquerda; carrinho, total e pagamento ficam à direita.
Valores aparecem com ponto de milhar (R$ 1.475,90) e o negativo com o sinal na frente (−R$ 3.691,11).', '{Admin,Operador}', true, '2026-10-17 09:27:56.719023+00', 'lista', 110, 'Todas as funções do celular existem no computador: o que muda é só a organização da tela.'),
	(279, 'man-admin-111-visitas-cardapio', 'Tela Início e visitas ao cardápio', 'visitas cardápio acessos clientes abriram contador início resumo alerta faixa mesas', 'No Início: alerta numa faixa fina no topo (só quando há algo), pedidos em andamento, caixa e vendas de hoje, visitas ao cardápio e mesas (com o valor a receber das mesas).
"Cardápio hoje" conta os clientes que abriram o cardápio eletrônico hoje: cada celular ou computador conta 1 vez por dia. Zera à meia-noite.
Aparelhos da equipe não contam: depois que alguém entra no sistema interno naquele aparelho, ele nunca mais conta.
É uma estimativa: a mesma pessoa em dois aparelhos conta duas vezes; aba anônima ou navegador limpo contam de novo.', '{Admin,Operador}', true, '2026-10-11 23:17:22.096614+00', 'lista', 111, 'Administrador e Operador veem as visitas.'),
	(280, 'man-admin-98-cupons-contas', 'Cupons: editar, só para conta, automáticos e conta do cliente', 'cupom editar cupons automáticos boas-vindas aniversário indique e ganhe indicação conta cliente google login só para conta cliente específico texto privacidade lgpd cnpj razão social aviso anonimizar baixar dados apagar conta', 'Em Promoções, toque em Editar em qualquer cupom para mudar valor, prazo, limite ou texto.
Cupom pode ser só para quem tem conta, só para um cliente (escolha na lista) e pode aparecer em Minha conta do cliente.
No cartão Cupons automáticos ficam boas-vindas, aniversário e indique e ganhe (quem indicou e quem foi indicado). Todos começam desligados: toque em Editar, ajuste e ligue.
Boas-vindas e indicado valem 1 vez por cliente. Pedido cancelado devolve o cupom.
O cliente entra com o Google (opcional) em Entrar, no topo do cardápio. O histórico e o cartão fidelidade se juntam à conta depois do primeiro pedido concluído feito logado.
No fim de Promoções, o cartão Privacidade mostra as contas, guarda razão social e CNPJ (aparecem no Aviso quando preenchidos), muda o prazo para anonimizar clientes sem pedidos (padrão 3 anos) e publica nova versão do Aviso.
O cliente baixa os próprios dados e apaga a conta em Minha conta, Meus dados.', '{Admin}', true, '2026-10-12 01:28:20.904708+00', 'lista', 98, 'O endereço do Aviso de Privacidade para o Google está no cartão Privacidade (termina em ?privacidade=1).'),
	(281, 'man-admin-111-conta-cliente', 'Conta do cliente (login com Google) e privacidade', 'conta cliente login google entrar minha conta cadastro privacidade lgpd aviso aceite promoções endereços repetir pedido fidelidade indique ganhe indicação apagar conta exportar dados cnpj anonimizar', 'O cliente pode entrar com o Google pelo botão "Entrar" do cardápio. É opcional: quem não entra pede normalmente. Na primeira vez ele aceita o Aviso de Privacidade e, separado, escolhe se quer receber promoções.
Em "Minha conta" o cliente vê os pedidos (e repete um com um toque), o cartão fidelidade, os cupons, os endereços salvos, o link do "indique e ganhe" e a Privacidade (baixar os dados dele ou apagar a conta).
A conta só se junta ao histórico do cliente depois do primeiro pedido entregue ou retirado feito logado.
Administrador, em Promoções: cada cupom tem Editar; dá para marcar "só para quem tem conta", "só para um cliente", mostrar em "Minha conta" e escrever um texto para o cliente. Os cupons automáticos (boas-vindas, aniversário e indique e ganhe para quem foi indicado) começam desligados: ajuste o benefício e ligue.
Pedido cancelado devolve o cupom de conta ao cliente e não conta como uso; o brinde (prêmio) usado nele volta para o cliente.
No cartão Privacidade (LGPD) da mesma tela: razão social e CNPJ (em branco = não aparecem no aviso), prazo para anonimizar clientes parados (3 anos) e "Publicar nova versão do Aviso" (todos aceitam de novo).
Atenção: o telefone digitado no pedido não é verificado.
Brindes: marque os produtos-prêmio em Editar produto › Mais opções (Prêmio de fidelidade / Prêmio de indicação). Com o cartão fidelidade completo, o cliente escolhe o prêmio em "Minha conta" ou no carrinho. Quem indica ganha 1 brinde (a escolher entre os produtos marcados como prêmio de indicação) quando o amigo conclui o 1º pedido; se esse pedido for cancelado, o brinde some.
O brinde pode ir junto com outros itens ou sozinho: sai a R$ 0,00 (entra nos relatórios, com o custo, e baixa o estoque) e a entrega, se for entrega, é cobrada. Não há pedido mínimo. Pedido cancelado devolve o brinde. O botão Entrar/Minha conta fica numa faixa abaixo do banner do cardápio.', '{Admin,Operador}', true, '2026-10-12 02:23:19.545114+00', 'lista', 112, 'Sem conta, o cliente pede como sempre. No modo reserva não há login.'),
	(282, 'man-admin-112-feedback-resposta', 'Responder feedback do cliente (e feedback ligado à conta)', 'feedback responder resposta cliente conta reclamação elogio sugestão whatsapp respondido pedido estrelas anônimo', 'Hoje → Feedbacks (Operador: Atendimento → Feedbacks). Cada feedback mostra a nota, o comentário, o pedido (se houver) e se veio "👤 com conta" ou "sem conta".
Toque em "💬 Responder", escreva a resposta (até 1000 letras) e salve. O feedback vira "Respondido". Dá para editar a resposta depois.
Cliente COM conta: vê a sua resposta em Minha conta › Pedidos, no próprio pedido. Cliente SEM conta (anônimo ou sem login): a resposta fica só registrada; use o botão "WhatsApp" para falar com ele pelo telefone, quando ele deixou.
No cardápio, quem está com a conta ligada tem o botão "⭐ Feedback" em cada pedido (um feedback por pedido). O botão de feedback do rodapé continua funcionando para qualquer pessoa, com ou sem login.', '{Admin,Operador}', true, '2026-10-16 03:03:49.796886+00', 'lista', 113, 'Anônimo e sem telefone: não há como responder. A resposta é visível ao cliente só se ele deu o feedback logado na conta dele.'),
	(283, 'man-admin-113-leitor-fiscal', 'Ler nota fiscal ou cupom pelo Tex', 'nota fiscal cupom fiscal foto XML leitor fiscal Tex compra fornecedor estoque despesa financeiro', 'Abra Administrador → Pergunte à IA → Leitor Fiscal IA. Envie uma foto legível, um XML de NF-e ou cole o texto da nota. Confira emitente, CNPJ, data, chave, fornecedor, itens, quantidades e valores. A soma dos itens deve bater com o total. Só toque em Confirmar e lançar compra depois de conferir: a confirmação registra a compra e pode atualizar estoque e financeiro. A foto fica em armazenamento privado e é excluída automaticamente após 30 dias. Se a leitura falhar, digite os dados manualmente.', '{Admin,Operador}', false, '2026-10-16 09:38:48.893007+00', 'lista', 113, 'Não lance uma nota do próprio Texas Burger como compra. Nota repetida pela chave fiscal é bloqueada. Pagamento dividido deve ser conferido e lançado manualmente nesta versão.'),
	(284, 'man-admin-114-caixa-vencido', 'Caixa vencido', 'caixa vencido esqueci fechar liberar emergência fechamento atrasado corte venda bloqueada 06:00', 'O caixa vence no primeiro corte (padrão 06:00, horário de Brasília) depois de ter pelo menos 6 horas aberto, e nunca passa de 24 horas. Quando vence, venda nova de balcão e de mesa, sangria e resgate de prêmio ficam bloqueados. Preparar, despachar, entregar e receber pedidos já aceitos continuam livres. Pedidos do iFood e do cardápio continuam entrando e podem ser aceitos.
Fechar: Caixa → botão "Fechar caixa vencido" no fim da tela (Admin e Operador). Informe o dinheiro contado e, se quiser, o motivo. A diferença fica registrada como "fechamento atrasado" em Administrador → Dinheiro → Histórico → Sessões de caixa. O caixa só fecha sem mesas abertas, pedidos pendentes ou não recebidos.
Emergência (só Admin): "Liberar por algumas horas" (padrão 4 h, máximo 12 h), com motivo obrigatório. Fica na auditoria, avisa os Administradores e aparece na Visão Geral. Expira sozinho.
Aviso: a partir de 2 horas antes do corte aparece uma faixa no Início (com atalho para o Caixa) e no Caixa. O Admin ajusta a regra em Caixa → "Regra do caixa vencido" (embaixo do botão de fechar).
Garçom e Cozinha veem "caixa vencido, chame o responsável".', '{Admin,Operador}', true, '2026-10-16 21:46:37.03337+00', 'lista', 114, ''),
	(285, 'man-admin-115-mercado-pago', 'Mercado Pago (pagamento online)', 'mercado pago pix cartão online crédito débito pagamento online checkout webhook liberar pedido reembolsar chaves teste produção', 'Onde: Administrador → Sistema → Integrações e contas → 💳 Mercado Pago. O quadro "👉 Próximo passo" mostra o que falta fazer.
Configurar (quem faz é o dono): conta de vendedor verificada; aplicação com Checkout Transparente; chaves de TESTE (Public Key e Access Token); aviso (webhook) com o evento "Order (Mercado Pago)" e a chave secreta; teste guiado com Pix e cartão; só então as chaves de PRODUÇÃO e "Ligar em PRODUÇÃO".
Formas de pagamento pelo site: cada forma tem só duas opções, "Só na entrega" ou "Também online". Online vale para Pix, crédito e débito. A forma continua valendo na entrega, com os mesmos preços, taxas e acréscimos.
Ajustes: validade do Pix (5 a 120 minutos; combinado 15), e-mails que veem o pagamento online em TESTE e e-mail do comprador de teste.
No cardápio, o cliente precisa entrar com a conta para pagar pelo site. O pedido só entra como Pago depois da confirmação do Mercado Pago.
Pagamentos que precisam de decisão: se o dinheiro foi aprovado mas o pedido não entrou sozinho na cozinha, a lista aparece em Mercado Pago ("No dia a dia") e numa faixa discreta no Caixa. "Liberar pedido" envia para a cozinha; "Reembolsar" registra a decisão e chama o Mercado Pago para devolver. Confira o resultado antes de repetir uma tentativa.
Relatórios → "Mercado Pago — resumo do mês" mostra recebimentos e taxas do mês.', '{Admin}', true, '2026-10-17 09:27:56.719023+00', 'lista', 115, 'O pedido de teste aprovado vira pedido de verdade na cozinha e no caixa: avise a equipe e cancele depois.
Desligada, a integração faz o cardápio voltar a funcionar só com pagamento na entrega. Ligar e desligar pedem a senha de administrador.'),
	(286, 'man-admin-116-entregadores-fechamento', 'Entregadores: taxa e fechamento', 'entregadores taxa de entrega ajuda diária fechamento de entregadores pagar entregador fechar período fechamentos anteriores', 'Administrador → Loja e equipe → Entregadores e taxas.
Em "Taxa e ajuda diária", defina a taxa de entrega padrão e a ajuda diária do entregador e salve. A taxa é do cliente e vai 100% para o entregador. Mudanças valem só para pedidos e fechamentos futuros.
Em "Fechamento de entregadores", escolha o entregador e o dia e toque em Calcular. O total devido é as taxas das entregas concluídas do dia mais a ajuda diária (uma vez por dia).
Informe o valor pago e a forma: Dinheiro (sai da gaveta do caixa) ou Pix (não sai da gaveta). Se o valor pago for diferente do devido, a observação é obrigatória.
Toque em "Fechar período". Os fechamentos aparecem em "Fechamentos anteriores" e não mudam mais.', '{Admin}', true, '2026-10-17 09:27:56.719023+00', 'lista', 116, 'A ajuda diária conta uma vez por dia e só se houve entrega.
O valor pago ao entregador entra nas despesas (Entregadores) no DRE.
Se a conexão cair ao fechar, confira "Fechamentos anteriores" antes de tentar de novo, para não fechar duas vezes.'),
	(287, 'man-admin-117-clientes-perfil-360', 'Clientes: Perfil 360, segmentos e preferências fixas', 'clientes perfil 360 segmento novo fiel vip em risco ticket médio frequência itens favoritos preferências fixas sem cebola alergia conta google filtro', 'Clientes → toque no cliente. No topo do perfil, o Perfil 360 mostra o segmento (Novo, Fiel, VIP ou Em risco), gasto total, ticket médio, frequência, itens favoritos e se tem conta Google. Na lista, cada cliente tem o selo do segmento, e os filtros são Em risco, VIP, Fiéis e Novos.
Os pedidos antigos arquivados entram na conta, pelo telefone do cliente.
Preferências fixas (ex.: sem cebola, alergias): preencha no perfil do cliente. Cada pedido novo guarda uma cópia, e as preferências aparecem na tela da cozinha, na comanda impressa e nos detalhes do pedido.
O cliente com conta também edita as dele em Minha conta › Meus dados e as vê no checkout antes de pedir.', '{Admin,Operador}', true, '2026-10-17 09:27:56.719023+00', 'lista', 117, ''),
	(288, 'man-admin-118-cupons-risco-vip', 'Cupons automáticos: Sentimos sua falta e Cliente VIP', 'cupom automático sentimos sua falta cliente em risco 45 dias cliente vip aviso push promoções cupons automáticos', 'Administrador → Vendas e cardápio → Promoções e cupons → Cupons automáticos.
Há dois cupons para fidelizar: "Sentimos sua falta" (cliente em risco, mais de 45 dias sem pedir) e "Cliente VIP". Já vêm DESLIGADOS: ajuste o valor e ligue.
Só recebe quem tem conta Google e aceitou promoções. O cupom aparece em Minha conta do cliente.
Quem está em Em risco ou VIP também recebe um aviso (push) junto com o cupom, se tiver o aviso ligado no aparelho.', '{Admin}', true, '2026-10-17 09:27:56.719023+00', 'lista', 118, ''),
	(289, 'man-admin-119-formas-pagamento', 'Formas de pagamento (Taxas e prazos / No cardápio)', 'formas de pagamento taxas prazos no cardápio acréscimo ifood pagamento cardápio', 'Administrador → Vendas e cardápio → Formas de pagamento. É uma tela só, com duas abas: "Taxas e prazos" e "No cardápio" (o que o cliente vê).
Esta tela substituiu a antiga aba Pagamentos do Cardápio Digital.
Para pagamento online (Pix, crédito e débito), veja Mercado Pago em Integrações e contas.', '{Admin}', true, '2026-10-17 09:27:56.719023+00', 'lista', 119, '');


--
-- Data for Name: ai_config; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ai_config (id, ia_ligada, recursos, provedor_principal, provedor_reserva, modelo_gemini, modelo_groq, cota_diaria_global, cota_diaria_usuario, limite_por_minuto, cache_ttl_min, cota_diaria_operador, limite_por_minuto_operador, recursos_operador, atualizado_em, extras_publico, modelo_nvidia, modelo_cloudflare, modelo_groq_rapido) VALUES
	(true, true, '{"ajuda": true, "alertas": true, "compras": true, "pergunte": true, "anomalias": true, "conversar": true, "resumo_dia": true, "suporte_pedido": false}', 'gemini', 'groq', 'gemini-3.8-flash', 'qwen/qwen3.8-27b', 1200, 300, 10, 10, 150, 8, '{"ajuda": true, "conversar": true}', '2026-10-15 09:52:35.797135+00', true, 'nvidia/nemotron-3-super-120b-a12b', '@cf/meta/llama-3.3-70b-instruct-fp8-fast', 'llama-3.1-8b-instant');


--
-- Data for Name: ai_uso; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ai_uso (dia, provedor, usuario_id, chamadas, erros, tokens_in, tokens_out) VALUES
	('2026-10-07', 'gemini', '9866c7ad-b231-458d-aed3-34daa4d28268', 5, 0, 25564, 514),
	('2026-10-07', 'gemini', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 9, 5, 3701, 459),
	('2026-10-07', 'groq', '9866c7ad-b231-458d-aed3-34daa4d28268', 1, 1, 0, 0),
	('2026-10-07', 'groq', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 5, 3, 2013, 351),
	('2026-10-08', 'gemini', '9866c7ad-b231-458d-aed3-34daa4d28268', 7, 1, 47258, 329),
	('2026-10-08', 'gemini', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 23, 9, 62118, 1890),
	('2026-10-08', 'groq', '9866c7ad-b231-458d-aed3-34daa4d28268', 4, 3, 5555, 605),
	('2026-10-08', 'groq', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 10, 5, 13894, 751),
	('2026-10-10', 'gemini', '9866c7ad-b231-458d-aed3-34daa4d28268', 1, 1, 0, 0),
	('2026-10-10', 'gemini', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 1, 0, 9413, 176),
	('2026-10-10', 'groq', '9866c7ad-b231-458d-aed3-34daa4d28268', 1, 1, 0, 0),
	('2026-10-11', 'cloudflare', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 4, 2, 20091, 95),
	('2026-10-11', 'gemini', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 18, 8, 102869, 1179),
	('2026-10-11', 'groq', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 8, 8, 0, 0),
	('2026-10-11', 'nvidia', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 10, 4, 64475, 1964),
	('2026-10-14', 'gemini', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 2, 2, 0, 0),
	('2026-10-14', 'groq_2', '9866c7ad-b231-458d-aed3-34daa4d28268', 1, 1, 0, 0),
	('2026-10-14', 'groq', '9866c7ad-b231-458d-aed3-34daa4d28268', 1, 1, 0, 0),
	('2026-10-14', 'groq', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 3, 3, 0, 0),
	('2026-10-14', 'nvidia', '9866c7ad-b231-458d-aed3-34daa4d28268', 1, 0, 10917, 261),
	('2026-10-14', 'nvidia', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 3, 0, 32622, 906),
	('2026-10-17', 'cloudflare', '9866c7ad-b231-458d-aed3-34daa4d28268', 6, 0, 38592, 392),
	('2026-10-17', 'groq_2', '9866c7ad-b231-458d-aed3-34daa4d28268', 2, 1, 6188, 172),
	('2026-10-17', 'groq', '9866c7ad-b231-458d-aed3-34daa4d28268', 18, 5, 55449, 1459);


--
-- Data for Name: backup_config; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.backup_config (id, auto_retencao_dias, arquivar_ativo, arquivar_dias, atualizado_em, arquivar_emerg_ativo, arquivar_emerg_pct, arquivar_emerg_ultimo) VALUES
	(true, 7, true, 90, '2026-10-06 02:57:32.342839+00', true, 95, NULL);


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.usuarios (id, login, nome, telefone, nivel, ativo, criado_em) VALUES
	('6d7fc99c-2ef1-4a53-b9eb-7bf3904573af', 'Garçom', 'Garçom', NULL, 'Garçom', true, '2026-10-02 22:45:00+00'),
	('8e442ee3-af30-4da0-ae6c-0312d2ba9223', 'Entregador', 'Entregador', '11963260715', 'Entregador', true, '2026-10-02 22:45:00+00'),
	('9866c7ad-b231-458d-aed3-34daa4d28268', 'Lucas', 'Lucas', '16996224986', 'Desenvolvedor', true, '2026-10-04 22:57:55.168608+00'),
	('98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'Jonatan', 'Jonatan', NULL, 'Admin', true, '2026-10-02 22:45:00+00'),
	('a1c0b864-b517-4c9e-995c-42394e88fe93', 'Cozinha', 'Cozinha', NULL, 'Cozinha', true, '2026-10-02 22:45:00+00'),
	('a7fb2364-a458-439d-b92d-e7e9933bfba5', 'Caixa', 'Caixa', NULL, 'Operador', true, '2026-10-02 22:45:00+00');


--
-- Data for Name: caixa_sessoes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.caixa_sessoes (id, abertura, fundo_caixa, fechamento, total_vendas, total_despesas, saldo_final, status, usuario_abertura, usuario_fechamento, valor_contado, diferenca, fechamento_atrasado, fechamento_motivo) VALUES
	('05ec15c8-ab89-4b6a-9ab4-13967234bbd0', '2026-10-17 22:43:39.516616+00', 100.00, NULL, NULL, NULL, NULL, 'Aberto', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', NULL, NULL, NULL, false, NULL),
	('0ec2d360-347d-4dc3-a9a8-92d4f78a819f', '2026-10-07 02:32:45.967713+00', 100.00, '2026-10-08 10:08:54.579656+00', 244.65, 0.00, 252.35, 'Fechado', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 252.35, 0.00, false, NULL),
	('50028182-957b-44f4-a956-b8e8fb9e3fdc', '2026-10-09 18:00:26.998761+00', 100.00, '2026-10-11 11:27:38.630853+00', 162.40, 0.00, 169.80, 'Fechado', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 169.80, 0.00, false, NULL),
	('67b86bcb-d8f9-484b-b000-dc1d8f1bb35d', '2026-10-17 00:21:21.487453+00', 0.00, '2026-10-17 19:02:35.642203+00', 46.30, 0.00, 46.30, 'Fechado', '9866c7ad-b231-458d-aed3-34daa4d28268', '9866c7ad-b231-458d-aed3-34daa4d28268', 46.30, 0.00, true, 'Fechamento atrasado: o caixa passou do vencimento'),
	('b1d6e6f9-6e82-46b4-8806-f4068489d609', '2026-10-08 10:09:02.846924+00', 100.00, '2026-10-09 18:00:17.828062+00', 407.10, 0.00, 448.25, 'Fechado', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 448.25, 0.00, false, NULL),
	('b9c06550-b8fd-45b7-a71d-a1ba49c8c374', '2026-10-12 01:50:45.20275+00', 100.00, '2026-10-16 11:01:03.767106+00', 307.20, 24.00, 160.60, 'Fechado', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', '9866c7ad-b231-458d-aed3-34daa4d28268', 160.60, 0.00, true, 'Fechamento atrasado: o caixa passou do vencimento'),
	('d1389d31-dbff-4c37-89dd-fda22c72cc17', '2026-10-04 10:44:19.832464+00', 100.00, '2026-10-07 02:31:55.574164+00', 347.45, 0.00, 415.95, 'Fechado', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 415.95, 0.00, false, NULL);


--
-- Data for Name: categorias; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.categorias (id, nome, ativa, ordem, perfil_fiscal_id) VALUES
	('70d82bfd-93a0-42c6-b784-4bd736f0cdbc', 'Batata Recheada', true, 10, NULL),
	('71faeb28-1e76-45a9-a64a-a84bb0f8ed01', 'Churrasco', true, 7, NULL),
	('75ea8c91-31b4-4b8a-b57c-e1120e5e6835', 'Smash', true, 2, NULL),
	('83e31e11-3bae-40c8-a8c0-fb729b768581', 'Bebidas', true, 11, NULL),
	('979f1174-1624-4773-be8a-45a38bf79f69', 'Texas Gourmet', true, 3, NULL),
	('9a732021-a144-477b-9831-9f33a85c5f30', 'Porções', true, 8, NULL),
	('b5e9987e-d8e3-4dd7-b0c8-814770bd33df', 'Combos', true, 1, NULL),
	('c00a6047-f5a6-481e-8dd2-2e41b622854f', 'Kids', true, 9, NULL),
	('c1517d71-2845-4fd1-91e5-707c9e4d74ed', 'Hot Dog Gourmet', true, 4, NULL),
	('d4ec1678-47a4-4135-b9f3-fbb49b7f6e06', 'Lanches de Hambúrguer', true, 5, NULL),
	('f9386fbd-44ce-4f5b-a6db-3f75bf5f757c', 'Lanches de Frango', true, 6, NULL);


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.clientes (id, nome, telefone, data_nascimento, endereco, como_conheceu, primeiro_contato, observacoes, criado_em, preferencias) VALUES
	('2e619cfb-66c2-413c-a942-8f13e145dd74', 'Natália Ap Monteiro Cintra', '17997073419', NULL, NULL, NULL, '2026-10-18 01:28:58.76397+00', NULL, '2026-10-18 01:28:58.76397+00', NULL),
	('4c44d8c2-e528-4dd3-a9d9-91deffa68b3b', 'Lucas Ricardo', '(16) 99622-4986', '1995-12-28', 'Av Prudêncio Ortiz, 364, Jaboticabal', 'Outro', '2026-10-04 10:58:59.171+00', '', '2026-10-04 10:58:59.171+00', NULL),
	('56d0342b-5df3-489d-963d-37950fcd3eb9', 'Jonatan Fragoso', '11948559694', NULL, NULL, NULL, '2026-10-08 14:43:13.783366+00', NULL, '2026-10-08 14:43:13.783366+00', NULL),
	('6bcaeb27-093a-4863-b3c2-f1cb6d7dbf4f', 'Marlene Nogueira', '17981289270', NULL, NULL, NULL, '2026-10-17 22:52:23.372227+00', NULL, '2026-10-17 22:52:23.372227+00', NULL);


--
-- Data for Name: produtos; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.produtos (id, nome, descricao, categoria_id, ativo, destaque, estoque_proprio_ingrediente_id, ordem_cardapio, foto_id_principal, foto_id_contingencia, foto_url_principal, foto_url_contingencia, foto_preferida, premio_fidelidade, premio_indicacao, perfil_fiscal_id) VALUES
	('13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', 'Batata Recheada Frango Bacon e Catupiry', 'Frango, bacon, queijo, catupiry aveludado, creme de leite, batata palha — 500g', '70d82bfd-93a0-42c6-b784-4bd736f0cdbc', true, false, NULL, 7, '1ENBzff09seYkmpRi1ujkRk2cNHppl-ra', NULL, NULL, NULL, 'principal', false, false, NULL),
	('1658ebed-648f-4150-bf26-f50993a72243', 'Fritas Simples', 'Batatas em palito, crocantes', '9a732021-a144-477b-9831-9f33a85c5f30', true, false, NULL, 1, '1CAgJ-RxM8cE1izxACN7OY6hxDgOkTs0b', NULL, NULL, NULL, 'principal', false, false, NULL),
	('25b30ac0-81b5-46bd-b3ad-876b48a78251', 'Catupiry Bacon', 'Pão Brioche, 1 Hambúrguer 150gr, Disco Catupiry 100gr, Bacon, Mussarela, Alface, Tomate', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, NULL, 8, '1JSjDqCEs9W9-nyKuu4_clIswr81j8X48', NULL, NULL, NULL, 'principal', false, false, NULL),
	('2b54201e-9524-4e52-9615-53eef6fae6f6', 'Frango Bacon Catupiry', 'Pão, 250g frango, bacon crocante, catupiry cremoso, queijo, alface, tomate', 'f9386fbd-44ce-4f5b-a6db-3f75bf5f757c', true, false, NULL, 4, '1ukZ_aJ8EtKWWqKNXSf8kiAagh-aAZFqq', NULL, NULL, NULL, 'principal', false, false, NULL),
	('3338daa5-5f14-4236-92b6-1cee71c509b2', 'Batata Recheada Frango Cubano', 'Frango, bacon, milho, catupiry, queijo, batata palha — 500g', '70d82bfd-93a0-42c6-b784-4bd736f0cdbc', true, false, NULL, 2, '1Q2rLBOvxWoCxsnhrq1sgUWqsDh45zB53', NULL, NULL, NULL, 'principal', false, false, NULL),
	('37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', 'Frango Bacon', 'Pão, 250g frango crocante, bacon, queijo derretido, tomate, alface', 'f9386fbd-44ce-4f5b-a6db-3f75bf5f757c', true, false, NULL, 2, '1dzBZRkPisR3KQAXkP0cypnFMsS6ErI8W', NULL, NULL, NULL, 'principal', false, false, NULL),
	('3c8204c5-6801-49bb-9fec-5ecc6fbb26db', 'Texas Honey', '1 Hambúrguer 150gr, Cheddar, Bacon, mostarda com mel, Pão Brioche', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, NULL, 7, '1sLP3nhi1aB3hTN8lh204YRRqoQf3DAtl', '1TVLDYggmSx45o6GUm6YU69md4Vr_RlqZ', NULL, NULL, 'principal', false, false, NULL),
	('400ed17e-5cf0-4a76-ac12-8c3ca074103c', 'Barbecue Mister', '1 Hambúrguer 150gr, Queijo, Picles, Bacon, Barbecue, Cebola Crispy, Pão com gergelim', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, NULL, 2, '196JTEpKV5lOCxq7TIWDWeM4-LmBudfn2', '1jq8XbThGPYFDWm0dixcxRK4wyK7WjZ3R', NULL, NULL, 'principal', false, false, NULL),
	('4014c744-53bc-4148-8fcf-0799918e88aa', 'Cheddar', 'Pão Brioche, 1 Hambúrguer 150gr, Cheddar cremoso, Bacon, Cebola Caramelizada', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, NULL, 9, '1k9pwLeClQtkG7Rbk_2LtKoXNvLJzGSs3', '1UM8WGZfzS_uHmKesj2j8_kKS0zhsJSZ8', NULL, NULL, 'principal', false, false, NULL),
	('43087961-297c-4b43-8ddd-1484188baab2', 'Frango Salada', 'Pão macio, 250g frango, queijo derretido, tomate fresco, alface crocante', 'f9386fbd-44ce-4f5b-a6db-3f75bf5f757c', true, false, NULL, 6, '1ibXsUY6lu88EaFYdSESlley2s5Mm0r6R', NULL, NULL, NULL, 'principal', false, false, NULL),
	('4436ddb0-689e-4b7e-954a-faa1999288a7', 'X Bacon', 'Pão, hambúrguer 150g, bacon crocante, presunto, queijo, tomate, alface', 'd4ec1678-47a4-4135-b9f3-fbb49b7f6e06', true, false, NULL, 3, '1Rx5_H9ln2RekCvkiaVcQabI2xrFwK5Eh', NULL, NULL, NULL, 'principal', false, false, NULL),
	('50516989-1011-4b8c-bde9-9ed0750f4a07', 'Batata Recheada Presunto e Queijo', 'Presunto, Catupiry, creme de leite, batata palha — 500g', '70d82bfd-93a0-42c6-b784-4bd736f0cdbc', true, false, NULL, 5, '1upy_7gC6pK6tJe-YO8aFcv4x6cK7RZqH', NULL, NULL, NULL, 'principal', false, false, NULL),
	('59fc09ea-7730-40ef-b700-6388068e3ec8', 'Smash Catupiry', 'Pão de Brioche, Smash de 80 gr, Catupiry, queijo mussarela, alface', '75ea8c91-31b4-4b8a-b57c-e1120e5e6835', true, false, NULL, 1, '1LVyTh4_6kOxuZOUO2U1aoNgF694Tobnr', '1slx9iLM0-9_ZR_K2xX8ZeAUh2_LMtrp2', NULL, NULL, 'principal', false, false, NULL),
	('5a98547e-4cca-4a74-bc73-6822c3b8d069', 'Doguinho', 'Pão fofinho, salsicha, batata palha, ketchup, maionese', 'c00a6047-f5a6-481e-8dd2-2e41b622854f', true, false, NULL, 3, '1PozA6pupVNjejKTosAywaAuhqeil7lmU', NULL, NULL, NULL, 'principal', false, false, NULL),
	('5c9f187f-de24-4615-9042-78e1773e904b', 'Batata Recheada Carne e Queijo Contra Filé', 'Carne suculenta, queijo derretido, batata palha — 500g', '70d82bfd-93a0-42c6-b784-4bd736f0cdbc', true, false, NULL, 4, '13cIQLF-kFtORkU62G8T0D2ov9mvzWW89', NULL, NULL, NULL, 'principal', false, false, NULL),
	('5f5533e0-5760-4edd-a22d-9122097da388', 'Batata Recheada Frango Bacon', 'Frango, bacon crocante, queijo, creme de leite, batata palha — 500g', '70d82bfd-93a0-42c6-b784-4bd736f0cdbc', true, false, NULL, 1, '1KfrYAoFBr8g-p8wDWgwHDN-9Bihn5V27', NULL, NULL, NULL, 'principal', false, false, NULL),
	('5fb6f8d6-49ed-4587-be09-333b67419ac0', 'X Tudo Especial', 'Pão, hambúrguer 150g, bacon, milho, salsicha, ovo, batata palha, catupiry, queijo, presunto, tomate', 'd4ec1678-47a4-4135-b9f3-fbb49b7f6e06', true, false, NULL, 7, '1I0R8XIvO_64XezzKw45tz2uDgAHsYkX9', NULL, NULL, NULL, 'principal', false, false, NULL),
	('60a58561-6800-44b4-8074-d70d035bb1a2', 'X Tudo', 'Pão, hambúrguer 150g, bacon, salsicha, ovo, presunto, queijo, tomate, alface', 'd4ec1678-47a4-4135-b9f3-fbb49b7f6e06', true, false, NULL, 6, '1pMPcOU9XoEMStOhXrtCpq9xp8QPr9EaO', NULL, NULL, NULL, 'principal', false, false, NULL),
	('63841581-68f3-4cfa-bc81-c78466e5ec5b', 'Fritas 3 Queijos', 'Batata com mussarela, catupiry e cheddar', '9a732021-a144-477b-9831-9f33a85c5f30', true, false, NULL, 2, '1THRYbwe3Caow1a8n39MDYWINrYaslN0v', NULL, NULL, NULL, 'principal', false, false, NULL),
	('64142b67-ba38-41fe-8e46-68213b65a342', 'Picles Cheddar', '1 Hambúrguer 150gr, Cheddar, Alface, Tomate, Cebola Roxa, Picles', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, NULL, 6, '1usHPUJkAcFX9kBBNtYDT1wMz_xYy6qXR', '1bbiZ_gg-hfC7YGIi2NguVNR8Uuj_vq-e', NULL, NULL, 'principal', false, false, NULL),
	('65226aff-26be-4bbe-9222-62cd159ba207', 'X Picanha', 'Pão Brioche, Hambúrguer 150gr de Picanha, Queijo, Rúcula, Tomate', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, NULL, 10, '1XAp01s7FPJzzMDvhrtW-VIqbgtbxh6tu', '1YJjCSjFwNrJFnwr0bFyIPVLqFJ_o40fp', NULL, NULL, 'principal', false, false, NULL),
	('69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', 'X Salada', 'Pão, hambúrguer 150g, presunto, queijo, tomate, alface', 'd4ec1678-47a4-4135-b9f3-fbb49b7f6e06', true, false, NULL, 1, '1HIIOXWOSYv4TRTbYBVvMZnqPkdAJI9jL', '12g_TVnWCga0Aln4jGyw5tfYvcTeaQj49', NULL, NULL, 'principal', false, false, NULL),
	('717f21cc-de1d-4881-942a-4601e8bf45f0', 'Frango Cubano', 'Pão, 250g frango, milho, batata palha, catupiry cremoso, queijo, alface, tomate', 'f9386fbd-44ce-4f5b-a6db-3f75bf5f757c', true, false, NULL, 5, '1rtd5hwUlMGmhw44d-YPDEGBmtky-_Jh7', NULL, NULL, NULL, 'principal', false, false, NULL),
	('71b73436-5512-4ba4-9719-541b70aec6e0', 'Smash Cheddar', 'Pão de Brioche, Smash de 80 gr, queijo cheddar e cebola caramelizada', '75ea8c91-31b4-4b8a-b57c-e1120e5e6835', true, false, NULL, 2, '1UnVGAUDP0FM___2u2ea1Oa6fiAXtdWOK', '1Ex2UmADdguv4EdIVu4u0_N5khgEMu8WX', NULL, NULL, 'principal', false, false, NULL),
	('7583e038-e58c-41a8-867c-026f1b90d787', 'Duplo Cheddar', 'Dois hambúrgueres 150g, duplo cheddar, bacon, cebola caramelizada, molho da casa', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, NULL, 5, '1ybRL42WdaZrvAWftJDSTfhqCfeOQOT7z', '1LktBGE0f7WH5_WCXpdDCxD3vgtVEaKfb', NULL, NULL, 'principal', false, false, NULL),
	('76ec1153-89e4-46e4-9c3d-a953e37e6f92', 'Batata Recheada Churrasco Cubano Contra Filé', 'Carne, bacon, milho, catupiry, queijo, batata palha — 500g', '70d82bfd-93a0-42c6-b784-4bd736f0cdbc', true, false, NULL, 3, '1a1hXtPnqURUwJl0iOryJChqnfiXehTpZ', NULL, NULL, NULL, 'principal', false, false, NULL),
	('7fa58aa9-40e3-4a45-b314-ad9086d83d26', 'Coca Cola 2L', NULL, '83e31e11-3bae-40c8-a8c0-fb729b768581', true, false, '435cdc1d-1800-4d38-84ad-3ba22fc809eb', 5, '1jV-S9IIkQuXnQ5nVs_ev5gchpVm4ocVp', NULL, NULL, NULL, 'principal', false, false, NULL),
	('8581a904-a689-4535-8ffd-0faef973e9a1', 'Smash Tasty', 'Pão de Brioche, Smash de 80 gr, queijo mussarela, alface e tomate', '75ea8c91-31b4-4b8a-b57c-e1120e5e6835', true, false, NULL, 3, '1IggiM5rCWvFV-_Z1jhIGxOq8xTHpJU6y', '1eI_k-KAplzVX9avr8saWMkCFX9g1gT1v', NULL, NULL, 'principal', false, false, NULL),
	('86519e93-90e6-4174-b509-136cf9f43430', 'Hamburguinho', 'Mini hambúrguer com queijo derretido', 'c00a6047-f5a6-481e-8dd2-2e41b622854f', true, false, NULL, 2, '1MraEirgXhQQjWf51pthK8NX6vhKLeZGb', NULL, NULL, NULL, 'principal', false, false, NULL),
	('8e155a9a-175c-4fb8-890e-97409b2953c8', 'Fritas C C B', 'Batata com cheddar cremoso, catupiry e bacon crocante', '9a732021-a144-477b-9831-9f33a85c5f30', true, false, NULL, 3, '15uSX4RUYIrUPrwgZrdVaKvgIKTRMoS76', NULL, NULL, NULL, 'principal', false, false, NULL),
	('9288b06c-ad35-4e4b-99d1-845cd2fd8b72', 'X Costela', 'Pão com Gergelim, Hambúrguer 150gr de Costela, Queijo, Rúcula, Tomate', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, NULL, 11, '1dMgFEq6tmX0uF8COlYoeo0gsUAM9bUf-', '1Zc-2CgLcD3OVlrNxL6BfsUTg8rn6atQJ', NULL, NULL, 'principal', false, false, NULL),
	('93ea5ac0-5b1f-42ce-9289-478820d9108d', 'Frango Catupiry', 'Pão, 250g frango, catupiry cremoso, queijo, alface, tomate', 'f9386fbd-44ce-4f5b-a6db-3f75bf5f757c', true, false, NULL, 3, '1cHY-FrqZsCgcU_3ms14u3GKf1DafXuYH', NULL, NULL, NULL, 'principal', false, false, NULL),
	('a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', 'Fritas Especial Texas', 'Batata com carne, frango, catupiry, cheddar, bacon e mussarela', '9a732021-a144-477b-9831-9f33a85c5f30', true, false, NULL, 5, '1DRDNifTtf4RrTa-THW_jqY2gxqTwl4DE', NULL, NULL, NULL, 'principal', false, false, NULL),
	('b8cfab2c-856b-40b0-870b-a36cfe11ef96', 'X Texas', '1 Hambúrguer 200gr linguiça, Queijo, Rúcula, Tomate, Geleia de pimenta', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, NULL, 4, '14NNXcOfgt4bCts2x7Uxr1LjFcjeEJvTV', '1F_3vHKJeLiJ0--hci1Pp3O0aTkNmQKUR', NULL, NULL, 'principal', false, false, NULL),
	('bf6331a3-74f5-44bb-8b82-635a399c4878', 'Frango a Passarinho', NULL, '9a732021-a144-477b-9831-9f33a85c5f30', true, false, NULL, 6, NULL, NULL, NULL, NULL, 'principal', false, false, NULL),
	('c5a83fe3-5587-42ea-a160-c16f3b83d2d8', 'Fritas Cheddar Bacon', 'Batata com cheddar cremoso e bacon crocante', '9a732021-a144-477b-9831-9f33a85c5f30', true, false, NULL, 4, '1-Kp-LShm0fcBsuWM8hh6GzxCBIq2yCGd', NULL, NULL, NULL, 'principal', false, false, NULL),
	('c5d1d013-4b5d-4006-892b-d41292f3a1f7', 'X Egg Bacon', 'Pão, hambúrguer 150g, dois ovos, bacon crocante, presunto, queijo, tomate, alface', 'd4ec1678-47a4-4135-b9f3-fbb49b7f6e06', true, false, NULL, 5, '1Jn7XsRS_4yEwtJZn3c4KNDMcsVMn4NEI', NULL, NULL, NULL, 'principal', false, false, NULL),
	('d0bb7b9e-1857-446c-9e61-48e7c23f51e2', 'Churrasco Tudo', 'Carne suculenta, ingredientes completos', '71faeb28-1e76-45a9-a64a-a84bb0f8ed01', true, false, NULL, 1, '1FcCapQ4d3lTiKpjlZKcDJsICaErVS9qz', NULL, NULL, NULL, 'principal', false, false, NULL),
	('d44c0f41-cdf3-428b-bb6d-8e960a22529d', 'X Burguer', 'Pão, hambúrguer 150g, presunto, queijo, tomate', 'd4ec1678-47a4-4135-b9f3-fbb49b7f6e06', true, false, NULL, 2, '1OEeJscM13vY0Dxcp-oxJz_IHnLgfOowx', '1yRwFTmtqh6Si-5bPd8O8RCb9nzagTWHJ', NULL, NULL, 'principal', false, false, NULL),
	('d84ddbbc-8922-419f-8d2c-0a94b2e123a2', 'Franguinho', 'Mini lanche frango empanado com queijo', 'c00a6047-f5a6-481e-8dd2-2e41b622854f', true, false, NULL, 1, '1qMX-gGVQuq-68yLVLSCEjbVvQtqep7uK', NULL, NULL, NULL, 'principal', false, false, NULL),
	('d96d6d4d-a32d-461f-ad10-d6bac52fc729', 'Onion Texas', '1 Hambúrguer 150gr, Queijo, Bacon, Anéis de Cebola, Barbecue, Picles', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, NULL, 3, '1My-eTcUxof1qzOx5KmDUSjnt589AUDjm', '12X66B6lZbdXzdi-xfbtu7dhRvaF55PD0', NULL, NULL, 'principal', false, false, NULL),
	('dbdba3e8-488c-4eca-b84c-108ba9de45ba', 'Coca Cola Zero 1L', NULL, '83e31e11-3bae-40c8-a8c0-fb729b768581', true, false, '4d1aed3a-dd06-4519-bbf4-db2c174db59a', 4, '1dU3WbDn4CWPk6tsjV2ZrI87Km4Y8eC-2', NULL, NULL, NULL, 'principal', false, false, NULL),
	('dca3fa98-20e5-487f-a479-5920c7783cab', 'X Egg', 'Pão, hambúrguer 150g, dois ovos fritos, presunto, queijo, tomate, alface', 'd4ec1678-47a4-4135-b9f3-fbb49b7f6e06', true, false, NULL, 4, '1N2LeFVzTczxJt8vhDkmqAcXfa4GUK16y', NULL, NULL, NULL, 'principal', false, false, NULL),
	('e2582ee2-3930-41e3-89b4-fc0a517ad88e', 'The Master Dog', 'Pão de cachorro-quente, salsicha, bacon, molho especial, picles e cebola', 'c1517d71-2845-4fd1-91e5-707c9e4d74ed', true, false, NULL, 2, '1EStQi7J4ZVJFia8ttth6RJeATMPz43ok', NULL, NULL, NULL, 'principal', false, false, NULL),
	('e5708074-2b1a-41f3-a9fe-a3a954ecc8e1', 'Coca Cola Zero 2L', NULL, '83e31e11-3bae-40c8-a8c0-fb729b768581', true, false, 'a00860db-8d18-4c79-af74-783b3025f6d3', 6, '1ZE30p1_82-oHF7E8KI291Xw1wCA42hbR', NULL, NULL, NULL, 'principal', false, false, NULL),
	('e9243992-5df7-4cfc-82cd-b8ee1d02e69f', 'Batata Recheada Brócolis e Bacon', 'Brócolis frescos, bacon defumado, queijo, batata palha — 500g', '70d82bfd-93a0-42c6-b784-4bd736f0cdbc', true, false, NULL, 6, '1tuLsi7hYfwpMDv8C4cYpM25z9Sm2FYGP', NULL, NULL, NULL, 'principal', false, false, NULL),
	('ee5b570a-759c-42aa-929b-efb390436f1a', 'Burguer Rustic', '1 Hambúrguer 150gr, Queijo, Bacon, Rúcula, Geleia de Pimenta, Pão com gergelim', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, NULL, 1, '1PxZEtjdgU9dq9WYrvG4NyviG5NrAJ7g7', '1W9xTBv_a-ZYsnKXG6ov7I_yoweWI0IrX', NULL, NULL, 'principal', false, false, NULL),
	('f4bc7c7f-14c6-42af-ad10-ea3740840d94', 'Nacho Dog Texas', 'Pão de cachorro-quente, salsicha, bacon, muito cheddar e cebola caramelizada', 'c1517d71-2845-4fd1-91e5-707c9e4d74ed', true, false, NULL, 1, '1iz9aQkSbJci10foup0NlQTLt859_Cl3L', NULL, NULL, NULL, 'principal', false, false, NULL),
	('f6777e04-f0b8-442f-ac33-ae1af4752932', 'Coca Cola Zero Lata 350ml', NULL, '83e31e11-3bae-40c8-a8c0-fb729b768581', true, false, '52c73474-5488-4404-8887-65a706905f3e', 2, '1M5EXuRz3FvwkLRT94fsNopIezhFFz3LO', NULL, NULL, NULL, 'principal', false, false, NULL),
	('f8f7cef0-be70-4335-99e0-53dd3ad00b45', 'Frango Egg', 'Pão, 250g frango, ovo, queijo, alface, tomate', 'f9386fbd-44ce-4f5b-a6db-3f75bf5f757c', true, false, NULL, 1, '1qNe7ytoI4MiwlM_o5co4zU5ysqlKc5QL', NULL, NULL, NULL, 'principal', false, false, NULL),
	('fb1ad5ae-9041-4688-accc-2745ff3b8550', 'Coca Cola 1L', NULL, '83e31e11-3bae-40c8-a8c0-fb729b768581', true, false, '0502d2f5-70c8-44f3-920b-ee10f22c8ef3', 3, '1aAoqO6LkwjCLUwNGtWoM8ucIotgKi4Ox', NULL, NULL, NULL, 'principal', false, false, NULL),
	('fb925849-fdb1-45d4-8e7f-8a3b57084595', 'Coca Cola Lata 350ml', NULL, '83e31e11-3bae-40c8-a8c0-fb729b768581', true, false, 'd77e9f66-dc34-4636-ab5d-96fbb51b21fa', 1, '1VIaC_VNdkTrNkdGGBUZ2V_2DluIQnzgS', NULL, NULL, NULL, 'principal', false, false, NULL);


--
-- Data for Name: brindes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.brindes (id, data_hora, tipo, cliente_id, cliente_nome, telefone, indicacao_id, produto_id, produto_nome, custo, consumo, caixa_id, despesa_id, registrado_por, requisicao_id, cancelado_em, motivo_cancelamento) VALUES
	('a1ac945f-0d30-4326-af97-61130bf7f5c2', '2026-10-09 01:31:27.4292+00', 'Fidelidade', '4c44d8c2-e528-4dd3-a9d9-91deffa68b3b', 'Lucas Ricardo', '(16) 99622-4986', NULL, '4436ddb0-689e-4b7e-954a-faa1999288a7', 'X Bacon', 0.00, '[]', 'b1d6e6f9-6e82-46b4-8806-f4068489d609', NULL, '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'r-1791509487249-xrsgxuyd', NULL, NULL),
	('baefc2f2-b19a-432c-a706-c4fa12d3f9fb', '2026-10-09 01:31:43.482337+00', 'Indicação', '4c44d8c2-e528-4dd3-a9d9-91deffa68b3b', 'Lucas Ricardo', '(16) 99622-4986', '06f97979-b6f2-411c-b71a-e30012e3c398', '4436ddb0-689e-4b7e-954a-faa1999288a7', 'X Bacon', 0.00, '[]', 'b1d6e6f9-6e82-46b4-8806-f4068489d609', NULL, '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'r-1791509503319-pq5mg3l9', NULL, NULL);


--
-- Data for Name: caixa_config; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.caixa_config (id, corte_hora, vida_minima_horas, teto_horas, aviso_horas, liberacao_padrao_horas, liberacao_max_horas, atualizado_em) VALUES
	(true, '06:00:00', 6, 24, 2, 4, 12, '2026-10-16 02:20:22.552275+00');


--
-- Data for Name: cardapio_visitas; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.cardapio_visitas (dia, aparelho, criado_em) VALUES
	('2026-10-11', '190658e92c57ae39b7f29b18', '2026-10-12 00:45:35.683001+00'),
	('2026-10-11', '35c81f8c0bc2e6f29ce4c1db', '2026-10-12 02:46:24.816694+00'),
	('2026-10-11', '46267688d8bc5c9ad2bb39ea', '2026-10-12 01:40:35.635187+00'),
	('2026-10-11', '523c69f2323e20a3dbbf8708', '2026-10-11 23:26:55.183829+00'),
	('2026-10-11', '5e79485b7f4460516cab3485', '2026-10-12 00:45:34.976967+00'),
	('2026-10-12', '0fb1c1ac4cbeee30b5ec3edc', '2026-10-12 13:51:39.817083+00'),
	('2026-10-12', '35c81f8c0bc2e6f29ce4c1db', '2026-10-12 20:48:22.436536+00'),
	('2026-10-16', '3453b3fb1a93b224f7f82743', '2026-10-16 19:09:13.716684+00'),
	('2026-10-16', '68063e36af90435c85b9b5f9', '2026-10-16 16:01:14.417884+00'),
	('2026-10-16', 'd7720dc50ad5f6284759ccf0', '2026-10-16 16:01:17.642482+00'),
	('2026-10-17', '4d6258611040c51cd67169e5', '2026-10-17 22:49:45.25997+00'),
	('2026-10-17', '5334c734124b612f29360c28', '2026-10-17 23:43:52.44027+00'),
	('2026-10-17', '56dcbd709231f6ae642b64ed', '2026-10-18 01:26:12.078814+00'),
	('2026-10-17', '5ef33ac8b47d33b613aab737', '2026-10-17 22:50:31.696616+00'),
	('2026-10-17', '6c575da63e2a9b61199c5017', '2026-10-17 23:43:06.820869+00'),
	('2026-10-17', '76e6ffa6a42863a477149aca', '2026-10-17 23:16:09.781011+00'),
	('2026-10-17', '878c8a1d21be118e36fe9a1f', '2026-10-17 19:41:38.667408+00'),
	('2026-10-17', 'a05199d898a99c9a25307e73', '2026-10-17 23:43:12.539401+00'),
	('2026-10-17', 'e97584e0fbabcaaf315c4850', '2026-10-18 00:22:52.152422+00');


--
-- Data for Name: chat_config; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.chat_config (id, chat_publico_ligado, ia_publica_cota_dia, janela_horas, atualizado_em) VALUES
	(true, true, 200, 48, '2026-10-08 09:41:03.954366+00');


--
-- Data for Name: fechamentos_entrega; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.fechamentos_entrega (id, data_ref, entregador_id, qtd_entregas, total_taxas, ajuda_diaria, total_devido, valor_pago, diferenca, fechado_em, fechado_por, observacao, requisicao_id, forma_pagamento) VALUES
	('0fb76783-1aba-4a82-9099-3f5fc4b19e68', '2026-10-11', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 3, 24.00, 0.00, 24.00, 24.00, 0.00, '2026-10-13 02:57:23.738794+00', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', NULL, 'a6ba15ef-c2c5-4894-a654-d59b3ea91fda', 'Dinheiro'),
	('161f7b31-021e-4894-8f7f-10ded06e50f7', '2026-10-10', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 1, 8.00, 0.00, 8.00, 8.00, 0.00, '2026-10-11 11:27:38.630853+00', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'Fechamento automático ao fechar o caixa', 'auto-50028182-957b-44f4-a956-b8e8fb9e3fdc-entregador-2026-10-10', NULL),
	('410c0bd5-aebe-4777-957b-2ca6a8f2edf4', '2026-10-04', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 4, 124.00, 0.00, 124.00, 124.00, 0.00, '2026-10-07 02:31:55.574164+00', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'Fechamento automático ao fechar o caixa', 'auto-d1389d31-dbff-4c37-89dd-fda22c72cc17-entregador-2026-10-04', NULL),
	('5f870beb-71d5-48a8-9494-5efae0707ee3', '2026-10-07', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 4, 32.00, 0.00, 32.00, 32.00, 0.00, '2026-10-08 10:08:54.579656+00', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'Fechamento automático ao fechar o caixa', 'auto-0ec2d360-347d-4dc3-a9a8-92d4f78a819f-entregador-2026-10-07', NULL),
	('7ee423d4-c8e0-494a-b0b5-b8d634232720', '2026-10-15', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 1, 8.00, 0.00, 8.00, 8.00, 0.00, '2026-10-16 11:01:03.767106+00', '9866c7ad-b231-458d-aed3-34daa4d28268', 'Fechamento automático ao fechar o caixa', 'auto-b9c06550-b8fd-45b7-a71d-a1ba49c8c374-entregador-2026-10-15', NULL),
	('8b8d316e-3a41-42af-92f2-e49ccf3b173b', '2026-10-08', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 6, 48.00, 0.00, 48.00, 48.00, 0.00, '2026-10-09 18:00:17.828062+00', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'Fechamento automático ao fechar o caixa', 'auto-b1d6e6f9-6e82-46b4-8806-f4068489d609-entregador-2026-10-08', NULL),
	('90255aa3-2c98-4606-8e58-aa375edfcb2c', '2026-10-11', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 2, 16.00, 0.00, 16.00, 16.00, 0.00, '2026-10-11 11:27:38.630853+00', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'Fechamento automático ao fechar o caixa', 'auto-50028182-957b-44f4-a956-b8e8fb9e3fdc-entregador-2026-10-11', NULL),
	('ccf797a2-9f29-41ea-ac02-cd59387c490d', '2026-10-16', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 1, 8.00, 0.00, 8.00, 8.00, 0.00, '2026-10-17 19:02:35.642203+00', '9866c7ad-b231-458d-aed3-34daa4d28268', 'Fechamento automático ao fechar o caixa', 'auto-67b86bcb-d8f9-484b-b000-dc1d8f1bb35d-entregador-2026-10-16', NULL),
	('df178e7d-e20e-4318-b085-108459696865', '2026-10-08', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 1, 8.00, 0.00, 8.00, 8.00, 0.00, '2026-10-08 10:08:54.579656+00', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'Fechamento automático ao fechar o caixa', 'auto-0ec2d360-347d-4dc3-a9a8-92d4f78a819f-entregador-2026-10-08', NULL);


--
-- Data for Name: mesas; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.mesas (id, numero, status, capacidade, observacao, garcom_responsavel_id, chamado_tipo, chamado_em) VALUES
	('6ce68177-48f7-4aad-a759-96034c371d5f', '1', 'Livre', 4, NULL, NULL, NULL, NULL);


--
-- Data for Name: vendas; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.vendas (id, numero_pedido, data_hora, cliente_id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, motivo_cancelamento, tipo, status_pedido, endereco, complemento, referencia, observacoes_entrega, pronta_em, concluida_em, status_pagamento, recebido_em, valor_original, valor_desconto, desconto_detalhe, entregador_id, saiu_em, origem, mesa_id, taxa_entrega, fechamento_entrega_id, registrado_por, inicio_preparo_em, caixa_id, requisicao_id, status_antes_suspensao, acrescimo_forma, canal, cpf_nota, preferencias_cliente) VALUES
	('04903c16-fbda-434c-8b0e-5257b533b932', 198, '2026-10-17 00:22:25.119322+00', NULL, 'Lucas Ricardo', '16996224986', 'Dinheiro', 46.30, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz, Parque 1º de Maio, nº 364 — Jaboticabal - SP', '', '', '', '2026-10-17 00:24:46.393661+00', '2026-10-17 01:44:40.110172+00', 'Pago', '2026-10-17 01:44:42.408432+00', 38.30, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-17 01:44:38.289438+00', 'Cardápio', NULL, 8.00, 'ccf797a2-9f29-41ea-ac02-cd59387c490d', NULL, '2026-10-17 00:23:18.027381+00', '67b86bcb-d8f9-484b-b000-dc1d8f1bb35d', 'r-1792196545044-cze4ti54', NULL, 0.00, NULL, NULL, NULL),
	('0e4f13c6-1149-4547-a29c-0cc48ae7af93', 152, '2026-10-14 22:38:13.675823+00', NULL, 'Jonatan Fragoso', '11948559694', 'Dinheiro', 46.30, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Rua Rubião Junior, Centro, nº 1345 — Bebedouro - SP', '', '', 'Troco para R$ 1000.00', '2026-10-15 23:17:06.966794+00', '2026-10-15 23:17:14.096787+00', 'Pago', '2026-10-15 23:17:18.375969+00', 38.30, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-15 23:17:07.92845+00', 'Cardápio', NULL, 8.00, '7ee423d4-c8e0-494a-b0b5-b8d634232720', NULL, '2026-10-14 22:38:52.349433+00', 'b9c06550-b8fd-45b7-a71d-a1ba49c8c374', 'r-1792017491738-436r04n5', NULL, 0.00, NULL, NULL, NULL),
	('13b25d4d-0082-46dd-89f0-dc07aa3ac932', 2, '2026-10-04 11:01:57.404999+00', NULL, 'Lucas Ricardo', '(16) 99622-4986', 'Dinheiro', 39.65, 0.00, 'Confirmada', NULL, 'Retirada', 'Retirada', '', '', '', '', '2026-10-04 11:34:29.196433+00', '2026-10-04 11:34:30.627451+00', 'Pago', '2026-10-04 11:01:57.404999+00', 79.30, 39.65, '50% (R$ 39.65)', NULL, NULL, 'Balcão', NULL, 0.00, NULL, 'a7fb2364-a458-439d-b92d-e7e9933bfba5', NULL, 'd1389d31-dbff-4c37-89dd-fda22c72cc17', 'r-1791111717593-0vr6g04i', NULL, 0, NULL, NULL, NULL),
	('15ff779b-e968-4947-9e6d-4755d1dd62ff', 114, '2026-10-11 11:03:03.278353+00', NULL, 'Lucas Ricardo', '16996224986', 'Cartão de Débito', 46.30, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz, Parque 1º de Maio, nº 364 — Jaboticabal - SP', '', '', '', '2026-10-11 11:05:12.040161+00', '2026-10-11 11:05:56.605657+00', 'Pago', '2026-10-11 11:06:05.79171+00', 38.30, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-11 11:05:17.267795+00', 'Cardápio', NULL, 8.00, '90255aa3-2c98-4606-8e58-aa375edfcb2c', NULL, '2026-10-11 11:04:16.779344+00', '50028182-957b-44f4-a956-b8e8fb9e3fdc', 'r-1791716582934-klbzvv1k', NULL, 0.00, NULL, NULL, NULL),
	('1823af77-ffad-41cf-83bc-9cc01499649e', 151, '2026-10-13 00:01:44.133909+00', NULL, 'Lucas Ricardo', '(16) 99622-4986', 'Dinheiro', 38.30, 0.00, 'Confirmada', NULL, 'Retirada', 'Retirada', '', '', '', '', '2026-10-13 00:02:18.898986+00', '2026-10-13 00:02:25.240266+00', 'Pago', '2026-10-13 00:01:44.133909+00', 38.30, 0.00, '', NULL, NULL, 'Balcão', NULL, 0.00, NULL, '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', NULL, 'b9c06550-b8fd-45b7-a71d-a1ba49c8c374', 'r-1791849704204-z1jz0pal', NULL, 0.00, NULL, NULL, NULL),
	('1b5d1529-bca4-452b-b658-0d6799f4c644', 75, '2026-10-07 03:07:21.013653+00', NULL, 'Lucas', '16996224986', 'Cartão de Crédito', 46.30, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz, 364', '', '', '', '2026-10-07 03:08:35.931996+00', '2026-10-07 03:29:05.255611+00', 'Pago', '2026-10-07 03:30:28.760999+00', 38.30, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-07 03:08:37.318441+00', 'Cardápio', NULL, 8.00, '5f870beb-71d5-48a8-9494-5efae0707ee3', NULL, NULL, '0ec2d360-347d-4dc3-a9a8-92d4f78a819f', 'r-1791342440896-fdj0auuq', NULL, 0, NULL, NULL, NULL),
	('2136dcd6-6c45-4e2d-a99e-2ea84dd5c3fb', 81, '2026-10-08 10:11:34.424276+00', NULL, 'Lucas Ricardo', '16996224986', 'Dinheiro', 47.00, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz, 364 , Jaboticabal', '', '', '', '2026-10-08 10:12:17.290146+00', '2026-10-08 10:12:23.954964+00', 'Pago', '2026-10-08 10:13:23.353556+00', 39.00, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-08 10:12:21.623864+00', 'Cardápio', NULL, 8.00, '8b8d316e-3a41-42af-92f2-e49ccf3b173b', NULL, '2026-10-08 10:12:15.548699+00', 'b1d6e6f9-6e82-46b4-8806-f4068489d609', 'r-1791454293518-bsdf2f69', NULL, 0, NULL, NULL, NULL),
	('264380f4-e558-4770-a575-532d7c031655', 79, '2026-10-08 10:05:43.386986+00', NULL, 'Lucas Ricardo', '16996224986', 'Dinheiro', 47.50, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz, 364, Jaboticabal', '', '', '', '2026-10-08 10:06:39.25312+00', '2026-10-08 10:07:36.474685+00', 'Pago', '2026-10-08 10:06:34.527557+00', 39.50, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-08 10:06:41.578464+00', 'Cardápio', NULL, 8.00, 'df178e7d-e20e-4318-b085-108459696865', NULL, '2026-10-08 10:06:33.372304+00', '0ec2d360-347d-4dc3-a9a8-92d4f78a819f', 'r-1791453942425-wtes8owm', NULL, 0, NULL, NULL, NULL),
	('3248a39c-0656-43e2-a5ea-6f368568bb2d', 36, '2026-10-04 23:06:03.393061+00', NULL, 'Lucas Ricardo', '(16) 99622-4986', 'Dinheiro', 49.00, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Av Prudêncio Ortiz, 364, Jaboticabal', '', '', '', '2026-10-04 23:07:08.207222+00', '2026-10-04 23:07:32.314609+00', 'Pago', '2026-10-04 23:06:03.393061+00', 41.00, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-04 23:07:20.334857+00', 'Balcão', NULL, 8.00, '410c0bd5-aebe-4777-957b-2ca6a8f2edf4', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', NULL, 'd1389d31-dbff-4c37-89dd-fda22c72cc17', 'r-1791155162701-kiexrfxh', NULL, 0, NULL, NULL, NULL),
	('374babd5-dd07-464d-b817-15ecb8c92aad', 106, '2026-10-11 00:24:43.909955+00', NULL, 'Lucas Ricardo', '16996224986', 'Dinheiro', 31.50, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz, Parque 1º de Maio, nº 364 — Jaboticabal - SP', '', '', '', '2026-10-11 00:25:53.560742+00', '2026-10-11 00:47:48.222485+00', 'Pago', '2026-10-11 00:47:51.995549+00', 23.50, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-11 00:25:58.497786+00', 'Cardápio', NULL, 8.00, '161f7b31-021e-4894-8f7f-10ded06e50f7', NULL, '2026-10-11 00:25:16.368905+00', '50028182-957b-44f4-a956-b8e8fb9e3fdc', 'r-1791678283533-28ofg2zb', NULL, 0.00, NULL, NULL, NULL),
	('4136a8ae-9068-4f8f-a555-987c16aa05f9', 199, '2026-10-17 22:52:23.372227+00', NULL, 'Marlene Nogueira', '17981289270', 'Pix', 31.50, 9.19, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Rua Emílio Balardin, Jardim de Lúcia, nº 327 — Bebedouro - SP', '', '', '', '2026-10-17 23:15:10.596123+00', '2026-10-17 23:41:10.217255+00', 'Pago', '2026-10-17 23:14:55.517445+00', 23.50, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-17 23:28:52.22814+00', 'Cardápio', NULL, 8.00, NULL, NULL, '2026-10-17 22:52:43.575903+00', '05ec15c8-ab89-4b6a-9ab4-13967234bbd0', 'r-1792277543215-8k6h9mq9', NULL, 0.00, NULL, NULL, NULL),
	('43094350-80ee-45ad-aed3-724f0bede2de', 88, '2026-10-09 01:24:59.550061+00', NULL, 'Lucas', '16996224986', 'Dinheiro', 47.00, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz, 364 jaboticabal', '', '', '', '2026-10-09 01:25:43.336647+00', '2026-10-09 01:26:17.966295+00', 'Pago', '2026-10-09 01:26:20.215805+00', 39.00, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-09 01:25:50.872837+00', 'Cardápio', NULL, 8.00, '8b8d316e-3a41-42af-92f2-e49ccf3b173b', NULL, '2026-10-09 01:25:39.548528+00', 'b1d6e6f9-6e82-46b4-8806-f4068489d609', 'r-1791509098131-fb1zsinu', NULL, 0, NULL, NULL, NULL),
	('6764a51b-5684-440d-83cd-1e330778058f', 77, '2026-10-08 00:59:26.665105+00', NULL, 'Lucas Ricardo', '16996224986', 'Dinheiro', 58.85, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz,364, Jaboticabal', '', '', '', '2026-10-08 01:03:12.35209+00', '2026-10-08 01:05:32.483666+00', 'Pago', '2026-10-08 01:05:31.233255+00', 50.85, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-08 01:03:13.490749+00', 'Cardápio', NULL, 8.00, '5f870beb-71d5-48a8-9494-5efae0707ee3', NULL, '2026-10-08 01:03:07.846775+00', '0ec2d360-347d-4dc3-a9a8-92d4f78a819f', 'r-1791421166542-t8398odr', NULL, 0, NULL, NULL, NULL),
	('68f9fb39-9f84-418a-b102-e0689553e46c', 87, '2026-10-08 22:46:55.142452+00', NULL, 'Jonathan', '11948559694', 'Cartão de Débito', 58.85, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Rubião', 'Caasa', '', 'Sem', '2026-10-09 01:05:14.365507+00', '2026-10-09 01:05:24.367469+00', 'Pago', '2026-10-09 01:05:28.130283+00', 50.85, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-09 01:05:16.568509+00', 'Cardápio', NULL, 8.00, '8b8d316e-3a41-42af-92f2-e49ccf3b173b', NULL, '2026-10-08 22:47:28.084978+00', 'b1d6e6f9-6e82-46b4-8806-f4068489d609', 'r-1791499612988-hz9uonn5', NULL, 0, NULL, NULL, NULL),
	('6ae32da0-8576-4ddb-8634-889649f5844c', 1, '2026-10-04 10:59:58.90609+00', NULL, 'Lucas Ricardo', '(16) 99622-4986', 'Dinheiro', 40.00, 0.00, 'Confirmada', NULL, 'Retirada', 'Retirada', '', '', '', '', '2026-10-04 11:34:26.690053+00', '2026-10-04 11:34:28.078937+00', 'Pago', '2026-10-04 10:59:58.90609+00', 80.00, 40.00, '50% (R$ 40.00)', NULL, NULL, 'Balcão', NULL, 0.00, NULL, '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', NULL, 'd1389d31-dbff-4c37-89dd-fda22c72cc17', 'r-1791111598496-387g5sr2', NULL, 0, NULL, NULL, NULL),
	('8800bc70-4d0f-4abc-81d5-0be42e9dc846', 82, '2026-10-08 12:00:06.051123+00', NULL, 'Lucas Ricardo', '16996224986', 'Dinheiro', 58.85, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz, 364, Jaboticabal', '', '', '', '2026-10-08 12:02:23.527592+00', '2026-10-08 14:30:58.541519+00', 'Pago', '2026-10-08 12:01:52.806301+00', 50.85, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-08 12:02:26.492249+00', 'Cardápio', NULL, 8.00, '8b8d316e-3a41-42af-92f2-e49ccf3b173b', NULL, '2026-10-08 12:01:47.779826+00', 'b1d6e6f9-6e82-46b4-8806-f4068489d609', 'r-1791460754357-vuyhwavq', NULL, 0, NULL, NULL, NULL),
	('9167773a-64fe-4fb9-83d9-f77a9feabc7f', 134, '2026-10-12 01:52:40.892477+00', NULL, 'Lucas Ricardo', '16996224986', 'Cartão de Crédito', 87.00, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz, Parque 1º de Maio, nº 364 — Jaboticabal - SP', '', '', '', '2026-10-12 01:56:42.003265+00', '2026-10-12 01:56:44.294826+00', 'Pago', '2026-10-12 01:56:45.778659+00', 79.00, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-12 01:56:43.299486+00', 'Cardápio', NULL, 8.00, '0fb76783-1aba-4a82-9099-3f5fc4b19e68', NULL, '2026-10-12 01:56:38.941736+00', 'b9c06550-b8fd-45b7-a71d-a1ba49c8c374', 'r-1791769960592-xow445kb', NULL, 0.00, NULL, NULL, NULL),
	('9358c5da-eb26-4443-92a5-27edc965c976', 116, '2026-10-11 11:21:06.526682+00', NULL, 'Lucas Ricardo', '16996224986', 'Dinheiro', 38.30, 0.00, 'Confirmada', NULL, 'Retirada', 'Retirada', '', '', '', '', '2026-10-11 11:22:10.80996+00', '2026-10-11 11:22:16.410747+00', 'Pago', '2026-10-11 11:22:19.358006+00', 38.30, 0.00, '', NULL, NULL, 'Cardápio', NULL, 0.00, NULL, NULL, '2026-10-11 11:22:08.423251+00', '50028182-957b-44f4-a956-b8e8fb9e3fdc', 'r-1791717666335-93flspnv', NULL, 0.00, NULL, NULL, NULL),
	('957fcd6b-3977-4449-b209-8e19e9d76f6a', 6, '2026-10-04 14:08:06.479992+00', NULL, 'Lucas Ricardo', '16996224986', 'Cartão de Débito', 31.50, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz, 364', '', '', '', '2026-10-04 14:10:29.08764+00', '2026-10-04 14:10:42.542497+00', 'Pago', '2026-10-04 14:10:24.896849+00', 23.50, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-04 14:10:30.781714+00', 'Cardápio', NULL, 8.00, '410c0bd5-aebe-4777-957b-2ca6a8f2edf4', NULL, NULL, 'd1389d31-dbff-4c37-89dd-fda22c72cc17', 'r-1791122885948-dynh3nva', NULL, 0, NULL, NULL, NULL),
	('9d475828-40c1-43a5-994f-48fd4fc3efc7', 78, '2026-10-08 02:07:27.698447+00', NULL, 'Lucas', '16999224986', 'Dinheiro', 46.00, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz, 364, Jaboticabal', '', '', '', '2026-10-08 02:09:32.379371+00', '2026-10-08 02:11:39.913981+00', 'Pago', '2026-10-08 02:11:33.849227+00', 38.00, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-08 02:09:36.021871+00', 'Cardápio', NULL, 8.00, '5f870beb-71d5-48a8-9494-5efae0707ee3', NULL, '2026-10-08 02:09:26.683306+00', '0ec2d360-347d-4dc3-a9a8-92d4f78a819f', 'r-1791425246433-b5uxwg8z', NULL, 0, NULL, NULL, NULL),
	('a0dcadb0-adc2-4af5-ac03-2a8ec08563f6', 147, '2026-10-12 02:48:04.657229+00', NULL, 'JONATAN GUILHERME FRAGOSO', '11948559694', 'Cartão de Débito', 89.30, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Rua Rubião Junior, Centro, nº 1345 — Bebedouro - SP', 'Casa', '', '', '2026-10-12 02:58:57.749643+00', '2026-10-12 02:59:02.718303+00', 'Pago', '2026-10-12 09:37:13.999309+00', 81.30, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-12 02:59:00.460819+00', 'Cardápio', NULL, 8.00, '0fb76783-1aba-4a82-9099-3f5fc4b19e68', NULL, '2026-10-12 02:48:39.091994+00', 'b9c06550-b8fd-45b7-a71d-a1ba49c8c374', 'r-1791773283796-zaqg9xqb', NULL, 0.00, NULL, NULL, NULL),
	('a1417a8b-3e58-4b73-ae37-9728f7849e7f', 76, '2026-10-07 03:29:35.636447+00', NULL, 'Lucas', '16996224986', 'Cartão de Crédito', 46.00, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz, 364', '', '', '', '2026-10-07 03:30:44.527453+00', '2026-10-07 03:31:37.257833+00', 'Pago', '2026-10-07 03:31:39.477529+00', 38.00, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-07 03:31:32.776941+00', 'Cardápio', NULL, 8.00, '5f870beb-71d5-48a8-9494-5efae0707ee3', NULL, '2026-10-07 03:30:40.873603+00', '0ec2d360-347d-4dc3-a9a8-92d4f78a819f', 'r-1791343775596-g4saewmd', NULL, 0, NULL, NULL, NULL),
	('bb1d3bd6-9494-47b8-b67b-cc4cf67e1220', 80, '2026-10-08 10:09:50.714468+00', NULL, 'Lucas Ricardo', '16996224986', 'Dinheiro', 38.30, 0.00, 'Confirmada', NULL, 'Retirada', 'Retirada', '', '', '', '', '2026-10-08 10:12:32.273336+00', '2026-10-08 10:12:33.346403+00', 'Pago', '2026-10-08 10:12:41.823337+00', 38.30, 0.00, '', NULL, NULL, 'Cardápio', NULL, 0.00, NULL, NULL, '2026-10-08 10:12:30.97116+00', 'b1d6e6f9-6e82-46b4-8806-f4068489d609', 'r-1791454190739-e3hd5s4v', NULL, 0, NULL, NULL, NULL),
	('bd8c4cd8-9b40-49ee-9f9b-0026223e3151', 115, '2026-10-11 11:19:09.087593+00', NULL, 'Lucas Ricardo', '16996224986', 'Cartão de Crédito', 46.30, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz, X, nº 364 — Jaboticabal - SP', '', '', '', '2026-10-11 11:20:17.849128+00', '2026-10-11 11:20:34.593847+00', 'Pago', '2026-10-11 11:20:36.137477+00', 38.30, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-11 11:20:23.585573+00', 'Cardápio', NULL, 8.00, '90255aa3-2c98-4606-8e58-aa375edfcb2c', NULL, '2026-10-11 11:19:57.488662+00', '50028182-957b-44f4-a956-b8e8fb9e3fdc', 'r-1791717548848-lkax0ya0', NULL, 0.00, NULL, NULL, NULL),
	('be0554f9-65a1-4e03-8b58-74007189eceb', 85, '2026-10-08 22:12:20.775913+00', NULL, 'Lucas Ricardo', '', 'Dinheiro', 38.30, 0.00, 'Confirmada', NULL, 'Mesa', 'Servida', '', '', '', '', '2026-10-08 22:13:01.903822+00', '2026-10-08 22:13:04.196617+00', 'Pago', '2026-10-08 22:13:25.770597+00', 38.30, 0.00, '', NULL, NULL, 'Cardápio', '6ce68177-48f7-4aad-a759-96034c371d5f', 0.00, NULL, NULL, '2026-10-08 22:12:47.177417+00', 'b1d6e6f9-6e82-46b4-8806-f4068489d609', 'r-1791497540719-z4zzmx1d', NULL, 0, NULL, NULL, NULL),
	('ce1970c5-e982-4745-ac8c-0316ab5299ab', 200, '2026-10-18 01:28:58.76397+00', NULL, 'Natália Ap Monteiro Cintra', '17997073419', 'Dinheiro', 99.90, 0.00, 'Confirmada', NULL, 'Retirada', 'Retirada', '', '', '', '', '2026-10-18 01:51:19.322032+00', '2026-10-18 02:33:37.978526+00', 'Pago', '2026-10-18 02:33:48.616288+00', 99.90, 0.00, '', NULL, NULL, 'Cardápio', NULL, 0.00, NULL, NULL, '2026-10-18 01:29:13.78294+00', '05ec15c8-ab89-4b6a-9ab4-13967234bbd0', 'r-1792286938635-ahbaf8pr', NULL, 0.00, NULL, NULL, NULL),
	('d07bd917-e19a-4776-81e6-3c112ef5b483', 38, '2026-10-04 23:23:33.87925+00', NULL, 'Lucas Ricardo', '16996224986', 'Dinheiro', 46.30, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz,353', '', '', '', '2026-10-04 23:24:19.748965+00', '2026-10-05 00:32:31.609877+00', 'Pago', '2026-10-05 00:31:29.103625+00', 38.30, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-05 00:31:29.560868+00', 'Cardápio', NULL, 8.00, '410c0bd5-aebe-4777-957b-2ca6a8f2edf4', NULL, NULL, 'd1389d31-dbff-4c37-89dd-fda22c72cc17', 'r-1791156213410-hfi8tqio', NULL, 0, NULL, NULL, NULL),
	('dea8e60c-8703-4e9f-8220-045e421e7f5a', 86, '2026-10-08 22:42:17.294786+00', NULL, 'Jonatan Fragoso', '11948559694', 'Dinheiro', 41.00, 0.00, 'Confirmada', NULL, 'Retirada', 'Retirada', '', '', '', '', '2026-10-08 22:43:33.2797+00', '2026-10-08 22:45:39.354325+00', 'Pago', '2026-10-08 22:45:27.622489+00', 41.00, 0.00, '', NULL, NULL, 'Cardápio', NULL, 0.00, NULL, NULL, '2026-10-08 22:43:11.203853+00', 'b1d6e6f9-6e82-46b4-8806-f4068489d609', 'r-1791499335429-xjojma1o', NULL, 0, NULL, NULL, NULL),
	('e733a406-8b9e-45c6-aa1a-02c45cfb42db', 133, '2026-10-12 01:51:27.139354+00', NULL, 'Lucas Ricardo', '16996224986', 'Cartão de Débito', 46.30, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz, Parque 1º de Maio, nº 364 — Jaboticabal - SP', '', '', '', '2026-10-12 01:56:48.423489+00', '2026-10-12 01:56:50.783115+00', 'Pago', '2026-10-12 01:56:52.979466+00', 38.30, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-12 01:56:49.538267+00', 'Cardápio', NULL, 8.00, '0fb76783-1aba-4a82-9099-3f5fc4b19e68', NULL, '2026-10-12 01:56:27.380284+00', 'b9c06550-b8fd-45b7-a71d-a1ba49c8c374', 'r-1791769816363-6q1a5vq8', NULL, 0.00, NULL, NULL, NULL),
	('ee77d427-2849-471a-a0b8-13f096b8980f', 83, '2026-10-08 14:43:13.783366+00', NULL, 'Jonatan Fragoso', '11948559694', 'Dinheiro', 31.50, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Rubião Junior', 'Casa', '1345', 'Sem cebola', '2026-10-08 14:44:48.491363+00', '2026-10-08 14:48:27.665092+00', 'Pago', '2026-10-08 14:48:30.942574+00', 23.50, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-08 14:44:52.617182+00', 'Cardápio', NULL, 8.00, '8b8d316e-3a41-42af-92f2-e49ccf3b173b', NULL, '2026-10-08 14:44:38.246828+00', 'b1d6e6f9-6e82-46b4-8806-f4068489d609', 'r-1791470591631-r4qqkspg', NULL, 0, NULL, NULL, NULL),
	('f6e79d89-0bb5-4f1f-8765-07ed2a9096e9', 84, '2026-10-08 17:59:39.628779+00', NULL, 'Lucas Ricardo', '16996224986', 'Dinheiro', 46.30, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Avenida Prudêncio Ortiz 364 Jaboticabal', '', '', '', '2026-10-08 18:00:34.594941+00', '2026-10-08 18:00:43.271542+00', 'Pago', '2026-10-08 18:00:46.423201+00', 38.30, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-08 18:00:40.021268+00', 'Cardápio', NULL, 8.00, '8b8d316e-3a41-42af-92f2-e49ccf3b173b', NULL, '2026-10-08 18:00:28.64681+00', 'b1d6e6f9-6e82-46b4-8806-f4068489d609', 'r-1791482377341-e88ebork', NULL, 0, NULL, NULL, NULL),
	('fca14f9b-9e40-44fb-9777-0cc61a5db211', 37, '2026-10-04 23:06:50.582141+00', NULL, 'Lucas Ricardo', '(16) 99622-4986', 'Dinheiro', 141.00, 0.00, 'Confirmada', NULL, 'Entrega', 'Entregue', 'Av Prudêncio Ortiz, 364, Jaboticabal', '', '', '', '2026-10-04 23:07:11.410152+00', '2026-10-04 23:07:30.36712+00', 'Pago', '2026-10-04 23:06:50.582141+00', 41.00, 0.00, '', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', '2026-10-04 23:07:28.845394+00', 'Balcão', NULL, 100.00, '410c0bd5-aebe-4777-957b-2ca6a8f2edf4', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', NULL, 'd1389d31-dbff-4c37-89dd-fda22c72cc17', 'r-1791155209685-vngoni4g', NULL, 0, NULL, NULL, NULL);


--
-- Data for Name: chat_conversas; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.chat_conversas (id, venda_id, estado, tipo_problema, resumo, texto_original, ia_chamadas, atendente_id, ocorrencia_id, nao_lidas_equipe, nao_lidas_cliente, solucao, criado_em, atualizado_em, transferida_em, encerrada_em, intencao, nome_cliente, telefone_cliente, pedido_nao_localizado, outros_pedidos) VALUES
	('314f43b6-9f01-487c-93d1-19d9b687207f', NULL, 'em_atendimento', 'antes_de_pedir', 'Cliente solicita atendimento para tirar uma dúvida antes de realizar o pedido.', 'Preciso de atendimento humano para tirar numa dúvida, ainda não fiz o pedido', 1, '9866c7ad-b231-458d-aed3-34daa4d28268', NULL, 0, 1, NULL, '2026-10-08 08:40:20.465943+00', '2026-10-08 08:41:34.658988+00', '2026-10-08 08:40:29.497305+00', NULL, 'antes_de_pedir', NULL, NULL, false, 0),
	('4fb577b5-3220-4b4a-80f2-714a142589c6', NULL, 'encerrada', 'antes_de_pedir', 'Cliente pergunta qual é o lanche mais vendido do cardápio.', 'Qual lanche sai mais ?', 1, '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', NULL, 0, 1, 'X tudo', '2026-10-08 14:31:45.290787+00', '2026-10-08 14:51:08.354275+00', '2026-10-08 14:31:56.426208+00', '2026-10-08 14:51:08.354275+00', 'antes_de_pedir', NULL, NULL, false, 0);


--
-- Data for Name: chat_ia_cotas; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.chat_ia_cotas (dia, chamadas, atualizado_em) VALUES
	('2026-10-08', 4, '2026-10-08 14:31:46.653643+00'),
	('2026-10-09', 2, '2026-10-09 12:24:58.768218+00'),
	('2026-10-11', 4, '2026-10-11 23:59:15.272748+00'),
	('2026-10-12', 3, '2026-10-12 03:05:04.798663+00'),
	('2026-10-16', 1, '2026-10-16 16:00:02.525902+00'),
	('2026-10-17', 2, '2026-10-17 11:09:23.448684+00');


--
-- Data for Name: chat_mensagens; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.chat_mensagens (id, conversa_id, autor, autor_id, texto, criado_em) OVERRIDING SYSTEM VALUE VALUES
	(10, '4fb577b5-3220-4b4a-80f2-714a142589c6', 'ia', NULL, 'Cliente pergunta qual é o lanche mais vendido do cardápio.', '2026-10-08 14:31:51.395466+00'),
	(11, '4fb577b5-3220-4b4a-80f2-714a142589c6', 'cliente', NULL, 'Qual lanche sai mais ?', '2026-10-08 14:31:56.426208+00'),
	(12, '4fb577b5-3220-4b4a-80f2-714a142589c6', 'sistema', NULL, 'Pedido de ajuda enviado. Uma pessoa da equipe vai responder aqui.', '2026-10-08 14:31:56.426208+00'),
	(13, '4fb577b5-3220-4b4a-80f2-714a142589c6', 'sistema', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'Jonatan assumiu o atendimento.', '2026-10-08 14:50:46.82479+00'),
	(14, '4fb577b5-3220-4b4a-80f2-714a142589c6', 'sistema', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'Atendimento encerrado pela equipe.', '2026-10-08 14:51:08.354275+00'),
	(4, '314f43b6-9f01-487c-93d1-19d9b687207f', 'ia', NULL, 'Cliente solicita atendimento para tirar uma dúvida antes de realizar o pedido.', '2026-10-08 08:40:28.000933+00'),
	(5, '314f43b6-9f01-487c-93d1-19d9b687207f', 'cliente', NULL, 'Preciso de atendimento humano para tirar numa dúvida, ainda não fiz o pedido', '2026-10-08 08:40:29.497305+00'),
	(6, '314f43b6-9f01-487c-93d1-19d9b687207f', 'sistema', NULL, 'Pedido de ajuda enviado. Uma pessoa da equipe vai responder aqui.', '2026-10-08 08:40:29.497305+00'),
	(7, '314f43b6-9f01-487c-93d1-19d9b687207f', 'cliente', NULL, 'Bom dia', '2026-10-08 08:40:38.828087+00'),
	(8, '314f43b6-9f01-487c-93d1-19d9b687207f', 'sistema', '9866c7ad-b231-458d-aed3-34daa4d28268', 'Lucas assumiu o atendimento.', '2026-10-08 08:41:20.329644+00'),
	(9, '314f43b6-9f01-487c-93d1-19d9b687207f', 'atendente', '9866c7ad-b231-458d-aed3-34daa4d28268', 'Boa noite tudo bem?', '2026-10-08 08:41:34.658988+00');


--
-- Data for Name: chat_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.chat_tokens (conversa_id, token_hash, criado_em) VALUES
	('314f43b6-9f01-487c-93d1-19d9b687207f', 'c0ecb19b7c1b199bc64ed53004e7f9b7d9f27d9ea9550f809e37e1fc6668819d', '2026-10-08 08:40:20.465943+00'),
	('4fb577b5-3220-4b4a-80f2-714a142589c6', '749e6007124304df89e9e889876d94825a10d7bc38d21dc678801fc10cbd0014', '2026-10-08 14:31:45.290787+00');


--
-- Data for Name: combos; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.combos (id, nome, categoria_id, ativo, destaque, ordem_cardapio, foto_id_principal, foto_id_contingencia, foto_url_principal, foto_url_contingencia, foto_preferida, perfil_fiscal_id) VALUES
	('018041a9-0b05-463c-a2ee-84cb5f19c283', 'Texas Honey Combo', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, 13, '1rq-yMlsfrEbeZXB0Fz5FH-7k1pULLPQK', NULL, NULL, NULL, 'principal', NULL),
	('0afc8438-08ba-4566-9e12-12861531f393', 'Duplo Tudo', 'b5e9987e-d8e3-4dd7-b0c8-814770bd33df', true, false, 4, '133Wa_16Sx9czzP-9EUPsb0ttwkrgeZZf', NULL, NULL, NULL, 'principal', NULL),
	('113c3645-508f-47f6-ae56-ff3bef65dcd0', 'Dobro Burguer + Churros', 'b5e9987e-d8e3-4dd7-b0c8-814770bd33df', true, false, 6, '1YeFeyiWqzJ9BJbtmg6_wm2vjCpQ1v8Xv', NULL, NULL, NULL, 'principal', NULL),
	('22d0c53b-2feb-48af-9e1f-6ae042f5700c', 'Cheddar Combo', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, 18, '1C-p9bhgXzsRGDpkCLqdLUYE4NVWz9uKT', NULL, NULL, NULL, 'principal', NULL),
	('3e6ff02c-6132-46b9-99a9-d5bba77d41c1', 'Combo Salada Burguer', 'b5e9987e-d8e3-4dd7-b0c8-814770bd33df', true, false, 3, '16s_RBJFnJyo_MhksvineSjFHGQNY8KDW', NULL, NULL, NULL, 'principal', NULL),
	('4924d6fc-c2bd-4852-ab08-eda7edf6567a', 'X Texas Combo', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, 19, '1y02s9Jy8oR6Lai7517J_3AP5daXlm61Z', NULL, NULL, NULL, 'principal', NULL),
	('552e573e-f261-4008-a43a-a0346b4600ed', 'Burguer Rustic Combo', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, 12, '1aKYu05gRnXB3gKuWI6UdXqr3nTN9RUA5', NULL, NULL, NULL, 'principal', NULL),
	('658a1f7f-bd39-4e62-982b-cc42d09f2a86', 'Combo Texas', 'b5e9987e-d8e3-4dd7-b0c8-814770bd33df', true, false, 1, '15RmES_By-g3ylKNdatk9kpQdHtdyyQd7', NULL, NULL, NULL, 'principal', NULL),
	('89813212-c1e9-4cb5-ba73-065023280af1', 'Barbecue Mister Combo', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, 15, '110btYqF2V0gJgdjtZ7iEzUEGQekJ7jmS', NULL, NULL, NULL, 'principal', NULL),
	('92a0d5b3-0757-4068-ab08-4751e8fcc9f9', 'Duplo Cheddar Combo', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, 14, '1aGunP7-M5FL3DfMWZ0uC_qViWmSDq0zi', NULL, NULL, NULL, 'principal', NULL),
	('98eb2ce5-964e-410a-8791-44033cffdbb4', 'Onion Texas Combo', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, 17, '1TBCQKsZpjJ2VgFnVn9rDrCaZOr0MmHmU', NULL, NULL, NULL, 'principal', NULL),
	('9c5807ac-3f36-49ea-874f-8db5acd18b2c', 'Cheddar em Dobro', 'b5e9987e-d8e3-4dd7-b0c8-814770bd33df', true, false, 5, '19fYXq_GTIe2iEqnaP6lZQVasSRroS2rt', NULL, NULL, NULL, 'principal', NULL),
	('9fdec5ac-97ac-41b8-a203-bd4dd0d8f514', 'Catupiry Bacon Combo', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, 16, '1ppSBJlGbiGjDNVn64O-IErdBbsBxitMO', NULL, NULL, NULL, 'principal', NULL),
	('a6b948b0-4109-4c4c-831a-660cece144b6', 'Picles Cheddar Combo', '979f1174-1624-4773-be8a-45a38bf79f69', true, false, 20, '1ZWPLe_pizlMPzoHr3SmLnfARkmOKGfQ_', NULL, NULL, NULL, 'principal', NULL),
	('d49ad88d-6fdf-4510-aa5f-c96ee9fd91d4', 'Combo X Bacon', 'b5e9987e-d8e3-4dd7-b0c8-814770bd33df', true, false, 2, '1fdS7fnDJxYbTE0zmvCi29rnq8yBp7nOI', NULL, NULL, NULL, 'principal', NULL);


--
-- Data for Name: combo_itens; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.combo_itens (id, combo_id, produto_id, quantidade) VALUES
	('04c82796-0811-43a9-bf65-67eee591cc45', 'a6b948b0-4109-4c4c-831a-660cece144b6', '64142b67-ba38-41fe-8e46-68213b65a342', 1),
	('20e2dccc-d1f4-44f8-b48f-b8fc3aecd371', '9fdec5ac-97ac-41b8-a203-bd4dd0d8f514', '1658ebed-648f-4150-bf26-f50993a72243', 1),
	('25217790-4c36-405f-a6fe-90d709b4955c', '22d0c53b-2feb-48af-9e1f-6ae042f5700c', '1658ebed-648f-4150-bf26-f50993a72243', 1),
	('28ab027d-f312-4e8f-b6c9-7c3f7cebb1dd', '552e573e-f261-4008-a43a-a0346b4600ed', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', 1),
	('2ac158a4-c9e0-4dbe-990f-9ea40ed412f2', '552e573e-f261-4008-a43a-a0346b4600ed', 'ee5b570a-759c-42aa-929b-efb390436f1a', 1),
	('305ee417-f891-4d06-9064-c58ea9a87ad7', '92a0d5b3-0757-4068-ab08-4751e8fcc9f9', '7583e038-e58c-41a8-867c-026f1b90d787', 1),
	('3107f841-f72d-4a7a-979c-b9118eb53d20', 'a6b948b0-4109-4c4c-831a-660cece144b6', '1658ebed-648f-4150-bf26-f50993a72243', 1),
	('3846caf6-35d2-4486-b572-af292b857237', '018041a9-0b05-463c-a2ee-84cb5f19c283', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', 1),
	('4bf0b276-b6fa-4d86-86b1-ca8ab8c624ad', '4924d6fc-c2bd-4852-ab08-eda7edf6567a', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', 1),
	('51cbce92-55c1-41bd-83c5-1ab45de6dc34', '89813212-c1e9-4cb5-ba73-065023280af1', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', 1),
	('5526e8a5-094d-43cb-b929-717a021faf75', '92a0d5b3-0757-4068-ab08-4751e8fcc9f9', '1658ebed-648f-4150-bf26-f50993a72243', 1),
	('58e249a5-d567-4a24-974c-3414d2b5468d', '89813212-c1e9-4cb5-ba73-065023280af1', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', 1),
	('5b48201f-19d4-44f8-9079-759b1e8d8294', '22d0c53b-2feb-48af-9e1f-6ae042f5700c', '4014c744-53bc-4148-8fcf-0799918e88aa', 1),
	('6e76c853-2fb1-47d8-8536-d1fe6afd3193', '4924d6fc-c2bd-4852-ab08-eda7edf6567a', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', 1),
	('88650a9a-07aa-4adc-bb1e-a807a9a93835', '89813212-c1e9-4cb5-ba73-065023280af1', '1658ebed-648f-4150-bf26-f50993a72243', 1),
	('9c274e73-bb59-4968-be46-d40de100a2a2', '9fdec5ac-97ac-41b8-a203-bd4dd0d8f514', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', 1),
	('9ced3265-bb30-4cc1-b5c4-0050355bcf8f', '018041a9-0b05-463c-a2ee-84cb5f19c283', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', 1),
	('a5aa599c-b6e3-438b-a2e7-02e9788ffc52', '4924d6fc-c2bd-4852-ab08-eda7edf6567a', '1658ebed-648f-4150-bf26-f50993a72243', 1),
	('a9643a5b-436a-4caa-9b3d-50395238fcb7', '22d0c53b-2feb-48af-9e1f-6ae042f5700c', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', 1),
	('af461816-8de2-410c-b2c1-a7664f486705', 'a6b948b0-4109-4c4c-831a-660cece144b6', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', 1),
	('b04cabe5-cde6-4f4e-88ee-40d2e4a90acd', '018041a9-0b05-463c-a2ee-84cb5f19c283', '1658ebed-648f-4150-bf26-f50993a72243', 1),
	('b14ef464-48f7-4443-b146-51e67562406b', '98eb2ce5-964e-410a-8791-44033cffdbb4', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', 1),
	('bcee07a8-311e-495f-b717-fbe3858a4d94', '9fdec5ac-97ac-41b8-a203-bd4dd0d8f514', '25b30ac0-81b5-46bd-b3ad-876b48a78251', 1),
	('bf86f889-bc56-441c-8b52-596651649a48', '552e573e-f261-4008-a43a-a0346b4600ed', '1658ebed-648f-4150-bf26-f50993a72243', 1),
	('c569c345-b7d0-423c-8d0b-5269819dc0bf', '92a0d5b3-0757-4068-ab08-4751e8fcc9f9', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', 1),
	('e3f5987e-d57e-4fa2-8e2a-3bcf1870db9f', '98eb2ce5-964e-410a-8791-44033cffdbb4', '1658ebed-648f-4150-bf26-f50993a72243', 1),
	('f0c6bb77-7634-4574-a56f-6f0b522a130d', '98eb2ce5-964e-410a-8791-44033cffdbb4', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', 1);


--
-- Data for Name: formas_pagamento; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.formas_pagamento (id, nome, ativa, visivel_cardapio, taxa_percentual, taxa_fixa, prazo_dias, permite_troco, ordem, acrescimo_percentual, acrescimo_fixo, preco_proprio, aceita_online, tipo_online) VALUES
	('17b14f91-68d9-4a94-9374-c64846414581', 'Pix', true, true, 0.00, 0.00, 0, false, 2, 0, 0, false, true, 'pix'),
	('19f2f926-8a9e-41a7-ba5f-2280b672950e', 'Cartão de Débito', true, true, 0.00, 0.00, 0, false, 3, 0, 0, false, true, 'debito'),
	('212c5286-05f4-47aa-8c00-ed7968551e08', 'Alelo', true, true, 0.00, 0.00, 0, false, 5, 0, 0, false, false, NULL),
	('21d76d26-8608-47b8-b387-1e9f5b150715', 'iFood', true, false, 0.00, 0.00, 0, false, 6, 0, 0, true, false, NULL),
	('415454fb-f2a6-4265-95d9-15fd0143cc1b', 'iFood (pagar na entrega)', false, false, 0.00, 0.00, 0, false, 99, 0, 0, false, false, NULL),
	('49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 'Dinheiro', true, true, 0.00, 0.00, 0, true, 1, 0, 0, false, false, NULL),
	('5ed453d4-554c-458d-b03b-a10f5c110f20', 'iFood (pago no app)', false, false, 0.00, 0.00, 0, false, 99, 0, 0, false, false, NULL),
	('d0e73585-ca32-43f7-8051-8469cc6034ba', 'Cartão de Crédito', true, true, 0.00, 0.00, 0, false, 4, 0, 0, false, true, 'credito');


--
-- Data for Name: combo_precos; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.combo_precos (id, combo_id, forma_pagamento_id, preco, custo) VALUES
	('0569fa4c-d93a-44bb-8c90-2f533f8d5e3e', '0afc8438-08ba-4566-9e12-12861531f393', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 60.00, 0.00),
	('09b7e765-80cd-4cc0-bec3-e25d3b3c9658', '22d0c53b-2feb-48af-9e1f-6ae042f5700c', '17b14f91-68d9-4a94-9374-c64846414581', 45.00, 25.21),
	('09c28a24-8128-44a9-9b2b-b900d9c9d4f9', '552e573e-f261-4008-a43a-a0346b4600ed', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 49.60, 24.01),
	('0afd2c36-616c-42bb-b5f4-a404f79061e4', '9c5807ac-3f36-49ea-874f-8db5acd18b2c', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 90.00, 0.00),
	('0ce304bd-7297-43cb-8457-09ddfe88164f', '113c3645-508f-47f6-ae56-ff3bef65dcd0', '17b14f91-68d9-4a94-9374-c64846414581', 80.00, 0.00),
	('0d4f7890-c8d2-46a2-82f8-cb614f5912a9', '658a1f7f-bd39-4e62-982b-cc42d09f2a86', '17b14f91-68d9-4a94-9374-c64846414581', 79.00, 0.00),
	('0db7917d-92a0-4534-969f-041c2e0fa832', '9c5807ac-3f36-49ea-874f-8db5acd18b2c', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 90.00, 0.00),
	('149a0fc4-1343-4a59-9075-2a1f9da0d15d', 'a6b948b0-4109-4c4c-831a-660cece144b6', '21d76d26-8608-47b8-b387-1e9f5b150715', 49.90, 24.55),
	('15f90277-a04b-4bf2-8768-8c72b19237af', '658a1f7f-bd39-4e62-982b-cc42d09f2a86', '21d76d26-8608-47b8-b387-1e9f5b150715', 84.99, 0.00),
	('1649d7c2-3a14-415e-a03b-df7b6d9a2e1e', '018041a9-0b05-463c-a2ee-84cb5f19c283', '21d76d26-8608-47b8-b387-1e9f5b150715', 52.90, 24.58),
	('176b8533-6652-4730-9a10-b86a79f434d7', '658a1f7f-bd39-4e62-982b-cc42d09f2a86', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 79.00, 0.00),
	('1894793d-5397-4d44-b3ee-ed05f21dd3e8', '22d0c53b-2feb-48af-9e1f-6ae042f5700c', '21d76d26-8608-47b8-b387-1e9f5b150715', 47.90, 25.21),
	('19bdda30-0ea2-4d1c-8198-f251d218acdb', '89813212-c1e9-4cb5-ba73-065023280af1', '17b14f91-68d9-4a94-9374-c64846414581', 50.00, 24.85),
	('1a661064-390b-4773-90bf-20c6edfdd6c8', '018041a9-0b05-463c-a2ee-84cb5f19c283', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 49.60, 24.58),
	('1d05cd66-f76c-4d9f-bb13-b7ed81fd8dac', '0afc8438-08ba-4566-9e12-12861531f393', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 60.00, 0.00),
	('1d62382d-d467-4d1f-8dd8-6470b968541d', '658a1f7f-bd39-4e62-982b-cc42d09f2a86', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 79.00, 0.00),
	('1e72b8ed-5f15-4c5d-94fb-4ea4442a7c2d', '3e6ff02c-6132-46b9-99a9-d5bba77d41c1', '212c5286-05f4-47aa-8c00-ed7968551e08', 90.00, 0.00),
	('22ac20f3-3644-4e42-8f3e-41376bb75c05', '0afc8438-08ba-4566-9e12-12861531f393', '21d76d26-8608-47b8-b387-1e9f5b150715', 71.99, 0.00),
	('25b195fd-ffe4-432e-8d27-24887dd020c8', '9fdec5ac-97ac-41b8-a203-bd4dd0d8f514', '212c5286-05f4-47aa-8c00-ed7968551e08', 56.40, 28.42),
	('28cc4d39-2b87-49bc-b17a-14abd712b338', '9c5807ac-3f36-49ea-874f-8db5acd18b2c', '21d76d26-8608-47b8-b387-1e9f5b150715', 107.99, 0.00),
	('33bc89de-0ee7-4e91-b428-976463232a41', 'a6b948b0-4109-4c4c-831a-660cece144b6', '17b14f91-68d9-4a94-9374-c64846414581', 47.00, 24.55),
	('355bb131-38c1-4cdc-8381-8328ba991be6', '98eb2ce5-964e-410a-8791-44033cffdbb4', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 52.00, 25.19),
	('35699aca-a49b-43cd-8cec-3ccaa28c9f99', '018041a9-0b05-463c-a2ee-84cb5f19c283', '17b14f91-68d9-4a94-9374-c64846414581', 49.60, 24.58),
	('363a0bda-a346-4c61-9997-0b8ba1c13f98', 'a6b948b0-4109-4c4c-831a-660cece144b6', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 47.00, 24.55),
	('3b999a40-48d6-479a-8223-a0b39ea8f586', '22d0c53b-2feb-48af-9e1f-6ae042f5700c', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 45.00, 25.21),
	('3bd5770d-2c80-4291-915c-d00ad51b4199', '98eb2ce5-964e-410a-8791-44033cffdbb4', '17b14f91-68d9-4a94-9374-c64846414581', 52.00, 25.19),
	('3e15c2df-5fcb-4af6-abde-cbc4adfd7794', '552e573e-f261-4008-a43a-a0346b4600ed', '17b14f91-68d9-4a94-9374-c64846414581', 49.60, 24.01),
	('3f3e8b81-120e-4563-a9e7-8fdcd2da916a', '552e573e-f261-4008-a43a-a0346b4600ed', '21d76d26-8608-47b8-b387-1e9f5b150715', 52.90, 24.01),
	('4135b575-e0db-4a97-8a3f-86ad1864b735', '4924d6fc-c2bd-4852-ab08-eda7edf6567a', '212c5286-05f4-47aa-8c00-ed7968551e08', 47.00, 22.08),
	('47504365-2a95-4b85-b2cd-882b11bf8fa8', '113c3645-508f-47f6-ae56-ff3bef65dcd0', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 80.00, 0.00),
	('4992d90c-9d5a-4574-93d7-5ac26666c280', '113c3645-508f-47f6-ae56-ff3bef65dcd0', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 80.00, 0.00),
	('4b3cc446-a08f-401f-8a16-f1ddc854affd', 'd49ad88d-6fdf-4510-aa5f-c96ee9fd91d4', '17b14f91-68d9-4a94-9374-c64846414581', 99.90, 0.00),
	('4c970bf8-9fcb-43b0-b610-6fa7c9583e2e', '3e6ff02c-6132-46b9-99a9-d5bba77d41c1', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 90.00, 0.00),
	('4cb1999d-ab6d-449f-8668-bc9fedc64384', '98eb2ce5-964e-410a-8791-44033cffdbb4', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 52.00, 25.19),
	('4de6315e-b22c-4192-9639-ffc44df38d16', '552e573e-f261-4008-a43a-a0346b4600ed', '212c5286-05f4-47aa-8c00-ed7968551e08', 49.60, 24.01),
	('5061c4b3-8037-4036-b987-2be4e5714695', '9fdec5ac-97ac-41b8-a203-bd4dd0d8f514', '21d76d26-8608-47b8-b387-1e9f5b150715', 59.90, 28.42),
	('559313d6-6804-4c3d-8b47-c3d8a9e4b098', '98eb2ce5-964e-410a-8791-44033cffdbb4', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 52.00, 25.19),
	('59129440-4827-473d-9572-6aa240b5c38c', '4924d6fc-c2bd-4852-ab08-eda7edf6567a', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 47.00, 22.08),
	('5c03aa48-c316-4c0d-adb9-511b7bd28f08', '22d0c53b-2feb-48af-9e1f-6ae042f5700c', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 45.00, 25.21),
	('64ccea8e-ba50-4a9f-bddc-31b37e3d2ed4', '9c5807ac-3f36-49ea-874f-8db5acd18b2c', '212c5286-05f4-47aa-8c00-ed7968551e08', 90.00, 0.00),
	('670463e3-8a3b-4106-9d7d-3d2fa49a17b8', '22d0c53b-2feb-48af-9e1f-6ae042f5700c', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 45.00, 25.21),
	('6b321262-3fe4-443f-877a-29ca5d6edc3b', '92a0d5b3-0757-4068-ab08-4751e8fcc9f9', '17b14f91-68d9-4a94-9374-c64846414581', 59.80, 34.39),
	('70f49920-400e-40be-a677-4fb1cbf3e5f1', '4924d6fc-c2bd-4852-ab08-eda7edf6567a', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 47.00, 22.08),
	('7113fa9a-d56c-4a9d-a2b9-4136ac3b1555', '89813212-c1e9-4cb5-ba73-065023280af1', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 50.00, 24.85),
	('727edec4-d7cf-422e-9db6-5283ea56efb0', '018041a9-0b05-463c-a2ee-84cb5f19c283', '212c5286-05f4-47aa-8c00-ed7968551e08', 49.60, 24.58),
	('75a2b874-f71a-469b-9757-8c59d5985485', '113c3645-508f-47f6-ae56-ff3bef65dcd0', '212c5286-05f4-47aa-8c00-ed7968551e08', 80.00, 0.00),
	('76426228-0e38-420f-aefa-09352cfbbf1e', '4924d6fc-c2bd-4852-ab08-eda7edf6567a', '17b14f91-68d9-4a94-9374-c64846414581', 47.00, 22.08),
	('76e8b19f-aa7b-4887-8af7-05a09cc4ec39', '89813212-c1e9-4cb5-ba73-065023280af1', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 50.00, 24.85),
	('772c8c0a-c4e7-47b9-ae64-4948f96f03ac', '113c3645-508f-47f6-ae56-ff3bef65dcd0', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 80.00, 0.00),
	('77f3174b-797d-4820-b579-6e9fabc71139', '89813212-c1e9-4cb5-ba73-065023280af1', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 50.00, 24.85),
	('7941df41-01f0-405d-a5e9-49b2e75db335', '9fdec5ac-97ac-41b8-a203-bd4dd0d8f514', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 56.40, 28.42),
	('7bef26a3-408c-415d-97f3-59b78b84f48a', '3e6ff02c-6132-46b9-99a9-d5bba77d41c1', '17b14f91-68d9-4a94-9374-c64846414581', 90.00, 0.00),
	('7d3e508e-217f-4802-997a-ad38c55e0c2d', '113c3645-508f-47f6-ae56-ff3bef65dcd0', '21d76d26-8608-47b8-b387-1e9f5b150715', 95.99, 0.00),
	('7f73079a-93f8-4949-919f-0afd716c86bf', '0afc8438-08ba-4566-9e12-12861531f393', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 60.00, 0.00),
	('81891451-da27-4b73-9184-4fae46daf506', '9c5807ac-3f36-49ea-874f-8db5acd18b2c', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 90.00, 0.00),
	('83934a14-1c9a-4b80-a8b0-ad9d28ce5972', 'a6b948b0-4109-4c4c-831a-660cece144b6', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 47.00, 24.55),
	('84095b79-584a-457f-921c-1e92f06c9870', 'd49ad88d-6fdf-4510-aa5f-c96ee9fd91d4', '21d76d26-8608-47b8-b387-1e9f5b150715', 107.99, 0.00),
	('85dc8784-1f2b-4b9b-a6d2-c694adce45f2', 'd49ad88d-6fdf-4510-aa5f-c96ee9fd91d4', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 99.90, 0.00),
	('88afcdf5-d632-4059-a5f5-367ba37e169b', '98eb2ce5-964e-410a-8791-44033cffdbb4', '212c5286-05f4-47aa-8c00-ed7968551e08', 52.00, 25.19),
	('88bf7cff-0835-4203-abc6-02b246f41ccd', '3e6ff02c-6132-46b9-99a9-d5bba77d41c1', '21d76d26-8608-47b8-b387-1e9f5b150715', 95.99, 0.00),
	('8b5eea05-20b4-4320-b65d-b49e2804867c', '4924d6fc-c2bd-4852-ab08-eda7edf6567a', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 47.00, 22.08),
	('976f696f-37a4-43ac-bdb9-dcd6e5197bc9', '658a1f7f-bd39-4e62-982b-cc42d09f2a86', '212c5286-05f4-47aa-8c00-ed7968551e08', 79.00, 0.00),
	('9abc6b65-92f8-459a-8325-d7d880a605ce', '92a0d5b3-0757-4068-ab08-4751e8fcc9f9', '21d76d26-8608-47b8-b387-1e9f5b150715', 63.90, 34.39),
	('9e692d9b-636d-4bf6-9200-a9f7713bcc18', '018041a9-0b05-463c-a2ee-84cb5f19c283', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 49.60, 24.58),
	('a1544f7e-176d-4100-a53f-20bb8cde1ee3', '92a0d5b3-0757-4068-ab08-4751e8fcc9f9', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 59.80, 34.39),
	('a5672b7d-5b8c-42be-8718-b60bb8501c17', '3e6ff02c-6132-46b9-99a9-d5bba77d41c1', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 90.00, 0.00),
	('a5b99059-97f3-4451-bd6a-06c25ad2655d', '0afc8438-08ba-4566-9e12-12861531f393', '212c5286-05f4-47aa-8c00-ed7968551e08', 60.00, 0.00),
	('ad6b4b58-504c-4a7d-badf-8b3df29b45cb', '9fdec5ac-97ac-41b8-a203-bd4dd0d8f514', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 56.40, 28.42),
	('b0fd20c8-2cca-4c6b-aaf3-89e3816a8941', '658a1f7f-bd39-4e62-982b-cc42d09f2a86', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 79.00, 0.00),
	('b1e13a45-22c7-4827-b650-eb1fbc102a0c', 'a6b948b0-4109-4c4c-831a-660cece144b6', '212c5286-05f4-47aa-8c00-ed7968551e08', 47.00, 24.55),
	('b342bbac-a291-4932-a621-a26903b31e42', '4924d6fc-c2bd-4852-ab08-eda7edf6567a', '21d76d26-8608-47b8-b387-1e9f5b150715', 49.90, 22.08),
	('b4769bc3-b2b1-4e7d-9a49-ebfbfce002d7', 'a6b948b0-4109-4c4c-831a-660cece144b6', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 47.00, 24.55),
	('bb1fcb31-664b-4f00-a772-503717ecb94d', '0afc8438-08ba-4566-9e12-12861531f393', '17b14f91-68d9-4a94-9374-c64846414581', 60.00, 0.00),
	('bc16b0e9-be5b-47f2-be4c-1b9b8112f0be', '92a0d5b3-0757-4068-ab08-4751e8fcc9f9', '212c5286-05f4-47aa-8c00-ed7968551e08', 59.80, 34.39),
	('bc6ddd9c-d0e7-45f4-8183-7d82470a45b8', '89813212-c1e9-4cb5-ba73-065023280af1', '212c5286-05f4-47aa-8c00-ed7968551e08', 50.00, 24.85),
	('c5d0d176-c2b1-4d64-918f-4aca56d3a9e6', '9fdec5ac-97ac-41b8-a203-bd4dd0d8f514', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 56.40, 28.42),
	('c6f6e9d7-682a-4d8d-acb8-a8a87fca17fd', '552e573e-f261-4008-a43a-a0346b4600ed', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 49.60, 24.01),
	('cfa68193-9342-44a3-867c-ee79d519bd83', '552e573e-f261-4008-a43a-a0346b4600ed', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 49.60, 24.01),
	('d5900b70-a42e-4123-a750-367d97f67e7a', 'd49ad88d-6fdf-4510-aa5f-c96ee9fd91d4', '212c5286-05f4-47aa-8c00-ed7968551e08', 99.90, 0.00),
	('d88a017c-b954-4882-aa4c-962dc3fbb3bd', '018041a9-0b05-463c-a2ee-84cb5f19c283', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 49.60, 24.58),
	('da329aa0-c718-411a-a9fe-ac0046e7acb9', '22d0c53b-2feb-48af-9e1f-6ae042f5700c', '212c5286-05f4-47aa-8c00-ed7968551e08', 45.00, 25.21),
	('e96be971-f38a-436f-9af8-50ac00148a0c', '9fdec5ac-97ac-41b8-a203-bd4dd0d8f514', '17b14f91-68d9-4a94-9374-c64846414581', 56.40, 28.42),
	('ea7737e1-0e6a-4e7c-a560-bfdc33efaad6', 'd49ad88d-6fdf-4510-aa5f-c96ee9fd91d4', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 99.90, 0.00),
	('ecb44a5b-cba8-4c09-97e1-8226f6bd1f68', 'd49ad88d-6fdf-4510-aa5f-c96ee9fd91d4', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 99.90, 0.00),
	('eda55f0a-42bb-4a37-aae6-81b194ae2fec', '92a0d5b3-0757-4068-ab08-4751e8fcc9f9', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 59.80, 34.39),
	('ef0e6087-6374-445b-a7dd-de6e01fd69ae', '89813212-c1e9-4cb5-ba73-065023280af1', '21d76d26-8608-47b8-b387-1e9f5b150715', 53.90, 24.85),
	('eff012c0-a375-420c-8fd1-49c22ea1b471', '92a0d5b3-0757-4068-ab08-4751e8fcc9f9', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 59.80, 34.39),
	('f465e2d4-e5af-4d3e-b6ec-5c62d0ff93ef', '98eb2ce5-964e-410a-8791-44033cffdbb4', '21d76d26-8608-47b8-b387-1e9f5b150715', 56.90, 25.19),
	('f56e31ea-44bd-4860-8f6d-ff88c3847a48', '3e6ff02c-6132-46b9-99a9-d5bba77d41c1', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 90.00, 0.00),
	('fcd91b09-2d5f-4bd0-9029-e45428eae1e7', '9c5807ac-3f36-49ea-874f-8db5acd18b2c', '17b14f91-68d9-4a94-9374-c64846414581', 90.00, 0.00);


--
-- Data for Name: configuracoes_fotos; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.configuracoes_fotos (id, onde_guardar, destino_padrao_upload, drive_preferido, sincronizacao_drives, backup_frio_storage, replicar_antigas, atualizado_em, historico_fotos_ativo) VALUES
	(true, 'drive_apenas', 'ambos', 'auto', 'manual', NULL, 'ativas', '2026-10-09 10:10:25.670399+00', true);


--
-- Data for Name: contas_cliente; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.contas_cliente (user_id, email, nome, telefone, cliente_id, data_nascimento, nasc_alterado_em, codigo_indicacao, indicado_por, indicacao_premiada, aceite_versao, aceite_em, promo_ok, promo_em, criado_em, ultimo_acesso) VALUES
	('f6020864-6292-4584-979e-4f63db3b1560', 'lucassricardo95@gmail.com', 'Lucas Ricardo', '16996224986', '4c44d8c2-e528-4dd3-a9d9-91deffa68b3b', '1995-12-28', '2026-10-12 01:48:57.114743+00', 'NDRD4T', NULL, false, 1, '2026-10-12 01:48:57.114743+00', true, '2026-10-12 01:48:57.114743+00', '2026-10-12 01:48:29.25865+00', '2026-10-18 02:04:35.400199+00');


--
-- Data for Name: contas_pedidos; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.contas_pedidos (venda_id, user_id, criado_em) VALUES
	('04903c16-fbda-434c-8b0e-5257b533b932', 'f6020864-6292-4584-979e-4f63db3b1560', '2026-10-17 00:22:25.119322+00'),
	('9167773a-64fe-4fb9-83d9-f77a9feabc7f', 'f6020864-6292-4584-979e-4f63db3b1560', '2026-10-12 01:52:40.892477+00');


--
-- Data for Name: contingencia_config; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.contingencia_config (id, timeout_supabase_ms, falhas_para_planilha, timeout_planilha_ms, falhas_para_contingencia, reconciliacao_lote, atualizado_em) VALUES
	(true, 8000, 3, 12000, 3, 50, '2026-10-06 02:57:32.342839+00');


--
-- Data for Name: cupons; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.cupons (id, codigo, nome, tipo, valor, frete_gratis, data_inicio, data_fim, hora_inicio, hora_fim, limite_total, limite_por_cliente, valor_minimo, ativa, acumula, criado_em, criado_por, faixas, somente_conta, cliente_id, mensagem, visivel_conta, automatico, validade_dias) VALUES
	('02e0b88a-3207-47c2-8b96-7e664852ce97', 'INDICADOR', 'Indique e ganhe — quem indicou', 'fixo', 10.00, false, NULL, NULL, NULL, NULL, 0, 1, 30.00, false, false, '2026-10-12 01:08:43.04162+00', NULL, '[]', true, NULL, 'Seu amigo fez o primeiro pedido! Este cupom é seu.', false, 'indicacao_indicador', 30),
	('1d91d238-5562-49df-84c1-6fa9d9964545', 'TEXAS017', 'Promoção de 10%', 'percentual', 10.00, false, '2026-10-08', '2026-12-31', NULL, NULL, 0, 1, 30.00, true, false, '2026-10-08 22:23:20.470705+00', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', '[]', false, NULL, '', true, NULL, 30),
	('2c08b506-75a8-422d-89e3-7bb0c43e4751', 'SAUDADE', 'Sentimos sua falta', 'fixo', 10.00, false, NULL, NULL, NULL, NULL, 0, 1, 30.00, false, false, '2026-10-16 23:22:57.62432+00', NULL, '[]', true, NULL, 'Sentimos sua falta! Um presente do Texas Burger para você voltar.', false, 'em_risco', 14),
	('61dbccc6-f701-4881-8618-2bf2ec79e830', 'VIPTEXAS', 'Cliente VIP', 'fixo', 15.00, false, NULL, NULL, NULL, NULL, 0, 1, 40.00, false, false, '2026-10-16 23:22:57.62432+00', NULL, '[]', true, NULL, 'Obrigado por ser cliente VIP do Texas Burger! Este cupom é seu.', false, 'vip', 30),
	('66f3d578-8850-41cf-b7de-00f2685bd851', 'ANIVERSARIO', 'Aniversário', 'fixo', 10.00, false, NULL, NULL, NULL, NULL, 0, 1, 30.00, false, false, '2026-10-12 01:08:43.04162+00', NULL, '[]', true, NULL, 'Feliz aniversário! Um presente do Texas Burger para você.', false, 'aniversario', 7),
	('7e4df2e3-6b0e-4b0e-af4d-0ba8f042200c', 'INDICADO', 'Indique e ganhe — quem foi indicado', 'fixo', 10.00, false, NULL, NULL, NULL, NULL, 0, 1, 30.00, false, false, '2026-10-12 01:08:43.04162+00', NULL, '[]', true, NULL, 'Você chegou por indicação de um amigo. Este cupom é seu.', false, 'indicacao_indicado', 30),
	('dbec3c0b-8d70-4159-8d1e-7ddb53dfd7ef', 'BOASVINDAS', 'Boas-vindas', 'percentual', 10.00, false, NULL, NULL, NULL, NULL, 0, 1, 0.00, false, false, '2026-10-12 01:08:43.04162+00', NULL, '[]', true, NULL, 'Cupom de boas-vindas pela sua conta!', false, 'boas_vindas', 30);


--
-- Data for Name: despesas; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.despesas (id, data_hora, descricao, valor, observacao, status, motivo_cancelamento, categoria, vencimento, situacao, recorrente_id, competencia, saiu_do_caixa, criada_em, requisicao_id) VALUES
	('df5b8a9e-395a-4ce6-ab3a-6e8262d7dd8d', '2026-10-13 02:57:23.738794+00', 'Repasse de taxas de entrega — Entregador (11/10/2026)', 24.00, 'Pago em Dinheiro', 'Paga', NULL, 'Entregadores', NULL, 'Paga', NULL, NULL, true, '2026-10-13 02:57:23.738794+00', 'ent-0fb76783-1aba-4a82-9099-3f5fc4b19e68-taxas');


--
-- Data for Name: entregas_fechadas; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.entregas_fechadas (id, fechamento_id, venda_id, data_ref, entregador_id, taxa) VALUES
	('097d058b-ef0a-42bc-927b-a2f9d531995a', '5f870beb-71d5-48a8-9494-5efae0707ee3', 'a1417a8b-3e58-4b73-ae37-9728f7849e7f', '2026-10-07', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('105e8371-1cb5-4861-9c5e-5584d5cbd087', '0fb76783-1aba-4a82-9099-3f5fc4b19e68', '9167773a-64fe-4fb9-83d9-f77a9feabc7f', '2026-10-11', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('11983ba3-d401-45e0-b2e9-0c981ef78cef', '7ee423d4-c8e0-494a-b0b5-b8d634232720', '0e4f13c6-1149-4547-a29c-0cc48ae7af93', '2026-10-15', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('177c00f1-fa48-4a97-8f02-12a7d8ffd51f', '8b8d316e-3a41-42af-92f2-e49ccf3b173b', '68f9fb39-9f84-418a-b102-e0689553e46c', '2026-10-08', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('1c45d38c-42d0-4b80-93d5-578424557d80', '410c0bd5-aebe-4777-957b-2ca6a8f2edf4', '3248a39c-0656-43e2-a5ea-6f368568bb2d', '2026-10-04', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('1e038f2e-3a1e-4dcf-95c5-6faa1d624899', '90255aa3-2c98-4606-8e58-aa375edfcb2c', 'bd8c4cd8-9b40-49ee-9f9b-0026223e3151', '2026-10-11', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('3f03e124-742c-4472-b7a8-f4f1584bb608', '90255aa3-2c98-4606-8e58-aa375edfcb2c', '15ff779b-e968-4947-9e6d-4755d1dd62ff', '2026-10-11', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('4103e4d6-664b-47f1-bc78-d0c2bdc940f1', '5f870beb-71d5-48a8-9494-5efae0707ee3', '9d475828-40c1-43a5-994f-48fd4fc3efc7', '2026-10-07', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('47ccdd13-e7f1-44e7-9c73-8463bcfb4966', '410c0bd5-aebe-4777-957b-2ca6a8f2edf4', 'fca14f9b-9e40-44fb-9777-0cc61a5db211', '2026-10-04', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 100.00),
	('75584c19-2c1b-4cdc-9894-43fe93030cb1', '5f870beb-71d5-48a8-9494-5efae0707ee3', '6764a51b-5684-440d-83cd-1e330778058f', '2026-10-07', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('75901a51-5ef1-43a8-a425-c020dc976625', '410c0bd5-aebe-4777-957b-2ca6a8f2edf4', '957fcd6b-3977-4449-b209-8e19e9d76f6a', '2026-10-04', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('7e3cc671-d00d-493f-aed7-8c24b216283e', '8b8d316e-3a41-42af-92f2-e49ccf3b173b', '8800bc70-4d0f-4abc-81d5-0be42e9dc846', '2026-10-08', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('8b8fc71e-3fa6-404c-b372-9bc9e93c3668', 'df178e7d-e20e-4318-b085-108459696865', '264380f4-e558-4770-a575-532d7c031655', '2026-10-08', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('95834058-a240-41f8-9389-6492b7349538', '8b8d316e-3a41-42af-92f2-e49ccf3b173b', '43094350-80ee-45ad-aed3-724f0bede2de', '2026-10-08', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('9c11e069-ae8b-4fa3-986b-b51461315d66', '8b8d316e-3a41-42af-92f2-e49ccf3b173b', '2136dcd6-6c45-4e2d-a99e-2ea84dd5c3fb', '2026-10-08', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('a36d1a35-06a5-4363-9ac0-73a44f54f9be', 'ccf797a2-9f29-41ea-ac02-cd59387c490d', '04903c16-fbda-434c-8b0e-5257b533b932', '2026-10-16', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('b3a0af5b-fea7-4c59-980c-7db2746318d4', '0fb76783-1aba-4a82-9099-3f5fc4b19e68', 'e733a406-8b9e-45c6-aa1a-02c45cfb42db', '2026-10-11', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('b4dc9a9d-f6d4-4c3d-90b0-dd91817a15d4', '8b8d316e-3a41-42af-92f2-e49ccf3b173b', 'f6e79d89-0bb5-4f1f-8765-07ed2a9096e9', '2026-10-08', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('b4e33f03-b34f-427e-a3f6-274d7a288a3b', '410c0bd5-aebe-4777-957b-2ca6a8f2edf4', 'd07bd917-e19a-4776-81e6-3c112ef5b483', '2026-10-04', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('bd499504-3d7e-4187-aa5c-f646c247d19e', '0fb76783-1aba-4a82-9099-3f5fc4b19e68', 'a0dcadb0-adc2-4af5-ac03-2a8ec08563f6', '2026-10-11', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('ca3f183e-fcae-49ea-9157-d0ecda574ee5', '8b8d316e-3a41-42af-92f2-e49ccf3b173b', 'ee77d427-2849-471a-a0b8-13f096b8980f', '2026-10-08', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('d7fbf3f1-cdda-4840-b394-b53d0fe86d07', '161f7b31-021e-4894-8f7f-10ded06e50f7', '374babd5-dd07-464d-b817-15ecb8c92aad', '2026-10-10', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00),
	('e1e9b21a-9fe4-45e5-8208-b1bf8d52037e', '5f870beb-71d5-48a8-9494-5efae0707ee3', '1b5d1529-bca4-452b-b658-0d6799f4c644', '2026-10-07', '8e442ee3-af30-4da0-ae6c-0312d2ba9223', 8.00);


--
-- Data for Name: erros_cliente; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.erros_cliente (id, criado_em, ultima_em, dia, usuario_id, nivel, tipo, mensagem, origem, pilha, tela, versao, aparelho, hash, ocorrencias) OVERRIDING SYSTEM VALUE VALUES
	(2, '2026-10-11 18:48:42.771682+00', '2026-10-11 18:48:42.771682+00', '2026-10-11', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'Admin', 'promise', 'rtParar_ is not defined', '', 'ReferenceError: rtParar_ is not defined     at sair (https://texasburguer.github.io/apptexasburguer/app-01-base-e-api.js)     at window.sair (https://texasburguer.github.io/apptexasburguer/app-19-ia.js)     at window.sair (https://texasburguer.github.io/apptexasburguer/app-20-balao-interno.js)     at window.sair (https://texasburguer.github.io/apptexasburguer/app-21-localizacao.js)     at HTMLButtonElement.onclick (https://texasburguer.github.io/apptexasburguer/:345:32)', 'tab-inicio', '1.0', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome', 'd285a0ef4abe66630a5907e53ee2bb73', 1),
	(3, '2026-10-11 18:55:02.569727+00', '2026-10-11 18:55:02.569727+00', '2026-10-11', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'Admin', 'promise', 'pedidosPainel_ is not defined', '', 'ReferenceError: pedidosPainel_ is not defined     at aplicarPermissoesNivel (https://texasburguer.github.io/apptexasburguer/app-01-base-e-api.js)     at nova (https://texasburguer.github.io/apptexasburguer/app-19-ia.js)     at nova (https://texasburguer.github.io/apptexasburguer/app-20-balao-interno.js)     at entrarNoApp (https://texasburguer.github.io/apptexasburguer/app-01-base-e-api.js)     at nova (https://texasburguer.github.io/apptexasburguer/app-19-ia.js)     at nova (https://texasburguer.github.i', 'tab-inicio', '1.0', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome', 'a832893017b230198ab7bc43caa5a8c7', 1),
	(4, '2026-10-11 18:55:09.64457+00', '2026-10-11 18:55:09.64457+00', '2026-10-11', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'Admin', 'error', 'Uncaught ReferenceError: abrirModalConexao_ is not defined', 'https://texasburguer.github.io/apptexasburguer/:340:141', 'ReferenceError: abrirModalConexao_ is not defined     at HTMLButtonElement.onclick (https://texasburguer.github.io/apptexasburguer/:340:141)', 'tab-inicio', '1.0', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome', 'ba915c41bf89b40ca8a78a02ee28d673', 1),
	(5, '2026-10-15 22:58:02.069989+00', '2026-10-15 23:16:30.123369+00', '2026-10-15', '9866c7ad-b231-458d-aed3-34daa4d28268', 'Desenvolvedor', 'error', 'Uncaught SyntaxError: Unexpected end of input', 'https://texasburguer.github.io/apptexasburguer/app-06-caixa.js:74:5', 'SyntaxError: Unexpected end of input', 'tab-inicio', '1.1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome', 'ab510bff2e7d10ebffa5e95eea97b19e', 3),
	(6, '2026-10-15 22:58:24.338772+00', '2026-10-15 23:16:33.30547+00', '2026-10-15', '9866c7ad-b231-458d-aed3-34daa4d28268', 'Desenvolvedor', 'promise', 'mesaQr is not defined', '', 'ReferenceError: mesaQr is not defined     at cdPintar_ (https://texasburguer.github.io/apptexasburguer/app-15-cardapio-cliente.js)     at carregarCardapioPublico (https://texasburguer.github.io/apptexasburguer/app-15-cardapio-cliente.js)     at HTMLDocument.tentarRestaurarSessao (https://texasburguer.github.io/apptexasburguer/app-16-sessao-final.js)', 'tab-inicio', '1.1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome', '941e18570697c1f6c066105ca356bc7e', 2),
	(7, '2026-10-15 22:58:25.897244+00', '2026-10-15 23:16:31.721353+00', '2026-10-15', '9866c7ad-b231-458d-aed3-34daa4d28268', 'Desenvolvedor', 'promise', 'renderPagamentos is not defined', '', 'ReferenceError: renderPagamentos is not defined     at init (https://texasburguer.github.io/apptexasburguer/app-13-conexao-sync.js)     at entrarNoApp (https://texasburguer.github.io/apptexasburguer/app-01-base-e-api.js)     at nova (https://texasburguer.github.io/apptexasburguer/app-19-ia.js)     at nova (https://texasburguer.github.io/apptexasburguer/app-20-balao-interno.js)     at n (https://texasburguer.github.io/apptexasburguer/:69:35)     at tentarLogin (https://texasburguer.github.io/apptexasburguer/app-01-base-e-api', 'tab-inicio', '1.1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome', '9414523c5bbac53759e2b36a0a4ee7ae', 2),
	(8, '2026-10-15 22:58:27.512872+00', '2026-10-15 22:58:27.512872+00', '2026-10-15', '9866c7ad-b231-458d-aed3-34daa4d28268', 'Desenvolvedor', 'promise', 'oferecerRecuperarCarrinho_ is not defined', '', 'ReferenceError: oferecerRecuperarCarrinho_ is not defined     at entrarNoApp (https://texasburguer.github.io/apptexasburguer/app-01-base-e-api.js)     at nova (https://texasburguer.github.io/apptexasburguer/app-19-ia.js)     at nova (https://texasburguer.github.io/apptexasburguer/app-20-balao-interno.js)     at n (https://texasburguer.github.io/apptexasburguer/:69:35)     at tentarLogin (https://texasburguer.github.io/apptexasburguer/app-01-base-e-api.js)', 'tab-inicio', '1.1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome', '60f7eb8c89804c49c0d26e8effb72c09', 1),
	(9, '2026-10-15 22:59:03.574786+00', '2026-10-15 22:59:03.574786+00', '2026-10-15', '9866c7ad-b231-458d-aed3-34daa4d28268', 'Desenvolvedor', 'error', 'Uncaught ReferenceError: souStaffCaixa_ is not defined', 'https://texasburguer.github.io/apptexasburguer/app-04-pedidos-entrega.js:165:3', 'ReferenceError: souStaffCaixa_ is not defined     at renderMesasPainel_ (https://texasburguer.github.io/apptexasburguer/app-04-pedidos-entrega.js)     at pedidosPainel_ (https://texasburguer.github.io/apptexasburguer/app-13-conexao-sync.js)     at HTMLButtonElement.onclick (https://texasburguer.github.io/apptexasburguer/:734:80)', 'tab-pedidos', '1.1', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome', '4047580e3159b1a6251faa4cec870839', 1);


--
-- Data for Name: feedbacks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.feedbacks (id, venda_id, cliente_id, telefone_cliente, nota, comentario, data, status, origem, user_id, resposta, respondido_em, respondido_por) VALUES
	('67b70892-9d3b-4a97-aefc-6c60d1fc4dfb', NULL, '4c44d8c2-e528-4dd3-a9d9-91deffa68b3b', '16996224986', 5, 'Muito bom', '2026-10-12 03:22:20.924047+00', 'Novo', 'formulario', NULL, NULL, NULL, NULL),
	('b45566f5-7367-43ff-8df7-ea550a95eed9', '9167773a-64fe-4fb9-83d9-f77a9feabc7f', '4c44d8c2-e528-4dd3-a9d9-91deffa68b3b', '16996224986', 5, 'Muito bom', '2026-10-12 09:36:24.242551+00', 'Respondido', 'formulario', 'f6020864-6292-4584-979e-4f63db3b1560', 'Muito obrigado', '2026-10-12 09:38:08.160997+00', 'Jonatan');


--
-- Data for Name: fidelidade; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.fidelidade (id, cliente_id, carimbos, premios_resgatados, atualizada_em, observacoes) VALUES
	('0afcb3dd-53f4-4fa3-86ec-0b1716917ab9', '2e619cfb-66c2-413c-a942-8f13e145dd74', 1, 0, '2026-10-18 02:33:48.616288+00', NULL),
	('2db5c4ed-45a5-43b9-a13c-673f063babca', '6bcaeb27-093a-4863-b3c2-f1cb6d7dbf4f', 1, 0, '2026-10-17 23:14:55.517445+00', NULL),
	('6a317769-86d0-4707-a4c2-1330d8274c60', '4c44d8c2-e528-4dd3-a9d9-91deffa68b3b', 10, 4, '2026-10-18 01:25:03.451588+00', NULL),
	('98f294d1-7bed-4ac2-b58c-1092294e07de', '56d0342b-5df3-489d-963d-37950fcd3eb9', 6, 0, '2026-10-15 23:17:18.375969+00', NULL);


--
-- Data for Name: fiscal_empresa; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.fiscal_empresa (id, razao_social, nome_fantasia, cnpj, inscricao_estadual, regime, cep, logradouro, numero, complemento, bairro, municipio, codigo_municipio, uf, telefone, csc_id, serie, aliquota_simples, perfil_padrao_id, atualizado_em) VALUES
	(true, NULL, NULL, NULL, NULL, 'simples', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0.00, NULL, '2026-10-11 05:30:05.619474+00');


--
-- Data for Name: ifood_estado; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ifood_estado (id, ultima_consulta, ultima_consulta_ok, ultimo_pedido_em, token_ok, ultimo_erro, ultimo_erro_em, trava_dono, trava_ate, atualizado_em, financeiro_em, avaliacoes_em) VALUES
	(true, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-10-11 05:25:36.895217+00', NULL, NULL);


--
-- Data for Name: ifood_loja; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.ifood_loja (id, situacao, disponivel, motivo, pausada_ate, interrupcao_id, fechada_por_nos, verificado_em, bruto, atualizado_em) VALUES
	(true, NULL, NULL, NULL, NULL, NULL, false, NULL, NULL, '2026-10-11 05:28:39.382194+00');


--
-- Data for Name: indicacoes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.indicacoes (id, indicador_id, indicado_id, nome_indicador, telefone_indicador, nome_indicado, telefone_indicado, data, status, observacoes) VALUES
	('06f97979-b6f2-411c-b71a-e30012e3c398', '4c44d8c2-e528-4dd3-a9d9-91deffa68b3b', NULL, 'Lucas Ricardo', '(16) 99622-4986', 'Beatiz', '(00) 00000-0000', '2026-10-08 21:58:52.764396+00', 'Resgatado', '');


--
-- Data for Name: integracoes_config; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.integracoes_config (provedor, ligado, modo, ligado_em, ligado_por, checklist, config, atualizado_em) VALUES
	('ifood', false, 'producao', NULL, NULL, '{"conta_dev": false}', '{"baixaEstoque": "confirmacao", "enviarPrecos": true, "pausarSemEstoque": true, "abrirFecharComCaixa": true, "retencaoClientesDias": 90, "confirmacaoAutomatica": true}', '2026-10-18 00:36:18.024188+00'),
	('mercadopago', false, 'homologacao', NULL, NULL, '{}', '{"pixValidadeMin": 15, "testeNoCardapio": false}', '2026-10-14 20:33:43.459043+00'),
	('nfce', false, 'homologacao', NULL, NULL, '{}', '{"canais": ["balcao"], "emitirQuando": "pagamento"}', '2026-10-11 17:39:17.433512+00');


--
-- Data for Name: integridade_checks; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.integridade_checks (id, criado_em, supabase_vendas, planilha_vendas, diferenca_vendas, status, detalhe) OVERRIDING SYSTEM VALUE VALUES
	(1, '2026-10-08 01:12:27.052386+00', 3, 3, 0, 'ok', '{"data": "2026-10-07", "pendentes_fila": 0}'),
	(10, '2026-10-09 19:48:18.249001+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(11, '2026-10-09 19:48:18.81432+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(12, '2026-10-09 19:48:19.201459+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(13, '2026-10-09 19:48:19.274536+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(14, '2026-10-09 19:48:19.381696+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(15, '2026-10-09 19:48:19.489921+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(16, '2026-10-09 19:48:19.741335+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(17, '2026-10-09 19:48:20.007231+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(18, '2026-10-09 19:48:20.017368+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(19, '2026-10-09 19:48:20.152705+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(2, '2026-10-08 01:12:29.935738+00', 3, 3, 0, 'ok', '{"data": "2026-10-07", "pendentes_fila": 0}'),
	(20, '2026-10-09 19:48:20.541654+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(21, '2026-10-09 19:48:20.674515+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(22, '2026-10-09 19:48:21.083328+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(23, '2026-10-09 19:48:21.122931+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(24, '2026-10-09 19:48:27.214042+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(25, '2026-10-09 19:48:27.236656+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(26, '2026-10-09 19:48:27.876908+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(27, '2026-10-09 19:48:28.040725+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(28, '2026-10-09 19:48:28.418456+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(29, '2026-10-09 19:48:28.754749+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(3, '2026-10-08 01:13:30.293677+00', 3, 0, 3, 'erro', '{"data": "2026-10-07", "pendentes_fila": 0}'),
	(30, '2026-10-09 19:48:28.774933+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(31, '2026-10-09 19:48:52.496283+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(32, '2026-10-09 19:48:53.713001+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(33, '2026-10-09 19:49:10.136103+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(34, '2026-10-10 03:10:56.291997+00', 0, 0, 0, 'ok', '{"data": "2026-10-10", "pendentes_fila": 0}'),
	(35, '2026-10-10 09:10:03.710483+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(36, '2026-10-11 09:10:04.488216+00', 1, 1, 0, 'ok', '{"data": "2026-10-10", "pendentes_fila": 0}'),
	(37, '2026-10-12 09:10:04.028196+00', 6, 6, 0, 'ok', '{"data": "2026-10-11", "pendentes_fila": 0}'),
	(38, '2026-10-13 00:01:14.666995+00', 0, 0, 0, 'ok', '{"data": "2026-10-12", "pendentes_fila": 0}'),
	(39, '2026-10-13 00:02:51.893023+00', 1, 1, 0, 'ok', '{"data": "2026-10-12", "pendentes_fila": 0}'),
	(4, '2026-10-08 01:13:45.863467+00', 3, 0, 3, 'erro', '{"data": "2026-10-07", "pendentes_fila": 0}'),
	(40, '2026-10-13 09:10:05.855703+00', 1, 1, 0, 'ok', '{"data": "2026-10-12", "pendentes_fila": 0}'),
	(41, '2026-10-14 09:10:05.418956+00', 0, 0, 0, 'ok', '{"data": "2026-10-13", "pendentes_fila": 0}'),
	(42, '2026-10-15 09:10:04.126935+00', 1, 1, 0, 'ok', '{"data": "2026-10-14", "pendentes_fila": 0}'),
	(43, '2026-10-16 09:10:06.680253+00', 0, 0, 0, 'ok', '{"data": "2026-10-15", "pendentes_fila": 0}'),
	(44, '2026-10-16 22:36:11.766478+00', 0, 0, 0, 'ok', '{"data": "2026-10-16", "pendentes_fila": 0}'),
	(45, '2026-10-17 09:10:05.396472+00', 1, 1, 0, 'ok', '{"data": "2026-10-16", "pendentes_fila": 0}'),
	(5, '2026-10-09 17:21:51.559345+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(6, '2026-10-09 17:22:55.791254+00', 10, 10, 0, 'ok', '{"data": "2026-10-08", "pendentes_fila": 0}'),
	(7, '2026-10-09 19:48:12.300536+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(8, '2026-10-09 19:48:14.724493+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}'),
	(9, '2026-10-09 19:48:17.837254+00', 0, 0, 0, 'ok', '{"data": "2026-10-09", "pendentes_fila": 0}');


--
-- Data for Name: itens_venda; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.itens_venda (id, venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids) VALUES
	('05aa9673-a92e-4864-8ba0-ded823262008', '374babd5-dd07-464d-b817-15ecb8c92aad', '71b73436-5512-4ba4-9719-541b70aec6e0', NULL, 'Smash Cheddar', 1, 23.50, 0.00, 23.50, '{}'),
	('063f48c0-a739-4cfa-a016-4c66ea8b92e4', '13b25d4d-0082-46dd-89f0-dc07aa3ac932', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', NULL, 'Texas Honey', 1, 38.30, 0.00, 38.30, '{}'),
	('088eab75-9096-4766-83b4-0ee1a568d036', 'e733a406-8b9e-45c6-aa1a-02c45cfb42db', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', NULL, 'Texas Honey', 1, 38.30, 0.00, 38.30, '{}'),
	('16266e30-c717-4022-8cc5-6d4db5bc48cf', '4136a8ae-9068-4f8f-a555-987c16aa05f9', '71b73436-5512-4ba4-9719-541b70aec6e0', NULL, 'Smash Cheddar', 1, 23.50, 9.19, 23.50, '{}'),
	('1fc7de5f-f3a4-439f-b7a2-7455efc3f571', 'a1417a8b-3e58-4b73-ae37-9728f7849e7f', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', NULL, 'Frango Bacon', 1, 38.00, 0.00, 38.00, '{}'),
	('227bf6d4-74af-4eba-a07b-34c6b7e49c97', '9d475828-40c1-43a5-994f-48fd4fc3efc7', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', NULL, 'Frango Bacon', 1, 38.00, 0.00, 38.00, '{}'),
	('2658cf3f-a3c9-43c1-8e5d-1b27e3775c19', 'dea8e60c-8703-4e9f-8220-045e421e7f5a', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', NULL, 'Batata Recheada Frango Bacon e Catupiry', 1, 41.00, 0.00, 41.00, '{}'),
	('2d724494-ceb5-4a52-877f-4c1cbf1aee94', '6ae32da0-8576-4ddb-8634-889649f5844c', '2b54201e-9524-4e52-9615-53eef6fae6f6', NULL, 'Frango Bacon Catupiry', 1, 39.00, 0.00, 39.00, '{}'),
	('3417da85-cfef-4aed-a80a-fba31dadf4f5', 'a0dcadb0-adc2-4af5-ac03-2a8ec08563f6', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', NULL, 'Batata Recheada Frango Bacon e Catupiry', 1, 43.00, 0.00, 43.00, '{}'),
	('394c6978-ade4-4dc2-88b2-f0251743e8b0', 'ee77d427-2849-471a-a0b8-13f096b8980f', '59fc09ea-7730-40ef-b700-6388068e3ec8', NULL, 'Smash Catupiry', 1, 23.50, 0.00, 23.50, '{}'),
	('45ab2c35-cfef-4f2d-bc1a-0ab7ffac3932', '04903c16-fbda-434c-8b0e-5257b533b932', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', NULL, 'Texas Honey', 1, 38.30, 0.00, 38.30, '{}'),
	('48c81975-fa60-4d93-b56a-eeaf1720df52', '68f9fb39-9f84-418a-b102-e0689553e46c', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', NULL, 'Churrasco Tudo', 1, 50.85, 0.00, 50.85, '{}'),
	('59927756-8164-4a70-b539-7031cba10a48', 'a0dcadb0-adc2-4af5-ac03-2a8ec08563f6', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', NULL, 'Texas Honey + Cheddar extra + Molho ranch', 1, 38.30, 0.00, 38.30, '{081a3274-b818-4fe1-908a-32a8f752e302,80e18270-3011-46cb-a5f3-10197a5d728a}'),
	('6c34ea6e-f4e6-4a20-9ba9-d975c617e1dd', 'd07bd917-e19a-4776-81e6-3c112ef5b483', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', NULL, 'Texas Honey', 1, 38.30, 0.00, 38.30, '{}'),
	('6cf37afe-61d5-45bf-959b-2f411d1091a0', '9167773a-64fe-4fb9-83d9-f77a9feabc7f', NULL, '658a1f7f-bd39-4e62-982b-cc42d09f2a86', 'Combo Texas', 1, 79.00, 0.00, 79.00, '{}'),
	('7885bce7-00a3-4ebb-b2a4-fb5647980bbc', '43094350-80ee-45ad-aed3-724f0bede2de', '2b54201e-9524-4e52-9615-53eef6fae6f6', NULL, 'Frango Bacon Catupiry', 1, 39.00, 0.00, 39.00, '{}'),
	('7936f69b-856c-479c-af77-9ca1f007070b', '1823af77-ffad-41cf-83bc-9cc01499649e', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', NULL, 'Texas Honey', 1, 38.30, 0.00, 38.30, '{}'),
	('7c38b675-e6fc-4dd2-88b2-906bb732647e', '6764a51b-5684-440d-83cd-1e330778058f', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', NULL, 'Churrasco Tudo', 1, 50.85, 0.00, 50.85, '{}'),
	('7e516b04-68c0-4f59-a176-1492d0cb91c0', '9358c5da-eb26-4443-92a5-27edc965c976', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', NULL, 'Texas Honey', 1, 38.30, 0.00, 38.30, '{}'),
	('863108e3-ea5d-4bdd-90ba-4a725ac0a23c', '2136dcd6-6c45-4e2d-a99e-2ea84dd5c3fb', '2b54201e-9524-4e52-9615-53eef6fae6f6', NULL, 'Frango Bacon Catupiry', 1, 39.00, 0.00, 39.00, '{}'),
	('8934c0d5-f390-441e-b9c1-b1cfe4396354', '264380f4-e558-4770-a575-532d7c031655', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', NULL, 'Barbecue Mister', 1, 39.50, 0.00, 39.50, '{}'),
	('898dc9fd-63ef-4298-b6fc-0ac8827d419d', '8800bc70-4d0f-4abc-81d5-0be42e9dc846', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', NULL, 'Churrasco Tudo', 1, 50.85, 0.00, 50.85, '{}'),
	('89dae0aa-7b8b-4dc3-b48a-43be41c93ba1', '13b25d4d-0082-46dd-89f0-dc07aa3ac932', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', NULL, 'Batata Recheada Frango Bacon e Catupiry', 1, 41.00, 0.00, 41.00, '{}'),
	('aab1d105-7f20-434f-a662-7ba8e0bbb7ee', 'be0554f9-65a1-4e03-8b58-74007189eceb', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', NULL, 'Texas Honey', 1, 38.30, 0.00, 38.30, '{}'),
	('ab3f3c01-3596-44dc-92ed-35820711a187', '15ff779b-e968-4947-9e6d-4755d1dd62ff', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', NULL, 'Texas Honey', 1, 38.30, 0.00, 38.30, '{}'),
	('ad451485-6913-4a84-9eaa-277860faec01', 'fca14f9b-9e40-44fb-9777-0cc61a5db211', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', NULL, 'Batata Recheada Frango Bacon e Catupiry', 1, 41.00, 0.00, 41.00, '{}'),
	('b5e4ae3f-3a80-45df-a666-6b75bc7821f0', 'bd8c4cd8-9b40-49ee-9f9b-0026223e3151', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', NULL, 'Texas Honey', 1, 38.30, 0.00, 38.30, '{}'),
	('c53d34d2-021f-4b77-92ab-ea2953dd3746', 'bb1d3bd6-9494-47b8-b67b-cc4cf67e1220', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', NULL, 'Texas Honey', 1, 38.30, 0.00, 38.30, '{}'),
	('cbc77440-e67f-4b14-b8d9-3bee6cd387c9', '1b5d1529-bca4-452b-b658-0d6799f4c644', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', NULL, 'Texas Honey', 1, 38.30, 0.00, 38.30, '{}'),
	('d65438a6-ff5e-46ab-89a9-beccc7f4f558', '3248a39c-0656-43e2-a5ea-6f368568bb2d', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', NULL, 'Batata Recheada Frango Bacon e Catupiry', 1, 41.00, 0.00, 41.00, '{}'),
	('da5ebe95-857d-4ccc-9370-7a5bb5f23cd6', 'f6e79d89-0bb5-4f1f-8765-07ed2a9096e9', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', NULL, 'Texas Honey', 1, 38.30, 0.00, 38.30, '{}'),
	('dbe3d22a-f97b-49d2-be60-0e39a2662acb', '6ae32da0-8576-4ddb-8634-889649f5844c', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', NULL, 'Batata Recheada Frango Bacon e Catupiry', 1, 41.00, 0.00, 41.00, '{}'),
	('df9774bb-8bbf-4f37-ac17-4b22440169b3', '957fcd6b-3977-4449-b209-8e19e9d76f6a', '59fc09ea-7730-40ef-b700-6388068e3ec8', NULL, 'Smash Catupiry', 1, 23.50, 0.00, 23.50, '{}'),
	('e72af394-e957-4f3a-9524-ff6b549e1b12', 'ce1970c5-e982-4745-ac8c-0316ab5299ab', NULL, 'd49ad88d-6fdf-4510-aa5f-c96ee9fd91d4', 'Combo X Bacon', 1, 99.90, 0.00, 99.90, '{}'),
	('f5d6f51f-dce9-4876-96a8-647dc2ab3377', '0e4f13c6-1149-4547-a29c-0cc48ae7af93', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', NULL, 'Texas Honey', 1, 38.30, 0.00, 38.30, '{}');


--
-- Data for Name: mesas_codigos; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.mesas_codigos (mesa_id, codigo, gerado_em) VALUES
	('6ce68177-48f7-4aad-a759-96034c371d5f', 'f5744f02f8e5', '2026-10-08 22:11:33.995678+00');


--
-- Data for Name: movimentacoes_estoque; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.movimentacoes_estoque (id, ingrediente_id, tipo, quantidade, qtd_antes, qtd_depois, motivo_referencia, usuario_id, data) VALUES
	('01364d22-77f8-482e-aa14-f547a4e590fb', '00ccbdd1-3e61-4e0c-b467-04abb8c9f9fc', 'Ajuste', -3.000, 3.000, 0.000, 'Edição manual do cadastro', '9866c7ad-b231-458d-aed3-34daa4d28268', '2026-10-15 09:54:51.384353+00'),
	('438bdaae-507b-4001-b658-4c8506e47e33', '8c352f67-b128-4eb6-b112-38ea50440b03', 'Ajuste', 1.000, 0.000, 1.000, 'Edição manual do cadastro', '9866c7ad-b231-458d-aed3-34daa4d28268', '2026-10-17 19:25:08.245246+00'),
	('495efa61-04fa-4139-9284-fd6eb2fe9f60', '18d885f8-2f6f-43db-b6ef-b3a5af5f6387', 'Entrada', 1.000, 0.000, 1.000, 'Estoque inicial do cadastro', '9866c7ad-b231-458d-aed3-34daa4d28268', '2026-10-17 19:30:53.281139+00'),
	('5fa63469-6616-4af1-b08e-de390689258f', '102e626e-de6c-4354-8a68-108f3639a677', 'Ajuste', 30.000, 0.000, 30.000, 'Edição manual do cadastro', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', '2026-10-16 00:15:25.22868+00'),
	('61d63f23-2d40-40b6-aa68-bd5f9b7515d0', 'aa6bd6a9-6065-43c2-8a57-406616c6edf0', 'Venda', -1.000, 0.000, -1.000, 'Venda #4136a8ae', NULL, '2026-10-17 22:52:23.372227+00'),
	('630bc6f0-af79-4932-b2c3-29d60dc79fa1', '00ccbdd1-3e61-4e0c-b467-04abb8c9f9fc', 'Ajuste', 3.000, 0.000, 3.000, 'Edição manual do cadastro', '9866c7ad-b231-458d-aed3-34daa4d28268', '2026-10-15 01:18:27.036973+00'),
	('6c0ba7e1-373b-4731-b565-53ce2b77b3a6', 'd5b72b65-a2c0-43cb-a59c-4bb3bb79035a', 'Venda', -0.040, 1.000, 0.960, 'Venda #4136a8ae', NULL, '2026-10-17 22:52:23.372227+00'),
	('89aa8cfa-1ffd-4962-9b94-43932381d936', '0e3054a3-96c8-43dd-b2cc-3bf7ce8769ca', 'Ajuste', 30.000, 0.000, 30.000, 'Edição manual do cadastro', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', '2026-10-16 00:14:43.411743+00'),
	('8b484e48-ca9a-4c47-9482-bfdcad5f2998', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 'Entrada', 6.000, 0.000, 6.000, 'Estoque inicial do cadastro', '9866c7ad-b231-458d-aed3-34daa4d28268', '2026-10-17 19:27:14.52632+00'),
	('945d43d7-8fa3-442f-9af3-cc96721e7895', '46354a04-75b6-47f8-8044-6395ff26e2fd', 'Venda', -0.030, 0.000, -0.030, 'Venda #4136a8ae', NULL, '2026-10-17 22:52:23.372227+00'),
	('95eea8e7-307c-4973-92b1-6bd8c7b1e624', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 'Venda', -0.080, 6.000, 5.920, 'Venda #4136a8ae', NULL, '2026-10-17 22:52:23.372227+00'),
	('bed95fc5-323f-4289-a8a8-9f6ead1e26e6', '00ccbdd1-3e61-4e0c-b467-04abb8c9f9fc', 'Ajuste', 8.000, 0.000, 8.000, 'Edição manual do cadastro', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', '2026-10-16 00:13:41.772762+00'),
	('d59f5f70-9d4c-4be8-b6fc-36b9f5c41b34', 'd5b72b65-a2c0-43cb-a59c-4bb3bb79035a', 'Ajuste', 1.000, 0.000, 1.000, 'Edição manual do cadastro', '9866c7ad-b231-458d-aed3-34daa4d28268', '2026-10-17 20:02:39.53962+00'),
	('d80e7f25-7348-40fe-8d53-d71a4f16fc89', '22c85853-8043-4ea8-9ff7-39c7562c0102', 'Entrada', 15.000, 0.000, 15.000, 'Estoque inicial do cadastro', '9866c7ad-b231-458d-aed3-34daa4d28268', '2026-10-17 19:21:42.855458+00');


--
-- Data for Name: pagamentos_venda; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.pagamentos_venda (id, venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo) VALUES
	('0724d9ad-33c9-4794-8744-ee5db6808d77', '8800bc70-4d0f-4abc-81d5-0be42e9dc846', 'Dinheiro', 58.85, 0.00, 0),
	('0a81f81d-64cc-47b2-b685-6588f466723b', '9d475828-40c1-43a5-994f-48fd4fc3efc7', 'Dinheiro', 46.00, 0.00, 0),
	('13dce776-b013-4f0e-81ec-6ae48868f94f', 'bd8c4cd8-9b40-49ee-9f9b-0026223e3151', 'Cartão de Crédito', 46.30, 0.00, 0.00),
	('22c31659-6c4c-4509-90de-0cd35d48938f', '264380f4-e558-4770-a575-532d7c031655', 'Dinheiro', 47.50, 0.00, 0),
	('29a3177d-91a2-471b-bb79-b3f616bc1ad9', 'e733a406-8b9e-45c6-aa1a-02c45cfb42db', 'Cartão de Débito', 46.30, 0.00, 0.00),
	('327c9229-1cae-4c61-a9e0-9b17c0a956e5', '43094350-80ee-45ad-aed3-724f0bede2de', 'Dinheiro', 47.00, 0.00, 0),
	('33d805e6-ee3c-4d46-a4ff-721e6430c918', '68f9fb39-9f84-418a-b102-e0689553e46c', 'Cartão de Débito', 58.85, 0.00, 0),
	('381072eb-92b5-4efe-90bd-3f58602a2058', 'fca14f9b-9e40-44fb-9777-0cc61a5db211', 'Dinheiro', 141.00, 0.00, 0),
	('6d5386be-fb57-44be-a38c-89ed942e1f73', '6764a51b-5684-440d-83cd-1e330778058f', 'Dinheiro', 58.85, 0.00, 0),
	('7d6e65a7-6ff8-4866-b6cd-8a0e35c3244d', '13b25d4d-0082-46dd-89f0-dc07aa3ac932', 'Dinheiro', 39.65, 0.00, 0),
	('8945f428-fffd-4eae-a17f-b8c720fb0492', '6ae32da0-8576-4ddb-8634-889649f5844c', 'Dinheiro', 40.00, 0.00, 0),
	('8d97a631-4e7e-4f76-82b8-2501321440c9', '0e4f13c6-1149-4547-a29c-0cc48ae7af93', 'Dinheiro', 46.30, 0.00, 0.00),
	('8faa33ab-2d6b-4d58-86f4-4b6e7eb314d8', 'f6e79d89-0bb5-4f1f-8765-07ed2a9096e9', 'Dinheiro', 46.30, 0.00, 0),
	('9004a4ec-cf12-4bd5-804e-a8ae1803b30b', '1823af77-ffad-41cf-83bc-9cc01499649e', 'Dinheiro', 38.30, 0.00, 0.00),
	('90459623-3afd-45da-b956-e47ecbae8623', 'a0dcadb0-adc2-4af5-ac03-2a8ec08563f6', 'Cartão de Débito', 89.30, 0.00, 0.00),
	('99e0c387-4d35-480d-b46e-91c242189223', '9358c5da-eb26-4443-92a5-27edc965c976', 'Dinheiro', 38.30, 0.00, 0.00),
	('9b0547ff-2b3c-44b6-9771-20cf86dbd880', '4136a8ae-9068-4f8f-a555-987c16aa05f9', 'Pix', 31.50, 0.00, 0.00),
	('9d0cfb89-6e4c-45ec-b1df-1b7de76e92a4', '2136dcd6-6c45-4e2d-a99e-2ea84dd5c3fb', 'Dinheiro', 47.00, 0.00, 0),
	('9f7f2eac-b73c-4cf0-a512-2b5d8ea159bd', '957fcd6b-3977-4449-b209-8e19e9d76f6a', 'Cartão de Débito', 31.50, 0.00, 0),
	('a07c3c01-04f2-4b6f-83b3-352b5b5905f9', '04903c16-fbda-434c-8b0e-5257b533b932', 'Dinheiro', 46.30, 0.00, 0.00),
	('b0527aa5-8a0f-4f05-a7d2-89ec87b55167', 'd07bd917-e19a-4776-81e6-3c112ef5b483', 'Dinheiro', 46.30, 0.00, 0),
	('cb0b7859-5682-4b86-896e-f1fd91266c05', 'ee77d427-2849-471a-a0b8-13f096b8980f', 'Dinheiro', 31.50, 0.00, 0),
	('d284af37-6813-46d7-a885-2b3164ae1cd4', '9167773a-64fe-4fb9-83d9-f77a9feabc7f', 'Cartão de Crédito', 87.00, 0.00, 0.00),
	('d5737231-8dcc-49ab-9cd5-8f0592969fb8', '15ff779b-e968-4947-9e6d-4755d1dd62ff', 'Cartão de Débito', 46.30, 0.00, 0.00),
	('d9d34043-2f9c-4937-8d42-270567ce0342', '3248a39c-0656-43e2-a5ea-6f368568bb2d', 'Dinheiro', 49.00, 0.00, 0),
	('e7548ae3-da37-4bc8-800b-5b81c8cc6233', '374babd5-dd07-464d-b817-15ecb8c92aad', 'Dinheiro', 31.50, 0.00, 0.00),
	('f04c6537-dec0-46d4-afca-2056e9e412a7', 'a1417a8b-3e58-4b73-ae37-9728f7849e7f', 'Cartão de Crédito', 46.00, 0.00, 0),
	('f2557b02-339b-4d78-a2c0-41014ab74205', 'be0554f9-65a1-4e03-8b58-74007189eceb', 'Dinheiro', 38.30, 0.00, 0),
	('f37f2e2d-f50c-4cab-a3b0-79fef9848a54', '1b5d1529-bca4-452b-b658-0d6799f4c644', 'Cartão de Crédito', 46.30, 0.00, 0),
	('f3f372e3-a585-4ae6-a08f-85e9767d7324', 'ce1970c5-e982-4745-ac8c-0316ab5299ab', 'Dinheiro', 99.90, 0.00, 0.00),
	('fa4a77f1-152d-428c-854e-a5798a7495f3', 'dea8e60c-8703-4e9f-8220-045e421e7f5a', 'Dinheiro', 41.00, 0.00, 0),
	('fc8e73ec-ae67-4982-b447-34a0821831b8', 'bb1d3bd6-9494-47b8-b67b-cc4cf67e1220', 'Dinheiro', 38.30, 0.00, 0);


--
-- Data for Name: produto_adicionais; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.produto_adicionais (id, produto_id, adicional_id) VALUES
	('00be0d0d-ab87-4b81-a254-f36336afbc8a', '5f5533e0-5760-4edd-a22d-9122097da388', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('00dd0ebb-143d-40de-907d-14c68f3a2f25', '63841581-68f3-4cfa-bc81-c78466e5ec5b', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('00e7608e-b75d-4b84-8908-ce8b6997bb13', '63841581-68f3-4cfa-bc81-c78466e5ec5b', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('01b95b34-0474-4b85-b130-d46a6d4e2312', '60a58561-6800-44b4-8074-d70d035bb1a2', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('01c9a785-e1b3-41b1-a705-9d395f73749b', '43087961-297c-4b43-8ddd-1484188baab2', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('02df0601-e65e-4545-b48c-c86afae44bf3', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('04b3e84a-1120-468e-b914-78d8a5651182', '5f5533e0-5760-4edd-a22d-9122097da388', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('04c37020-4e74-4cd1-9a7c-75644175ca95', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('06a83176-c714-448e-896f-c55a216747a2', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('06f1cb45-1024-46d0-be81-38162168db3c', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('0733710e-862c-4a05-b652-5bc9aff788b4', '60a58561-6800-44b4-8074-d70d035bb1a2', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('07bbc3d8-59f1-4d6d-b434-190df11e8022', '4014c744-53bc-4148-8fcf-0799918e88aa', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('092ff40b-6544-498c-9c6e-b7780c785c02', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('09bf2f23-fb36-45f5-9a76-ae4b4cd7901b', '63841581-68f3-4cfa-bc81-c78466e5ec5b', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('09d90800-1f11-4567-b317-fc98aa2d4ec4', '43087961-297c-4b43-8ddd-1484188baab2', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('0ae54208-c61b-4dfd-8042-fea85d5dc4d2', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('0ba6e01d-f36a-44f1-9333-9a5057bb6f7f', '4436ddb0-689e-4b7e-954a-faa1999288a7', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('0be50fa6-11f2-4822-9f9f-808f881e7581', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('0c8763c2-d732-46a5-9666-2d32f60fe1d5', '5fb6f8d6-49ed-4587-be09-333b67419ac0', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('0cf45a19-e7d1-464d-b9da-0bf3a658b17a', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('0d6d525b-6dbe-44e7-a4b4-7879c74a3e45', 'dca3fa98-20e5-487f-a479-5920c7783cab', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('0ff751f6-c97c-4407-9333-2dab64d36e6d', '25b30ac0-81b5-46bd-b3ad-876b48a78251', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('1017b1f0-c35d-45d4-ae7e-5307527c4c61', '43087961-297c-4b43-8ddd-1484188baab2', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('103f7f54-15a2-456a-8351-da590ee6bd3a', '5a98547e-4cca-4a74-bc73-6822c3b8d069', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('104b95df-db1b-4823-994e-291bc37d3ae8', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('11376415-217f-488a-9b3b-414eee8df8b7', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('11daa912-314b-4a33-bc84-40b821b8f9fa', '93ea5ac0-5b1f-42ce-9289-478820d9108d', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('1258af1d-355e-4c7a-a406-5f9d8143b809', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('12973af9-c415-4937-882e-01dc8aeb48cd', '1658ebed-648f-4150-bf26-f50993a72243', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('12df9228-ffa0-4442-9c48-6b953dbf0d05', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('12f1ee6e-05ec-4c2a-9f34-faee2334ba6d', '64142b67-ba38-41fe-8e46-68213b65a342', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('136c6806-b666-4fcc-8f43-40a180f33ec2', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('13f8de4d-8158-4455-98f8-780592fe3e55', '8e155a9a-175c-4fb8-890e-97409b2953c8', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('1519b74e-22a5-47c0-8fff-a4b4979bd57b', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('1523c63a-3d42-4a58-97f9-b8e9f725fe2e', '50516989-1011-4b8c-bde9-9ed0750f4a07', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('156297ad-ad5c-4571-b02f-3f1f04a99143', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('15d4a415-c50d-4889-83e8-91cd4a207f78', '4436ddb0-689e-4b7e-954a-faa1999288a7', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('15ff897c-cc02-4ff6-b929-bae293b85b67', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('16f5d8b7-72e9-4336-ae4c-7793d76f3a25', '1658ebed-648f-4150-bf26-f50993a72243', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('1791b88c-37e4-4e96-a92a-2026363023da', '1658ebed-648f-4150-bf26-f50993a72243', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('183fbfd1-f5c5-4673-879c-825d3dd6d24c', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('19521755-2443-4853-9c35-641f4bfb663e', '5c9f187f-de24-4615-9042-78e1773e904b', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('1b70e146-9f84-4cc3-9da5-589d87ff322d', '717f21cc-de1d-4881-942a-4601e8bf45f0', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('1b8a139f-051d-463d-8e19-73733b77672c', '7583e038-e58c-41a8-867c-026f1b90d787', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('1b938f25-c809-45bc-8784-48f47e94f739', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('1bbc312f-f2e6-48b4-a88b-292ce27cb639', '60a58561-6800-44b4-8074-d70d035bb1a2', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('1bca7fb1-d0a7-4f9f-bbd1-df4b14c587e4', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('1c7619fb-6adf-4f88-9a2f-cf6762f2fe8d', '86519e93-90e6-4174-b509-136cf9f43430', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('1d00ec23-9f67-4e17-96cb-c32b000007cc', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('1d7314c2-c697-48f7-9c3d-ddcbb97f5dca', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('1de747b1-dc2f-4749-a39b-7265a1e110b3', '93ea5ac0-5b1f-42ce-9289-478820d9108d', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('1e2d2dc2-d586-4ef3-af5c-929dfb71e050', '63841581-68f3-4cfa-bc81-c78466e5ec5b', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('1e42b4f3-a90c-49a2-b083-6b3a284b8a2f', '25b30ac0-81b5-46bd-b3ad-876b48a78251', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('1f80cfc7-4c33-4204-baf0-7a8897460458', '7583e038-e58c-41a8-867c-026f1b90d787', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('200528d9-d53d-47ad-9f29-ba3a44179292', '5c9f187f-de24-4615-9042-78e1773e904b', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('21bbeab9-19ca-49b3-8d8c-482af84ce188', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('21e8015f-42fc-4dbd-bbc7-daa4208a04f5', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('234da8c4-df3c-42ed-be2e-f678459182c0', '4436ddb0-689e-4b7e-954a-faa1999288a7', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('27f5b1b9-fc8a-4a93-b75f-d99a89d4b931', '5a98547e-4cca-4a74-bc73-6822c3b8d069', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('2a1a2af8-303c-4a03-b740-74b5897f3400', '4014c744-53bc-4148-8fcf-0799918e88aa', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('2ca4cb93-e6de-47e4-b176-f8d7bc183988', '2b54201e-9524-4e52-9615-53eef6fae6f6', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('2e367146-5f1f-46aa-956f-6a6937020d02', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('2e69200a-f4e0-4ee4-a299-646cb55ea5c6', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('2efa2ef3-5d17-48b0-a7c4-57cc4893a926', '5a98547e-4cca-4a74-bc73-6822c3b8d069', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('302f6cbc-f770-43b3-b36a-d1c6d576b15d', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('309b0d08-2dc7-4d51-b837-cb9f7a69ade3', '5fb6f8d6-49ed-4587-be09-333b67419ac0', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('326140ca-f9a1-401e-9343-d2de0f6b4de1', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('335e48de-a1fb-486e-b402-204d1498b990', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('33910c5f-e340-42d7-ac2e-3ca859c9cd9f', 'ee5b570a-759c-42aa-929b-efb390436f1a', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('33b38e79-943d-4e58-904a-f57555e3ab19', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('34e7b7d9-c1aa-4d4e-ba35-f94797dbc1be', '65226aff-26be-4bbe-9222-62cd159ba207', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('35ce6895-545d-436a-b2b8-57d68232a87e', '5a98547e-4cca-4a74-bc73-6822c3b8d069', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('3622f72f-803a-4b59-b19f-6d336926271d', '63841581-68f3-4cfa-bc81-c78466e5ec5b', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('3666c035-b111-4cb4-a937-a2ed2220d287', '7583e038-e58c-41a8-867c-026f1b90d787', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('36764e1d-4ee7-4e0f-8398-6eaa174a0c48', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('36a3d4d4-9bc4-43f5-97f8-0eee6a079c67', '5f5533e0-5760-4edd-a22d-9122097da388', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('3801356f-b2be-4ba4-a4b0-476b030e8b12', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('3926666d-0748-4b55-8e6c-db173b410e50', '2b54201e-9524-4e52-9615-53eef6fae6f6', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('39a97d80-059f-4cb9-8ce0-739c44f46423', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('39b82998-09cc-4867-b4cf-324618496692', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('39f8cc6a-2bfb-4f40-bd93-015da2c63fe2', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('3a5ddec3-bf92-4fda-ae72-de907144c848', '93ea5ac0-5b1f-42ce-9289-478820d9108d', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('3bd9777e-901e-4ead-9cf5-7e415b5339dd', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('3c512ddf-d566-4175-8e33-3f57eae3f9d3', '64142b67-ba38-41fe-8e46-68213b65a342', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('3d5432ac-e0d0-45be-a588-c62885be0139', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('3d9b35b9-2f40-421d-8439-fe54fbaad85b', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('3fee715d-36e3-4dc0-9f01-6ff5b6c301b0', '5a98547e-4cca-4a74-bc73-6822c3b8d069', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('3ff5290a-8dfc-44a3-afc3-2370995a0d92', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('40c20619-81f5-4b4f-b828-fc7ec504e832', 'ee5b570a-759c-42aa-929b-efb390436f1a', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('41766d5c-6f50-4c5d-b7e8-09722646c5e2', '50516989-1011-4b8c-bde9-9ed0750f4a07', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('42f5ae41-e606-404e-92a8-c0a800c3b3f4', '60a58561-6800-44b4-8074-d70d035bb1a2', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('43db23f5-51f1-4ea2-90b1-9b5ba75f9994', '8e155a9a-175c-4fb8-890e-97409b2953c8', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('445c3aed-6f1d-4ffb-8a56-f326829a40b0', '43087961-297c-4b43-8ddd-1484188baab2', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('45066074-1ecd-453d-88aa-8269b97b51ac', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('450c69ea-b699-4dbc-94da-8e2f0a459564', '4014c744-53bc-4148-8fcf-0799918e88aa', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('45239eed-cc9f-42da-a5af-343d4f886d0a', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('45d1dc7f-e3ae-4d3d-8afd-8e4f656015e4', '60a58561-6800-44b4-8074-d70d035bb1a2', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('4781fbc8-838b-47ae-a7d3-32cb6bb68705', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('48fb0c90-6206-44c2-83ff-52908c8a18af', '3338daa5-5f14-4236-92b6-1cee71c509b2', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('49190f81-9505-49a5-9591-0c4cd1af6d1f', '3338daa5-5f14-4236-92b6-1cee71c509b2', '081a3274-b818-4fe1-908a-32a8f752e302');
INSERT INTO public.produto_adicionais (id, produto_id, adicional_id) VALUES
	('4a814bb8-a03d-42a8-8d8b-3ac3fe92bdd6', 'dca3fa98-20e5-487f-a479-5920c7783cab', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('4aa5afbd-1bdd-4c39-9fa6-7a4978697a80', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('4ab38f51-0c02-4362-9866-62c132170eb0', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('4c82f856-aac1-454f-9ebf-f0b25e81bf8a', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('4cac5714-9b2a-4d4b-a29f-c6042f36d7f8', '5a98547e-4cca-4a74-bc73-6822c3b8d069', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('4cb5ebd0-d874-49ef-a90e-d09342a29c65', '1658ebed-648f-4150-bf26-f50993a72243', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('4cdcf167-37fb-4ad9-8bd7-2b10dc708ae3', '3338daa5-5f14-4236-92b6-1cee71c509b2', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('4d1f10dc-aae1-49a8-81f3-2735261871f5', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('4dd44a4f-1899-4bb1-8fe8-da36194058c7', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('4de06c12-5dcb-4d0e-906f-88ccdaad2119', '25b30ac0-81b5-46bd-b3ad-876b48a78251', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('4ef3ff85-1330-400b-ad75-b84c8875357f', '8e155a9a-175c-4fb8-890e-97409b2953c8', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('4eff5ed8-5b19-4bef-ad7b-2e3409d36238', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('4ffb1538-2163-4eb8-b3ac-d0e28c3b1f73', '7583e038-e58c-41a8-867c-026f1b90d787', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('50b858c8-6d40-463c-bbf6-5265b49a246b', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('51fb6727-5052-40bd-8d0c-b02090b3c7ea', '43087961-297c-4b43-8ddd-1484188baab2', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('52e03145-7b91-42d9-8908-72557603f163', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('547b266d-8061-43a7-9226-503d567f90dd', '5c9f187f-de24-4615-9042-78e1773e904b', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('559fc490-9d38-4283-9ae0-e40d23ad024d', '93ea5ac0-5b1f-42ce-9289-478820d9108d', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('55c2eb90-a8af-427f-813c-39a05075cff1', 'dca3fa98-20e5-487f-a479-5920c7783cab', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('55dd2958-5df8-4460-ab0e-3e551a1425df', '7583e038-e58c-41a8-867c-026f1b90d787', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('565561d7-e288-4671-a017-b6a4df310575', '4436ddb0-689e-4b7e-954a-faa1999288a7', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('56c12404-a843-42d0-b74c-9b88ede1c4a7', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('58401fe0-8148-4051-bc6c-7c4c23159b1e', '50516989-1011-4b8c-bde9-9ed0750f4a07', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('59880644-92d6-4470-92e1-39e30f353870', '8e155a9a-175c-4fb8-890e-97409b2953c8', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('59abad45-8513-441e-8b77-535842921299', 'dca3fa98-20e5-487f-a479-5920c7783cab', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('59ef9799-2f25-49fd-bab7-1a06f02bce34', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('5aed7632-b2f8-4e2e-86db-21ebd998df89', '86519e93-90e6-4174-b509-136cf9f43430', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('5b064667-4f63-4997-9bed-baddd5d5b755', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('5b1cdfc5-8413-45a7-8f7f-d83943a8688c', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('5b704d2e-5e94-43bb-a3c0-9cd71c01f9a7', '4436ddb0-689e-4b7e-954a-faa1999288a7', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('5c203782-c28b-4522-8dcd-c0fa6424bc28', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('5c234cd9-ed69-4eb5-9c8b-23a9f5d9412d', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('5c71e569-8d51-4b9c-a4ef-7013a6f6e711', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('5f3c5498-4968-4f03-956e-646de7466809', 'dca3fa98-20e5-487f-a479-5920c7783cab', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('63652936-a0eb-4731-bb47-584b7dd049ce', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('648e58cb-e177-4fcf-8abe-2084469d07fa', 'dca3fa98-20e5-487f-a479-5920c7783cab', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('649fab5f-49fb-4ae3-aced-ef25e0a31ea3', '3338daa5-5f14-4236-92b6-1cee71c509b2', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('6538abb6-1d4e-4e4c-af3f-a94cb001132b', '5a98547e-4cca-4a74-bc73-6822c3b8d069', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('66799e42-2b1d-4ef4-b747-033576c83944', '5a98547e-4cca-4a74-bc73-6822c3b8d069', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('67c642ad-77f8-4f01-97da-9de6e9d1b4ab', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('67cd1a97-fb34-41c0-ba35-d50bc3403ac7', '25b30ac0-81b5-46bd-b3ad-876b48a78251', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('68487461-7474-43a3-8d74-6a13a1efec20', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('685635d5-247e-4e2b-8f5f-2e6765864d2b', '86519e93-90e6-4174-b509-136cf9f43430', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('68877258-8a8c-4cfa-ba46-53d1711ef17b', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('688974eb-5c3c-499d-b972-507146e96aea', '5f5533e0-5760-4edd-a22d-9122097da388', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('6934d2b3-ac50-449a-b6f1-6db25877e61e', '86519e93-90e6-4174-b509-136cf9f43430', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('69900e61-55a2-4472-97cb-7eb4600eda70', '2b54201e-9524-4e52-9615-53eef6fae6f6', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('699b1c07-116b-46dd-b717-5060987b7b87', '25b30ac0-81b5-46bd-b3ad-876b48a78251', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('6a1f1344-1426-4871-aeb3-1fab39ca221a', '1658ebed-648f-4150-bf26-f50993a72243', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('6af7bcd8-68cb-45af-8c8c-17df5e7f5c45', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('6b9e5687-b918-4831-b6f7-1adc55d53c27', '5c9f187f-de24-4615-9042-78e1773e904b', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('6c0fcd7a-d055-43a5-8663-c3e07dcb9c58', '65226aff-26be-4bbe-9222-62cd159ba207', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('6c54b051-4005-4bf2-bf55-8597e5084afc', '65226aff-26be-4bbe-9222-62cd159ba207', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('6cd6aecd-8cd4-4b08-87fa-50486c52308f', '60a58561-6800-44b4-8074-d70d035bb1a2', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('71848d3b-5edc-47c1-99cf-c4a0aa69b1d7', '65226aff-26be-4bbe-9222-62cd159ba207', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('71a1118d-b71e-488c-aad5-7d07dee0ab66', '86519e93-90e6-4174-b509-136cf9f43430', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('72bae29d-4e45-401b-a2ae-d0171ffb4b71', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('73a2a611-10cf-4d39-bd6b-d77871bc32ae', '5f5533e0-5760-4edd-a22d-9122097da388', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('746d0bc5-adb7-4beb-8e75-03502b44f859', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('7488da52-1fbc-4953-868f-8014283bb324', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('74bf3e8b-1b33-4535-8aba-b89ee8db22c6', '25b30ac0-81b5-46bd-b3ad-876b48a78251', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('7637346b-ebfa-445c-b618-a58f252b7fd7', '86519e93-90e6-4174-b509-136cf9f43430', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('76994b27-2def-4932-8267-f7e10bd4fd6b', '5f5533e0-5760-4edd-a22d-9122097da388', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('769c521f-a7e7-4c7a-94df-a182db78fd3e', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('7734c936-b024-4332-92a6-14a9b0f1ee2a', '50516989-1011-4b8c-bde9-9ed0750f4a07', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('784d0036-f550-4c4e-b806-4c023e540785', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('78a122a8-18e9-4701-9285-a448561ea329', '5f5533e0-5760-4edd-a22d-9122097da388', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('7a1b2485-6fff-4186-a2b1-086cb7dc94b1', '8e155a9a-175c-4fb8-890e-97409b2953c8', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('7a294fa8-1443-4411-ac62-762ef53f7989', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('7a6d1d19-86a7-4854-a079-656d41568cb0', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('7aef71bc-b21c-484a-9acb-56c9aa15d2a3', '717f21cc-de1d-4881-942a-4601e8bf45f0', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('7b692b7c-3b59-46cb-b95a-c37b59dfa7a6', '63841581-68f3-4cfa-bc81-c78466e5ec5b', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('7beeda31-4007-4fdc-9188-831886b77a7b', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('7c204a19-f1ed-4fcb-8ce8-cf139b87c84d', '60a58561-6800-44b4-8074-d70d035bb1a2', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('7ca87eb0-35d6-4b23-b8ff-2967b9acc00d', 'bf6331a3-74f5-44bb-8b82-635a399c4878', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('7e11259f-da10-4c5f-ada6-9e7d91705c7a', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('7e76182d-e295-4158-a502-31d509263c46', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('7f54f9dc-adb3-4f1f-976b-bbd7a1dcb472', '5fb6f8d6-49ed-4587-be09-333b67419ac0', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('80538740-b572-4622-a8c7-2357c5e52cbc', '2b54201e-9524-4e52-9615-53eef6fae6f6', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('822e27ae-78f4-4546-bb2c-b9bf5a104420', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('829c34dd-10d4-4c80-9bf8-51a59c688c2a', '8e155a9a-175c-4fb8-890e-97409b2953c8', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('82f99f0e-d39a-4403-a5e8-b906f76a515c', '65226aff-26be-4bbe-9222-62cd159ba207', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('83347362-91cc-4f17-8359-4cd79af1058f', '7583e038-e58c-41a8-867c-026f1b90d787', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('842b914c-8b9e-4545-8dde-8c42fde17e11', '717f21cc-de1d-4881-942a-4601e8bf45f0', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('85e6bb9f-dab9-4a41-9480-c66fe4745d97', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('874af384-8278-4605-af48-4d994b36b421', 'bf6331a3-74f5-44bb-8b82-635a399c4878', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('87810b0b-2efb-49cb-8342-530180e59ad3', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('88518d24-4d03-4f49-ba9f-a70014ac2239', '50516989-1011-4b8c-bde9-9ed0750f4a07', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('890dd29b-830f-4af7-88b6-e2a675f3b8f7', '93ea5ac0-5b1f-42ce-9289-478820d9108d', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('895b551f-815c-4af0-907a-8cb75b420679', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('8a997bad-38e1-4f77-a952-3ee4bb541bf7', '50516989-1011-4b8c-bde9-9ed0750f4a07', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('8b841712-f95f-4bac-b79e-67d6dd26c0f0', 'ee5b570a-759c-42aa-929b-efb390436f1a', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('8c462617-a3fd-4ff1-a30f-942dbdeb3375', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('8c8e6d57-d8ec-4cca-bd43-4fb7e10ffd4d', '63841581-68f3-4cfa-bc81-c78466e5ec5b', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('8ce1dc0a-1044-4ab5-9355-e584d4854de2', 'bf6331a3-74f5-44bb-8b82-635a399c4878', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('8ddc7122-cbf1-467e-be2f-4d7ce6371478', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('8e6bf666-9b27-4caf-89f2-c35d36a6b1ad', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('8f181e7e-e38d-4695-8b76-5041215d81a2', 'bf6331a3-74f5-44bb-8b82-635a399c4878', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('8f6ee51d-51a8-4f48-867b-f3577af1027b', 'bf6331a3-74f5-44bb-8b82-635a399c4878', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('8f7ea8cc-e915-4af8-8baf-bda90c1b1228', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', 'a526737c-cfd1-4169-a2fa-d9c62819fd16');
INSERT INTO public.produto_adicionais (id, produto_id, adicional_id) VALUES
	('8f9b9382-fcbd-4fe8-971e-d65b753fe85e', 'dca3fa98-20e5-487f-a479-5920c7783cab', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('8fd4ca08-6c3a-4405-a3b8-f911d29281e6', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('8fe2ec8f-bcde-45c2-ac76-67b4567bae7d', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('90fdd3bb-113e-43e9-980e-159e4334b828', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('91aeaaf7-40e7-4f7b-9f4b-cbfb11cc4ad5', '25b30ac0-81b5-46bd-b3ad-876b48a78251', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('91c23f1e-f64a-463c-8135-32333e8b15fa', '8e155a9a-175c-4fb8-890e-97409b2953c8', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('9335a7a8-59d5-4f6d-8d7b-b17577a617b7', '43087961-297c-4b43-8ddd-1484188baab2', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('9370d02f-c72f-4cd7-af79-3bbf82f28377', '60a58561-6800-44b4-8074-d70d035bb1a2', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('93aced72-97a9-4fcd-8f43-2c4668dadfcf', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('93e919cc-9610-4d9a-a498-5b6356226ba8', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('9561df3c-2ead-43be-964e-e6b83efac0b2', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('95ba2393-551f-4e35-aa5b-62a265fbe2b2', '5a98547e-4cca-4a74-bc73-6822c3b8d069', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('96c5b890-e16d-4830-9d09-a5041759dc73', 'bf6331a3-74f5-44bb-8b82-635a399c4878', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('975bdb67-069e-4d12-9a2b-5aa3a0fa9902', '4436ddb0-689e-4b7e-954a-faa1999288a7', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('97849dc7-9e78-4964-a3c3-09eb7c08ec44', '5c9f187f-de24-4615-9042-78e1773e904b', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('988875e8-a191-4078-849a-891529256aed', 'ee5b570a-759c-42aa-929b-efb390436f1a', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('9903c970-2d01-4842-bfc1-3b5a9f4af840', '1658ebed-648f-4150-bf26-f50993a72243', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('9a6ffccd-2649-493c-ac3b-83293ad35caf', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('9cdae160-0bb9-450c-84b1-fb1af457ba25', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('9cfdd033-2c96-4056-ad43-1a905dc9c638', '5fb6f8d6-49ed-4587-be09-333b67419ac0', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('9cfe2266-85f7-4bdc-821a-90b57fc1daf2', '2b54201e-9524-4e52-9615-53eef6fae6f6', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('9d3ee129-b6ad-4530-a305-a21dcace2886', '4014c744-53bc-4148-8fcf-0799918e88aa', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('9d48f8f4-8117-4d11-be11-2adfd75a65cf', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('9e7e3b70-590a-4623-90f2-aff8e052d5ed', '4436ddb0-689e-4b7e-954a-faa1999288a7', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('9e8b7c8c-5b03-4e88-b1ae-2862102d7ef6', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('9eb94516-aa3c-4739-a35c-324c5eaea2db', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('a1ac363b-cfec-4bd4-b407-ceca46bc926c', '4436ddb0-689e-4b7e-954a-faa1999288a7', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('a216221e-a989-48d0-9fac-544af0b0d9bf', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('a3390fc0-eb50-40dd-8ae3-8b50642bb412', '5f5533e0-5760-4edd-a22d-9122097da388', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('a34dc4f1-80de-4dc1-ab24-3cf015ba3325', '2b54201e-9524-4e52-9615-53eef6fae6f6', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('a35fa4bd-ecac-4510-b5e6-0fb3b94e0635', '65226aff-26be-4bbe-9222-62cd159ba207', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('a3ca3a42-6615-4e2e-abd8-52c9314f8e31', '5c9f187f-de24-4615-9042-78e1773e904b', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('a45438b8-ed84-4523-98db-52a9ba5e8639', '93ea5ac0-5b1f-42ce-9289-478820d9108d', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('a49166b8-73e8-4b7c-b3d6-05632d917fd0', '93ea5ac0-5b1f-42ce-9289-478820d9108d', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('a740c3d6-5424-4057-8fc7-16ac09b41964', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('a779fbf9-546d-46eb-98a4-940e375eeb5e', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('a7e35937-af18-45d3-b314-2685a36b866c', '4014c744-53bc-4148-8fcf-0799918e88aa', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('a905a63b-8882-4018-badb-202dc2880cfd', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('a9063ca3-ef7d-42e8-8295-22ced3655486', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('a9184384-e8c1-4bfb-9406-5daa533d6a5f', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('aa33e1f7-e0ce-4179-ba62-fd4789e1c4ec', '8e155a9a-175c-4fb8-890e-97409b2953c8', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('ab1a9264-2951-4fe3-8693-236c07ddf97c', '5fb6f8d6-49ed-4587-be09-333b67419ac0', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('abf6e404-b709-4f45-8a68-3edbfdfb4b57', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('ac2b8dfe-7afa-40d1-b8cb-3340d2a6fa9d', '65226aff-26be-4bbe-9222-62cd159ba207', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('ac65b79c-2a1b-4fce-9169-8a4b57d8545e', '4014c744-53bc-4148-8fcf-0799918e88aa', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('acd3bf9c-d0c1-4783-b7d5-34eb512d73a5', 'ee5b570a-759c-42aa-929b-efb390436f1a', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('ad49c115-51e2-486e-9e93-1ae3f34c60ac', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('ad5e7543-56ca-4563-a17c-6e97ad77e795', '5fb6f8d6-49ed-4587-be09-333b67419ac0', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('ad7db8eb-5614-4a53-a736-151b13da0a00', '43087961-297c-4b43-8ddd-1484188baab2', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('ae204bae-1b40-4a0f-a111-bb482936b85c', '717f21cc-de1d-4881-942a-4601e8bf45f0', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('ae374fbd-2b66-4cdf-ae95-8c84f2c9f898', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('ae4a53e3-fc83-4b7f-986c-9405d1481da0', '64142b67-ba38-41fe-8e46-68213b65a342', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('aeb2dfad-fdea-4302-93c3-6abbc3369283', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('aeec09a8-e09f-412c-a8e9-c33549876e7a', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('afe7b44a-ae96-463b-8fac-6b9be112485b', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('b18b02c3-6af1-4a34-a2d9-451e1cd10cb3', '717f21cc-de1d-4881-942a-4601e8bf45f0', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('b315d89b-7a16-4655-a2dc-b9b1f9ad4872', '50516989-1011-4b8c-bde9-9ed0750f4a07', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('b37f5617-6caf-4df2-8c3d-37475bfd44d2', 'dca3fa98-20e5-487f-a479-5920c7783cab', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('b3dc9d4b-a238-4da0-8610-708dd4787384', '86519e93-90e6-4174-b509-136cf9f43430', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('b3f908f7-8d30-4145-aa10-ff55b7f21582', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('b5f99e39-bf8d-402e-bf93-df705e7b4e68', 'ee5b570a-759c-42aa-929b-efb390436f1a', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('b6519b01-880a-4cd1-8500-bf67422885f8', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('b68c7c5d-4692-4005-8ff1-90685969687c', 'bf6331a3-74f5-44bb-8b82-635a399c4878', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('b9174c21-9d9f-43e5-a09d-9eff406ad176', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('b9179b5b-c1fd-44f2-af66-2679a4f12244', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('b952d107-41f7-4820-b7d4-951ad490ea37', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('b96781a3-3867-42b2-b144-9922b81eb506', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('b9878083-9ef0-4c32-87cb-a2f90961d863', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('b9a13fd0-45c0-414c-b2f3-9f36792320b8', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('ba78f90a-90a2-4fad-a783-d3a050b54841', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('baab63aa-9d6f-4293-a67c-276b7e249c3b', '2b54201e-9524-4e52-9615-53eef6fae6f6', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('badaf600-8562-4c0b-b877-e9d1a0da7c8a', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('bb199c99-de06-482a-859d-f13c4ba35496', 'bf6331a3-74f5-44bb-8b82-635a399c4878', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('bbabfdab-77d3-4c68-9c1c-0b3cdde8260e', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('bbda4e2e-4edb-462b-9c21-5edc5bec7b39', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('bd2c7d0d-e260-4844-9e18-12ab61703e33', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('bd53fab6-de2b-4667-852d-bdaeef431d67', '7583e038-e58c-41a8-867c-026f1b90d787', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('be6f5646-6423-4d93-846e-ac9eae7e67e5', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('be988386-7a69-438f-a730-3f9635ce6852', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('bf0d7f64-8734-48b9-994b-7d25153ebd23', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('c164e128-50ef-43ee-a46f-7e4506492f8c', '5c9f187f-de24-4615-9042-78e1773e904b', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('c33d514e-b00f-45d5-a6bb-ea9e6a90151a', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('c3920f30-30c1-4fa6-8795-a21e4aaa5af1', 'dca3fa98-20e5-487f-a479-5920c7783cab', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('c3e74c68-b5ea-412d-85ad-1f9de0cf9009', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('c4a0d6a3-236a-49ee-948d-99d71198f6be', '5f5533e0-5760-4edd-a22d-9122097da388', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('c5eae900-e7c3-4eaa-b174-a7d548ac8934', '3338daa5-5f14-4236-92b6-1cee71c509b2', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('c624a21f-fe44-4278-a546-7ae2ed2706f5', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('c647b514-0199-4f2d-be76-0a7287b1f962', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('c7f19dc7-9a91-41b1-af2c-6cff515a03ec', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('c89b4300-19b6-4262-9b0e-431d5e33ae16', '4014c744-53bc-4148-8fcf-0799918e88aa', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('c8a1e7e7-4a0f-4899-be87-10e962576d82', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('c9793f4c-6223-40cb-8cd3-2e029ecbbf7a', '65226aff-26be-4bbe-9222-62cd159ba207', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('ca1d9e2f-58df-4ea0-801a-0061e04bfeb9', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('ca97a949-569a-4ca9-a96d-49e7871a4bf9', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('cb039433-7efb-4f12-aa1b-2a9f32023758', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('cb049558-18d5-40e2-9710-a8d66e9614cb', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('cb1c7506-503f-412e-af8f-2f2be68600b1', '5c9f187f-de24-4615-9042-78e1773e904b', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('cb32e49e-b59c-400d-bba8-635375936dcc', 'ee5b570a-759c-42aa-929b-efb390436f1a', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('cb35b6cf-de56-4cbe-afd7-ce455bda509c', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('cb9d78cb-daf4-42b6-ae2c-48251ed5c56b', '5c9f187f-de24-4615-9042-78e1773e904b', '527e67ca-6eca-4b95-ba76-7fa0dd557594');
INSERT INTO public.produto_adicionais (id, produto_id, adicional_id) VALUES
	('cbdc18e2-13e5-499b-8c2f-4206f6642ed0', '64142b67-ba38-41fe-8e46-68213b65a342', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('cbfda7d9-8873-449f-b52b-5e508de0b46f', '5fb6f8d6-49ed-4587-be09-333b67419ac0', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('cca47d75-40f0-4c21-941c-34b8c3c749df', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('ccd805b0-beee-4213-b812-09924db1c2cc', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('cd90d85c-a300-436b-8af0-1cc3da922cd5', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('cd9562da-9db2-4721-876e-b89683e35ec5', '50516989-1011-4b8c-bde9-9ed0750f4a07', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('ceaf31a4-cbb5-4453-b345-42cee1ea044d', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('d030dc6e-84bb-4370-86b6-0afa0784d549', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('d14e0a29-0856-4bec-ab3c-c964a50b9ecc', '717f21cc-de1d-4881-942a-4601e8bf45f0', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('d1978cef-cf65-4fc5-a523-1fc2848426e7', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('d1c59ca4-8a7f-4fea-ba41-bc3a8b08de83', '64142b67-ba38-41fe-8e46-68213b65a342', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('d20144c4-37a2-47e5-ae05-1753a5ad7a8f', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('d20845fe-3ade-454c-8163-40a978c01bd4', '86519e93-90e6-4174-b509-136cf9f43430', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('d2154410-612b-49ee-85f4-285a04167078', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('d30ee803-a039-4760-8eac-dfb1237f4109', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('d4dcf614-20ee-4a4e-a868-12e05bae13a0', '93ea5ac0-5b1f-42ce-9289-478820d9108d', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('d51981d2-f0f6-4e41-95fc-175db47dd8bd', '43087961-297c-4b43-8ddd-1484188baab2', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('d524627c-0ab1-46ca-a98b-fe88d26c8502', '86519e93-90e6-4174-b509-136cf9f43430', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('d60da670-ca70-4652-b026-e87177c31dbe', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('d63bba9b-8932-4ed7-aa41-64b9c74a3ae0', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('d6550c34-01df-4978-a83f-46bf72523969', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('d6a4fad0-43cf-4111-a475-25050fdfb04d', '64142b67-ba38-41fe-8e46-68213b65a342', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('d7410590-dd61-4432-97d5-e16d3315c98e', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('d7cf0210-aa2e-421f-b896-d94dcb499ec0', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('d823dafd-6622-4ecb-a343-0f374cc9e37e', '2b54201e-9524-4e52-9615-53eef6fae6f6', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('d9e002e0-6516-49c6-9026-4e7931a5247a', '25b30ac0-81b5-46bd-b3ad-876b48a78251', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('da865a10-2152-4458-9c6c-7f29775d8539', '3338daa5-5f14-4236-92b6-1cee71c509b2', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('dc580bb7-f2e3-4a68-9532-797097eee90a', '43087961-297c-4b43-8ddd-1484188baab2', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('dc78dc01-f127-4c04-8688-8a72ef6be4ec', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('dcc5c305-81d3-4ee1-9747-17e1e7a07929', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('dcf3528a-f772-46d4-af07-98ec86f57b1d', 'ee5b570a-759c-42aa-929b-efb390436f1a', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('dd299412-c420-4dbc-9407-095f4cbdfb52', '25b30ac0-81b5-46bd-b3ad-876b48a78251', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('dd3d37e4-ebc3-47c2-9b83-4ca65a76d56f', '7583e038-e58c-41a8-867c-026f1b90d787', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('ddde5825-c4b8-476a-9cf0-5420b60c686e', 'bf6331a3-74f5-44bb-8b82-635a399c4878', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('deb98079-ff20-4ee5-9aed-1772040b64cc', '717f21cc-de1d-4881-942a-4601e8bf45f0', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('def69e3f-a8c2-47f0-bf2b-a73ff4b809f4', 'ee5b570a-759c-42aa-929b-efb390436f1a', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('df178a55-fe29-4b30-a612-55d193fce13d', '1658ebed-648f-4150-bf26-f50993a72243', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('df297aa8-77df-4503-9f04-b51d96ee98e4', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('e0588d52-62d7-4f23-87da-d7033ffc9243', '3338daa5-5f14-4236-92b6-1cee71c509b2', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('e0e90c20-914e-4a40-bcd2-3dff66e288b6', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('e16f7b0e-00a4-41d6-a09e-fc236da5c1c5', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('e25b7371-ea5f-4a3a-92ae-3189704ab927', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('e353a293-4607-43e2-92c1-cac9ab67f8a4', '4436ddb0-689e-4b7e-954a-faa1999288a7', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('e3c62c6a-6d52-4557-8cbc-870eab409090', '64142b67-ba38-41fe-8e46-68213b65a342', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('e3f0e0a0-0311-4acd-a68d-4d55bf1cc73a', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('e55cb853-a432-4226-9a64-f9049d5f1f86', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('e5e8efd3-d448-418c-8550-d905ea5bf0b0', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('e65a29b7-766d-439b-9d12-782302bb3a9b', '4014c744-53bc-4148-8fcf-0799918e88aa', '6861e324-b899-48fe-8854-a42e33113ecb'),
	('e81b0947-dea1-4a9e-b907-e3c3866b4551', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('e83eb768-c11e-4d8d-a94f-36fc0ba39ca6', '717f21cc-de1d-4881-942a-4601e8bf45f0', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('e8b9372b-bc96-454c-8b5d-355854e68891', '717f21cc-de1d-4881-942a-4601e8bf45f0', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('e8dee3d9-2893-44d9-a791-de86a6ff3a1a', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('e8ea7707-322a-44c8-951e-77c143db0790', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('e96615be-2e48-4feb-8014-66a03abddd97', '3338daa5-5f14-4236-92b6-1cee71c509b2', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('ea2a1c60-1ccd-4289-87f4-64a358a733b0', '60a58561-6800-44b4-8074-d70d035bb1a2', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('eb13c7b8-7fd3-4657-ab60-86f95022508d', '65226aff-26be-4bbe-9222-62cd159ba207', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('ec2eb72e-79d3-4528-8221-53dd8901a6ad', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('ec4f51a5-ec35-4083-810d-bb6a7c6a3ef7', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('eca6c532-57c0-4d39-b87b-153c6f86bd83', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('ecf691a8-f355-4132-9acc-7624f7965ea8', '8e155a9a-175c-4fb8-890e-97409b2953c8', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('ed798621-7162-4c70-9fab-f1a7f7f870d2', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('edb431ed-3b4c-4928-bc3e-a3817d112fbf', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('eef465af-7f05-4d73-8204-37568288d583', '50516989-1011-4b8c-bde9-9ed0750f4a07', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('ef34dbc0-d11c-4fc7-94b8-c7bec37a665c', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '375fb3e2-36f3-47be-9d78-7d0d11882a35'),
	('f01ab5fe-e2fa-4f83-887a-8a4f1aa89f83', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('f256e464-0e08-4fd2-b6dc-84617bb22b25', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('f2713c83-466a-45c8-b7df-f9e831791a78', '64142b67-ba38-41fe-8e46-68213b65a342', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('f2ad4e58-ce52-4cbc-9610-ec436965efa0', '3338daa5-5f14-4236-92b6-1cee71c509b2', 'a526737c-cfd1-4169-a2fa-d9c62819fd16'),
	('f300d7d0-eb44-45a3-9bc6-3baa07c8a910', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('f34d5569-55b4-4bda-8932-9544a8ab5831', '5fb6f8d6-49ed-4587-be09-333b67419ac0', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('f4aa8d00-aef3-43c4-893d-bf06376c40db', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('f4b55a25-5ae1-4c08-a01d-7912792a97c6', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('f4dfa740-ad1a-4371-8383-d200968dc2a5', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('f56273ff-73af-49a9-b2f6-4f45d7566c26', '5fb6f8d6-49ed-4587-be09-333b67419ac0', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('f5be1597-8425-4eb1-a479-f5e4526a17b1', '7583e038-e58c-41a8-867c-026f1b90d787', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('f5d7d054-d736-4a0e-8209-ab55ec9329c1', '1658ebed-648f-4150-bf26-f50993a72243', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('f65d6da2-2e69-4cc6-84e2-252072180716', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('f827d2e5-3859-4672-b6f1-96ff0f7fc8ec', '63841581-68f3-4cfa-bc81-c78466e5ec5b', '1d9cc231-ec6a-4425-9571-1da72ea37d0b'),
	('fa317fdc-9388-407f-a008-a3bbed89a500', '4014c744-53bc-4148-8fcf-0799918e88aa', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149'),
	('fa8d4307-8d78-423c-81a2-1cfa3df4c758', '93ea5ac0-5b1f-42ce-9289-478820d9108d', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('fabd3dcc-e984-441b-a8f7-bedbc253ee1e', '63841581-68f3-4cfa-bc81-c78466e5ec5b', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('fc3ce8e6-b8e7-42b1-b160-53bdecea555a', '2b54201e-9524-4e52-9615-53eef6fae6f6', 'dc16b7c5-3a49-44a3-ada1-4caeddaf6f88'),
	('fce261cc-8c17-4fff-8a8c-684a45e88c1a', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', 'c06e9235-09d1-45d3-ad09-e347d8da6c75'),
	('fdba7312-0e79-493c-b6de-b87fc506a769', '64142b67-ba38-41fe-8e46-68213b65a342', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('fe0656a7-3822-4197-bb09-7a14e8011bc4', '1658ebed-648f-4150-bf26-f50993a72243', '081a3274-b818-4fe1-908a-32a8f752e302'),
	('feb168b1-3432-4ab3-9d7a-93582046a5f4', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', '527e67ca-6eca-4b95-ba76-7fa0dd557594'),
	('fffa82a6-09c9-4482-b6fc-3886f144057e', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', 'aeec0c9c-2f3c-4db0-9bce-b625018c7149');


--
-- Data for Name: produto_ingredientes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.produto_ingredientes (id, produto_id, ingrediente_id, quantidade_por_unidade) VALUES
	('01e52b29-c151-4c11-8dff-f02e5312b97b', 'dbdba3e8-488c-4eca-b84c-108ba9de45ba', '4d1aed3a-dd06-4519-bbf4-db2c174db59a', 1.000),
	('038b32f1-3cbb-42a0-b4a1-c012f9b7a465', '86519e93-90e6-4174-b509-136cf9f43430', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.020),
	('03debb3a-cf18-44e3-bbca-d28af2559c91', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '102e626e-de6c-4354-8a68-108f3639a677', 0.015),
	('0550aac7-1303-41cc-9efc-4dc06dd3d248', '43087961-297c-4b43-8ddd-1484188baab2', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('0589f5f2-41e1-4f53-b155-1a19bd5ceef2', '5fb6f8d6-49ed-4587-be09-333b67419ac0', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('0645f4c6-9d30-487f-b345-5f09872aa5c7', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('0661b38a-107b-4aba-aa0d-d4be17bd6d97', '4436ddb0-689e-4b7e-954a-faa1999288a7', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('07ae8193-d8e0-4275-b4fb-4706fa6455f2', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.030),
	('07d1d4ba-cd20-4475-a33b-e6d455cdae4a', '50516989-1011-4b8c-bde9-9ed0750f4a07', 'e8d06141-538b-4bc0-a08c-ec3f40048387', 0.500),
	('0881a22b-4e0b-4c45-9aea-489809e4bfe2', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', 'a193d8e1-f087-49a5-b078-e5fa4990aedc', 0.030),
	('08903c70-dc19-4dde-9606-a1276fe060c4', '4014c744-53bc-4148-8fcf-0799918e88aa', 'd5b72b65-a2c0-43cb-a59c-4bb3bb79035a', 0.040),
	('08ddb106-ec6c-44a5-b557-ac5eb0fb868c', '93ea5ac0-5b1f-42ce-9289-478820d9108d', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('08eb26ae-f4eb-4337-af57-3e3aae98327a', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.150),
	('09c0894c-23d5-4cc8-9105-02e8347bc391', '71b73436-5512-4ba4-9719-541b70aec6e0', 'd5b72b65-a2c0-43cb-a59c-4bb3bb79035a', 0.040),
	('0a4dfa08-17a9-496e-b76c-03f0b65cecc8', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('0a54b61f-0995-4041-97e8-75831036fede', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('0a9361c6-28ec-4888-9a98-a873ae155b27', 'dca3fa98-20e5-487f-a479-5920c7783cab', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('0caaf80a-3532-48d7-8e58-6408de0b85ef', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', 'bfaa5579-33fc-4327-85d8-7a76f7ebeb5b', 2.000),
	('0e14eeaa-a1db-49fa-b96f-e10786817634', '8581a904-a689-4535-8ffd-0faef973e9a1', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.080),
	('0e492bd3-cdd2-4972-8f53-13f562d4f927', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', '13f5cd01-df2c-402c-aa1d-d58c4b7340b5', 0.050),
	('1052a6fa-4647-4b44-9fba-991f56914221', 'dca3fa98-20e5-487f-a479-5920c7783cab', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('1254fb04-7dd6-4354-a729-46b35913e9f7', '93ea5ac0-5b1f-42ce-9289-478820d9108d', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('12d8a0df-d9e6-401b-8c02-5a61b6f2bc3b', '5a98547e-4cca-4a74-bc73-6822c3b8d069', '328dfe6e-8b6d-4b40-9d19-8439038f9647', 1.000),
	('16d74daf-f7b4-4755-b6e0-f8d92d5a9874', '8581a904-a689-4535-8ffd-0faef973e9a1', 'aa6bd6a9-6065-43c2-8a57-406616c6edf0', 1.000),
	('1ca2bc26-b1a1-45c5-9657-1abc7079df28', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', 'bfaa5579-33fc-4327-85d8-7a76f7ebeb5b', 1.000),
	('1e09617a-e570-4881-aeff-53c4d8985c14', '60a58561-6800-44b4-8074-d70d035bb1a2', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('1e7377b0-f035-413b-8c05-7f351520f373', '717f21cc-de1d-4881-942a-4601e8bf45f0', '8c352f67-b128-4eb6-b112-38ea50440b03', 0.040),
	('1e9b5a34-6fda-490b-be11-539da66205f2', '64142b67-ba38-41fe-8e46-68213b65a342', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('1ebf9b2f-175c-4383-a649-5a11e0dc4ac0', '25b30ac0-81b5-46bd-b3ad-876b48a78251', 'aa6bd6a9-6065-43c2-8a57-406616c6edf0', 1.000),
	('21563a3f-b38a-465a-9f7f-8ca19047e379', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('221053b9-278c-4019-9937-bc5091ecb4ed', '65226aff-26be-4bbe-9222-62cd159ba207', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.030),
	('22b94c64-69e3-4e79-b36b-481cffeb0ca2', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', '8c352f67-b128-4eb6-b112-38ea50440b03', 0.040),
	('24847a12-1aba-4f73-b368-bcc15fcf1b73', '717f21cc-de1d-4881-942a-4601e8bf45f0', '13f5cd01-df2c-402c-aa1d-d58c4b7340b5', 0.050),
	('26486ef0-ffd0-43fb-a337-8e39730145a0', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '4dae510c-cc28-483d-80c8-32d2592f4d9f', 0.050),
	('28c4267d-9dce-4c3e-bdac-9b6fd0da7303', '4014c744-53bc-4148-8fcf-0799918e88aa', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.150),
	('28e087ce-4d4a-4562-9605-852f428e37be', '63841581-68f3-4cfa-bc81-c78466e5ec5b', '8c352f67-b128-4eb6-b112-38ea50440b03', 0.030),
	('2a2b8f39-3970-418d-afbc-b0640a1c43f4', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.030),
	('2afccf9c-d5fd-4796-aaa4-dfc69196ad77', '64142b67-ba38-41fe-8e46-68213b65a342', '102e626e-de6c-4354-8a68-108f3639a677', 0.015),
	('2b613069-ea79-47e8-8c86-e9e62947d3ec', '3338daa5-5f14-4236-92b6-1cee71c509b2', 'd146b503-920a-4b79-9814-521148ed2d8c', 0.100),
	('2bcaa84f-f428-4108-8994-447ea4ba4d13', '65226aff-26be-4bbe-9222-62cd159ba207', 'f39adc02-af43-46eb-b2b5-50c14c2558cf', 0.150),
	('2bfc3a9f-b6e9-4a74-9478-1729bf4dcba6', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', '8c352f67-b128-4eb6-b112-38ea50440b03', 0.040),
	('2c7e470f-326f-441a-a096-81fcdd87708c', '5c9f187f-de24-4615-9042-78e1773e904b', 'ce47359c-271c-4d58-a9e1-018a38340282', 0.300),
	('2cae238a-f1e8-49a9-950a-d2b71deaa86e', '5fb6f8d6-49ed-4587-be09-333b67419ac0', 'bfaa5579-33fc-4327-85d8-7a76f7ebeb5b', 1.000),
	('2d02a210-6e77-4382-aa70-730b87cff7b9', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('2d0c6605-e434-4db8-aef0-16c374331101', '71b73436-5512-4ba4-9719-541b70aec6e0', '46354a04-75b6-47f8-8044-6395ff26e2fd', 0.030),
	('2d66b223-84e4-43ce-a383-03407f17e3a9', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('2d995407-ed74-46be-b2b5-57dde4ad4505', '60a58561-6800-44b4-8074-d70d035bb1a2', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('2df5b6b9-2269-420f-b040-3253f9b40eda', '5a98547e-4cca-4a74-bc73-6822c3b8d069', '13f5cd01-df2c-402c-aa1d-d58c4b7340b5', 0.030),
	('2e654e40-3f97-49ca-bee7-17ddfc01a74f', 'dca3fa98-20e5-487f-a479-5920c7783cab', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('2fafa68d-e7a2-4041-9642-3fd22001f8dc', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', 'd5b72b65-a2c0-43cb-a59c-4bb3bb79035a', 0.050),
	('30661541-64f6-4e4c-aea6-2f7667627741', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', '102e626e-de6c-4354-8a68-108f3639a677', 0.015),
	('306bb23f-dbea-4820-9349-038dfb79d00d', '63841581-68f3-4cfa-bc81-c78466e5ec5b', 'b8511ba5-b6ff-43ec-adc8-1cee823ac124', 0.400),
	('30c37db0-5b12-4672-9e1b-4f4e642f6150', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('30e2c503-5234-4299-b994-1c740b4a2a4b', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '826e891d-c682-427a-a7c6-d53c14f06ece', 0.030),
	('3129b979-d6ae-4a71-9964-5c89c04fd446', '43087961-297c-4b43-8ddd-1484188baab2', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('33880307-cf6d-4852-8534-096c61dfa4aa', '5fb6f8d6-49ed-4587-be09-333b67419ac0', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('34db6ec4-4947-4577-82aa-6e149b1f458c', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', '32e9ad52-3c43-4b4a-985b-48e9762a59fd', 0.030),
	('34e410bd-01f5-4a74-8c5b-0413d96edf78', '64142b67-ba38-41fe-8e46-68213b65a342', 'd5b72b65-a2c0-43cb-a59c-4bb3bb79035a', 0.040),
	('351b78fa-7644-4da8-acb7-4c50a569d968', '5f5533e0-5760-4edd-a22d-9122097da388', '13f5cd01-df2c-402c-aa1d-d58c4b7340b5', 0.050),
	('351db993-d506-4b60-af14-a8b5834f1c71', '7583e038-e58c-41a8-867c-026f1b90d787', '46354a04-75b6-47f8-8044-6395ff26e2fd', 0.030),
	('3593307d-1261-4ab6-9137-0371dedd2abc', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', 'b3a46cc2-6b6c-4304-bfac-52e2c3e1de79', 0.250),
	('36173717-2ec6-4d85-bd35-700391f6f6a6', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.040),
	('3630a5a2-9760-4263-8ead-dc5928c0c06f', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', 'a0571d1c-21ff-49ac-a040-cbe78dc15944', 1.000),
	('373add05-889e-4fa1-ae09-95cbcab5887b', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', 'a193d8e1-f087-49a5-b078-e5fa4990aedc', 0.030),
	('374a8c75-b8d5-45fb-a382-164625b7d7ed', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('3766aa26-b21c-46d0-9aac-e7d98f6fb445', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('37b6cff7-0496-468c-a17a-116804bf83b7', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('3b2a5960-505a-4874-a058-29691b5bbf36', '4014c744-53bc-4148-8fcf-0799918e88aa', '46354a04-75b6-47f8-8044-6395ff26e2fd', 0.030),
	('3c9abc5f-c422-4516-9609-0bfe8e184bee', '93ea5ac0-5b1f-42ce-9289-478820d9108d', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('3ce476b1-06f8-4f39-b723-faecddbd1ecb', '43087961-297c-4b43-8ddd-1484188baab2', '00ccbdd1-3e61-4e0c-b467-04abb8c9f9fc', 0.250),
	('3db07eed-ad2b-4315-b6e1-bb1821709a72', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('40262bb3-4d78-45ae-8f8a-929d06d3ddfe', '25b30ac0-81b5-46bd-b3ad-876b48a78251', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('41016bd7-d3a2-44d5-8a3d-f60798f64500', '4014c744-53bc-4148-8fcf-0799918e88aa', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('413e1f47-d141-4092-9700-221c2e9d0c71', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', '0e3054a3-96c8-43dd-b2cc-3bf7ce8769ca', 1.000),
	('41e4ad28-823e-4df9-8f8d-f81e52c3b6a7', '60a58561-6800-44b4-8074-d70d035bb1a2', 'bfaa5579-33fc-4327-85d8-7a76f7ebeb5b', 1.000),
	('4200b4d5-0100-49f8-a10d-f63e8e39bac4', '5c9f187f-de24-4615-9042-78e1773e904b', 'fb24c49d-a4a4-4d4a-9446-1969b8440ebc', 0.150),
	('42632090-1cba-44b6-b804-dec2764e82d6', 'dca3fa98-20e5-487f-a479-5920c7783cab', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('447965ec-8d74-4940-b722-7f652def2da5', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.030),
	('45945be1-54f8-4a5f-804f-d9b63093e15d', '43087961-297c-4b43-8ddd-1484188baab2', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('4695dc54-7f69-47a0-9e87-491777bc5f1f', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.150),
	('46a0fa45-d685-4b0a-9331-6dc64b3b1b2e', '5fb6f8d6-49ed-4587-be09-333b67419ac0', '13f5cd01-df2c-402c-aa1d-d58c4b7340b5', 0.050),
	('4808dc0b-1761-4634-95f1-3097e9ce064a', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.040),
	('48b6c7a4-8417-4551-a3e9-5964b418cda2', '7583e038-e58c-41a8-867c-026f1b90d787', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.300),
	('4992b4ea-1279-40df-ad30-d8e66e4f57aa', '4436ddb0-689e-4b7e-954a-faa1999288a7', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('49c04105-5b41-4ada-ae77-072cb79fd98d', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', 'fb24c49d-a4a4-4d4a-9446-1969b8440ebc', 0.150),
	('4ad21b29-a2b0-4023-8e67-791a13b7ed16', '5c9f187f-de24-4615-9042-78e1773e904b', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.060),
	('4c86877f-1a7a-4d84-a1bd-91c6a2637c03', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('4dce72c4-62d7-40f0-9de5-f8f263328f68', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', 'b8511ba5-b6ff-43ec-adc8-1cee823ac124', 0.400),
	('4e509e73-70de-4683-97c2-8b241f16515c', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', '00ccbdd1-3e61-4e0c-b467-04abb8c9f9fc', 0.250),
	('4ed7fb97-9ab3-49d5-992e-d9ba61002f72', '60a58561-6800-44b4-8074-d70d035bb1a2', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('506f7cca-a1e7-439d-805e-6bc97e303919', '4436ddb0-689e-4b7e-954a-faa1999288a7', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('5127fac7-9172-45a0-bbad-dd6997739126', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('53162ff2-ed7b-4fe0-9951-0071ed408e1e', '8e155a9a-175c-4fb8-890e-97409b2953c8', 'd5b72b65-a2c0-43cb-a59c-4bb3bb79035a', 0.040),
	('53c31883-b888-461b-b9ca-f4da74058b33', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.020),
	('5464b125-dcd0-4af7-a3c5-ee22206200ce', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('546cc629-3b04-48c3-ac99-11ad4001f773', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', 'a0571d1c-21ff-49ac-a040-cbe78dc15944', 1.000),
	('55a20b93-3a12-4a85-be97-f785d58bf4d9', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.040),
	('56d45e74-5027-4caf-bf22-388a04094de2', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('57344b2f-389b-483b-a4e8-2e6facf8698b', '717f21cc-de1d-4881-942a-4601e8bf45f0', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('5780c459-4835-4fad-aa63-078882c5c367', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.150);
INSERT INTO public.produto_ingredientes (id, produto_id, ingrediente_id, quantidade_por_unidade) VALUES
	('58870542-5707-4cab-8674-8fe779d06ca2', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', 'b3a46cc2-6b6c-4304-bfac-52e2c3e1de79', 0.080),
	('58ae406e-7275-405d-8069-46d76498cba4', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', '8c352f67-b128-4eb6-b112-38ea50440b03', 0.030),
	('5c7fa4d1-33cf-411e-884b-1a14b2dd5578', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', 'fb24c49d-a4a4-4d4a-9446-1969b8440ebc', 0.080),
	('5cb5a486-aff8-4344-b301-6f71ae343823', '5fb6f8d6-49ed-4587-be09-333b67419ac0', 'a0571d1c-21ff-49ac-a040-cbe78dc15944', 1.000),
	('5d48ef3e-2ecb-4e39-80c1-d757e3e9ddd8', '86519e93-90e6-4174-b509-136cf9f43430', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('5ea7123f-6d09-4869-bba3-e56c491ccb0e', '7583e038-e58c-41a8-867c-026f1b90d787', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('5fb81074-836b-4461-8026-7a9482a7be37', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('6073e3b8-2c5f-4011-972f-e7c779ea25b8', '8581a904-a689-4535-8ffd-0faef973e9a1', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.030),
	('609e6ca1-6699-437a-9d92-f12d17b505d7', '1658ebed-648f-4150-bf26-f50993a72243', 'b8511ba5-b6ff-43ec-adc8-1cee823ac124', 0.400),
	('60a72fe0-ae48-4c88-89a5-f061c2fdef7c', '8e155a9a-175c-4fb8-890e-97409b2953c8', '8c352f67-b128-4eb6-b112-38ea50440b03', 0.030),
	('627deb74-dac6-4e37-9ac7-361e35eaf01e', '3338daa5-5f14-4236-92b6-1cee71c509b2', '13f5cd01-df2c-402c-aa1d-d58c4b7340b5', 0.050),
	('62f4d71e-b55a-4964-beca-ef08321abdb5', '4436ddb0-689e-4b7e-954a-faa1999288a7', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('63c2f649-0372-4cc1-a4d1-bb95832c9215', '7583e038-e58c-41a8-867c-026f1b90d787', '5b3f3d17-4928-445f-8150-6a8ab3e45c94', 1.000),
	('64f46bf8-a7a7-4025-85a8-a3353235c1e1', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', 'b6855458-ccb8-4799-b714-cf7a0e77a894', 0.020),
	('650dbcc9-ed68-456c-95c1-75d16d459640', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', 'aa6bd6a9-6065-43c2-8a57-406616c6edf0', 1.000),
	('65ef0865-aca0-4c50-bd9b-e4c00be2f5a0', '50516989-1011-4b8c-bde9-9ed0750f4a07', 'ce47359c-271c-4d58-a9e1-018a38340282', 0.300),
	('65fef137-c8ff-42aa-9156-69e8902b62db', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('667fdf40-dca4-4eca-a1cf-b2a6efadb917', '5f5533e0-5760-4edd-a22d-9122097da388', '00ccbdd1-3e61-4e0c-b467-04abb8c9f9fc', 0.150),
	('69328791-cfa4-43a1-b36f-3363353949b1', '65226aff-26be-4bbe-9222-62cd159ba207', '18ded61d-073a-4c0f-bea8-30b95b40cbdf', 0.050),
	('6957d26a-fff7-4bb8-a9a4-7f1991fd8f5c', '64142b67-ba38-41fe-8e46-68213b65a342', '2b9518fb-7248-48dc-a3fb-9d1553f2b058', 0.020),
	('69b7e101-be91-462c-a60d-02988ededd0c', '25b30ac0-81b5-46bd-b3ad-876b48a78251', '8c352f67-b128-4eb6-b112-38ea50440b03', 0.100),
	('6a9acc81-6e0c-480c-994d-9909afabb4a2', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('6b486303-521a-4796-80b1-11c91849c9e3', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', 'e8d06141-538b-4bc0-a08c-ec3f40048387', 0.500),
	('6d0c47d5-2ebd-4fff-86c2-06201f085cba', '65226aff-26be-4bbe-9222-62cd159ba207', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('6f76bcfa-e4b7-43b3-ba2f-26c89a59529f', '60a58561-6800-44b4-8074-d70d035bb1a2', 'a193d8e1-f087-49a5-b078-e5fa4990aedc', 0.030),
	('6fda568c-1096-4c83-a290-e3274f7ad6ce', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('70e4972b-7683-41a2-9ee6-a36f88152133', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '826e891d-c682-427a-a7c6-d53c14f06ece', 0.030),
	('71ade455-4d81-49cc-9390-1f4e44d61af6', '5a98547e-4cca-4a74-bc73-6822c3b8d069', '0e3054a3-96c8-43dd-b2cc-3bf7ce8769ca', 1.000),
	('72d73720-e308-479b-af89-c341b573eaee', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', 'a193d8e1-f087-49a5-b078-e5fa4990aedc', 0.030),
	('74c63fbe-4b2f-454d-b120-7d6705649c68', '59fc09ea-7730-40ef-b700-6388068e3ec8', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.080),
	('76802364-f800-4523-b56d-3335a81cf00f', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', 'ce47359c-271c-4d58-a9e1-018a38340282', 0.300),
	('7b300d25-a422-439a-ac07-d0e9304fa6d9', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', 'd5b72b65-a2c0-43cb-a59c-4bb3bb79035a', 0.030),
	('7bcd5139-d0cf-4896-8520-e39ca04a91b1', '64142b67-ba38-41fe-8e46-68213b65a342', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.150),
	('7d2b69af-ed6b-44bc-bbfd-132cb896cc30', '25b30ac0-81b5-46bd-b3ad-876b48a78251', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.030),
	('7d382565-a9a5-4b7d-b9b8-a4cfb3883299', '2b54201e-9524-4e52-9615-53eef6fae6f6', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('7d704c3a-41f3-4710-b955-3b0f5d622778', '86519e93-90e6-4174-b509-136cf9f43430', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.080),
	('7ed8d5fa-760a-4820-be36-3b8ef4ac5bf7', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', '13f5cd01-df2c-402c-aa1d-d58c4b7340b5', 0.050),
	('7f447df4-50d7-4f9c-b196-ffd8a65d7acc', '59fc09ea-7730-40ef-b700-6388068e3ec8', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.030),
	('82f7f782-85a4-4b84-96bf-763c1183cd3d', '64142b67-ba38-41fe-8e46-68213b65a342', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('84894392-1c9d-48c2-878d-9a9e0dbba1a5', 'ee5b570a-759c-42aa-929b-efb390436f1a', '60186adc-05ed-4ade-8165-634077433346', 1.000),
	('888273e9-7082-46dc-97de-333618a8a18b', 'dca3fa98-20e5-487f-a479-5920c7783cab', 'bfaa5579-33fc-4327-85d8-7a76f7ebeb5b', 2.000),
	('8b62bfc1-ca33-4237-b766-c06e7ebaff9c', '4014c744-53bc-4148-8fcf-0799918e88aa', 'aa6bd6a9-6065-43c2-8a57-406616c6edf0', 1.000),
	('8c6c5f3e-4b59-45e0-9b0c-11c376c5faeb', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', 'd5b72b65-a2c0-43cb-a59c-4bb3bb79035a', 0.040),
	('8c8b825f-84d3-461b-adcc-38da0d1e083a', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.030),
	('8cf5b214-a1b5-4887-ab94-2cb549e87fb1', '5f5533e0-5760-4edd-a22d-9122097da388', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.040),
	('8d603e19-3341-4b66-aad8-2d6718d52c2d', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', 'd77e9f66-dc34-4636-ab5d-96fbb51b21fa', 1.000),
	('8dcb02d8-7374-4aaa-b6a4-c2bb8e8ff6fb', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('8df9f28a-5e80-4a30-8fb8-23aba99a9ba7', '5a98547e-4cca-4a74-bc73-6822c3b8d069', 'c2c6531b-dc84-41d1-a45c-259c979c7cd9', 1.000),
	('8ed457a0-616c-44f0-aefd-d2be92ce8407', '8e155a9a-175c-4fb8-890e-97409b2953c8', 'b8511ba5-b6ff-43ec-adc8-1cee823ac124', 0.400),
	('8f2b457c-58f0-4cf2-8030-e3acf1e26213', '8581a904-a689-4535-8ffd-0faef973e9a1', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('8fc312a7-cd1a-4f37-be54-974b2c2ad68d', 'ee5b570a-759c-42aa-929b-efb390436f1a', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.030),
	('917c0dbf-3830-4394-a6aa-84cdafe4aabe', '3338daa5-5f14-4236-92b6-1cee71c509b2', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('91c014fc-5070-4dec-b8b0-4be7acfb2d4f', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.150),
	('91ea13e2-23a8-4bf2-b8a0-ce5f6746b242', '59fc09ea-7730-40ef-b700-6388068e3ec8', 'aa6bd6a9-6065-43c2-8a57-406616c6edf0', 1.000),
	('92a22915-7716-45f8-948a-a80dbca009b4', '50516989-1011-4b8c-bde9-9ed0750f4a07', '13f5cd01-df2c-402c-aa1d-d58c4b7340b5', 0.050),
	('9378b063-fbfc-45c6-af0b-6f6becd909d5', '64142b67-ba38-41fe-8e46-68213b65a342', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('93d9aeae-6cdb-4c3f-bc8a-10d3998ca6ee', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('94e53e14-9645-414d-b8ea-29276eae3dff', '71b73436-5512-4ba4-9719-541b70aec6e0', 'aa6bd6a9-6065-43c2-8a57-406616c6edf0', 1.000),
	('94ee8817-a190-498a-9d15-c34d3126d49f', '93ea5ac0-5b1f-42ce-9289-478820d9108d', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('97cc84f1-eab7-4ed1-9ffe-f401328acce0', '43087961-297c-4b43-8ddd-1484188baab2', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('983a69a1-5c52-488f-a926-a8d9f6d13b45', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('99125506-0c7b-4597-85c3-2b731870add3', '5f5533e0-5760-4edd-a22d-9122097da388', 'e8d06141-538b-4bc0-a08c-ec3f40048387', 0.500),
	('996fabbf-8a21-4678-baaf-d3f5a51b3146', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', 'fb24c49d-a4a4-4d4a-9446-1969b8440ebc', 0.250),
	('9a2bf874-7eb3-4441-8eaa-65d3544cc90b', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', 'd146b503-920a-4b79-9814-521148ed2d8c', 0.100),
	('9f9dc699-8163-46ba-bc52-01f5e59cdcca', '59fc09ea-7730-40ef-b700-6388068e3ec8', '8c352f67-b128-4eb6-b112-38ea50440b03', 0.040),
	('a24af73f-2dd8-4f87-8b11-63cfb10a217c', '25b30ac0-81b5-46bd-b3ad-876b48a78251', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.150),
	('a3633394-aad3-48c0-8cb9-fd1faac7d025', '5fb6f8d6-49ed-4587-be09-333b67419ac0', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('a46f499a-365c-4095-aefe-6d9c4eb04cc5', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '29aa2b4d-ee2d-4f82-a8ea-96c1032f3a28', 0.020),
	('a7c9e13b-2efd-4411-8fde-fd1ac906c6c2', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', '53b91edb-66fa-4b11-a1c5-674a78d08750', 0.080),
	('a87eb369-3818-45a3-8868-f2591c3ea8c2', '7583e038-e58c-41a8-867c-026f1b90d787', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('a8c21e45-c033-4a6a-a6e4-a7bd605e21d2', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.050),
	('a9bf3a20-3800-460e-bd9c-1fff63305e73', '2b54201e-9524-4e52-9615-53eef6fae6f6', '8c352f67-b128-4eb6-b112-38ea50440b03', 0.040),
	('a9f27457-4c78-4f97-b692-4602fee60fdf', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.050),
	('aa888553-9101-448d-857b-324b49710f16', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', 'ce47359c-271c-4d58-a9e1-018a38340282', 0.300),
	('aae309f8-c30b-4a5f-87e7-1e1a2b586f4d', '63841581-68f3-4cfa-bc81-c78466e5ec5b', 'd5b72b65-a2c0-43cb-a59c-4bb3bb79035a', 0.030),
	('abb9222b-3931-47cc-9ad5-4b6d90fbd8cb', '4436ddb0-689e-4b7e-954a-faa1999288a7', 'a193d8e1-f087-49a5-b078-e5fa4990aedc', 0.030),
	('abcb02e8-953d-4a43-8e65-b0270620fb91', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '102e626e-de6c-4354-8a68-108f3639a677', 0.015),
	('ac00cee7-754c-4bd7-9bb2-e23dc4bf8014', '50516989-1011-4b8c-bde9-9ed0750f4a07', '8c352f67-b128-4eb6-b112-38ea50440b03', 0.040),
	('ac35f85a-583f-47bb-9f26-da18aa2376a5', 'dca3fa98-20e5-487f-a479-5920c7783cab', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.150),
	('ad4e8b83-7227-4225-b662-6a7b3192f5bc', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('ae2028b3-62c7-4ea9-bd73-fafd0703ff2e', '5fb6f8d6-49ed-4587-be09-333b67419ac0', '8c352f67-b128-4eb6-b112-38ea50440b03', 0.040),
	('ae63882e-3690-4f44-be41-c4fe5d8c93a8', '717f21cc-de1d-4881-942a-4601e8bf45f0', '00ccbdd1-3e61-4e0c-b467-04abb8c9f9fc', 0.250),
	('aefc53b0-f5f8-4368-bd20-54cc2e1e8d13', '8581a904-a689-4535-8ffd-0faef973e9a1', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('af17f48a-6e2a-4bb8-bba5-0fa1f64352bd', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('b003411d-ebce-4f43-ad61-745eafc94645', '717f21cc-de1d-4881-942a-4601e8bf45f0', 'd146b503-920a-4b79-9814-521148ed2d8c', 0.100),
	('b0a183e4-6de0-4462-8a46-8dc7375b3b7b', '5fb6f8d6-49ed-4587-be09-333b67419ac0', 'd146b503-920a-4b79-9814-521148ed2d8c', 0.100),
	('b1dbecd2-108a-4a12-aa11-42f186f2bf17', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('b2779f45-692c-4e3a-a38a-4a65384592a5', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', '95f24215-1057-4ca2-97ed-f9e2aadc60f4', 0.020),
	('b279ac17-fd8c-4452-9c42-f366ec2d1a03', 'ee5b570a-759c-42aa-929b-efb390436f1a', '95f24215-1057-4ca2-97ed-f9e2aadc60f4', 0.020),
	('b3fa1152-292c-404f-b7af-7707488819be', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('b70869b1-b8cd-490e-9808-e90103962837', 'e5708074-2b1a-41f3-a9fe-a3a954ecc8e1', 'a00860db-8d18-4c79-af74-783b3025f6d3', 1.000),
	('b7597d3a-d771-4586-969f-cbe20b8633e4', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', 'e0e0d601-c3d4-4276-9799-aa54eca3d07e', 0.150),
	('b7bf8d08-dc50-4e46-b0c2-cd0e0ae6c4c6', '60a58561-6800-44b4-8074-d70d035bb1a2', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('b7ca902d-0dde-435b-bb4f-161eb3961c01', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', 'a193d8e1-f087-49a5-b078-e5fa4990aedc', 0.030),
	('b9864e79-e885-44f1-b403-c341cdaa174f', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('b9a9c23b-b8bf-4bca-a7c4-40fab50adba3', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', '60186adc-05ed-4ade-8165-634077433346', 1.000),
	('baa5d11e-083c-4e52-be14-8a329fa4c8db', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', 'f5be099f-f6d4-4cc2-a203-b98c8eff04ae', 0.200),
	('bac49d30-8a8b-47ae-aed6-029afc994a8a', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', '0e3054a3-96c8-43dd-b2cc-3bf7ce8769ca', 1.000),
	('bb3fb00a-94b0-4066-82da-abdb07c777fe', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', 'ce47359c-271c-4d58-a9e1-018a38340282', 0.300),
	('bb7d2dd0-05a0-42fc-b03d-85302593852e', '2b54201e-9524-4e52-9615-53eef6fae6f6', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040);
INSERT INTO public.produto_ingredientes (id, produto_id, ingrediente_id, quantidade_por_unidade) VALUES
	('bbf5be3b-d0c1-48b6-9f51-ef2c3653da92', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', '13f5cd01-df2c-402c-aa1d-d58c4b7340b5', 0.050),
	('bde5b539-d7c6-4b6b-a24b-8d9c53409834', '93ea5ac0-5b1f-42ce-9289-478820d9108d', '8c352f67-b128-4eb6-b112-38ea50440b03', 0.040),
	('bf092722-6e5a-4bff-8507-94cb18c27bfa', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('bf4150af-fa5f-4b2b-aa16-67802479763b', '50516989-1011-4b8c-bde9-9ed0750f4a07', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.050),
	('c1415129-50a2-41a4-a191-134b9abd7a3b', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('c615a44b-1dfa-4459-a715-0161cc635448', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('c7b5cfd0-92b2-4d86-9d23-2c6cd54ae72c', '65226aff-26be-4bbe-9222-62cd159ba207', 'aa6bd6a9-6065-43c2-8a57-406616c6edf0', 1.000),
	('c80226dc-19bc-4ef8-a4e1-751b6b202932', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('c87f9667-9421-46f6-a06d-06d6167b84cd', '7fa58aa9-40e3-4a45-b314-ad9086d83d26', '435cdc1d-1800-4d38-84ad-3ba22fc809eb', 1.000),
	('c8b9b7ed-f782-4a3f-8709-a65832097760', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', 'd146b503-920a-4b79-9814-521148ed2d8c', 0.100),
	('c8c3fd65-dbed-45c8-8e1b-b30d0bb2f71f', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('c97dc103-7213-484a-a64d-882059506ab0', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', '00ccbdd1-3e61-4e0c-b467-04abb8c9f9fc', 0.080),
	('c9aff610-9c9b-45cf-931d-2b4a3b13661a', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('cb07fb3c-4bd2-4d9e-b6d0-41756a8fe226', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', 'a0571d1c-21ff-49ac-a040-cbe78dc15944', 1.000),
	('cbadae24-f4d6-46ac-a80c-20064ca842c7', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '60186adc-05ed-4ade-8165-634077433346', 1.000),
	('cc7e220d-f52b-4942-9fbb-9ad827a60e7c', '5c9f187f-de24-4615-9042-78e1773e904b', '13f5cd01-df2c-402c-aa1d-d58c4b7340b5', 0.050),
	('cd43422b-deab-41bf-a9c8-8038d107ea10', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', '18ded61d-073a-4c0f-bea8-30b95b40cbdf', 0.050),
	('cee7cb83-3a52-4568-bedd-4b155faed670', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '8c352f67-b128-4eb6-b112-38ea50440b03', 0.040),
	('cfa73b99-6f82-4e7d-9399-47394990026e', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('d0d6dd99-3045-48b5-9592-9295659daec1', '5f5533e0-5760-4edd-a22d-9122097da388', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.050),
	('d237fbad-3af8-43fe-a25b-6ebe6c41249d', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('d300817e-a313-44b4-942e-63183eab5f26', 'fb1ad5ae-9041-4688-accc-2745ff3b8550', '0502d2f5-70c8-44f3-920b-ee10f22c8ef3', 1.000),
	('d5ab7fcf-ecb8-47f5-9e93-39c4e7d96878', 'ee5b570a-759c-42aa-929b-efb390436f1a', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.150),
	('d61f6b5c-56dd-45f0-82ce-ffa0ef60a008', '3338daa5-5f14-4236-92b6-1cee71c509b2', '8c352f67-b128-4eb6-b112-38ea50440b03', 0.040),
	('d628802f-de31-4669-8706-0b024b3ab72b', '5f5533e0-5760-4edd-a22d-9122097da388', 'ce47359c-271c-4d58-a9e1-018a38340282', 0.300),
	('d7b7ed5e-625e-4180-9cf7-fcc0449d4b5f', '717f21cc-de1d-4881-942a-4601e8bf45f0', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('d7c347a7-9c53-4dd2-8717-1732e4aa05ab', 'bf6331a3-74f5-44bb-8b82-635a399c4878', '00ccbdd1-3e61-4e0c-b467-04abb8c9f9fc', 0.500),
	('d87a3c82-737f-4467-9d2d-3085ec930f67', '717f21cc-de1d-4881-942a-4601e8bf45f0', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('d8fdfd2b-8e26-4c38-b574-2581b711de20', '25b30ac0-81b5-46bd-b3ad-876b48a78251', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('d921bfab-4d95-4213-9f70-46b26e21431f', '5fb6f8d6-49ed-4587-be09-333b67419ac0', 'a193d8e1-f087-49a5-b078-e5fa4990aedc', 0.030),
	('d9f302b9-e01a-412d-ac55-d7af70f0afb1', '50516989-1011-4b8c-bde9-9ed0750f4a07', 'a193d8e1-f087-49a5-b078-e5fa4990aedc', 0.080),
	('d9f559dd-4ef0-4ada-b5e6-23c5a72fd8c3', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('db46d0a0-ae2d-4c89-a4cd-dc9c26062617', '25b30ac0-81b5-46bd-b3ad-876b48a78251', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('db5a3d95-1a96-47fb-b721-392a5860e0b8', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '13f5cd01-df2c-402c-aa1d-d58c4b7340b5', 0.050),
	('de06dad5-d378-467d-a22e-ad6deb03ea04', '2b54201e-9524-4e52-9615-53eef6fae6f6', '00ccbdd1-3e61-4e0c-b467-04abb8c9f9fc', 0.250),
	('dedef849-4276-4172-ba13-716097cf7f11', '3338daa5-5f14-4236-92b6-1cee71c509b2', 'ce47359c-271c-4d58-a9e1-018a38340282', 0.300),
	('e10c3362-3276-4b3e-80bc-c74ffe735487', '59fc09ea-7730-40ef-b700-6388068e3ec8', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('e14f5db1-84cb-4f06-8310-219265f16e17', '2b54201e-9524-4e52-9615-53eef6fae6f6', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('e190d68c-8093-4b07-8aba-58fbdaca2b4d', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', 'bfaa5579-33fc-4327-85d8-7a76f7ebeb5b', 1.000),
	('e300e044-986b-44a4-a852-1708281e79fb', '4436ddb0-689e-4b7e-954a-faa1999288a7', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.150),
	('e38d786b-a2a0-49b8-89bf-cf64189c1554', '5fb6f8d6-49ed-4587-be09-333b67419ac0', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('e3aea838-4f8a-4ef3-9dd2-42f84cc6cbd2', '93ea5ac0-5b1f-42ce-9289-478820d9108d', '00ccbdd1-3e61-4e0c-b467-04abb8c9f9fc', 0.250),
	('e3c42d2a-4eed-49e0-bd37-74e363383d1e', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', '46354a04-75b6-47f8-8044-6395ff26e2fd', 0.030),
	('e43e1621-e11a-45b4-ba86-5e7f28160cb3', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('e47ceb4d-700c-4f29-8b6b-57bbe14d4b84', '60a58561-6800-44b4-8074-d70d035bb1a2', 'a0571d1c-21ff-49ac-a040-cbe78dc15944', 1.000),
	('e5148538-f454-47a3-a657-daa13e1c84d4', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '00ccbdd1-3e61-4e0c-b467-04abb8c9f9fc', 0.150),
	('e51c5774-fc8f-4566-9933-c6370710376d', '2b54201e-9524-4e52-9615-53eef6fae6f6', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('e656c4f9-b959-4688-a17d-a69ab542d92f', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('e7150f83-e168-4bc5-b2f3-691e525ed4f1', '8e155a9a-175c-4fb8-890e-97409b2953c8', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('e75ad639-a02d-4e36-8950-d799b8b71ab5', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', 'b8511ba5-b6ff-43ec-adc8-1cee823ac124', 0.400),
	('e8736fe3-5a83-42f9-981a-49321dcb7d7d', '60a58561-6800-44b4-8074-d70d035bb1a2', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030),
	('e9fead5e-e670-42cb-8074-619df0852191', 'ee5b570a-759c-42aa-929b-efb390436f1a', '18ded61d-073a-4c0f-bea8-30b95b40cbdf', 0.050),
	('eace8f46-28f8-4a72-b51e-815f69307e59', 'dca3fa98-20e5-487f-a479-5920c7783cab', 'a193d8e1-f087-49a5-b078-e5fa4990aedc', 0.030),
	('eafb3cbe-2cec-4108-a9c8-a6b9654bc0c8', '717f21cc-de1d-4881-942a-4601e8bf45f0', '774de063-d27a-44b3-9600-62929ab39a51', 1.000),
	('ed639ac4-59e3-4396-8652-1ed39fc75411', '7583e038-e58c-41a8-867c-026f1b90d787', 'd5b72b65-a2c0-43cb-a59c-4bb3bb79035a', 0.080),
	('eda3ebfd-b53d-4047-890c-f90e7570b4fe', '71b73436-5512-4ba4-9719-541b70aec6e0', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.080),
	('eeb1d290-7b11-4712-be0d-6fa5377b72d9', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', '18ded61d-073a-4c0f-bea8-30b95b40cbdf', 0.050),
	('ef667f44-79b2-4a4b-91d0-dad2ae3deac9', '60a58561-6800-44b4-8074-d70d035bb1a2', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.150),
	('f1403d75-b959-4295-804a-22833bab9968', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.150),
	('f1d51395-2b26-44a6-b614-9f666c1cb1a4', '3338daa5-5f14-4236-92b6-1cee71c509b2', '00ccbdd1-3e61-4e0c-b467-04abb8c9f9fc', 0.150),
	('f211fa02-5965-4919-ab1b-70fde6e6f8cc', '4436ddb0-689e-4b7e-954a-faa1999288a7', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('f2ebbeea-4de8-45c8-88c1-81e7171027cc', 'f6777e04-f0b8-442f-ac33-ae1af4752932', '52c73474-5488-4404-8887-65a706905f3e', 1.000),
	('f39bd221-185e-4a79-905e-c51af7d8bf82', '5a98547e-4cca-4a74-bc73-6822c3b8d069', 'a0571d1c-21ff-49ac-a040-cbe78dc15944', 1.000),
	('f39d2e66-4e00-47c2-b67a-8c39bb3d8c38', '3338daa5-5f14-4236-92b6-1cee71c509b2', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.040),
	('f65e0352-84c6-4cd7-94be-745a1fc9d3e6', '5fb6f8d6-49ed-4587-be09-333b67419ac0', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.150),
	('f676bf51-aa07-4fca-8204-278e6468a3c3', '63841581-68f3-4cfa-bc81-c78466e5ec5b', 'eb106229-8c07-465b-9129-24cadf4c7c00', 0.040),
	('f79df1fe-bec2-4384-8664-8bffff149f30', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '5f964547-cf55-411a-8ba7-b4b2585e0c32', 0.150),
	('f7d1f3b5-ac1b-43b1-ae0c-92acf5b98114', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', 'd5b72b65-a2c0-43cb-a59c-4bb3bb79035a', 0.040),
	('fb01a20c-7710-485a-91e0-be05d838cbd7', '2b54201e-9524-4e52-9615-53eef6fae6f6', 'd5f83abb-06fc-4c50-aae2-c54c9b3eea35', 0.050),
	('fc8d3ec4-0ab8-4d87-83d2-34cfb1c6f968', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('fd3d4b3b-381b-48c7-a045-9d6d4e4ebf86', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', '5b3f3d17-4928-445f-8150-6a8ab3e45c94', 1.000),
	('fd4c8771-696e-4c2e-9bb2-4aab5a28554e', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', 'f43cc40f-3a3b-40a3-b253-adf393569879', 0.030),
	('fe23829b-9fa7-4f72-9931-7dc9bbbd0f6b', 'ee5b570a-759c-42aa-929b-efb390436f1a', '60aabb92-6c29-43f2-a1b5-9cc7217a6cb4', 0.030);


--
-- Data for Name: produto_precos; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.produto_precos (id, produto_id, forma_pagamento_id, preco, custo) VALUES
	('00ec219f-6478-449d-be8b-d701296ead0a', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 90.00, 21.37),
	('010919b6-f3fe-42dd-a9e7-6eaa037ae45f', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '21d76d26-8608-47b8-b387-1e9f5b150715', 41.00, 11.69),
	('0185f96e-5387-456c-a6bb-35a327ae15a8', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 38.00, 10.33),
	('01883992-6145-41f0-a6cc-f4089f59ad50', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 28.25, 10.71),
	('01d3b488-f5ca-404d-8055-60d61fbd608d', '86519e93-90e6-4174-b509-136cf9f43430', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 22.60, 6.36),
	('01d9f45d-6c3d-44bc-9575-57f2006a5108', 'e5708074-2b1a-41f3-a9fe-a3a954ecc8e1', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 16.00, 10.00),
	('032d0f59-e5ec-4c3f-a799-f29627add92d', '50516989-1011-4b8c-bde9-9ed0750f4a07', '212c5286-05f4-47aa-8c00-ed7968551e08', 33.00, 9.15),
	('03b4662b-b3d3-4f2b-b1aa-1fc62cc1b5b4', '71b73436-5512-4ba4-9719-541b70aec6e0', '21d76d26-8608-47b8-b387-1e9f5b150715', 24.90, 9.19),
	('040db079-36db-45e7-9670-4803dc408842', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', '17b14f91-68d9-4a94-9374-c64846414581', 38.30, 12.18),
	('054364ef-d784-42dc-bac3-5da2c35514f8', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 36.00, 9.68),
	('05bc0cd8-7da7-4619-a867-9cf7c8864cf9', 'dca3fa98-20e5-487f-a479-5920c7783cab', '212c5286-05f4-47aa-8c00-ed7968551e08', 31.65, 12.31),
	('05cff8eb-50ba-4318-8884-d662926415ee', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 41.70, 12.79),
	('05e0f6db-7a5b-46b7-8460-95932b393663', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', '212c5286-05f4-47aa-8c00-ed7968551e08', 39.55, 13.27),
	('082da509-b771-4137-9b20-dd7d6ab7a830', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 32.00, 9.97),
	('08345556-b758-4005-8b41-d243395bc938', 'e5708074-2b1a-41f3-a9fe-a3a954ecc8e1', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 16.00, 10.00),
	('08b6b8d8-80a2-4012-9bcd-a743d614fe25', '4436ddb0-689e-4b7e-954a-faa1999288a7', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 36.00, 12.07),
	('08e79f70-604a-4507-8996-63881e8d6157', 'fb1ad5ae-9041-4688-accc-2745ff3b8550', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 10.00, 8.00),
	('09cc5920-981a-4478-9b0d-6417fbd0b19e', '4014c744-53bc-4148-8fcf-0799918e88aa', '21d76d26-8608-47b8-b387-1e9f5b150715', 35.90, 12.81),
	('09dbf00a-114a-4f33-83c7-c03b10fee31c', '86519e93-90e6-4174-b509-136cf9f43430', '17b14f91-68d9-4a94-9374-c64846414581', 22.60, 6.36),
	('09f01908-3a6b-48d9-b4b7-cf2b333a9d0c', 'dca3fa98-20e5-487f-a479-5920c7783cab', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 31.65, 12.31),
	('0aaa4eab-5137-47fa-91fd-3f51bf36f6d1', 'ee5b570a-759c-42aa-929b-efb390436f1a', '21d76d26-8608-47b8-b387-1e9f5b150715', 40.90, 11.61),
	('0c0d3c4c-4fb1-41d9-8c55-cd548030f786', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 39.50, 12.45),
	('0ddf14b8-ab97-4183-a570-b65f3ba9d6dd', '25b30ac0-81b5-46bd-b3ad-876b48a78251', '17b14f91-68d9-4a94-9374-c64846414581', 45.00, 16.02),
	('0e7a0c93-9e18-41c6-853d-9cea0861f387', 'ee5b570a-759c-42aa-929b-efb390436f1a', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 38.30, 11.61),
	('0ef78518-b71c-457e-b291-7ea06d36f124', 'dca3fa98-20e5-487f-a479-5920c7783cab', '21d76d26-8608-47b8-b387-1e9f5b150715', 33.90, 12.31),
	('1395fbcf-e09b-4bcb-9bf0-b943e12fe35e', '60a58561-6800-44b4-8074-d70d035bb1a2', '212c5286-05f4-47aa-8c00-ed7968551e08', 39.55, 13.67),
	('13ab937e-9a2f-4953-a8cb-225113a9b1a9', '25b30ac0-81b5-46bd-b3ad-876b48a78251', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 45.00, 16.02),
	('14ec0c4e-eac7-444a-a867-3f68a69447a5', '1658ebed-648f-4150-bf26-f50993a72243', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 34.00, 9.20),
	('15e9cb82-611c-42bc-a77c-013b35b273bb', 'e5708074-2b1a-41f3-a9fe-a3a954ecc8e1', '21d76d26-8608-47b8-b387-1e9f5b150715', 19.00, 10.00),
	('1653a4de-08d7-443c-80a7-bf2a11bfbff5', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 28.25, 11.11),
	('190d38d7-fddd-4529-8121-cf36551f1f66', '1658ebed-648f-4150-bf26-f50993a72243', '212c5286-05f4-47aa-8c00-ed7968551e08', 34.00, 9.20),
	('19d2def6-ad45-4e4c-bb91-28302d44e5d6', '5fb6f8d6-49ed-4587-be09-333b67419ac0', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 45.00, 16.48),
	('19e61884-f5ad-43ce-84ab-bf3e66536382', 'f6777e04-f0b8-442f-ac33-ae1af4752932', '212c5286-05f4-47aa-8c00-ed7968551e08', 6.00, 3.20),
	('19e7894c-c581-4443-930c-c238f664861e', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 39.50, 12.45),
	('1a0e301c-8e0f-419c-a757-860d9ad6464d', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', '17b14f91-68d9-4a94-9374-c64846414581', 38.30, 9.96),
	('1a163d06-d0de-4205-89ae-e046a4482f35', '5f5533e0-5760-4edd-a22d-9122097da388', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 38.30, 9.73),
	('1a8140f1-f7b1-4999-a374-7debbe9aa1f2', '60a58561-6800-44b4-8074-d70d035bb1a2', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 39.55, 13.67),
	('1b7b39ee-4bca-4ee1-9233-befe244456a4', 'e5708074-2b1a-41f3-a9fe-a3a954ecc8e1', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 16.00, 10.00),
	('1bd7f6a9-61ed-4c10-a85d-2bf8c7002840', '59fc09ea-7730-40ef-b700-6388068e3ec8', '212c5286-05f4-47aa-8c00-ed7968551e08', 23.50, 9.13),
	('1c3506a8-5e6d-4f7b-bc93-403c39e0dd2b', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '5ed453d4-554c-458d-b03b-a10f5c110f20', 43.00, 11.69),
	('1cd6585d-876d-4cb0-bcda-fe44d75fbc30', '3338daa5-5f14-4236-92b6-1cee71c509b2', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 41.70, 10.63),
	('1e8999e9-d5cc-480c-8e38-a6a985fa5a09', '64142b67-ba38-41fe-8e46-68213b65a342', '212c5286-05f4-47aa-8c00-ed7968551e08', 36.00, 12.15),
	('1f074f5a-96ce-409b-b98a-73e2f26b877b', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 39.55, 13.27),
	('1ff241f8-4283-4217-82c3-202828d1ce3f', '4014c744-53bc-4148-8fcf-0799918e88aa', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 34.00, 12.81),
	('20bacd85-7472-4b5e-8e4b-14da1509418c', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 21.50, 6.06),
	('21dee84a-70c3-4d65-8c4c-4c153dd8f7a2', '5f5533e0-5760-4edd-a22d-9122097da388', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 38.30, 9.73),
	('22f5e4bf-1bad-4f06-974e-6271e885f5ed', '5fb6f8d6-49ed-4587-be09-333b67419ac0', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 45.00, 16.48),
	('2626e5af-929f-4a99-ac40-35c860fc1f43', '5c9f187f-de24-4615-9042-78e1773e904b', '212c5286-05f4-47aa-8c00-ed7968551e08', 50.85, 14.16),
	('272c4d1c-dbf1-4904-9f62-1d8bdff9f328', '4436ddb0-689e-4b7e-954a-faa1999288a7', '21d76d26-8608-47b8-b387-1e9f5b150715', 38.90, 12.07),
	('278e3c65-5e0b-4edc-9ef6-82d571ff4115', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 90.00, 21.37),
	('28cd0c60-be91-4a05-b680-6ce34df8f517', 'f6777e04-f0b8-442f-ac33-ae1af4752932', '17b14f91-68d9-4a94-9374-c64846414581', 6.00, 3.20),
	('29065452-c54f-4e0f-9763-4e887cf5a52b', '2b54201e-9524-4e52-9615-53eef6fae6f6', '21d76d26-8608-47b8-b387-1e9f5b150715', 41.90, 12.29),
	('293c582c-e21a-4d08-b5ca-c67232b49de2', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 28.25, 10.71),
	('29a4cad0-5bd9-4a73-bc68-e31ffe272950', 'fb1ad5ae-9041-4688-accc-2745ff3b8550', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 10.00, 8.00),
	('2c7b93ae-7fbe-4e62-b380-5c48e1e3240a', 'f6777e04-f0b8-442f-ac33-ae1af4752932', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 6.00, 3.20),
	('2c8723b3-4eac-40f4-a70a-f2a6ec435d5a', 'bf6331a3-74f5-44bb-8b82-635a399c4878', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 50.00, 9.00),
	('2e0dd756-00c1-4c2b-b40c-7a1d11a75fd4', '8e155a9a-175c-4fb8-890e-97409b2953c8', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 67.80, 14.11),
	('2e697973-9725-49c6-973f-7e48175247b1', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 6.00, 3.20),
	('2ea2f40a-da3e-4962-aa32-906309ef6d45', '64142b67-ba38-41fe-8e46-68213b65a342', '17b14f91-68d9-4a94-9374-c64846414581', 36.00, 12.15),
	('2f75970a-0e30-4318-9e74-1fb1fe1172f6', '86519e93-90e6-4174-b509-136cf9f43430', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 22.60, 6.36),
	('309ea5a1-d7be-42d7-932c-044abbcad1d4', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 22.60, 4.76),
	('323308e8-d515-4d02-b9ee-cdab0d1722c5', '1658ebed-648f-4150-bf26-f50993a72243', '17b14f91-68d9-4a94-9374-c64846414581', 34.00, 9.20),
	('32859568-366c-4b07-8633-320d6346d541', '60a58561-6800-44b4-8074-d70d035bb1a2', '21d76d26-8608-47b8-b387-1e9f5b150715', 41.90, 13.67),
	('34442323-d341-43f5-9938-439675a752d9', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', '21d76d26-8608-47b8-b387-1e9f5b150715', 40.90, 10.33),
	('34918a96-cc71-4c10-ab8c-2617007d3a89', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', '21d76d26-8608-47b8-b387-1e9f5b150715', 22.90, 8.73),
	('349257cd-9025-4724-951a-831e119dbe12', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '212c5286-05f4-47aa-8c00-ed7968551e08', 39.50, 12.45),
	('359663a0-fc95-4e35-b782-c7afc10d41ed', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 67.80, 12.64),
	('3679779b-5b77-4428-af0a-0391c5ec2320', '4014c744-53bc-4148-8fcf-0799918e88aa', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 34.00, 12.81),
	('369fbe24-e55e-4eb4-b61e-ee6521c1904b', '717f21cc-de1d-4881-942a-4601e8bf45f0', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 41.70, 12.58),
	('36dde6ea-bca3-4e0c-8df8-9d890710546b', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', '212c5286-05f4-47aa-8c00-ed7968551e08', 28.25, 10.71),
	('37e28ce9-7253-4eda-9f8a-8deb8a0bd5f2', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 22.60, 4.76),
	('380ac361-7983-4aa1-8bc3-a31f900c70f2', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', '212c5286-05f4-47aa-8c00-ed7968551e08', 90.00, 21.37),
	('38d578e4-d191-4a51-b27c-7266683d0ba0', '7583e038-e58c-41a8-867c-026f1b90d787', '17b14f91-68d9-4a94-9374-c64846414581', 48.40, 21.99),
	('39b7473f-d832-4e5e-91b8-e4ff240e6600', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 39.55, 13.27),
	('3a12fdc4-5060-495e-8316-50d0675c90da', '4436ddb0-689e-4b7e-954a-faa1999288a7', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 36.00, 12.07),
	('3bf08ed1-b1c3-4ffc-be99-29f4605d4419', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '21d76d26-8608-47b8-b387-1e9f5b150715', 44.90, 12.79),
	('3c0d9ccc-f1b7-4221-9d35-aa327dd6457b', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 22.60, 4.76),
	('3e4dc2ef-fb61-4dff-ba79-5b8746f6a284', '63841581-68f3-4cfa-bc81-c78466e5ec5b', '17b14f91-68d9-4a94-9374-c64846414581', 67.80, 14.17),
	('3eb762d5-5d8a-469b-b71f-7075d023d48c', '65226aff-26be-4bbe-9222-62cd159ba207', '21d76d26-8608-47b8-b387-1e9f5b150715', 42.00, 9.96),
	('401226a6-19b1-4efb-ab00-0e2bfda11fcf', '5fb6f8d6-49ed-4587-be09-333b67419ac0', '17b14f91-68d9-4a94-9374-c64846414581', 45.00, 16.48),
	('40bf48e5-d7fa-4d62-a8de-88b621d2f6e3', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 38.30, 12.18),
	('418a60c9-9b8e-4e65-962d-74f4b237f57d', '1658ebed-648f-4150-bf26-f50993a72243', '21d76d26-8608-47b8-b387-1e9f5b150715', 35.90, 9.20),
	('424a0e07-f69f-4f8e-b536-07b71cdbf693', '7583e038-e58c-41a8-867c-026f1b90d787', '212c5286-05f4-47aa-8c00-ed7968551e08', 48.40, 21.99),
	('42988e8c-7506-48e9-8741-e3a8e711e999', '4436ddb0-689e-4b7e-954a-faa1999288a7', '17b14f91-68d9-4a94-9374-c64846414581', 36.00, 12.07),
	('42f74de9-f19d-4663-a8db-b1e98ab46a1c', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 38.00, 10.33),
	('4328ab7e-a769-44ca-9ef3-a5f1d9b9aeaa', '7583e038-e58c-41a8-867c-026f1b90d787', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 48.40, 21.99),
	('43ce09e7-8a4d-4125-90b1-586ac4ca5876', 'dbdba3e8-488c-4eca-b84c-108ba9de45ba', '21d76d26-8608-47b8-b387-1e9f5b150715', 12.00, 8.00),
	('44147a93-e65b-4d0e-a30b-54da9dd3daa8', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', '212c5286-05f4-47aa-8c00-ed7968551e08', 67.80, 12.64),
	('44c98aa9-8c54-4fac-b749-6f4cf85846e5', '8e155a9a-175c-4fb8-890e-97409b2953c8', '17b14f91-68d9-4a94-9374-c64846414581', 67.80, 14.11),
	('461a4b04-322f-4ac9-af03-f8741f402507', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', '21d76d26-8608-47b8-b387-1e9f5b150715', 38.90, 9.68),
	('47cded56-c07c-4a7a-b7be-7a815dad5f55', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', '17b14f91-68d9-4a94-9374-c64846414581', 39.55, 13.27),
	('4aad0c4f-c1f8-42ab-b90d-cd724ff7217b', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 36.00, 7.47),
	('4ad09c01-05e5-431f-bd04-39bbc6848b19', '7583e038-e58c-41a8-867c-026f1b90d787', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 48.40, 21.99),
	('4ae4dac1-900a-4746-9919-8a22ae86ec74', '5a98547e-4cca-4a74-bc73-6822c3b8d069', '21d76d26-8608-47b8-b387-1e9f5b150715', 17.99, 4.54),
	('4f913649-3feb-45fb-906e-b6a791efd41a', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', '17b14f91-68d9-4a94-9374-c64846414581', 28.25, 10.71),
	('5011aade-aedd-4548-8f87-8ea5089dc87b', '64142b67-ba38-41fe-8e46-68213b65a342', '21d76d26-8608-47b8-b387-1e9f5b150715', 38.90, 12.15),
	('51e1ee6c-9910-4bb9-9b7e-1afdeda5d5a8', '7fa58aa9-40e3-4a45-b314-ad9086d83d26', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 16.00, 10.00),
	('524933c1-fd31-45c1-8f7f-adcbd9c30ba6', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 50.85, 16.93),
	('53141bdf-b4f6-49da-8073-5aadd7eb8d08', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', '17b14f91-68d9-4a94-9374-c64846414581', 36.00, 9.68),
	('533dc9b7-48c6-4121-87d2-5a70b5d92835', 'dca3fa98-20e5-487f-a479-5920c7783cab', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 31.65, 12.31);
INSERT INTO public.produto_precos (id, produto_id, forma_pagamento_id, preco, custo) VALUES
	('535fb8ba-85b6-4c5e-a330-97799cfe48b3', '5c9f187f-de24-4615-9042-78e1773e904b', '17b14f91-68d9-4a94-9374-c64846414581', 50.85, 14.16),
	('5524b7ff-f894-4279-8bdf-e0c7c6070723', '5f5533e0-5760-4edd-a22d-9122097da388', '212c5286-05f4-47aa-8c00-ed7968551e08', 38.30, 9.73),
	('559ec123-314a-4d48-b2ae-b7a312208fc6', '3338daa5-5f14-4236-92b6-1cee71c509b2', '212c5286-05f4-47aa-8c00-ed7968551e08', 41.70, 10.63),
	('55e5e74d-49a2-42ae-8ae1-0e8b565e1a93', '8581a904-a689-4535-8ffd-0faef973e9a1', '17b14f91-68d9-4a94-9374-c64846414581', 23.50, 7.50),
	('568f1099-d33b-4ebc-8ece-368675d438a6', 'fb1ad5ae-9041-4688-accc-2745ff3b8550', '212c5286-05f4-47aa-8c00-ed7968551e08', 10.00, 8.00),
	('581e6781-b6ce-4427-aa41-c87b123db3db', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 32.00, 9.97),
	('58937811-765c-4fd0-afb4-b43703b43fce', '63841581-68f3-4cfa-bc81-c78466e5ec5b', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 67.80, 14.17),
	('5978d927-3cda-4395-9462-642b142cb1f4', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', '212c5286-05f4-47aa-8c00-ed7968551e08', 6.00, 3.20),
	('5a3cd266-9d43-4b02-8ee1-56817a33c467', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 21.50, 6.06),
	('5b7e2401-0810-4020-9dcd-5f418e529e01', '65226aff-26be-4bbe-9222-62cd159ba207', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 39.40, 9.96),
	('5c1e7e8d-a221-4731-bdbd-09e705860127', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '21d76d26-8608-47b8-b387-1e9f5b150715', 41.90, 12.45),
	('5cc6484f-8329-4baf-bc70-aa6a520b30f7', '71b73436-5512-4ba4-9719-541b70aec6e0', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 23.50, 9.19),
	('5e4020d4-5181-4ae2-897f-c0dd286b926a', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', '21d76d26-8608-47b8-b387-1e9f5b150715', 39.90, 13.27),
	('5e5dad69-7af9-47e9-9450-b91cd8f3591b', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', '21d76d26-8608-47b8-b387-1e9f5b150715', 33.90, 9.97),
	('60325e68-10d2-4022-8c57-125aa2a6810c', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 90.00, 21.37),
	('609be250-e79f-4666-a571-83cffe82c668', 'f6777e04-f0b8-442f-ac33-ae1af4752932', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 6.00, 3.20),
	('6249f45a-69d4-4f54-9574-24511bfc25db', '86519e93-90e6-4174-b509-136cf9f43430', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 22.60, 6.36),
	('65db12a1-85af-49e3-b865-8da788e4b1c5', '59fc09ea-7730-40ef-b700-6388068e3ec8', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 23.50, 9.13),
	('675cda4b-2af7-41aa-a91e-c449ca83d7d6', 'e5708074-2b1a-41f3-a9fe-a3a954ecc8e1', '212c5286-05f4-47aa-8c00-ed7968551e08', 16.00, 10.00),
	('684f9ed1-d73f-453f-bdbd-6180886ff6fd', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', '21d76d26-8608-47b8-b387-1e9f5b150715', 53.90, 26.18),
	('689eb4ad-2212-4394-8a6d-c531a3563345', '60a58561-6800-44b4-8074-d70d035bb1a2', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 39.55, 13.67),
	('6a52589c-2fa4-47c1-8a84-94a494948384', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', '21d76d26-8608-47b8-b387-1e9f5b150715', 23.99, 4.76),
	('6a6f739c-3dc5-4a85-9968-d62c9a4da4d9', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 21.50, 6.06),
	('6b045881-16bf-4596-b2d5-af29bff323c9', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', '17b14f91-68d9-4a94-9374-c64846414581', 21.50, 8.73),
	('6b4a9d58-99d3-43d5-a017-8b962a1c6f6f', '2b54201e-9524-4e52-9615-53eef6fae6f6', '212c5286-05f4-47aa-8c00-ed7968551e08', 39.00, 12.29),
	('6c09d5df-1440-4ea0-8775-8d86c7d553cb', '8581a904-a689-4535-8ffd-0faef973e9a1', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 23.50, 7.50),
	('6c7ca0b9-5ee5-4051-a0b9-4b47e3dc06e3', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', '17b14f91-68d9-4a94-9374-c64846414581', 67.80, 12.64),
	('6c98bb47-c47f-4c2b-b2f6-951b0b07c5e8', '8e155a9a-175c-4fb8-890e-97409b2953c8', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 67.80, 14.11),
	('6e2d5910-3c31-45b2-98a9-5717c5f3b37c', '4436ddb0-689e-4b7e-954a-faa1999288a7', '212c5286-05f4-47aa-8c00-ed7968551e08', 36.00, 12.07),
	('6e9a690f-9935-47a9-b762-9c1cb42fc4dc', '93ea5ac0-5b1f-42ce-9289-478820d9108d', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 34.00, 11.33),
	('6ec96848-dbb6-4a6f-bbe2-dc39606a8628', '65226aff-26be-4bbe-9222-62cd159ba207', '212c5286-05f4-47aa-8c00-ed7968551e08', 39.40, 9.96),
	('6f8079ee-5921-4916-a449-3e42be0cd5f4', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', '17b14f91-68d9-4a94-9374-c64846414581', 39.50, 12.45),
	('7035e674-d5d9-4915-a95c-d9672d38bcc7', '5fb6f8d6-49ed-4587-be09-333b67419ac0', '21d76d26-8608-47b8-b387-1e9f5b150715', 47.90, 16.48),
	('707f3738-1fa5-448b-b86d-e294bfe173bd', '7583e038-e58c-41a8-867c-026f1b90d787', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 48.40, 21.99),
	('732b7fb9-cdfb-4cec-b3ee-b8bfd1e25892', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', '17b14f91-68d9-4a94-9374-c64846414581', 6.00, 3.20),
	('7392c11b-5e42-4632-8729-968ebd0c3e44', '50516989-1011-4b8c-bde9-9ed0750f4a07', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 33.00, 9.15),
	('74207a8a-5116-4aa4-aee0-b9a631261c0f', 'fb1ad5ae-9041-4688-accc-2745ff3b8550', '21d76d26-8608-47b8-b387-1e9f5b150715', 12.00, 8.00),
	('765004b1-e2ca-46aa-93b2-b437c4e81950', '43087961-297c-4b43-8ddd-1484188baab2', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 31.00, 9.37),
	('772d51f8-a0bc-484e-bf97-ef93495e2f9c', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', '17b14f91-68d9-4a94-9374-c64846414581', 22.60, 4.76),
	('78dca2dd-c972-42a1-9aff-a7a64b42fe56', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 36.00, 7.47),
	('791f8590-bb5f-4527-9429-2f115e2eb3bd', 'd84ddbbc-8922-419f-8d2c-0a94b2e123a2', '212c5286-05f4-47aa-8c00-ed7968551e08', 22.60, 4.76),
	('79219cb6-b883-4876-a548-a03f3e4479b0', '8581a904-a689-4535-8ffd-0faef973e9a1', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 23.50, 7.50),
	('79465cf4-360b-45d4-b1d9-801a4039fa6b', '59fc09ea-7730-40ef-b700-6388068e3ec8', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 23.50, 9.13),
	('7b01fb48-a0c2-4286-8f3a-24fe2252a831', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', '17b14f91-68d9-4a94-9374-c64846414581', 50.85, 26.18),
	('7bf9eed7-1127-49b9-8778-60bd8b76da71', '717f21cc-de1d-4881-942a-4601e8bf45f0', '17b14f91-68d9-4a94-9374-c64846414581', 41.70, 12.58),
	('7cd62a7f-1b8d-49d1-b243-0af2e475d72f', '1658ebed-648f-4150-bf26-f50993a72243', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 34.00, 9.20),
	('7f322f3e-80c6-41d5-9615-bb48a0724b74', '71b73436-5512-4ba4-9719-541b70aec6e0', '212c5286-05f4-47aa-8c00-ed7968551e08', 23.50, 9.19),
	('80800f0e-25eb-4bd8-b3d4-7bfbca1b8c6e', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', '21d76d26-8608-47b8-b387-1e9f5b150715', 29.90, 11.11),
	('80cbe7c2-4c29-4ec7-9812-599c2820a199', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 41.70, 12.79),
	('80d19fdd-ed5b-4509-a928-3c68a66ad76e', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', '17b14f91-68d9-4a94-9374-c64846414581', 38.00, 10.33),
	('82522516-292b-4d51-814b-b04abdcc5a1f', '8e155a9a-175c-4fb8-890e-97409b2953c8', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 67.80, 14.11),
	('83a7180d-801e-4054-848c-0c24c8b3d0a4', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', '212c5286-05f4-47aa-8c00-ed7968551e08', 36.00, 9.68),
	('8515c874-b132-4527-9df2-0a069559274a', '59fc09ea-7730-40ef-b700-6388068e3ec8', '17b14f91-68d9-4a94-9374-c64846414581', 23.50, 9.13),
	('8518eada-b8d0-41cc-855f-a0dde401c9b7', '25b30ac0-81b5-46bd-b3ad-876b48a78251', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 45.00, 16.02),
	('8ad169af-63dd-4ef8-b5a9-a27411859c79', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 38.00, 10.33),
	('8b4b2a51-411c-451c-9657-f13c569b67c6', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', '17b14f91-68d9-4a94-9374-c64846414581', 21.50, 6.06),
	('8c311533-7dd0-4ac1-bd10-4c0889a0b110', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 43.00, 11.69),
	('8c8a39b5-3262-4281-a2b4-66e52a4ee454', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 41.70, 12.79),
	('8d1b0f3d-bc75-4b7d-b5d5-481efb9f5e1f', '63841581-68f3-4cfa-bc81-c78466e5ec5b', '212c5286-05f4-47aa-8c00-ed7968551e08', 67.80, 14.17),
	('8d3ec5e2-c73e-472f-b3a1-09ebd56a8b34', '4014c744-53bc-4148-8fcf-0799918e88aa', '17b14f91-68d9-4a94-9374-c64846414581', 34.00, 12.81),
	('8d4b4ce6-9b16-471a-aabe-3fd516f17c2b', '64142b67-ba38-41fe-8e46-68213b65a342', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 36.00, 12.15),
	('8d65a250-6bef-4ac6-a4b0-e6cf0ec4d976', '8e155a9a-175c-4fb8-890e-97409b2953c8', '21d76d26-8608-47b8-b387-1e9f5b150715', 71.90, 14.11),
	('8f279a19-baef-449a-922c-5200d25b7759', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 50.85, 26.18),
	('903e5bcd-419c-4eb6-b3d9-337a59d24072', '5f5533e0-5760-4edd-a22d-9122097da388', '21d76d26-8608-47b8-b387-1e9f5b150715', 41.00, 9.73),
	('90522a4d-6477-4342-ab49-d7e862156543', '3338daa5-5f14-4236-92b6-1cee71c509b2', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 41.70, 10.63),
	('90918f49-8887-4d8e-8725-81eadcc9d12e', '7583e038-e58c-41a8-867c-026f1b90d787', '21d76d26-8608-47b8-b387-1e9f5b150715', 51.90, 21.99),
	('90cc4c09-c1d1-4c05-b5e9-a034efa8b6d3', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', '21d76d26-8608-47b8-b387-1e9f5b150715', 41.00, 9.96),
	('911a4061-fe4b-481f-bf50-9a6ca7c2318f', '2b54201e-9524-4e52-9615-53eef6fae6f6', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 39.00, 12.29),
	('921a8398-10c1-4d7b-a5ee-67b4c19843d6', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 38.30, 9.96),
	('9222a703-6b46-4ac3-8f59-ebff4de429e7', '37a9d977-55ed-4ff2-a8dc-38c271a1e6a3', '212c5286-05f4-47aa-8c00-ed7968551e08', 38.00, 10.33),
	('933cd3e9-3d85-4961-b6f1-3c5e8a648598', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '17b14f91-68d9-4a94-9374-c64846414581', 41.70, 12.79),
	('93927324-3365-40d6-a06f-46fd53e7d8db', '63841581-68f3-4cfa-bc81-c78466e5ec5b', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 67.80, 14.17),
	('94420789-a1a5-4af6-b6c9-8411ca0b3c90', '43087961-297c-4b43-8ddd-1484188baab2', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 31.00, 9.37),
	('945785c9-7133-4713-b2fa-3a0a52449116', '2b54201e-9524-4e52-9615-53eef6fae6f6', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 39.00, 12.29),
	('9485ad20-7967-44d9-86b7-8165731a603c', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 28.25, 11.11),
	('972937f0-a1ea-4d22-a7b7-37b9469ebc41', '5a98547e-4cca-4a74-bc73-6822c3b8d069', '17b14f91-68d9-4a94-9374-c64846414581', 17.00, 4.54),
	('9816fd72-bdf4-4166-a1ac-ddd02d6026af', '5c9f187f-de24-4615-9042-78e1773e904b', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 50.85, 14.16),
	('9b68d6c5-c6e3-4130-8d4a-aa68142e4203', '7fa58aa9-40e3-4a45-b314-ad9086d83d26', '21d76d26-8608-47b8-b387-1e9f5b150715', 19.00, 10.00),
	('9bc17854-0d84-40b7-82b0-b02d4476e3d4', '1658ebed-648f-4150-bf26-f50993a72243', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 34.00, 9.20),
	('9bf57578-0504-4648-81cb-64fcf47ce519', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', '17b14f91-68d9-4a94-9374-c64846414581', 32.00, 9.97),
	('9c635f31-4899-4c36-a968-33e163934b60', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', '212c5286-05f4-47aa-8c00-ed7968551e08', 36.00, 7.47),
	('9cb243dd-df51-46c6-90bf-b5fca4b84315', '7fa58aa9-40e3-4a45-b314-ad9086d83d26', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 16.00, 10.00),
	('9cc3eef7-b7e5-4da7-8f77-98d68bad5816', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', '21d76d26-8608-47b8-b387-1e9f5b150715', 71.90, 12.64),
	('9e026b25-cea4-46fa-82da-e49517371877', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', '212c5286-05f4-47aa-8c00-ed7968551e08', 38.30, 12.18),
	('9f4a4a73-7acd-47b7-a677-551f7775745b', '43087961-297c-4b43-8ddd-1484188baab2', '212c5286-05f4-47aa-8c00-ed7968551e08', 31.00, 9.37),
	('9f7ba2b1-358e-4968-b4fb-0cbbb78eb349', '717f21cc-de1d-4881-942a-4601e8bf45f0', '21d76d26-8608-47b8-b387-1e9f5b150715', 44.90, 12.58),
	('9fba9ab2-a5aa-420f-b4be-0a58f0db9360', 'bf6331a3-74f5-44bb-8b82-635a399c4878', '212c5286-05f4-47aa-8c00-ed7968551e08', 50.00, 9.00),
	('9fc3675f-d78e-47f9-8e64-ee13137990a5', '93ea5ac0-5b1f-42ce-9289-478820d9108d', '212c5286-05f4-47aa-8c00-ed7968551e08', 34.00, 11.33),
	('a11294b8-09a9-455d-8c72-584c71d837d2', '59fc09ea-7730-40ef-b700-6388068e3ec8', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 23.50, 9.13),
	('a331bb8c-ac47-4752-b1a3-132d58d5b9b0', '60a58561-6800-44b4-8074-d70d035bb1a2', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 39.55, 13.67),
	('a49dcc95-c043-4af2-b35a-1faf2339abc1', 'ee5b570a-759c-42aa-929b-efb390436f1a', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 38.30, 11.61),
	('a60009cf-fb71-4e0b-ab34-af115d412ab8', '5fb6f8d6-49ed-4587-be09-333b67419ac0', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 45.00, 16.48),
	('a6509132-922e-4183-b3ba-422bed94cf5d', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 21.50, 8.73),
	('a72fa154-9cf0-476f-b23c-f68fca7e5cba', 'dbdba3e8-488c-4eca-b84c-108ba9de45ba', '17b14f91-68d9-4a94-9374-c64846414581', 10.00, 8.00),
	('a752a6d0-938e-4cf2-b6b6-85dc4144fc13', '50516989-1011-4b8c-bde9-9ed0750f4a07', '17b14f91-68d9-4a94-9374-c64846414581', 33.00, 9.15),
	('a7788bd9-a947-484c-895d-7803e01ebb35', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', '212c5286-05f4-47aa-8c00-ed7968551e08', 28.25, 11.11),
	('a8d54678-88c8-4b0a-a78c-6164d446b3b0', 'bf6331a3-74f5-44bb-8b82-635a399c4878', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 50.00, 9.00),
	('a918ae75-62b1-4506-992b-b5e185513faa', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 43.00, 11.69),
	('a96627bf-c63d-4f80-974e-f9b660105616', '93ea5ac0-5b1f-42ce-9289-478820d9108d', '21d76d26-8608-47b8-b387-1e9f5b150715', 35.90, 11.33),
	('aa292d71-961b-4cf1-bb5b-f4fc3b5ed8e5', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 67.80, 12.64);
INSERT INTO public.produto_precos (id, produto_id, forma_pagamento_id, preco, custo) VALUES
	('aa6fd4ee-46de-4a80-a1eb-3341ae52b07d', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', '212c5286-05f4-47aa-8c00-ed7968551e08', 21.50, 6.06),
	('aac859ea-2131-45e7-b255-93fafdaa8c3a', '25b30ac0-81b5-46bd-b3ad-876b48a78251', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 45.00, 16.02),
	('abea1712-f986-45a4-b14c-ceca80943f25', '2b54201e-9524-4e52-9615-53eef6fae6f6', '17b14f91-68d9-4a94-9374-c64846414581', 39.00, 12.29),
	('abfa2a5f-6030-4287-ae9d-03ebef753f14', '43087961-297c-4b43-8ddd-1484188baab2', '21d76d26-8608-47b8-b387-1e9f5b150715', 32.90, 9.37),
	('aca31cfe-9d88-43f2-a4d4-e5cfa9f506e8', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 50.85, 16.93),
	('acd87060-e2b9-4880-bc14-0d81c466e0b0', '7fa58aa9-40e3-4a45-b314-ad9086d83d26', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 16.00, 10.00),
	('ad0f71ea-9992-4dda-8f9a-69e2663433a8', '50516989-1011-4b8c-bde9-9ed0750f4a07', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 33.00, 9.15),
	('ad8fe033-9e20-4e50-ac97-6fbdb6bf3368', '65226aff-26be-4bbe-9222-62cd159ba207', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 39.40, 9.96),
	('ae435c17-9774-488b-a165-116d2e8344f9', '7fa58aa9-40e3-4a45-b314-ad9086d83d26', '212c5286-05f4-47aa-8c00-ed7968551e08', 16.00, 10.00),
	('aff59093-034a-4fb1-8725-3b855048c4d0', '50516989-1011-4b8c-bde9-9ed0750f4a07', '21d76d26-8608-47b8-b387-1e9f5b150715', 35.00, 9.15),
	('b106844f-0772-46d8-973d-88c288d75c78', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', '21d76d26-8608-47b8-b387-1e9f5b150715', 95.90, 21.37),
	('b20da042-5168-4b20-a3ba-9e4f615a015b', '5a98547e-4cca-4a74-bc73-6822c3b8d069', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 17.00, 4.54),
	('b2fdb9b4-3c1a-45f9-a0c1-389750d29f7a', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', '212c5286-05f4-47aa-8c00-ed7968551e08', 38.30, 9.96),
	('b3c72e81-1bf1-4fe4-a506-dd703e23738c', '93ea5ac0-5b1f-42ce-9289-478820d9108d', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 34.00, 11.33),
	('b3f57033-787b-40dc-b147-9a628880377e', '93ea5ac0-5b1f-42ce-9289-478820d9108d', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 34.00, 11.33),
	('b41c75ce-05b8-476a-88e0-63d21d1491be', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', '212c5286-05f4-47aa-8c00-ed7968551e08', 32.00, 9.97),
	('b468ec3d-92c3-404a-ba24-5a06221056b7', '64142b67-ba38-41fe-8e46-68213b65a342', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 36.00, 12.15),
	('b535a99f-3d10-40f2-b49a-e55bc9dae089', '25b30ac0-81b5-46bd-b3ad-876b48a78251', '212c5286-05f4-47aa-8c00-ed7968551e08', 45.00, 16.02),
	('b594901c-c4a9-444b-9306-a4c7f79f50be', '63841581-68f3-4cfa-bc81-c78466e5ec5b', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 67.80, 14.17),
	('b5c0180c-c929-4032-86b7-13db2ed20c1e', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '415454fb-f2a6-4265-95d9-15fd0143cc1b', 43.00, 11.69),
	('b5f83b2e-6d79-4b87-9e7d-6c816968f9c1', '5a98547e-4cca-4a74-bc73-6822c3b8d069', '212c5286-05f4-47aa-8c00-ed7968551e08', 17.00, 4.54),
	('b6c0ea8b-8797-4b4a-a06a-24f4e6a7b6e2', '71b73436-5512-4ba4-9719-541b70aec6e0', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 23.50, 9.19),
	('b771554e-326c-4d3a-baee-7e79ae55c71f', 'dbdba3e8-488c-4eca-b84c-108ba9de45ba', '212c5286-05f4-47aa-8c00-ed7968551e08', 10.00, 8.00),
	('b78a91e6-68ed-4410-b1bf-399e9684f272', 'f6777e04-f0b8-442f-ac33-ae1af4752932', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 6.00, 3.20),
	('b7eb43fd-efbe-4780-8d6d-450168d641ae', '4014c744-53bc-4148-8fcf-0799918e88aa', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 34.00, 12.81),
	('b91054e3-0511-4e59-8934-6ceb23b7f1e5', '60a58561-6800-44b4-8074-d70d035bb1a2', '17b14f91-68d9-4a94-9374-c64846414581', 39.55, 13.67),
	('bb4ac72f-134c-4bbb-87a2-ade616961801', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 43.00, 11.69),
	('bd0fd808-c5cf-4a80-ba81-b0b74160abb9', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 36.00, 9.68),
	('bd7bfdf3-ac92-4db2-b0df-26aef9cd698d', '3338daa5-5f14-4236-92b6-1cee71c509b2', '21d76d26-8608-47b8-b387-1e9f5b150715', 45.00, 10.63),
	('bd9b4e49-5a29-4a6e-9513-f4541624461c', '93ea5ac0-5b1f-42ce-9289-478820d9108d', '17b14f91-68d9-4a94-9374-c64846414581', 34.00, 11.33),
	('be49b0d6-4a18-4235-b16c-ee60d9851d47', 'bf6331a3-74f5-44bb-8b82-635a399c4878', '21d76d26-8608-47b8-b387-1e9f5b150715', 50.00, 9.00),
	('bfefeb46-3626-429b-9127-ed648cc25364', '8e155a9a-175c-4fb8-890e-97409b2953c8', '212c5286-05f4-47aa-8c00-ed7968551e08', 67.80, 14.11),
	('c03267d0-0319-4cec-b205-4bf0b287e552', '8581a904-a689-4535-8ffd-0faef973e9a1', '21d76d26-8608-47b8-b387-1e9f5b150715', 24.90, 7.50),
	('c23bfee0-0dbf-4fae-af9d-9ee85c95c48a', '7fa58aa9-40e3-4a45-b314-ad9086d83d26', '17b14f91-68d9-4a94-9374-c64846414581', 16.00, 10.00),
	('c2a38cd3-1b64-4352-bad2-0ee6fbd6d6fe', 'e2582ee2-3930-41e3-89b4-fc0a517ad88e', '21d76d26-8608-47b8-b387-1e9f5b150715', 22.90, 6.06),
	('c3aefa9d-cbb4-48a4-831f-e0df0a007fad', 'e5708074-2b1a-41f3-a9fe-a3a954ecc8e1', '17b14f91-68d9-4a94-9374-c64846414581', 16.00, 10.00),
	('c3dc716d-14be-4b4b-9b8a-620fe30e4c0e', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 38.30, 12.18),
	('c43b268d-bc70-4630-9b1a-0b0bab52e8df', '400ed17e-5cf0-4a76-ac12-8c3ca074103c', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 39.50, 12.45),
	('c526a4f5-22b7-44d7-83e3-1c17f4035b70', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', '17b14f91-68d9-4a94-9374-c64846414581', 50.85, 16.93),
	('c52e77e7-b240-45c3-b80e-4e2f7c81d3a4', 'ee5b570a-759c-42aa-929b-efb390436f1a', '17b14f91-68d9-4a94-9374-c64846414581', 38.30, 11.61),
	('c5341e3b-4c77-4afb-b364-62f3fc2050c2', '71b73436-5512-4ba4-9719-541b70aec6e0', '17b14f91-68d9-4a94-9374-c64846414581', 23.50, 9.19),
	('c5bc1999-10fd-4bd4-9e84-cc0530e8ab6e', 'bf6331a3-74f5-44bb-8b82-635a399c4878', '17b14f91-68d9-4a94-9374-c64846414581', 50.00, 9.00),
	('c66b2bd5-5afa-46b4-a6be-dac4c9ba63d8', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', '21d76d26-8608-47b8-b387-1e9f5b150715', 38.00, 7.47),
	('c8a3e11b-ba20-4da1-9f4a-0553eb14b8e8', 'f8f7cef0-be70-4335-99e0-53dd3ad00b45', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 32.00, 9.97),
	('c8cdb088-fc48-4f61-ae56-3e12f03d18b9', '717f21cc-de1d-4881-942a-4601e8bf45f0', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 41.70, 12.58),
	('c8e54e73-4729-4ba8-9a69-f04c4532a44e', '63841581-68f3-4cfa-bc81-c78466e5ec5b', '21d76d26-8608-47b8-b387-1e9f5b150715', 71.90, 14.17),
	('c97bb014-590d-498b-8c2e-cd0230ea2f3d', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 50.85, 16.93),
	('c9828324-b00e-4a1d-b21b-ddd328a0f1e8', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 36.00, 7.47),
	('ca95f221-f2c1-4389-8982-c703d55415cb', '25b30ac0-81b5-46bd-b3ad-876b48a78251', '21d76d26-8608-47b8-b387-1e9f5b150715', 45.00, 16.02),
	('caf6b884-8037-4e24-bff4-c4373a42caf1', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '17b14f91-68d9-4a94-9374-c64846414581', 43.00, 11.69),
	('ccbc5352-d25f-434d-ba42-aaf0f8e82c10', 'e9243992-5df7-4cfc-82cd-b8ee1d02e69f', '17b14f91-68d9-4a94-9374-c64846414581', 36.00, 7.47),
	('ccc6e0ef-3105-436b-8d66-3917a19d47ca', '5c9f187f-de24-4615-9042-78e1773e904b', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 50.85, 14.16),
	('cd3fc252-3df2-4f29-829a-d233bdf9346b', '5a98547e-4cca-4a74-bc73-6822c3b8d069', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 17.00, 4.54),
	('cee5db8a-b6d8-403e-8be9-001299120d6b', '4436ddb0-689e-4b7e-954a-faa1999288a7', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 36.00, 12.07),
	('cfaec2a3-46fa-44e4-ac16-d62d8db84d8d', '43087961-297c-4b43-8ddd-1484188baab2', '17b14f91-68d9-4a94-9374-c64846414581', 31.00, 9.37),
	('d03910a4-6999-436f-b648-eb1c4d9a9705', 'd96d6d4d-a32d-461f-ad10-d6bac52fc729', '212c5286-05f4-47aa-8c00-ed7968551e08', 41.70, 12.79),
	('d0fa28dc-adea-4a1e-be7e-0f2a357084cb', '5fb6f8d6-49ed-4587-be09-333b67419ac0', '212c5286-05f4-47aa-8c00-ed7968551e08', 45.00, 16.48),
	('d18c8e77-5558-424d-bc1b-0d0ef16309c4', '717f21cc-de1d-4881-942a-4601e8bf45f0', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 41.70, 12.58),
	('d2fd2478-c887-4da0-bb9c-5ce724e86e1c', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', '17b14f91-68d9-4a94-9374-c64846414581', 28.25, 11.11),
	('d3205b89-4547-4de8-8729-3430ec9c28eb', '8581a904-a689-4535-8ffd-0faef973e9a1', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 23.50, 7.50),
	('d56d0fea-5bf6-4293-b199-f2697cb78133', '86519e93-90e6-4174-b509-136cf9f43430', '212c5286-05f4-47aa-8c00-ed7968551e08', 22.60, 6.36),
	('d59ef051-717f-4787-b191-aaa2a66f789d', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 50.85, 26.18),
	('d5b99daf-f3c6-48f3-ae78-96b588f04b3d', '59fc09ea-7730-40ef-b700-6388068e3ec8', '21d76d26-8608-47b8-b387-1e9f5b150715', 24.90, 9.13),
	('d5cdfb96-f265-4663-b900-c9bba485bc2c', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 28.25, 10.71),
	('d6903bbe-5ab3-404e-84ac-6ce8cd1494df', '13d9f0c0-5fe6-41ee-8b62-fc3ca16a35f2', '212c5286-05f4-47aa-8c00-ed7968551e08', 43.00, 11.69),
	('d6ad367a-50c4-4c23-83d4-477e1ad1a598', '5f5533e0-5760-4edd-a22d-9122097da388', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 38.30, 9.73),
	('d9322e2e-4429-4e6a-98c1-3c2389e6da30', '43087961-297c-4b43-8ddd-1484188baab2', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 31.00, 9.37),
	('da081600-dd64-4b5c-82d8-2536a4dcb6e8', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', '212c5286-05f4-47aa-8c00-ed7968551e08', 50.85, 16.93),
	('dc258a7f-bec2-40e3-8b4e-2ec05260d52b', '5c9f187f-de24-4615-9042-78e1773e904b', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 50.85, 14.16),
	('dcbcc3ba-9e47-4dba-bdf0-8c57c184971f', '3338daa5-5f14-4236-92b6-1cee71c509b2', '17b14f91-68d9-4a94-9374-c64846414581', 41.70, 10.63),
	('deeb7a4e-4eef-441b-a23d-b93feddb041f', '3338daa5-5f14-4236-92b6-1cee71c509b2', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 41.70, 10.63),
	('df01c3ac-8f3f-4278-98b5-4aa642639ad0', '4014c744-53bc-4148-8fcf-0799918e88aa', '212c5286-05f4-47aa-8c00-ed7968551e08', 34.00, 12.81),
	('e012032f-24ae-4677-a20b-80f36acd263a', '86519e93-90e6-4174-b509-136cf9f43430', '21d76d26-8608-47b8-b387-1e9f5b150715', 23.99, 6.36),
	('e2db535d-e80f-4dac-b176-468eeee3caeb', 'c5d1d013-4b5d-4006-892b-d41292f3a1f7', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 39.55, 13.27),
	('e4b0f3f8-4968-44f9-8ecb-622a7f6bceb5', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 6.00, 3.20),
	('e4d55def-4fe9-4698-88e7-d642ed5032c4', 'dbdba3e8-488c-4eca-b84c-108ba9de45ba', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 10.00, 8.00),
	('e4e3dd5f-4a8f-4c8c-b21f-8af456a2583c', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 50.85, 26.18),
	('e584f864-7762-46d9-ab2a-f349f743dd80', 'dbdba3e8-488c-4eca-b84c-108ba9de45ba', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 10.00, 8.00),
	('e5b6d3c6-510e-4cf8-9f04-980b6c686a7c', 'd0bb7b9e-1857-446c-9e61-48e7c23f51e2', '212c5286-05f4-47aa-8c00-ed7968551e08', 50.85, 26.18),
	('e5ef1236-737c-482d-a700-0e913f8009e5', 'c5a83fe3-5587-42ea-a160-c16f3b83d2d8', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 67.80, 12.64),
	('e67ff5ab-6d66-4d7f-b0d7-59309d2a4a37', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 38.30, 12.18),
	('e6fd58cb-b5fc-4635-9c00-22a304b9cec3', '2b54201e-9524-4e52-9615-53eef6fae6f6', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 39.00, 12.29),
	('e9e81758-54bc-4cdd-ba27-a1fc179bd20e', '64142b67-ba38-41fe-8e46-68213b65a342', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 36.00, 12.15),
	('ea8bddd6-e182-4f0b-889f-26a42068f29d', '8581a904-a689-4535-8ffd-0faef973e9a1', '212c5286-05f4-47aa-8c00-ed7968551e08', 23.50, 7.50),
	('ea8fe295-cd2e-475c-ad07-ef591d88552d', '65226aff-26be-4bbe-9222-62cd159ba207', '17b14f91-68d9-4a94-9374-c64846414581', 39.40, 9.96),
	('eb67aae2-d2f0-4e1b-954e-34f55ca29b9c', 'fb1ad5ae-9041-4688-accc-2745ff3b8550', '17b14f91-68d9-4a94-9374-c64846414581', 10.00, 8.00),
	('ec063e2f-ad01-4054-a677-1770fc32f3c6', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', '212c5286-05f4-47aa-8c00-ed7968551e08', 21.50, 8.73),
	('ec1f29dd-620a-49b9-a3b6-92dd81117713', '65226aff-26be-4bbe-9222-62cd159ba207', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 39.40, 9.96),
	('ec3f42f0-2a53-445e-a2ea-6e4114d9897e', '3c8204c5-6801-49bb-9fec-5ecc6fbb26db', '21d76d26-8608-47b8-b387-1e9f5b150715', 40.90, 12.18),
	('eccebd0e-5a92-423c-9ac2-78b6f98cc7cb', 'd44c0f41-cdf3-428b-bb6d-8e960a22529d', '21d76d26-8608-47b8-b387-1e9f5b150715', 29.90, 10.71),
	('eee95358-fc18-468e-8160-9acaf2e26329', '69f282b2-c2b1-4e69-8cf0-236a3cc55c5b', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 28.25, 11.11),
	('f0a56f29-0d84-4578-9ea9-fdcf3771b8bb', 'fb1ad5ae-9041-4688-accc-2745ff3b8550', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 10.00, 8.00),
	('f152e6ab-aa62-4e67-baea-4fd426374de1', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 21.50, 8.73),
	('f26cab93-3327-4253-ae5d-512af13bfcfe', 'ee5b570a-759c-42aa-929b-efb390436f1a', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 38.30, 11.61),
	('f2c6b367-4475-4d96-bea2-8091b465485f', '5a98547e-4cca-4a74-bc73-6822c3b8d069', '49db43bc-75cc-49e6-a4f2-4cbab36c7e71', 17.00, 4.54),
	('f2ce261c-d906-48e1-9b72-9bfe73c700a4', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', '21d76d26-8608-47b8-b387-1e9f5b150715', 7.50, 3.20),
	('f325fe4c-6fc9-42b5-ba5c-dfad9e9293c5', 'b8cfab2c-856b-40b0-870b-a36cfe11ef96', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 36.00, 9.68),
	('f478c421-3d69-49c0-b20f-119690b22e49', 'bf6331a3-74f5-44bb-8b82-635a399c4878', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 50.00, 9.00),
	('f54644fc-f0b8-44fc-b0b9-f051975b8538', 'f4bc7c7f-14c6-42af-ad10-ea3740840d94', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 21.50, 8.73),
	('f634a8f0-2102-4a06-adcb-b689de4eb991', '717f21cc-de1d-4881-942a-4601e8bf45f0', '212c5286-05f4-47aa-8c00-ed7968551e08', 41.70, 12.58);
INSERT INTO public.produto_precos (id, produto_id, forma_pagamento_id, preco, custo) VALUES
	('f802d65e-a373-47f4-9f5b-d4dbce4dfa23', '76ec1153-89e4-46e4-9c3d-a953e37e6f92', '21d76d26-8608-47b8-b387-1e9f5b150715', 54.90, 16.93),
	('f85c4b48-9369-420d-8cef-143a769b3edd', '50516989-1011-4b8c-bde9-9ed0750f4a07', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 33.00, 9.15),
	('f897b0e7-5e78-44e0-9860-51182e2276ea', 'ee5b570a-759c-42aa-929b-efb390436f1a', '212c5286-05f4-47aa-8c00-ed7968551e08', 38.30, 11.61),
	('f933f5d5-8927-4763-833e-647f591d13f2', 'dca3fa98-20e5-487f-a479-5920c7783cab', '17b14f91-68d9-4a94-9374-c64846414581', 31.65, 12.31),
	('fa1c5025-c290-4be3-b26f-4c8140bd7f5c', 'dbdba3e8-488c-4eca-b84c-108ba9de45ba', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 10.00, 8.00),
	('fa6e56ee-3e2a-4031-b23d-98af421da479', 'a5bf9dcb-7066-4b50-acd4-04f560e5eb3b', '17b14f91-68d9-4a94-9374-c64846414581', 90.00, 21.37),
	('fb1447c6-6719-4530-a448-e6a8b5e4882f', 'dca3fa98-20e5-487f-a479-5920c7783cab', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 31.65, 12.31),
	('fb1e9601-e639-4669-b001-175c2a988c21', 'f6777e04-f0b8-442f-ac33-ae1af4752932', '21d76d26-8608-47b8-b387-1e9f5b150715', 7.50, 3.20),
	('fcaf89b6-89b0-45ca-ac85-b858ac7715fa', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 38.30, 9.96),
	('fcc0f316-ebbe-46d0-b9fe-95839a7ddd35', 'fb925849-fdb1-45d4-8e7f-8a3b57084595', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 6.00, 3.20),
	('fcc8a22e-9d97-4ff1-b1f6-d0bdc6c41d78', '71b73436-5512-4ba4-9719-541b70aec6e0', 'd0e73585-ca32-43f7-8051-8469cc6034ba', 23.50, 9.19),
	('fde84c7e-a3df-4ba2-a056-bd83b3b90b8b', '5c9f187f-de24-4615-9042-78e1773e904b', '21d76d26-8608-47b8-b387-1e9f5b150715', 54.90, 14.16),
	('fdec8450-4775-40c0-9929-f51955b9bdec', '5f5533e0-5760-4edd-a22d-9122097da388', '17b14f91-68d9-4a94-9374-c64846414581', 38.30, 9.73),
	('ff98a3ec-2754-4ab1-b30a-6a3c06f73b66', '9288b06c-ad35-4e4b-99d1-845cd2fd8b72', '19f2f926-8a9e-41a7-ba5f-2280b672950e', 38.30, 9.96);


--
-- Data for Name: promocoes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.promocoes (id, nome, tipo, regra_duplicidade, beneficio, ativa) VALUES
	('4238e8ee-8978-42e6-8655-12e4be0f5652', 'Indicação de amigos', 'Indicação', 'O indicado só pode aparecer uma vez', '1 batata pequena para quem indicou', true),
	('9407cd22-4c89-46c0-9990-1351c9650b49', 'Cartão Fidelidade', 'Fidelidade (carimbos)', 'Soma marca a cada venda com cliente associado', '1 porção de batata frita a cada 10 marcas', true),
	('c502d56e-b484-4acf-86a3-774c04944f83', 'Cartão Fidelidade', 'Fidelidade (carimbos)', 'Soma marca a cada venda com cliente associado', '1 porção de batata frita a cada 10 marcas', true),
	('d5c80a36-e534-4a2b-b1b6-7110b8f6c063', 'Indicação de amigos', 'Indicação', 'O indicado só pode aparecer uma vez', '1 batata pequena para quem indicou', true);


--
-- Data for Name: push_clientes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.push_clientes (id, endpoint, p256dh, auth, criado_em, usado_em, ultimo_envio_em, falhas) VALUES
	('00d4ac0c-d862-49a7-bd8e-b2894cc987b9', 'https://fcm.googleapis.com/fcm/send/dhJARyPYpNo:APA91bFaiCzz-tVaSEEMq27vbwoVUh81e6UwgqhVPN5Ri_82AV0875Enby2xMKKy_UF6KnCvtj2xsj6FWh-KCOP5nArqsI0lYcZ60P-BzdbriBH6VgET7oEd5PmCudJM0JvryUvCFXZg', 'BGGLE-8fjBDO7X9Yk9Ezw8ntqLklsnZFP6YLA7jUMWIxHi7MyrmIbaBP-rK5aNO5x7HYOOKyfPV95BZy58Oryrg', 'Pyhh0Bzvx1duczNweQ9C_Q', '2026-10-12 00:56:10.581252+00', '2026-10-12 01:48:29.938239+00', NULL, 0),
	('02a90b90-44d3-4ff5-8850-777a8e2ce835', 'https://wns2-bl2p.notify.windows.com/w/?token=BQYAAABTgTBqhw0YSNUhgwv7KrBff8W6UOhlEqb4t2xP5sTRALED3pSlQEtkWMeeTAhCoVXYezoDkn%2frfuCb9oJtVbeS5%2bp8QHMrTsDcmUAZz97CAKecQnNau0fz7aTWqY36c%2fonkpQxRZTdeDE5P5AXLJDywqmgqdM7bU7luwnRzUAwQ5rc8HOR5KGyQaZQyeMm6JQIzi2ZRYZm3snNFSuvfbzaWxm9Yf56Dt4YkHb15IoLY71GS3vIcDtZ%2buHX%2bFQ5g4ZKgCHGWetit2cKhh9yakYD9TXnFdXA6GiRHf79VjDmaPt%2b%2b1IaNXaw9lQW6%2fT73vl9fvfCohUDduyGeKvyCbJE', 'BBuC9KMqd0TgM93RG2Pt6koarB4RTqT3mKMOXih9LitIqSUrCTJu5Lo1ZFxpPsao1GvBrZiv4P19dHUrymV7Z00', 'TX1pANk5D5U1IT8SDJo2Rw', '2026-10-12 13:52:37.405426+00', '2026-10-12 13:52:37.405426+00', NULL, 0),
	('09e6aad0-d32a-4bfd-8cad-dc5e432672eb', 'https://fcm.googleapis.com/fcm/send/fIYKRwnzKfI:APA91bHx3-rLKa7dirMCAreChXKSRHKE6pBmdXASosq1nOToP41Y_Ytv9I8T8Aaeymo_rorNxXKoGCGlrmVXIP8ZQ8f23qOsXJLXRPQOL6Dj_zH6ffw3e2GY2wXH7Xm9cIRc1vtreuGc', 'BJu2dkFBqLWluEDezeM3aQIb04FGTUUE9cNMpZRbXEmak6pUxUI_2N_W-tKVf-8PBlIHuFNYTv5OnJ_eNQNPi_E', 'J7KNanQLDgXka5TS6bP65w', '2026-10-17 19:36:05.919632+00', '2026-10-17 19:36:05.919632+00', NULL, 0),
	('0a10197a-7978-4052-89df-ed11ca7be495', 'https://fcm.googleapis.com/fcm/send/cCIcvzaLN7o:APA91bGYYMxRRAxf1nKaf_2LnV2LLW9JDRkfAAvw0L1CufdDitsob-MhbDlWyd-8k1j8V9LmSPc0BXNY-CBc7uzHIrTSdFhUT2mtHuLpzdtTCiEjfVq_4Yben5PviCT0zl8iaDk9W17C', 'BGI-mUs4kGEBrCRNJgo19BXx1y5F0X41unG1bkFgRP-dwLzmIPFCGuFPWEKZjKzVjFyLhrHgoyJcj0B_Qq3nmrI', '6mFiSeYXHcuxhee2vSzrwg', '2026-10-11 09:10:56.73156+00', '2026-10-11 09:10:56.73156+00', NULL, 0),
	('0a121290-ab85-4250-ba29-4ba169fa448d', 'https://fcm.googleapis.com/fcm/send/drdCTMQ4Q7M:APA91bHazgnWcsrWmLiRbFBTBKgYtZYzpZpZiG72NmfgDZiRuCZO38y-wsTkT8YVRRJus6EfQuyfWI7bEN2kSpjWTw845Irpb7eMbmQQgu8mn3BOn7K2nwd0fvOcsJP3jMgqfCbNmmc4', 'BFSImI8QrmaOEK7zEPEwQlCSBzxg4CKy8PGhM8V42yexpPmUj4VNb_8Ub5AHZXrZ6noR_GCB5l7iUHVxX7ipTeQ', 'yQTiP9Rq25cZ0riwsPje1A', '2026-10-11 08:21:14.251237+00', '2026-10-11 08:56:51.808697+00', NULL, 0),
	('13b3ba39-f490-4fd0-9196-0fddc84ba254', 'https://fcm.googleapis.com/fcm/send/dC1ciFQsPLw:APA91bGFIiHmSfB9vIwWQbjtJi_a3m_-egWEm2AFcSth-1cC01e5HKgpmG8CEoTloYS12o6xxYSYkm6nYYsg7U9YmkIxKlQ8eVwaR-L6TYSwqyWjRDcYZvluCfwP1aYFwVgNjeyWkIpR', 'BEM4t9mdc1XBXykk1G7EAyYZ-MfGZak7ROGIilopxm5KYkZyxndHvz9-23Kivd1Ju09XeTkyKIAGSCfyc6PjtFw', 'aHWQFUnvDonfJ0zBhpJWLg', '2026-10-16 15:58:04.699521+00', '2026-10-16 15:58:04.699521+00', NULL, 0),
	('17b7e833-d05d-4926-8ce6-9cdf6f903209', 'https://wns2-bl2p.notify.windows.com/w/?token=BQYAAAA7jfKa9ckCjSW7nRz4S9e9nXGjPfEIUSZCdk1uUlWoiGGcfuYv2GXs4lAcRFrq6BReuObWcmVwVrH3iuT0fJjK6WF6HVHY%2fFgl0a3rgpEpDUM7reT%2fQb00ms04u0PaaB3ejZi2bwYuKDS4WdbKVg4j8mdLalZTokhcJW2uZrjyM6jzbXdrduIENV9na5buQOn%2beb3Zk9JfMb1lt89Fy8p4Zd%2fFqkejHIIlHbtqSXXgN4HQO83uBQ5xx%2f8Y1d4WqafC657lIg1AX85m8QlnZR20HMPQL5ln1rMZHlx5Ue%2bThcrP5%2fvESOB7cFm8iSwDlmaqxAmMMvEkskT7ZDqB0eZI', 'BGNJjJ_aaFdaZxTnuQc24iIbBMipAGWA6WhtDCVrfzjkQKy4QE8_xicSNPPPr42lDTzLccETW4xc7QUDWeU6mJs', 'kug9jhc2t4TlCufPjMRVEg', '2026-10-11 00:30:09.901201+00', '2026-10-12 13:51:37.965417+00', NULL, 0),
	('23a3b6b5-126a-4a81-b9f2-9b84618b9ebf', 'https://fcm.googleapis.com/fcm/send/eaK3O6PvFJ4:APA91bHUOviYy8hRtGs84vl0OvsYT18O4mPttA1y5ZdPLIQK7Ulyiv5rOiiy3fk-W3Dt5OESvWInyHxdslLbeELxEhknImQpEB35CpckFrk_kQf-r79of5QLthqr4kHyeYN1wsGCQoYz', 'BNwBFG-GmfxYrZeRESBZLavZxSHargxkjjWcBd-wOG16qzbwI7XopUn9CKbAmsijU1b_O-ThmTJRLXLX6He-nNQ', 'YUIVPSAZ0cQi0Gd7alTlXQ', '2026-10-12 13:59:21.118235+00', '2026-10-12 14:44:50.924941+00', NULL, 0),
	('24e0d553-bebc-433a-a7ea-ae291e6ffd03', 'https://fcm.googleapis.com/fcm/send/c62PrHuSHv4:APA91bGY5N_JGXBxcqNPddixnOUw2G0P8nQvPDNIdZBf-WjWUAEzIGLvWWX2Tgm45T4IdQGLzRFCaHtCv_Y0IHjnyABcfL7bOWZX5qOEZaz38vaMOCxnW7DBPZlUi0h4nfL8e2ErdDLS', 'BII7pMh8bf77rYvNe-jgKGsg-ZChoTpwkqhYNAsnlfpI8vG92ArnjoGlr9qguvURB3JVp_kksYjGdPj8HgOOWfY', 'ICqAltqbOf2_5uJ0csK7tQ', '2026-10-17 11:08:32.11679+00', '2026-10-17 11:52:10.6729+00', NULL, 0),
	('28827c39-a857-49b0-889b-c93ca77e4cae', 'https://fcm.googleapis.com/fcm/send/fBXmlQXa4LE:APA91bHTOsMbtMvIgAo0cHtrj4NynZOfsZczcsFxNM6VB_7ClyUme0I1Untk4zOxz0BK6NyVmedmo9ycrg7XiKCvLt5OEAyI0sZSNHDI1iVe2hFUHAiocrGEmaXpVt7XODZqPxcNJKf1', 'BMJ-ns8qndFk5MH0gRVkzBWZCpZJOc5heWzR9B4ajJAFRXWaOSLjhaatlgt77IwIukFL6UWNVYsbsS3dM4hNLA0', 'aL-hKrKYmvKK_Y-UT6A9Og', '2026-10-17 00:32:31.690355+00', '2026-10-17 01:42:21.312383+00', NULL, 0),
	('2d4033db-b40d-4a60-af3d-84a09aedd38e', 'https://fcm.googleapis.com/fcm/send/eiFElJOnsdE:APA91bHnKxDWH0ohdu3NCoG5QX1pp3Zs5cVNv3z-duSXNjemWt3jnII9KuNtB9_d4o_f3-LKw1mDobSx2jX7iqQyo8b7yAEBCfWWneDJTCJq_NGkioDyMCO0BJxZSNeGK1ksCOLacPef', 'BFlu6QM5yuYN-OZYw7sXDt3p5iSuBlYael56oGJiSiTuL5WEUh-aCJTcLK9CHxiY4ZEeyesi0_I1lNidirSHFy4', '2fJnSf-ZejwPysbmIvPhvA', '2026-10-12 01:58:37.931478+00', '2026-10-12 01:58:37.931478+00', NULL, 0),
	('2f16ab0a-72e8-4688-9a73-026a102d3523', 'https://fcm.googleapis.com/fcm/send/dBoEQiYvLHs:APA91bFOqwZ3Ap-GOKRCdKznL0iyWNdse8vDxMkVuCIG1HUZhAYZW2MCuS1yqp2-SIbcqFRMGaxWFhW7GL-LaxGBJk5UwDu3OTMZJ10GcNfo9k-jnTKb-ZCZcZzgNCPbzsq9Cimc_4Qi', 'BLyL9fou8n1AK-GwteRJq4vCul0BtaXogT6SEFbY6hDGK6MpiBkpn924xVqZnC5A_X8XIjFwFASedS-aXq3C_EA', 'FdFNJtnsnXwQDqDePQLE4A', '2026-10-11 14:15:02.207377+00', '2026-10-11 14:39:41.889758+00', NULL, 0),
	('301a6dc6-a14a-42d1-b482-6dcff31e25e6', 'https://fcm.googleapis.com/fcm/send/dF5yUgoBmMo:APA91bFGqCXaJaqZZJaDOg_URzv3GQPLnM8pIqGb3IHprNP2yuVMghij24DuKFlfUjVFRrzcMEgh2PRHMQklYYqkBmveS_tICB3xVcY3RNPV5vCDnLNfwTSizMGzVa3A9qRNKIWaZHQc', 'BBbI78WGtf_1iUTRE1FNy78z09GUDcc7tgXZy18ugs-gkVgOO70onNiCOZYec_CzvT3ffxq121lBq88ic1iAayM', 'miw1m7qCW3QrRFt2AI76mQ', '2026-10-15 00:38:44.875413+00', '2026-10-15 01:03:59.570062+00', NULL, 0),
	('33d19218-37e4-486f-bf35-498f6539d346', 'https://fcm.googleapis.com/fcm/send/cpfPAmSv-6k:APA91bEmA9s6XpodTUkJ4FxGH53iJUbn8xHajHHCvvRaedTfGsM2ZKeGx0o2PYsea9xt26xE7DCKN4P9MZxBeYrBZEns6NXwWG04Cu00q9jnPinadTxkedB7cqb3nUfxU0luAqBWc0t-', 'BFgLoa2Vlca2Fa-KSbiRhrhaXi75Hrygs02EoIXIAvncnNAKtCVVBvhY3s906wvGxi44phx3l7nO8YUCWjmYHVc', '9oUejC2ElA-IRrOAud3EZQ', '2026-10-17 19:56:22.278055+00', '2026-10-17 21:45:06.869605+00', NULL, 0),
	('3686d33b-04fc-4f20-8e43-d4c7181c24e7', 'https://fcm.googleapis.com/fcm/send/cZUWgx4nFq0:APA91bH7C_mbsnVSMnnAJ04ewxy0xC1ta69c7z2dq6nOi929wqGnl3cjdY8i6N2MuYrRSCA9N2YDtWgP2iReR73yvmsh45bzExq-PJt8y1lC0auHLRd_iUOUuKRopvbp2jkO7mAQTFk6', 'BLWHzpUepaDhMvuwKVRij7JfLcuLekKSVZN0RJJ0Kby5ArnPvAnSr-Y3NUsNz2aR1zwRpBeIZJ4rqERd46beSP4', '5XZSeDXjwWfcZgs5w94Aow', '2026-10-11 23:26:53.40557+00', '2026-10-11 23:26:53.40557+00', NULL, 0),
	('38436b07-71f6-4f73-a346-f65e4af523a7', 'https://fcm.googleapis.com/fcm/send/dN_2Au3CawI:APA91bGCfeqYN5JVx493zSy9sk3avYj6sfYl_IPeKk9Np3cU9HpE7guDlCtorD5YxK5ofbhpcFG-TIez-v8JVguCNZhWXQbrgqHpsP18j9Klw1mi6wl2er49JshW4MQM6CY-0dMP4ryu', 'BPZ55gXav4dReRkzuRDiboN6A0nUupAOTf46b3Dk0h513M7rJw7hoVQCIlnYsNowGgqm5IJv9dC72tUgJz3xrYM', 'Auztw5Hw4L-eOV7WJzOQbQ', '2026-10-11 06:35:09.027393+00', '2026-10-11 06:35:09.027393+00', NULL, 0),
	('3896ef58-af2a-4fcd-8e1a-e7faf7589852', 'https://fcm.googleapis.com/fcm/send/eDkW6-FdhPk:APA91bHHnip9xFCN3R5QLKv_VURvZsCqlzyW4zqWK0iWShVDZrSLUAMsdRHsDobMCh0-cRb0GIMp2w4sqZ1-ioBma1bUw-glifWL6CwWZvxEHzpVklP_UkqFb7wMEby_6H2ryox8xVUK', 'BAfaQNCQEaAFvE9yWkSeIya23czcoIvCCYogqjzl6jKDSeLa6ptmEW68nI5MJ46cieS718f5awNDtfJPGHZ4hFw', '7aFj0EnPFsmEHSbFYYEZaA', '2026-10-12 09:38:46.031344+00', '2026-10-12 13:07:39.710813+00', NULL, 0),
	('4014a8f7-ae3a-4ce3-91e9-1d0f57f4c538', 'https://fcm.googleapis.com/fcm/send/ffhZtDXxClg:APA91bEZaaS5NBagbpTGquazC_wiSqGkAtqCF8Wz-VM58AXhNXhBYGp67M2kS9NV-mpFbFFB9Ww2tqk64eBN6TAZKg44n8KuF0tF219rEzwHgjxdZIi0BR6o-FPBQORFu8bjC3ohu85o', 'BBLu1mRI_i5Zl782A9bobzEgjeM99B8sNRK2vtK5VchTNhMg-hwvGTxaeRJEiG7R_2YC2Hj7qhIVrqC5G7lHEsU', '4iEyEZfPeI87rzsjx6DrRQ', '2026-10-17 00:08:46.386417+00', '2026-10-17 00:08:46.386417+00', NULL, 0),
	('43dc8b77-baa6-48d4-becc-4d94a563ccec', 'https://fcm.googleapis.com/fcm/send/fMqTV1st8uw:APA91bEM3OvucrHCt00RjYQygSqUd5ZXN2DeGtI8G2MHrrPFC34y74SnML3PQmxWl6xhwv2KNogCyxj7RYFPEc_bKKxAhspoPjp9rD19gzOSY97l86zVEmRT9xZw58R33-Y3U7lm8hPV', 'BM9AgCuN3HtpbLLN4l3nqO8SXJVUR4E-1LeADBfZ03MfTlgitYCtkBCjRBL8JME-R9HPtv0h5zIwmsNLUDUq42c', 'e86ldmQKCGyWJREuPoeoTg', '2026-10-12 02:57:15.805477+00', '2026-10-12 02:57:15.805477+00', NULL, 0),
	('57aef0e4-8463-4bcc-aca8-5955b6a5c90b', 'https://fcm.googleapis.com/fcm/send/eDowkio0YUc:APA91bHa1pD44mpMS4K8Qs9HzuRaaOVbyyRDhQKgw7unN4AyNia9H6fuav8nsjxFmFiUIP1p7ZiC3LJWbvaWPDNeqbpYDp2zlE6BzzKiKDX8Ug84GHb6sG3rLHairIbBGNkU9UxGW4XC', 'BOW2ZFUGMhYx2rGKPlF_N4dXssxRK7TuqYAV8ITlriAtu6ysmmMu7zYU_qEn3bi6HKwUzYsYZ2jzTKXz5h9TZ_M', 'kQj9862NyTmrBWoC_aOxLg', '2026-10-11 14:43:33.247139+00', '2026-10-11 14:43:33.247139+00', NULL, 0),
	('5e6d019e-f226-4663-a7ef-9c09c89b2730', 'https://fcm.googleapis.com/fcm/send/dHzEClFJAzw:APA91bE-rbxdxu4_pbrdjIijk4SXlvToD_OLJ8Ec_8nnKFJSqCid3KyYHues44ZuPpQfUR9wYcMgJul3Va3wshpE6M3fyBVsPwiqFQMvpw4mAAfKvtoyzKpNHtZ8bFtYX_7loIInWS7E', 'BMRMQLNAVCr1-cm1fEbyLA8fJiCF4mIyyBFENS9qs380YYRnsatQNqCEI85RzE07OKJOdtY4UalkEp6W5EpFlvg', 'ai8cPXz27KgQ9TnvytkA6g', '2026-10-12 02:41:28.425127+00', '2026-10-15 01:21:21.145636+00', '2026-10-15 23:50:05.816+00', 0),
	('61a2fe24-5855-4775-81fc-702c5a3e1f76', 'https://fcm.googleapis.com/fcm/send/fOnd8xvTXS0:APA91bHgToLbcKKyh7cELltUKfhCAkPMufFk2Iq6wCra9GzDz44A3S3Ta4EF-Vm6xiu5Gyia-_oEWAYez1qqU5pMMQK_XIPdPf3D9lYdp2LnGI2aX5w60wB2hwE5jN9hugG3bCLIUpgR', 'BJ2ODHt8-DQgWYoWkjilb7QEa4y4zJSP8013uV8WBT8om61QLnPvcg-HR5QOdRbu3UHQC0MeUjzn0erAUk-Ip6w', 'E8KmDEquorDjnOadisoYSA', '2026-10-14 23:53:20.739009+00', '2026-10-15 00:15:45.251115+00', NULL, 0),
	('64ecfe7a-d906-4164-86ba-6795940c25ba', 'https://fcm.googleapis.com/fcm/send/cUypXr9LrdQ:APA91bF2aGV30ObVKU68sOocvM14X3WiUUr_cj11EbUX8Wvtr96pCZBk7NoABo1Wow2HzgLYV1XcW0r8NK10Uc-cp3mSpGIpoKzSuHo4TNQWl1hCRIS51xX2p2jsc0i8Gpp--te3-U-e', 'BL9RIGamF2d2z1SDwjEG3aPghepgHabfRtYdlKqVU_uEDH8XEvam1u3torz5VEoGvH5GzH3PnKYId3-tm2OzBoU', 'PmT621edm9_3_yYIg2gfUw', '2026-10-11 11:02:00.473125+00', '2026-10-11 11:02:00.473125+00', NULL, 0),
	('660c1a56-d30e-4ae2-aa36-e1e8381f4973', 'https://fcm.googleapis.com/fcm/send/dpf5j5oOCCY:APA91bHo5zEZF8kj1F9slzmvggOjkwcsL7wtdIBjL7WqBjR7yrZPbiMQ5ZkdTFrCe1W-fK8VLMaR6xKU8-tvEns3Jlmag2FyEZwI3jqJ2FTdNdqBDT97VFeIiMxpui_G4lWWYmlXnoOz', 'BLG3ERAHURPn-vW0AJLXYeA01xZU7yonxK0d7rVKHAf6Iv7YGKO7nanbq3w_jif9L77SSzKF9kb4wkEcBT15OCM', 'eBXGHhFe92Qa-mkHhls84w', '2026-10-15 01:14:52.145508+00', '2026-10-15 01:14:52.145508+00', NULL, 0),
	('6c76e320-a482-4c61-b8d8-5b45de25ad56', 'https://fcm.googleapis.com/fcm/send/d_d--jM9Knk:APA91bFE2KK6xDj09YTVwXOo8LOVPLLso4h_ILIjWwQws2b7aevJ9kL23RUvS2Tn5j4FNmx88Eo0kNGoGusfgDPmzfcM1TK8zkM8Oe_QmUXeuCmDkw3V5UpOZ8pGY_2KGhIPpexr8WsL', 'BKSdUBqz4i-PRBvEC9V2rRx0MF_oVJ61IbmoJqKz8dULQN0bWDZ4jbg5qgijdwBOEhmQk4Y7EijhZ2FpmOVq-3M', 'DEi867ayjcpaWA8_cTIzPg', '2026-10-11 09:47:09.573967+00', '2026-10-11 09:47:09.573967+00', NULL, 0),
	('6d11407e-7538-404a-bd7f-5b47f07cb8af', 'https://fcm.googleapis.com/fcm/send/fQNf9B4Dr-Q:APA91bGrgSzS65vgxf-jeqZkiTBVwTYPKpssW8KMIWxquON2EgnhsDjOsML_XbzgVRoZh5WegdUVQZ_F7xmDKYvyb5J20Chnd0VrsFZMeW1qa2zK4efdiztVm2QMqx2cRRbxTM5SyOUH', 'BCbSajfNGv061nVnqHoKAisvBadpR-lrjZc8r9vtjZpX9jCXXEjpM3ERMTRn6rbSEuR2EZR7r3B3ZKzxMxe72sI', 'pjWV3EayHKbI2OGoOOvvAg', '2026-10-11 16:37:41.02811+00', '2026-10-11 16:37:41.02811+00', NULL, 0),
	('6d35993a-2d45-40e3-b4bb-b874711914b3', 'https://fcm.googleapis.com/fcm/send/c9XJQBz0yEM:APA91bEBbQSOcn_KuqnNWTjOTObf21xBfgCcR3pamHBIdqoKhVjoPKltEhcFMo2Ki-S4zIhTr6jVXGp8vj1usvxAp5nHI5b9768kSXXnlU8nvMygRcJkokabeI8pEZpsORhIELUDeIqS', 'BJmzo-OyshE75J7j6A7lvREIJpqP8QijMC2U6ZSxlAbbGMAFNixhtZB1kBJ2qK06jXY5hu5VJOCO67APRHIRE00', 'rAy29voXAfQ7p57FRLzyeg', '2026-10-12 03:24:23.555885+00', '2026-10-12 09:35:58.065471+00', NULL, 0),
	('6f516247-6597-43bc-b865-259afc068428', 'https://fcm.googleapis.com/fcm/send/exNcl2J3WII:APA91bEbqTBhFesN8xofj-cfnJlQwDFiYLdzA15mEYtBSNn_p1NAWW2toKIeyVMd1J6MGZfjNWN7kSBZCAIWMjEt8ebhz_Mr_gX6UF0BJB5zmuJiK78Z2zrqVnAUQVemO3kyMJYNk2Y0', 'BBkGh-77UthGBrh6hZHs18s-Sano665myHSf5MBSavJqrbtLf2bednDUKz8mJbbLzWX-6h-PFYdb3WU7WyYIoWc', 'ClpahXZnJNEmzp9MVS2T8g', '2026-10-10 20:56:33.418549+00', '2026-10-10 20:56:33.418549+00', NULL, 0),
	('74b7b631-2103-49d6-902f-1bff5a313ecb', 'https://fcm.googleapis.com/fcm/send/fau8jj4FIVo:APA91bE_vk3qlaGGBd8wkNGsHcGES5uApUmp6s43t3lA3-I-F-lcVqGR9jVv6DlC_H20kNPmB0e4fY7WD9DCAvdYRLDU30AYGJzmyr45I5Xc2U5ooSz7res83OyUBmf1Liz5CbRUlSn7', 'BEQov1ug0Fd6qL-axqKzfFhpsZHaRiw78MwqqhP4o3wOmpS966-eZYi5SuDFGe2PRPTMEgmWeCESzJuPK78d9qQ', 'xv3ZhVneQWiIluRhwdORyg', '2026-10-12 03:03:35.052157+00', '2026-10-12 03:03:35.052157+00', NULL, 0),
	('753fd380-80ba-4af4-9a80-c1e460af7de8', 'https://fcm.googleapis.com/fcm/send/dmwOTkflFhs:APA91bGx-MFBe3pMpHHQ7ZAkX3LQnS06DaJyYbiCgJupVliYEd7iuVjhtNByJ3gcgyng0gVdjdQnLi0eAsHV9DVfoLbLtba1eUt1Ov6rLh_8n675Ep99qdAyDfGgcXBSpNH_ZVkJ9Z_B', 'BGq4Y39kX2gWcJE-54-VrG34PoADhO5XDuXNAitV7RmMNYMQX9LO3zAy50TuIRP-Z1HtuwvSeq2ab-rhpt6tQEU', 'BEzKWJ8uuZaqqOT-M9apkA', '2026-10-12 03:20:55.165037+00', '2026-10-12 03:20:55.165037+00', NULL, 0),
	('75fc2ba9-88f1-4949-a82b-f05a6298b94d', 'https://fcm.googleapis.com/fcm/send/fgN48BiDDAU:APA91bEvWFFdB_Ylv1kP4cljZ-oAX1Sr8Fpc-jo-ugqg--D9RMJ-SzXxXvRf0mfbg6eXybGOzrwPS2dlVsX8Xd41kDe8LwvC_vbAlPwkBrrToHOQPBW62DCNWPySp_tQlZ0K1Z_wAKed', 'BD_4pSjBs6Xsufy389pYlyZ0Y8vLtnrmS1qF4P8wolcjfHbuZcjB-u-0cxihpeEzlBj8PxwDOW8VZTmNMNu2jhE', 'kO7cD1qfScFw_yZNH_q9dQ', '2026-10-14 23:20:41.489222+00', '2026-10-14 23:20:47.313659+00', NULL, 0),
	('78ec367e-6ee1-4774-aad6-5c333c3c6a55', 'https://fcm.googleapis.com/fcm/send/dvGngGp5vOk:APA91bHROYZd3Zk1VByiDfrcv1aqDFlb7ZvhvzYlBAhZ5ELIPDwNx-N7UCpuXwD5W3OAymSZuuArIqGerr5gu6b2v09HHwc7AdcpSsqOUPzZm-_5A29MjeGGqi39EbpXYXTbbvyl7OxH', 'BP6PhmidvyvdsysrADZegjxHxeuxkgTLYdZbbSg-R2PXKK8RlQmOI3Ez1JwNEpW5237mwDgKdI50m9iJC0O01RU', 'aMeHBCZR6TwGdIlUq_llog', '2026-10-16 22:11:57.142866+00', '2026-10-16 22:11:57.142866+00', NULL, 0),
	('83fd0110-870f-4e2e-b0ec-830e9204202c', 'https://fcm.googleapis.com/fcm/send/flxXdsz9uWI:APA91bE5m6cn6Y1TssVkrGXkD7Rh27fDgHlGEaTYQV3BJw-ELlLo6DR6qvUDGQm8vlE7dRSJQmNSiRuovFo9Qj1-pICF3B4zKUkFtemn5GbdG9ryN4HwIyHyxMx8uNGH_DgXm2zSYyg9', 'BHA0JVypFvg0861wLQVwvEx7iSbgcu9t59UKlSjAzyouHiQn6YhSJvhdJXCHvvj-AYNRBFAkW_5AZrIdfxBNo5k', 'zqisS3TfHJCiWPmnvy2Pxw', '2026-10-15 22:58:05.928544+00', '2026-10-15 22:58:09.036216+00', NULL, 0),
	('8a3a9141-c788-4901-9cda-869a54211fa1', 'https://fcm.googleapis.com/fcm/send/euNATD_04ys:APA91bG40fbqJfBe3pwTueQoVUvS7sITRA34vq-AeYGjAqhBciZL1B_9d-oQRIltBhMGxQ7nXeETQZcYPbWr2AtqE4YQm552L3X4sBISFCyuepaWcnYrqf_IRwsqrD9DbeKkd4AKSBiv', 'BM0GxlFPoBCgwl_84feIkxhs6qcx_ss9rylX_u4TV_f_kTm4Yz1vf-9VGAZrCwYJ0ik5uzx-M7jzZSYL5ZksRzs', 'k9129BCI5nU9qKDaEcvhwQ', '2026-10-15 00:35:29.098569+00', '2026-10-15 00:35:29.098569+00', NULL, 0),
	('903afebc-5f89-4614-8388-30cb95a94201', 'https://fcm.googleapis.com/fcm/send/dVZ-aACre-8:APA91bHPPumG-j0uW28ELE439bOIe_LTJLfNflYxDTYUy0yQ6tlJCz6gEvy4b1vFOxwy45mV9WVuH6k8g8HiKOiDUfhKSb0zJStkvnlSOqKx7Uj-ryAVGMEObpxA1j99Yq2-SqDAUX74', 'BOeM83SjAaljFINBw5XzbvmuoFPKJR0NuVfOLuzQe7AN0EsGjVwcfaRhdwErHO1-CmnX4EApwN48CSsKPJyZZaE', 'uFdl8JyEJRSGLucLeguXBg', '2026-10-11 09:25:24.850708+00', '2026-10-11 09:25:24.850708+00', NULL, 0),
	('90471752-8379-48e6-ba72-d9eca93a0008', 'https://fcm.googleapis.com/fcm/send/eAE6397Fdn0:APA91bF-AcTV92p9NLAs2l8Msvqm6oMfmBuM7ElExpcv0lsmpawstoRUlLKEpLkTXlQaYoJNAJHXYlcWEg6P4xVluxbaaLzjDpap_sc-x4ZIhtXvZ_pmnI0SXf0wt-lL2AWM-_SxlKxI', 'BMlssZ3Qn709UGRDM0AAVVk9XYVTewv1423n_Y3uNOW3GyBYWkynA3CFcDYL4hqtMpnoMucPkqR1LsnykVZXljc', 'xvToKULyy-t6_dwS3xzycw', '2026-10-11 23:33:14.126386+00', '2026-10-12 00:05:07.245404+00', NULL, 0),
	('94d084cf-07fd-4f7d-99ea-fec6c475711a', 'https://web.push.apple.com/QOfMQ6tbsAWiKATup4LlhuP5Nce5ZnvZ3M1CNYQrJCGBbiHlg-YnvhUtozLiYkicciIqaE_WG8Rlrmui1dcZS6hFV7XMtdxcetTQAHWzJmJYkUz6AT8yW1qZq9PToY9bUPXaIFEqKCdji5UhFq0-cfqIFvGqcL0O69MtXeZ8oak', 'BHuddO-fbTn7zwYLPVEAbwJeTqT817_fGAHpVgxQAoU-kjEUBvyDUn7EwWd0FNv7N-7VxQp5S2ez3beUx_vGoFI', 'KpR2STRiVngIuhMLtfcLnA', '2026-10-17 21:38:26.059258+00', '2026-10-17 21:38:26.059258+00', NULL, 0),
	('99a3c475-f9aa-4c94-8a0f-f556ecbbf936', 'https://fcm.googleapis.com/fcm/send/ecZOSIlAytk:APA91bFR8N6RmzgzJk4MGKo3EPkETwjXGaLuzE53g7fd9ydjDGbC086anNl_ypssqExyLivuEXEe9wa4VMoZ1o8FboHR-tXiiFd8It4bfV_RXLIfMByBia1Kd4X6z8V3tdhOce5AN-vM', 'BJ0ktKYk_tBdBMl3JoARXk5PwEwVaIGOqGseotcw5Nes5ME3uOhZXrcEI6ycyX_Fm2BrfmSnAh3SXT3_Wb1_3Ck', '3o37Q6-_3A_8QNK9npwTMg', '2026-10-18 02:04:35.913945+00', '2026-10-18 02:04:35.913945+00', NULL, 0),
	('9c010836-db15-4082-9c13-ea22ebbbc367', 'https://fcm.googleapis.com/fcm/send/dxjvXIsgZlc:APA91bHGi3cETNMfY5I38q3KnozoqQ2mxw1SkXSS1jMr-gB6wF-PRbBs2ADoxDGyHlpwVIQ344r33podM1JxBnAFPwzSSuEWPkHwXeddOmLKdLhcAdIAsOYs81sW--Dn6WT6iudnScJ8', 'BGUmcgXi1FAmHLVIByEpHpfH9RWU67DqBjHQ1OZ_0rgT_Hw6tcw9pHvxu4HLOnmoHRZphVLywvjJvXpjDB5NbP0', '7AYQncrOA1wBZHEgGSupzw', '2026-10-17 19:52:48.079815+00', '2026-10-17 19:52:48.079815+00', NULL, 0),
	('a737c29e-89a8-477a-a57f-e72897daa389', 'https://fcm.googleapis.com/fcm/send/fDZaeTMVcGA:APA91bHYgdwQgUr6-j0temO6USc9i9J-zFPAcuWk6uxA7W8SjEo09f5SYFsqxMiNnnl80RrlTKlCpbuf1kEyGsS8rMwhd9P-r6PTY1cVh0FNw3xBK23jhku1peaaa8pt0qrVN0pEVzR4', 'BOpKo96ue5Vp41TrueLIoaGOyNlQgc6mNYxfZpLGfpOHsxOhCkNHaPTWDIP8L3d0MGdX6krpakIAYdkGiF3StEQ', 'PJWz4F9HOibhoZkRhRyapg', '2026-10-16 10:20:05.394596+00', '2026-10-16 10:20:05.394596+00', NULL, 0),
	('aa54025d-5a40-4bf0-afaf-a7fde58e02fd', 'https://fcm.googleapis.com/fcm/send/cQ-ue6bD1jU:APA91bEuBPcD_c1adXkusC-mXjj9GURgpfaBx3tnYS7MH0a0EmYnArwlzXr4OqM7-lsaq1EE1bSODLCozYfO2hVU15Lv_pPJNGvtAJrOJXKNlm6zwlzKeK3cYOyLWNH_AgRLR_iup9la', 'BAmJS6NH4trJA_9mJLVnzqL2BAfPmGMFcDBWz5I0e-0Z5W_GV5eou74dRxsxJO_g1QkZoGUWDr2jidFbByTJ-pY', 'oBwOUr8SHrT8gCR9wXE5Ww', '2026-10-17 00:28:59.835468+00', '2026-10-17 22:54:05.558265+00', NULL, 0),
	('aaa23a66-733f-4f04-a120-5b9e1eabfd5d', 'https://fcm.googleapis.com/fcm/send/fecLKTd0B5k:APA91bEBNYmU64RP6QlISlU07xrmShusGKlLUikrvdaxlzAj3LWk25Cupw0OJmXxGWZCtW5zOIUvrzufGJwY7cfr2f8TIBjwvZQUBq90m4eB2jMhyhpox5bMItvqWPQlvKqC8Dzq0mcR', 'BD1HOnexGmQ2XhwoFQScwCZ5IJIaXK_65noMx1quO42BZvQ8gM__JFtM4ySg2KJ51sA8Un68rDFnjGAhF21sfrw', 'jVw6VDqHNxZ5l-TKW6Nz_Q', '2026-10-14 20:41:25.497148+00', '2026-10-14 20:41:25.497148+00', NULL, 0),
	('b4766fb5-472d-4781-a5a8-bb33b8e39f15', 'https://fcm.googleapis.com/fcm/send/dZvlpFbx4tQ:APA91bGP2oefTxD5nvIix069Zn3bitfGY7MrZhzy2s6IBIZgzDJIt0aWy1PdzFa7RtpxDKRS2c0NmxTWaXPnUnoMOmK36bTv_3VU_LFlWDVDCXg_-uN822LmC8Bg33vmO52v9tfBRoHf', 'BEn2pRK_zJMxZEo6JQbjRKlkKY6ieuBf4_qt9r-TaPmhil3pk70V0wivTHUgMJhwheVFQJuR2USHvkT6JvU96NU', 'Qep6wEXlLeaYqEC8BkKPGQ', '2026-10-16 16:10:15.89196+00', '2026-10-16 16:10:15.89196+00', NULL, 0),
	('b557017d-b373-412d-9a1f-3172a23ef85d', 'https://fcm.googleapis.com/fcm/send/d_hxpdthK_k:APA91bGjYL1t1M9wGNfewFb8Z063VI0iWSqUQEWAUXCEO_dBjQzHAlfp7Xs-rXc9DMFD5Pwi6Eeg-x9x3iZIdl9GjF3PG67Ge7c4CZTZTT2Zt1GQ3i2bMK12wgANa9qWsGdFXKedfPq2', 'BKCOE4vomaIteO0C4qiAFnWPvpSDYGPIlbVgWxEVgH7y05o9ExDjnXmYJhEvc5FCqfeaeujcKL3g4dNvAefcwNI', 'UeCSEdRUDQpB1mZxeZQoYQ', '2026-10-11 11:27:50.746465+00', '2026-10-11 14:02:33.429499+00', NULL, 0),
	('b671b8cb-52b9-402c-986c-9e3f86fa2fbb', 'https://fcm.googleapis.com/fcm/send/f9cDKYlrd9I:APA91bFgOuGLYBhLCPwHPw9u-NdAafEvZU6KzpBswRtbIWPWjCmXtkJh4BWzqiOXLm5Q-7fl5o8iOb-d9UCZuMx56pwNS_bLjRWT1YYUh5Q9b7QFxBtx6oLwZdpGKeNJjWrLeAb45YtN', 'BBQlPmS1ojys95an1_xitNBInLraYTiJ10gZek0kfehzja-ivelv_nIvY8d_tfx6SJm1B04mNGriX4SgFFgF6XQ', 'J77pXOSjMTjhqhsCUeaNhA', '2026-10-11 18:54:47.620501+00', '2026-10-11 18:54:47.620501+00', NULL, 0),
	('c86d98ad-b93f-495e-8a78-c121365dac2c', 'https://fcm.googleapis.com/fcm/send/dgEUeZiy2Rk:APA91bFvGlRmNYdLgg96OiUY3Yc3BLZdXJU2QkpjprJP_DYBTLlAdCHrrFKL0_xg0zwi2YVW-trJC07ojmovH3CQoPgXeJl9MOXs4ksmYo3XbHTPwk3eVpbumsh20FepcpNo9ZshytSA', 'BBD570QpQP0hBQQGGlzIeoGIkrzY-pv0zuTJDDiDenBiYZczgTpj6st5RuEw5h308UfrBYH6XooU0ZLJJwkl0-4', 'TY5-2T9ozYDNNeHWJhCxsQ', '2026-10-12 02:09:22.415848+00', '2026-10-12 02:26:37.782679+00', NULL, 0),
	('c8813fc6-312d-465d-b2de-5c1ed30bb9a5', 'https://fcm.googleapis.com/fcm/send/cLYaMzEv2gQ:APA91bEDjusYIcKZavO_bPMaM8xRtnNHJyBSXUhK1O2bcsuQuksg3ZshHVDhWDTk8k_N22-jzkidPZpbQAkHcyReshluQ5Yu1TC4sW1IGCR-A61YPnAH3cuJFYbH59kl2iVwaX-q21VZ', 'BMTUTzWgmiFN-ZmycrCk36IEjHGvNthj2BS_OY3VNhS3XfY4mm8rCiwV-F14NNxQ1wcSg7b9frQw0OHWKCo7ITA', 'zEWDoS1ftRS37r1IAoFDkA', '2026-10-11 00:41:17.749991+00', '2026-10-11 06:02:47.946478+00', NULL, 0),
	('c9c8a808-733a-48b1-bb9a-02d9c0875a1d', 'https://wns2-bl2p.notify.windows.com/w/?token=BQYAAABkqBdJPjPjOl%2ffgLE44x7dtyehDXDQwA%2bfwLfxH6GSxeVq8iGSfCWUMS1sbFmVDGQnh7giQoOHrpFZSkTXxR2AVaTEhmKwpoWIa4kz%2bZd2eFVHIOJ6teyASZpHOLMcfmD8e%2fxkpCiuBhOwVwwBUn2h%2br2lODNvBXGCv3xtDkj2EJHMXxxxaRcxiosLBl7kD0XBBkkupuHmtwbR4SJ4HdB9x3Ezn4LfGQ3nxgYo2FFEykmpWLdqCjbaAoXK1sgtEY%2bP0ekJkmpdG3aNz%2bqmZviLioM8ynYsoU843HE79FBHcUAejz3PDT25IPwQJTBfUufvvn0XXlY2PNhlyxSw8Bl0', 'BCpGvwyzjXy-LEGQAtc2g1a9TB0RJb4FNT4DtWnA--rVSh0vRG-Y83OSCUe_DCAHkKbCT9L8t0isjRsD3KPuncI', 'a98k2Q_xRxQfZI_EVSvfuw', '2026-10-11 00:14:17.348039+00', '2026-10-11 00:14:21.905128+00', NULL, 0),
	('ddbddac7-3de3-4384-ba06-7e5adc730c6b', 'https://fcm.googleapis.com/fcm/send/eN4JEHRWiXc:APA91bFeeUYdjGIUFsBfaYMAJEWl0W82B5OTk2O1oPaxHaJ92dkDxhTFqXBah98GTKUNGA5oP5ccwJgtNZWyYtL4dMHLaHFi9ovT8XKc4x1T7D6rREWOmhQwJXC8i6Jk2CcbZaxfwVJQ', 'BL03SEYdwBVLo_z6jDIASol5pRO-xSaymXxUsfMAr81gbE2HMcugFqj7PCbYqWQLO0MuWZKv9czTUXB-z9UO7MA', '4dJU3LH7qyxt2bzj9zPgmQ', '2026-10-11 07:36:20.78012+00', '2026-10-11 07:36:20.78012+00', NULL, 0),
	('e57ece4a-cbf8-4a11-a5a5-7eba9cbc56a9', 'https://fcm.googleapis.com/fcm/send/dXiD0hmmgno:APA91bHkPx64XDXjy8ft3D6zlFXdm1HxAStDFJMkk-qoAWzI1B-q6XBIlaqB6b-D_LsJu34JLWvcV0X7gtbZg_rmvWWL-x87fQHqXi0drjDzdtp_pdgC5KyFVOklCl2AWWklg-KzG20H', 'BLrMdPzLJQzCCj9SJATSFufHuKM9hccFa_mt_Y2O1KwJltpoAMooXookYWno5MkGIVjsOAfhM2nmb0UMp9ewkc8', 'um9fUWnuGHQ_AxkpkYFASQ', '2026-10-17 01:45:57.904834+00', '2026-10-17 01:45:57.904834+00', NULL, 0),
	('eba00b87-7a47-4430-ad56-96a5cdcf7419', 'https://fcm.googleapis.com/fcm/send/cTStdZSNc70:APA91bGFXgQu_Qc6WKDTKUOf59CVRr6yDzvpPZ4PQ77huCII0EWjTzS3IrfbRutwp0DLXzSJR_UTrXQA-z1NMUS_YGu-fA7Et89s5-hpzndzw8DD6eanJKRS2q6i2vz2cYjI5IV6M7KJ', 'BAAEkN5YUa536V619C54NFnPR2d3C4GojxPzhKCs4-5HrctPdP7TzvSHqhMA9FSPoiatvC8pFNPen11hQC-WsSQ', 'IxgJG1zUsWspGO1hhXNupg', '2026-10-11 20:27:35.797677+00', '2026-10-11 20:27:35.797677+00', NULL, 0),
	('efc875a5-691d-42a2-8718-ad2d9b4eb99d', 'https://fcm.googleapis.com/fcm/send/f6tS4TzAvKc:APA91bHkXMf10_7q-kqumBBAQtdygkvqdWXNJ4nZOoDU85nQa4-SHLYtLW0mI7Q7jrKCE_eVpOCT2BxK3lpSpfnikFV0m_n35Kz2v1-i6dSs_nMcaoHSnfB6nY6nNzuIp11DQxy8TGww', 'BEm_Yj5C9mSJZTmLWh51VlhAyCwnzsHoj5aPIfMI7QLy9CpENuqVTiNFoTXy26uonEk6zPLexe8NkPESSPjICwQ', '_uST3eEulZkeL_bTt29lpg', '2026-10-12 22:08:56.849091+00', '2026-10-12 23:16:05.018506+00', NULL, 0),
	('fd27b99a-4f3e-4ee8-8e48-0c8d98bce71e', 'https://fcm.googleapis.com/fcm/send/e5yR2aBrAbo:APA91bEKHiY3aOStZ95tbPSQTfeKbvAygRV0EqP99TbHQBbU1Y5XlRlyyon5ayI7-gkHJtcRd8uzyBlSaeJqV_0ipgqCC4-3daQoc9-X4UANbOxYsJsAPxP5CiGMqyIpI1OKdhCXhNXy', 'BLZ2yGdwCWf97kXOyFdV33TRHiRyPnfFbAbxgEdzKoHaeoBmtQn8L0ACg-nPN1gM8_w58IcuSPiGZ9JD38woyrM', 'hhIjxa7Uoor70QzDn6MTnw', '2026-10-11 06:04:30.392009+00', '2026-10-11 06:04:30.392009+00', NULL, 0);


--
-- Data for Name: push_cliente_pedidos; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.push_cliente_pedidos (venda_id, inscricao_id, criado_em, feedback_pedido_em) VALUES
	('0e4f13c6-1149-4547-a29c-0cc48ae7af93', '5e6d019e-f226-4663-a7ef-9c09c89b2730', '2026-10-14 22:38:13.974888+00', '2026-10-15 23:50:00.12815+00');


--
-- Data for Name: push_inscricoes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.push_inscricoes (id, usuario_id, endpoint, p256dh, auth, criado_em, ultimo_envio_em, falhas) VALUES
	('2f7d129c-3b73-4494-a5cb-a2f0c83f8ff2', '9866c7ad-b231-458d-aed3-34daa4d28268', 'https://fcm.googleapis.com/fcm/send/cpfPAmSv-6k:APA91bEmA9s6XpodTUkJ4FxGH53iJUbn8xHajHHCvvRaedTfGsM2ZKeGx0o2PYsea9xt26xE7DCKN4P9MZxBeYrBZEns6NXwWG04Cu00q9jnPinadTxkedB7cqb3nUfxU0luAqBWc0t-', 'BFgLoa2Vlca2Fa-KSbiRhrhaXi75Hrygs02EoIXIAvncnNAKtCVVBvhY3s906wvGxi44phx3l7nO8YUCWjmYHVc', '9oUejC2ElA-IRrOAud3EZQ', '2026-10-17 20:01:36.724472+00', '2026-10-18 01:29:00.586+00', 0),
	('796fcab4-572f-4501-ac33-9704acb563f7', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'https://fcm.googleapis.com/fcm/send/cQ-ue6bD1jU:APA91bEuBPcD_c1adXkusC-mXjj9GURgpfaBx3tnYS7MH0a0EmYnArwlzXr4OqM7-lsaq1EE1bSODLCozYfO2hVU15Lv_pPJNGvtAJrOJXKNlm6zwlzKeK3cYOyLWNH_AgRLR_iup9la', 'BAmJS6NH4trJA_9mJLVnzqL2BAfPmGMFcDBWz5I0e-0Z5W_GV5eou74dRxsxJO_g1QkZoGUWDr2jidFbByTJ-pY', 'oBwOUr8SHrT8gCR9wXE5Ww', '2026-10-17 00:29:44.851284+00', '2026-10-18 01:28:59.924+00', 0),
	('866c9e83-a3f1-42b7-9b40-0dbfa2848429', '9866c7ad-b231-458d-aed3-34daa4d28268', 'https://wns2-bl2p.notify.windows.com/w/?token=BQYAAAA7jfKa9ckCjSW7nRz4S9e9nXGjPfEIUSZCdk1uUlWoiGGcfuYv2GXs4lAcRFrq6BReuObWcmVwVrH3iuT0fJjK6WF6HVHY%2fFgl0a3rgpEpDUM7reT%2fQb00ms04u0PaaB3ejZi2bwYuKDS4WdbKVg4j8mdLalZTokhcJW2uZrjyM6jzbXdrduIENV9na5buQOn%2beb3Zk9JfMb1lt89Fy8p4Zd%2fFqkejHIIlHbtqSXXgN4HQO83uBQ5xx%2f8Y1d4WqafC657lIg1AX85m8QlnZR20HMPQL5ln1rMZHlx5Ue%2bThcrP5%2fvESOB7cFm8iSwDlmaqxAmMMvEkskT7ZDqB0eZI', 'BGNJjJ_aaFdaZxTnuQc24iIbBMipAGWA6WhtDCVrfzjkQKy4QE8_xicSNPPPr42lDTzLccETW4xc7QUDWeU6mJs', 'kug9jhc2t4TlCufPjMRVEg', '2026-10-12 13:52:07.095184+00', '2026-10-18 01:29:00.199+00', 0),
	('b1a5f756-e379-49db-a12b-06440b775322', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', 'https://fcm.googleapis.com/fcm/send/dHzEClFJAzw:APA91bE-rbxdxu4_pbrdjIijk4SXlvToD_OLJ8Ec_8nnKFJSqCid3KyYHues44ZuPpQfUR9wYcMgJul3Va3wshpE6M3fyBVsPwiqFQMvpw4mAAfKvtoyzKpNHtZ8bFtYX_7loIInWS7E', 'BMRMQLNAVCr1-cm1fEbyLA8fJiCF4mIyyBFENS9qs380YYRnsatQNqCEI85RzE07OKJOdtY4UalkEp6W5EpFlvg', 'ai8cPXz27KgQ9TnvytkA6g', '2026-10-12 02:41:44.567267+00', '2026-10-18 01:29:00.608+00', 0),
	('cb93795d-3aaa-4b6c-af5f-c798cfb1b364', '9866c7ad-b231-458d-aed3-34daa4d28268', 'https://fcm.googleapis.com/fcm/send/ecZOSIlAytk:APA91bFR8N6RmzgzJk4MGKo3EPkETwjXGaLuzE53g7fd9ydjDGbC086anNl_ypssqExyLivuEXEe9wa4VMoZ1o8FboHR-tXiiFd8It4bfV_RXLIfMByBia1Kd4X6z8V3tdhOce5AN-vM', 'BJ0ktKYk_tBdBMl3JoARXk5PwEwVaIGOqGseotcw5Nes5ME3uOhZXrcEI6ycyX_Fm2BrfmSnAh3SXT3_Wb1_3Ck', '3o37Q6-_3A_8QNK9npwTMg', '2026-10-18 02:08:52.979233+00', NULL, 0);


--
-- Data for Name: requisicoes; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.requisicoes (chave, acao, resultado, usuario_id, data_hora) VALUES
	('r-1791509487249-xrsgxuyd', 'registrarBrinde', '{"id": "a1ac945f-0d30-4326-af97-61130bf7f5c2", "ok": true, "message": "🎁 X Bacon entregue a Lucas Ricardo. (o produto não tem receita cadastrada: nada foi baixado do estoque)"}', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', '2026-10-09 01:31:27.4292+00'),
	('r-1791509503319-pq5mg3l9', 'registrarBrinde', '{"id": "baefc2f2-b19a-432c-a706-c4fa12d3f9fb", "ok": true, "message": "🎁 X Bacon entregue a Lucas Ricardo. (o produto não tem receita cadastrada: nada foi baixado do estoque)"}', '98a655a7-3d3b-4826-b6ac-e7c81fe5a0e1', '2026-10-09 01:31:43.482337+00');


--
-- Data for Name: sistema; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sistema (chave, valor, atualizado_em) VALUES
	('AjudaDiariaEntregador', '0.00', '2026-10-04 17:13:29.113404+00'),
	('AvisoPrivacidadeVersao', '1', '2026-10-12 01:08:43.04162+00'),
	('BACKUP_AUTO_ATIVO', 'true', '2026-10-06 21:28:33.131972+00'),
	('BACKUP_FREQ', '"diario"', '2026-10-06 21:28:33.895986+00'),
	('BACKUP_HORA', '4', '2026-10-06 21:28:33.50982+00'),
	('BLOQUEAR_ESTOQUE_NEGATIVO', 'false', '2026-10-03 16:23:23.875703+00'),
	('CardapioFechadoManual', '{"ativo": false, "mensagem": ""}', '2026-10-17 00:28:56.76773+00'),
	('CardapioFrase', '""', '2026-10-03 16:23:23.875703+00'),
	('CardapioKicker', '""', '2026-10-03 16:23:23.875703+00'),
	('CardapioPeriodosFechado', '[]', '2026-10-17 00:28:56.76773+00'),
	('CardapioTempoEntrega', '""', '2026-10-03 16:23:23.875703+00'),
	('CardapioTempoMesa', '""', '2026-10-03 16:23:23.875703+00'),
	('CardapioTempoRetirada', '""', '2026-10-03 16:23:23.875703+00'),
	('LgpdAnosAnonimizar', '3', '2026-10-12 01:08:43.04162+00'),
	('MANUTENCAO', 'null', '2026-10-03 16:23:23.875703+00'),
	('MetaDiaria', '0', '2026-10-03 16:23:23.875703+00'),
	('MetaMensal', '0', '2026-10-03 16:23:23.875703+00'),
	('NotificacoesConfig', '{"pedido": {"ativo": true, "perfis": ["Admin", "Cozinha", "Operador"]}, "entrega": {"ativo": true, "perfis": ["Admin", "Operador"]}, "estoque": {"ativo": true, "perfis": ["Admin", "Cozinha", "Operador"]}, "sistema": {"ativo": true, "perfis": ["Admin"]}, "inativos": {"ativo": true, "perfis": ["Admin", "Operador"]}, "indicacao": {"ativo": true, "perfis": ["Admin", "Operador"]}, "fidelidade": {"ativo": true, "perfis": ["Admin", "Operador"]}, "financeiro": {"ativo": true, "perfis": ["Admin"]}, "ocorrencia": {"ativo": true, "perfis": ["Admin", "Operador"]}, "aniversario": {"ativo": true, "perfis": ["Admin", "Operador"]}}', '2026-10-09 19:06:39.309219+00'),
	('RestauranteEndereco', '"Bebedouro - SP"', '2026-10-10 13:37:25.720379+00'),
	('RestauranteNome', '"Texas Burger"', '2026-10-10 13:37:25.720379+00'),
	('RestauranteRedes', '"Instagram: @texas_burguer017"', '2026-10-10 13:37:25.720379+00'),
	('RestauranteTelefone', '"(17) 98832-3473"', '2026-10-10 13:37:25.720379+00'),
	('TaxaEntregaPadrao', '8.00', '2026-10-04 17:13:29.113404+00'),
	('ULTIMA_GERACAO_DESPESAS', '"2026-10"', '2026-10-04 14:08:42.811026+00');


--
-- Data for Name: sync_estado; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.sync_estado (id, principal_ultimo_ok, principal_ultimo_erro, principal_ultimo_erro_msg, contingencia_ultimo_ok, contingencia_ultimo_erro, contingencia_ultimo_erro_msg, contingencia_atraso_minutos, alerta_itens_limite, alerta_horas_limite, atualizado_em) VALUES
	(true, '2026-10-18 02:34:03.191099+00', '2026-10-11 11:24:16.075331+00', 'Unexpected token ''<'', "<!DOCTYPE "... is not valid JSON', NULL, NULL, NULL, 60, 500, 6, '2026-10-18 02:34:03.191099+00');


--
-- Data for Name: versoes_sync; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO public.versoes_sync (grupo, n) VALUES
	('cad', 175),
	('din', 328);


--
-- Name: ai_ajuda_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ai_ajuda_id_seq', 289, true);


--
-- Name: chat_mensagens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.chat_mensagens_id_seq', 14, true);


--
-- Name: erros_cliente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.erros_cliente_id_seq', 9, true);


--
-- Name: integridade_checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.integridade_checks_id_seq', 45, true);


--
-- PostgreSQL database dump complete
--




-- contadores (sequências)
select pg_catalog.setval('public.vendas_numero_pedido_seq', 200, true);
select pg_catalog.setval('public.ocorrencias_numero_seq', 1, true);
select pg_catalog.setval('public.arquivo_historico_id_seq', 1, true);
select pg_catalog.setval('public.ai_ajuda_id_seq', 289, true);
select pg_catalog.setval('public.ai_log_id_seq', 188, true);
select pg_catalog.setval('public.auditoria_id_seq', 1048, true);
select pg_catalog.setval('public.erros_cliente_id_seq', 9, true);
select pg_catalog.setval('public.chat_mensagens_id_seq', 14, true);
select pg_catalog.setval('public.fotos_historico_id_seq', 1, false);
select pg_catalog.setval('public.fila_sync_id_seq', 9551, true);
select pg_catalog.setval('public.integridade_checks_id_seq', 45, true);
select pg_catalog.setval('public.integracoes_log_id_seq', 64, true);
select pg_catalog.setval('public.ifood_precos_hist_id_seq', 1, false);
select pg_catalog.setval('public.ifood_acoes_id_seq', 5, true);
select pg_catalog.setval('public.nfce_inutilizacoes_id_seq', 1, false);
select pg_catalog.setval('public.nfce_notas_id_seq', 7, true);
select pg_catalog.setval('public.pagamentos_online_eventos_id_seq', 4, true);
select pg_catalog.setval('public.anonimizar_arquivo_fila_id_seq', 1, true);


set session_replication_role = origin;
