-- 18 - Assistente: 4 verbetes novos (alertas que repetem, histórico de vendas arquivado, rascunho/ajuste de preços, mudanças na edição de venda). Pode rodar de novo.
-- Desfazer: delete from public.ai_ajuda where slug in ('man-admin-125-alertas-repetem','man-admin-126-historico-arquivado','man-admin-127-rascunho-ajuste-precos','man-admin-128-editar-venda-diferenca');
insert into public.ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns) values
($t$man-admin-125-alertas-repetem$t$,$t$Avisos do sistema que se repetem até resolver$t$,$t$alertas avisos notificação repetir repete aviso sistema caixa vencido backup planilha parou configurar avisos intervalo minutos som$t$,
$t$Administrador → Loja e equipe → Configurar avisos → "Alertas automáticos". Os avisos de problema do sistema (caixa aberto há muito tempo, backup parado, planilha sem salvar, vencimentos) repetem a cada 30 minutos até o problema ser resolvido. Você muda esse tempo em "Repetir avisos do sistema a cada (min)" (10 a 240).
O e-mail sai no máximo a cada 6 horas por problema, para não lotar a caixa; o aviso no celular e o som continuam repetindo. Aviso de pedido parado repete no tempo "Repetir a cada" até o pedido andar, ser adiado ou silenciado.$t$,
ARRAY['Admin'],true,'secao',125,$t$$t$),
($t$man-admin-126-historico-arquivado$t$,$t$Dados antigos na planilha: o que continua acessível$t$,$t$arquivo arquivado planilha histórico vendas antigas cliente pedidos antigos reimprimir relatório mês perdi sumiu antigo$t$,
$t$Vendas e caixas antigos são copiados para a planilha e só depois saem do sistema, quando a planilha confirma que recebeu tudo. Mesmo assim continuam acessíveis: o histórico e os pedidos do cliente (com valores e total gasto), os relatórios por mês, o histórico de caixa e o "Histórico de vendas" de qualquer dia antigo, com reimpressão do comprovante.
Se algo parecer faltar, abra Relatórios e escolha o mês; o sistema avisa o Admin, repetindo, quando a planilha passa de 80% do limite do Google.$t$,
ARRAY['Admin'],true,'secao',126,$t$$t$),
($t$man-admin-127-rascunho-ajuste-precos$t$,$t$Produto: rascunho automático e ajuste de preços em lote$t$,$t$rascunho produto novo continuar fechei sem querer perdi ajustar preços porcentagem aumentar preço reajuste lote categoria$t$,
$t$Administrador → Produtos. Se você fechar o "Novo produto" no meio, o rascunho fica salvo no aparelho: ao tocar em "+ Novo produto" o sistema pergunta se quer continuar de onde parou.
Para reajustar preços, toque em "% Ajustar preços", digite o percentual (8 sobe 8%, -5 baixa 5%), escolha a categoria (ou todas) e confirme. O custo não muda e a ação fica na auditoria.$t$,
ARRAY['Admin'],true,'secao',127,$t$$t$),
($t$man-admin-128-editar-venda-diferenca$t$,$t$Editar venda: diferença, forma de pagamento e fidelidade ao cancelar$t$,$t$editar venda diferença pagamento forma pagar a mais a menos cancelar venda fidelidade pontos selo desfazer$t$,
$t$Caixa → venda → Editar. Se o total mudar, o sistema pede a forma de pagamento da diferença (cobrar ou devolver) e registra no caixa. Ao cancelar uma venda, os pontos de fidelidade ganhos nela são desfeitos.$t$,
ARRAY['Admin','Operador'],true,'secao',128,$t$$t$)
on conflict (slug) do update set titulo=excluded.titulo, palavras_chave=excluded.palavras_chave, passos=excluded.passos, perfis=excluded.perfis, ativo=excluded.ativo, grupo=excluded.grupo, ordem=excluded.ordem, comuns=excluded.comuns, atualizado_em=now();
