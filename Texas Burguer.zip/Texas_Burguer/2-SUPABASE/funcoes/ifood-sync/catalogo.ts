// ifood-sync · gestão do catálogo no iFood (categorias, itens, grupos de complementos, complementos, preço/status em massa).
// ⚠️ Corpos e endereços seguem a documentação pública do Catalog v2 conforme conhecida; ainda NÃO testados com o iFood de verdade.
// Qualquer recusa do iFood aparece na tela "Cardápio no iFood" (texto do erro) e nos Logs da API do Developer Portal.
type Ctx = { chamar: (cred: any, metodo: string, caminho: string, corpo?: unknown) => Promise<any>; rpc: (fn: string, args?: Record<string, unknown>) => Promise<any>; HttpErro: any };

const numero = (v: unknown) => Number(String(v ?? 0).replace(",", "."));
const erroTexto = (ctx: Ctx, er: unknown) => er instanceof ctx.HttpErro ? `${(er as any).status} ${(er as any).corpo}` : String((er as any)?.message || er);

async function catalogoId(ctx: Ctx, cred: any, m: string): Promise<string> {
  const r: any = await ctx.chamar(cred, "GET", `/catalog/v2.0/merchants/${m}/catalogs`);
  const lista: any[] = Array.isArray(r) ? r : (r?.catalogs || []);
  const c = lista.find((x) => /DEFAULT/i.test(JSON.stringify(x.context || x.catalogContext || ""))) || lista[0];
  const id = c?.catalogId || c?.id;
  if (!id) throw new Error("o iFood não devolveu nenhum catálogo para a loja");
  return String(id);
}

async function subirFoto(ctx: Ctx, cred: any, m: string, dataUrl: string): Promise<string> {
  const r: any = await ctx.chamar(cred, "POST", `/catalog/v2.0/merchants/${m}/image/upload`, { image: dataUrl });
  const caminho = r?.imagePath || r?.path || r?.image || r?.url;
  if (!caminho) throw new Error("o iFood não devolveu o endereço da foto enviada");
  return String(caminho);
}

async function enviarCategoria(ctx: Ctx, cred: any, m: string, reg: any) {
  const d = reg.dados || {};
  const cid = await catalogoId(ctx, cred, m);
  const status = d.status === "UNAVAILABLE" ? "UNAVAILABLE" : "AVAILABLE";
  let ifoodId = d.ifoodId as string | undefined;
  if (!ifoodId) {
    const r: any = await ctx.chamar(cred, "POST", `/catalog/v2.0/merchants/${m}/catalogs/${encodeURIComponent(cid)}/categories`, { name: reg.nome, status, template: "DEFAULT", sequence: 0 });
    ifoodId = r?.id || r?.categoryId;
    if (!ifoodId) throw new Error("o iFood não devolveu o código da categoria criada");
  } else {
    await ctx.chamar(cred, "PATCH", `/catalog/v2.0/merchants/${m}/catalogs/${encodeURIComponent(cid)}/categories/${encodeURIComponent(ifoodId)}`, { name: reg.nome, status });
  }
  await ctx.rpc("ifood_cat_resultado", { p_id: reg.id, p_estado: "enviado", p_erro: null, p_patch: { ifoodId, catalogId: cid, enviado: { nome: reg.nome, status } } });
}

async function enviarItem(ctx: Ctx, cred: any, m: string, arv: any) {
  const reg = arv.registro, d = reg.dados || {};
  const cat = arv.categoria;
  if (!cat?.dados?.ifoodId) throw new Error("envie primeiro a categoria deste item ao iFood");
  const grupos: any[] = arv.grupos || [], opcoes: any[] = arv.opcoes || [];
  const productId: string = d.productId || crypto.randomUUID();
  let foto: string | undefined = d.foto;
  if (d.fotoPendente) foto = await subirFoto(ctx, cred, m, d.fotoPendente);
  const patchOpcoes: Record<string, any> = {};
  for (const o of opcoes) {
    const od = o.dados || {};
    const p: any = { productId: od.productId || crypto.randomUUID(), foto: od.foto };
    if (od.fotoPendente) p.foto = await subirFoto(ctx, cred, m, od.fotoPendente);
    patchOpcoes[o.id] = p;
  }
  const status = d.status === "UNAVAILABLE" ? "UNAVAILABLE" : "AVAILABLE";
  const preco = numero(d.preco);
  const est = JSON.stringify({ n: reg.nome, d: d.descricao || "", f: foto || "", c: cat.dados.ifoodId,
    g: grupos.map((g) => ({ id: g.id, n: g.nome, min: g.min, max: g.max, o: (g.dados?.opcoes || []).map((x: any) => x.id) })),
    o: opcoes.map((o) => ({ id: o.id, n: o.nome, d: o.dados?.descricao || "", f: patchOpcoes[o.id].foto || "" })) });
  const env = d.enviado || null;
  if (!env || env.est !== est) {
    const corpo = {
      item: { id: reg.id, type: "DEFAULT", categoryId: cat.dados.ifoodId, status, price: { value: preco }, externalCode: reg.id, index: 0, productId },
      products: [
        { id: productId, name: reg.nome, description: d.descricao || "", externalCode: reg.id, image: foto, serving: "NOT_APPLICABLE", optionGroups: grupos.map((g) => ({ id: g.id, min: g.min, max: g.max })) },
        ...opcoes.map((o) => ({ id: patchOpcoes[o.id].productId, name: o.nome, description: o.dados?.descricao || "", externalCode: o.id, image: patchOpcoes[o.id].foto, serving: "NOT_APPLICABLE" })),
      ],
      optionGroups: grupos.map((g, i) => ({ id: g.id, name: g.nome, externalCode: g.id, status: "AVAILABLE", index: i, optionIds: (g.dados?.opcoes || []).map((x: any) => x.id) })),
      options: opcoes.map((o, i) => ({ id: o.id, status: o.dados?.status === "UNAVAILABLE" ? "UNAVAILABLE" : "AVAILABLE", index: i, productId: patchOpcoes[o.id].productId, price: { value: numero(o.dados?.preco) }, externalCode: o.id, fixedQuantity: 1 })),
    };
    await ctx.chamar(cred, "PUT", `/catalog/v2.0/merchants/${m}/items`, corpo);
  } else {
    // só preço/pausa mudaram: o iFood exige PATCH para isso
    if (numero(env.preco) !== preco) await ctx.chamar(cred, "PATCH", `/catalog/v2.0/merchants/${m}/items/price`, { itemId: reg.id, price: { value: preco } });
    if (env.status !== status) await ctx.chamar(cred, "PATCH", `/catalog/v2.0/merchants/${m}/items/status`, { itemId: reg.id, status });
    for (const o of opcoes) {
      const oe = o.dados?.enviado || {}; const op = numero(o.dados?.preco); const os = o.dados?.status === "UNAVAILABLE" ? "UNAVAILABLE" : "AVAILABLE";
      if (oe.preco !== undefined && numero(oe.preco) !== op) await ctx.chamar(cred, "PATCH", `/catalog/v2.0/merchants/${m}/options/price`, { optionId: o.id, price: { value: op } });
      if (oe.status !== undefined && oe.status !== os) await ctx.chamar(cred, "PATCH", `/catalog/v2.0/merchants/${m}/options/status`, { optionId: o.id, status: os });
    }
  }
  for (const o of opcoes) {
    const od = o.dados || {};
    await ctx.rpc("ifood_cat_patch", { p_id: o.id, p_patch: { productId: patchOpcoes[o.id].productId, foto: patchOpcoes[o.id].foto || null, enviado: { preco: numero(od.preco), status: od.status === "UNAVAILABLE" ? "UNAVAILABLE" : "AVAILABLE" } } });
  }
  await ctx.rpc("ifood_cat_resultado", { p_id: reg.id, p_estado: "enviado", p_erro: null, p_patch: { productId, foto: foto || null, ifoodId: reg.id, enviado: { est, preco, status } } });
}

async function lote(ctx: Ctx, cred: any, m: string, a: any) {
  const itens: any[] = Array.isArray(a.dados?.itens) ? a.dados.itens : [];
  const preco = a.acao === "catalogo_lote_preco" || a.acao === "catalogo_opcao_preco";
  const opcao = a.acao.startsWith("catalogo_opcao");
  const chave = opcao ? "optionId" : "itemId";
  const corpo = itens.map((x) => preco ? { [chave]: x.id, price: { value: numero(x.valor) } } : { [chave]: x.id, status: x.valor === "UNAVAILABLE" ? "UNAVAILABLE" : "AVAILABLE" });
  await ctx.chamar(cred, "PATCH", `/catalog/v2.0/merchants/${m}/${opcao ? "options" : "items"}/${preco ? "price" : "status"}`, corpo);
  for (const x of itens) {
    const arv: any = await ctx.rpc("ifood_cat_arvore", { p_id: x.id });
    const dd = arv?.registro?.dados || {};
    const novo = preco ? { preco: numero(x.valor) } : { status: x.valor === "UNAVAILABLE" ? "UNAVAILABLE" : "AVAILABLE" };
    await ctx.rpc("ifood_cat_patch", { p_id: x.id, p_patch: { ...novo, enviado: { ...(dd.enviado || {}), ...novo } } });
  }
}

export async function executarCatalogoGestao(ctx: Ctx, cred: any, a: any) {
  const m = encodeURIComponent(cred.merchantId || "");
  const idReg: string | null = a.acao === "catalogo_modelo_enviar" ? (a.dados?.id || null) : null;
  try {
    if (a.acao === "catalogo_modelo_enviar") {
      const arv: any = await ctx.rpc("ifood_cat_arvore", { p_id: idReg });
      if (!arv?.registro) throw new Error("registro não encontrado no sistema");
      if (arv.registro.tipo === "categoria") await enviarCategoria(ctx, cred, m, arv.registro);
      else if (arv.registro.tipo === "item") await enviarItem(ctx, cred, m, arv);
      else throw new Error("só categoria e item são enviados direto");
    } else {
      await lote(ctx, cred, m, a);
    }
    await ctx.rpc("ifood_acao_resultado", { p_id: a.id, p_estado: "ok" });
  } catch (er) {
    const st = er instanceof ctx.HttpErro ? (er as any).status : 0;
    const msg = erroTexto(ctx, er);
    if (idReg) { try { await ctx.rpc("ifood_cat_resultado", { p_id: idReg, p_estado: "erro", p_erro: msg, p_patch: {} }); } catch { /* sem registro */ } }
    await ctx.rpc("ifood_acao_resultado", { p_id: a.id, p_estado: st >= 400 && st < 500 || st === 0 && !(er instanceof ctx.HttpErro) ? "erro" : "duvida", p_erro: msg });
  }
}
