// =====================================================================
// ifood-rastreio · OPCIONAL (ajuste "acompanharEntrega" em Integrações › iFood; nasce DESLIGADO). Roda 1x por minuto, mas o agendamento
// só chama esta função quando a integração está ligada E há pedido do iFood pronto/a caminho com entrega feita pelo próprio iFood.
// Consulta a posição do entregador do iFood e grava no pedido (o painel mostra "onde está" e a previsão).
// verify_jwt = false: aceita só a chave de serviço (a mesma do pg_cron). Erro aqui nunca afeta o ifood-sync.
// ⚠️ O endereço /tracking vem de fonte de terceiros: ainda NÃO testado com o iFood de verdade.
// =====================================================================
import { createClient } from "npm:@supabase/supabase-js@2";

const URL_ = Deno.env.get("SUPABASE_URL")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const svc = createClient(URL_, SVC, { auth: { persistSession: false } });
const BASE = Deno.env.get("IFOOD_BASE_URL") || "https://merchant-api.ifood.com.br";
const json = (o: unknown, status = 200) => new Response(JSON.stringify(o), { status, headers: { "Content-Type": "application/json" } });
const dormir = (ms: number) => new Promise((r) => setTimeout(r, ms));
const seg = async (nome: string) => { try { const { data } = await svc.rpc("api_segredo", { p_nome: nome }); return (data as string) || ""; } catch { return ""; } };
const rpc = async (fn: string, args: Record<string, unknown> = {}) => {
  const { data, error } = await svc.rpc(fn, args);
  if (error) throw new Error(fn + ": " + error.message);
  return data;
};

class HttpErro extends Error { constructor(public status: number, public corpo: string) { super("http_" + status); } }

async function http(metodo: string, caminho: string, token: string | null, corpo?: unknown, extra: Record<string, string> = {}) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 15000);
  try {
    const h: Record<string, string> = { ...extra };
    if (token) h["Authorization"] = "Bearer " + token;
    let body: string | undefined;
    if (corpo !== undefined) {
      if (corpo instanceof URLSearchParams) { body = corpo.toString(); h["Content-Type"] = "application/x-www-form-urlencoded"; }
      else { body = JSON.stringify(corpo); h["Content-Type"] = "application/json"; }
    }
    const r = await fetch(BASE + caminho, { method: metodo, headers: h, body, signal: ctl.signal });
    const txt = await r.text();
    if (!r.ok) throw new HttpErro(r.status, txt.slice(0, 300));
    if (!txt) return null;
    try { return JSON.parse(txt); } catch { return txt; }
  } catch (e) {
    if (e instanceof HttpErro) throw e;
    throw new HttpErro(0, "rede_ou_timeout");
  } finally { clearTimeout(t); }
}

// ---------- acesso (token OAuth guardado no banco; renova antes de vencer) ----------
async function pegarToken(cred: any, forcar = false): Promise<string> {
  if (!forcar) { const t: any = await rpc("ifood_token_ler"); if (t && t.token) return t.token; }
  if (!cred.clientId || !cred.clientSecret) throw new HttpErro(401, "faltam Client ID / Client Secret");
  const r: any = await http("POST", "/authentication/v1.0/oauth/token", null,
    new URLSearchParams({ grantType: "client_credentials", clientId: cred.clientId, clientSecret: cred.clientSecret }));
  const token = r?.accessToken || r?.access_token;
  if (!token) throw new HttpErro(401, "resposta sem token");
  await rpc("ifood_token_gravar", { p_token: token, p_seg: Number(r?.expiresIn || r?.expires_in || 3600) - 120 });
  return token;
}

// chama o iFood; se o token estiver vencido (401) renova uma vez e repete
async function chamar(cred: any, metodo: string, caminho: string, corpo?: unknown, extra: Record<string, string> = {}) {
  let token = await pegarToken(cred);
  try { return await http(metodo, caminho, token, corpo, extra); }
  catch (e) {
    if (e instanceof HttpErro && e.status === 401) { token = await pegarToken(cred, true); return await http(metodo, caminho, token, corpo, extra); }
    throw e;
  }
}


Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ ok: false }, 405);
  const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
  const chaveVault = await seg("service_key");
  if (!token || (token !== SVC && token !== chaveVault)) return json({ ok: false, message: "Só execução interna." }, 403);
  try {
    const cred: any = await rpc("ifood_credenciais");
    if (!cred || !cred.ligado) return json({ ok: true, ligado: false });
    const lista = ((await rpc("ifood_rastreio_pendentes")) as string[]) || [];
    let gravados = 0;
    for (const id of lista) {
      try {
        const r: any = await chamar(cred, "GET", `/order/v1.0/orders/${encodeURIComponent(id)}/tracking`);
        if (r && typeof r === "object") {
          await rpc("ifood_rastreio_gravar", { p_pedido: id, p_dados: { latitude: r.latitude ?? null, longitude: r.longitude ?? null, trackDate: r.trackDate ?? null, expectedDelivery: r.expectedDelivery ?? null, pickupEtaStart: r.pickupEtaStart ?? null, deliveryEtaEnd: r.deliveryEtaEnd ?? null } });
          gravados++;
        }
      } catch { /* ainda sem posição (normal antes do entregador sair) */ }
    }
    return json({ ok: true, pedidos: lista.length, gravados });
  } catch (e) {
    return json({ ok: false, message: String(e).slice(0, 200) }, 500);
  }
});
