# Ajuda do Tex (ai_ajuda) — 16/10/2026 (JÁ APLICADO via conector)
- Backup antes: tabela `ai_ajuda_backup_20261016`.
- Nomes antigos do menu trocados pelos novos (Painel→Hoje, Financeiro→Dinheiro, Catálogo→Produtos, Operação→Loja e equipe, Campanhas→Vendas e cardápio, "Contas e acessos"→"Integrações e contas", "Ajustes pós-venda"→"Reembolsos e ajustes", "Configurar notificações"→"Configurar avisos", Pagamentos→"Formas de pagamento") em todas as entradas ativas.
- Entrada 23 ("Onde fica cada coisa") reescrita com os 6 grupos novos, o Início do Administrador e o campo "Ir para…".
- Nova entrada `man-admin-114-caixa-vencido` (id 284).
- Ficaram como estão (descrevem a aba do Operador, que continua "Operação"): entradas 41, 138 e 110.
- Depois (16/10/2026): "Pergunte à IA" saiu do painel do Administrador (a IA só é acessada pelo balão do Tex). Entrada 23 sem esse item; entrada 283 (Leitor Fiscal, que já tinha sido removido em 15/10) ficou `ativo = false`.
