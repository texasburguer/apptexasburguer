-- Teste do caixa vencido · 2026-10-16 · NÃO deixa nada no banco (termina com o erro de propósito "RELATORIO")
-- Como usar: Supabase → SQL Editor → cole tudo → Run. Leia o relatório que aparece no erro.
do $t$
declare
  r text := ''; x jsonb; cx uuid; adm uuid; gar uuid; opr uuid; ab0 timestamptz; v timestamptz;
  itens jsonb := '[{"descricao":"x","quantidade":1,"valorUnitario":10,"custoUnitario":1}]'::jsonb;
  pags jsonb := '[{"forma":"Dinheiro","valor":10}]'::jsonb;
begin
  select id into adm from usuarios where nivel = 'Admin' and ativo limit 1;
  select id into gar from usuarios where nivel = 'Garçom' and ativo limit 1;
  select id into opr from usuarios where nivel = 'Operador' and ativo limit 1;
  insert into caixa_sessoes (status) select 'Aberto' where not exists (select 1 from caixa_sessoes where status = 'Aberto');
  select id, abertura into cx, ab0 from caixa_sessoes where status = 'Aberto' order by abertura desc limit 1;

  -- 1) cálculo do vencimento (America/Sao_Paulo, corte 06:00, vida mínima 6 h, teto 24 h)
  v := _caixa_vence_em('2026-10-14 21:00:00+00');  -- aberto 18:00 BRT
  r := concat(r, '1a aberto 18h vence 06h do dia seguinte (esperado 2026-10-15 09:00:00+00): ', v, E'\n');
  v := _caixa_vence_em('2026-10-14 08:30:00+00');  -- aberto 05:30 BRT: não vence às 06:00
  r := concat(r, '1b aberto 05:30 NÃO vence 06:00 do mesmo dia (esperado depois de 2026-10-14 09:00:00+00): ', v, E'\n');
  r := concat(r, '1c nunca passa de 24 h (esperado true): ', (_caixa_vence_em('2026-10-14 08:30:00+00') <= '2026-10-14 08:30:00+00'::timestamptz + interval '24 hours'), E'\n');

  -- 2) caixa de 25 h: vencido; venda nova de balcão é recusada
  update caixa_sessoes set abertura = now() - interval '25 hours' where id = cx;
  delete from caixa_liberacoes where caixa_id = cx;
  r := concat(r, '2a _caixa_vencido com 25 h (esperado true): ', _caixa_vencido(cx), E'\n');
  perform set_config('request.jwt.claims', json_build_object('sub', adm, 'role', 'authenticated')::text, true);
  set local role authenticated;
  x := api_iniciar_venda(jsonb_build_object('itens', itens, 'pagamentos', pags, 'tipoEntrega', 'Retirada'));
  r := concat(r, '2b venda com caixa vencido (esperado ok=false e "vencido"): ', (x->>'ok'), ' | ', left(coalesce(x->>'message',''), 70), E'\n');
  x := api_add_sangria(jsonb_build_object('valor', 1, 'motivo', 'teste'));
  r := concat(r, '2c sangria com caixa vencido (esperado ok=false): ', (x->>'ok'), ' | ', left(coalesce(x->>'message',''), 60), E'\n');
  x := api_caixa_liberar(jsonb_build_object('horas', 4, 'motivo', ''));
  r := concat(r, '3a liberar sem motivo (esperado ok=false): ', (x->>'ok'), E'\n');
  x := api_caixa_liberar(jsonb_build_object('horas', 99, 'motivo', 'teste de limite'));
  r := concat(r, '3b liberar por 99 h (esperado ok=false, máximo 12): ', (x->>'ok'), E'\n');
  reset role;

  -- 3) só Admin libera
  perform set_config('request.jwt.claims', json_build_object('sub', opr, 'role', 'authenticated')::text, true);
  set local role authenticated;
  x := api_caixa_liberar(jsonb_build_object('horas', 4, 'motivo', 'operador tentando'));
  r := concat(r, '3c Operador tenta liberar (esperado ok=false): ', (x->>'ok'), E'\n');
  reset role;
  perform set_config('request.jwt.claims', json_build_object('sub', gar, 'role', 'authenticated')::text, true);
  set local role authenticated;
  x := api_iniciar_venda(jsonb_build_object('itens', itens, 'pagamentos', pags, 'tipoEntrega', 'Retirada'));
  r := concat(r, '3d Garçom com caixa vencido (esperado "chame o responsável"): ', left(coalesce(x->>'message',''), 60), E'\n');
  reset role;

  -- 4) liberação de 4 h: libera; expirada: trava de novo
  perform set_config('request.jwt.claims', json_build_object('sub', adm, 'role', 'authenticated')::text, true);
  set local role authenticated;
  x := api_caixa_liberar(jsonb_build_object('horas', 4, 'motivo', 'teste de liberação'));
  r := concat(r, '4a liberar 4 h (esperado ok=true): ', (x->>'ok'), E'\n');
  reset role;
  r := concat(r, '4b vencido durante a liberação (esperado false): ', _caixa_vencido(cx), E'\n');
  r := concat(r, '4c view v_sessao_aberta mostra liberado_ate (esperado true): ', (select liberado_ate is not null from caixa_sessoes s join lateral (select ate as liberado_ate from caixa_liberacoes l where l.caixa_id = s.id and l.ate > now() order by ate desc limit 1) q on true where s.id = cx), E'\n');
  update caixa_liberacoes set ate = now() - interval '1 minute' where caixa_id = cx;
  r := concat(r, '4d vencido depois que a liberação expira (esperado true): ', _caixa_vencido(cx), E'\n');
  r := concat(r, '4e auditoria registrou a liberação (esperado >= 1): ', (select count(*) from auditoria where acao = 'Caixa vencido liberado' and data_hora > now() - interval '5 minutes'), E'\n');

  -- 5) caixa novo (1 h) não vence
  update caixa_sessoes set abertura = now() - interval '1 hour' where id = cx;
  r := concat(r, '5 caixa de 1 h (esperado false): ', _caixa_vencido(cx), E'\n');

  -- 6) pedido externo nunca trava: as funções de entrada do iFood e do cardápio não consultam o vencimento
  r := concat(r, '6a api_criar_pedido_cardapio NÃO usa _caixa_vencido (esperado true): ', (position('_caixa_vencido' in pg_get_functiondef('public.api_criar_pedido_cardapio(jsonb)'::regprocedure)) = 0), E'\n');
  r := concat(r, '6b api_iniciar_venda, fechar conta de mesa, sangria e resgate USAM (esperado 4x true): ',
    (position('_caixa_vencido' in pg_get_functiondef('public.api_iniciar_venda(jsonb)'::regprocedure)) > 0), ' ',
    (position('_caixa_vencido' in pg_get_functiondef('public.api_fechar_conta_mesa(jsonb)'::regprocedure)) > 0), ' ',
    (position('_caixa_vencido' in pg_get_functiondef('public.api_add_sangria(jsonb)'::regprocedure)) > 0), ' ',
    (position('_caixa_vencido' in pg_get_functiondef('public.api_registrar_brinde(jsonb)'::regprocedure)) > 0), E'\n');
  raise exception E'RELATORIO\n%', r;
end $t$;
