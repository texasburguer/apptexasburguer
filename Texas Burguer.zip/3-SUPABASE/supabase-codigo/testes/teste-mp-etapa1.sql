-- TESTE DA ETAPA 1 DO MERCADO PAGO (não grava nada: termina com erro de propósito e desfaz tudo). Cole no SQL Editor
-- DEPOIS de rodar 2026-10-13-mp-etapa1-estrutura.sql. O erro "RELATORIO {...}" no fim é o resultado.
-- Esperado:
--   mp_ligado=false, mp_modo=homologacao, chave_estranha=recusou, online_sem_tipo=recusou, tipo_debito=recusou,
--   itens_checklist: mercadopago=5 (ifood=7 e nfce=8 continuam iguais),
--   pendencias: inicio=5, com_chaves_e_webhook=3, com_teste_pix_e_credito=2,
--   publica: desligado=false, ligado_teste_sem_liberar=false, ligado_teste_liberado=true (com chave pública e 1 forma),
--            vazou_token=false, producao_sem_chave=false, producao_com_chave=true,
--   rls: anon=recusou, authenticated=recusou, flags: mercadopago=true e impostoPadrao presente.
do $$
declare r jsonb := '{}'::jsonb; v jsonb; v_forma uuid; v_res uuid; adm uuid; n int;
begin
  -- 1) linha criada e desligada
  r := r || jsonb_build_object('mp_ligado', (select ligado from integracoes_config where provedor = 'mercadopago'),
                               'mp_modo', (select modo from integracoes_config where provedor = 'mercadopago'));

  -- 2) segredos: chave nova aceita, chave estranha recusada
  insert into integracoes_segredos (chave, valor) values ('mp_public_key_teste', 'TEST-chave-publica-1234')
    on conflict (chave) do update set valor = excluded.valor;
  begin
    insert into integracoes_segredos (chave, valor) values ('chave_estranha', 'xxxxxxxxxx');
    r := r || '{"chave_estranha": "ACEITOU (ruim)"}'::jsonb;
  exception when check_violation then r := r || '{"chave_estranha": "recusou"}'::jsonb; end;

  -- 3) formas de pagamento
  select id into v_forma from formas_pagamento where ativa and visivel_cardapio order by ordem limit 1;
  if v_forma is null then raise exception 'Sem forma de pagamento ativa para testar.'; end if;
  begin
    update formas_pagamento set aceita_online = true where id = v_forma;
    r := r || '{"online_sem_tipo": "ACEITOU (ruim)"}'::jsonb;
  exception when check_violation then r := r || '{"online_sem_tipo": "recusou"}'::jsonb; end;
  begin
    update formas_pagamento set tipo_online = 'debito' where id = v_forma;
    r := r || '{"tipo_debito": "ACEITOU (ruim)"}'::jsonb;
  exception when check_violation then r := r || '{"tipo_debito": "recusou"}'::jsonb; end;
  update formas_pagamento set aceita_online = true, tipo_online = 'pix' where id = v_forma;

  -- 4) checklist e pendências
  r := r || jsonb_build_object('itens_checklist', jsonb_build_object('mercadopago', jsonb_array_length(_integ_checklist_def('mercadopago')),
      'ifood', jsonb_array_length(_integ_checklist_def('ifood')), 'nfce', jsonb_array_length(_integ_checklist_def('nfce'))));
  n := coalesce(array_length(_integ_pendencias('mercadopago', 'homologacao'), 1), 0);
  insert into integracoes_segredos (chave, valor) values ('mp_access_token_teste', 'APP_USR-segredo-9999'), ('mp_webhook_secret', 'segredo-webhook-9999')
    on conflict (chave) do update set valor = excluded.valor;
  insert into pedidos_reserva (user_id, itens, valor_total, expira_em) values (gen_random_uuid(), '[]'::jsonb, 10, now() + interval '15 minutes') returning id into v_res;
  r := r || jsonb_build_object('pendencias', jsonb_build_object('inicio', n, 'com_chaves_e_webhook', coalesce(array_length(_integ_pendencias('mercadopago', 'homologacao'), 1), 0)));
  insert into pagamentos_online (reserva_id, metodo, mp_modo, status, valor) values (v_res, 'pix', 'homologacao', 'aprovado', 10), (v_res, 'credito', 'homologacao', 'aprovado', 10);
  r := r || jsonb_build_object('pendencias', (r->'pendencias') || jsonb_build_object('com_teste_pix_e_credito', coalesce(array_length(_integ_pendencias('mercadopago', 'homologacao'), 1), 0)));

  -- 5) leitura pública (como cliente anônimo)
  execute 'set local role anon';
  v := public.api_mp_config_publica('{}'::jsonb);
  execute 'reset role';
  r := r || jsonb_build_object('publica', jsonb_build_object('desligado', v->'ligado'));

  update integracoes_config set ligado = true where provedor = 'mercadopago';
  execute 'set local role anon';
  v := public.api_mp_config_publica('{}'::jsonb);
  execute 'reset role';
  r := jsonb_set(r, '{publica,ligado_teste_sem_liberar}', coalesce(v->'ligado', 'null'::jsonb));

  update integracoes_config set config = config || '{"testeNoCardapio": true}'::jsonb where provedor = 'mercadopago';
  execute 'set local role anon';
  v := public.api_mp_config_publica('{}'::jsonb);
  execute 'reset role';
  r := jsonb_set(r, '{publica,ligado_teste_liberado}', coalesce(v->'ligado', 'null'::jsonb));
  r := jsonb_set(r, '{publica,chave_publica}', coalesce(v->'publicKey', 'null'::jsonb));
  r := jsonb_set(r, '{publica,formas}', to_jsonb(jsonb_array_length(coalesce(v->'formas', '[]'::jsonb))));
  r := jsonb_set(r, '{publica,vazou_token}', to_jsonb(position('segredo-9999' in v::text) > 0));

  update integracoes_config set modo = 'producao' where provedor = 'mercadopago';
  execute 'set local role anon';
  v := public.api_mp_config_publica('{}'::jsonb);
  execute 'reset role';
  r := jsonb_set(r, '{publica,producao_sem_chave}', coalesce(v->'ligado', 'null'::jsonb));
  insert into integracoes_segredos (chave, valor) values ('mp_public_key_producao', 'APP_USR-chave-publica-5678')
    on conflict (chave) do update set valor = excluded.valor;
  execute 'set local role anon';
  v := public.api_mp_config_publica('{}'::jsonb);
  execute 'reset role';
  r := jsonb_set(r, '{publica,producao_com_chave}', coalesce(v->'ligado', 'null'::jsonb));

  -- 6) as tabelas novas não podem ser lidas por anônimo nem por usuário logado
  r := r || jsonb_build_object('rls', '{}'::jsonb);
  begin
    execute 'set local role anon';
    perform 1 from pagamentos_online limit 1;
    execute 'reset role';
    r := jsonb_set(r, '{rls,anon}', '"LEU (ruim)"'::jsonb);
  exception when insufficient_privilege then
    execute 'reset role';
    r := jsonb_set(r, '{rls,anon}', '"recusou"'::jsonb);
  end;
  begin
    execute 'set local role authenticated';
    perform 1 from pedidos_reserva limit 1;
    execute 'reset role';
    r := jsonb_set(r, '{rls,authenticated}', '"LEU (ruim)"'::jsonb);
  exception when insufficient_privilege then
    execute 'reset role';
    r := jsonb_set(r, '{rls,authenticated}', '"recusou"'::jsonb);
  end;

  -- 7) flags da equipe (como Admin)
  select u.id into adm from usuarios u where u.nivel::text in ('Admin', 'Desenvolvedor') and u.ativo limit 1;
  perform set_config('request.jwt.claims', json_build_object('sub', adm, 'role', 'authenticated')::text, true);
  execute 'set local role authenticated';
  v := public.api_integracoes_flags('{}'::jsonb);
  execute 'reset role';
  r := r || jsonb_build_object('flags', jsonb_build_object('mercadopago', v->'mercadopago', 'impostoPadrao_presente', v ? 'impostoPadrao', 'ifood_presente', v ? 'ifood'));

  raise exception 'RELATORIO %', r::text;
end $$;
