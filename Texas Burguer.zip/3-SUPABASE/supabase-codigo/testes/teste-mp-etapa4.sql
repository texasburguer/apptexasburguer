-- TESTE DA ETAPA 4 DO MERCADO PAGO (não grava nada: termina com erro de propósito e desfaz tudo). Cole no SQL Editor
-- DEPOIS de rodar as Etapas 1 e 2 e 2026-10-13-mp-etapa4-painel.sql. O erro "RELATORIO {...}" no fim é o resultado.
-- Esperado (supondo que ainda não existam chaves do Mercado Pago cadastradas; se já existirem, só "inicio" muda):
--   pendencias: inicio_teste=3, inicio_producao=5, com_chaves_teste_webhook_e_conta=0 (teste), producao_so_com_teste=2, producao_completa=0,
--   config: validade_3=recusou, validade_20=ok, email_invalido=recusou, emails_teste_minusculos=true, email_pagador=ok,
--   formas: pix_ok=true, segundo_pix=recusou (ou n/a se só houver 1 forma), troco=recusou (ou n/a), desligar_forma=true,
--   status: formas_na_lista>=1, podeLigarTeste/podeLigarProducao presentes, segredos_mp>=1,
--   publica: sem_lista=false, com_email_na_lista=true, outro_usuario=false, mostrar_a_todos=true, producao=true,
--   preparar: email_do_pagador=o e-mail de teste, pagamento_criado=true,
--   saude: mercadopago_presente=true (nivel ok), recentes: itens>=2, testePix=true (o teste cria 2 pagamentos aprovados de mentira), a_decidir=0,
--   senha: ligar_sem_senha=recusou.
do $$
declare r jsonb := '{}'::jsonb; v jsonb; adm uuid; n_formas int; f1 uuid; f2 uuid; f_troco uuid; v_user uuid; v_email text; v_res uuid; v_forma_pix uuid;
begin
  select u.id into adm from usuarios u where u.nivel::text in ('Admin', 'Desenvolvedor') and u.ativo limit 1;
  if adm is null then raise exception 'Sem usuário Admin para testar.'; end if;
  perform set_config('request.jwt.claims', json_build_object('sub', adm, 'role', 'authenticated')::text, true);

  -- 1) pendências por ambiente
  r := r || jsonb_build_object('pendencias', jsonb_build_object('inicio_teste', coalesce(array_length(_integ_pendencias('mercadopago', 'homologacao'), 1), 0),
                                                              'inicio_producao', coalesce(array_length(_integ_pendencias('mercadopago', 'producao'), 1), 0)));
  insert into integracoes_segredos (chave, valor) values ('mp_public_key_teste', 'TEST-chave-publica-1234'), ('mp_access_token_teste', 'TEST-token-de-teste-1234567890-abcdef'),
    ('mp_webhook_secret', 'segredo-webhook-9999999999')
    on conflict (chave) do update set valor = excluded.valor;
  update integracoes_config set checklist = jsonb_set(coalesce(checklist, '{}'::jsonb), '{conta_vendedor}', 'true'::jsonb) where provedor = 'mercadopago';
  r := jsonb_set(r, '{pendencias,com_chaves_teste_webhook_e_conta}', to_jsonb(coalesce(array_length(_integ_pendencias('mercadopago', 'homologacao'), 1), 0)));
  r := jsonb_set(r, '{pendencias,producao_so_com_teste}', to_jsonb(coalesce(array_length(_integ_pendencias('mercadopago', 'producao'), 1), 0)));
  insert into integracoes_segredos (chave, valor) values ('mp_public_key_producao', 'APP_USR-chave-publica-prod-1234'), ('mp_access_token_producao', 'APP_USR-token-de-producao-1234567890-abcdef')
    on conflict (chave) do update set valor = excluded.valor;
  insert into pedidos_reserva (user_id, itens, valor_total, expira_em) values (gen_random_uuid(), '[]'::jsonb, 10, now() + interval '15 minutes') returning id into v_res;
  insert into pagamentos_online (reserva_id, metodo, mp_modo, status, valor) values (v_res, 'pix', 'homologacao', 'aprovado', 10), (v_res, 'credito', 'homologacao', 'aprovado', 10);
  r := jsonb_set(r, '{pendencias,producao_completa}', to_jsonb(coalesce(array_length(_integ_pendencias('mercadopago', 'producao'), 1), 0)));

  -- 2) ajustes (como Admin)
  execute 'set local role authenticated';
  v := api_integracoes_config(jsonb_build_object('provedor', 'mercadopago', 'config', jsonb_build_object('pixValidadeMin', 3)));
  r := r || jsonb_build_object('config', jsonb_build_object('validade_3', case when (v->>'ok') = 'true' then 'ACEITOU (ruim)' else 'recusou' end));
  v := api_integracoes_config(jsonb_build_object('provedor', 'mercadopago', 'config', jsonb_build_object('pixValidadeMin', 20)));
  r := jsonb_set(r, '{config,validade_20}', case when (v->>'ok') = 'true' then '"ok"'::jsonb else '"FALHOU"'::jsonb end);
  v := api_integracoes_config(jsonb_build_object('provedor', 'mercadopago', 'config', jsonb_build_object('emailsTeste', jsonb_build_array('isso-nao-e-email'))));
  r := jsonb_set(r, '{config,email_invalido}', case when (v->>'ok') = 'true' then '"ACEITOU (ruim)"'::jsonb else '"recusou"'::jsonb end);
  v := api_integracoes_config(jsonb_build_object('provedor', 'mercadopago', 'config', jsonb_build_object('emailPagadorTeste', 'Test_User_1@TestUser.com')));
  r := jsonb_set(r, '{config,email_pagador}', case when (v->>'ok') = 'true' then '"ok"'::jsonb else '"FALHOU"'::jsonb end);
  execute 'reset role';

  -- 3) formas online
  select count(*) into n_formas from formas_pagamento where ativa and visivel_cardapio and not permite_troco;
  select id into f1 from formas_pagamento where ativa and visivel_cardapio and not permite_troco order by ordem limit 1;
  select id into f2 from formas_pagamento where ativa and visivel_cardapio and not permite_troco and id <> f1 order by ordem limit 1;
  select id into f_troco from formas_pagamento where ativa and visivel_cardapio and permite_troco limit 1;
  update formas_pagamento set aceita_online = false, tipo_online = null where aceita_online;
  execute 'set local role authenticated';
  v := api_mp_forma_online(jsonb_build_object('formaId', f1, 'aceitaOnline', true, 'tipoOnline', 'pix'));
  r := r || jsonb_build_object('formas', jsonb_build_object('pix_ok', (v->>'ok') = 'true'));
  if f2 is not null then
    v := api_mp_forma_online(jsonb_build_object('formaId', f2, 'aceitaOnline', true, 'tipoOnline', 'pix'));
    r := jsonb_set(r, '{formas,segundo_pix}', case when (v->>'ok') = 'true' then '"ACEITOU (ruim)"'::jsonb else '"recusou"'::jsonb end);
  else r := jsonb_set(r, '{formas,segundo_pix}', '"n/a"'::jsonb); end if;
  if f_troco is not null then
    v := api_mp_forma_online(jsonb_build_object('formaId', f_troco, 'aceitaOnline', true, 'tipoOnline', 'credito'));
    r := jsonb_set(r, '{formas,troco}', case when (v->>'ok') = 'true' then '"ACEITOU (ruim)"'::jsonb else '"recusou"'::jsonb end);
  else r := jsonb_set(r, '{formas,troco}', '"n/a"'::jsonb); end if;
  execute 'reset role';
  v_forma_pix := f1;

  -- 4) status para o card
  execute 'set local role authenticated';
  v := api_integracoes_status('{}'::jsonb);
  execute 'reset role';
  r := r || jsonb_build_object('status', jsonb_build_object(
      'formas_na_lista', (select jsonb_array_length(x->'formas') from jsonb_array_elements(v->'integracoes') x where x->>'provedor' = 'mercadopago'),
      'podeLigarTeste', (select x->'podeLigarTeste' from jsonb_array_elements(v->'integracoes') x where x->>'provedor' = 'mercadopago'),
      'podeLigarProducao', (select x->'podeLigarProducao' from jsonb_array_elements(v->'integracoes') x where x->>'provedor' = 'mercadopago'),
      'segredos_mp', (select count(*) from jsonb_each((select x->'segredos' from jsonb_array_elements(v->'integracoes') x where x->>'provedor' = 'mercadopago')))));

  -- 5) quem vê o pagamento online no cardápio (modo Teste)
  select u.id, lower(u.email) into v_user, v_email from auth.users u where u.email is not null limit 1;
  update integracoes_config set ligado = true, modo = 'homologacao',
         config = (config - 'emailsTeste' - 'testeNoCardapio') where provedor = 'mercadopago';
  r := r || jsonb_build_object('publica', jsonb_build_object('sem_lista', _mp_publico(v_user)->'ligado'));
  update integracoes_config set config = config || jsonb_build_object('emailsTeste', jsonb_build_array(v_email)) where provedor = 'mercadopago';
  r := jsonb_set(r, '{publica,com_email_na_lista}', _mp_publico(v_user)->'ligado');
  r := jsonb_set(r, '{publica,outro_usuario}', _mp_publico(gen_random_uuid())->'ligado');
  update integracoes_config set config = (config - 'emailsTeste') || jsonb_build_object('testeNoCardapio', true) where provedor = 'mercadopago';
  r := jsonb_set(r, '{publica,mostrar_a_todos}', _mp_publico(null)->'ligado');
  update integracoes_config set modo = 'producao', config = config || jsonb_build_object('testeNoCardapio', false) where provedor = 'mercadopago';
  r := jsonb_set(r, '{publica,producao}', _mp_publico(null)->'ligado');

  -- 6) preparar pagamento em Teste: o e-mail do pagador vem do card
  update integracoes_config set modo = 'homologacao', config = config || jsonb_build_object('emailsTeste', jsonb_build_array(v_email), 'testeNoCardapio', false, 'emailPagadorTeste', 'test_user_1@testuser.com') where provedor = 'mercadopago';
  insert into pedidos_reserva (user_id, forma_pagamento_id, itens, valor_total, expira_em) values (v_user, v_forma_pix, '[]'::jsonb, 25, now() + interval '15 minutes') returning id into v_res;
  v := mp_preparar_pagamento(jsonb_build_object('reservaId', v_res, 'userId', v_user));
  r := r || jsonb_build_object('preparar', jsonb_build_object('email_do_pagador', v->>'email', 'pagamento_criado', (v->>'ok') = 'true' and (v->>'pagamentoId') is not null, 'erro', v->>'message'));

  -- 7) saúde e pagamentos recentes
  r := r || jsonb_build_object('saude', jsonb_build_object(
      'mercadopago_presente', exists (select 1 from jsonb_array_elements(_saude_integracoes()) x where x->>'id' = 'mercadopago'),
      'nivel', (select x->>'nivel' from jsonb_array_elements(_saude_integracoes()) x where x->>'id' = 'mercadopago')));
  execute 'set local role authenticated';
  v := api_mp_pagamentos_recentes('{}'::jsonb);
  execute 'reset role';
  r := r || jsonb_build_object('recentes', jsonb_build_object('itens', jsonb_array_length(v->'itens'), 'testePix', v->'testePix', 'a_decidir', v->'aDecidir'));

  -- 8) ligar sem a senha de administrador
  execute 'set local role authenticated';
  v := api_integracoes_ligar(jsonb_build_object('provedor', 'mercadopago', 'modo', 'homologacao'));
  execute 'reset role';
  r := r || jsonb_build_object('senha', jsonb_build_object('ligar_sem_senha', case when (v->>'ok') = 'true' then 'LIGOU (ruim)' else 'recusou' end));

  raise exception 'RELATORIO %', r::text;
end $$;
