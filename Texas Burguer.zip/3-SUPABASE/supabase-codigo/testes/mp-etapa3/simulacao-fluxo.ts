const handlers: Record<string, (r: Request) => Promise<Response>> = {}; let atual = "";
(globalThis as any).Deno = { serve: (h: any) => { handlers[atual] = h; }, env: { get: (k: string) => (k === "SUPABASE_URL" ? "https://x.supabase.co" : k === "SUPABASE_SERVICE_ROLE_KEY" ? "svc" : k === "SB_PUBLISHABLE_KEY" ? "pub" : undefined) } };
for (const f of ["mp-criar", "mp-webhook", "mp-status", "mp-reembolsar"]) { atual = f; await import(`./${f}/index.ts`); }
const hmac = (await import("./mp-criar/mp-puro.ts")).hmacHex;

const U1 = "11111111-1111-4111-8111-111111111111", RES = "22222222-2222-4222-8222-222222222222", PAG = "33333333-3333-4333-8333-333333333333", F_PIX = "44444444-4444-4444-8444-444444444444", F_CC = "55555555-5555-4555-8555-555555555555", VENDA = "66666666-6666-4666-8666-666666666666";
let ok = 0; const falhas: string[] = []; const t = (n: string, c: boolean) => { if (c) ok++; else falhas.push(n); };

function mundo(extra: any = {}) {
  const w: any = { tables: { pedidos_reserva: [{ id: RES, user_id: U1, forma_pagamento_id: F_PIX, estado: "ativa" }], formas_pagamento: [{ id: F_PIX, tipo_online: "pix" }, { id: F_CC, tipo_online: "credito" }],
    pagamentos_online: [], usuarios: [{ id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", nivel: "Admin", ativo: true }, { id: "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb", nivel: "Garçom", ativo: true }, { id: "cccccccc-cccc-4ccc-8ccc-cccccccccccc", nivel: "Operador", ativo: true }], reembolsos: [] },
    tokens: { "tok-cli": { id: U1, email: "cli@exemplo.com" }, "tok-adm": { id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", email: "a@x" }, "tok-garcom": { id: "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb", email: "g@x" }, "tok-op": { id: "cccccccc-cccc-4ccc-8ccc-cccccccccccc", email: "o@x" } },
    rpcs: [] as any[], updates: [] as any[], fetchs: [] as any[], logs: [] as string[], fetchH: null as any,
    rpcH: {
      mp_preparar_pagamento: async (a: any) => ({ ok: true, pagamentoId: PAG, metodo: w.metodo || "pix", modo: "homologacao", valor: 52.9, expiraEm: new Date(Date.now() + 14 * 60000).toISOString(), email: "cli@exemplo.com", nome: "Cliente" }),
      mp_credenciais: async (a: any) => ({ ligado: true, modoAtual: "homologacao", modo: a.p_modo || "homologacao", accessToken: "APP_USR-teste", webhookSecret: "segredo-do-webhook", publicKey: "pk" }),
      mp_aplicar_status: async (a: any) => w.aplicarRes ? w.aplicarRes(a.p) : ({ ok: true, status: a.p.status }),
      api_mp_status_pagamento: async (a: any, cli: string) => ({ ok: true, estado: "aguardando", reservaId: a.p.reservaId, _como: cli }),
    }, ...extra };
  (globalThis as any).__world = w;
  (globalThis as any).fetch = async (url: string, init: any) => { w.fetchs.push({ url, metodo: init?.method, headers: init?.headers, body: init?.body ? JSON.parse(init.body) : undefined }); const r = await w.fetchH(url, init); return new Response(JSON.stringify(r.body ?? {}), { status: r.status }); };
  console.log = (s: string) => { w.logs.push(String(s)); };
  return w;
}
let seq = 0;
const novoCliente = (w: any) => { seq++; const id = `aaaa${String(seq).padStart(4, "0")}-0000-4000-8000-000000000000`; const tok = "tok-n" + seq; w.tokens[tok] = { id, email: "n" + seq + "@x.com" }; w.tables.pedidos_reserva[0].user_id = id; return tok; };
const chama = async (fn: string, corpo: any, tok?: string, extraHeaders: any = {}, url = "https://f/x") => handlers[fn](new Request(url, { method: "POST", headers: { "content-type": "application/json", ...(tok ? { authorization: "Bearer " + tok } : {}), ...extraHeaders }, body: JSON.stringify(corpo) }));
const ult = (w: any, fn: string) => [...w.rpcs].reverse().find((r) => r.fn === fn);

// ===== mp-criar: Pix =====
let w = mundo();
w.fetchH = async () => ({ status: 201, body: { id: "ORD1", status: "action_required", status_detail: "waiting_transfer", external_reference: PAG, transactions: { payments: [{ id: "PAY1", status: "action_required", status_detail: "waiting_transfer", date_of_expiration: "2026-10-13T12:30:00.000-03:00", payment_method: { id: "pix", type: "bank_transfer", qr_code: "000201COPIA", qr_code_base64: "QRB64" } }] } } });
let r = await chama("mp-criar", { reservaId: RES }, "tok-cli"); let j = await r.json();
t("pix: estado aguardando com QR", r.status === 200 && j.ok && j.estado === "aguardando" && j.pix.copiaCola === "000201COPIA" && j.pix.qrBase64 === "QRB64" && j.metodo === "pix");
let mp = w.fetchs[0];
t("pix: POST /v1/orders com valor em texto, external_reference e idempotência = id do pagamento", mp.url.endsWith("/v1/orders") && mp.body.total_amount === "52.90" && mp.body.transactions.payments[0].amount === "52.90" && mp.body.external_reference === PAG && mp.headers["X-Idempotency-Key"] === PAG);
t("pix: vencimento mínimo de 30 min", mp.body.transactions.payments[0].expiration_time === "PT30M" && mp.body.transactions.payments[0].payment_method.id === "pix");
t("pix: access token vai no cabeçalho e não no corpo", mp.headers.Authorization === "Bearer APP_USR-teste" && !JSON.stringify(mp.body).includes("APP_USR"));
t("pix: banco recebeu o QR e o status", ult(w, "mp_aplicar_status").args.p.pixCopiaCola === "000201COPIA" && ult(w, "mp_aplicar_status").args.p.status === "aguardando" && ult(w, "mp_aplicar_status").args.p.mpOrderId === "ORD1");
t("pix: devolve o vencimento da reserva (cronômetro de 15 min)", !!j.reservaExpiraEm);

// ===== mp-criar: sem login / reserva de outro =====
w = mundo(); r = await chama("mp-criar", { reservaId: RES }); t("criar sem login = 401", r.status === 401);
w = mundo(); w.tokens["tok-outro"] = { id: "99999999-9999-4999-8999-999999999999", email: "o@x" }; r = await chama("mp-criar", { reservaId: RES }, "tok-outro"); j = await r.json();
t("criar com reserva de outro cliente é recusado antes de chamar o banco de pagamentos", j.ok === false && !w.rpcs.find((x: any) => x.fn === "mp_preparar_pagamento") && w.fetchs.length === 0);
w = mundo(); r = await chama("mp-criar", { reservaId: "abc" }, "tok-cli"); t("criar com id inválido = 400", r.status === 400);

// ===== mp-criar: cartão =====
const cartaoBody = { reservaId: RES, token: "cardtoken1234567890", paymentMethodId: "master", paymentTypeId: "credit_card", payerCpf: "529.982.247-25" };
w = mundo(); w.tables.pedidos_reserva[0].forma_pagamento_id = F_CC; w.metodo = "credito";
w.fetchH = async () => ({ status: 201, body: { id: "ORD2", status: "processed", status_detail: "accredited", external_reference: PAG, transactions: { payments: [{ id: "PAY2", status: "processed", status_detail: "accredited", payment_method: { id: "master", type: "credit_card", last_four_digits: "4321" } }] } } });
w.aplicarRes = (p: any) => ({ ok: true, status: p.status, resultado: { ok: true, vendaId: VENDA, numero: 77 } });
r = await chama("mp-criar", cartaoBody, "tok-cli"); j = await r.json(); mp = w.fetchs[0];
t("cartão aprovado: estado aprovado com número do pedido", j.ok && j.estado === "aprovado" && j.numero === 77 && j.vendaId === VENDA);
t("cartão: corpo ao MP com token, 1 parcela, CPF só dígitos", mp.body.transactions.payments[0].payment_method.token === "cardtoken1234567890" && mp.body.transactions.payments[0].payment_method.installments === 1 && mp.body.transactions.payments[0].payment_method.type === "credit_card" && mp.body.payer.identification.number === "52998224725" && mp.body.payer.identification.type === "CPF" && mp.body.payer.email === "cli@exemplo.com");
t("cartão: log não tem token nem CPF", !w.logs.join("\n").includes("cardtoken") && !w.logs.join("\n").includes("52998224725") && !w.logs.join("\n").includes("APP_USR"));
t("cartão: final e bandeira vão ao banco", ult(w, "mp_aplicar_status").args.p.cartaoFinal === "4321" && ult(w, "mp_aplicar_status").args.p.cartaoBandeira === "master");

w = mundo(); w.tables.pedidos_reserva[0].forma_pagamento_id = F_CC; w.metodo = "credito"; w.fetchH = async () => ({ status: 201, body: {} });
r = await chama("mp-criar", { ...cartaoBody, payerCpf: "111.111.111-11" }, "tok-cli"); j = await r.json();
t("cartão com CPF inválido: recusa ANTES de gastar tentativa", j.ok === false && /CPF/.test(j.message) && !w.rpcs.find((x: any) => x.fn === "mp_preparar_pagamento") && w.fetchs.length === 0);
w = mundo(); w.tables.pedidos_reserva[0].forma_pagamento_id = F_CC; r = await chama("mp-criar", { ...cartaoBody, paymentTypeId: "debit_card" }, "tok-cli"); j = await r.json(); t("débito é recusado", j.ok === false && /crédito/.test(j.message));
w = mundo(); w.tables.pedidos_reserva[0].forma_pagamento_id = F_CC; r = await chama("mp-criar", { reservaId: RES }, "tok-cli"); j = await r.json(); t("cartão sem token é recusado", j.ok === false && w.fetchs.length === 0);

w = mundo(); w.tables.pedidos_reserva[0].forma_pagamento_id = F_CC; w.metodo = "credito";
w.fetchH = async () => ({ status: 201, body: { id: "ORD3", status: "failed", status_detail: "failed", transactions: { payments: [{ id: "PAY3", status: "failed", status_detail: "insufficient_amount", payment_method: { id: "visa", type: "credit_card" } }] } } });
r = await chama("mp-criar", cartaoBody, "tok-cli"); j = await r.json();
t("cartão recusado: estado recusado com texto amigável", j.estado === "recusado" && /limite/.test(j.mensagem) && !JSON.stringify(j).includes("insufficient_amount"));
t("cartão recusado: não solta a reserva (status recusado, não erro)", ult(w, "mp_aplicar_status").args.p.status === "recusado");

w = mundo(); w.tables.pedidos_reserva[0].forma_pagamento_id = F_CC; w.metodo = "credito"; w.fetchH = async () => ({ status: 400, body: { errors: [{ code: "invalid_token", message: "x" }] } });
r = await chama("mp-criar", cartaoBody, "tok-cli"); j = await r.json(); t("HTTP 400 no cartão: recusado e pode tentar de novo", j.estado === "recusado" && ult(w, "mp_aplicar_status").args.p.status === "recusado");

w = mundo(); w.tables.pedidos_reserva[0].forma_pagamento_id = F_CC; w.metodo = "credito";
w.fetchH = async () => ({ status: 201, body: { id: "ORD4", status: "processed", status_detail: "accredited", transactions: { payments: [{ id: "P4", status: "processed", status_detail: "accredited", payment_method: { id: "master", type: "credit_card" } }] } } });
w.aplicarRes = (p: any) => ({ ok: true, status: p.status, resultado: { ok: true, decidir: true, motivo: "Caixa fechado quando o pagamento foi aprovado" } });
r = await chama("mp-criar", cartaoBody, "tok-cli"); j = await r.json(); t("aprovado mas caiu em 'Pagamento a decidir': cliente vê 'conferindo', nunca 'erro'", j.estado === "conferindo" && !/Caixa fechado/.test(JSON.stringify(j)));

// ===== mp-criar: Mercado Pago fora do ar =====
w = mundo(); let n = 0; w.fetchH = async () => { n++; return { status: 503, body: {} }; }; const setT = globalThis.setTimeout; (globalThis as any).setTimeout = (f: any, ms: number, ...a: any[]) => setT(f, ms > 1000 && ms < 5000 ? 1 : ms, ...a);
r = await chama("mp-criar", { reservaId: RES }, "tok-cli"); j = await r.json();
t("MP 503: tenta 2 vezes com a MESMA chave e solta a reserva (estado erro)", n === 2 && w.fetchs[0].headers["X-Idempotency-Key"] === w.fetchs[1].headers["X-Idempotency-Key"] && j.estado === "erro" && /entrega/.test(j.mensagem) && ult(w, "mp_aplicar_status").args.p.status === "erro");
w = mundo(); w.fetchH = async () => { throw new Error("rede"); }; (globalThis as any).fetch = async () => { throw new Error("rede"); };
r = await chama("mp-criar", { reservaId: RES }, "tok-cli"); j = await r.json(); t("rede fora: estado erro e reserva solta", j.estado === "erro" && ult(w, "mp_aplicar_status").args.p.status === "erro");
w = mundo({}); w.rpcH.mp_credenciais = async () => ({ ligado: true, accessToken: null }); w.fetchH = async () => ({ status: 201, body: {} }); r = await chama("mp-criar", { reservaId: RES }, "tok-cli"); j = await r.json(); t("sem Access Token cadastrado: erro e reserva solta, sem chamar o MP", j.estado === "erro" && w.fetchs.length === 0);
w = mundo(); w.rpcH.mp_preparar_pagamento = async () => ({ ok: false, message: "O tempo deste pedido acabou. Faça o pedido de novo." }); r = await chama("mp-criar", { reservaId: RES }, novoCliente(w)); j = await r.json(); t("banco recusa (tempo acabou): repassa a mensagem", j.ok === false && /tempo/.test(j.message));
w = mundo(); w.rpcH.mp_preparar_pagamento = async () => ({ ok: true, reaproveitar: true, pagamentoId: PAG, metodo: "pix", valor: 52.9, pixCopiaCola: "COPIA-VELHA", pixQrBase64: "QR-VELHO", pixExpiraEm: "2026-10-13T12:30:00-03:00" }); r = await chama("mp-criar", { reservaId: RES }, novoCliente(w)); j = await r.json();
t("Pix ainda valendo é reaproveitado sem falar com o MP", j.reaproveitado === true && j.pix.copiaCola === "COPIA-VELHA" && w.fetchs.length === 0);
// Pix substituído é cancelado no MP
w = mundo(); w.tables.pagamentos_online = [{ id: "77777777-7777-4777-8777-777777777777", reserva_id: RES, metodo: "pix", status: "cancelado", status_detalhe: "substituído por nova tentativa", mp_order_id: "ORDVELHA" }];
w.fetchH = async (u: string) => u.endsWith("/cancel") ? { status: 200, body: {} } : { status: 201, body: { id: "ORDNOVA", status: "action_required", transactions: { payments: [{ id: "P", status: "action_required", status_detail: "waiting_transfer", payment_method: { id: "pix", type: "bank_transfer", qr_code: "NOVO", qr_code_base64: "Q" } }] } } };
r = await chama("mp-criar", { reservaId: RES }, novoCliente(w)); await r.json();
t("Pix antigo substituído é cancelado no Mercado Pago", w.fetchs.some((x: any) => x.url.endsWith("/v1/orders/ORDVELHA/cancel")));

w = mundo(); w.fetchH = async () => ({ status: 201, body: {} }); { const tk = novoCliente(w); let ultimo = 0; for (let i = 0; i < 14; i++) { const x = await chama("mp-criar", { reservaId: "abc" }, tk); ultimo = x.status; } t("freio: depois de 12 chamadas por minuto o cliente leva 429", ultimo === 429); }

// ===== mp-webhook =====
const assina = async (w: any, dataId: string, reqId = "req-1", ts = "1742505638683", segredo = "segredo-do-webhook") => ({ "x-signature": `ts=${ts},v1=${await hmac(segredo, `id:${dataId};request-id:${reqId};ts:${ts};`)}`, "x-request-id": reqId });
const pedidoPago = { id: "ORD01XPAGO0001", status: "processed", status_detail: "accredited", external_reference: PAG, transactions: { payments: [{ id: "PAYX", status: "processed", status_detail: "accredited", payment_method: { id: "pix", type: "bank_transfer" } }] } };
const avisoCorpo = { action: "order.processed", type: "order", data: { id: "ORD01XPAGO0001" }, date_created: "2026-10-13T15:00:00Z", live_mode: false };
w = mundo(); w.fetchH = async () => ({ status: 200, body: pedidoPago });
r = await chama("mp-webhook", avisoCorpo, undefined, await assina(w, "ORD01XPAGO0001"), "https://f/mp-webhook?data.id=ORD01XPAGO0001&type=order"); j = await r.json();
t("webhook válido: 200 e status aprovado entregue ao banco com chave do evento", r.status === 200 && j.ok && ult(w, "mp_aplicar_status").args.p.status === "aprovado" && ult(w, "mp_aplicar_status").args.p.assinaturaOk === true && /^order:ORD01XPAGO0001:order.processed:/.test(ult(w, "mp_aplicar_status").args.p.chaveEvento) && ult(w, "mp_aplicar_status").args.p.pagamentoId === PAG);
t("webhook: consultou o pedido no MP (não confia no corpo do aviso)", w.fetchs.length === 1 && w.fetchs[0].metodo === "GET" && w.fetchs[0].url.endsWith("/v1/orders/ORD01XPAGO0001"));
w = mundo(); w.fetchH = async () => ({ status: 200, body: pedidoPago });
r = await chama("mp-webhook", avisoCorpo, undefined, await assina(w, "ORD01XPAGO0001", "req-1", "1742505638683", "segredo-errado"), "https://f/mp-webhook?data.id=ORD01XPAGO0001&type=order");
t("webhook com assinatura inválida: 401, só registra, não consulta nem aprova", r.status === 401 && w.fetchs.length === 0 && ult(w, "mp_aplicar_status").args.p.assinaturaOk === false && !w.rpcs.some((x: any) => x.fn === "mp_aplicar_status" && x.args.p.status));
w = mundo(); r = await chama("mp-webhook", avisoCorpo, undefined, {}, "https://f/mp-webhook?data.id=ORD01XPAGO0001&type=order"); t("webhook sem assinatura: 401", r.status === 401 && w.fetchs.length === 0);
w = mundo(); w.rpcH.mp_credenciais = async () => ({ ligado: true, webhookSecret: null, accessToken: "t" }); r = await chama("mp-webhook", avisoCorpo, undefined, await assina(w, "ORD01XPAGO0001"), "https://f/mp-webhook?data.id=ORD01XPAGO0001&type=order"); t("webhook sem chave secreta cadastrada: 401", r.status === 401);
w = mundo(); w.fetchH = async () => ({ status: 404, body: { message: "not found" } });
r = await chama("mp-webhook", { ...avisoCorpo, data: { id: "ORDFALSO" } }, undefined, await assina(w, "ORDFALSO"), "https://f/mp-webhook?data.id=ORDFALSO&type=order"); j = await r.json(); t("'Simular' do painel (pedido que não existe): 200 sem mexer no banco", r.status === 200 && j.ignorado === "pedido_inexistente" && !w.rpcs.some((x: any) => x.fn === "mp_aplicar_status"));
w = mundo(); w.fetchH = async () => ({ status: 503, body: {} }); r = await chama("mp-webhook", avisoCorpo, undefined, await assina(w, "ORD01XPAGO0001"), "https://f/mp-webhook?data.id=ORD01XPAGO0001&type=order"); t("MP fora do ar ao consultar: 500 (o MP reenvia)", r.status === 500);
w = mundo(); w.fetchH = async () => ({ status: 200, body: pedidoPago }); w.rpcH.mp_aplicar_status = async () => { throw new Error("banco caiu"); }; r = await chama("mp-webhook", avisoCorpo, undefined, await assina(w, "ORD01XPAGO0001"), "https://f/mp-webhook?data.id=ORD01XPAGO0001&type=order"); t("banco fora do ar: 500 (o MP reenvia)", r.status === 500);
w = mundo(); r = await chama("mp-webhook", { ...avisoCorpo, type: "payment" }, undefined, await assina(w, "ORD01XPAGO0001"), "https://f/mp-webhook?data.id=ORD01XPAGO0001&type=payment"); j = await r.json(); t("outro tipo de aviso: 200 e ignora", r.status === 200 && j.ignorado === "tipo" && w.fetchs.length === 0);
w = mundo(); w.tables.pagamentos_online = [{ id: PAG, mp_order_id: "ORD01XPAGO0001", mp_modo: "producao" }]; w.fetchH = async () => ({ status: 200, body: { ...pedidoPago, external_reference: "texto-qualquer" } });
r = await chama("mp-webhook", avisoCorpo, undefined, await assina(w, "ORD01XPAGO0001"), "https://f/mp-webhook?data.id=ORD01XPAGO0001&type=order");
t("webhook usa o modo gravado no pagamento (produção) e acha o pagamento pelo número do pedido", ult(w, "mp_credenciais").args.p_modo === "producao" && ult(w, "mp_aplicar_status").args.p.pagamentoId === PAG);
w = mundo(); w.fetchH = async () => ({ status: 200, body: pedidoPago }); w.rpcH.mp_aplicar_status = async () => ({ ok: true, duplicado: true }); r = await chama("mp-webhook", avisoCorpo, undefined, await assina(w, "ORD01XPAGO0001"), "https://f/mp-webhook?data.id=ORD01XPAGO0001&type=order"); j = await r.json(); t("aviso repetido: 200 (duplicado)", r.status === 200 && j.duplicado === true);

// ===== mp-status =====
w = mundo(); w.tables.pagamentos_online = [{ id: PAG, reserva_id: RES, status: "aguardando", metodo: "pix", mp_modo: "homologacao", mp_order_id: "ORD01XPAGO0001", criado_em: "2026-10-13T15:00:00Z", atualizado_em: new Date(Date.now() - 20000).toISOString() }];
w.fetchH = async () => ({ status: 200, body: pedidoPago });
r = await chama("mp-status", { reservaId: RES }, "tok-cli"); j = await r.json();
t("status: aguardando parado há 20 s → consulta o MP e aplica o aprovado", w.fetchs.length === 1 && ult(w, "mp_aplicar_status").args.p.status === "aprovado" && j.ok === true);
t("status: a resposta final vem do banco COMO o cliente", ult(w, "api_mp_status_pagamento").cliente === "usuario" && j._como === "usuario");
w = mundo(); w.tables.pagamentos_online = [{ id: PAG, reserva_id: RES, status: "aguardando", metodo: "pix", mp_modo: "homologacao", mp_order_id: "ORD01XPAGO0001", criado_em: "x", atualizado_em: new Date().toISOString() }]; w.fetchH = async () => ({ status: 200, body: pedidoPago });
r = await chama("mp-status", { reservaId: RES }, "tok-cli"); t("status: atualizado agora há pouco → NÃO consulta o MP", w.fetchs.length === 0);
w = mundo(); w.tables.pagamentos_online = [{ id: PAG, reserva_id: RES, status: "aguardando", metodo: "pix", mp_modo: "homologacao", mp_order_id: "ORD01XPAGO0001", criado_em: "x", atualizado_em: new Date(Date.now() - 20000).toISOString() }]; w.fetchH = async () => ({ status: 200, body: { id: "ORD01XPAGO0001", status: "action_required", status_detail: "waiting_transfer", transactions: { payments: [{ id: "P", status: "action_required", status_detail: "waiting_transfer", payment_method: { id: "pix", type: "bank_transfer" } }] } } });
r = await chama("mp-status", { reservaId: RES }, "tok-cli"); t("status: ainda aguardando no MP → não aplica nada", !w.rpcs.some((x: any) => x.fn === "mp_aplicar_status"));
w = mundo(); w.tables.pagamentos_online = [{ id: PAG, reserva_id: RES, status: "cancelado", metodo: "pix", mp_modo: "homologacao", mp_order_id: "ORD01XPAGO0001", criado_em: "x", atualizado_em: new Date(Date.now() - 60000).toISOString() }]; w.fetchH = async (u: string) => u.endsWith("/cancel") ? { status: 200, body: {} } : { status: 200, body: { id: "ORD01XPAGO0001", status: "action_required", transactions: { payments: [{ id: "P", status: "action_required", status_detail: "waiting_transfer", payment_method: { id: "pix", type: "bank_transfer" } }] } } };
r = await chama("mp-status", { reservaId: RES }, "tok-cli"); t("status: Pix cancelado aqui mas aberto no MP → cancela lá também", w.fetchs.some((x: any) => x.url.endsWith("/v1/orders/ORD01XPAGO0001/cancel")));
w = mundo(); w.tokens["tok-outro"] = { id: "99999999-9999-4999-8999-999999999999", email: "o@x" }; r = await chama("mp-status", { reservaId: RES }, "tok-outro"); j = await r.json(); t("status: reserva de outro cliente é recusada", j.ok === false && !w.rpcs.some((x: any) => x.fn === "api_mp_status_pagamento"));
w = mundo(); r = await chama("mp-status", { reservaId: RES }); t("status sem login: 401", r.status === 401);

// ===== mp-reembolsar =====
const pagAprovado = (extra: any = {}) => ({ id: PAG, venda_id: VENDA, status: "aprovado", mp_modo: "homologacao", mp_order_id: "ORDR", mp_payment_id: "PAYR", valor: 52.9, valor_reembolsado: 0, decisao: "reembolsar", ...extra });
w = mundo(); w.tables.pagamentos_online = [pagAprovado()]; r = await chama("mp-reembolsar", { pagamentoId: PAG }, "tok-garcom"); t("garçom não reembolsa: 403", r.status === 403 && w.fetchs.length === 0);
w = mundo(); w.tables.pagamentos_online = [pagAprovado()]; r = await chama("mp-reembolsar", { pagamentoId: PAG }, "tok-cli"); t("cliente não reembolsa: 403", r.status === 403);
w = mundo(); w.tables.pagamentos_online = [pagAprovado()]; r = await chama("mp-reembolsar", { pagamentoId: PAG }); t("sem login: 403", r.status === 403);
w = mundo(); w.tables.pagamentos_online = [pagAprovado({ decisao: null })]; r = await chama("mp-reembolsar", { pagamentoId: PAG }, "tok-adm"); j = await r.json(); t("sem decisão e sem reembolso pendente: recusa e NÃO fala com o MP", j.ok === false && /decisão/.test(j.message) && w.fetchs.length === 0);
w = mundo(); w.tables.pagamentos_online = [pagAprovado({ decisao: null })]; w.tables.reembolsos = [{ id: "r1", venda_id: VENDA, status: "Pendente" }]; w.fetchH = async () => ({ status: 201, body: { id: "ORDR", status: "processed", status_detail: "refunded" } });
r = await chama("mp-reembolsar", { pagamentoId: PAG }, "tok-op"); j = await r.json(); mp = w.fetchs[0];
t("cancelamento de pedido pago (reembolso pendente) libera a devolução total, pelo Operador", j.ok && j.estado === "reembolsado" && mp.url.endsWith("/v1/orders/ORDR/refund") && mp.body === undefined);
t("devolução total: chave de idempotência fixa", mp.headers["X-Idempotency-Key"] === `ref-${PAG}-0-5290`);
t("devolução total: banco recebe 'reembolsado' com o valor todo", ult(w, "mp_aplicar_status").args.p.status === "reembolsado" && ult(w, "mp_aplicar_status").args.p.valorReembolsado === 52.9);
w = mundo(); w.tables.pagamentos_online = [pagAprovado()]; w.fetchH = async () => ({ status: 201, body: {} });
r = await chama("mp-reembolsar", { pagamentoId: PAG, valor: "10,50" }, "tok-adm"); j = await r.json(); mp = w.fetchs[0];
t("devolução parcial: manda id da transação e valor em texto", j.ok && j.estado === "reembolso_parcial" && mp.body.transactions[0].id === "PAYR" && mp.body.transactions[0].amount === "10.50" && j.restante === 42.4);
w = mundo(); w.tables.pagamentos_online = [pagAprovado({ status: "reembolso_parcial", valor_reembolsado: 10.5 })]; w.fetchH = async () => ({ status: 201, body: {} });
r = await chama("mp-reembolsar", { pagamentoId: PAG }, "tok-adm"); j = await r.json(); mp = w.fetchs[0];
t("devolver o que falta depois de uma parcial: vai como parcial do restante e fecha em 'reembolsado'", j.ok && mp.body.transactions[0].amount === "42.40" && j.estado === "reembolsado" && mp.headers["X-Idempotency-Key"] === `ref-${PAG}-1050-4240`);
w = mundo(); w.tables.pagamentos_online = [pagAprovado()]; r = await chama("mp-reembolsar", { pagamentoId: PAG, valor: 60 }, "tok-adm"); j = await r.json(); t("valor maior que o pago é recusado sem chamar o MP", j.ok === false && w.fetchs.length === 0);
w = mundo(); w.tables.pagamentos_online = [pagAprovado()]; r = await chama("mp-reembolsar", { pagamentoId: PAG, valor: 0 }, "tok-adm"); j = await r.json(); t("valor zero é recusado", j.ok === false && w.fetchs.length === 0);
w = mundo(); w.tables.pagamentos_online = [pagAprovado({ status: "reembolsado", valor_reembolsado: 52.9 })]; r = await chama("mp-reembolsar", { pagamentoId: PAG }, "tok-adm"); j = await r.json(); t("já devolvido por inteiro: recusa", j.ok === false && w.fetchs.length === 0);
w = mundo(); w.tables.pagamentos_online = [pagAprovado({ status: "aguardando" })]; r = await chama("mp-reembolsar", { pagamentoId: PAG }, "tok-adm"); j = await r.json(); t("pagamento não aprovado: recusa", j.ok === false && w.fetchs.length === 0);
w = mundo(); w.tables.pagamentos_online = [pagAprovado({ mp_payment_id: null })]; w.fetchH = async (u: string, i: any) => i.method === "GET" ? { status: 200, body: pedidoPago } : { status: 201, body: {} };
r = await chama("mp-reembolsar", { pagamentoId: PAG, valor: 5 }, "tok-adm"); j = await r.json(); t("parcial sem id da transação guardado: busca no pedido do MP", j.ok && w.fetchs[0].metodo === "GET" && w.fetchs[1].body.transactions[0].id === "PAYX");
w = mundo(); w.tables.pagamentos_online = [pagAprovado()]; w.fetchH = async () => ({ status: 400, body: { errors: [{ code: "x" }] } }); r = await chama("mp-reembolsar", { pagamentoId: PAG }, "tok-adm"); j = await r.json(); t("MP recusa a devolução: erro claro e o banco NÃO marca como devolvido", j.ok === false && !w.rpcs.some((x: any) => x.fn === "mp_aplicar_status"));
w = mundo(); w.tables.pagamentos_online = [pagAprovado()]; (globalThis as any).fetch = async () => { throw new Error("rede"); }; r = await chama("mp-reembolsar", { pagamentoId: PAG }, "tok-adm"); j = await r.json(); t("sem resposta do MP: avisa para conferir e diz que repetir é seguro", j.ok === false && /seguro/.test(j.message) && !w.rpcs.some((x: any) => x.fn === "mp_aplicar_status"));

// ===== CORS / método =====
w = mundo(); const op = await handlers["mp-criar"](new Request("https://f/x", { method: "OPTIONS", headers: { origin: "https://texasburguer.github.io" } })); t("CORS: OPTIONS libera a origem do cardápio", op.headers.get("access-control-allow-origin") === "https://texasburguer.github.io");
const op2 = await handlers["mp-criar"](new Request("https://f/x", { method: "OPTIONS", headers: { origin: "https://site-malicioso.com" } })); t("CORS: origem estranha não é liberada", op2.headers.get("access-control-allow-origin") !== "https://site-malicioso.com");
const gt = await handlers["mp-criar"](new Request("https://f/x", { method: "GET" })); t("GET na mp-criar: 405", gt.status === 405);

process.stdout.write(`OK: ${ok}  |  FALHAS: ${falhas.length}\n`); if (falhas.length) process.stdout.write(falhas.join("\n") + "\n");
