// Mini-Supabase em memória só para o teste de fluxo (não faz parte do pacote)
const W = () => (globalThis as any).__world;
function consulta(tabela: string) {
  const f: any = { filtros: [] as any[], ordem: null as any, lim: 0, upd: null as any };
  const linhas = () => {
    let l: any[] = (W().tables[tabela] || []).slice();
    for (const x of f.filtros) l = l.filter((r) => x.op === "eq" ? r[x.c] === x.v : x.op === "neq" ? r[x.c] !== x.v : x.op === "notnull" ? r[x.c] != null : true);
    if (f.ordem) l.sort((a, b) => (a[f.ordem.c] < b[f.ordem.c] ? 1 : -1) * (f.ordem.asc ? -1 : 1));
    if (f.lim) l = l.slice(0, f.lim);
    return l;
  };
  const q: any = {
    select: () => q, eq: (c: string, v: any) => { f.filtros.push({ op: "eq", c, v }); return q; }, neq: (c: string, v: any) => { f.filtros.push({ op: "neq", c, v }); return q; },
    not: (c: string, _o: string, _v: any) => { f.filtros.push({ op: "notnull", c }); return q; }, order: (c: string, o: any) => { f.ordem = { c, asc: o?.ascending !== false }; return q; }, limit: (n: number) => { f.lim = n; return q; },
    maybeSingle: async () => ({ data: linhas()[0] ?? null, error: null }), single: async () => ({ data: linhas()[0] ?? null, error: null }),
    update: (o: any) => { f.upd = o; return q; },
    then: (ok: any, ko: any) => Promise.resolve().then(() => { if (f.upd) { for (const r of linhas()) Object.assign(r, f.upd); W().updates.push({ tabela, upd: f.upd }); return { data: null, error: null }; } return { data: linhas(), error: null }; }).then(ok, ko),
  };
  return q;
}
function cliente(rotulo: string) {
  return {
    auth: { getUser: async (tok: string) => { const u = W().tokens[tok]; return { data: { user: u ? { id: u.id, email: u.email } : null } }; } },
    from: (t: string) => consulta(t),
    rpc: async (fn: string, args: any) => { W().rpcs.push({ cliente: rotulo, fn, args }); const h = W().rpcH[fn]; if (!h) return { data: null, error: { message: "sem handler " + fn } }; const d = await h(args, rotulo); return { data: d, error: null }; },
  };
}
export const createClient = (_u: string, _k: string, opts?: any) => cliente(opts?.global?.headers?.Authorization ? "usuario" : "servico");
