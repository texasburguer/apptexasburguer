import { cpfValido, duracaoPix, mapearStatus, traduzirOrder, validarAssinatura, hmacHex, lerAssinatura, dinheiro, mensagemRecusa, iguaisSeguro } from "../funcoes/mp-puro.ts";
let ok = 0, falhas: string[] = [];
const t = (nome: string, cond: boolean) => { if (cond) ok++; else falhas.push(nome); };

// CPF
t("cpf valido", cpfValido("529.982.247-25") && cpfValido("52998224725"));
t("cpf repetido", !cpfValido("111.111.111-11"));
t("cpf dv errado", !cpfValido("529.982.247-24"));
t("cpf curto", !cpfValido("1234"));
// duração do Pix: mínimo 30 min
t("pix 15 min vira 30", duracaoPix(15) === "PT30M");
t("pix 45", duracaoPix(44.2) === "PT45M");
t("dinheiro", dinheiro(12.5) === "12.50" && dinheiro(0.1 + 0.2) === "0.30");
// status
const casos: [string, string, string][] = [["processed","accredited","aprovado"],["processed","partially_refunded","reembolso_parcial"],["refunded","refunded","reembolsado"],
  ["failed","insufficient_amount","recusado"],["expired","expired","expirado"],["canceled","canceled_by_api","cancelado"],["action_required","waiting_transfer","aguardando"],
  ["action_required","pending_challenge","aguardando"],["created","","aguardando"],["processing","in_process","aguardando"],["algo_novo","","aguardando"],["PROCESSED","ACCREDITED","aprovado"]];
for (const [s, d, e] of casos) t(`status ${s}/${d}`, mapearStatus(s, d) === e);
// Pix criado
const pix = traduzirOrder({ id: "ORD01ABC", status: "action_required", status_detail: "waiting_transfer", external_reference: "5f1c1b0e-0000-4000-8000-000000000001", total_amount: "50.00",
  transactions: { payments: [{ id: "PAY01X", amount: "50.00", status: "action_required", status_detail: "waiting_transfer", date_of_expiration: "2026-10-13T12:30:00.000-03:00",
    payment_method: { id: "pix", type: "bank_transfer", ticket_url: "https://mp/ticket", qr_code: "000201...", qr_code_base64: "iVBOR..." } }] } });
t("pix aguardando", pix.status === "aguardando" && pix.pix?.copiaCola === "000201..." && pix.pix?.qrBase64 === "iVBOR..." && pix.paymentId === "PAY01X" && pix.orderId === "ORD01ABC" && pix.pix?.expiraEm.startsWith("2026-10-13"));
// Pix pago
const pago = traduzirOrder({ id: "ORD01ABC", status: "processed", status_detail: "accredited", total_paid_amount: "50.00", transactions: { payments: [{ id: "PAY01X", status: "processed", status_detail: "accredited", paid_amount: "50.00", payment_method: { id: "pix", type: "bank_transfer" } }] } });
t("pix aprovado", pago.status === "aprovado" && pago.valorPago === 50 && pago.pix === null);
// cartão aprovado e recusado
const cartao = traduzirOrder({ id: "ORD02", status: "processed", status_detail: "accredited", transactions: { payments: [{ id: "PAY02", status: "processed", status_detail: "accredited", payment_method: { id: "master", type: "credit_card", token: "SEGREDO", installments: 1, last_four_digits: "1234" } }] } });
t("cartão aprovado", cartao.status === "aprovado" && cartao.cartaoFinal === "1234" && cartao.cartaoBandeira === "master" && cartao.pix === null);
t("token do cartão não sai na tradução", !JSON.stringify(cartao).includes("SEGREDO"));
const recusado = traduzirOrder({ id: "ORD03", status: "failed", status_detail: "failed", transactions: { payments: [{ id: "PAY03", status: "failed", status_detail: "insufficient_amount", payment_method: { id: "visa", type: "credit_card" } }] } });
t("cartão recusado usa o detalhe da transação", recusado.status === "recusado" && recusado.detalheMp === "insufficient_amount" && /limite/.test(mensagemRecusa(recusado.detalheMp)));
t("final de cartão inválido ignorado", traduzirOrder({ transactions: { payments: [{ payment_method: { id: "visa", type: "credit_card", last_four_digits: "12ab" } }] } }).cartaoFinal === "");
// 3DS
const d3 = traduzirOrder({ status: "action_required", transactions: { payments: [{ status: "action_required", status_detail: "pending_challenge", payment_method: { id: "master", type: "credit_card", transaction_security: { url: "https://3ds.exemplo/x" } } }] } });
t("3DS vira aguardando com url", d3.status === "aguardando" && d3.desafio?.url === "https://3ds.exemplo/x");
t("3DS com url não-https é ignorada", traduzirOrder({ transactions: { payments: [{ payment_method: { transaction_security: { url: "http://x" } } }] } }).desafio === null);
// reembolso
const ref = traduzirOrder({ id: "ORD04", status: "processed", status_detail: "partially_refunded", transactions: { payments: [{ id: "P", status: "processed", status_detail: "partially_refunded" }], refunds: [{ amount: "10.00", status: "processed" }, { amount: "5.50", status: "processed" }, { amount: "99", status: "failed" }] } });
t("reembolso parcial soma só os que não falharam", ref.status === "reembolso_parcial" && ref.valorReembolsado === 15.5);
t("resposta vazia não quebra", traduzirOrder(null).status === "aguardando" && traduzirOrder({}).orderId === "");

// assinatura do aviso
const segredo = "chave-secreta-de-teste", ts = "1742505638683", reqId = "2066ca19-c6f1-498a-be75-1923005edd06", dataId = "ORD01M28P44G5FG8RJPM579EH56FV";
const v1 = await hmacHex(segredo, `id:${dataId};request-id:${reqId};ts:${ts};`);
t("assinatura válida", await validarAssinatura({ segredo, assinatura: `ts=${ts},v1=${v1}`, requestId: reqId, ids: [dataId] }));
const v1min = await hmacHex(segredo, `id:${dataId.toLowerCase()};request-id:${reqId};ts:${ts};`);
t("assinatura calculada com id em minúsculas também vale", await validarAssinatura({ segredo, assinatura: `ts=${ts},v1=${v1min}`, requestId: reqId, ids: [dataId] }));
t("segredo errado falha", !(await validarAssinatura({ segredo: "outro", assinatura: `ts=${ts},v1=${v1}`, requestId: reqId, ids: [dataId] })));
t("id trocado falha", !(await validarAssinatura({ segredo, assinatura: `ts=${ts},v1=${v1}`, requestId: reqId, ids: ["ORDOUTRO"] })));
t("request-id trocado falha", !(await validarAssinatura({ segredo, assinatura: `ts=${ts},v1=${v1}`, requestId: "outro", ids: [dataId] })));
t("ts trocado falha", !(await validarAssinatura({ segredo, assinatura: `ts=999,v1=${v1}`, requestId: reqId, ids: [dataId] })));
t("sem header falha", !(await validarAssinatura({ segredo, assinatura: null, requestId: reqId, ids: [dataId] })));
t("sem segredo falha", !(await validarAssinatura({ segredo: "", assinatura: `ts=${ts},v1=${v1}`, requestId: reqId, ids: [dataId] })));
t("header sem v1 falha", !(await validarAssinatura({ segredo, assinatura: `ts=${ts}`, requestId: reqId, ids: [dataId] })));
const v1sem = await hmacHex(segredo, `id:${dataId};ts:${ts};`);
t("sem request-id usa só o que existe", await validarAssinatura({ segredo, assinatura: `ts=${ts},v1=${v1sem}`, requestId: null, ids: [dataId] }));
t("v1 em maiúsculas vale", await validarAssinatura({ segredo, assinatura: `ts=${ts},v1=${v1.toUpperCase()}`, requestId: reqId, ids: [dataId] }));
t("lerAssinatura", JSON.stringify(lerAssinatura(" ts=1 , v1=abc ")) === JSON.stringify({ ts: "1", v1: "abc" }));
t("iguaisSeguro", iguaisSeguro("abc", "abc") && !iguaisSeguro("abc", "abd") && !iguaisSeguro("abc", "ab"));

console.log(`OK: ${ok}  |  FALHAS: ${falhas.length}`); if (falhas.length) { console.log(falhas.join("\n")); process.exit(1); }
