#!/bin/bash
# Roda os testes locais da Etapa 3 (precisa de Node 22+). Não usa internet, não toca no Supabase nem no Mercado Pago.
# Uso: bash rodar.sh      (de dentro desta pasta)
set -e
AQUI="$(cd "$(dirname "$0")" && pwd)"; FUNC="$AQUI/../../funcoes"; D="$(mktemp -d)"
mkdir -p "$D/tt" "$D/funcoes" && cp "$FUNC/mp-criar/mp-puro.ts" "$D/funcoes/mp-puro.ts" && cp "$AQUI/teste-mp-puro.ts" "$D/tt/"
echo "== Funções puras (assinatura, status, CPF) =="; node --experimental-strip-types --no-warnings "$D/tt/teste-mp-puro.ts"
mkdir -p "$D/sim" && cp "$AQUI/mock-supabase.ts" "$D/sim/" && cp "$AQUI/simulacao-fluxo.ts" "$D/sim/sim.ts"
for f in mp-criar mp-webhook mp-status mp-reembolsar; do mkdir -p "$D/sim/$f"; cp "$FUNC/$f/index.ts" "$FUNC/$f/mp-puro.ts" "$D/sim/$f/"; sed 's#npm:@supabase/supabase-js@2#../mock-supabase.ts#' "$FUNC/$f/mp.ts" > "$D/sim/$f/mp.ts"; done
echo "== Fluxo das 4 funções (Supabase e Mercado Pago de mentira) =="; node --experimental-strip-types --no-warnings "$D/sim/sim.ts"
