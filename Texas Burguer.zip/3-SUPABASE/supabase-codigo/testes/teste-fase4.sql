-- Teste da Fase 4 (itens 1 a 5). Só lê o banco; termina com erro de propósito ("RELATORIO") para não deixar nada.
do $$
declare v_ok int := 0; v_f text := ''; d text; n int;
begin
  -- 1) fuso: nenhuma dessas funções pode ainda usar current_date puro
  for d in select pg_get_functiondef(p.oid) from pg_proc p where p.pronamespace = 'public'::regnamespace
            and p.proname in ('_imposto_pct', 'api_integracoes_flags', 'api_simular_precificacao', 'chat_ia_consumir_cota', 'api_ifood_financeiro', 'api_mp_resumo_operacional') loop
    if d ~* 'current_date' or d ~ 'criado_em::date' then v_f := v_f || ' [fuso:' || left(d, 60) || ']'; else v_ok := v_ok + 1; end if;
  end loop;
  -- o imposto de hoje continua devolvendo número
  if public._imposto_pct() is null then v_f := v_f || ' [_imposto_pct nulo]'; else v_ok := v_ok + 1; end if;
  -- 2) TRUNCATE
  select count(*) into n from information_schema.role_table_grants where grantee in ('anon', 'authenticated') and table_schema = 'public' and privilege_type = 'TRUNCATE';
  if n = 0 then v_ok := v_ok + 1; else v_f := v_f || ' [truncate:' || n || ']'; end if;
  -- 3) search_path
  if exists (select 1 from pg_proc where proname = '_nfce_traduzir' and pronamespace = 'public'::regnamespace and proconfig::text like '%search_path%') then v_ok := v_ok + 1; else v_f := v_f || ' [_nfce_traduzir sem search_path]'; end if;
  -- 4) índice duplicado
  if not exists (select 1 from pg_indexes where tablename = 'ai_ajuda' and indexname = 'ai_ajuda_slug_uq') and exists (select 1 from pg_indexes where tablename = 'ai_ajuda' and indexname = 'ai_ajuda_slug_key') then v_ok := v_ok + 1; else v_f := v_f || ' [indice ai_ajuda]'; end if;
  -- 5) prazo do pg_net
  if pg_get_functiondef('public.chamar_edge'::regproc) like '%timeout_milliseconds := 30000%' then v_ok := v_ok + 1; else v_f := v_f || ' [chamar_edge sem prazo]'; end if;
  raise exception 'RELATORIO: % verificacoes ok; falhas:%', v_ok, case when v_f = '' then ' nenhuma' else v_f end;
end $$;
