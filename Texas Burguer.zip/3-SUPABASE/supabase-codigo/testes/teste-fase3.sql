-- Teste da Fase 3 (cancelar Pix vencido no Mercado Pago, lado do banco). NÃO grava nada: termina com erro de propósito ("RELATORIO").
-- A parte de nuvem (função mp-cancelar chamando o Mercado Pago) NÃO é testável aqui e ainda não foi testada contra o Mercado Pago real.
-- Esperado: todas as chaves "ok_*" = true.
do $$
declare rep jsonb := '{}'::jsonb; usr uuid; res uuid; p_ok uuid; p_aguarda uuid; p_feito uuid; p_esgotado uuid; p_velho uuid; p_falha uuid; l jsonb;
begin
  -- estrutura
  rep := rep || jsonb_build_object('ok_colunas', (select count(*) from information_schema.columns where table_schema = 'public' and table_name = 'pagamentos_online' and column_name in ('mp_cancelado_em', 'mp_cancelar_tentativas')) = 2,
    'ok_cron', exists (select 1 from cron.job where jobname = 'mp-cancelar-pix' and active),
    'ok_fechada_ao_publico', not has_function_privilege('anon', 'public.mp_pendentes_cancelar()', 'execute') and not has_function_privilege('authenticated', 'public.mp_pendentes_cancelar()', 'execute')
       and not has_function_privilege('anon', 'public.mp_cancelar_resultado(uuid,boolean,text)', 'execute') and not has_function_privilege('authenticated', 'public.mp_cancelar_resultado(uuid,boolean,text)', 'execute'));

  -- cenários (some no rollback)
  select id into usr from auth.users limit 1;
  insert into pedidos_reserva (user_id, itens, valor_total, expira_em) values (usr, '[]'::jsonb, 30, now() - interval '1 minute') returning id into res;
  insert into pagamentos_online (reserva_id, metodo, mp_modo, status, valor, valor_reembolsado, mp_order_id) values (res, 'pix', 'homologacao', 'expirado', 30, 0, 'ORD-T3-OK') returning id into p_ok;
  insert into pagamentos_online (reserva_id, metodo, mp_modo, status, valor, valor_reembolsado, mp_order_id) values (res, 'pix', 'homologacao', 'aguardando', 30, 0, 'ORD-T3-AGUARDA') returning id into p_aguarda;
  insert into pagamentos_online (reserva_id, metodo, mp_modo, status, valor, valor_reembolsado, mp_order_id, mp_cancelado_em) values (res, 'pix', 'homologacao', 'expirado', 30, 0, 'ORD-T3-FEITO', now()) returning id into p_feito;
  insert into pagamentos_online (reserva_id, metodo, mp_modo, status, valor, valor_reembolsado, mp_order_id, mp_cancelar_tentativas) values (res, 'pix', 'homologacao', 'expirado', 30, 0, 'ORD-T3-ESGOTADO', 5) returning id into p_esgotado;
  insert into pagamentos_online (reserva_id, metodo, mp_modo, status, valor, valor_reembolsado, mp_order_id) values (res, 'pix', 'homologacao', 'cancelado', 30, 0, 'ORD-T3-VELHO') returning id into p_velho;
  update pagamentos_online set atualizado_em = now() - interval '4 hours' where id = p_velho;

  l := public.mp_pendentes_cancelar();
  rep := rep || jsonb_build_object('lista', l,
    'ok_lista_so_o_certo', jsonb_array_length(l) = 1 and l->0->>'id' = p_ok::text and l->0->>'orderId' = 'ORD-T3-OK' and l->0->>'modo' = 'homologacao');

  -- falha: conta tentativa e guarda o motivo; depois de 5 falhas sai da lista
  perform public.mp_cancelar_resultado(p_ok, false, 'teste de falha');
  rep := rep || jsonb_build_object('ok_falha_conta', (select mp_cancelar_tentativas = 1 and mp_cancelado_em is null and erro = 'teste de falha' from pagamentos_online where id = p_ok));
  perform public.mp_cancelar_resultado(p_ok, false, 'f2'); perform public.mp_cancelar_resultado(p_ok, false, 'f3'); perform public.mp_cancelar_resultado(p_ok, false, 'f4'); perform public.mp_cancelar_resultado(p_ok, false, 'f5');
  rep := rep || jsonb_build_object('ok_desiste_apos_5', jsonb_array_length(public.mp_pendentes_cancelar()) = 0);

  -- sucesso: marca o cancelamento e sai da lista
  update pagamentos_online set mp_cancelar_tentativas = 0 where id = p_ok;
  rep := rep || jsonb_build_object('ok_volta_a_lista', jsonb_array_length(public.mp_pendentes_cancelar()) = 1);
  perform public.mp_cancelar_resultado(p_ok, true);
  rep := rep || jsonb_build_object('ok_sucesso_sai_da_lista', (select mp_cancelado_em is not null from pagamentos_online where id = p_ok) and jsonb_array_length(public.mp_pendentes_cancelar()) = 0);

  -- id inexistente não dá erro
  perform public.mp_cancelar_resultado(gen_random_uuid(), false, 'x');
  rep := rep || jsonb_build_object('ok_id_inexistente', true);

  raise exception 'RELATORIO %', jsonb_pretty(rep);
end $$;
