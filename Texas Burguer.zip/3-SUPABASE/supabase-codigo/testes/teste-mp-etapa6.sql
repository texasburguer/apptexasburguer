-- Testes de fumaça da Etapa 6. Executar SOMENTE depois de aplicar o SQL no Supabase.
-- Não cria, altera ou apaga pedidos/pagamentos.
select 'api_mp_pendencias_decisao existe' as teste,
       to_regprocedure('public.api_mp_pendencias_decisao(jsonb)') is not null as passou;
select 'api_mp_resumo_operacional existe' as teste,
       to_regprocedure('public.api_mp_resumo_operacional(jsonb)') is not null as passou;
select 'api_mp_decidir_pagamento existe' as teste,
       to_regprocedure('public.api_mp_decidir_pagamento(jsonb)') is not null as passou;
-- Com login Admin/Operador, validar que as chamadas abaixo retornam {ok:true,...}.
-- select public.api_mp_pendencias_decisao('{}'::jsonb);
-- select public.api_mp_resumo_operacional('{}'::jsonb);
