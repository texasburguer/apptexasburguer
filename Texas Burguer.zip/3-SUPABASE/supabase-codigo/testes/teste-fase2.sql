-- TESTE DA FASE 2 (iFood). NÃO grava nada: termina com erro de propósito ("RELATORIO") e desfaz tudo.
-- Cobre os itens de banco: 1 (sem itens), 2 (INDOOR), 3 (troco), 4 (cancelamento tardio), 5 (centavos), 6 (trava renovável),
-- 7 (evento antes do pedido: lado do banco), 8 (data de agendamento inválida) e 9 (eventos presos).
-- Os itens 6 e 7 também dependem da função de nuvem ifood-sync (não testável aqui).
-- Esperado: todas as chaves "ok_*" = true.
do $$
declare rep jsonb := '{}'::jsonb; o jsonb; r jsonb; v uuid; v2 uuid; v3 uuid; v4 uuid; n int; soma numeric; obs text; n_antes int;
  base jsonb := jsonb_build_object('displayId','T2','orderType','DELIVERY','customer',jsonb_build_object('name','Teste'),
    'items', jsonb_build_array(jsonb_build_object('name','Item','quantity',1,'unitPrice',30,'totalPrice',30)),
    'total', jsonb_build_object('subTotal',30,'deliveryFee',0,'benefits',0,'orderAmount',30),'payments', jsonb_build_object('prepaid',30,'pending',0));
begin
  -- 1) pedido sem itens é recusado e não cria nada
  r := public.ifood_criar_pedido(jsonb_set(jsonb_set(base,'{id}','"t2-vazio"'),'{items}','[]'::jsonb), true);
  rep := rep || jsonb_build_object('sem_itens', r, 'ok_sem_itens', (r->>'ok')::boolean is false and not exists (select 1 from ifood_pedidos where pedido_ifood = 't2-vazio'));
  r := public.ifood_criar_pedido((base - 'items') || '{"id":"t2-semcampo"}'::jsonb, true);
  rep := rep || jsonb_build_object('ok_sem_campo_items', (r->>'ok')::boolean is false);

  -- 2) INDOOR vira Retirada; DELIVERY continua Entrega
  v := (public.ifood_criar_pedido(jsonb_set(jsonb_set(base,'{id}','"t2-indoor"'),'{orderType}','"INDOOR"'), true)->>'vendaId')::uuid;
  v2 := (public.ifood_criar_pedido(jsonb_set(base,'{id}','"t2-entrega"'), true)->>'vendaId')::uuid;
  rep := rep || jsonb_build_object('ok_indoor', (select tipo::text from vendas where id = v) = 'Retirada', 'ok_entrega', (select tipo::text from vendas where id = v2) = 'Entrega');

  -- 3) "levar troco" só quando a entrega é do restaurante
  o := jsonb_set(base, '{payments}', jsonb_build_object('prepaid',0,'pending',30,'methods', jsonb_build_array(jsonb_build_object('method','CASH','type','OFFLINE','value',30,'cash',jsonb_build_object('changeFor',50)))));
  v := (public.ifood_criar_pedido(jsonb_set(jsonb_set(o,'{id}','"t2-troco-loja"'),'{delivery}','{"deliveredBy":"MERCHANT"}'::jsonb), true)->>'vendaId')::uuid;
  v2 := (public.ifood_criar_pedido(jsonb_set(jsonb_set(o,'{id}','"t2-troco-ifood"'),'{delivery}','{"deliveredBy":"IFOOD"}'::jsonb), true)->>'vendaId')::uuid;
  rep := rep || jsonb_build_object('obs_troco_loja', (select observacoes_entrega from vendas where id = v), 'obs_troco_ifood', (select observacoes_entrega from vendas where id = v2),
    'ok_troco', (select observacoes_entrega from vendas where id = v) like '%levar troco para R$ 50,00%' and (select observacoes_entrega from vendas where id = v2) not like '%troco%');

  -- 4) cancelamento depois de concluído é ignorado; cancelamento normal cancela
  v := (public.ifood_criar_pedido(jsonb_set(base,'{id}','"t2-con-can"'), true)->>'vendaId')::uuid;
  perform public.ifood_aplicar_evento('CON', 't2-con-can');
  r := public.ifood_aplicar_evento('CAN', 't2-con-can', 'cliente desistiu');
  rep := rep || jsonb_build_object('can_depois_con', r, 'ok_can_tardio', (r->>'ignorado')::boolean is true and (select status::text from vendas where id = v) = 'Confirmada' and (select estado from ifood_pedidos where pedido_ifood = 't2-con-can') = 'concluido');
  v2 := (public.ifood_criar_pedido(jsonb_set(base,'{id}','"t2-can"'), true)->>'vendaId')::uuid;
  perform public.ifood_aplicar_evento('CAN', 't2-can', 'sem entregador');
  rep := rep || jsonb_build_object('ok_can_normal', (select status::text from vendas where id = v2) = 'Cancelada' and (select estado from ifood_pedidos where pedido_ifood = 't2-can') = 'cancelado');

  -- 5) centavos: 3 unidades por R$ 10,00 → a soma dos itens fecha exatamente em 10,00
  o := jsonb_set(jsonb_set(jsonb_set(base,'{id}','"t2-centavos"'),'{items}', jsonb_build_array(jsonb_build_object('name','Item x3','quantity',3,'unitPrice',3.33,'totalPrice',10))),'{total}', jsonb_build_object('subTotal',10,'deliveryFee',0,'benefits',0,'orderAmount',10));
  v := (public.ifood_criar_pedido(o, true)->>'vendaId')::uuid;
  select sum(valor_total_item), count(*), sum(quantidade) into soma, n, n_antes from itens_venda where venda_id = v;
  rep := rep || jsonb_build_object('centavos_soma', soma, 'centavos_linhas', n, 'centavos_qtd', n_antes, 'ok_centavos', soma = 10.00 and n_antes = 3);

  -- 6) a trava do leitor pode ser renovada pelo mesmo dono e não é tomada por outro
  rep := rep || jsonb_build_object('ok_trava', public.ifood_trava_pegar('dono-a', 100) and not public.ifood_trava_pegar('dono-b', 100) and public.ifood_trava_pegar('dono-a', 100));
  perform public.ifood_trava_soltar('dono-a');
  rep := rep || jsonb_build_object('ok_trava_solta', public.ifood_trava_pegar('dono-b', 100));
  perform public.ifood_trava_soltar('dono-b');

  -- 7) (lado do banco) evento de pedido que ainda não existe devolve "desconhecido", para o ifood-sync tentar de novo
  r := public.ifood_aplicar_evento('CAN', 't2-nao-existe');
  rep := rep || jsonb_build_object('ok_desconhecido', (r->>'desconhecido')::boolean is true);

  -- 8) data de agendamento inválida não derruba o pedido; válida aparece em horário de Brasília
  o := jsonb_set(jsonb_set(base,'{orderTiming}','"SCHEDULED"'),'{schedule}','{"deliveryDateTimeStart":"lixo-de-data"}'::jsonb);
  r := public.ifood_criar_pedido(jsonb_set(o,'{id}','"t2-agenda-ruim"'), true);
  select observacoes_entrega into obs from vendas where id = (r->>'vendaId')::uuid;
  rep := rep || jsonb_build_object('obs_agenda_ruim', obs, 'ok_agenda_ruim', (r->>'ok')::boolean and obs like '%AGENDADO%' and obs not like '%AGENDADO para%');
  r := public.ifood_criar_pedido(jsonb_set(jsonb_set(o,'{id}','"t2-agenda-ok"'),'{schedule}','{"deliveryDateTimeStart":"2026-10-20T19:30:00Z"}'::jsonb), true);
  select observacoes_entrega into obs from vendas where id = (r->>'vendaId')::uuid;
  rep := rep || jsonb_build_object('obs_agenda_ok', obs, 'ok_agenda_ok', obs like '%AGENDADO para 20/10 16:30%');

  -- 9) evento parado há mais de 1 dia é encerrado com erro; evento recente fica
  insert into ifood_eventos (id, codigo, pedido_ifood, recebido_em) values ('t2-ev-velho', 'PLC', 'x', now() - interval '2 days'), ('t2-ev-novo', 'PLC', 'y', now());
  n := public.ifood_eventos_vencidos_fechar();
  rep := rep || jsonb_build_object('fechados', n, 'ok_eventos_presos', n >= 1 and (select processado_em is not null and erro like 'Ficou mais de 1 dia%' from ifood_eventos where id = 't2-ev-velho') and (select processado_em is null from ifood_eventos where id = 't2-ev-novo'));

  raise exception 'RELATORIO %', jsonb_pretty(rep);
end $$;
