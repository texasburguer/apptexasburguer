-- TESTE DA FASE 1 (dinheiro e fiscal). NÃO grava nada: termina com erro de propósito ("RELATORIO") e desfaz tudo.
-- Para testar ANTES: cole só o bloco "do $$ ... $$" (sem a migração). Para testar DEPOIS: cole a migração
-- (ajustes/2026-10-16-fase1-dinheiro-e-fiscal.sql) e este bloco juntos, na mesma execução.
-- Esperado (depois): todas as chaves "ok_*" = true.
do $$
declare rep jsonb := '{}'::jsonb; o jsonb; r jsonb; v1 uuid; v2 uuid; v3 uuid; v4 uuid; nid bigint; nid2 bigint; m jsonb; pf uuid; usr uuid; res uuid; pg uuid; pend text;
begin
  -- preparo (some no rollback): empresa fiscal "ok" e um perfil fiscal
  create or replace function public._fiscal_empresa_ok() returns boolean language sql as 'select true';
  update fiscal_empresa set cnpj = '11222333000181' where id;
  insert into fiscal_perfis (nome, ncm, cfop, csosn, origem, unidade, pis_cst, cofins_cst) values ('perfil teste', '21069090', '5102', '102', '0', 'UN', '49', '49') returning id into pf;
  update fiscal_empresa set perfil_padrao_id = pf where id;

  -- 1) CPF do iFood: válido grava, inválido e CNPJ ficam de fora
  o := jsonb_build_object('id','t1-cpf','displayId','F01','orderType','TAKEOUT','customer',jsonb_build_object('name','A','documentNumber','529.982.247-25'),
        'items', jsonb_build_array(jsonb_build_object('name','Item','quantity',1,'unitPrice',30,'totalPrice',30,'observations','sem cebola')),
        'total', jsonb_build_object('subTotal',30,'deliveryFee',0,'benefits',0,'orderAmount',30),'payments', jsonb_build_object('prepaid',30,'pending',0));
  v1 := (public.ifood_criar_pedido(o, true)->>'vendaId')::uuid;
  o := jsonb_set(jsonb_set(o,'{id}','"t1-cpf-ruim"'),'{customer,documentNumber}','"111.111.111-11"'); v2 := (public.ifood_criar_pedido(o, true)->>'vendaId')::uuid;
  o := jsonb_set(jsonb_set(o,'{id}','"t1-cnpj"'),'{customer,documentNumber}','"11.222.333/0001-81"'); v3 := (public.ifood_criar_pedido(o, true)->>'vendaId')::uuid;
  o := jsonb_set(jsonb_set(o,'{id}','"t1-sem"'),'{customer}','{"name":"B"}'::jsonb); v4 := (public.ifood_criar_pedido(o, true)->>'vendaId')::uuid;
  rep := rep || jsonb_build_object('cpf_valido', (select cpf_nota from vendas where id=v1), 'cpf_invalido', (select cpf_nota from vendas where id=v2), 'cpf_cnpj', (select cpf_nota from vendas where id=v3), 'cpf_ausente', (select cpf_nota from vendas where id=v4));
  rep := rep || jsonb_build_object('ok_cpf', (select cpf_nota from vendas where id=v1) = '52998224725' and (select cpf_nota from vendas where id=v2) is null and (select cpf_nota from vendas where id=v3) is null and (select cpf_nota from vendas where id=v4) is null);

  -- 2) LGPD: depois da retenção o CPF some da venda
  update vendas set data_hora = now() - interval '400 days' where id = v1;
  perform public.ifood_limpar();
  rep := rep || jsonb_build_object('ok_lgpd', (select cpf_nota is null from vendas where id=v1));

  -- 3) nota: item SEM ligação é barrado; item ligado sai sem "(obs: ...)"
  insert into nfce_notas (venda_id, ref, ambiente) values (v4, 't-sem-ligacao', 'homologacao') returning id into nid;
  m := public.nfce_montar(nid);
  rep := rep || jsonb_build_object('nota_sem_ligacao', m, 'ok_barrou_sem_ligacao', (m->>'ok')::boolean is false and m->>'motivo' like 'Item do iFood sem ligação%');
  -- liga o item a um produto de verdade e confere a descrição
  update itens_venda set produto_id = (select id from produtos limit 1), descricao = 'X-Burger + Bacon (obs: sem cebola, alergia a amendoim)' where venda_id = v4;
  m := public.nfce_montar(nid);
  rep := rep || jsonb_build_object('descricao_fiscal', m->'payload'->'itens'->0->>'descricao', 'ok_descricao', m->'payload'->'itens'->0->>'descricao' = 'X-Burger + Bacon');

  -- 4) pagamento 99 leva descrição; os demais códigos NÃO levam
  update pagamentos_venda set forma_pagamento = 'iFood (pago no app)' where venda_id = v4;
  m := public.nfce_montar(nid);
  rep := rep || jsonb_build_object('pag_ifood_app', m->'payload'->'formas_pagamento'->0, 'ok_pag99', m->'payload'->'formas_pagamento'->0->>'forma_pagamento' = '99' and m->'payload'->'formas_pagamento'->0->>'descricao_pagamento' = 'iFood - pago no app');
  update pagamentos_venda set forma_pagamento = 'iFood (pagar na entrega)' where venda_id = v4;
  m := public.nfce_montar(nid);
  rep := rep || jsonb_build_object('ok_pag_entrega', m->'payload'->'formas_pagamento'->0->>'descricao_pagamento' = 'iFood - pagar na entrega');
  rep := rep || jsonb_build_object('ok_sem_desc_no_pix', public._nfce_forma_desc('Pix') is null and public._nfce_forma_desc('Dinheiro') is null and public._nfce_forma_desc('Crédito') is null);

  -- 5) reembolso feito no painel do Mercado Pago (venda ainda ativa)
  select id into usr from auth.users limit 1;
  insert into pedidos_reserva (user_id, itens, valor_total, expira_em) values (usr, '[]'::jsonb, 30, now() + interval '1 hour') returning id into res;
  insert into pagamentos_online (reserva_id, venda_id, metodo, mp_modo, status, valor, valor_reembolsado, mp_order_id) values (res, v1, 'pix', 'homologacao', 'aprovado', 30, 0, 'ORD-TESTE-1') returning id into pg;
  r := public.mp_aplicar_status(jsonb_build_object('pagamentoId', pg, 'status', 'reembolsado', 'valorReembolsado', 30));
  rep := rep || jsonb_build_object('reembolso_chamada', r, 'reembolso_linha', (select to_jsonb(x) - 'id' - 'criado_em' - 'devolvido_em' from reembolsos x where venda_id = v1),
        'ok_reembolso_painel', exists (select 1 from reembolsos where venda_id = v1 and status = 'Devolvido' and valor = 30 and forma_pagamento = 'Mercado Pago'));
  -- repetir o aviso não duplica nem dá erro
  r := public.mp_aplicar_status(jsonb_build_object('pagamentoId', pg, 'status', 'reembolsado', 'valorReembolsado', 30));
  rep := rep || jsonb_build_object('ok_reembolso_repetido', (select count(*) from reembolsos where venda_id = v1) = 1);

  raise exception 'RELATORIO %', jsonb_pretty(rep);
end $$;
