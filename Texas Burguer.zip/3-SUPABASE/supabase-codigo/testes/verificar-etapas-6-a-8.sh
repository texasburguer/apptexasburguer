#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
APP="$ROOT/1-SUBIR-NO-GITHUB"
SQL="$ROOT/3-SUPABASE/supabase-codigo/ajustes/2026-10-13-mp-etapa6-operacao.sql"
node --version >/dev/null
find "$APP" -maxdepth 1 -name '*.js' -print0 | while IFS= read -r -d '' f; do node --check "$f" >/dev/null; done
grep -q "texas-shell-v" "$APP/sw.js"
grep -q "api_mp_pendencias_decisao" "$SQL"
grep -q "api_mp_resumo_operacional" "$SQL"
grep -q "Mercado Pago" "$APP/app-27-conta-cliente.js"
grep -q "mpCarregarPendenciasDecisao_" "$APP/app-11-admin-integracoes.js"
echo "PASSOU: sintaxe JS, versão do Service Worker, SQL Etapa 6 e ganchos do checkout/privacidade."
echo "NOTA: isto não executa SQL nem testa transações reais."
