# Texas Burger — código do Supabase (para refazer do zero)

Projeto de origem: `awryywtgqfaxppayzpca`. Gerado em 09/10/2026.
**NÃO contém dados das tabelas, nem senhas/chaves.** Só a estrutura e o código.

## O que tem aqui
- `01-estrutura.sql` — banco inteiro: extensões, tipos, tabelas, funções (api_*, ia_*, chat_*), restrições, índices, views, triggers, RLS + políticas, permissões, 13 agendamentos (pg_cron), bucket `backups` e linhas de configuração iniciais. Testado em um Postgres limpo: 0 erros.
- `funcoes/<nome>/index.ts` (+ `auth.ts`) — as 16 Edge Functions.

## Ordem para refazer
1. Crie um projeto novo no Supabase.
2. Em Database → Extensions, ligue: `pg_cron`, `pg_net`, `supabase_vault` (e `pgcrypto`/`uuid-ossp` se pedir).
3. Em Vault, crie os segredos (só os nomes; valores você gera/pega de novo):
   - `service_key` (chave secreta `sb_secret_...` do projeto novo)
   - `publishable_key` (chave publicável do projeto novo)
   - `sheets_main_url` (URL do Apps Script da planilha principal)
   - `chave_servidor_planilha` (a mesma chave que está no Apps Script)
4. Abra o SQL Editor e rode `01-estrutura.sql` **uma vez**, num projeto vazio.
5. Troque o endereço do projeto antigo pelo novo: no SQL, a função `chamar_edge` tem `https://awryywtgqfaxppayzpca.supabase.co/functions/v1/` — busque e substitua **antes** de rodar (ou recrie a função depois).
6. Publique as Edge Functions (cada pasta = uma função; `auth.ts` fica junto do `index.ts`). `verify_jwt` = **false** em todas, **exceto** `ai-dev-analise` (true; hoje é só um aviso "desligada").
   Funções: ai-assistente, push-enviar, ai-gateway (antiga, pode pular), ai-publico-atendente, ai-publico-recepcao, ai-dev-analise, arquivar-antigos, conferir-integridade, criar-backup, excluir-backup, restaurar-backup, ping, planilha-admin, remover-foto, sincronizar-fotos, sync-fila, upload-foto.
7. Autenticação: em Auth → Providers deixe e-mail/senha ligado e **ligue a proteção contra senhas vazadas**.
8. Usuários: cada login vira um usuário do Auth com e-mail `login-sem-acento-minusculo@usuarios.texasburger.app` e uma linha em `usuarios` com **o mesmo id** do Auth (`usuarios.id = auth.users.id`).
9. Chaves de IA: insira em `ai_segredos` (provedor `gemini` e/ou `groq`, coluna `chave`). Modelos e liga/desliga ficam em `ai_config`.
10. No `index.html`, troque `SUPABASE_URL_` e `SUPABASE_CHAVE_` pelos do projeto novo. No Apps Script, atualize a URL do Supabase e as chaves.
11. Restaurar dados: se tiver um backup (`backup-....json.gz` do bucket `backups` ou do Drive), use a função restaurar-backup pelo app (Admin).

## Fora do pacote (de propósito)
- Conteúdo das tabelas (vendas, clientes, produtos…).
- Textos do manual da IA (`ai_ajuda`) — são dados; peça uma exportação separada se quiser.
- Senhas, chaves de IA, chaves do Supabase, URLs secretas.
- Apps Script (`planilha_FINAL.gs`, `texas-burger-contingencia_FINAL.gs`) e `index.html` já estão nos seus outros arquivos.

## Observação
Existe uma chave padrão antiga fixa no Apps Script; vale trocar por uma nova ao refazer.

## Ajustes (pasta `ajustes/`) — versão 1.0
O `01-estrutura.sql` já traz estas correções. Os arquivos abaixo servem para aplicar num banco que já existe:
- `2026-10-09-correcoes-v1.sql` — editar o próprio usuário não derruba a sessão; mensagens do Caixa; limite do banco configurável (segredo `LIMITE_BANCO_MB` na tabela `sistema`, padrão 500).
- `2026-10-09-manual-ia-status-e-impressao.sql` — texto do manual da IA (`ai_ajuda`): servidor principal = Supabase, modo emergência, impressão e entregador automático. Usa o slug, não o id. Rode depois de restaurar o manual.
- `2026-10-09-acrescimo-forma-pagamento.sql` — acréscimo por forma de pagamento (ex.: iFood cobra a mais): colunas novas em `formas_pagamento`, `vendas` e `pagamentos_venda`, funções `_acrescimo_forma`/`_acrescimo_pagamento`, ajustes em venda, cardápio, mesa, edição de venda e cadastro da forma, e o preço passa a ser único por produto. O % incide sobre itens menos desconto (não sobre a taxa de entrega); o valor fixo é cobrado uma vez por forma usada. Rode uma vez; se aparecer "já aplicado", o banco já tem.
- `2026-10-09-cardapio-fechamento-e-dados-restaurante.sql` — fechar o cardápio à mão e por período (`_cardapio_bloqueio`, `api_salvar_cardapio_fechamento`, coluna `cardapio_bloqueio` em `v_cardapio_status`, bloqueio em `_criar_pedido_publico`; pedido de mesa por QR não é bloqueado) e Dados do restaurante (`api_salvar_dados_restaurante`, chaves `Restaurante*` na `v_cardapio_config`). Rode uma vez, depois do arquivo do acréscimo (a função `_criar_pedido_publico` aqui já inclui o acréscimo).
- `2026-10-09-cupom-progressivo.sql` — cupom com desconto por faixa (ex.: R$ 5 a partir de R$ 50, R$ 10 a partir de R$ 100): coluna `faixas` em `cupons` e ajustes em `_cupom_validar`, `_cupom_calcular`, `api_salvar_cupom` e `api_editar_cupom`. Rode uma vez.
- `2026-10-09-compras-fornecedores.sql` — fornecedores e compras (só Administrador/Desenvolvedor): tabelas `fornecedores`, `compras`, `compra_itens` e funções `api_salvar_fornecedor`, `api_registrar_compra`, `api_receber_compra`, `api_cancelar_compra`, `api_listar_compras` (+ auxiliares `_converter_unidade`, `_compra_receber`). Compra recebida soma no estoque, atualiza o custo médio e gera a despesa. Rode uma vez.
- `2026-10-09-auditoria-ip.sql` — IP na auditoria (coluna `ip`, visível só ao Admin/Dev, apagado após 90 dias), registro de "Login" e "Falha de login", `api_listar_auditoria` (a tela de Auditoria volta a listar) e IP nas sessões abertas. Rode uma vez.
- `2026-10-09-push-equipe.sql` — avisos com o app fechado (Web Push): tabela `push_inscricoes`, `api_push_inscrever/cancelar` e gatilhos de novo pedido do Cardápio e mensagem de cliente. ANTES: guarde as chaves VAPID no Vault (comandos no topo do arquivo). Depois publique a função `push-enviar` (verify_jwt desligado) e suba o `sw.js` novo (v4) junto do index.html.
- Função `ai-assistente` (V2.3, em `funcoes/ai-assistente/index.ts`): o Administrador pode pedir "comprei 30kg de picanha do fornecedor X por R$ 900"; a IA só PROPÕE um cartão e o app grava após Confirmar. Publique de novo (verify_jwt desligado).
- `funcoes/criar-backup/index.ts` já está na versão 1.0 (cópia ao Drive com 2 tentativas de 20 s).

- `2026-10-09-saude-reserva.sql` — cartão "Saúde do sistema" (`api_saude_sistema`, só Admin/Dev: fila da planilha, backup diário com alerta após 26 h/48 h, Drive, conferência de vendas, tarefas, IA), conferência de integridade DIÁRIA (cron `integridade-diaria` às 09:10; remove a `integridade-semanal`) e textos do manual da IA (modo reserva e Saúde). Rode uma vez.
- `2026-10-09-preco-base.sql` — preço base único (produtos e combos com um só preço; o que muda por forma é o acréscimo da forma), `_exige_admin` que confere a senha do Admin de verdade, senha obrigatória ao criar/excluir/mudar perfil-senha-situação de usuário, `api_aplicar_preco_calculadora` grava o preço base. Guarda os preços antigos em `precos_backup_20261009`.
- `2026-10-09-endereco-cidade.sql` — endereço de entrega no cardápio com número e cidade obrigatórios; o pedido grava "Rua, Bairro, nº 123 — Cidade" (sem bloqueio por cidade).
- `2026-10-10-contas-e-acessos.sql` — tela Contas e acessos (Admin → Sistema): tabela `contas_acessos` (sem acesso direto), senhas no Vault, RPCs `api_listar_contas`, `api_salvar_conta`, `api_excluir_conta`, `api_ver_senha_conta` (exige senha de administrador e audita).
- `2026-10-10-preco-proprio-ifood.sql` — preço próprio por produto em formas marcadas (ex.: iFood): coluna `formas_pagamento.preco_proprio`, add/editar forma aceitam a opção, calculadora não sobrescreve preços próprios.
- `2026-10-10-chaves-ia.sql` — "Chaves das IAs" em Contas e acessos: `api_listar_chaves_ia` (só mostra se tem chave), `api_ver_chave_ia` e `api_salvar_chave_ia` (exigem senha de administrador e auditam). As chaves continuam em `ai_segredos`.
- `2026-10-10-avisos-cliente.sql` — avisos do pedido no celular do CLIENTE: tabelas `push_clientes` e `push_cliente_pedidos` (separadas da equipe), `api_push_cliente_inscrever`/`api_push_cliente_cancelar` (públicas), gatilho `trg_push_status_cliente` em vendas, rotina `push-clientes-feedback` (a cada 5 min: "Como foi seu pedido?" 30 min após entregue, e limpeza), coluna `feedbacks.origem` (formulario/aviso/chat) e `api_add_feedback` aceitando `codigo` e `origem`. Funções `push-enviar` (envia também para clientes com `publico:true`) e `ai-publico-atendente` (ação `feedback`) atualizadas; `sw.js` v5 abre o pedido ou o feedback ao tocar no aviso.
- `2026-10-11-f0-saude-ajuda.sql` — só atualiza o texto de ajuda (`ai_ajuda`): a Saúde do sistema fica só dentro de "Conexão e servidores" (bolinha do topo). Substitui o `2026-10-10-saude-ajuda.sql`. Nenhuma tabela ou função muda.
- Função `conferir-integridade` atualizada: com `{"cron":true}` confere o dia ANTERIOR; aceita `{"dia":"AAAA-MM-DD"}`. Publique de novo (verify_jwt desligado).

## Chaves
As chaves da planilha principal continuam no código por decisão do dono; a contingência as lê das Propriedades do script.

- ajustes/2026-10-11-f0-base.sql — FASE 0 (plano iFood/Nota): interruptores das integrações, cofre de chaves, IAs extras NVIDIA/Cloudflare, Saúde. NÃO aplicar ainda: a subida é só no final (SUBIR-TUDO-supabase.sql).
- funcoes/ai-gateway, ai-assistente, ai-publico-atendente, ai-publico-recepcao — FASE 0: fallback NVIDIA/Cloudflare (sem chave = igual a hoje).
- ajustes/2026-10-11-f1-ifood-nucleo.sql — FASE 1 (iFood núcleo): pedidos entram como venda, itens ligados, fila de ações, leitor único, saúde. NÃO aplicar ainda (subida só no final).
- funcoes/ifood-sync — FASE 1: consulta o iFood a cada ~30 s (só quando a integração está ligada). Publicar com verify_jwt desligado.
- ajustes/2026-10-11-f2-ifood-operacao.sql — FASE 2 (iFood operação): negociação de cancelamento, loja aberta/fechada/pausada, abrir/fechar com o caixa, saúde da loja. NÃO aplicar ainda.
- funcoes/ifood-sync — atualizada na Fase 2 (negociações e loja).
- ajustes/2026-10-11-f3-ifood-inteligencia.sql — FASE 3 (iFood): preços (importar/enviar/desfazer), pausa por estoque, financeiro/repasses, avaliações, relatório por canal. NÃO aplicar ainda.
- funcoes/ifood-sync — atualizada na Fase 3 (catálogo, preço, pausa, financeiro, avaliações).
- ajustes/2026-10-11-f4-fiscal-cadastro.sql — FASE 4 (Nota fiscal, cadastro): dados fiscais da empresa, perfis fiscais (NCM/CFOP/CSOSN) por produto/categoria/padrão, itens sem perfil, planilha do contador, CSC como segredo, imposto estimado no DRE. NÃO aplicar ainda.
- ajustes/2026-10-11-f5-nfce-emissao.sql — FASE 5 (Nota fiscal, emissão): fila de notas, gatilho que cria a nota quando a venda cumpre a regra (canal + ao pagar/na entrega), CPF na nota, lista de notas, reemitir, nota de treino, saúde, cron. NÃO aplicar ainda.
- funcoes/nfce-emitir — FASE 5: emite a NFC-e na Focus NFe (consulta antes de reenviar em caso de dúvida). Publicar com verify_jwt desligado.
- CORREÇÃO (f0/f1): nova função _eh_dev() na f0; "Simular pedido do iFood" (f1) agora usa ela (antes o teste de Desenvolvedor nunca era verdadeiro).
- ajustes/2026-10-11-f6-nfce-fechamento.sql — FASE 6 (Nota fiscal, fechamento): cancelamento automático da nota (até 30 min), inutilização, conferência Vendas × Notas, pacote do contador, aviso do limite do plano. NÃO aplicar ainda.
- funcoes/nfce-emitir — atualizada na Fase 6 (cancelamento e inutilização).

## SUBIR-TUDO-supabase.sql (11/10/2026)
Um único arquivo (`../SUBIR-TUDO-supabase.sql`, também em `ajustes/`) reúne as Fases 0–6 (iFood e Nota fiscal), numa transação só, idempotente, tudo nascendo DESLIGADO.
Ordem de subida: 1) rodar esse SQL; 2) publicar as funções `ifood-sync`, `nfce-emitir` (verify_jwt desligado) e as 4 de IA (`ai-gateway`, `ai-assistente`, `ai-publico-atendente`, `ai-publico-recepcao`); 3) subir `index.html` e `sw.js` no GitHub.

## Assistente grava mais coisas (11/10/2026)
`funcoes/ai-assistente/index.ts` (publicar de novo, verify_jwt desligado) + `ajustes/2026-10-11-f7-assistente-grava-mais.sql` (já incluído no SUBIR-TUDO): o Assistente propõe despesa, estoque, ingrediente, cliente, ocorrência, sangria, ajuste pós-venda, brinde e receber/cancelar compra — sempre com cartão e "Confirmar e gravar" no app.
