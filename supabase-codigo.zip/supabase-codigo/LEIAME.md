# Texas Burger — código do Supabase (para refazer do zero)

Projeto de origem: `awryywtgqfaxppayzpca`. Gerado em 09/10/2026.
**NÃO contém dados das tabelas, nem senhas/chaves.** Só a estrutura e o código.

## O que tem aqui
- `01-estrutura.sql` — banco inteiro: extensões, tipos, tabelas, funções (api_*, ia_*, chat_*), restrições, índices, views, triggers, RLS + políticas, permissões, 13 agendamentos (pg_cron), bucket `backups` e linhas de configuração iniciais. Testado em um Postgres limpo: 0 erros.
- `funcoes/<nome>/index.ts` (+ `auth.ts`) — as 16 Edge Functions.

## Ordem para refazer
1. Crie um projeto novo no Supabase.
2. Em Database → Extensions, ligue: `pg_cron`, `pg_net`, `supabase_vault` (e `pgcrypto`/`uuid-ossp` se pedir).
3. Em Vault, crie os segredos (só os nomes; valores você gera/pega de novo):
   - `service_key` (chave secreta `sb_secret_...` do projeto novo)
   - `publishable_key` (chave publicável do projeto novo)
   - `sheets_main_url` (URL do Apps Script da planilha principal)
   - `chave_servidor_planilha` (a mesma chave que está no Apps Script)
4. Abra o SQL Editor e rode `01-estrutura.sql` **uma vez**, num projeto vazio.
5. Troque o endereço do projeto antigo pelo novo: no SQL, a função `chamar_edge` tem `https://awryywtgqfaxppayzpca.supabase.co/functions/v1/` — busque e substitua **antes** de rodar (ou recrie a função depois).
6. Publique as Edge Functions (cada pasta = uma função; `auth.ts` fica junto do `index.ts`). `verify_jwt` = **false** em todas, **exceto** `ai-dev-analise` (true; hoje é só um aviso "desligada").
   Funções: ai-assistente, push-enviar, ai-gateway (antiga, pode pular), ai-publico-atendente, ai-publico-recepcao, ai-dev-analise, arquivar-antigos, conferir-integridade, criar-backup, excluir-backup, restaurar-backup, ping, planilha-admin, remover-foto, sincronizar-fotos, sync-fila, upload-foto.
7. Autenticação: em Auth → Providers deixe e-mail/senha ligado e **ligue a proteção contra senhas vazadas**.
8. Usuários: cada login vira um usuário do Auth com e-mail `login-sem-acento-minusculo@usuarios.texasburger.app` e uma linha em `usuarios` com **o mesmo id** do Auth (`usuarios.id = auth.users.id`).
9. Chaves de IA: insira em `ai_segredos` (provedor `gemini` e/ou `groq`, coluna `chave`). Modelos e liga/desliga ficam em `ai_config`.
10. No `index.html`, troque `SUPABASE_URL_` e `SUPABASE_CHAVE_` pelos do projeto novo. No Apps Script, atualize a URL do Supabase e as chaves.
11. Restaurar dados: se tiver um backup (`backup-....json.gz` do bucket `backups` ou do Drive), use a função restaurar-backup pelo app (Admin).

## Fora do pacote (de propósito)
- Conteúdo das tabelas (vendas, clientes, produtos…).
- Textos do manual da IA (`ai_ajuda`) — são dados; peça uma exportação separada se quiser.
- Senhas, chaves de IA, chaves do Supabase, URLs secretas.
- Apps Script (`planilha_FINAL.gs`, `texas-burger-contingencia_FINAL.gs`) e `index.html` já estão nos seus outros arquivos.

## Observação
Existe uma chave padrão antiga fixa no Apps Script; vale trocar por uma nova ao refazer.

## Ajustes (pasta `ajustes/`) — versão 1.0
O `01-estrutura.sql` já traz estas correções. Os arquivos abaixo servem para aplicar num banco que já existe:
- `2026-10-09-correcoes-v1.sql` — editar o próprio usuário não derruba a sessão; mensagens do Caixa; limite do banco configurável (segredo `LIMITE_BANCO_MB` na tabela `sistema`, padrão 500).
- `2026-10-09-manual-ia-status-e-impressao.sql` — texto do manual da IA (`ai_ajuda`): servidor principal = Supabase, modo emergência, impressão e entregador automático. Usa o slug, não o id. Rode depois de restaurar o manual.
- `2026-10-09-acrescimo-forma-pagamento.sql` — acréscimo por forma de pagamento (ex.: iFood cobra a mais): colunas novas em `formas_pagamento`, `vendas` e `pagamentos_venda`, funções `_acrescimo_forma`/`_acrescimo_pagamento`, ajustes em venda, cardápio, mesa, edição de venda e cadastro da forma, e o preço passa a ser único por produto. O % incide sobre itens menos desconto (não sobre a taxa de entrega); o valor fixo é cobrado uma vez por forma usada. Rode uma vez; se aparecer "já aplicado", o banco já tem.
- `2026-10-09-cardapio-fechamento-e-dados-restaurante.sql` — fechar o cardápio à mão e por período (`_cardapio_bloqueio`, `api_salvar_cardapio_fechamento`, coluna `cardapio_bloqueio` em `v_cardapio_status`, bloqueio em `_criar_pedido_publico`; pedido de mesa por QR não é bloqueado) e Dados do restaurante (`api_salvar_dados_restaurante`, chaves `Restaurante*` na `v_cardapio_config`). Rode uma vez, depois do arquivo do acréscimo (a função `_criar_pedido_publico` aqui já inclui o acréscimo).
- `2026-10-09-cupom-progressivo.sql` — cupom com desconto por faixa (ex.: R$ 5 a partir de R$ 50, R$ 10 a partir de R$ 100): coluna `faixas` em `cupons` e ajustes em `_cupom_validar`, `_cupom_calcular`, `api_salvar_cupom` e `api_editar_cupom`. Rode uma vez.
- `2026-10-09-compras-fornecedores.sql` — fornecedores e compras (só Administrador/Desenvolvedor): tabelas `fornecedores`, `compras`, `compra_itens` e funções `api_salvar_fornecedor`, `api_registrar_compra`, `api_receber_compra`, `api_cancelar_compra`, `api_listar_compras` (+ auxiliares `_converter_unidade`, `_compra_receber`). Compra recebida soma no estoque, atualiza o custo médio e gera a despesa. Rode uma vez.
- `2026-10-09-auditoria-ip.sql` — IP na auditoria (coluna `ip`, visível só ao Admin/Dev, apagado após 90 dias), registro de "Login" e "Falha de login", `api_listar_auditoria` (a tela de Auditoria volta a listar) e IP nas sessões abertas. Rode uma vez.
- `2026-10-09-push-equipe.sql` — avisos com o app fechado (Web Push): tabela `push_inscricoes`, `api_push_inscrever/cancelar` e gatilhos de novo pedido do Cardápio e mensagem de cliente. ANTES: guarde as chaves VAPID no Vault (comandos no topo do arquivo). Depois publique a função `push-enviar` (verify_jwt desligado) e suba o `sw.js` novo (v4) junto do index.html.
- Função `ai-assistente` (V2.3, em `funcoes/ai-assistente/index.ts`): o Administrador pode pedir "comprei 30kg de picanha do fornecedor X por R$ 900"; a IA só PROPÕE um cartão e o app grava após Confirmar. Publique de novo (verify_jwt desligado).
- `funcoes/criar-backup/index.ts` já está na versão 1.0 (cópia ao Drive com 2 tentativas de 20 s).

- `2026-10-09-saude-reserva.sql` — cartão "Saúde do sistema" (`api_saude_sistema`, só Admin/Dev: fila da planilha, backup diário com alerta após 26 h/48 h, Drive, conferência de vendas, tarefas, IA), conferência de integridade DIÁRIA (cron `integridade-diaria` às 09:10; remove a `integridade-semanal`) e textos do manual da IA (modo reserva e Saúde). Rode uma vez.
- `2026-10-09-preco-base.sql` — preço base único (produtos e combos com um só preço; o que muda por forma é o acréscimo da forma), `_exige_admin` que confere a senha do Admin de verdade, senha obrigatória ao criar/excluir/mudar perfil-senha-situação de usuário, `api_aplicar_preco_calculadora` grava o preço base. Guarda os preços antigos em `precos_backup_20261009`.
- `2026-10-09-endereco-cidade.sql` — endereço de entrega no cardápio com número e cidade obrigatórios; o pedido grava "Rua, Bairro, nº 123 — Cidade" (sem bloqueio por cidade).
- Função `conferir-integridade` atualizada: com `{"cron":true}` confere o dia ANTERIOR; aceita `{"dia":"AAAA-MM-DD"}`. Publique de novo (verify_jwt desligado).

## Chaves
As chaves da planilha principal continuam no código por decisão do dono; a contingência as lê das Propriedades do script.
