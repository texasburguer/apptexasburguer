# Texas Burger — código do Supabase (para refazer do zero)

Projeto de origem: `awryywtgqfaxppayzpca`. Gerado em 09/10/2026.
**NÃO contém dados das tabelas, nem senhas/chaves.** Só a estrutura e o código.

## O que tem aqui
- `01-estrutura.sql` — banco inteiro: extensões, tipos, tabelas, funções (api_*, ia_*, chat_*), restrições, índices, views, triggers, RLS + políticas, permissões, 13 agendamentos (pg_cron), bucket `backups` e linhas de configuração iniciais. Testado em um Postgres limpo: 0 erros.
- `funcoes/<nome>/index.ts` (+ `auth.ts`) — as 16 Edge Functions.

## Ordem para refazer
1. Crie um projeto novo no Supabase.
2. Em Database → Extensions, ligue: `pg_cron`, `pg_net`, `supabase_vault` (e `pgcrypto`/`uuid-ossp` se pedir).
3. Em Vault, crie os segredos (só os nomes; valores você gera/pega de novo):
   - `service_key` (chave secreta `sb_secret_...` do projeto novo)
   - `publishable_key` (chave publicável do projeto novo)
   - `sheets_main_url` (URL do Apps Script da planilha principal)
   - `chave_servidor_planilha` (a mesma chave que está no Apps Script)
4. Abra o SQL Editor e rode `01-estrutura.sql` **uma vez**, num projeto vazio.
5. Troque o endereço do projeto antigo pelo novo: no SQL, a função `chamar_edge` tem `https://awryywtgqfaxppayzpca.supabase.co/functions/v1/` — busque e substitua **antes** de rodar (ou recrie a função depois).
6. Publique as Edge Functions (cada pasta = uma função; `auth.ts` fica junto do `index.ts`). `verify_jwt` = **false** em todas, **exceto** `ai-dev-analise` (true; hoje é só um aviso "desligada").
   Funções: ai-assistente, ai-gateway (antiga, pode pular), ai-publico-atendente, ai-publico-recepcao, ai-dev-analise, arquivar-antigos, conferir-integridade, criar-backup, excluir-backup, restaurar-backup, ping, planilha-admin, remover-foto, sincronizar-fotos, sync-fila, upload-foto.
7. Autenticação: em Auth → Providers deixe e-mail/senha ligado e **ligue a proteção contra senhas vazadas**.
8. Usuários: cada login vira um usuário do Auth com e-mail `login-sem-acento-minusculo@usuarios.texasburger.app` e uma linha em `usuarios` com **o mesmo id** do Auth (`usuarios.id = auth.users.id`).
9. Chaves de IA: insira em `ai_segredos` (provedor `gemini` e/ou `groq`, coluna `chave`). Modelos e liga/desliga ficam em `ai_config`.
10. No `index.html`, troque `SUPABASE_URL_` e `SUPABASE_CHAVE_` pelos do projeto novo. No Apps Script, atualize a URL do Supabase e as chaves.
11. Restaurar dados: se tiver um backup (`backup-....json.gz` do bucket `backups` ou do Drive), use a função restaurar-backup pelo app (Admin).

## Fora do pacote (de propósito)
- Conteúdo das tabelas (vendas, clientes, produtos…).
- Textos do manual da IA (`ai_ajuda`) — são dados; peça uma exportação separada se quiser.
- Senhas, chaves de IA, chaves do Supabase, URLs secretas.
- Apps Script (`planilha_FINAL.gs`, `texas-burger-contingencia_FINAL.gs`) e `index.html` já estão nos seus outros arquivos.

## Observação
Existe uma chave padrão antiga fixa no Apps Script; vale trocar por uma nova ao refazer.

## Ajustes (pasta `ajustes/`) — versão 1.0
O `01-estrutura.sql` já traz estas correções. Os arquivos abaixo servem para aplicar num banco que já existe:
- `2026-10-09-correcoes-v1.sql` — editar o próprio usuário não derruba a sessão; mensagens do Caixa; limite do banco configurável (segredo `LIMITE_BANCO_MB` na tabela `sistema`, padrão 500).
- `2026-10-09-manual-ia-status-e-impressao.sql` — texto do manual da IA (`ai_ajuda`): servidor principal = Supabase, modo emergência, impressão e entregador automático. Usa o slug, não o id. Rode depois de restaurar o manual.
- `funcoes/criar-backup/index.ts` já está na versão 1.0 (cópia ao Drive com 2 tentativas de 20 s).

## Chaves
As chaves da planilha principal continuam no código por decisão do dono; a contingência as lê das Propriedades do script.
