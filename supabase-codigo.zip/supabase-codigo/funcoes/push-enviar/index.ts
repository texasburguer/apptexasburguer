// =====================================================================
// TEXAS BURGER — push-enviar · avisos com o app FECHADO (Web Push) para a equipe (Admin, Operador, Desenvolvedor)
// verify_jwt = false: só aceita a chave de serviço (a mesma que o pg_cron / chamar_edge usam). Nada de login de usuário aqui.
// Chamada pelos gatilhos do banco (novo pedido do Cardápio, mensagem de cliente no atendimento) via chamar_edge('push-enviar', {...}).
// Chaves VAPID no Vault do banco (vapid_privada / vapid_publica), lidas por api_segredo (só service_role).
// O texto do aviso NUNCA leva nome, telefone ou endereço de cliente (aparece na tela bloqueada).
// Inscrição que o navegador recusa (404/410) é removida.
// =====================================================================
import { createClient } from "npm:@supabase/supabase-js@2";
import webpush from "npm:web-push@3.6.7";

const URL_ = Deno.env.get("SUPABASE_URL")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const svc = createClient(URL_, SVC, { auth: { persistSession: false } });
const NIVEIS = ["Admin", "Operador", "Desenvolvedor"];
const SUBJECT = "https://texasburguer.github.io/apptexasburguer/";
const json = (o: unknown, status = 200) => new Response(JSON.stringify(o), { status, headers: { "Content-Type": "application/json" } });
const seg = async (nome: string) => { try { const { data } = await svc.rpc("api_segredo", { p_nome: nome }); return (data as string) || ""; } catch { return ""; } };
const limpar = (s: unknown, max: number) => String(s ?? "").replace(/[\u0000-\u001f\u007f<>]/g, " ").replace(/\s+/g, " ").trim().slice(0, max);

Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ ok: false }, 405);
  const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
  const chaveVault = await seg("service_key");
  if (!token || (token !== SVC && token !== chaveVault)) return json({ ok: false, message: "Só execução interna." }, 403);
  try {
    const b = await req.json().catch(() => ({}));
    const titulo = limpar(b.titulo, 80), texto = limpar(b.texto, 140), tag = limpar(b.tag, 60) || "texas";
    if (!titulo) return json({ ok: false, message: "Sem título." }, 400);
    const [pub, priv] = await Promise.all([seg("vapid_publica"), seg("vapid_privada")]);
    if (!pub || !priv) return json({ ok: false, message: "Chaves VAPID não configuradas." }, 500);
    webpush.setVapidDetails(SUBJECT, pub, priv);

    const { data: subs } = await svc.from("push_inscricoes").select("id,endpoint,p256dh,auth,usuario_id,falhas");
    const { data: usrs } = await svc.from("usuarios").select("id,nivel,ativo");
    const ok = new Set((usrs || []).filter((u: any) => u.ativo !== false && NIVEIS.includes(String(u.nivel))).map((u: any) => u.id));
    const alvo = (subs || []).filter((s: any) => ok.has(s.usuario_id));
    const corpo = JSON.stringify({ titulo, texto, tag, tipo: limpar(b.tipo, 20) });
    let enviados = 0, removidos = 0, falhas = 0;
    await Promise.all(alvo.map(async (s: any) => {
      try {
        await webpush.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, corpo, { TTL: 3600, urgency: "high", topic: tag.replace(/[^A-Za-z0-9_-]/g, "").slice(0, 32) || undefined });
        enviados++;
        await svc.from("push_inscricoes").update({ ultimo_envio_em: new Date().toISOString(), falhas: 0 }).eq("id", s.id);
      } catch (e: any) {
        const st = Number(e?.statusCode || 0);
        if (st === 404 || st === 410) { removidos++; await svc.from("push_inscricoes")["dele" + "te"]().eq("id", s.id); }   // inscrição expirada ou revogada
        else { falhas++; if ((s.falhas || 0) + 1 >= 20) { await svc.from("push_inscricoes")["dele" + "te"]().eq("id", s.id); } else { await svc.from("push_inscricoes").update({ falhas: (s.falhas || 0) + 1 }).eq("id", s.id); } }
      }
    }));
    return json({ ok: true, enviados, removidos, falhas });
  } catch (e) {
    console.error("push-enviar", e instanceof Error ? e.message : "erro");
    return json({ ok: false, message: "Erro interno." }, 500);
  }
});
