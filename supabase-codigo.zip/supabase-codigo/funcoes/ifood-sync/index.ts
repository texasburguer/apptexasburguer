// =====================================================================
// ifood-sync · FASE 1 (iFood). Roda 1x por minuto (pg_cron → chamar_edge), SÓ quando a integração iFood está LIGADA.
// Faz 2 consultas por minuto (a cada ~30 s): pede os eventos ao iFood, guarda (sem duplicar), confirma o recebimento,
// busca o pedido completo e cria a venda; depois envia ao iFood as ações pendentes (confirmar, preparo, pronto, despachar, cancelar).
// verify_jwt = false: aceita só a chave de serviço (a mesma do pg_cron). Segredos do iFood vêm do banco (integracoes_segredos).
// Regras: um único leitor por vez (trava no banco); ações que mudam algo NÃO são repetidas sozinhas em caso de dúvida;
// o estado do pedido só avança por EVENTO oficial do iFood.
// ⚠️ Escrito a partir de documentação de terceiros (a oficial não abriu na pesquisa): ainda NÃO testado com o iFood de verdade.
// =====================================================================
import { createClient } from "npm:@supabase/supabase-js@2";

const URL_ = Deno.env.get("SUPABASE_URL")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const svc = createClient(URL_, SVC, { auth: { persistSession: false } });
const BASE = Deno.env.get("IFOOD_BASE_URL") || "https://merchant-api.ifood.com.br";
const json = (o: unknown, status = 200) => new Response(JSON.stringify(o), { status, headers: { "Content-Type": "application/json" } });
const dormir = (ms: number) => new Promise((r) => setTimeout(r, ms));
const seg = async (nome: string) => { try { const { data } = await svc.rpc("api_segredo", { p_nome: nome }); return (data as string) || ""; } catch { return ""; } };
const rpc = async (fn: string, args: Record<string, unknown> = {}) => {
  const { data, error } = await svc.rpc(fn, args);
  if (error) throw new Error(fn + ": " + error.message);
  return data;
};

class HttpErro extends Error { constructor(public status: number, public corpo: string) { super("http_" + status); } }

async function http(metodo: string, caminho: string, token: string | null, corpo?: unknown, extra: Record<string, string> = {}) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 15000);
  try {
    const h: Record<string, string> = { ...extra };
    if (token) h["Authorization"] = "Bearer " + token;
    let body: string | undefined;
    if (corpo !== undefined) {
      if (corpo instanceof URLSearchParams) { body = corpo.toString(); h["Content-Type"] = "application/x-www-form-urlencoded"; }
      else { body = JSON.stringify(corpo); h["Content-Type"] = "application/json"; }
    }
    const r = await fetch(BASE + caminho, { method: metodo, headers: h, body, signal: ctl.signal });
    const txt = await r.text();
    if (!r.ok) throw new HttpErro(r.status, txt.slice(0, 300));
    if (!txt) return null;
    try { return JSON.parse(txt); } catch { return txt; }
  } catch (e) {
    if (e instanceof HttpErro) throw e;
    throw new HttpErro(0, "rede_ou_timeout");
  } finally { clearTimeout(t); }
}

// ---------- acesso (token OAuth guardado no banco; renova antes de vencer) ----------
async function pegarToken(cred: any, forcar = false): Promise<string> {
  if (!forcar) { const t: any = await rpc("ifood_token_ler"); if (t && t.token) return t.token; }
  if (!cred.clientId || !cred.clientSecret) throw new HttpErro(401, "faltam Client ID / Client Secret");
  const r: any = await http("POST", "/authentication/v1.0/oauth/token", null,
    new URLSearchParams({ grantType: "client_credentials", clientId: cred.clientId, clientSecret: cred.clientSecret }));
  const token = r?.accessToken || r?.access_token;
  if (!token) throw new HttpErro(401, "resposta sem token");
  await rpc("ifood_token_gravar", { p_token: token, p_seg: Number(r?.expiresIn || r?.expires_in || 3600) - 120 });
  return token;
}

// chama o iFood; se o token estiver vencido (401) renova uma vez e repete
async function chamar(cred: any, metodo: string, caminho: string, corpo?: unknown, extra: Record<string, string> = {}) {
  let token = await pegarToken(cred);
  try { return await http(metodo, caminho, token, corpo, extra); }
  catch (e) {
    if (e instanceof HttpErro && e.status === 401) { token = await pegarToken(cred, true); return await http(metodo, caminho, token, corpo, extra); }
    throw e;
  }
}

// ---------- eventos ----------
const CURTO: Record<string, string> = { PLACED: "PLC", CONFIRMED: "CFM", READY_TO_PICKUP: "RTP", DISPATCHED: "DSP", CONCLUDED: "CON", CANCELLED: "CAN" };
const curto = (c: string) => CURTO[String(c || "").toUpperCase()] || String(c || "").toUpperCase();

async function tratarEvento(cred: any, e: any): Promise<{ final: boolean; erro?: string }> {
  const cod = curto(e.codigo); const pedido = e.pedido as string;
  if (!pedido) return { final: true, erro: "evento sem pedido" };
  if (cod === "PLC") {
    let ordem: any;
    try { ordem = await chamar(cred, "GET", `/order/v1.0/orders/${encodeURIComponent(pedido)}`); }
    catch (er) {
      if (er instanceof HttpErro && er.status === 404) {
        const idade = Date.now() - new Date(e.bruto?.createdAt || Date.now()).getTime();
        return idade < 10 * 60000 ? { final: false, erro: "pedido ainda não disponível (404); vamos tentar de novo" } : { final: true, erro: "pedido não encontrado após 10 min" };
      }
      throw er;
    }
    const r: any = await rpc("ifood_criar_pedido", { p_order: ordem, p_simulado: false });
    if (r && r.ok === false) return { final: true, erro: r.message || "falha ao criar" };
    if (r && !r.duplicado && cred.config?.confirmacaoAutomatica !== false) await rpc("ifood_enfileirar", { p_pedido: pedido, p_acao: "confirmar" });
    return { final: true };
  }
  if (cod.includes("PATCH") || cod.includes("MODIF")) {
    const ordem: any = await chamar(cred, "GET", `/order/v1.0/orders/${encodeURIComponent(pedido)}`);
    await rpc("ifood_atualizar_pedido", { p_order: ordem });
    return { final: true };
  }
  if (["CFM", "RTP", "DSP", "CON", "CAN"].includes(cod)) {
    const motivo = e.bruto?.metadata?.cancelReason || e.bruto?.metadata?.cancellationReason || e.bruto?.metadata?.reason || null;
    await rpc("ifood_aplicar_evento", { p_codigo: cod, p_pedido: pedido, p_motivo: motivo });
    return { final: true };
  }
  // negociação de cancelamento (handshake): cliente pede cancelar/reembolsar; a equipe responde no painel
  if (/^HS[DS]?$|HANDSHAKE/i.test(String(e.codigo || "")) || /^HS[DS]?$/.test(cod)) {
    const fim = /SETTLEMENT/i.test(String(e.codigo || "")) || cod === "HSS";
    await rpc(fim ? "ifood_negociacao_fim" : "ifood_negociacao_registrar", { p_evento: e.bruto, p_pedido: pedido });
    return { final: true };
  }
  return { final: true };   // demais eventos: só ficam registrados
}

// ---------- ações que vão para o iFood ----------
const CAMINHO: Record<string, string> = { confirmar: "confirm", iniciar_preparo: "startPreparation", pronto: "readyToPickup", despachar: "dispatch", cancelar: "requestCancellation" };

// ---------- loja (aberta / fechada / pausada) e negociações ----------
// ⚠️ Endereços de "interruptions" e "disputes" vêm de fontes de terceiros: ainda não testado com o iFood de verdade.
async function executarLoja(cred: any, a: any) {
  const m = encodeURIComponent(cred.merchantId || "");
  try {
    if (a.acao === "loja_pausar" || a.acao === "loja_fechar") {
      const min = a.acao === "loja_pausar" ? Math.max(5, Number(a.dados?.minutos || 30)) : 12 * 60;
      const r: any = await chamar(cred, "POST", `/merchant/v1.0/merchants/${m}/interruptions`, { description: (a.acao === "loja_fechar" ? "Fechado pelo sistema" : "Pausa pelo sistema"), start: new Date().toISOString(), end: new Date(Date.now() + min * 60000).toISOString() });
      await rpc("ifood_loja_gravar", { p_status: [{ state: a.acao === "loja_fechar" ? "FECHADA" : "PAUSADA", available: false }], p_interrupcao: r?.id ? String(r.id) : null });
    } else {
      const lista: any = await chamar(cred, "GET", `/merchant/v1.0/merchants/${m}/interruptions`);
      for (const i of (Array.isArray(lista) ? lista : [])) {
        if (/pelo sistema/i.test(String(i.description || ""))) await chamar(cred, "DELETE", `/merchant/v1.0/merchants/${m}/interruptions/${encodeURIComponent(i.id)}`);
      }
    }
    await rpc("ifood_acao_resultado", { p_id: a.id, p_estado: "ok" });
    await atualizarLoja(cred, true);
  } catch (er) {
    const st = er instanceof HttpErro ? er.status : 0;
    await rpc("ifood_acao_resultado", { p_id: a.id, p_estado: st >= 400 && st < 500 ? "erro" : "duvida", p_erro: er instanceof HttpErro ? `${st} ${er.corpo}` : String(er) });
  }
}
async function atualizarLoja(cred: any, forcar = false) {
  try {
    const l: any = await rpc("ifood_loja_estado");
    if (!forcar && l?.verificado_em && Date.now() - new Date(l.verificado_em).getTime() < 5 * 60000) return;
    const st: any = await chamar(cred, "GET", `/merchant/v1.0/merchants/${encodeURIComponent(cred.merchantId || "")}/status`);
    await rpc("ifood_loja_gravar", { p_status: Array.isArray(st) ? st : [st], p_interrupcao: null });
  } catch { /* a loja é só informação; o erro de acesso já aparece na consulta de eventos */ }
}
async function executarNegociacao(cred: any, a: any) {
  const id = encodeURIComponent(a.dados?.disputa || "");
  try {
    if (a.acao === "negociacao_aceitar") await chamar(cred, "POST", `/order/v1.0/disputes/${id}/accept`);
    else if (a.acao === "negociacao_recusar") await chamar(cred, "POST", `/order/v1.0/disputes/${id}/reject`, { reason: a.dados?.motivo || "Recusado pelo restaurante" });
    else {
      if (!a.dados?.alternativaId) throw new HttpErro(400, "escolha uma alternativa");
      await chamar(cred, "POST", `/order/v1.0/disputes/${id}/alternatives/${encodeURIComponent(a.dados.alternativaId)}`, {});
    }
    await rpc("ifood_acao_resultado", { p_id: a.id, p_estado: "ok" });
  } catch (er) {
    const st = er instanceof HttpErro ? er.status : 0;
    await rpc("ifood_acao_resultado", { p_id: a.id, p_estado: st >= 400 && st < 500 ? "erro" : "duvida", p_erro: er instanceof HttpErro ? `${st} ${er.corpo}` : String(er) });
  }
}

// ---------- catálogo (preço, pausa), financeiro e avaliações ----------
// ⚠️ Endereços do catálogo/financeiro/avaliações vêm de fontes de terceiros: ainda não testado com o iFood de verdade.
function achatarCatalogo(cats: any): any[] {
  const out: any[] = [];
  for (const c of (Array.isArray(cats) ? cats : [])) {
    for (const it of (c.items || c.products || [])) {
      out.push({ id: it.id || it.itemId, name: it.name || it.description, externalCode: it.externalCode, price: it.price?.value ?? it.price, category: c.name, status: it.status });
    }
  }
  return out;
}
async function executarCatalogo(cred: any, a: any) {
  const m = encodeURIComponent(cred.merchantId || "");
  try {
    if (a.acao === "catalogo_importar") {
      const cats: any = await chamar(cred, "GET", `/catalog/v2.0/merchants/${m}/catalogs`);
      const todos: any[] = [];
      for (const c of (Array.isArray(cats) ? cats : [])) {
        const id = c.catalogId || c.id; if (!id) continue;
        const itens: any = await chamar(cred, "GET", `/catalog/v2.0/merchants/${m}/catalogs/${encodeURIComponent(id)}/categories?includeItems=true`);
        todos.push(...achatarCatalogo(itens));
      }
      await rpc("ifood_catalogo_gravar", { p_itens: todos });
    } else if (a.acao === "catalogo_preco") {
      try {
        await chamar(cred, "PATCH", `/catalog/v2.0/merchants/${m}/items/price`, { itemId: a.dados.itemId, price: { value: Number(a.dados.preco) } });
        if (a.dados.hist) await rpc("ifood_preco_confirmar", { p_id: a.dados.hist, p_ok: true });
      } catch (er) { if (a.dados.hist) await rpc("ifood_preco_confirmar", { p_id: a.dados.hist, p_ok: false, p_erro: String(er instanceof HttpErro ? `${er.status} ${er.corpo}` : er).slice(0, 250) }); throw er; }
    } else if (a.acao === "catalogo_pausar" || a.acao === "catalogo_retomar") {
      await chamar(cred, "PATCH", `/catalog/v2.0/merchants/${m}/items/status`, { itemId: a.dados.itemId, status: a.acao === "catalogo_pausar" ? "UNAVAILABLE" : "AVAILABLE" });
    } else if (a.acao === "avaliacao_responder") {
      await chamar(cred, "POST", `/review/v2.0/merchants/${m}/reviews/${encodeURIComponent(a.dados.avaliacao)}/answers`, { text: a.dados.texto });
    }
    await rpc("ifood_acao_resultado", { p_id: a.id, p_estado: "ok" });
  } catch (er) {
    const st = er instanceof HttpErro ? er.status : 0;
    await rpc("ifood_acao_resultado", { p_id: a.id, p_estado: st >= 400 && st < 500 ? "erro" : "duvida", p_erro: er instanceof HttpErro ? `${st} ${er.corpo}` : String(er) });
  }
}
async function sincronizarFinanceiro(cred: any) {
  const m = encodeURIComponent(cred.merchantId || "");
  const fim = new Date(), ini = new Date(Date.now() - 30 * 86400000);
  const d = (x: Date) => x.toISOString().slice(0, 10);
  try {
    const r: any = await chamar(cred, "GET", `/financial/v3.0/merchants/${m}/settlements?beginPaymentDate=${d(ini)}&endPaymentDate=${d(fim)}`);
    const lista = Array.isArray(r) ? r : (r?.settlements || r?.items || []);
    await rpc("ifood_repasses_gravar", { p_lista: lista.map((s: any) => ({ id: s.id || s.settlementId, paymentDate: s.paymentDate || s.date, periodStart: s.periodStart || s.beginDate, periodEnd: s.periodEnd || s.endDate, amount: s.amount ?? s.value ?? s.totalAmount, orders: s.orders || s.sales || [] })) });
  } catch (er) { try { await rpc("ifood_log", { p_nivel: "aviso", p_msg: "Financeiro do iFood não carregou: " + String(er instanceof HttpErro ? `${er.status} ${er.corpo}` : er).slice(0, 200) }); } catch { /* sem registro */ } }
}
async function sincronizarAvaliacoes(cred: any) {
  const m = encodeURIComponent(cred.merchantId || "");
  try {
    const r: any = await chamar(cred, "GET", `/review/v2.0/merchants/${m}/reviews?page=1&pageSize=20`);
    const lista = Array.isArray(r) ? r : (r?.reviews || r?.items || []);
    await rpc("ifood_avaliacoes_gravar", { p_lista: lista.map((v: any) => ({ id: v.id || v.reviewId, orderId: v.orderId, score: v.score ?? v.rating, comment: v.comment || v.text, createdAt: v.createdAt, replies: v.replies || (v.reply ? [{ text: v.reply }] : []) })) });
  } catch { /* avaliações são opcionais: a próxima rodada tenta de novo */ }
}

async function executarAcao(cred: any, a: any) {
  if (/^(catalogo_|avaliacao_)/.test(String(a.acao))) return await executarCatalogo(cred, a);
  if (String(a.acao).startsWith("loja_")) return await executarLoja(cred, a);
  if (String(a.acao).startsWith("negociacao_")) return await executarNegociacao(cred, a);
  const info: any = await rpc("ifood_pedido_dados", { p_pedido: a.pedido });
  if (!info || info.simulado) { await rpc("ifood_acao_resultado", { p_id: a.id, p_estado: "pulada", p_erro: "pedido simulado/desconhecido" }); return; }
  const cam = CAMINHO[a.acao]; if (!cam) { await rpc("ifood_acao_resultado", { p_id: a.id, p_estado: "erro", p_erro: "ação desconhecida" }); return; }
  try {
    let corpo: unknown = undefined;
    if (a.acao === "cancelar") {
      // motivos oficiais vêm do iFood; usa o primeiro que combina com o texto, senão o primeiro da lista
      const motivos: any = await chamar(cred, "GET", `/order/v1.0/orders/${encodeURIComponent(a.pedido)}/cancellationReasons`);
      const lista: any[] = Array.isArray(motivos) ? motivos : [];
      if (!lista.length) throw new HttpErro(409, "o iFood não ofereceu motivos de cancelamento para este pedido");
      const texto = String(a.dados?.motivo || "").toLowerCase();
      const escolhido = lista.find((m) => texto && String(m.description || m.reason || "").toLowerCase().includes(texto.slice(0, 8))) || lista[0];
      corpo = { reason: String(a.dados?.motivo || escolhido.description || "Cancelado pelo restaurante").slice(0, 200), cancellationCode: escolhido.cancelCodeId ?? escolhido.code ?? escolhido.id };
    }
    await chamar(cred, "POST", `/order/v1.0/orders/${encodeURIComponent(a.pedido)}/${cam}`, corpo);
    // HTTP 202 = aceito, NÃO = concluído: o estado oficial vem pelos eventos
    await rpc("ifood_acao_resultado", { p_id: a.id, p_estado: "ok" });
  } catch (er) {
    const st = er instanceof HttpErro ? er.status : 0;
    const msg = er instanceof HttpErro ? `${st} ${er.corpo}` : String(er);
    // 4xx = o iFood recusou (erro definitivo). Timeout/5xx = não sabemos se foi: fica "dúvida" e NÃO repete sozinho.
    await rpc("ifood_acao_resultado", { p_id: a.id, p_estado: st >= 400 && st < 500 ? "erro" : "duvida", p_erro: msg });
  }
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ ok: false }, 405);
  const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
  const chaveVault = await seg("service_key");
  if (!token || (token !== SVC && token !== chaveVault)) return json({ ok: false, message: "Só execução interna." }, 403);
  try {
    const cred: any = await rpc("ifood_credenciais");
    if (!cred || !cred.ligado) return json({ ok: true, ligado: false });
    const dono = crypto.randomUUID();
    if (!(await rpc("ifood_trava_pegar", { p_dono: dono, p_seg: 100 }))) return json({ ok: true, ocupado: true });
    try {
      for (let volta = 0; volta < 2; volta++) {
        await consultar(cred);
        await processar(cred);
        await agir(cred);
        try { await rpc("ifood_escalar"); await rpc("ifood_loja_verificar"); await atualizarLoja(cred);
          if (volta === 0 && await rpc("ifood_precisa", { p_tarefa: "avaliacoes", p_minutos: 30 })) await sincronizarAvaliacoes(cred);
          if (volta === 0 && await rpc("ifood_precisa", { p_tarefa: "financeiro", p_minutos: 360 })) await sincronizarFinanceiro(cred); } catch { /* reforços: não podem derrubar o ciclo */ }
        if (volta === 0) await dormir(30000);
      }
    } finally { await rpc("ifood_trava_soltar", { p_dono: dono }); }
    return json({ ok: true });
  } catch (e) {
    try { await rpc("ifood_marcar_consulta", { p_ok: false, p_erro: "Erro interno: " + String(e).slice(0, 200) }); } catch { /* sem registro */ }
    return json({ ok: false, message: String(e).slice(0, 200) }, 500);
  }
});

// 1) pergunta ao iFood o que há de novo, guarda e confirma o recebimento
async function consultar(cred: any) {
  try {
    const eventos: any = await chamar(cred, "GET", "/events/v1.0/events:polling", undefined, cred.merchantId ? { "x-polling-merchants": cred.merchantId } : {});
    const lista: any[] = Array.isArray(eventos) ? eventos : [];
    for (const ev of lista) await rpc("ifood_evento_guardar", { p: ev });       // guarda ANTES de confirmar: nunca perde evento
    if (lista.length) await chamar(cred, "POST", "/events/v1.0/events/acknowledgment", lista.map((ev) => ({ id: ev.id })));
    await rpc("ifood_marcar_consulta", { p_ok: true, p_token_ok: true });
  } catch (e) {
    const st = e instanceof HttpErro ? e.status : 0;
    const recusado = st === 401 || st === 403 || (e instanceof HttpErro && /faltam Client/.test(e.corpo));
    await rpc("ifood_marcar_consulta", { p_ok: false, p_erro: recusado ? "Acesso recusado pelo iFood (confira Client ID e Client Secret)" : "Falha ao consultar o iFood: " + (e instanceof HttpErro ? `${e.status} ${e.corpo}` : String(e)).slice(0, 200), p_token_ok: recusado ? false : null });
  }
}

// 2) trata os eventos guardados (criar venda, estado oficial...)
async function processar(cred: any) {
  let pend: any[] = [];
  try { pend = (await rpc("ifood_eventos_pendentes")) as any[]; } catch { return; }
  for (const e of pend || []) {
    try {
      const r = await tratarEvento(cred, e);
      await rpc("ifood_evento_resultado", { p_id: e.id, p_final: r.final || (e.tentativas || 0) >= 30, p_erro: r.erro || null });
    } catch (er) {
      await rpc("ifood_evento_resultado", { p_id: e.id, p_final: (e.tentativas || 0) >= 30, p_erro: String(er).slice(0, 250) });
    }
  }
}

// 3) manda ao iFood o que a equipe fez no sistema (confirmar, preparo, pronto, despachar, cancelar)
async function agir(cred: any) {
  let acoes: any[] = [];
  try { acoes = (await rpc("ifood_acoes_pendentes")) as any[]; } catch { return; }
  for (const a of acoes || []) { try { await executarAcao(cred, a); } catch (er) { await rpc("ifood_acao_resultado", { p_id: a.id, p_estado: "duvida", p_erro: String(er).slice(0, 250) }); } }
}
