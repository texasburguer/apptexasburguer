import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { CORS, json, autorizar, cfg, svcClient, URL_ } from "./auth.ts";
const SHEETS_MAIN = await cfg("SHEETS_MAIN_URL");
const CHAVE_SERVIDOR = await cfg("PRINCIPAL_CHAVE_SERVIDOR");
const PUBLISHABLE = await cfg("SB_PUBLISHABLE_KEY");

// Ponte entre o app (usuário logado) e o Apps Script da planilha principal: espaço do Drive, espelho,
// vendas da contingência, meses arquivados e chave de leitura da reserva. As chaves da contingência ficam no Apps Script.
async function planilha(corpo: Record<string, unknown>) {
  const r = await fetch(SHEETS_MAIN, { method: "POST", headers: { "Content-Type": "text/plain" },
    body: JSON.stringify({ chave: CHAVE_SERVIDOR, ...corpo }) });
  return await r.json();
}

const TODOS = ["Admin", "Operador", "Garçom", "Cozinha", "Entregador"];
const ACOES: Record<string, { niveis: string[]; action: string }> = {
  armazenamento:            { niveis: ["Admin"], action: "sbArmazenamento" },
  armazenamentoContingencia:{ niveis: ["Admin"], action: "sbArmazenamentoContingencia" },
  sincronizarContingencia:  { niveis: ["Admin"], action: "sbSincronizarContingencia" },
  sincAutoStatus:           { niveis: ["Admin"], action: "sbSincAutoStatus" },   // espelho automático (3h) ligado?
  sincAutoDefinir:          { niveis: ["Admin"], action: "sbSincAutoDefinir" },  // liga/desliga (corpo.ativar)
  chaveContingencia:        { niveis: ["Admin", "Operador"], action: "sbChaveContingencia" },
  arquivoVendas:            { niveis: ["Admin", "Operador"], action: "sbLerArquivo" },
  arquivoCaixa:             { niveis: ["Admin", "Operador"], action: "sbLerArquivoCaixa" },   // D17: caixas fechados e sangrias arquivados
  arquivoPedido:            { niveis: ["Admin", "Operador"], action: "sbLerArquivoPedido" },  // D17: um pedido arquivado (por id ou número)
  chaveLeitura:             { niveis: TODOS, action: "sbChaveLeitura" },   // chave só de consulta da reserva (não enfileira venda)
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  try {
    const corpo = await req.json().catch(() => ({}));
    const acao = String(corpo.acao || "");
    const simples = ACOES[acao];
    const niveis = simples ? simples.niveis : (acao === "reconciliarContingencia" ? ["Admin"] : null);
    if (!niveis) return json({ ok: false, message: "Ação desconhecida." }, 400);
    const a = await autorizar(req, niveis);
    if (!a.ok) return json({ ok: false, message: a.message }, a.status);

    if (simples) {
      const usaMes = acao === "arquivoVendas" || acao === "arquivoCaixa";
      const mes = usaMes ? String(corpo.mes || "") : undefined;
      if (usaMes && !/^\d{4}-(0[1-9]|1[0-2])$/.test(mes!)) return json({ ok: false, message: "Mês inválido." }, 400);
      let id: string | undefined, numero: string | undefined;
      if (acao === "arquivoPedido") {
        id = corpo.id ? String(corpo.id) : undefined;
        numero = corpo.numero ? String(corpo.numero) : undefined;
        if (id && !/^[0-9a-fA-F-]{8,40}$/.test(id)) return json({ ok: false, message: "Pedido inválido." }, 400);
        if (numero && !/^[0-9A-Za-z-]{1,20}$/.test(numero)) return json({ ok: false, message: "Pedido inválido." }, 400);
        if (!id && !numero) return json({ ok: false, message: "Informe o pedido." }, 400);
      }
      const r = await planilha({ action: simples.action, mes, id, numero, rapido: corpo.rapido === true, renovar: corpo.renovar === true, ativar: corpo.ativar === true });
      if ((acao === "arquivoVendas" || acao === "arquivoPedido") && r?.ok) {   // o arquivo guarda só os ids de quem registrou/entregou: devolve os logins para o app montar o relatório
        const { data: us } = await svcClient().from("usuarios").select("id,login");
        r.logins = Object.fromEntries((us || []).map((u: any) => [u.id, u.login]));
      }
      return json(r);
    }

    // ---- reconciliarContingencia: busca a fila na contingência e lança cada venda no Supabase, como o Admin logado ----
    if (a.servico) return json({ ok: false, message: "Use o app logado como Admin." }, 403);
    const token = (req.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
    const cli = createClient(URL_, PUBLISHABLE, { global: { headers: { Authorization: `Bearer ${token}` } }, auth: { persistSession: false } });
    const lista = await planilha({ action: "sbListarPendentesContingencia" });
    if (!lista?.ok) return json({ ok: false, message: lista?.message || "Não foi possível ler a fila da contingência." });
    const pendentes: any[] = lista.pendentes || [];
    const res = { reaplicadas: 0, jaEstavam: 0, falhas: [] as string[], restantes: 0 };
    const paraMarcar: string[] = [];
    for (const item of pendentes.slice(0, 30)) {
      const id = String(item?.id || "");
      if (!id) continue;
      if (item.tipo !== "venda") { res.falhas.push(`${id}: tipo desconhecido (${item.tipo})`); continue; }
      if (item.corrompido || !item.dados || !item.dados.itens) { res.falhas.push(`${id}: dados ilegíveis na fila`); continue; }
      const { data, error } = await cli.rpc("api_reconciliar_venda_contingencia", { p: { idFila: id, dados: item.dados } });
      if (error) { res.falhas.push(`${id}: ${error.message}`); continue; }
      if (data?.ok) { paraMarcar.push(id); if (data.jaFeita || data.duplicado) res.jaEstavam++; else res.reaplicadas++; }
      else res.falhas.push(`${id}: ${data?.message || "recusada"}`);
    }
    res.restantes = Math.max(0, pendentes.length - 30);
    if (paraMarcar.length) {
      const m = await planilha({ action: "sbMarcarSincronizadoContingencia", ids: paraMarcar });
      if (m?.falhas?.length) res.falhas.push(`${m.falhas.length} venda(s) lançada(s) mas não marcadas na contingência (não duplicam se repetir)`);
    }
    const partes = [`${res.reaplicadas} venda(s) lançada(s)`, `${res.jaEstavam} já estavam no sistema`];
    if (res.falhas.length) partes.push(`${res.falhas.length} com problema`);
    if (res.restantes) partes.push(`${res.restantes} ainda na fila (rode de novo)`);
    return json({ ok: true, message: partes.join(" · ") + ".", ...res });
  } catch (e) { return json({ ok: false, message: (e as Error).message }, 500); }
});
