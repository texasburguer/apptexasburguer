import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { CORS, json, svcClient, autorizar, URL_, CHAVE_SERVICO, cfg } from "./auth.ts";

const PRESERVAR = ["usuarios", "auditoria", "backups", "arquivo_historico"];
// Ordem calculada a partir das chaves estrangeiras da estrutura: pais antes dos filhos (inserir) e o inverso (apagar).
const ORDEM = [
  "estoque", "adicionais", "despesas_recorrentes", "despesas", "caixa_sessoes", "clientes",
  "fechamentos_entrega", "mesas", "mesas_codigos", "categorias", "combos", "produtos",
  "combo_itens", "formas_pagamento", "combo_precos", "produto_adicionais", "produto_ingredientes", "produto_precos",
  "cupons", "vendas", "ajustes_pos_venda", "cupons_usos", "entregas_fechadas", "eventos",
  "eventos_custos", "eventos_recebimentos", "feedbacks", "fidelidade", "indicacoes", "itens_venda",
  "movimentacoes_estoque", "ocorrencias", "pagamentos_venda", "promocoes", "sangrias"];
const CHAVE: Record<string, string> = { mesas_codigos: "mesa_id" };   // as demais usam "id"

async function gunzip(bytes: Uint8Array): Promise<string> {
  const s = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip"));
  return await new Response(s).text();
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const a = await autorizar(req, ["Admin"]);   // quem manda é o login, não o usuarioId do corpo
  if (!a.ok || a.servico) return json({ ok: false, message: a.ok ? "Só o Admin logado restaura." : a.message }, a.ok ? 403 : a.status);
  const svc = svcClient();
  let manutencao = false;
  try {
    const { backupId, senhaAdmin } = await req.json();
    if (!backupId || !senhaAdmin) return json({ ok: false, message: "Dados incompletos." }, 400);

    // Confere a senha do Admin no servidor, do mesmo jeito que o login do app (e-mail montado a partir do login).
    const { data: u } = await svc.from("usuarios").select("login").eq("id", a.usuario.id).single();
    const email = String(u?.login || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim() + "@usuarios.texasburger.app";
    const chavePub = (await cfg("SB_PUBLISHABLE_KEY")) || Deno.env.get("SUPABASE_ANON_KEY")!;
    const rs = await fetch(`${URL_}/auth/v1/token?grant_type=password`, { method: "POST",
      headers: { apikey: chavePub, "Content-Type": "application/json" }, body: JSON.stringify({ email, password: senhaAdmin }) });
    if (!rs.ok) return json({ ok: false, message: "Senha incorreta." }, 403);

    const { data: bk } = await svc.from("backups").select("arquivo").eq("id", backupId).eq("status", "Sucesso").single();
    if (!bk?.arquivo) return json({ ok: false, message: "Backup não encontrado." }, 404);

    // Backup de segurança antes de mexer em qualquer coisa — se falhar, aborta
    const pre = await fetch(`${URL_}/functions/v1/criar-backup`, { method: "POST",
      headers: { Authorization: `Bearer ${CHAVE_SERVICO}`, "Content-Type": "application/json" },
      body: JSON.stringify({ tipo: "Pré-restauração", usuarioId: a.usuario.id }) });
    const preJ = await pre.json().catch(() => ({}));
    if (!preJ.ok) return json({ ok: false, message: "Não foi possível criar o backup de segurança. Nada foi alterado." }, 500);

    const { data: arq } = await svc.storage.from("backups").download(bk.arquivo);
    const dados = JSON.parse(await gunzip(new Uint8Array(await arq!.arrayBuffer())));

    await svc.from("sistema").upsert({ chave: "MANUTENCAO", valor: { mensagem: "Restaurando os dados — aguarde alguns minutos.", desde: new Date().toISOString() } }, { onConflict: "chave" });
    manutencao = true;

    const tabelas = ORDEM.filter((t) => Array.isArray(dados[t]) && !PRESERVAR.includes(t));
    for (const t of [...tabelas].reverse()) {
      const { error } = await svc.from(t).delete().not(CHAVE[t] || "id", "is", null);
      if (error) throw new Error(`Apagar ${t}: ${error.message}`);
    }
    for (const t of tabelas) {
      const linhas = dados[t];
      for (let i = 0; i < linhas.length; i += 500) {
        const { error } = await svc.from(t).insert(linhas.slice(i, i + 500));
        if (error) throw new Error(`Inserir ${t}: ${error.message}`);
      }
    }
    if (Array.isArray(dados.sistema)) {
      for (const l of dados.sistema.filter((x: any) => x.chave !== "MANUTENCAO"))
        await svc.from("sistema").upsert(l, { onConflict: "chave" });
    }
    await svc.from("sistema").upsert({ chave: "MANUTENCAO", valor: false }, { onConflict: "chave" });   // a linha existe e o app só liga o aviso se o valor for verdadeiro
    await svc.from("auditoria").insert({ acao: "Backup restaurado", usuario_id: a.usuario.id, usuario_login: u?.login ?? null, detalhes: `Backup ${backupId} · ${tabelas.length} tabelas` });
    return json({ ok: true, message: `Restaurado. ${tabelas.length} tabelas.` });
  } catch (e) {
    if (manutencao) await svc.from("sistema").upsert({ chave: "MANUTENCAO", valor: false }, { onConflict: "chave" });
    return json({ ok: false, message: (e as Error).message + " — se algo ficou pela metade, restaure o backup 'Pré-restauração' mais recente." }, 500);
  }
});
