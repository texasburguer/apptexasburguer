import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { CORS, json, svcClient, autorizar, cfg } from "./auth.ts";
const SHEETS_MAIN = await cfg("SHEETS_MAIN_URL");
const CHAVE_SERVIDOR = await cfg("PRINCIPAL_CHAVE_SERVIDOR");

async function planilha(corpo: any) {
  const r = await fetch(SHEETS_MAIN, { method: "POST", headers: { "Content-Type": "text/plain" },
    body: JSON.stringify({ action: "arquivar", chave: CHAVE_SERVIDOR, ...corpo }) });
  return await r.json();
}

// Envia lotes para a planilha e SÓ remove do Supabase o que a planilha confirmou ter recebido (contagem igual).
// O .gs grava por ID (sem duplicar): se a confirmação falhar, o lote é reenviado depois.
async function arquivarFaixa(svc: any, dias: number, minDias: number, orcamento: { vendas: number; caixas: number }, res: any) {
  for (; orcamento.vendas > 0 && !res.erro; orcamento.vendas--) {
    const { data: l } = await svc.rpc("api_arquivar_lote_vendas", { p_dias: dias, p_limite: 200, p_min_dias: minDias });
    if (!l?.ids?.length) break;
    const j = await planilha({ tipo: "vendas", vendas: l.vendas, itens: l.itens, pagamentos: l.pagamentos });
    if (!j?.ok || j.recebidas !== l.ids.length) { res.erro = "Planilha não confirmou: " + (j?.message || "contagem diferente"); break; }
    const { data: r } = await svc.rpc("api_arquivar_confirmar_vendas", { p_ids: l.ids });
    if (!r?.ok) { res.erro = r?.message || "Falha ao remover"; break; }
    res.vendas += r.removidos;
  }
  for (; orcamento.caixas > 0 && !res.erro; orcamento.caixas--) {
    const { data: l } = await svc.rpc("api_arquivar_lote_caixa", { p_dias: dias, p_limite: 100, p_min_dias: minDias });
    if (!l?.ids?.length) break;
    const j = await planilha({ tipo: "caixa", caixas: l.caixas, sangrias: l.sangrias });
    if (!j?.ok || j.recebidas !== l.ids.length) { res.erro = "Planilha não confirmou: " + (j?.message || "contagem diferente"); break; }
    const { data: r } = await svc.rpc("api_arquivar_confirmar_caixa", { p_ids: l.ids });
    if (!r?.ok) { res.erro = r?.message || "Falha ao remover"; break; }
    res.caixas += r.removidos;
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const a = await autorizar(req, ["Admin"]);
  if (!a.ok) return json({ ok: false, message: a.message }, a.status);
  try {
    const svc = svcClient();
    const corpo = await req.json().catch(() => ({}));
    const { data: conf } = await svc.from("backup_config").select("arquivar_ativo,arquivar_dias,arquivar_emerg_ativo,arquivar_emerg_pct,arquivar_emerg_ultimo").eq("id", true).single();

    // ---- GATILHO DE EMERGÊNCIA: banco perto do limite -> arquiva do mais antigo para o mais novo, até 1 dia atrás ----
    // Só vendas ENCERRADAS (pagas e entregues, ou canceladas) e caixas FECHADOS entram; nada em andamento sai. O pedido de hoje fica.
    if (corpo.emergencia === true) {
      if (!conf?.arquivar_emerg_ativo) return json({ ok: true, message: "Arquivamento de emergência desligado." });
      const { data: pct } = await svc.rpc("api_espaco_percentual_servico");
      const limite = conf.arquivar_emerg_pct ?? 95;
      if (Number(pct) < limite) return json({ ok: true, message: `Uso em ${pct}%, abaixo de ${limite}%.`, pct });
      const ult = conf.arquivar_emerg_ultimo ? new Date(conf.arquivar_emerg_ultimo).getTime() : 0;
      if (Date.now() - ult < 3 * 3600000) return json({ ok: true, message: "Emergência já rodou há menos de 3 h.", pct });
      await svc.from("backup_config").update({ arquivar_emerg_ultimo: new Date().toISOString() }).eq("id", true);
      const res = { vendas: 0, caixas: 0, pctAntes: Number(pct), limite, erro: null as string | null };
      const orc = { vendas: 20, caixas: 20 };   // máx. 4.000 vendas e 2.000 caixas por rodada; se ainda estiver alto, a próxima rodada continua
      for (const dias of [30, 14, 7, 3, 1]) { if (res.erro || (orc.vendas <= 0 && orc.caixas <= 0)) break; await arquivarFaixa(svc, dias, 1, orc, res); }
      await svc.from("auditoria").insert({ usuario_login: "sistema", acao: "Arquivamento de emergência (" + limite + "%)", detalhes: JSON.stringify(res) });
      return json({ ok: !res.erro, message: res.erro || `Uso em ${pct}%: ${res.vendas} venda(s) e ${res.caixas} caixa(s) enviados à planilha.`, ...res });
    }

    // ---- arquivamento normal (por idade) ----
    // O cron respeita o interruptor "arquivar_ativo"; o botão manual (Admin logado) roda mesmo com ele desligado.
    const manual = !a.servico && corpo.manual === true;
    if (!manual && !conf?.arquivar_ativo) return json({ ok: true, message: "Arquivamento desligado." });
    const pedido = manual ? Number(corpo.dias) : NaN;
    const dias = Math.max(30, Number.isFinite(pedido) && pedido > 0 ? pedido : (conf?.arquivar_dias ?? 90));   // trava: o arquivamento normal nunca arquiva o que tem menos de 30 dias
    const res = { vendas: 0, caixas: 0, dias, manual, erro: null as string | null };
    await arquivarFaixa(svc, dias, 30, { vendas: 20, caixas: 20 }, res);
    await svc.from("auditoria").insert({ usuario_login: manual ? "admin (manual)" : "sistema", acao: manual ? "Arquivamento manual" : "Arquivamento automático", detalhes: JSON.stringify(res) });
    return json({ ok: !res.erro, message: res.erro || undefined, ...res });
  } catch (e) { return json({ ok: false, message: (e as Error).message }, 500); }
});
