// ai-dev-analise: DESLIGADA (IA do Desenvolvedor removida em 2026-10-08). Não lê nada, não chama IA.
Deno.serve((_req: Request) =>
  new Response(JSON.stringify({ ok: false, codigo: "desligado", message: "Esta função foi desligada." }), {
    status: 410,
    headers: { "Content-Type": "application/json; charset=utf-8" },
  })
);
