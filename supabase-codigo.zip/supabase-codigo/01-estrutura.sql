-- =====================================================================
-- TEXAS BURGER — ESTRUTURA COMPLETA DO SUPABASE (gerada em 09/10/2026)
-- Projeto de origem: awryywtgqfaxppayzpca
-- Recria: extensões, tipos, tabelas, funções, regras (RLS), views, triggers,
--         permissões, rotinas automáticas (cron) e o bucket de backups.
-- NÃO contém dados de negócio (vendas, clientes, produtos...), nem senhas/chaves.
-- Leia o LEIAME.md antes de rodar. Rode no SQL Editor de um projeto NOVO e vazio.
-- =====================================================================
set check_function_bodies = off;

-- ---------------------------------------------------------------------
-- 1. EXTENSÕES
-- ---------------------------------------------------------------------
create extension if not exists pg_cron with schema pg_catalog;
create extension if not exists pg_net with schema extensions;
create extension if not exists pg_stat_statements with schema extensions;
create extension if not exists pgcrypto with schema extensions;
create extension if not exists supabase_vault with schema vault;
create extension if not exists "uuid-ossp" with schema extensions;

-- ---------------------------------------------------------------------
-- 2. TIPOS (ENUMS)
-- ---------------------------------------------------------------------
create type public.foto_preferida as enum ('principal', 'contingencia', 'auto');
create type public.nivel_acesso as enum ('Admin', 'Operador', 'Garçom', 'Cozinha', 'Entregador', 'Desenvolvedor');
create type public.op_sync as enum ('INSERT', 'UPDATE', 'DELETE');
create type public.origem_venda as enum ('Balcão', 'Cardápio', 'Garçom');
create type public.status_caixa as enum ('Aberto', 'Fechado');
create type public.status_despesa as enum ('Paga', 'A pagar', 'Cancelada');
create type public.status_indicacao as enum ('Pendente', 'Resgatado');
create type public.status_mesa as enum ('Livre', 'Ocupada', 'Aguardando fechamento', 'Fechada', 'Bloqueada/Manutenção');
create type public.status_ocorrencia as enum ('Aberta', 'Em andamento', 'Resolvida');
create type public.status_pagamento as enum ('Pago', 'A Receber');
create type public.status_pedido as enum ('Recebido', 'Em preparo', 'Pronta', 'Saiu para entrega', 'Entregue', 'Retirada', 'Servida', 'Suspenso');
create type public.tipo_backup as enum ('Manual', 'Automático', 'Pré-restauração');
create type public.tipo_mov_estoque as enum ('Entrada', 'Venda', 'Saída', 'Perda', 'Ajuste', 'Inventário');
create type public.unidade_estoque as enum ('un', 'g', 'kg', 'ml', 'l');
create type public.venda_status as enum ('Confirmada', 'Cancelada');
create type public.venda_tipo as enum ('Retirada', 'Entrega', 'Mesa');

-- ---------------------------------------------------------------------
-- 3. SEQUÊNCIAS
-- ---------------------------------------------------------------------
create sequence if not exists public.ai_ajuda_id_seq start 1 increment 1;
create sequence if not exists public.ai_log_id_seq start 1 increment 1;
create sequence if not exists public.arquivo_historico_id_seq start 1 increment 1;
create sequence if not exists public.auditoria_id_seq start 1 increment 1;
create sequence if not exists public.chat_mensagens_id_seq start 1 increment 1;
create sequence if not exists public.codigo_analises_id_seq start 1 increment 1;
create sequence if not exists public.codigo_versoes_id_seq start 1 increment 1;
create sequence if not exists public.erros_cliente_id_seq start 1 increment 1;
create sequence if not exists public.fila_sync_id_seq start 1 increment 1;
create sequence if not exists public.fotos_historico_id_seq start 1 increment 1;
create sequence if not exists public.ia_relatorio_codigo_id_seq start 1 increment 1;
create sequence if not exists public.integridade_checks_id_seq start 1 increment 1;
create sequence if not exists public.ocorrencias_numero_seq start 1 increment 1;
create sequence if not exists public.vendas_numero_pedido_seq start 1 increment 1;

-- ---------------------------------------------------------------------
-- 4. TABELAS
-- ---------------------------------------------------------------------
create table public.adicionais (
  id uuid default gen_random_uuid() not null,
  nome text not null,
  preco numeric(10,2) default 0 not null,
  ativo boolean default true not null,
  ingrediente_id uuid,
  quantidade_descontar numeric(12,3) default 0 not null
);
create table public.ai_ajuda (
  id bigint generated always as identity not null,
  slug text not null,
  titulo text not null,
  palavras_chave text default ''::text not null,
  passos text not null,
  perfis text[] default ARRAY['Admin'::text, 'Operador'::text] not null,
  ativo boolean default true not null,
  atualizado_em timestamp with time zone default now() not null,
  grupo text default 'secao'::text not null,
  ordem integer default 0 not null,
  comuns text default ''::text not null
);
create table public.ai_ajuda_bkp_20261007 (
  id bigint,
  slug text,
  titulo text,
  palavras_chave text,
  passos text,
  perfis text[],
  ativo boolean,
  atualizado_em timestamp with time zone,
  grupo text,
  ordem integer,
  comuns text
);
create table public.ai_cache (
  hash text not null,
  recurso text not null,
  resposta jsonb not null,
  criado_em timestamp with time zone default now() not null,
  expira_em timestamp with time zone not null
);
create table public.ai_config (
  id boolean default true not null,
  ia_ligada boolean default false not null,
  recursos jsonb default '{"ajuda": true, "alertas": true, "compras": true, "pergunte": true, "anomalias": true, "resumo_dia": true, "diagnostico": true, "suporte_pedido": false}'::jsonb not null,
  provedor_principal text default 'gemini'::text not null,
  provedor_reserva text default 'groq'::text,
  modelo_gemini text default 'gemini-2.5-flash'::text not null,
  modelo_groq text default 'llama-3.3-70b-versatile'::text not null,
  cota_diaria_global integer default 300 not null,
  cota_diaria_usuario integer default 40 not null,
  limite_por_minuto integer default 6 not null,
  cache_ttl_min integer default 120 not null,
  cota_diaria_operador integer default 8 not null,
  limite_por_minuto_operador integer default 2 not null,
  recursos_operador jsonb default '{"ajuda": true, "alertas": true, "compras": true, "pergunte": false, "anomalias": true, "resumo_dia": true}'::jsonb not null,
  atualizado_em timestamp with time zone default now() not null
);
create table public.ai_log (
  id bigint generated always as identity not null,
  criado_em timestamp with time zone default now() not null,
  usuario_id uuid,
  recurso text not null,
  status text not null,
  provedor text,
  latencia_ms integer,
  detalhe text
);
create table public.ai_segredos (
  provedor text not null,
  chave text not null,
  atualizado_em timestamp with time zone default now() not null
);
create table public.ai_uso (
  dia date not null,
  provedor text not null,
  usuario_id uuid not null,
  chamadas integer default 0 not null,
  erros integer default 0 not null,
  tokens_in integer default 0 not null,
  tokens_out integer default 0 not null
);
create table public.ajustes_pos_venda (
  id uuid default gen_random_uuid() not null,
  data_hora timestamp with time zone default now() not null,
  venda_id uuid not null,
  pedido_numero integer,
  cliente text,
  telefone text,
  tipo text not null,
  valor numeric(10,2) default 0 not null,
  motivo text,
  detalhe text,
  saida boolean default false not null,
  despesa_id uuid,
  status text default 'Ativo'::text not null,
  autorizado_por uuid,
  registrado_por uuid,
  cancelado_em timestamp with time zone,
  motivo_cancelamento text
);
create table public.arquivo_historico (
  id bigint generated always as identity not null,
  tabela text not null,
  registro_id uuid not null,
  arquivado_em timestamp with time zone default now() not null,
  data_referencia date not null
);
create table public.auditoria (
  id bigint generated always as identity not null,
  data_hora timestamp with time zone default now() not null,
  usuario_id uuid,
  usuario_login text,
  perfil text,
  acao text not null,
  telefone text,
  detalhes text,
  autorizado_por text,
  aparelho text
);
create table public.backup_config (
  id boolean default true not null,
  auto_retencao_dias integer default 7 not null,
  arquivar_ativo boolean default true not null,
  arquivar_dias integer default 90 not null,
  atualizado_em timestamp with time zone default now() not null,
  arquivar_emerg_ativo boolean default true not null,
  arquivar_emerg_pct integer default 95 not null,
  arquivar_emerg_ultimo timestamp with time zone
);
create table public.backups (
  id uuid default gen_random_uuid() not null,
  data_hora timestamp with time zone default now() not null,
  tipo tipo_backup not null,
  status text default 'Em andamento'::text not null,
  arquivo text,
  tamanho_bytes bigint,
  tentativas integer default 0 not null,
  erro text,
  usuario_id uuid,
  copia_drive_em timestamp with time zone,
  copia_drive_erro text
);
create table public.brindes (
  id uuid default gen_random_uuid() not null,
  data_hora timestamp with time zone default now() not null,
  tipo text not null,
  cliente_id uuid,
  cliente_nome text default ''::text not null,
  telefone text default ''::text not null,
  indicacao_id uuid,
  produto_id uuid,
  produto_nome text default ''::text not null,
  custo numeric default 0 not null,
  consumo jsonb default '[]'::jsonb not null,
  caixa_id uuid,
  despesa_id uuid,
  registrado_por uuid,
  requisicao_id text,
  cancelado_em timestamp with time zone,
  motivo_cancelamento text
);
create table public.caixa_sessoes (
  id uuid default gen_random_uuid() not null,
  abertura timestamp with time zone default now() not null,
  fundo_caixa numeric(10,2) default 0 not null,
  fechamento timestamp with time zone,
  total_vendas numeric(10,2),
  total_despesas numeric(10,2),
  saldo_final numeric(10,2),
  status status_caixa default 'Aberto'::status_caixa not null,
  usuario_abertura uuid,
  usuario_fechamento uuid,
  valor_contado numeric(10,2),
  diferenca numeric(10,2)
);
create table public.categorias (
  id uuid default gen_random_uuid() not null,
  nome text not null,
  ativa boolean default true not null,
  ordem integer default 0 not null
);
create table public.chat_config (
  id boolean default true not null,
  chat_publico_ligado boolean default false not null,
  ia_publica_cota_dia integer default 30 not null,
  janela_horas integer default 48 not null,
  atualizado_em timestamp with time zone default now() not null
);
create table public.chat_conversas (
  id uuid default gen_random_uuid() not null,
  venda_id uuid,
  estado text default 'recepcao'::text not null,
  tipo_problema text,
  resumo text,
  texto_original text,
  ia_chamadas smallint default 0 not null,
  atendente_id uuid,
  ocorrencia_id uuid,
  nao_lidas_equipe integer default 0 not null,
  nao_lidas_cliente integer default 0 not null,
  solucao text,
  criado_em timestamp with time zone default now() not null,
  atualizado_em timestamp with time zone default now() not null,
  transferida_em timestamp with time zone,
  encerrada_em timestamp with time zone,
  intencao text,
  nome_cliente text,
  telefone_cliente text,
  pedido_nao_localizado boolean default false not null,
  outros_pedidos smallint default 0 not null
);
create table public.chat_ia_cotas (
  dia date default CURRENT_DATE not null,
  chamadas integer default 0 not null,
  atualizado_em timestamp with time zone default now() not null
);
create table public.chat_mensagens (
  id bigint generated always as identity not null,
  conversa_id uuid not null,
  autor text not null,
  autor_id uuid,
  texto text not null,
  criado_em timestamp with time zone default now() not null
);
create table public.chat_tokens (
  conversa_id uuid not null,
  token_hash text not null,
  criado_em timestamp with time zone default now() not null
);
create table public.clientes (
  id uuid default gen_random_uuid() not null,
  nome text not null,
  telefone text,
  data_nascimento date,
  endereco text,
  como_conheceu text,
  primeiro_contato timestamp with time zone,
  observacoes text,
  criado_em timestamp with time zone default now() not null
);
create table public.codigo_analises (
  id bigint generated always as identity not null,
  arquivo text not null,
  hash text not null,
  achados jsonb default '[]'::jsonb not null,
  provedor text,
  analisado_em timestamp with time zone default now() not null
);
create table public.codigo_snapshots (
  id uuid default gen_random_uuid() not null,
  arquivo text not null,
  bloco integer not null,
  hash text not null,
  conteudo text not null,
  versao text,
  enviado_em timestamp with time zone default now() not null,
  enviado_por uuid
);
create table public.codigo_versoes (
  id bigint generated always as identity not null,
  arquivo text not null,
  versao text not null,
  hash_total text not null,
  blocos jsonb not null,
  enviado_em timestamp with time zone default now() not null,
  enviado_por uuid,
  relatorio jsonb,
  consolidado_em timestamp with time zone
);
create table public.combo_itens (
  id uuid default gen_random_uuid() not null,
  combo_id uuid not null,
  produto_id uuid not null,
  quantidade integer default 1 not null
);
create table public.combo_precos (
  id uuid default gen_random_uuid() not null,
  combo_id uuid not null,
  forma_pagamento_id uuid not null,
  preco numeric(10,2) default 0 not null,
  custo numeric(10,2) default 0 not null
);
create table public.combos (
  id uuid default gen_random_uuid() not null,
  nome text not null,
  categoria_id uuid,
  ativo boolean default true not null,
  destaque boolean default false not null,
  ordem_cardapio integer default 0 not null,
  foto_id_principal text,
  foto_id_contingencia text,
  foto_url_principal text,
  foto_url_contingencia text,
  foto_preferida foto_preferida default 'principal'::foto_preferida not null
);
create table public.configuracoes_fotos (
  id boolean default true not null,
  onde_guardar text,
  destino_padrao_upload text,
  drive_preferido foto_preferida,
  sincronizacao_drives text,
  backup_frio_storage text,
  replicar_antigas text,
  atualizado_em timestamp with time zone default now() not null,
  historico_fotos_ativo boolean default true not null
);
create table public.contingencia_config (
  id boolean default true not null,
  timeout_supabase_ms integer default 8000 not null,
  falhas_para_planilha integer default 3 not null,
  timeout_planilha_ms integer default 12000 not null,
  falhas_para_contingencia integer default 3 not null,
  reconciliacao_lote integer default 50 not null,
  atualizado_em timestamp with time zone default now() not null
);
create table public.contingencia_reconciliada (
  id_fila text not null,
  venda_id uuid,
  origem text,
  usuario_id uuid,
  criado_em timestamp with time zone default now() not null
);
create table public.cupons (
  id uuid default gen_random_uuid() not null,
  codigo text not null,
  nome text,
  tipo text default 'percentual'::text not null,
  valor numeric(10,2) default 0 not null,
  frete_gratis boolean default false not null,
  data_inicio date,
  data_fim date,
  hora_inicio time without time zone,
  hora_fim time without time zone,
  limite_total integer default 0 not null,
  limite_por_cliente integer default 1 not null,
  valor_minimo numeric(10,2) default 0 not null,
  ativa boolean default true not null,
  acumula boolean default false not null,
  criado_em timestamp with time zone default now() not null,
  criado_por uuid
);
create table public.cupons_usos (
  id uuid default gen_random_uuid() not null,
  cupom_id uuid not null,
  codigo text,
  venda_id uuid,
  cliente_id uuid,
  telefone text,
  desconto numeric(10,2) default 0 not null,
  frete_gratis boolean default false not null,
  data_hora timestamp with time zone default now() not null,
  requisicao_id text
);
create table public.despesas (
  id uuid default gen_random_uuid() not null,
  data_hora timestamp with time zone default now() not null,
  descricao text not null,
  valor numeric(10,2) default 0 not null,
  observacao text,
  status status_despesa default 'Paga'::status_despesa not null,
  motivo_cancelamento text,
  categoria text,
  vencimento date,
  situacao text,
  recorrente_id uuid,
  competencia text,
  saiu_do_caixa boolean default true not null,
  criada_em timestamp with time zone default now() not null,
  requisicao_id text
);
create table public.despesas_recorrentes (
  id uuid default gen_random_uuid() not null,
  descricao text not null,
  categoria text,
  valor numeric(10,2) default 0 not null,
  dia_vencimento integer,
  periodicidade text default 'Mensal'::text not null,
  ativa boolean default true not null,
  observacao text,
  inicio date,
  termino date,
  criada_em timestamp with time zone default now() not null
);
create table public.entrega_destinos (
  venda_id uuid not null,
  lat double precision not null,
  lng double precision not null,
  compartilhado_em timestamp with time zone default now() not null
);
create table public.entregador_posicoes (
  venda_id uuid not null,
  entregador_id uuid not null,
  lat double precision not null,
  lng double precision not null,
  precisao_m real,
  atualizado_em timestamp with time zone default now() not null
);
create table public.entregas_fechadas (
  id uuid default gen_random_uuid() not null,
  fechamento_id uuid not null,
  venda_id uuid not null,
  data_ref date not null,
  entregador_id uuid,
  taxa numeric(10,2) default 0 not null
);
create table public.erros_cliente (
  id bigint generated always as identity not null,
  criado_em timestamp with time zone default now() not null,
  ultima_em timestamp with time zone default now() not null,
  dia date default ((now() AT TIME ZONE 'America/Sao_Paulo'::text))::date not null,
  usuario_id uuid,
  nivel text,
  tipo text default 'error'::text not null,
  mensagem text not null,
  origem text default ''::text not null,
  pilha text default ''::text not null,
  tela text default ''::text not null,
  versao text default ''::text not null,
  aparelho text default ''::text not null,
  hash text not null,
  ocorrencias integer default 1 not null
);
create table public.estoque (
  id uuid default gen_random_uuid() not null,
  ingrediente text not null,
  quantidade numeric(12,3) default 0 not null,
  quantidade_minima numeric(12,3) default 0 not null,
  unidade unidade_estoque default 'un'::unidade_estoque not null,
  custo_unitario numeric(10,4) default 0 not null,
  status text
);
create table public.eventos (
  id uuid default gen_random_uuid() not null,
  nome text not null,
  tipo text,
  data date,
  hora_inicio time without time zone,
  hora_fim time without time zone,
  local text,
  contratante text,
  telefone text,
  status text,
  valor_contratado numeric(10,2) default 0 not null,
  valor_recebido numeric(10,2) default 0 not null,
  valor_a_receber numeric(10,2) default 0 not null,
  custo_total numeric(10,2) default 0 not null,
  resultado numeric(10,2) default 0 not null,
  observacoes text,
  criado_em timestamp with time zone default now() not null,
  criado_por uuid,
  atualizado_em timestamp with time zone default now() not null
);
create table public.eventos_custos (
  id uuid default gen_random_uuid() not null,
  evento_id uuid not null,
  descricao text not null,
  categoria text,
  valor numeric(10,2) default 0 not null,
  data date,
  observacao text,
  criado_em timestamp with time zone default now() not null,
  criado_por uuid,
  requisicao_id text
);
create table public.eventos_recebimentos (
  id uuid default gen_random_uuid() not null,
  evento_id uuid not null,
  valor numeric(10,2) default 0 not null,
  forma_pagamento text,
  data date,
  observacao text,
  criado_em timestamp with time zone default now() not null,
  criado_por uuid,
  requisicao_id text
);
create table public.faq_publico (
  id uuid default gen_random_uuid() not null,
  ordem integer default 0 not null,
  pergunta text not null,
  palavras_chave text default ''::text not null,
  resposta text not null,
  ativo boolean default true not null,
  atualizado_em timestamp with time zone default now() not null
);
create table public.fechamentos_entrega (
  id uuid default gen_random_uuid() not null,
  data_ref date not null,
  entregador_id uuid,
  qtd_entregas integer default 0 not null,
  total_taxas numeric(10,2) default 0 not null,
  ajuda_diaria numeric(10,2) default 0 not null,
  total_devido numeric(10,2) default 0 not null,
  valor_pago numeric(10,2) default 0 not null,
  diferenca numeric(10,2) default 0 not null,
  fechado_em timestamp with time zone default now() not null,
  fechado_por uuid,
  observacao text,
  requisicao_id text,
  forma_pagamento text
);
create table public.feedbacks (
  id uuid default gen_random_uuid() not null,
  venda_id uuid,
  cliente_id uuid,
  telefone_cliente text,
  nota integer,
  comentario text,
  data timestamp with time zone default now() not null,
  status text default 'Novo'::text not null
);
create table public.fidelidade (
  id uuid default gen_random_uuid() not null,
  cliente_id uuid not null,
  carimbos integer default 0 not null,
  premios_resgatados integer default 0 not null,
  atualizada_em timestamp with time zone default now() not null,
  observacoes text
);
create table public.fila_sync (
  id bigint generated always as identity not null,
  tabela text not null,
  registro_id text not null,
  operacao op_sync not null,
  payload jsonb,
  criado_em timestamp with time zone default now() not null,
  principal_ok_em timestamp with time zone,
  principal_tentativas integer default 0 not null,
  principal_erro text,
  contingencia_ok_em timestamp with time zone,
  contingencia_tentativas integer default 0 not null,
  contingencia_erro text
);
create table public.formas_pagamento (
  id uuid default gen_random_uuid() not null,
  nome text not null,
  ativa boolean default true not null,
  visivel_cardapio boolean default true not null,
  taxa_percentual numeric(5,2) default 0 not null,
  taxa_fixa numeric(10,2) default 0 not null,
  prazo_dias integer default 0 not null,
  permite_troco boolean default false not null,
  ordem integer default 0 not null
);
create table public.fotos_historico (
  id bigint generated always as identity not null,
  produto_id uuid,
  combo_id uuid,
  acao text not null,
  drive_origem text,
  drive_destino text,
  foto_id_antigo text,
  foto_id_novo text,
  usuario_id uuid,
  criado_em timestamp with time zone default now() not null
);
create table public.ia_relatorio_codigo (
  id bigint generated always as identity not null,
  gerado_em timestamp with time zone default now() not null,
  origem text default 'analisador_estatico'::text not null,
  resumo jsonb not null
);
create table public.indicacoes (
  id uuid default gen_random_uuid() not null,
  indicador_id uuid,
  indicado_id uuid,
  nome_indicador text,
  telefone_indicador text,
  nome_indicado text,
  telefone_indicado text,
  data timestamp with time zone default now() not null,
  status status_indicacao default 'Pendente'::status_indicacao not null,
  observacoes text
);
create table public.integridade_checks (
  id bigint generated always as identity not null,
  criado_em timestamp with time zone default now() not null,
  supabase_vendas integer,
  planilha_vendas integer,
  diferenca_vendas integer,
  status text default 'ok'::text not null,
  detalhe jsonb
);
create table public.itens_venda (
  id uuid default gen_random_uuid() not null,
  venda_id uuid not null,
  produto_id uuid,
  combo_id uuid,
  descricao text,
  quantidade integer default 1 not null,
  valor_unitario numeric(10,2) default 0 not null,
  custo_unitario numeric(10,2) default 0 not null,
  valor_total_item numeric(10,2) default 0 not null,
  adicionais_ids uuid[] default '{}'::uuid[] not null
);
create table public.mesas (
  id uuid default gen_random_uuid() not null,
  numero text not null,
  status status_mesa default 'Livre'::status_mesa not null,
  capacidade integer,
  observacao text,
  garcom_responsavel_id uuid,
  chamado_tipo text,
  chamado_em timestamp with time zone
);
create table public.mesas_codigos (
  mesa_id uuid not null,
  codigo text not null,
  gerado_em timestamp with time zone default now() not null
);
create table public.movimentacoes_estoque (
  id uuid default gen_random_uuid() not null,
  ingrediente_id uuid not null,
  tipo tipo_mov_estoque not null,
  quantidade numeric(12,3) not null,
  qtd_antes numeric(12,3),
  qtd_depois numeric(12,3),
  motivo_referencia text,
  usuario_id uuid,
  data timestamp with time zone default now() not null
);
create table public.ocorrencias (
  id uuid default gen_random_uuid() not null,
  numero integer default nextval('ocorrencias_numero_seq'::regclass) not null,
  data_hora timestamp with time zone default now() not null,
  tipo text,
  setor text,
  venda_id uuid,
  cliente text,
  telefone text,
  registrado_por uuid,
  responsavel text,
  descricao text,
  solucao text,
  status status_ocorrencia default 'Aberta'::status_ocorrencia not null,
  atualizada_em timestamp with time zone default now() not null,
  historico jsonb default '[]'::jsonb not null
);
create table public.pagamentos_venda (
  id uuid default gen_random_uuid() not null,
  venda_id uuid not null,
  forma_pagamento text not null,
  valor numeric(10,2) default 0 not null,
  taxa_aplicada numeric(10,2) default 0 not null
);
create table public.pedido_destinos (
  venda_id uuid not null,
  lat double precision not null,
  lng double precision not null,
  criado_em timestamp with time zone default now() not null
);
create table public.produto_adicionais (
  id uuid default gen_random_uuid() not null,
  produto_id uuid not null,
  adicional_id uuid not null
);
create table public.produto_ingredientes (
  id uuid default gen_random_uuid() not null,
  produto_id uuid not null,
  ingrediente_id uuid not null,
  quantidade_por_unidade numeric(12,3) default 0 not null
);
create table public.produto_precos (
  id uuid default gen_random_uuid() not null,
  produto_id uuid not null,
  forma_pagamento_id uuid not null,
  preco numeric(10,2) default 0 not null,
  custo numeric(10,2) default 0 not null
);
create table public.produtos (
  id uuid default gen_random_uuid() not null,
  nome text not null,
  descricao text,
  categoria_id uuid,
  ativo boolean default true not null,
  destaque boolean default false not null,
  estoque_proprio_ingrediente_id uuid,
  ordem_cardapio integer default 0 not null,
  foto_id_principal text,
  foto_id_contingencia text,
  foto_url_principal text,
  foto_url_contingencia text,
  foto_preferida foto_preferida default 'principal'::foto_preferida not null,
  premio_fidelidade boolean default false not null,
  premio_indicacao boolean default false not null
);
create table public.promocoes (
  id uuid default gen_random_uuid() not null,
  nome text not null,
  tipo text,
  regra_duplicidade text,
  beneficio text,
  ativa boolean default true not null
);
create table public.requisicoes (
  chave text not null,
  acao text not null,
  resultado jsonb,
  usuario_id uuid,
  data_hora timestamp with time zone default now() not null
);
create table public.sangrias (
  id uuid default gen_random_uuid() not null,
  data_hora timestamp with time zone default now() not null,
  valor numeric(10,2) not null,
  motivo text,
  usuario_id uuid,
  caixa_id uuid
);
create table public.sistema (
  chave text not null,
  valor jsonb not null,
  atualizado_em timestamp with time zone default now() not null
);
create table public.sync_estado (
  id boolean default true not null,
  principal_ultimo_ok timestamp with time zone,
  principal_ultimo_erro timestamp with time zone,
  principal_ultimo_erro_msg text,
  contingencia_ultimo_ok timestamp with time zone,
  contingencia_ultimo_erro timestamp with time zone,
  contingencia_ultimo_erro_msg text,
  contingencia_atraso_minutos integer default 60 not null,
  alerta_itens_limite integer default 500 not null,
  alerta_horas_limite integer default 6 not null,
  atualizado_em timestamp with time zone default now() not null
);
create table public.tentativas (
  chave text not null,
  falhas integer default 0 not null,
  bloqueado_ate timestamp with time zone
);
create table public.usuarios (
  id uuid not null,
  login text not null,
  nome text not null,
  telefone text,
  nivel nivel_acesso not null,
  ativo boolean default true not null,
  criado_em timestamp with time zone default now() not null
);
create table public.vendas (
  id uuid default gen_random_uuid() not null,
  numero_pedido integer default nextval('vendas_numero_pedido_seq'::regclass) not null,
  data_hora timestamp with time zone default now() not null,
  cliente_id uuid,
  cliente_nome text,
  telefone_cliente text,
  forma_pagamento text,
  valor_total numeric(10,2) default 0 not null,
  custo_total numeric(10,2) default 0 not null,
  status venda_status default 'Confirmada'::venda_status not null,
  motivo_cancelamento text,
  tipo venda_tipo default 'Retirada'::venda_tipo not null,
  status_pedido status_pedido,
  endereco text,
  complemento text,
  referencia text,
  observacoes_entrega text,
  pronta_em timestamp with time zone,
  concluida_em timestamp with time zone,
  status_pagamento status_pagamento default 'Pago'::status_pagamento not null,
  recebido_em timestamp with time zone,
  valor_original numeric(10,2),
  valor_desconto numeric(10,2) default 0 not null,
  desconto_detalhe text,
  entregador_id uuid,
  saiu_em timestamp with time zone,
  origem origem_venda default 'Balcão'::origem_venda not null,
  mesa_id uuid,
  taxa_entrega numeric(10,2) default 0 not null,
  fechamento_entrega_id uuid,
  registrado_por uuid,
  inicio_preparo_em timestamp with time zone,
  caixa_id uuid,
  requisicao_id text,
  status_antes_suspensao text
);
create table public.versoes_sync (
  grupo text not null,
  n bigint default 0 not null
);

-- ---------------------------------------------------------------------
-- 5. FUNÇÕES (RPC e internas)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public._agora_br()
 RETURNS text
 LANGUAGE sql
 STABLE
 SET search_path TO 'public'
AS $function$
  select to_char(now() at time zone 'America/Sao_Paulo', 'DD/MM/YYYY HH24:MI')
$function$
;

CREATE OR REPLACE FUNCTION public._ajustar_estoque(p_itens jsonb, p_dir integer, p_venda uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r record; e estoque%rowtype; v_delta numeric; v_novo numeric;
        v_ref text := case when p_venda is not null then 'Venda #' || left(p_venda::text, 8) else case when p_dir > 0 then 'Venda' else 'Estorno de venda' end end;
begin
  for r in select * from _consumo(p_itens) order by ingrediente_id loop
    select * into e from estoque where id = r.ingrediente_id for update;
    if not found then continue; end if;
    v_delta := p_dir * r.qtd;
    v_novo := round(e.quantidade - v_delta, 3);
    update estoque set quantidade = v_novo where id = e.id;
    if p_dir > 0 and v_novo < 0 then perform _auditar('Estoque negativo', e.ingrediente || ': ' || v_novo || ' (' || v_ref || ')'); end if;
    if v_delta <> 0 then
      insert into movimentacoes_estoque (ingrediente_id, tipo, quantidade, qtd_antes, qtd_depois, motivo_referencia, usuario_id)
      values (e.id, (case when p_dir > 0 then 'Venda' else 'Saída' end)::tipo_mov_estoque, -v_delta, e.quantidade, v_novo, v_ref, auth.uid());
    end if;
  end loop;
end $function$
;

CREATE OR REPLACE FUNCTION public._auditar(p_acao text, p_detalhes text DEFAULT NULL::text, p_telefone text DEFAULT NULL::text)
 RETURNS void
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  insert into auditoria (usuario_id, usuario_login, perfil, acao, telefone, detalhes, autorizado_por)
  select u.id, u.login, u.nivel::text, p_acao, p_telefone, p_detalhes, nullif(current_setting('app.autorizador', true), '')
  from usuarios u where u.id = auth.uid()
$function$
;

CREATE OR REPLACE FUNCTION public._auditar_publico(p_acao text, p_detalhes text, p_tel text)
 RETURNS void
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  insert into auditoria (usuario_login, perfil, acao, telefone, detalhes) values ('Cardápio (cliente)', 'Cliente', p_acao, p_tel, p_detalhes)
$function$
;

CREATE OR REPLACE FUNCTION public._bump_versao_sync()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_grupos text[]; v_chave text; v_tx text := txid_current()::text;
begin
  -- dispara no COMMIT (gatilho adiado): o carimbo só muda quando a alteração já está visível para todos
  v_grupos := case
    when tg_table_name = 'sistema' then array['cad', 'din']
    when tg_table_name in ('formas_pagamento','categorias','produtos','produto_precos','produto_ingredientes','combos','combo_precos','combo_itens','adicionais','produto_adicionais') then array['cad']
    else array['din'] end;
  v_chave := 'app.vsync_' || array_to_string(v_grupos, '_');
  if coalesce(current_setting(v_chave, true), '') = v_tx then return null; end if;   -- 1 incremento por grupo e por transação
  perform set_config(v_chave, v_tx, true);
  perform 1 from versoes_sync where grupo in ('cad', 'din') order by grupo for update;  -- ordem fixa de travas: sem deadlock
  update versoes_sync set n = n + 1 where grupo = any(v_grupos);
  return null;
end $function$
;

CREATE OR REPLACE FUNCTION public._caixa_aberto_id()
 RETURNS uuid
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select id from public.caixa_sessoes
  where status = 'Aberto'::public.status_caixa
  order by abertura desc
  limit 1
$function$
;

CREATE OR REPLACE FUNCTION public._calc_fechamento_entrega(p_login text, p_data date, OUT qtd integer, OUT total_taxas numeric, OUT ajuda numeric, OUT total numeric, OUT ids uuid[])
 RETURNS record
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare uid uuid; ja boolean; aj numeric;
begin
  select id into uid from usuarios where lower(login) = lower(p_login) and nivel::text = 'Entregador';
  select count(*)::int, coalesce(round(sum(taxa_entrega), 2), 0), coalesce(array_agg(id), '{}'::uuid[]) into qtd, total_taxas, ids
    from vendas where status = 'Confirmada' and tipo = 'Entrega' and status_pedido::text = 'Entregue' and entregador_id = uid
     and fechamento_entrega_id is null and (concluida_em at time zone 'America/Sao_Paulo')::date = p_data;
  select exists (select 1 from fechamentos_entrega where entregador_id = uid and data_ref = p_data) into ja;
  select coalesce(_num(valor #>> '{}'), 0) into aj from sistema where chave = 'AjudaDiariaEntregador';
  ajuda := case when qtd > 0 and not ja then coalesce(aj, 0) else 0 end;
  total := round(total_taxas + ajuda, 2);
end $function$
;

CREATE OR REPLACE FUNCTION public._carimbar_fidelidade(p_tel text, p_nome text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_cli uuid := _upsert_cliente(p_tel, p_nome); f fidelidade%rowtype;
begin
  if v_cli is null then return; end if;
  select * into f from fidelidade where cliente_id = v_cli for update;
  if found then
    if f.carimbos < 10 then
      update fidelidade set carimbos = f.carimbos + 1, atualizada_em = now() where cliente_id = v_cli;
      perform _auditar('Marca adicionada (fidelidade)', (f.carimbos + 1) || '/10', p_tel);
    end if;
  else
    insert into fidelidade (cliente_id, carimbos, atualizada_em) values (v_cli, 1, now());
    perform _auditar('Cliente novo no fidelidade', coalesce(p_nome, ''), p_tel);
  end if;
end $function$
;

CREATE OR REPLACE FUNCTION public._categoria_despesa(v text, padrao text DEFAULT 'Outros'::text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
  select case when v = any (array['Insumos','Aluguel','Energia','Água','Gás','Internet/Telefone','Salários','Impostos','Manutenção','Marketing','Embalagens','Entregadores','Outros'])
              then v else padrao end
$function$
;

CREATE OR REPLACE FUNCTION public._cfg_gravar(p_chave text, p_valor jsonb)
 RETURNS void
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  insert into sistema (chave, valor) values (p_chave, p_valor)
  on conflict (chave) do update set valor = excluded.valor
$function$
;

CREATE OR REPLACE FUNCTION public._chat_caixa_aberto()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$ select exists (select 1 from caixa_sessoes where status = 'Aberto') $function$
;

CREATE OR REPLACE FUNCTION public._chat_hash(t text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public', 'pg_catalog'
AS $function$ select encode(sha256(convert_to(coalesce(t, ''), 'utf8')), 'hex') $function$
;

CREATE OR REPLACE FUNCTION public._chat_ligado()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$ select coalesce((select chat_publico_ligado from chat_config where id), false) $function$
;

CREATE OR REPLACE FUNCTION public._chat_limpar(t text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public', 'pg_catalog'
AS $function$ select btrim(regexp_replace(coalesce(t, ''), '[\x01-\x08\x0B\x0C\x0E-\x1F]', '', 'g')) $function$
;

CREATE OR REPLACE FUNCTION public._chat_normalizar_intencao()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
begin
  if new.estado <> 'recepcao' and new.venda_id is null then
    if new.intencao is null then new.intencao := 'antes_de_pedir';
    elsif new.intencao = 'pedido_feito' then new.pedido_nao_localizado := true; end if;
  end if;
  return new;
end $function$
;

CREATE OR REPLACE FUNCTION public._chat_validar(p_id uuid, p_token text)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_catalog'
AS $function$ select exists (select 1 from chat_tokens t where t.conversa_id = p_id and t.token_hash = _chat_hash(p_token)) $function$
;

CREATE OR REPLACE FUNCTION public._combo_gravar_itens(p_combo uuid, p_itens jsonb)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  delete from combo_itens where combo_id = p_combo;
  insert into combo_itens (combo_id, produto_id, quantidade)
  select p_combo, _uuid(e->>'produtoId'), _num(e->>'quantidade')::int
  from jsonb_array_elements(coalesce(p_itens, '[]'::jsonb)) e
  where _uuid(e->>'produtoId') is not null and _num(e->>'quantidade') > 0;
end $function$
;

CREATE OR REPLACE FUNCTION public._combo_gravar_precos(p_combo uuid, p_precos jsonb)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  delete from combo_precos where combo_id = p_combo;
  insert into combo_precos (combo_id, forma_pagamento_id, preco, custo)
  select p_combo, _uuid(e->>'formaPagamentoId'), _num(e->>'preco'), _num(e->>'custo')
  from jsonb_array_elements(coalesce(p_precos, '[]'::jsonb)) e where _uuid(e->>'formaPagamentoId') is not null
  on conflict (combo_id, forma_pagamento_id) do update set preco = excluded.preco, custo = excluded.custo;
end $function$
;

CREATE OR REPLACE FUNCTION public._comp_valida(v text)
 RETURNS boolean
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
  select coalesce(v ~ '^\d{4}-(0[1-9]|1[0-2])$', false)
$function$
;

CREATE OR REPLACE FUNCTION public._competencia_atual()
 RETURNS text
 LANGUAGE sql
 STABLE
 SET search_path TO 'public'
AS $function$
  select to_char(now() at time zone 'America/Sao_Paulo', 'YYYY-MM')
$function$
;

CREATE OR REPLACE FUNCTION public._conflito(p_msg text)
 RETURNS jsonb
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public', 'pg_catalog'
AS $function$
  select jsonb_build_object('ok', false, 'conflito', true, 'message', p_msg) $function$
;

CREATE OR REPLACE FUNCTION public._consumo(p_itens jsonb)
 RETURNS TABLE(ingrediente_id uuid, qtd numeric)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  with it as (
    select _uuid(e->>'produtoId') as produto_id, _uuid(e->>'comboId') as combo_id,
           _num(e->>'quantidade') as q, e->'adicionaisIds' as ads
    from jsonb_array_elements(coalesce(p_itens, '[]'::jsonb)) e
  ), consumo as (
    select pi.ingrediente_id, pi.quantidade_por_unidade * it.q as qtd
      from it join produto_ingredientes pi on pi.produto_id = it.produto_id
    union all
    select pi.ingrediente_id, pi.quantidade_por_unidade * ci.quantidade * it.q
      from it join combo_itens ci on ci.combo_id = it.combo_id
              join produto_ingredientes pi on pi.produto_id = ci.produto_id
    union all
    select a.ingrediente_id, coalesce(nullif(a.quantidade_descontar, 0), 1) * it.q
      from it
      cross join lateral jsonb_array_elements_text(case when jsonb_typeof(it.ads) = 'array' then it.ads else '[]'::jsonb end) x
      join adicionais a on a.id = _uuid(x)
      where a.ingrediente_id is not null
  )
  select c.ingrediente_id, sum(c.qtd) from consumo c where c.ingrediente_id is not null group by c.ingrediente_id having sum(c.qtd) <> 0
$function$
;

CREATE OR REPLACE FUNCTION public._criar_login_auth(p_id uuid, p_email text, p_senha text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'auth', 'extensions'
AS $function$
begin
  insert into auth.users (
    instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
    raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
    confirmation_token, recovery_token, email_change_token_new, email_change,
    email_change_token_current, phone_change, phone_change_token, reauthentication_token)
  values ('00000000-0000-0000-0000-000000000000', p_id, 'authenticated', 'authenticated', p_email,
    crypt(p_senha, gen_salt('bf')), now(),
    '{"provider":"email","providers":["email"]}'::jsonb, '{}'::jsonb, now(), now(), '', '', '', '', '', '', '', '');
  insert into auth.identities (id, user_id, identity_data, provider, provider_id, last_sign_in_at, created_at, updated_at)
  values (gen_random_uuid(), p_id, jsonb_build_object('sub', p_id::text, 'email', p_email, 'email_verified', true, 'phone_verified', false),
          'email', p_id::text, now(), now(), now());
end $function$
;

CREATE OR REPLACE FUNCTION public._criar_pedido_publico(p jsonb, p_mesa_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_eh_mesa boolean := p_mesa_id is not null; v_mesa mesas%rowtype;
  v_nome text := _texto_publico(p->>'clienteNome', 80);
  v_tel text := case when p_mesa_id is not null then '' else _texto_publico(p->>'clienteTelefone', 20) end;
  v_dig text := case when p_mesa_id is not null then '' else _so_digitos(p->>'clienteTelefone') end;
  v_obs_troco text := _texto_publico(p->>'observacaoTroco', 200);
  v_de jsonb := case when jsonb_typeof(p->'dadosEntrega') = 'object' then p->'dadosEntrega' else '{}'::jsonb end;
  v_end text := _texto_publico(v_de->>'endereco', 200); v_comp text := _texto_publico(v_de->>'complemento', 100); v_ref text := _texto_publico(v_de->>'referencia', 150);
  v_obs_ent text := _texto_publico(coalesce(nullif(p->>'observacoes', ''), v_de->>'observacoes'), 300);
  v_itens jsonb := p->'itens'; v_tipo_in text := p->>'tipoEntrega'; v_ip text := _ip_cliente();
  v_req text := nullif(left(btrim(coalesce(p->>'requisicaoId', '')), 80), '');
  v_forma formas_pagamento%rowtype; v_caixa uuid; v_tipo venda_tipo; v_ja record; v_prod produtos%rowtype; v_comb combos%rowtype;
  it record; r record; v_prod_id uuid; v_comb_id uuid; v_qtd numeric; v_preco numeric; v_custo_u numeric; v_nome_item text; v_extra numeric; v_n_ad int; v_n_ok int;
  v_ads text; v_obs_item text; v_ads_ids jsonb; v_itens_ok jsonb := '[]'::jsonb; v_orig numeric := 0; v_custo numeric := 0;
  v_cod text := ''; v_cup jsonb; v_desc numeric := 0; v_frete boolean := false; v_taxa numeric := 0; v_pad numeric; v_total numeric;
  v_venda uuid := gen_random_uuid(); v_numero int; v_cli uuid; v_chave text; v_obs_final text; v_bloqueia boolean; v_forma_nome text;
begin
  -- repetição do mesmo envio (duplo toque, nova tentativa): devolve o pedido já criado, sem criar outro
  if v_req is not null then
    perform pg_advisory_xact_lock(hashtext('venda:' || v_req));
    select id, numero_pedido, valor_total into v_ja from vendas where requisicao_id = v_req;
    if found then
      return jsonb_build_object('ok', true, 'duplicado', true, 'id', v_ja.id, 'numero', v_ja.numero_pedido, 'valorTotal', v_ja.valor_total, 'message', 'Pedido já recebido — envio repetido ignorado.');
    end if;
  end if;

  if jsonb_typeof(v_itens) <> 'array' or jsonb_array_length(v_itens) = 0 then return _falha('Carrinho vazio.'); end if;
  if jsonb_array_length(v_itens) > 40 then return _falha('Carrinho grande demais.'); end if;
  if v_eh_mesa then
    if v_nome = '' then return _falha('Informe o seu nome.'); end if;
    v_chave := 'pedmesa_' || p_mesa_id::text;
  else
    if v_nome = '' or v_dig = '' then return _falha('Informe nome e telefone.'); end if;
    if length(v_dig) < 10 or length(v_dig) > 13 then return _falha('Informe um telefone válido com DDD.'); end if;
    v_chave := 'pedcard_' || v_dig;
  end if;
  if _excedeu('pedcard_global', 150) then return _falha('Estamos com muitos pedidos no momento. Tente novamente em alguns minutos ou ligue para o restaurante.'); end if;
  if _excedeu('pedcard_ip_' || v_ip, 40) then return _falha('Muitos pedidos em sequência deste local. Aguarde alguns minutos.'); end if;
  if _excedeu(v_chave, case when v_eh_mesa then 8 else 5 end) then
    return _falha(case when v_eh_mesa then 'Muitos pedidos em sequência nesta mesa. Chame o garçom.' else 'Muitos pedidos em sequência. Aguarde alguns minutos.' end);
  end if;

  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;
  if v_caixa is null then return _falha('Estamos fechados no momento. Tente novamente mais tarde.'); end if;

  if v_eh_mesa then
    select * into v_mesa from mesas where id = p_mesa_id for update;
    if not found then return _falha('Mesa não encontrada.'); end if;
    if v_mesa.status::text not in ('Livre', 'Ocupada') then
      return _falha(case when v_mesa.status::text = 'Aguardando fechamento' then 'A conta desta mesa já foi pedida. Chame o garçom para novos pedidos.' else 'Esta mesa não está disponível para pedidos pelo celular. Chame o garçom.' end);
    end if;
    v_tipo := 'Mesa';
    -- mesa: o cliente não escolhe a forma; vale a primeira forma do cardápio só para o preço (o recebimento é feito no fechamento da conta)
    select * into v_forma from formas_pagamento where ativa and visivel_cardapio order by ordem limit 1;
    v_forma_nome := 'A Receber (Mesa)';
  else
    v_tipo := (case when v_tipo_in = 'Entrega' then 'Entrega' else 'Retirada' end)::venda_tipo;
    if v_tipo = 'Entrega' and v_end = '' then return _falha('Informe o endereço de entrega.'); end if;
    select * into v_forma from formas_pagamento where id = _uuid(p->>'formaPagamentoId') and ativa and visivel_cardapio;
    v_forma_nome := v_forma.nome;
  end if;
  if v_forma.id is null then return _falha('Forma de pagamento inválida.'); end if;

  -- itens: tudo vem do cadastro (produto/combo ativo, preço da forma escolhida, adicionais ativos e vinculados)
  for it in select value as e from jsonb_array_elements(v_itens) loop
    v_qtd := _num(it.e->>'quantidade');
    if v_qtd <= 0 then continue; end if;
    if v_qtd > 50 or v_qtd <> floor(v_qtd) then return _falha('Quantidade inválida no carrinho.'); end if;
    v_prod_id := _uuid(it.e->>'produtoId'); v_comb_id := _uuid(it.e->>'comboId');
    if (v_prod_id is null) = (v_comb_id is null) then return _falha('Item inválido no carrinho.'); end if;
    if jsonb_typeof(it.e->'adicionaisIds') = 'array' and jsonb_array_length(it.e->'adicionaisIds') > 20 then return _falha('Adicionais demais em um item.'); end if;
    if v_prod_id is not null then
      select * into v_prod from produtos where id = v_prod_id and ativo;
      if not found then return _falha('Um dos produtos não está mais disponível.'); end if;
      v_nome_item := v_prod.nome;
      select preco, custo into v_preco, v_custo_u from produto_precos where produto_id = v_prod_id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_nome_item || '" não tem preço configurado para essa forma de pagamento.'); end if;
    else
      select * into v_comb from combos where id = v_comb_id and ativo;
      if not found then return _falha('Um dos combos não está mais disponível.'); end if;
      if exists (select 1 from combo_itens ci join produtos pr on pr.id = ci.produto_id where ci.combo_id = v_comb_id and not pr.ativo) then
        return _falha('O combo "' || v_comb.nome || '" está temporariamente indisponível.');
      end if;
      v_nome_item := v_comb.nome;
      select preco, custo into v_preco, v_custo_u from combo_precos where combo_id = v_comb_id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_nome_item || '" não tem preço configurado para essa forma de pagamento.'); end if;
    end if;
    select count(*), coalesce(sum(a.preco), 0),
           count(a.id) filter (where a.ativo and ((v_prod_id is not null and exists (select 1 from produto_adicionais pa where pa.produto_id = v_prod_id and pa.adicional_id = a.id)) or (v_comb_id is not null and exists (select 1 from combo_itens ci join produto_adicionais pa on pa.produto_id = ci.produto_id where ci.combo_id = v_comb_id and pa.adicional_id = a.id)))),
           coalesce(string_agg(' + ' || a.nome, '' order by s.ord) filter (where a.id is not null), ''),
           coalesce(jsonb_agg(a.id order by s.ord) filter (where a.id is not null), '[]'::jsonb)
      into v_n_ad, v_extra, v_n_ok, v_ads, v_ads_ids
      from jsonb_array_elements_text(case when jsonb_typeof(it.e->'adicionaisIds') = 'array' then it.e->'adicionaisIds' else '[]'::jsonb end) with ordinality as s(x, ord)
      left join adicionais a on a.id = _uuid(s.x);
    if v_n_ad <> v_n_ok then return _falha('Um adicional escolhido para "' || v_nome_item || '" não está disponível.'); end if;
    v_obs_item := _texto_publico(it.e->>'observacao', 100);
    v_itens_ok := v_itens_ok || jsonb_build_array(jsonb_build_object('produtoId', v_prod_id, 'comboId', v_comb_id,
      'descricao', v_nome_item || v_ads || case when v_obs_item <> '' then ' — Obs: ' || v_obs_item else '' end,
      'quantidade', v_qtd, 'valorUnitario', v_preco + v_extra, 'custoUnitario', v_custo_u, 'adicionaisIds', v_ads_ids));
    v_orig := v_orig + round(v_qtd * (v_preco + v_extra), 2); v_custo := v_custo + v_qtd * v_custo_u;
  end loop;
  if jsonb_array_length(v_itens_ok) = 0 then return _falha('Carrinho vazio.'); end if;
  v_orig := round(v_orig, 2); v_custo := round(v_custo, 2);

  select coalesce((select (valor #>> '{}') = 'true' from sistema where chave = 'BLOQUEAR_ESTOQUE_NEGATIVO'), false) into v_bloqueia;
  if v_bloqueia then
    for r in select c.ingrediente_id, c.qtd, e.quantidade from _consumo(v_itens_ok) c join estoque e on e.id = c.ingrediente_id loop
      if r.quantidade + 0.000000001 < r.qtd then return _falha('Um dos itens do pedido acabou. Escolha outro item ou fale com o restaurante.'); end if;
    end loop;
  end if;

  -- cupom (só no cardápio comum; travado por código para dois pedidos simultâneos não estourarem o limite)
  if not v_eh_mesa then
    v_cod := upper(regexp_replace(btrim(coalesce(p->>'codigoCupom', '')), '\s+', '', 'g'));
    if v_cod <> '' then
      perform pg_advisory_xact_lock(hashtext('cupom:' || v_cod));
      v_cup := _cupom_calcular(v_cod, v_tel, v_orig, v_tipo::text);
      if coalesce(v_cup->>'ok', '') <> 'true' then return v_cup; end if;
      v_desc := (v_cup->>'desconto')::numeric; v_frete := (v_cup->>'freteGratis')::boolean;
    end if;
  end if;

  if v_tipo = 'Entrega' and not v_frete then
    select coalesce(_num(valor #>> '{}'), 0) into v_pad from sistema where chave = 'TaxaEntregaPadrao';
    v_taxa := coalesce(v_pad, 0);
  end if;
  v_total := greatest(0.01, round(v_orig - v_desc + v_taxa, 2));
  v_obs_final := coalesce(concat_ws(' — ', nullif(v_obs_ent, ''), nullif(v_obs_troco, '')), '');

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido,
                      endereco, complemento, referencia, observacoes_entrega, status_pagamento, valor_original, valor_desconto,
                      desconto_detalhe, origem, mesa_id, taxa_entrega, caixa_id, requisicao_id)
  values (v_venda, v_nome, v_tel, v_forma_nome, v_total, v_custo, 'Confirmada', v_tipo, 'Recebido',
          case when v_tipo = 'Entrega' then v_end else '' end, case when v_tipo = 'Entrega' then v_comp else '' end, case when v_tipo = 'Entrega' then v_ref else '' end,
          v_obs_final, 'A Receber', v_orig, v_desc, case when v_cod <> '' then 'Cupom ' || (v_cup->>'codigo') else '' end, 'Cardápio',
          case when v_eh_mesa then p_mesa_id else null end, v_taxa, v_caixa, v_req)
  returning numero_pedido into v_numero;

  insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
  select v_venda, _uuid(e->>'produtoId'), _uuid(e->>'comboId'), e->>'descricao', _num(e->>'quantidade', 1)::int, _num(e->>'valorUnitario'), _num(e->>'custoUnitario'),
         round(_num(e->>'quantidade', 1) * _num(e->>'valorUnitario'), 2),
         coalesce((select array_agg(_uuid(x)) filter (where _uuid(x) is not null) from jsonb_array_elements_text(e->'adicionaisIds') x), '{}')
  from jsonb_array_elements(v_itens_ok) e;

  insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada)
  values (v_venda, v_forma_nome, v_total, case when v_eh_mesa then 0 else round(v_total * v_forma.taxa_percentual / 100 + v_forma.taxa_fixa, 2) end);

  if v_eh_mesa and v_mesa.status::text = 'Livre' then update mesas set status = 'Ocupada' where id = p_mesa_id; end if;
  perform _ajustar_estoque(v_itens_ok, 1, v_venda);
  if v_tel <> '' then v_cli := _upsert_cliente(v_tel, v_nome); end if;
  if v_cod <> '' then
    insert into cupons_usos (cupom_id, codigo, venda_id, cliente_id, telefone, desconto, frete_gratis, requisicao_id)
    values ((v_cup->>'cupomId')::uuid, v_cup->>'codigo', v_venda, v_cli, v_tel, v_desc, v_frete, v_req);
  end if;
  perform _registrar_falha(v_chave, 600); perform _registrar_falha('pedcard_global', 300); perform _registrar_falha('pedcard_ip_' || v_ip, 600);
  perform _auditar_publico(case when v_eh_mesa then 'Pedido recebido pelo cliente na mesa ' || v_mesa.numero else 'Pedido recebido pelo Cardápio' end,
    'Total R$ ' || _dinheiro(v_total) || case when v_cod <> '' then ' | Cupom ' || (v_cup->>'codigo') else '' end, case when v_eh_mesa then v_nome else v_tel end);

  return jsonb_build_object('ok', true, 'message', 'Pedido enviado! Nº ' || v_numero || '. Total: R$ ' || _dinheiro(v_total) || '.',
    'id', v_venda, 'numero', v_numero, 'valorTotal', v_total, 'valorOriginal', v_orig, 'valorDesconto', v_desc,
    'cupom', case when v_cod <> '' then v_cup->>'codigo' else '' end, 'freteGratis', v_frete);
end $function$
;

CREATE OR REPLACE FUNCTION public._cupom_calcular(p_codigo text, p_tel text, p_subtotal numeric, p_tipo text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c cupons%rowtype; v_cod text := upper(regexp_replace(btrim(coalesce(p_codigo, '')), '\s+', '', 'g'));
  v_tel text := _so_digitos(p_tel); v_bruto numeric := round(coalesce(p_subtotal, 0), 2); v_desc numeric := 0;
  v_agora timestamp := now() at time zone 'America/Sao_Paulo'; v_hh int; v_hi int; v_hf int; v_usos int; v_usos_cli int;
begin
  if v_cod = '' then return _falha('Informe um cupom.'); end if;
  select * into c from cupons where codigo = v_cod and ativa;
  if not found then return _falha('Cupom inválido ou inativo.'); end if;
  if (c.data_inicio is not null and v_agora::date < c.data_inicio) or (c.data_fim is not null and v_agora::date > c.data_fim) then
    return _falha('Este cupom está fora do período de validade.');
  end if;
  if c.hora_inicio is not null and c.hora_fim is not null then
    v_hh := extract(hour from v_agora)::int * 60 + extract(minute from v_agora)::int;
    v_hi := extract(hour from c.hora_inicio)::int * 60 + extract(minute from c.hora_inicio)::int;
    v_hf := extract(hour from c.hora_fim)::int * 60 + extract(minute from c.hora_fim)::int;
    if v_hi <= v_hf then
      if v_hh < v_hi or v_hh > v_hf then return _falha('Este cupom está fora do período de validade.'); end if;
    else
      if v_hh < v_hi and v_hh > v_hf then return _falha('Este cupom está fora do período de validade.'); end if;
    end if;
  end if;
  select count(*), count(*) filter (where v_tel <> '' and _so_digitos(telefone) = v_tel) into v_usos, v_usos_cli from cupons_usos where cupom_id = c.id;
  if c.limite_total > 0 and v_usos >= c.limite_total then return _falha('O limite de utilizações deste cupom foi atingido.'); end if;
  if c.limite_por_cliente > 0 and v_usos_cli >= c.limite_por_cliente then return _falha('Você já atingiu o limite de uso deste cupom.'); end if;
  if v_bruto < c.valor_minimo then return _falha('Este cupom exige pedido mínimo de R$ ' || replace(_dinheiro(c.valor_minimo), '.', ',') || '.'); end if;
  if c.tipo = 'percentual' then
    if c.valor <= 0 or c.valor > 100 then return _falha('Cupom configurado com percentual inválido.'); end if;
    v_desc := round(v_bruto * c.valor / 100, 2);
  elsif c.tipo = 'fixo' then
    if c.valor <= 0 then return _falha('Cupom configurado com valor inválido.'); end if;
    v_desc := least(v_bruto, round(c.valor, 2));
  elsif c.tipo = 'frete' then
    v_desc := 0;
  else
    return _falha('Tipo de cupom não suportado.');
  end if;
  v_desc := round(least(v_desc, greatest(0, v_bruto - 0.01)), 2);
  return jsonb_build_object('ok', true, 'cupomId', c.id, 'codigo', c.codigo, 'nome', c.nome, 'tipo', c.tipo, 'desconto', v_desc,
    'freteGratis', (c.frete_gratis or c.tipo = 'frete'), 'acumula', c.acumula,
    'limiteRestante', case when c.limite_total > 0 then greatest(0, c.limite_total - v_usos - 1) else null end);
end $function$
;

CREATE OR REPLACE FUNCTION public._cupom_validar(p jsonb, p_id uuid, OUT erro text, OUT c cupons)
 RETURNS record
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
declare v_cod text := upper(regexp_replace(btrim(coalesce(p->>'codigo', '')), '\s+', '', 'g'));
        v_tipo text := coalesce(nullif(btrim(p->>'tipo'), ''), 'percentual'); v_val numeric := _num(p->>'valor');
begin
  if v_cod !~ '^[A-Z0-9_-]{3,40}$' then erro := 'Código inválido. Use letras, números, _ ou -.'; return; end if;
  if btrim(coalesce(p->>'nome', '')) = '' then erro := 'Informe o nome da promoção.'; return; end if;
  if v_tipo <> all (array['percentual','fixo','frete']) then erro := 'Tipo de cupom inválido.'; return; end if;
  if v_tipo <> 'frete' and v_val <= 0 then erro := 'Valor do benefício inválido.'; return; end if;
  if v_tipo = 'percentual' and v_val > 100 then erro := 'Percentual não pode ultrapassar 100%.'; return; end if;
  if exists (select 1 from cupons where codigo = v_cod and id is distinct from p_id) then erro := 'Já existe um cupom com esse código.'; return; end if;
  c.codigo := v_cod; c.nome := left(btrim(p->>'nome'), 80); c.tipo := v_tipo; c.valor := case when v_tipo = 'frete' then greatest(0, v_val) else round(v_val, 2) end;
  c.frete_gratis := coalesce(p->>'freteGratis', '') in ('true', 't', 'Sim');
  c.data_inicio := _data_iso(btrim(coalesce(p->>'dataInicio', ''))); c.data_fim := _data_iso(btrim(coalesce(p->>'dataFim', '')));
  c.hora_inicio := _hora_valida(p->>'horaInicio'); c.hora_fim := _hora_valida(p->>'horaFim');
  c.limite_total := greatest(0, floor(_num(p->>'limiteTotal'))::int); c.limite_por_cliente := greatest(0, floor(_num(p->>'limitePorCliente'))::int);
  c.valor_minimo := greatest(0, round(_num(p->>'valorMinimo'), 2));
  c.ativa := coalesce(p->>'ativa', '') not in ('false', 'f', 'Não'); c.acumula := coalesce(p->>'acumula', '') in ('true', 't', 'Sim');
end $function$
;

CREATE OR REPLACE FUNCTION public._data_iso(v text)
 RETURNS date
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
begin
  if v is null or v !~ '^\d{4}-\d{2}-\d{2}$' then return null; end if;
  return v::date;
exception when others then return null;
end $function$
;

CREATE OR REPLACE FUNCTION public._dinheiro(v numeric)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public', 'pg_catalog'
AS $function$
  select to_char(coalesce(v, 0), 'FM999999990.00')
$function$
;

CREATE OR REPLACE FUNCTION public._dist_km(a_lat double precision, a_lng double precision, b_lat double precision, b_lng double precision)
 RETURNS double precision
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
  select 6371 * 2 * atan2(sqrt(x), sqrt(1 - x)) from (
    select power(sin(radians(b_lat - a_lat) / 2), 2) + cos(radians(a_lat)) * cos(radians(b_lat)) * power(sin(radians(b_lng - a_lng) / 2), 2) as x) t
$function$
;

CREATE OR REPLACE FUNCTION public._email_login(p_login text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public', 'pg_catalog'
AS $function$
  select translate(lower(btrim(p_login)), 'àáâãäåçèéêëìíîïñòóôõöùúûüýÿ', 'aaaaaaceeeeiiiinooooouuuuyy') || '@usuarios.texasburger.app'
$function$
;

CREATE OR REPLACE FUNCTION public._entrega_limpar_loc()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if old.status_pedido::text = 'Saiu para entrega' and new.status_pedido::text is distinct from 'Saiu para entrega' then
    delete from entregador_posicoes where venda_id = new.id;
  end if;
  if new.status_pedido::text in ('Entregue', 'Retirada', 'Servida') or new.status::text = 'Cancelada' then
    delete from entregador_posicoes where venda_id = new.id;
    delete from entrega_destinos where venda_id = new.id;
  end if;
  return new;
end $function$
;

CREATE OR REPLACE FUNCTION public._erro_recorrente(p_desc text, p_valor numeric, p_dia numeric, p_period text, p_inicio text, p_termino text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
  select case
    when btrim(coalesce(p_desc, '')) = '' then 'Informe a descrição.'
    when coalesce(p_valor, 0) <= 0 then 'Informe um valor maior que zero.'
    when p_valor > 9999999 then 'Valor alto demais.'
    when p_dia is null or p_dia < 1 or p_dia > 31 or p_dia <> floor(p_dia) then 'O dia do vencimento deve ser de 1 a 31.'
    when _meses_periodicidade(p_period) is null then 'Periodicidade inválida.'
    when not _comp_valida(p_inicio) then 'Informe o mês de início.'
    when coalesce(p_termino, '') <> '' and (not _comp_valida(p_termino) or p_termino < p_inicio) then 'O término deve ser um mês igual ou depois do início.'
    else '' end
$function$
;

CREATE OR REPLACE FUNCTION public._erro_senha_fraca(p_senha text, p_login text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public', 'pg_catalog'
AS $function$
  select case
    when length(coalesce(p_senha, '')) < 8 then 'A senha precisa ter ao menos 8 caracteres.'
    when p_login is not null and lower(p_senha) = lower(p_login) then 'A senha não pode ser igual ao login.'
    when p_senha ~ '^(.)\1+$' or lower(p_senha) in ('12345678','123456789','1234567890','87654321','senha123','password','qwertyui','11111111')
      then 'Essa senha é fácil demais de adivinhar. Escolha outra.'
    else '' end
$function$
;

CREATE OR REPLACE FUNCTION public._estoque_proprio(p_atual uuid, p_nome text, p_ep jsonb)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid; v_qtd numeric; v_un text;
begin
  if p_ep is null or jsonb_typeof(p_ep) <> 'object' or coalesce((p_ep->>'ativo')::boolean, false) is not true then
    return p_atual;   -- sem estoque próprio ativo: mantém o que já existia
  end if;
  v_un := coalesce(nullif(p_ep->>'unidade', ''), 'un');
  if v_un not in ('un','g','kg','ml','l') then v_un := 'un'; end if;
  if p_atual is not null and exists (select 1 from estoque where id = p_atual) then
    update estoque set ingrediente = p_nome, quantidade_minima = _num(p_ep->>'minimo'), unidade = v_un::unidade_estoque,
           custo_unitario = _num(p_ep->>'custo') where id = p_atual;   -- mantém a quantidade atual
    return p_atual;
  end if;
  select id into v_id from estoque where ingrediente = p_nome limit 1;   -- já existe um com esse nome: reaproveita
  if v_id is not null then return v_id; end if;
  v_id := gen_random_uuid(); v_qtd := _num(p_ep->>'quantidade');
  insert into estoque (id, ingrediente, quantidade, quantidade_minima, unidade, custo_unitario, status)
  values (v_id, p_nome, v_qtd, _num(p_ep->>'minimo'), v_un::unidade_estoque, _num(p_ep->>'custo'), 'Ativo');
  if v_qtd > 0 then
    insert into movimentacoes_estoque (ingrediente_id, tipo, quantidade, qtd_antes, qtd_depois, motivo_referencia, usuario_id)
    values (v_id, 'Entrada', v_qtd, 0, v_qtd, 'Estoque inicial do cadastro', auth.uid());
  end if;
  return v_id;
end $function$
;

CREATE OR REPLACE FUNCTION public._evento_json(p_id uuid)
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select jsonb_build_object('id', e.id, 'nome', e.nome, 'tipo', coalesce(e.tipo, ''), 'data', coalesce(e.data::text, ''),
    'horaInicio', coalesce(to_char(e.hora_inicio, 'HH24:MI'), ''), 'horaFim', coalesce(to_char(e.hora_fim, 'HH24:MI'), ''),
    'local', coalesce(e.local, ''), 'contratante', coalesce(e.contratante, ''), 'telefone', coalesce(e.telefone, ''), 'status', coalesce(e.status, 'Orçamento'),
    'valorContratado', e.valor_contratado, 'valorRecebido', e.valor_recebido, 'valorAReceber', e.valor_a_receber, 'custoTotal', e.custo_total,
    'resultado', e.resultado, 'observacoes', coalesce(e.observacoes, ''), 'criadoEm', e.criado_em, 'atualizadoEm', e.atualizado_em)
  from eventos e where e.id = p_id
$function$
;

CREATE OR REPLACE FUNCTION public._excedeu(p_chave text, p_max integer)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select coalesce((select falhas >= p_max and bloqueado_ate > now() from tentativas where chave = p_chave), false)
$function$
;

CREATE OR REPLACE FUNCTION public._exige_admin(p_senha text)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'auth', 'extensions'
AS $function$
declare v_eu usuarios%rowtype; v_chave text; v_adm record;
begin
  select * into v_eu from usuarios where id = auth.uid() and ativo;
  if not found then return null; end if;
  if v_eu.nivel::text in ('Admin','Desenvolvedor') then perform set_config('app.autorizador', v_eu.login, true); return v_eu.login; end if;
  if coalesce(p_senha, '') = '' then return null; end if;
  v_chave := 'falhas_admin_' || lower(v_eu.login);
  if _excedeu(v_chave, 5) then return null; end if;
  select us.login into v_adm from usuarios us join auth.users au on au.id = us.id
    where us.nivel in ('Admin','Desenvolvedor') and us.ativo and au.encrypted_password = crypt(p_senha, au.encrypted_password) limit 1;
  if found then
    perform _limpar_falhas(v_chave);
    perform set_config('app.autorizador', v_adm.login, true);
    return v_adm.login;
  end if;
  perform _registrar_falha(v_chave);
  perform _auditar('Falha na senha de administrador', 'Tentativa por ' || v_eu.login);
  return null;
end $function$
;

CREATE OR REPLACE FUNCTION public._falha(p_msg text)
 RETURNS jsonb
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public', 'pg_catalog'
AS $function$
  select jsonb_build_object('ok', false, 'message', p_msg)
$function$
;

CREATE OR REPLACE FUNCTION public._gerar_despesas_recorrentes(p_comp text)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r record; v_ini date; v_dias int; v_dia int; v_venc date; v_meses int; v_n int := 0; v_lin int;
begin
  if not _comp_valida(p_comp) then return 0; end if;
  v_ini := (p_comp || '-01')::date;
  v_dias := extract(day from (v_ini + interval '1 month' - interval '1 day'))::int;
  for r in select * from despesas_recorrentes
            where ativa and inicio is not null and date_trunc('month', inicio)::date <= v_ini
              and (termino is null or v_ini <= date_trunc('month', termino)::date) loop
    v_meses := (extract(year from v_ini)::int * 12 + extract(month from v_ini)::int) - (extract(year from r.inicio)::int * 12 + extract(month from r.inicio)::int);
    continue when v_meses < 0 or v_meses % coalesce(_meses_periodicidade(r.periodicidade), 1) <> 0;
    v_dia := least(coalesce(r.dia_vencimento, 1), v_dias);
    v_venc := v_ini + (v_dia - 1);
    insert into despesas (data_hora, descricao, valor, observacao, status, categoria, vencimento, situacao, recorrente_id, competencia, saiu_do_caixa)
    values (_meio_dia(v_venc), r.descricao, r.valor, coalesce(r.observacao, ''), 'A pagar', coalesce(r.categoria, 'Outros'), v_venc, 'A pagar', r.id, p_comp, false)
    on conflict (recorrente_id, competencia) where recorrente_id is not null do nothing;
    get diagnostics v_lin = row_count;
    v_n := v_n + v_lin;
  end loop;
  if v_n > 0 then perform _auditar('Despesas mensais geradas', p_comp || ': ' || v_n || ' conta(s)'); end if;
  return v_n;
end $function$
;

CREATE OR REPLACE FUNCTION public._hora_valida(v text)
 RETURNS time without time zone
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
begin
  if v is null or btrim(v) !~ '^\d{1,2}:\d{2}(:\d{2})?$' then return null; end if;
  return btrim(v)::time;
exception when others then return null;
end $function$
;

CREATE OR REPLACE FUNCTION public._ia_mascara(j jsonb, p_adm boolean)
 RETURNS jsonb
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO ''
AS $function$
  select coalesce(jsonb_object_agg(e.k,
           case when jsonb_typeof(e.v) = 'string' and e.k ~* '(texto|coment|observ|resumo|descri|mensagem|motivo|detalhe|solucao|pilha)'
                then to_jsonb(public._ia_scrub(e.v #>> '{}')) else e.v end), '{}'::jsonb)
  from jsonb_each(j) e(k, v)
  where not public._ia_oculta(e.k, p_adm)
$function$
;

CREATE OR REPLACE FUNCTION public._ia_oculta(p_coluna text, p_adm boolean)
 RETURNS boolean
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO ''
AS $function$
  select p_coluna ~* '(senha|hash|token|chave|secret|refresh|password|apikey|api_key)'
      or p_coluna ~* '(telefone|celular|whatsapp|^fone|endereco|complemento|^referencia$|^lat$|^lng$|latitude|longitude|e_?mail|cpf|cnpj|nascimento|^login$)'
      or (not p_adm and p_coluna ~* '(custo|taxa|valor_total|^total|_total|lucro|resultado|saldo|valor_contrat|valor_receb|valor_a_receber)')
$function$
;

CREATE OR REPLACE FUNCTION public._ia_scrub(t text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO ''
AS $function$
  select regexp_replace(regexp_replace(regexp_replace(coalesce(t,''),
    '(\+?55[\s.-]?)?\(?\d{2}\)?[\s.-]?9?\d{4}[\s.-]?\d{4}', '[telefone oculto]', 'g'),
    '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}', '[e-mail oculto]', 'g'),
    '\d{3}\.\d{3}\.\d{3}-\d{2}', '[cpf oculto]', 'g')
$function$
;

CREATE OR REPLACE FUNCTION public._ia_tabelas(p_adm boolean)
 RETURNS text[]
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO ''
AS $function$
  select case when p_adm then array[
    'adicionais','ajustes_pos_venda','auditoria','brindes','caixa_sessoes','categorias','chat_conversas','clientes',
    'combo_itens','combo_precos','combos','cupons','cupons_usos','despesas','despesas_recorrentes','entregas_fechadas',
    'estoque','eventos','eventos_custos','eventos_recebimentos','faq_publico','fechamentos_entrega','feedbacks','fidelidade',
    'formas_pagamento','indicacoes','integridade_checks','itens_venda','mesas','movimentacoes_estoque','ocorrencias',
    'pagamentos_venda','produto_adicionais','produto_ingredientes','produto_precos','produtos','promocoes','sangrias','vendas',
    -- ampliação (Admin e Desenvolvedor): entregas, atendimento, saúde do sistema. Continuam FORA: usuarios, senhas, chaves,
    -- tokens, códigos de mesa, segredos da IA e configuração da contingência.
    'pedido_destinos','entrega_destinos','entregador_posicoes','chat_mensagens','erros_cliente',
    'ai_log','ai_uso','usuarios','arquivo_historico','backups','sync_estado']
  else array[
    'adicionais','categorias','combo_itens','combo_precos','combos','cupons','estoque','faq_publico','formas_pagamento',
    'mesas','movimentacoes_estoque','produto_adicionais','produto_ingredientes','produto_precos','produtos','promocoes'] end
$function$
;

CREATE OR REPLACE FUNCTION public._idem_gravar(p_chave text, p_acao text, p_resultado jsonb)
 RETURNS void
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  insert into requisicoes (chave, acao, resultado, usuario_id) values (p_chave, p_acao, p_resultado, auth.uid())
  on conflict (chave) do nothing
$function$
;

CREATE OR REPLACE FUNCTION public._idem_ler(p_chave text)
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select resultado from requisicoes where chave = p_chave
$function$
;

CREATE OR REPLACE FUNCTION public._ip_cliente()
 RETURNS text
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'public'
AS $function$
declare h jsonb; ip text;
begin
  begin h := nullif(current_setting('request.headers', true), '')::jsonb; exception when others then h := null; end;
  ip := coalesce(nullif(h->>'cf-connecting-ip', ''), nullif(h->>'x-real-ip', ''), nullif(split_part(coalesce(h->>'x-forwarded-for', ''), ',', 1), ''));
  if ip is null then
    ip := 'sem-ip-' || left(md5(coalesce(h->>'user-agent', '') || '|' || coalesce(h->>'accept-language', '')), 12);
  end if;
  return left(btrim(ip), 45);
end $function$
;

CREATE OR REPLACE FUNCTION public._itens_da_venda(p_venda uuid)
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select coalesce(jsonb_agg(jsonb_build_object('produtoId', i.produto_id, 'comboId', i.combo_id, 'quantidade', i.quantidade,
                                               'adicionaisIds', to_jsonb(i.adicionais_ids))), '[]'::jsonb)
  from itens_venda i where i.venda_id = p_venda
$function$
;

CREATE OR REPLACE FUNCTION public._lancar_pagamento_entregador(p_fid uuid, p_entregador uuid, p_dia date, p_taxas numeric, p_pago numeric, p_forma text, p_caixa_aberto boolean)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_nome text; v_repasse numeric; v_ajuda numeric; v_sai boolean; v_rot text;
begin
  select coalesce(nullif(btrim(nome), ''), login) into v_nome from usuarios where id = p_entregador;
  v_sai := (p_forma = 'Dinheiro') and p_caixa_aberto;
  v_repasse := round(least(p_pago, p_taxas), 2);
  v_ajuda := round(p_pago - v_repasse, 2);
  v_rot := v_nome || ' (' || to_char(p_dia, 'DD/MM/YYYY') || ')';
  if v_repasse > 0 then
    insert into despesas (descricao, valor, status, situacao, categoria, saiu_do_caixa, observacao, requisicao_id)
    values ('Repasse de taxas de entrega — ' || v_rot, v_repasse, 'Paga', 'Paga', 'Entregadores', v_sai, 'Pago em ' || p_forma, 'ent-' || p_fid::text || '-taxas');
  end if;
  if v_ajuda > 0 then
    insert into despesas (descricao, valor, status, situacao, categoria, saiu_do_caixa, observacao, requisicao_id)
    values ('Ajuda de custo diária — ' || v_rot, v_ajuda, 'Paga', 'Paga', 'Entregadores', v_sai, 'Pago em ' || p_forma, 'ent-' || p_fid::text || '-ajuda');
  end if;
end $function$
;

CREATE OR REPLACE FUNCTION public._limpar_falhas(p_chave text)
 RETURNS void
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  delete from tentativas where chave = p_chave
$function$
;

CREATE OR REPLACE FUNCTION public._lista_curta(p_itens text[])
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public', 'pg_catalog'
AS $function$
  select array_to_string(p_itens[1:6], ', ') || case when coalesce(array_length(p_itens, 1), 0) > 6 then ' e mais ' || (array_length(p_itens, 1) - 6) else '' end
$function$
;

CREATE OR REPLACE FUNCTION public._lista_qr_mesas()
 RETURNS jsonb
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select coalesce(jsonb_agg(jsonb_build_object('id', m.id, 'numero', m.numero, 'codigo', c.codigo)
         order by case when m.numero ~ '^\d{1,9}$' then m.numero::int end, m.numero), '[]'::jsonb)
  from mesas m join mesas_codigos c on c.mesa_id = m.id
$function$
;

CREATE OR REPLACE FUNCTION public._login_de(p_id uuid)
 RETURNS text
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select login from usuarios where id = p_id
$function$
;

CREATE OR REPLACE FUNCTION public._meio_dia(d date)
 RETURNS timestamp with time zone
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
  select (d::timestamp + interval '12 hours') at time zone 'America/Sao_Paulo'
$function$
;

CREATE OR REPLACE FUNCTION public._mesa_numero_de(p_id uuid)
 RETURNS text
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select numero::text from public.mesas where id = p_id
$function$
;

CREATE OR REPLACE FUNCTION public._mesa_qr(p_numero text, p_codigo text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_ip text := _ip_cliente(); v_cod text := btrim(coalesce(p_codigo, '')); v_id uuid;
begin
  if _excedeu('mesaqr_ip_' || v_ip, 15) or _excedeu('mesaqr_fail', 200) then
    return jsonb_build_object('ok', false, 'message', 'Muitas tentativas. Aguarde alguns minutos ou chame o garçom.');
  end if;
  select me.id into v_id from mesas me join mesas_codigos mc on mc.mesa_id = me.id
   where me.numero = btrim(coalesce(p_numero, '')) and v_cod <> '' and mc.codigo = v_cod;
  if v_id is null then
    perform _registrar_falha('mesaqr_ip_' || v_ip, 600); perform _registrar_falha('mesaqr_fail', 600);
    return jsonb_build_object('ok', false, 'invalido', true, 'message', 'QR Code inválido ou desativado. Chame o garçom.');
  end if;
  return jsonb_build_object('ok', true, 'mesaId', v_id);
end $function$
;

CREATE OR REPLACE FUNCTION public._meses_periodicidade(p text)
 RETURNS integer
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
  select case p when 'Mensal' then 1 when 'Bimestral' then 2 when 'Trimestral' then 3 when 'Semestral' then 6 when 'Anual' then 12 end
$function$
;

CREATE OR REPLACE FUNCTION public._negado()
 RETURNS jsonb
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public', 'pg_catalog'
AS $function$
  select jsonb_build_object('ok', false, 'message', 'Seu perfil não tem permissão para esta ação.')
$function$
;

CREATE OR REPLACE FUNCTION public._num(v text, padrao numeric DEFAULT 0)
 RETURNS numeric
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'public', 'pg_catalog'
AS $function$
begin
  return coalesce(nullif(btrim(v), '')::numeric, padrao);
exception when others then
  return padrao;
end $function$
;

CREATE OR REPLACE FUNCTION public._pedido_trava(p jsonb, OUT v vendas, OUT erro jsonb)
 RETURNS record
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  select * into v from vendas where id = _uuid(p->>'vendaId') for update;
  if not found then erro := _falha('Pedido não encontrado.');
  elsif v.status <> 'Confirmada' then erro := _falha('Este pedido foi cancelado.');
  elsif v.fechamento_entrega_id is not null then erro := _falha('Esta entrega já está em um fechamento — não pode mais ser alterada.');
  end if;
end $function$
;

CREATE OR REPLACE FUNCTION public._precos_ou_base(p jsonb)
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select case when jsonb_typeof(p->'precos') = 'array' and jsonb_array_length(p->'precos') > 0 then p->'precos'
    else coalesce((select jsonb_agg(jsonb_build_object('formaPagamentoId', f.id, 'preco', _num(p->>'precoBase'), 'custo', _num(p->>'custoBase'))) from formas_pagamento f), '[]'::jsonb) end
$function$
;

CREATE OR REPLACE FUNCTION public._produto_gravar_adicionais(p_prod uuid, p_ads jsonb)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  delete from produto_adicionais where produto_id = p_prod;
  insert into produto_adicionais (produto_id, adicional_id)
  select distinct p_prod, _uuid(x) from jsonb_array_elements_text(coalesce(p_ads, '[]'::jsonb)) x where _uuid(x) is not null
  on conflict (produto_id, adicional_id) do nothing;
end $function$
;

CREATE OR REPLACE FUNCTION public._produto_gravar_precos(p_prod uuid, p_precos jsonb)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  delete from produto_precos where produto_id = p_prod;
  insert into produto_precos (produto_id, forma_pagamento_id, preco, custo)
  select p_prod, _uuid(e->>'formaPagamentoId'), _num(e->>'preco'), _num(e->>'custo')
  from jsonb_array_elements(coalesce(p_precos, '[]'::jsonb)) e
  where _uuid(e->>'formaPagamentoId') is not null
  on conflict (produto_id, forma_pagamento_id) do update set preco = excluded.preco, custo = excluded.custo;
end $function$
;

CREATE OR REPLACE FUNCTION public._produto_gravar_receita(p_prod uuid, p_ingr jsonb, p_proprio uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  delete from produto_ingredientes where produto_id = p_prod;
  insert into produto_ingredientes (produto_id, ingrediente_id, quantidade_por_unidade)
  select p_prod, _uuid(e->>'ingredienteId'), _num(e->>'quantidadePorUnidade')
  from jsonb_array_elements(coalesce(p_ingr, '[]'::jsonb)) e where _uuid(e->>'ingredienteId') is not null;
  if p_proprio is not null then
    insert into produto_ingredientes (produto_id, ingrediente_id, quantidade_por_unidade) values (p_prod, p_proprio, 1);
  end if;
end $function$
;

CREATE OR REPLACE FUNCTION public._proteger_desenvolvedor_usuarios()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
declare
  v_eu uuid := auth.uid();
  v_eh_dev boolean := false;
begin
  if tg_op = 'UPDATE' then
    if old.nivel::text <> 'Desenvolvedor' and new.nivel::text <> 'Desenvolvedor' then
      return new;
    end if;
  elsif tg_op = 'DELETE' then
    if old.nivel::text <> 'Desenvolvedor' then
      return old;
    end if;
  end if;

  select exists (
    select 1
    from public.usuarios u
    where u.id = v_eu
      and u.ativo
      and u.nivel::text = 'Desenvolvedor'
  ) into v_eh_dev;

  if not v_eh_dev then
    raise exception 'Acesso de Desenvolvedor é protegido: somente um Desenvolvedor pode alterar, promover ou excluir esse usuário.'
      using errcode = '42501';
  end if;

  if tg_op = 'UPDATE' then
    return new;
  end if;
  return old;
end;
$function$
;

CREATE OR REPLACE FUNCTION public._recalcular_evento(p_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_contr numeric; v_custos numeric; v_rec numeric;
begin
  select valor_contratado into v_contr from eventos where id = p_id;
  if not found then return; end if;
  select coalesce(sum(valor), 0) into v_custos from eventos_custos where evento_id = p_id;
  select coalesce(sum(valor), 0) into v_rec from eventos_recebimentos where evento_id = p_id;
  update eventos set valor_recebido = v_rec, valor_a_receber = greatest(0, v_contr - v_rec), custo_total = v_custos,
         resultado = round(v_contr - v_custos, 2) where id = p_id;
end $function$
;

CREATE OR REPLACE FUNCTION public._registrar_falha(p_chave text, p_seg integer DEFAULT 600)
 RETURNS integer
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare t tentativas%rowtype;
begin
  select * into t from tentativas where chave = p_chave for update;
  if not found then
    insert into tentativas (chave, falhas, bloqueado_ate) values (p_chave, 1, now() + make_interval(secs => p_seg));
    return 1;
  end if;
  if t.bloqueado_ate is null or t.bloqueado_ate <= now() then
    update tentativas set falhas = 1, bloqueado_ate = now() + make_interval(secs => p_seg) where chave = p_chave;
    return 1;
  end if;
  update tentativas set falhas = falhas + 1 where chave = p_chave;
  return t.falhas + 1;
end $function$
;

CREATE OR REPLACE FUNCTION public._saldo_gaveta_aberta()
 RETURNS numeric
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare s caixa_sessoes%rowtype; v_din numeric; v_desp numeric; v_sang numeric; v_nomes text[];
begin
  select * into s from caixa_sessoes where status = 'Aberto' limit 1;
  if not found then return null; end if;
  select coalesce(array_agg(nome), '{}') into v_nomes from formas_pagamento where permite_troco;
  if coalesce(array_length(v_nomes, 1), 0) = 0 then v_nomes := array['Dinheiro']; end if;
  select coalesce(sum(pv.valor), 0) into v_din from pagamentos_venda pv join vendas v on v.id = pv.venda_id
   where v.status = 'Confirmada' and v.status_pagamento <> 'A Receber' and coalesce(v.recebido_em, v.data_hora) >= s.abertura and pv.forma_pagamento = any(v_nomes);
  select coalesce(sum(valor), 0) into v_desp from despesas where status = 'Paga' and saiu_do_caixa and data_hora >= s.abertura;
  select coalesce(sum(valor), 0) into v_sang from sangrias where data_hora >= s.abertura;
  return round(s.fundo_caixa + v_din - v_desp - v_sang, 2);
end $function$
;

CREATE OR REPLACE FUNCTION public._senha_confere(p_user uuid, p_senha text)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'auth', 'extensions'
AS $function$
  select coalesce((select u.encrypted_password = crypt(p_senha, u.encrypted_password) from auth.users u where u.id = p_user), false)
$function$
;

CREATE OR REPLACE FUNCTION public._so_digitos(t text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public', 'pg_catalog'
AS $function$
  select regexp_replace(coalesce(t, ''), '\D', '', 'g')
$function$
;

CREATE OR REPLACE FUNCTION public._texto_publico(t text, mx integer)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public', 'pg_catalog'
AS $function$
  select btrim(left(btrim(replace(replace(regexp_replace(regexp_replace(coalesce(t, ''), '[' || chr(1) || '-' || chr(31) || chr(127) || ']+', ' ', 'g'), '[<>`]', '', 'g'), '"', '”'), '''', '’')), greatest(mx, 0)))
$function$
;

CREATE OR REPLACE FUNCTION public._travar_unico_desenvolvedor()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
begin
  if tg_op = 'DELETE' then
    if old.nivel::text = 'Desenvolvedor' then
      raise exception 'O acesso de Desenvolvedor não pode ser excluído.' using errcode = '42501';
    end if;
    return old;
  end if;
  if new.nivel::text = 'Desenvolvedor' and (tg_op = 'INSERT' or old.nivel::text <> 'Desenvolvedor') then
    raise exception 'O acesso de Desenvolvedor já existe. Não é possível criar outro.' using errcode = '42501';
  end if;
  return new;
end $function$
;

CREATE OR REPLACE FUNCTION public._upsert_cliente(p_tel text, p_nome text)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid; v_dig text := _so_digitos(p_tel);
begin
  if v_dig = '' then return null; end if;
  -- pedidos simultâneos do mesmo telefone passam um de cada vez (o segundo já encontra o cliente criado pelo primeiro)
  perform pg_advisory_xact_lock(hashtextextended('cliente:' || v_dig, 0));
  select id into v_id from clientes where _so_digitos(telefone) = v_dig limit 1;
  if found then
    if btrim(coalesce(p_nome, '')) <> '' then update clientes set nome = btrim(p_nome) where id = v_id and btrim(coalesce(nome, '')) = ''; end if;
    return v_id;
  end if;
  begin
    v_id := gen_random_uuid();
    insert into clientes (id, nome, telefone, primeiro_contato) values (v_id, btrim(coalesce(p_nome, '')), btrim(p_tel), now());
  exception when unique_violation then
    -- rede de segurança (índice único por dígitos): outro caminho criou o mesmo telefone no meio tempo
    select id into v_id from clientes where _so_digitos(telefone) = v_dig limit 1;
    if v_id is null then raise; end if;
  end;
  return v_id;
end $function$
;

CREATE OR REPLACE FUNCTION public._uuid(v text)
 RETURNS uuid
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'public', 'pg_catalog'
AS $function$
begin
  return nullif(btrim(v), '')::uuid;
exception when others then
  return null;
end $function$
;

CREATE OR REPLACE FUNCTION public._validar_adicionais_item_venda()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
declare
  v_total integer := coalesce(array_length(new.adicionais_ids, 1), 0);
  v_ok integer := 0;
begin
  if v_total = 0 then
    return new;
  end if;

  if (new.produto_id is null) = (new.combo_id is null) then
    raise exception 'Item de venda inválido: informe produto ou combo, mas não ambos.' using errcode = '23514';
  end if;

  if new.produto_id is not null then
    select count(*)
      into v_ok
      from unnest(new.adicionais_ids) aid
      join public.adicionais a on a.id = aid
      where a.ativo
        and exists (
          select 1
          from public.produto_adicionais pa
          where pa.produto_id = new.produto_id
            and pa.adicional_id = a.id
        );
  else
    select count(*)
      into v_ok
      from unnest(new.adicionais_ids) aid
      join public.adicionais a on a.id = aid
      where a.ativo
        and exists (
          select 1
          from public.combo_itens ci
          join public.produto_adicionais pa on pa.produto_id = ci.produto_id
                                           and pa.adicional_id = a.id
          where ci.combo_id = new.combo_id
        );
  end if;

  if v_ok <> v_total then
    raise exception 'Um adicional escolhido não está ativo ou não pertence ao produto/combo informado.' using errcode = '23514';
  end if;

  return new;
end;
$function$
;

CREATE OR REPLACE FUNCTION public._validar_forma(pct numeric, fixa numeric, prazo numeric)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public', 'pg_catalog'
AS $function$
  select case
    when pct < 0 or pct > 100 then 'A taxa % deve ficar entre 0 e 100.'
    when fixa < 0 then 'A taxa fixa não pode ser negativa.'
    when prazo < 0 or prazo > 365 or prazo <> floor(prazo) then 'O prazo deve ser um número inteiro de dias (0 a 365).'
    else '' end
$function$
;

CREATE OR REPLACE FUNCTION public._versao_conflita(p jsonb, p_tab text, p_id uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_esp text := btrim(coalesce(p->>'versaoEsperada', '')); v_atual text;
begin
  -- sem versão no pedido (aparelho antigo, contingência): não trava, como na planilha
  if v_esp = '' or p_id is null then return false; end if;
  if p_tab <> all (array['produtos','combos','adicionais','formas_pagamento','categorias','clientes','cupons','eventos','despesas','despesas_recorrentes','usuarios','vendas']) then
    raise exception 'Tabela sem controle de versão: %', p_tab;
  end if;
  -- trava a linha até o fim da transação: ninguém altera entre a conferência e a gravação
  execute format('select 1 from public.%I where id = $1 for update', p_tab) using p_id;
  select ver into v_atual from _versoes_tabela(p_tab, p_id);
  return v_atual is distinct from v_esp;
end $function$
;

CREATE OR REPLACE FUNCTION public._versoes_tabela(p_tab text, p_id uuid DEFAULT NULL::uuid)
 RETURNS TABLE(rid uuid, ver text)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  -- "versão" = carimbo (md5) do conteúdo que a pessoa vê/edita; muda sempre que o registro (ou seus filhos) muda
  if p_tab = 'produtos' then
    return query select x.id, md5(
        (to_jsonb(x) - 'foto_id_principal' - 'foto_id_contingencia' - 'foto_url_principal' - 'foto_url_contingencia' - 'foto_preferida')::text
        || '|' || coalesce((select jsonb_agg(jsonb_build_array(a.forma_pagamento_id, a.preco, a.custo) order by a.forma_pagamento_id)::text from produto_precos a where a.produto_id = x.id), '')
        || '|' || coalesce((select jsonb_agg(jsonb_build_array(a.ingrediente_id, a.quantidade_por_unidade) order by a.ingrediente_id)::text from produto_ingredientes a where a.produto_id = x.id), '')
        || '|' || coalesce((select jsonb_agg(a.adicional_id order by a.adicional_id)::text from produto_adicionais a where a.produto_id = x.id), ''))
      from produtos x where p_id is null or x.id = p_id;
  elsif p_tab = 'combos' then
    return query select x.id, md5(
        (to_jsonb(x) - 'foto_id_principal' - 'foto_id_contingencia' - 'foto_url_principal' - 'foto_url_contingencia' - 'foto_preferida')::text
        || '|' || coalesce((select jsonb_agg(jsonb_build_array(a.forma_pagamento_id, a.preco, a.custo) order by a.forma_pagamento_id)::text from combo_precos a where a.combo_id = x.id), '')
        || '|' || coalesce((select jsonb_agg(jsonb_build_array(a.produto_id, a.quantidade) order by a.produto_id, a.quantidade)::text from combo_itens a where a.combo_id = x.id), ''))
      from combos x where p_id is null or x.id = p_id;
  elsif p_tab = 'vendas' then
    return query select x.id, md5(
        jsonb_build_array(x.status, x.status_pedido, x.valor_total, x.valor_original, x.valor_desconto, x.forma_pagamento, x.status_pagamento, x.tipo)::text
        || '|' || coalesce((select jsonb_agg(jsonb_build_array(i.produto_id, i.combo_id, i.descricao, i.quantidade, i.valor_unitario, i.custo_unitario)
                                              order by i.descricao, i.produto_id, i.combo_id, i.valor_unitario, i.quantidade)::text
                              from itens_venda i where i.venda_id = x.id), ''))
      from vendas x where p_id is null or x.id = p_id;
  elsif p_tab = 'adicionais' then
    return query select x.id, md5(to_jsonb(x)::text) from adicionais x where p_id is null or x.id = p_id;
  elsif p_tab = 'formas_pagamento' then
    return query select x.id, md5(to_jsonb(x)::text) from formas_pagamento x where p_id is null or x.id = p_id;
  elsif p_tab = 'categorias' then
    return query select x.id, md5(to_jsonb(x)::text) from categorias x where p_id is null or x.id = p_id;
  elsif p_tab = 'clientes' then
    return query select x.id, md5(to_jsonb(x)::text) from clientes x where p_id is null or x.id = p_id;
  elsif p_tab = 'cupons' then
    return query select x.id, md5(to_jsonb(x)::text) from cupons x where p_id is null or x.id = p_id;
  elsif p_tab = 'eventos' then
    return query select x.id, md5(to_jsonb(x)::text) from eventos x where p_id is null or x.id = p_id;
  elsif p_tab = 'despesas' then
    return query select x.id, md5(to_jsonb(x)::text) from despesas x where p_id is null or x.id = p_id;
  elsif p_tab = 'despesas_recorrentes' then
    return query select x.id, md5(to_jsonb(x)::text) from despesas_recorrentes x where p_id is null or x.id = p_id;
  elsif p_tab = 'usuarios' then
    return query select x.id, md5(to_jsonb(x)::text) from usuarios x where p_id is null or x.id = p_id;
  else
    raise exception 'Tabela sem controle de versão: %', p_tab;
  end if;
end $function$
;

CREATE OR REPLACE FUNCTION public.api_abrir_caixa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_fundo numeric := round(_num(p->>'fundoCaixa'), 2);
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if v_fundo < 0 then return _falha('O fundo de caixa não pode ser negativo.'); end if;
  if exists (select 1 from caixa_sessoes where status = 'Aberto') then return _falha('Já existe um caixa aberto. Feche-o antes de abrir outro.'); end if;
  begin
    insert into caixa_sessoes (fundo_caixa, usuario_abertura, status) values (v_fundo, auth.uid(), 'Aberto');
  exception when unique_violation then
    return _falha('Já existe um caixa aberto. Feche-o antes de abrir outro.');
  end;
  perform _auditar('Caixa aberto', 'Fundo de caixa: R$ ' || _dinheiro(v_fundo));
  return jsonb_build_object('ok', true, 'message', 'Caixa aberto.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_aceitar_pedido(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare t record; v vendas; v_eu uuid := auth.uid(); v_nivel text;
begin
  if not tem_nivel('Admin','Operador','Cozinha','Garçom') then return _negado(); end if;
  select * into t from _pedido_trava(p); v := t.v; if t.erro is not null then return t.erro; end if;
  if v.status_pedido::text <> 'Recebido' then return _conflito('Esse pedido não está mais aguardando aceite.'); end if;
  v_nivel := auth_nivel()::text;
  -- Garçom aceita só pedidos do seu escopo (mesas dele ou registrados por ele)
  if v_nivel = 'Garçom' and not (v.registrado_por = v_eu or exists (select 1 from mesas m where m.id = v.mesa_id and m.garcom_responsavel_id = v_eu)) then
    return _falha('Este pedido não está no seu escopo operacional.');
  end if;
  -- aceitou = já entra em preparo na cozinha (aparece na coluna "Em preparo")
  update vendas set status_pedido = 'Em preparo', inicio_preparo_em = coalesce(inicio_preparo_em, now()) where id = v.id;
  perform _auditar('Pedido aceito', '#' || v.numero_pedido || ' — em preparo', v.telefone_cliente);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_add_adicional(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_nome text := btrim(coalesce(p->>'nome', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_nome = '' then return _falha('Informe o nome do adicional.'); end if;
  if exists (select 1 from adicionais where lower(btrim(nome)) = lower(v_nome)) then return _falha('Já existe um adicional com esse nome.'); end if;
  insert into adicionais (nome, preco, ativo, ingrediente_id, quantidade_descontar)
  values (v_nome, _num(p->>'preco'), true, _uuid(p->>'ingredienteId'), coalesce(nullif(_num(p->>'quantidadeDesconto'), 0), 1));
  perform _auditar('Adicional cadastrado', v_nome);
  return jsonb_build_object('ok', true, 'message', 'Adicional cadastrado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_add_categoria(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_nome text := btrim(coalesce(p->>'nome', '')); v_ordem int;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_nome = '' then return _falha('Informe o nome da categoria.'); end if;
  if exists (select 1 from categorias where lower(nome) = lower(v_nome)) then return _falha('Já existe uma categoria com esse nome.'); end if;
  select coalesce(max(ordem), 0) + 1 into v_ordem from categorias;
  insert into categorias (nome, ativa, ordem) values (v_nome, true, v_ordem);
  perform _auditar('Categoria cadastrada', v_nome);
  return jsonb_build_object('ok', true, 'message', 'Categoria cadastrada.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_add_combo(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_nome text := btrim(coalesce(p->>'nome', '')); v_id uuid := gen_random_uuid(); v_cat uuid := _uuid(p->>'categoria'); v_ordem int;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_nome = '' then return _falha('Informe o nome do combo.'); end if;
  if exists (select 1 from combos where lower(btrim(nome)) = lower(v_nome)) then return _falha('Já existe um combo com esse nome.'); end if;
  select coalesce(max(ordem_cardapio), 0) + 1 into v_ordem from combos where categoria_id is not distinct from v_cat;
  insert into combos (id, nome, categoria_id, ativo, destaque, ordem_cardapio)
  values (v_id, v_nome, v_cat, true, coalesce((p->>'destaque')::boolean, false), v_ordem);
  perform _combo_gravar_precos(v_id, _precos_ou_base(p));
  perform _combo_gravar_itens(v_id, p->'itens');
  perform _auditar('Combo cadastrado', v_nome);
  return jsonb_build_object('ok', true, 'message', 'Combo cadastrado.', 'id', v_id);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_add_despesa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_desc text := btrim(coalesce(p->>'descricao', '')); v_valor numeric := round(_num(p->>'valor'), 2);
        v_admin boolean := tem_nivel('Admin'); v_req text := nullif(p->>'requisicaoId', ''); v_r jsonb;
        v_sit text; v_caixa boolean; v_cat text; v_venc date := _data_iso(p->>'vencimento'); v_quando timestamptz;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if v_req is not null then perform pg_advisory_xact_lock(hashtext(v_req)); v_r := _idem_ler(v_req); if v_r is not null then return v_r; end if; end if;
  if v_desc = '' then return _falha('Informe a descrição da despesa.'); end if;
  if v_valor <= 0 then return _falha('Informe um valor maior que zero.'); end if;
  if v_valor > 9999999 then return _falha('Valor alto demais.'); end if;
  v_sit := case when v_admin and p->>'situacao' = 'A pagar' then 'A pagar' else 'Paga' end;
  v_caixa := case when v_admin then coalesce(p->>'saiuDoCaixa', '') <> 'false' else true end;
  v_cat := _categoria_despesa(p->>'categoria');
  if v_sit = 'A pagar' and v_venc is null then return _falha('Informe um vencimento válido para a conta a pagar.'); end if;
  v_quando := case when v_sit = 'A pagar' then _meio_dia(v_venc) else now() end;
  insert into despesas (data_hora, descricao, valor, observacao, status, categoria, vencimento, situacao, competencia, saiu_do_caixa, requisicao_id)
  values (v_quando, v_desc, v_valor, coalesce(p->>'observacao', ''), v_sit::status_despesa, v_cat, v_venc, v_sit,
          case when v_venc is not null then to_char(v_venc, 'YYYY-MM') end,
          case when v_sit = 'Paga' then v_caixa else true end, v_req);
  perform _auditar(case when v_sit = 'A pagar' then 'Conta a pagar registrada' else 'Despesa registrada' end,
                   v_desc || ' [' || v_cat || '] = R$ ' || _dinheiro(v_valor) || case when v_venc is not null then ' | vence ' || v_venc else '' end);
  v_r := jsonb_build_object('ok', true, 'message', case when v_sit = 'A pagar' then 'Conta a pagar registrada: R$ ' || _dinheiro(v_valor) else 'Despesa registrada: R$ ' || _dinheiro(v_valor) end);
  if v_req is not null then perform _idem_gravar(v_req, 'addDespesa', v_r); end if;
  return v_r;
end $function$
;

CREATE OR REPLACE FUNCTION public.api_add_despesa_recorrente(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_desc text := btrim(coalesce(p->>'descricao', '')); v_valor numeric := round(_num(p->>'valor'), 2); v_dia numeric := _num(p->>'diaVencimento', 0);
        v_per text := coalesce(nullif(p->>'periodicidade', ''), 'Mensal'); v_ini text := coalesce(nullif(p->>'inicio', ''), _competencia_atual());
        v_ter text := coalesce(p->>'termino', ''); v_erro text; v_n int;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  v_erro := _erro_recorrente(v_desc, v_valor, v_dia, v_per, v_ini, v_ter);
  if v_erro <> '' then return _falha(v_erro); end if;
  if exists (select 1 from despesas_recorrentes where ativa and lower(btrim(descricao)) = lower(v_desc)) then
    return _falha('Já existe uma despesa mensal ativa com essa descrição.');
  end if;
  insert into despesas_recorrentes (descricao, categoria, valor, dia_vencimento, periodicidade, ativa, observacao, inicio, termino)
  values (v_desc, _categoria_despesa(p->>'categoria'), v_valor, v_dia::int, v_per, true, coalesce(p->>'observacao', ''),
          (v_ini || '-01')::date, case when v_ter <> '' then (v_ter || '-01')::date end);
  perform _auditar('Despesa mensal cadastrada', v_desc || ' = R$ ' || _dinheiro(v_valor) || ' (' || v_per || ', dia ' || v_dia::int || ')');
  v_n := _gerar_despesas_recorrentes(_competencia_atual());
  return jsonb_build_object('ok', true, 'message', 'Despesa mensal cadastrada.' || case when v_n > 0 then ' ' || v_n || ' conta(s) gerada(s) neste mês.' else '' end);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_add_feedback(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_nota numeric := _num(p->>'nota'); v_dig text := _so_digitos(p->>'telefone'); v_ip text := _ip_cliente(); v_chave text;
        v_venda uuid := _uuid(p->>'vendaId'); v_cli uuid;
begin
  if v_nota < 1 or v_nota > 5 or v_nota <> floor(v_nota) then return _falha('A nota deve ser de 1 a 5.'); end if;
  if v_dig <> '' and (length(v_dig) < 10 or length(v_dig) > 13) then return _falha('Telefone inválido.'); end if;
  v_chave := 'feedback_' || coalesce(nullif(v_dig, ''), 'anon');
  if _excedeu(v_chave, 5) or _excedeu('feedback_ip_' || v_ip, 10) or _excedeu('feedback_global', 120) then
    return _falha('Muitos feedbacks em sequência. Aguarde alguns minutos.');
  end if;
  if v_venda is not null and not exists (select 1 from vendas where id = v_venda) then v_venda := null; end if;
  if v_dig <> '' then select id into v_cli from clientes where _so_digitos(telefone) = v_dig limit 1; end if;
  insert into feedbacks (venda_id, cliente_id, telefone_cliente, nota, comentario, status)
  values (v_venda, v_cli, v_dig, v_nota::int, _texto_publico(p->>'comentario', 500), 'Novo');
  perform _registrar_falha(v_chave, 600); perform _registrar_falha('feedback_ip_' || v_ip, 600); perform _registrar_falha('feedback_global', 600);
  perform _auditar_publico('Feedback recebido', 'Nota ' || v_nota::int, v_dig);
  return jsonb_build_object('ok', true, 'message', 'Obrigado pelo feedback!');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_add_forma_pagamento(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_nome text := btrim(coalesce(p->>'nome', ''));
  v_pct numeric := _num(p->>'taxaPct'); v_fixa numeric := _num(p->>'taxaFixa'); v_prazo numeric := _num(p->>'prazoDias');
  v_troco boolean := coalesce((p->>'permiteTroco')::boolean, false);
  v_erro text; v_id uuid := gen_random_uuid(); v_ordem int; v_ref uuid;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_nome = '' then return _falha('Informe o nome da forma de pagamento.'); end if;
  if exists (select 1 from formas_pagamento where lower(nome) = lower(v_nome)) then return _falha('Já existe uma forma de pagamento com esse nome.'); end if;
  v_erro := _validar_forma(v_pct, v_fixa, v_prazo);
  if v_erro <> '' then return _falha(v_erro); end if;
  select coalesce(max(ordem), 0) + 1 into v_ordem from formas_pagamento;
  -- referência para o preço inicial: a primeira forma (pela ordem) que já existia
  select id into v_ref from formas_pagamento order by ordem, id limit 1;
  insert into formas_pagamento (id, nome, ativa, visivel_cardapio, taxa_percentual, taxa_fixa, prazo_dias, permite_troco, ordem)
  values (v_id, v_nome, true, true, v_pct, v_fixa, v_prazo::int, v_troco, v_ordem);
  -- a nova forma já nasce com o preço/custo da referência em todos os produtos e combos
  insert into produto_precos (produto_id, forma_pagamento_id, preco, custo)
    select pr.id, v_id, coalesce(pp.preco, 0), coalesce(pp.custo, 0)
    from produtos pr left join produto_precos pp on pp.produto_id = pr.id and pp.forma_pagamento_id = v_ref;
  insert into combo_precos (combo_id, forma_pagamento_id, preco, custo)
    select c.id, v_id, coalesce(cp.preco, 0), coalesce(cp.custo, 0)
    from combos c left join combo_precos cp on cp.combo_id = c.id and cp.forma_pagamento_id = v_ref;
  perform _auditar('Forma de pagamento cadastrada', v_nome || ' | taxa ' || v_pct || '% + R$ ' || to_char(v_fixa, 'FM999990.00') || ' | prazo ' || v_prazo::int || 'd | troco ' || case when v_troco then 'sim' else 'não' end);
  return jsonb_build_object('ok', true, 'message', 'Forma de pagamento cadastrada.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_add_ingrediente(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_nome text := btrim(coalesce(p->>'nome', '')); v_qtd numeric := _num(p->>'quantidade'); v_id uuid := gen_random_uuid();
        v_un text := coalesce(nullif(p->>'unidade', ''), 'un');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_nome = '' then return _falha('Informe o nome do ingrediente.'); end if;
  if exists (select 1 from estoque where lower(btrim(ingrediente)) = lower(v_nome)) then return _falha('Já existe um ingrediente com esse nome.'); end if;
  if v_un not in ('un','g','kg','ml','l') then v_un := 'un'; end if;
  insert into estoque (id, ingrediente, quantidade, quantidade_minima, unidade, custo_unitario, status)
  values (v_id, v_nome, v_qtd, _num(p->>'minimo'), v_un::unidade_estoque, _num(p->>'custo'), 'Ativo');
  if v_qtd > 0 then
    insert into movimentacoes_estoque (ingrediente_id, tipo, quantidade, qtd_antes, qtd_depois, motivo_referencia, usuario_id)
    values (v_id, 'Entrada', v_qtd, 0, v_qtd, 'Estoque inicial do cadastro', auth.uid());
  end if;
  perform _auditar('Ingrediente cadastrado', v_nome);
  return jsonb_build_object('ok', true, 'message', 'Ingrediente cadastrado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_add_mesa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_num text := btrim(coalesce(p->>'numero', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_num = '' then return _falha('Informe o número da mesa.'); end if;
  if exists (select 1 from mesas where numero = v_num) then return _falha('Já existe uma mesa com esse número.'); end if;
  insert into mesas (numero, status, capacidade) values (v_num, 'Livre', nullif(_num(p->>'capacidade'), 0)::int);
  perform _auditar('Mesa cadastrada', 'Mesa ' || v_num);
  return jsonb_build_object('ok', true, 'message', 'Mesa cadastrada.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_add_or_stamp_fidelidade(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_tel text := btrim(coalesce(p->>'telefone', '')); v_nome text := btrim(coalesce(p->>'nome', ''));
        v_obs text := left(btrim(coalesce(p->>'observacao', '')), 300); v_cli uuid; f fidelidade%rowtype;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if _so_digitos(v_tel) = '' then return _falha('Informe o telefone do cliente.'); end if;
  select id into v_cli from clientes where _so_digitos(telefone) = _so_digitos(v_tel) limit 1;
  if v_cli is not null then select * into f from fidelidade where cliente_id = v_cli for update; end if;
  if f.id is not null then
    if v_obs <> '' then update fidelidade set observacoes = v_obs where id = f.id; end if;
    if f.carimbos >= 10 then
      return jsonb_build_object('ok', true, 'novo', false, 'message', 'Cartão já está completo (10/10). Resgate o prêmio antes de somar nova marca.');
    end if;
    update fidelidade set carimbos = f.carimbos + 1, atualizada_em = now() where id = f.id;
    perform _auditar('Marca adicionada (fidelidade)', (f.carimbos + 1) || '/10', v_tel);
    return jsonb_build_object('ok', true, 'novo', false, 'message', 'Marca adicionada (' || (f.carimbos + 1) || '/10).');
  end if;
  if v_nome = '' then return _falha('Cliente não encontrado no fidelidade e nome não informado.'); end if;
  v_cli := _upsert_cliente(v_tel, v_nome);
  insert into fidelidade (cliente_id, carimbos, atualizada_em, observacoes) values (v_cli, 1, now(), nullif(v_obs, ''))
  on conflict (cliente_id) do update set carimbos = least(10, fidelidade.carimbos + 1), atualizada_em = now();
  perform _auditar('Cliente novo no fidelidade', v_nome, v_tel);
  return jsonb_build_object('ok', true, 'novo', true, 'message', '1ª marca registrada.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_add_produto(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_nome text := btrim(coalesce(p->>'nome', '')); v_id uuid := gen_random_uuid(); v_cat uuid := _uuid(p->>'categoria');
        v_ordem int; v_proprio uuid;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_nome = '' then return _falha('Informe o nome do produto.'); end if;
  if exists (select 1 from produtos where lower(btrim(nome)) = lower(v_nome)) then return _falha('Já existe um produto com esse nome.'); end if;
  v_proprio := _estoque_proprio(null, v_nome, p->'estoqueProprio');
  select coalesce(max(ordem_cardapio), 0) + 1 into v_ordem from produtos where categoria_id is not distinct from v_cat;
  insert into produtos (id, nome, descricao, categoria_id, ativo, destaque, estoque_proprio_ingrediente_id, ordem_cardapio)
  values (v_id, v_nome, coalesce(p->>'descricao', ''), v_cat, true, coalesce((p->>'destaque')::boolean, false), v_proprio, v_ordem);
  perform _produto_gravar_precos(v_id, _precos_ou_base(p));
  perform _produto_gravar_receita(v_id, p->'ingredientes', v_proprio);
  perform _produto_gravar_adicionais(v_id, p->'adicionaisIds');
  perform _auditar('Produto cadastrado', v_nome);
  return jsonb_build_object('ok', true, 'message', 'Produto cadastrado.', 'id', v_id);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_add_sangria(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_valor numeric := _num(p->>'valor'); v_motivo text := btrim(coalesce(p->>'motivo', '')); v_req text := nullif(p->>'requisicaoId', ''); v_r jsonb; v_saldo numeric;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if v_req is not null then perform pg_advisory_xact_lock(hashtext(v_req)); v_r := _idem_ler(v_req); if v_r is not null then return v_r; end if; end if;
  if v_valor <= 0 then return _falha('Informe um valor de sangria maior que zero.'); end if;
  if v_motivo = '' then return _falha('Informe o motivo da sangria.'); end if;
  v_saldo := _saldo_gaveta_aberta();
  if v_saldo is null then return _falha('Abra o caixa antes de registrar uma sangria.'); end if;
  if round(v_valor, 2) > v_saldo then return _falha('A sangria (R$ ' || to_char(v_valor, 'FM999990.00') || ') é maior que o dinheiro na gaveta (R$ ' || to_char(v_saldo, 'FM999990.00') || '). Nada foi registrado.'); end if;
  insert into sangrias (valor, motivo, usuario_id, caixa_id)
  values (round(v_valor, 2), v_motivo, auth.uid(), (select id from caixa_sessoes where status = 'Aberto' limit 1));
  perform _auditar('Sangria registrada', v_motivo || ' = R$ ' || to_char(v_valor, 'FM999990.00'));
  v_r := jsonb_build_object('ok', true, 'message', 'Sangria registrada: R$ ' || to_char(v_valor, 'FM999990.00'));
  if v_req is not null then perform _idem_gravar(v_req, 'addSangria', v_r); end if;
  return v_r;
end $function$
;

CREATE OR REPLACE FUNCTION public.api_adicionar_custo_evento(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_ev uuid := _uuid(p->>'eventoId'); v_val numeric := round(_num(p->>'valor'), 2); v_req text := nullif(btrim(coalesce(p->>'requisicaoId', '')), '');
        v_desc text := left(btrim(coalesce(p->>'descricao', '')), 160);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_ev is null or not exists (select 1 from eventos where id = v_ev) then return _falha('Evento não encontrado.'); end if;
  if not (v_val > 0) then return _falha('Valor inválido.'); end if;
  if v_req is not null then
    perform pg_advisory_xact_lock(hashtext('evc' || v_req));
    if exists (select 1 from eventos_custos where requisicao_id = v_req) then
      return jsonb_build_object('ok', true, 'message', 'Lançamento já registrado.', 'evento', _evento_json(v_ev));
    end if;
  end if;
  insert into eventos_custos (evento_id, descricao, categoria, valor, data, observacao, criado_por, requisicao_id)
  values (v_ev, v_desc, left(coalesce(nullif(btrim(p->>'categoria'), ''), 'Outros'), 60), v_val,
          coalesce(_data_iso(btrim(coalesce(p->>'data', ''))), (now() at time zone 'America/Sao_Paulo')::date), left(coalesce(p->>'observacao', ''), 300), auth.uid(), v_req);
  perform _recalcular_evento(v_ev);
  perform _auditar('Custo de evento lançado', v_desc || ' R$ ' || _dinheiro(v_val), v_ev::text);
  return jsonb_build_object('ok', true, 'message', 'Custo lançado.', 'evento', _evento_json(v_ev));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_adicionar_recebimento_evento(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_ev uuid := _uuid(p->>'eventoId'); v_val numeric := round(_num(p->>'valor'), 2); v_req text := nullif(btrim(coalesce(p->>'requisicaoId', '')), '');
        v_forma text := btrim(coalesce(p->>'forma', '')); e eventos%rowtype;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into e from eventos where id = v_ev for update;
  if e.id is null then return _falha('Evento não encontrado.'); end if;
  if not (v_val > 0) then return _falha('Valor inválido.'); end if;
  if v_forma <> '' and not exists (select 1 from formas_pagamento where ativa and nome = v_forma) then return _falha('Forma de pagamento inválida.'); end if;
  if v_val > greatest(0, e.valor_a_receber) + 0.01 then return _falha('O recebimento não pode ultrapassar o valor a receber do evento.'); end if;
  if v_req is not null then
    perform pg_advisory_xact_lock(hashtext('evr' || v_req));
    if exists (select 1 from eventos_recebimentos where requisicao_id = v_req) then
      return jsonb_build_object('ok', true, 'message', 'Recebimento já registrado.', 'evento', _evento_json(v_ev));
    end if;
  end if;
  insert into eventos_recebimentos (evento_id, valor, forma_pagamento, data, observacao, criado_por, requisicao_id)
  values (v_ev, v_val, nullif(v_forma, ''), coalesce(_data_iso(btrim(coalesce(p->>'data', ''))), (now() at time zone 'America/Sao_Paulo')::date),
          left(coalesce(p->>'observacao', ''), 300), auth.uid(), v_req);
  perform _recalcular_evento(v_ev);
  perform _auditar('Recebimento de evento lançado', 'R$ ' || _dinheiro(v_val) || ' ' || v_forma, v_ev::text);
  return jsonb_build_object('ok', true, 'message', 'Recebimento registrado.', 'evento', _evento_json(v_ev));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_alternar_cupom(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_on boolean := coalesce(p->>'ativo', '') in ('true', 't', 'Sim'); v_cod text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  update cupons set ativa = v_on where id = _uuid(p->>'id') returning codigo into v_cod;
  if not found then return _falha('Cupom não encontrado.'); end if;
  perform _auditar(case when v_on then 'Cupom ativado' else 'Cupom desativado' end, v_cod);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_aplicar_preco_calculadora(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_novo numeric := round(_num(p->>'novoPreco'), 2); v_antigo numeric; v_prod uuid := _uuid(p->>'produtoId'); v_forma uuid := _uuid(p->>'formaPagamentoId');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not (v_novo > 0) then return _falha('Preço inválido.'); end if;
  select preco into v_antigo from produto_precos where produto_id = v_prod and forma_pagamento_id = v_forma for update;
  if not found then return _falha('Preço do produto para esta forma de pagamento não encontrado.'); end if;
  update produto_precos set preco = v_novo where produto_id = v_prod and forma_pagamento_id = v_forma;
  perform _auditar('Preço aplicado pela calculadora', 'Produto ' || v_prod || ' | forma ' || v_forma || ' | R$ ' || _dinheiro(v_antigo) || ' → R$ ' || _dinheiro(v_novo));
  return jsonb_build_object('ok', true, 'message', 'Preço aplicado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_arquivar_confirmar_caixa(p_ids uuid[])
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_n int;
BEGIN
  PERFORM set_config('txb.sem_fila','on',true);
  INSERT INTO arquivo_historico (tabela, registro_id, data_referencia)
    SELECT 'caixa_sessoes', unnest(p_ids), CURRENT_DATE ON CONFLICT DO NOTHING;
  DELETE FROM sangrias WHERE caixa_id = ANY(p_ids);
  WITH d AS (DELETE FROM caixa_sessoes WHERE id = ANY(p_ids) RETURNING id) SELECT count(*) INTO v_n FROM d;
  RETURN jsonb_build_object('ok',true,'removidos',v_n);
EXCEPTION WHEN foreign_key_violation THEN
  RETURN _falha('Caixa ainda referenciado por outra tabela: '||SQLERRM);
END $function$
;

CREATE OR REPLACE FUNCTION public.api_arquivar_confirmar_vendas(p_ids uuid[])
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_n int;
BEGIN
  PERFORM set_config('txb.sem_fila','on',true);
  INSERT INTO arquivo_historico (tabela, registro_id, data_referencia)
    SELECT 'vendas', unnest(p_ids), CURRENT_DATE ON CONFLICT DO NOTHING;
  DELETE FROM itens_venda WHERE venda_id = ANY(p_ids);
  DELETE FROM pagamentos_venda WHERE venda_id = ANY(p_ids);
  WITH d AS (DELETE FROM vendas WHERE id = ANY(p_ids) RETURNING id) SELECT count(*) INTO v_n FROM d;
  RETURN jsonb_build_object('ok',true,'removidos',v_n);
EXCEPTION WHEN foreign_key_violation THEN
  RETURN _falha('Venda ainda referenciada por outra tabela: '||SQLERRM);
END $function$
;

CREATE OR REPLACE FUNCTION public.api_arquivar_lote_caixa(p_dias integer, p_limite integer DEFAULT 100, p_min_dias integer DEFAULT 30)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_corte timestamptz := now() - (greatest(p_dias, greatest(p_min_dias,1))||' days')::interval; v_ids uuid[];
begin
  select array_agg(id) into v_ids from (
    select c.id from caixa_sessoes c
    where c.status = 'Fechado' and c.fechamento < v_corte
      and not exists (select 1 from vendas v where v.caixa_id = c.id)
    order by c.fechamento limit p_limite) x;
  return jsonb_build_object('ok',true,
    'ids', coalesce(to_jsonb(v_ids),'[]'::jsonb),
    'caixas', (select coalesce(jsonb_agg(to_jsonb(c)),'[]'::jsonb) from caixa_sessoes c where c.id = any(coalesce(v_ids,'{}'))),
    'sangrias', (select coalesce(jsonb_agg(to_jsonb(s)),'[]'::jsonb) from sangrias s where s.caixa_id = any(coalesce(v_ids,'{}'))));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_arquivar_lote_vendas(p_dias integer, p_limite integer DEFAULT 200, p_min_dias integer DEFAULT 30)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_corte timestamptz := now() - (greatest(p_dias, greatest(p_min_dias,1))||' days')::interval; v_ids uuid[];
begin
  select array_agg(id) into v_ids from (
    select v.id from vendas v
    where v.data_hora < v_corte
      and (v.status = 'Cancelada' or (v.status_pagamento = 'Pago' and coalesce(v.status_pedido::text,'Entregue') in ('Entregue','Retirada','Servida')))
      and not exists (select 1 from ajustes_pos_venda a where a.venda_id = v.id)
      and not exists (select 1 from entregas_fechadas e where e.venda_id = v.id)
      and not (v.status <> 'Cancelada' and v.tipo::text = 'Entrega' and v.entregador_id is not null and v.fechamento_entrega_id is null)
      and not exists (select 1 from ocorrencias o where o.venda_id = v.id and o.status::text <> 'Resolvida')
      and not exists (select 1 from chat_conversas c where c.venda_id = v.id and c.estado <> 'encerrada')
    order by v.data_hora limit p_limite) x;
  return jsonb_build_object('ok',true,
    'ids', coalesce(to_jsonb(v_ids),'[]'::jsonb),
    'vendas', (select coalesce(jsonb_agg(to_jsonb(v)),'[]'::jsonb) from vendas v where v.id = any(coalesce(v_ids,'{}'))),
    'itens', (select coalesce(jsonb_agg(to_jsonb(i)),'[]'::jsonb) from itens_venda i where i.venda_id = any(coalesce(v_ids,'{}'))),
    'pagamentos', (select coalesce(jsonb_agg(to_jsonb(p)),'[]'::jsonb) from pagamentos_venda p where p.venda_id = any(coalesce(v_ids,'{}'))));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_atender_chamado_mesa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare m mesas; v_nivel nivel_acesso := auth_nivel();
begin
  if v_nivel is null or v_nivel not in ('Admin', 'Operador', 'Garçom') then return _negado(); end if;
  select * into m from mesas where id = _uuid(p->>'mesaId') for update;
  if not found then return _falha('Mesa não encontrada.'); end if;
  if v_nivel = 'Garçom' and m.garcom_responsavel_id is not null and m.garcom_responsavel_id <> auth.uid() then return _falha('Esta mesa está sob responsabilidade de outro garçom.'); end if;
  update mesas set chamado_tipo = null, chamado_em = null,
    garcom_responsavel_id = case when v_nivel = 'Garçom' and garcom_responsavel_id is null then auth.uid() else garcom_responsavel_id end
    where id = m.id;
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_atribuir_entregador(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare t record; v vendas; u usuarios; lg text := btrim(coalesce(p->>'entregador','')); ant text;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if lg <> '' then
    select * into u from usuarios where lower(login) = lower(lg);
    if not found or u.nivel::text <> 'Entregador' then return _falha('Esse usuário não é um entregador cadastrado.'); end if;
    if not u.ativo then return _falha('Esse entregador está inativo.'); end if;
  end if;
  select * into t from _pedido_trava(p); v := t.v; if t.erro is not null then return t.erro; end if;
  if v.tipo <> 'Entrega' then return _falha('Só pedidos de entrega têm entregador.'); end if;
  if v.status_pedido::text = 'Entregue' then return _falha('Esta entrega já foi concluída.'); end if;
  if v.status_pedido::text = 'Saiu para entrega' and lg = '' then return _falha('O pedido já saiu para entrega — troque o entregador, não remova.'); end if;
  ant := coalesce(_login_de(v.entregador_id), '(nenhum)');
  update vendas set entregador_id = case when lg = '' then null else u.id end where id = v.id;
  perform _auditar('Entregador atribuído', '#' || v.numero_pedido || ': ' || ant || ' → ' || coalesce(nullif(lg,''), '(nenhum)'));
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_atualizar_ocorrencia(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_st text := btrim(coalesce(p->>'status', '')); v_sol text := left(btrim(coalesce(p->>'solucao', '')), 600);
        v_resp text := left(btrim(coalesce(p->>'responsavel', '')), 60); v_esp text := nullif(btrim(coalesce(p->>'statusEsperado', '')), '');
        o ocorrencias%rowtype; v_login text := _login_de(auth.uid()); v_nivel_real text; v_linha text;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if v_st <> all (array['Aberta','Em andamento','Resolvida']) then return _falha('Status inválido.'); end if;
  if v_st = 'Resolvida' and char_length(v_sol) < 3 then return _falha('Descreva a solução para resolver a ocorrência.'); end if;
  select * into o from ocorrencias where id = _uuid(p->>'id') for update;
  if o.id is null then return _falha('Ocorrência não encontrada.'); end if;
  if v_esp is not null and v_esp <> o.status::text then
    return jsonb_build_object('ok', false, 'conflito', true,
      'message', 'Essa ocorrência já foi atualizada por outra pessoa (agora está "' || o.status || '"). Confira a lista.');
  end if;
  select nivel::text into v_nivel_real from usuarios where id = auth.uid();
  v_linha := _agora_br() || ' — ' || coalesce(v_login, '') || ' (' || coalesce(v_nivel_real, '') || '): ' || o.status || ' → ' || v_st
             || case when v_resp <> '' then ' · resp.: ' || v_resp else '' end
             || case when v_sol <> '' then ' · solução: ' || left(v_sol, 80) else '' end;
  update ocorrencias set status = v_st::status_ocorrencia, atualizada_em = now(),
         responsavel = case when v_resp <> '' then v_resp else responsavel end,
         solucao = case when v_sol <> '' then v_sol else solucao end,
         historico = historico || to_jsonb(v_linha)
   where id = o.id;
  perform _auditar('Ocorrência atualizada', '#' || o.numero || ': ' || o.status || ' → ' || v_st || case when v_sol <> '' then ' — ' || left(v_sol, 120) else '' end);
  return jsonb_build_object('ok', true, 'message', 'Ocorrência #' || o.numero || ' atualizada.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_avancar_status_pedido(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare t record; v vendas; novo text := p->>'novoStatus'; atual text; eu uuid := auth.uid(); lg text; nv text;
begin
  if not tem_nivel('Admin','Operador','Cozinha','Garçom','Entregador') then return _negado(); end if;
  if novo not in ('Em preparo','Pronta','Saiu para entrega','Entregue','Retirada','Servida') then return _falha('Status inválido.'); end if;
  select * into t from _pedido_trava(p); if t.erro is not null then return t.erro; end if;
  v := t.v; atual := coalesce(v.status_pedido::text, ''); lg := _login_de(eu);
  select nivel::text into nv from usuarios where id = eu;
  if nullif(p->>'statusEsperado','') is not null and p->>'statusEsperado' <> atual then return _conflito('Este pedido já foi atualizado por outra pessoa (agora está "' || atual || '"). A tela foi atualizada.'); end if;
  if atual = 'Suspenso' then return _falha('Este pedido está suspenso — retome antes de avançar.'); end if;
  if v.tipo = 'Retirada' and novo in ('Saiu para entrega','Entregue','Servida') then return _falha('Pedido de retirada não tem esse status.'); end if;
  if v.tipo = 'Entrega' and novo in ('Retirada','Servida') then return _falha('Pedido de entrega não tem esse status.'); end if;
  if v.tipo = 'Mesa' and novo in ('Saiu para entrega','Entregue','Retirada') then return _falha('Pedido de mesa não tem esse status — use "Servida".'); end if;
  if not ((novo='Em preparo' and atual='Recebido') or (novo='Pronta' and atual='Em preparo') or (novo='Saiu para entrega' and atual='Pronta') or (novo='Entregue' and atual='Saiu para entrega') or (novo in ('Retirada','Servida') and atual='Pronta')) then
    if novo = 'Pronta' and atual = 'Recebido' then return _falha('Aceite o pedido e inicie o preparo antes de marcá-lo como pronto.'); end if;
    return _falha('Transição inválida: o pedido está "' || atual || '" e não pode avançar diretamente para "' || novo || '".'); end if;
  if nv = 'Cozinha' and novo not in ('Em preparo','Pronta') then return _falha('A cozinha só pode marcar "Em preparo" e "Pronta".'); end if;
  if nv = 'Garçom' then
    if not (v.registrado_por = eu or exists (select 1 from mesas m where m.id = v.mesa_id and m.garcom_responsavel_id = eu)) then return _falha('Este pedido não está no seu escopo operacional.'); end if;
    if novo <> 'Servida' then return _falha('O garçom apenas pode marcar como "Servida" um pedido de sua mesa.'); end if;
  end if;
  if nv = 'Entregador' then
    if v.tipo <> 'Entrega' or v.entregador_id is distinct from eu then return _falha('Esta entrega não está atribuída a você.'); end if;
    if novo not in ('Saiu para entrega','Entregue') then return _falha('O entregador só pode marcar "Saiu para entrega" e "Entregue".'); end if;
  end if;
  if novo = 'Saiu para entrega' and v.entregador_id is null then return _falha('Atribua um entregador antes de o pedido sair para entrega.'); end if;
  update vendas set status_pedido = novo::status_pedido,
    inicio_preparo_em = case when novo = 'Em preparo' then coalesce(inicio_preparo_em, now()) else inicio_preparo_em end,
    pronta_em = case when novo = 'Pronta' then now() else pronta_em end,
    saiu_em = case when novo = 'Saiu para entrega' then now() else saiu_em end,
    concluida_em = case when novo in ('Entregue','Retirada','Servida') then now() else concluida_em end
  where id = v.id;
  perform _auditar('Status do pedido atualizado', '#' || v.numero_pedido || ' → ' || novo);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_cancelar_ajuste_pos_venda(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_aut text; v_req text := nullif(p->>'requisicaoId', ''); v_r jsonb; v_motivo text := left(btrim(coalesce(p->>'motivo', '')), 200);
        a ajustes_pos_venda%rowtype; d despesas%rowtype; s caixa_sessoes%rowtype; v_ref text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_req is not null then perform pg_advisory_xact_lock(hashtext(v_req)); v_r := _idem_ler(v_req); if v_r is not null then return v_r; end if; end if;
  v_aut := _exige_admin(p->>'senhaAdminConfirmacao');
  if v_aut is null then return _falha('Senha de administrador incorreta.'); end if;
  if v_motivo = '' then return _falha('Informe o motivo do cancelamento do ajuste.'); end if;
  select * into a from ajustes_pos_venda where id = _uuid(p->>'id') for update;
  if not found then return _falha('Ajuste não encontrado.'); end if;
  if a.status = 'Cancelado' then return _falha('Este ajuste já está cancelado.'); end if;
  if a.despesa_id is not null then
    select * into d from despesas where id = a.despesa_id for update;
    if found and d.saiu_do_caixa then
      select * into s from caixa_sessoes where status = 'Aberto' limit 1;
      if not found or a.data_hora < s.abertura then
        return _falha('Esta devolução saiu do caixa de um turno que já foi fechado. Não dá para desfazer sem mexer na conferência daquele dia — registre a diferença como ajuste/despesa nova e fale com o contador.');
      end if;
    end if;
  end if;
  update ajustes_pos_venda set status = 'Cancelado', cancelado_em = now(), motivo_cancelamento = v_motivo where id = a.id;
  if a.despesa_id is not null then
    update despesas set status = 'Cancelada', motivo_cancelamento = 'Ajuste pós-venda cancelado: ' || v_motivo where id = a.despesa_id;
  end if;
  v_ref := coalesce('nº ' || a.pedido_numero, right(a.venda_id::text, 8));
  perform _auditar('Ajuste pós-venda cancelado', a.tipo || ' R$ ' || _dinheiro(a.valor) || ' | pedido ' || v_ref || ' | ' || v_motivo, a.telefone);
  v_r := jsonb_build_object('ok', true, 'message', 'Ajuste cancelado.');
  if v_req is not null then perform _idem_gravar(v_req, 'cancelarAjustePosVenda', v_r); end if;
  return v_r;
end $function$
;

CREATE OR REPLACE FUNCTION public.api_cancelar_brinde(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare b brindes%rowtype; f fidelidade%rowtype; e estoque%rowtype; x jsonb; v_novo numeric; v_motivo text := btrim(coalesce(p->>'motivo', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_motivo = '' then return _falha('Informe o motivo do cancelamento.'); end if;
  select * into b from brindes where id = _uuid(p->>'id') for update;
  if b.id is null then return _falha('Lançamento não encontrado.'); end if;
  if b.cancelado_em is not null then return _falha('Este prêmio já foi cancelado.'); end if;
  if b.tipo = 'Fidelidade' then
    select * into f from fidelidade where cliente_id = b.cliente_id for update;
    if f.id is null or f.carimbos > 0 then return _falha('O cartão do cliente já recomeçou, então não dá para devolver o prêmio. Para acertar o estoque, use uma entrada em Movimentações.'); end if;
    update fidelidade set carimbos = 10, premios_resgatados = greatest(0, f.premios_resgatados - 1), atualizada_em = now() where id = f.id;
  else
    update indicacoes set status = 'Pendente' where id = b.indicacao_id;
  end if;
  for x in select * from jsonb_array_elements(coalesce(b.consumo, '[]'::jsonb)) loop
    select * into e from estoque where id = _uuid(x->>'ingredienteId') for update;
    if e.id is null then continue; end if;
    v_novo := round(e.quantidade + _num(x->>'qtd'), 3);
    update estoque set quantidade = v_novo where id = e.id;
    insert into movimentacoes_estoque (ingrediente_id, tipo, quantidade, qtd_antes, qtd_depois, motivo_referencia, usuario_id)
    values (e.id, 'Entrada'::tipo_mov_estoque, _num(x->>'qtd'), e.quantidade, v_novo, 'Cancelamento de prêmio — ' || v_motivo, auth.uid());
  end loop;
  if b.despesa_id is not null then
    update despesas set status = 'Cancelada'::status_despesa, motivo_cancelamento = 'Prêmio cancelado — ' || v_motivo where id = b.despesa_id;
  end if;
  update brindes set cancelado_em = now(), motivo_cancelamento = v_motivo where id = b.id;
  perform _auditar('Prêmio cancelado (' || b.tipo || ')', b.produto_nome || ' de ' || b.cliente_nome || ' — ' || v_motivo, b.telefone);
  return jsonb_build_object('ok', true, 'message', 'Prêmio cancelado: estoque devolvido e ' || case when b.tipo = 'Fidelidade' then 'cartão reaberto.' else 'indicação voltou a pendente.' end);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_cancelar_despesa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare d despesas%rowtype; v_aut text; v_motivo text := btrim(coalesce(p->>'motivo', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  v_aut := _exige_admin(p->>'senhaAdminConfirmacao');
  if v_aut is null then return _falha('Senha de administrador incorreta.'); end if;
  if v_motivo = '' then return _falha('Informe o motivo do cancelamento.'); end if;
  select * into d from despesas where id = _uuid(p->>'id') for update;
  if not found then return _falha('Despesa não encontrada.'); end if;
  if d.categoria = 'Ajuste pós-venda' then return _falha('Esta despesa nasceu de um Ajuste pós-venda. Para desfazer, cancele o ajuste em Financeiro → Ajustes pós-venda.'); end if;
  if d.status = 'Cancelada' then return _falha('Esta despesa já está cancelada.'); end if;
  update despesas set status = 'Cancelada', motivo_cancelamento = v_motivo where id = d.id;
  perform _auditar('Despesa cancelada', d.descricao || ' = R$ ' || _dinheiro(d.valor) || ' | ' || v_motivo);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_cancelar_evento(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_motivo text := left(btrim(coalesce(p->>'motivo', '')), 300);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  update eventos set status = 'Cancelado', observacoes = coalesce(observacoes, '') || case when v_motivo <> '' then ' | Cancelamento: ' || v_motivo else '' end
   where id = _uuid(p->>'id');
  if not found then return _falha('Evento não encontrado.'); end if;
  perform _auditar('Evento cancelado', p->>'id', v_motivo);
  return jsonb_build_object('ok', true, 'message', 'Evento cancelado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_cancelar_pedido_cardapio_publico(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_alvo text := lower(btrim(coalesce(p->>'codigo', ''))); v vendas%rowtype; v_ip text := _ip_cliente(); v_chave_tel text; v_id uuid;
begin
  if v_alvo !~ '^[0-9a-f-]{8,36}$' then return _falha('Código do pedido inválido.'); end if;
  if _excedeu('cancpub_ip_' || v_ip, 10) or _excedeu('cancpub_falhas', 60) then
    return jsonb_build_object('ok', false, 'message', 'Muitas tentativas seguidas. Ligue para o restaurante.', 'limite', true);
  end if;
  select id into v_id from vendas where right(id::text, 8) = right(v_alvo, 8) and right(id::text, length(v_alvo)) = v_alvo order by data_hora desc limit 1;
  if v_id is not null then select * into v from vendas where id = v_id for update; end if;
  if v_id is null or v.origem <> 'Cardápio' or v.mesa_id is not null then
    perform _registrar_falha('cancpub_ip_' || v_ip, 600); perform _registrar_falha('cancpub_falhas', 600);
    return _falha('Pedido não encontrado ou não pode ser cancelado por aqui.');
  end if;
  v_chave_tel := 'cancpub_' || right(_so_digitos(v.telefone_cliente), 11);
  if _excedeu(v_chave_tel, 3) then
    return jsonb_build_object('ok', false, 'message', 'Você já cancelou vários pedidos em pouco tempo. Ligue para o restaurante.', 'limite', true);
  end if;
  if v.status <> 'Confirmada' then return _falha('Esse pedido já está cancelado.'); end if;
  if v.status_pedido is distinct from 'Recebido' then return _falha('O restaurante já aceitou o pedido. Ligue para o restaurante para alterar.'); end if;
  if v.status_pagamento <> 'A Receber' then return _falha('Este pedido já tem pagamento registrado. Ligue para o restaurante.'); end if;
  if now() - v.data_hora > interval '3 minutes' then return _falha('O prazo de 3 minutos para cancelar já passou. Ligue para o restaurante.'); end if;
  update vendas set status = 'Cancelada', motivo_cancelamento = 'Cancelado pelo cliente (cardápio, até 3 min)' where id = v.id;
  perform _ajustar_estoque(_itens_da_venda(v.id), -1, v.id);
  perform _registrar_falha(v_chave_tel, 600);
  perform _auditar_publico('Pedido cancelado pelo cliente (cardápio)', 'Pedido ' || v.numero_pedido || ' | R$ ' || _dinheiro(v.valor_total), v.telefone_cliente);
  return jsonb_build_object('ok', true, 'message', 'Pedido cancelado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_cancelar_pedido_mesa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_q jsonb := _mesa_qr(p->>'mesa', p->>'codigo'); m mesas; v vendas%rowtype; v_restantes int;
begin
  if v_q->>'ok' <> 'true' then return v_q; end if;
  select * into m from mesas where id = (v_q->>'mesaId')::uuid for update;
  select * into v from vendas where id = _uuid(p->>'vendaId') for update;
  if not found then return _falha('Pedido não encontrado.'); end if;
  if v.mesa_id is distinct from m.id or v.origem <> 'Cardápio' then return _falha('Pedido não encontrado nesta mesa.'); end if;
  if v.status <> 'Confirmada' then return _falha('Esse pedido já foi cancelado.'); end if;
  if v.status_pedido is distinct from 'Recebido' then return _falha('O restaurante já aceitou este pedido. Chame o garçom para alterar.'); end if;
  update vendas set status = 'Cancelada', motivo_cancelamento = 'Cancelado pelo cliente (mesa ' || m.numero || ')' where id = v.id;
  perform _ajustar_estoque(_itens_da_venda(v.id), -1, v.id);
  perform _auditar_publico('Pedido de mesa cancelado pelo cliente', 'Mesa ' || m.numero || ' | R$ ' || _dinheiro(v.valor_total), v.cliente_nome);
  -- mesa aberta só por esse pedido (sem garçom e sem outro pedido pendente): volta a Livre
  select count(*) into v_restantes from vendas where mesa_id = m.id and status = 'Confirmada' and status_pagamento = 'A Receber';
  if m.status::text = 'Ocupada' and m.garcom_responsavel_id is null and v_restantes = 0 then update mesas set status = 'Livre' where id = m.id; end if;
  return jsonb_build_object('ok', true, 'message', 'Pedido cancelado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_cancelar_venda(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v vendas%rowtype; v_aut text; v_motivo text := btrim(coalesce(p->>'motivo', '')); v_st text; v_pronta boolean; v_login text;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  v_aut := _exige_admin(p->>'senhaAdminConfirmacao');
  if v_aut is null then return _falha('Senha de administrador incorreta.'); end if;
  if v_motivo = '' then return _falha('Informe o motivo do cancelamento.'); end if;
  select * into v from vendas where id = _uuid(p->>'id') for update;
  if not found then return _falha('Venda não encontrada.'); end if;
  if v.status = 'Cancelada' then return _falha('Esta venda já está cancelada.'); end if;
  if v.fechamento_entrega_id is not null then return _falha('Esta entrega já está em um fechamento — não pode ser cancelada. Faça o ajuste pelo Financeiro.'); end if;
  v_st := v.status_pedido::text;
  if v_st = 'Suspenso' then v_st := coalesce(nullif(v.status_antes_suspensao, ''), 'Em preparo'); end if;
  v_pronta := v_st is not null and v_st <> '' and v_st not in ('Em preparo', 'Recebido');
  update vendas set status = 'Cancelada', motivo_cancelamento = v_motivo where id = v.id;
  -- antes de "Pronta" o estoque sempre volta; depois, só se a mercadoria não foi perdida
  if not v_pronta or coalesce(p->>'mercadoriaPerdida', '') = 'false' then
    perform _ajustar_estoque(_itens_da_venda(v.id), -1, v.id);
  end if;
  select login into v_login from usuarios where id = auth.uid();
  perform _auditar('Venda cancelada', 'Autorizado por ' || coalesce(nullif(current_setting('app.autorizador', true), ''), v_login) || ' | R$ ' || _dinheiro(v.valor_total) || ' | ' || v_motivo
    || case when v.status_pagamento = 'Pago' then ' | ESTORNO ao cliente pendente (venda estava paga)' else '' end
    || case when v_pronta then case when coalesce(p->>'mercadoriaPerdida', '') = 'false' then ' — mercadoria devolvida ao estoque' else ' — mercadoria perdida' end else '' end, v.telefone_cliente);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_chamar_garcom_mesa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_q jsonb := _mesa_qr(p->>'mesa', p->>'codigo'); m mesas;
begin
  if v_q->>'ok' <> 'true' then return v_q; end if;
  select * into m from mesas where id = (v_q->>'mesaId')::uuid for update;
  if _excedeu('chamargarcom_' || m.id::text, 3) then return jsonb_build_object('ok', true, 'message', 'Já avisamos o garçom. Já estamos a caminho!'); end if;
  update mesas set chamado_tipo = 'garcom', chamado_em = now() where id = m.id;
  perform _registrar_falha('chamargarcom_' || m.id::text, 600);
  perform _auditar_publico('Garçom chamado pelo cliente na mesa', 'Mesa ' || m.numero, null);
  return jsonb_build_object('ok', true, 'message', 'Garçom chamado! Já estamos a caminho.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_compartilhar_destino_pedido(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_alvo text := lower(btrim(coalesce(p->>'codigo', ''))); v_ip text := _ip_cliente(); v vendas%rowtype;
  v_lat double precision; v_lng double precision;
begin
  if v_alvo !~ '^[0-9a-f-]{8,36}$' then return jsonb_build_object('ok', false, 'message', 'Código do pedido inválido.'); end if;
  if _excedeu('destino_ip_' || v_ip, 10) then return jsonb_build_object('ok', false, 'limite', true, 'message', 'Muitas tentativas. Aguarde alguns minutos.'); end if;
  perform _registrar_falha('destino_ip_' || v_ip, 600);
  begin v_lat := (p->>'lat')::double precision; v_lng := (p->>'lng')::double precision;
  exception when others then return jsonb_build_object('ok', false, 'message', 'Localização inválida.'); end;
  if v_lat is null or v_lng is null or v_lat not between -90 and 90 or v_lng not between -180 and 180 then
    return jsonb_build_object('ok', false, 'message', 'Localização inválida.'); end if;
  select * into v from vendas where right(id::text, 8) = right(v_alvo, 8) and right(id::text, length(v_alvo)) = v_alvo order by data_hora desc limit 1;
  if not found or v.tipo::text <> 'Entrega' or v.status::text <> 'Confirmada'
     or v.status_pedido::text not in ('Recebido', 'Em preparo', 'Pronta', 'Saiu para entrega') then
    return jsonb_build_object('ok', false, 'message', 'Não foi possível registrar a localização para este pedido.'); end if;
  insert into entrega_destinos (venda_id, lat, lng, compartilhado_em) values (v.id, v_lat, v_lng, now())
  on conflict (venda_id) do update set lat = excluded.lat, lng = excluded.lng, compartilhado_em = now();
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_confirmar_recebimento_pedido(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare t record; v vendas;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  select * into t from _pedido_trava(p); v := t.v;
  if t.erro is not null then return case when v.status = 'Cancelada' then _falha('Este pedido foi cancelado — não dá para receber o pagamento.') else t.erro end; end if;
  if v.status_pagamento = 'Pago' then return jsonb_build_object('ok', true, 'duplicado', true, 'message', 'Este pedido já estava com o pagamento confirmado.'); end if;
  update vendas set status_pagamento = 'Pago', recebido_em = now() where id = v.id;
  if nullif(v.telefone_cliente,'') is not null then perform _carimbar_fidelidade(v.telefone_cliente, v.cliente_nome); end if;
  perform _auditar('Pagamento confirmado', '#' || v.numero_pedido, v.telefone_cliente);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_criar_pedido_cardapio(p jsonb)
 RETURNS jsonb
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$ select _criar_pedido_publico(p, null) $function$
;

CREATE OR REPLACE FUNCTION public.api_criar_pedido_mesa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_q jsonb := _mesa_qr(p->>'mesa', p->>'codigo');
begin
  if v_q->>'ok' <> 'true' then return v_q; end if;
  return _criar_pedido_publico(p, (v_q->>'mesaId')::uuid);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_criar_usuario(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'auth', 'extensions'
AS $function$
declare v_login text := btrim(coalesce(p->>'novoLogin', '')); v_senha text := coalesce(p->>'novaSenha', ''); v_nivel text := p->>'nivel';
        v_erro text; v_id uuid := gen_random_uuid(); v_email text; v_aut text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_login = '' or v_senha = '' or coalesce(v_nivel, '') = '' then return _falha('Preencha login, senha e nível de acesso.'); end if;
  if v_login !~ '^[A-Za-z0-9\u00C0-\u00FF][A-Za-z0-9\u00C0-\u00FF._-]{2,29}$' then
    return _falha('Login inválido: use de 3 a 30 caracteres (letras, números, ponto, hífen ou sublinhado), começando por letra ou número e sem espaços.');
  end if;
  v_erro := _erro_senha_fraca(v_senha, v_login);
  if v_erro <> '' then return _falha(v_erro); end if;
  if v_nivel = 'Desenvolvedor' then return _falha('Não é possível criar usuário Desenvolvedor.'); end if;
  if v_nivel not in ('Admin','Operador','Garçom','Cozinha','Entregador') then return _falha('Nível de acesso inválido.'); end if;
  v_aut := _exige_admin(p->>'senhaAdminConfirmacao');
  if v_aut is null then return _falha('Senha de administrador incorreta.'); end if;
  v_email := _email_login(v_login);
  if exists (select 1 from usuarios where lower(login) = lower(v_login)) or exists (select 1 from auth.users where lower(email) = v_email) then
    return _falha('Já existe um usuário com esse login.');
  end if;
  perform _criar_login_auth(v_id, v_email, v_senha);
  insert into usuarios (id, login, nome, telefone, nivel, ativo)
  values (v_id, v_login, left(coalesce(p->>'nome', ''), 60), left(coalesce(p->>'telefone', ''), 25), v_nivel::nivel_acesso, true);
  perform _auditar('Usuário criado', v_login || ' (' || v_nivel || ')');
  return jsonb_build_object('ok', true, 'message', 'Usuário criado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_detectar_novos_pedidos(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_nivel nivel_acesso := auth_nivel(); v_eu uuid := auth.uid(); v_ids jsonb; v_rec jsonb; v_ent jsonb; v_pro jsonb;
begin
  if v_nivel is null then return _negado(); end if;
  if v_nivel = 'Entregador' then
    select coalesce(jsonb_agg(v.id::text), '[]'::jsonb) into v_ent from (select * from vendas order by data_hora desc limit 300) v
     where v.status = 'Confirmada' and v.tipo = 'Entrega' and v.entregador_id = v_eu and v.status_pedido::text not in ('Entregue', 'Suspenso');
    return jsonb_build_object('ok', true, 'ids', '[]'::jsonb, 'recebidos', '[]'::jsonb, 'total', 0, 'entregas', v_ent, 'prontas', '[]'::jsonb);
  elsif v_nivel = 'Garçom' then
    select coalesce(jsonb_agg(v.id::text), '[]'::jsonb) into v_pro from (select * from vendas order by data_hora desc limit 300) v
     where v.status = 'Confirmada' and v.status_pedido = 'Pronta' and v.mesa_id in (select id from mesas where garcom_responsavel_id = v_eu);
    return jsonb_build_object('ok', true, 'ids', '[]'::jsonb, 'recebidos', '[]'::jsonb, 'total', 0, 'entregas', '[]'::jsonb, 'prontas', v_pro);
  end if;
  select coalesce(jsonb_agg(v.id::text) filter (where v.status_pedido = 'Recebido' or (v.status_pedido = 'Em preparo' and v.inicio_preparo_em is null)), '[]'::jsonb),
         coalesce(jsonb_agg(v.id::text) filter (where v.status_pedido = 'Recebido'), '[]'::jsonb)
    into v_ids, v_rec
    from (select * from vendas order by data_hora desc limit 300) v where v.status = 'Confirmada';
  return jsonb_build_object('ok', true, 'ids', v_ids, 'recebidos', v_rec, 'total', jsonb_array_length(v_ids));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_distancia_entrega_publico(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_alvo text := lower(btrim(coalesce(p->>'codigo', ''))); v_ip text := _ip_cliente(); v vendas%rowtype;
  pos entregador_posicoes%rowtype; d entrega_destinos%rowtype; v_seg int; v_km double precision;
begin
  if v_alvo !~ '^[0-9a-f-]{8,36}$' then return jsonb_build_object('ok', false); end if;
  if _excedeu('distpub_ip_' || v_ip, 60) then return jsonb_build_object('ok', false, 'limite', true); end if;
  perform _registrar_falha('distpub_ip_' || v_ip, 600);
  select * into v from vendas where right(id::text, 8) = right(v_alvo, 8) and right(id::text, length(v_alvo)) = v_alvo order by data_hora desc limit 1;
  if not found or v.tipo::text <> 'Entrega' or v.status_pedido::text <> 'Saiu para entrega' then return jsonb_build_object('ok', true, 'estado', 'fora_da_entrega'); end if;
  select * into d from entrega_destinos where venda_id = v.id;
  if not found then return jsonb_build_object('ok', true, 'estado', 'sem_destino'); end if;
  select * into pos from entregador_posicoes where venda_id = v.id;
  if not found then return jsonb_build_object('ok', true, 'estado', 'sem_posicao'); end if;
  v_seg := greatest(0, extract(epoch from (now() - pos.atualizado_em))::int);
  if v_seg > 300 then return jsonb_build_object('ok', true, 'estado', 'sem_sinal'); end if;
  v_km := _dist_km(pos.lat, pos.lng, d.lat, d.lng);
  return jsonb_build_object('ok', true, 'estado', 'ok', 'km', round(v_km::numeric, 1), 'atualizadoHaSeg', v_seg);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_adicional(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id'); v_nome text := btrim(coalesce(p->>'nome', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not exists (select 1 from adicionais where id = v_id) then return _falha('Adicional não encontrado.'); end if;
  if _versao_conflita(p, 'adicionais', v_id) then return _conflito('Este registro foi alterado por outra pessoa enquanto você editava. A tela foi atualizada — confira e edite de novo.'); end if;
  update adicionais set nome = case when v_nome = '' then nome else v_nome end, preco = _num(p->>'preco') where id = v_id;
  if p ? 'ativo' then update adicionais set ativo = (coalesce(p->>'ativo','') <> 'false') where id = v_id; end if;
  if p ? 'ingredienteId' then update adicionais set ingrediente_id = _uuid(p->>'ingredienteId') where id = v_id; end if;
  if p ? 'quantidadeDesconto' then update adicionais set quantidade_descontar = coalesce(nullif(_num(p->>'quantidadeDesconto'), 0), 1) where id = v_id; end if;
  perform _auditar('Adicional editado', v_nome);
  return jsonb_build_object('ok', true, 'message', 'Adicional atualizado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_categoria(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id'); v_nome text := btrim(coalesce(p->>'novoNome', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not exists (select 1 from categorias where id = v_id) then return _falha('Categoria não encontrada.'); end if;
  if _versao_conflita(p, 'categorias', v_id) then return _conflito('Este registro foi alterado por outra pessoa enquanto você editava. A tela foi atualizada — confira e edite de novo.'); end if;
  if v_nome <> '' then update categorias set nome = v_nome where id = v_id; end if;
  if p ? 'novoAtivo' then update categorias set ativa = (coalesce(p->>'novoAtivo','') <> 'false') where id = v_id; end if;
  if p ? 'novaOrdem' and p->>'novaOrdem' is not null then update categorias set ordem = _num(p->>'novaOrdem')::int where id = v_id; end if;
  perform _auditar('Categoria atualizada', coalesce(nullif(v_nome, ''), v_id::text));
  return jsonb_build_object('ok', true, 'message', 'Categoria atualizada.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_combo(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id'); v_nome text := btrim(coalesce(p->>'nome', '')); v_det text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not exists (select 1 from combos where id = v_id) then return _falha('Combo não encontrado.'); end if;
  if _versao_conflita(p, 'combos', v_id) then return _conflito('Este registro foi alterado por outra pessoa enquanto você editava. A tela foi atualizada — confira e edite de novo.'); end if;
  if v_nome = '' then return _falha('Informe o nome do combo.'); end if;
  if jsonb_typeof(p->'precos') = 'array' then
    select coalesce(string_agg(f.nome || ': R$ ' || to_char(a.preco, 'FM999990.00') || ' → R$ ' || to_char(_num(e->>'preco'), 'FM999990.00'), '; '), '') into v_det
    from jsonb_array_elements(p->'precos') e
    join combo_precos a on a.combo_id = v_id and a.forma_pagamento_id = _uuid(e->>'formaPagamentoId')
    join formas_pagamento f on f.id = a.forma_pagamento_id
    where a.preco <> _num(e->>'preco');
  end if;
  update combos set nome = v_nome, categoria_id = _uuid(p->>'categoria'), ativo = (coalesce(p->>'ativo','') <> 'false') where id = v_id;
  if p ? 'destaque' then update combos set destaque = coalesce((p->>'destaque')::boolean, false) where id = v_id; end if;
  if jsonb_typeof(p->'precos') = 'array' then perform _combo_gravar_precos(v_id, p->'precos'); end if;
  if jsonb_typeof(p->'itens') = 'array' then perform _combo_gravar_itens(v_id, p->'itens'); end if;
  perform _auditar('Combo editado', v_nome || case when coalesce(v_det, '') <> '' then ' — Preços alterados: ' || v_det else '' end);
  return jsonb_build_object('ok', true, 'message', 'Combo atualizado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_cupom(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v record; v_id uuid := _uuid(p->>'id');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_id is null or not exists (select 1 from cupons where id = v_id) then return _falha('Cupom não encontrado.'); end if;
  if _versao_conflita(p, 'cupons', v_id) then return _conflito('Este registro foi alterado por outra pessoa enquanto você editava. A tela foi atualizada — confira e edite de novo.'); end if;
  select * into v from _cupom_validar(p, v_id);
  if v.erro is not null then return _falha(v.erro); end if;
  update cupons set codigo = (v.c).codigo, nome = (v.c).nome, tipo = (v.c).tipo, valor = (v.c).valor, frete_gratis = (v.c).frete_gratis,
         data_inicio = (v.c).data_inicio, data_fim = (v.c).data_fim, hora_inicio = (v.c).hora_inicio, hora_fim = (v.c).hora_fim,
         limite_total = (v.c).limite_total, limite_por_cliente = (v.c).limite_por_cliente, valor_minimo = (v.c).valor_minimo, ativa = (v.c).ativa, acumula = (v.c).acumula
   where id = v_id;
  perform _auditar('Cupom alterado', (v.c).codigo, (v.c).nome);
  return jsonb_build_object('ok', true, 'message', 'Cupom atualizado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_despesa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare d despesas%rowtype; v_desc text := btrim(coalesce(p->>'descricao', '')); v_valor numeric := round(_num(p->>'valor'), 2);
        v_cat text; v_venc date; v_venc_txt text := btrim(coalesce(p->>'vencimento', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_desc = '' then return _falha('Informe a descrição da despesa.'); end if;
  if v_valor <= 0 then return _falha('Informe um valor maior que zero.'); end if;
  if v_valor > 9999999 then return _falha('Valor alto demais.'); end if;
  select * into d from despesas where id = _uuid(p->>'id') for update;
  if not found then return _falha('Despesa não encontrada.'); end if;
  if _versao_conflita(p, 'despesas', d.id) then return _conflito('Este registro foi alterado por outra pessoa enquanto você editava. A tela foi atualizada — confira e edite de novo.'); end if;
  if d.status = 'Cancelada' then return _falha('Só é possível editar despesas confirmadas.'); end if;
  if d.categoria = 'Ajuste pós-venda' then return _falha('Esta despesa nasceu de um Ajuste pós-venda. Para desfazer, cancele o ajuste em Financeiro → Ajustes pós-venda.'); end if;
  v_cat := case when p ? 'categoria' then _categoria_despesa(p->>'categoria') else d.categoria end;
  v_venc := d.vencimento;
  if v_venc_txt <> '' then
    v_venc := _data_iso(v_venc_txt);
    if v_venc is null then return _falha('Vencimento inválido.'); end if;
  end if;
  if d.status = 'A pagar' and v_venc is null then return _falha('Conta a pagar precisa de vencimento.'); end if;
  update despesas set descricao = v_desc, valor = v_valor, observacao = coalesce(p->>'observacao', ''), categoria = v_cat,
         vencimento = v_venc,
         data_hora = case when v_venc is distinct from d.vencimento and d.status = 'A pagar' then _meio_dia(v_venc) else data_hora end
   where id = d.id;
  perform _auditar('Despesa editada', v_desc || ' | valor R$ ' || _dinheiro(d.valor) || ' → R$ ' || _dinheiro(v_valor)
    || case when v_venc is distinct from d.vencimento then ' | vencimento ' || coalesce(d.vencimento::text, '—') || ' → ' || coalesce(v_venc::text, '—') else '' end);
  return jsonb_build_object('ok', true, 'message', 'Despesa atualizada.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_despesa_recorrente(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare a despesas_recorrentes%rowtype; v_desc text; v_valor numeric; v_dia numeric; v_per text; v_ini text; v_ter text; v_erro text; v_cat text; v_ativa boolean;
        v_mudou text[] := '{}'; v_n int;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into a from despesas_recorrentes where id = _uuid(p->>'id') for update;
  if not found then return _falha('Despesa mensal não encontrada.'); end if;
  if _versao_conflita(p, 'despesas_recorrentes', a.id) then return _conflito('Este registro foi alterado por outra pessoa enquanto você editava. A tela foi atualizada — confira e edite de novo.'); end if;
  v_desc := case when p ? 'descricao' then btrim(coalesce(p->>'descricao', '')) else a.descricao end;
  v_valor := case when p ? 'valor' then round(_num(p->>'valor'), 2) else a.valor end;
  v_dia := case when p ? 'diaVencimento' then _num(p->>'diaVencimento', 0) else a.dia_vencimento end;
  v_per := case when p ? 'periodicidade' then p->>'periodicidade' else a.periodicidade end;
  v_ini := coalesce(nullif(p->>'inicio', ''), to_char(a.inicio, 'YYYY-MM'));
  v_ter := case when p ? 'termino' then coalesce(p->>'termino', '') else coalesce(to_char(a.termino, 'YYYY-MM'), '') end;
  v_erro := _erro_recorrente(v_desc, v_valor, v_dia, v_per, v_ini, v_ter);
  if v_erro <> '' then return _falha(v_erro); end if;
  v_cat := _categoria_despesa(p->>'categoria', a.categoria);
  v_ativa := case when p ? 'ativa' then coalesce(p->>'ativa', '') <> 'false' else a.ativa end;
  update despesas_recorrentes set descricao = v_desc, categoria = v_cat, valor = v_valor, dia_vencimento = v_dia::int, periodicidade = v_per, ativa = v_ativa,
         observacao = case when p ? 'observacao' then coalesce(p->>'observacao', '') else observacao end,
         inicio = (v_ini || '-01')::date, termino = case when v_ter <> '' then (v_ter || '-01')::date end
   where id = a.id;
  if a.valor <> v_valor then v_mudou := v_mudou || ('valor R$ ' || _dinheiro(a.valor) || ' → R$ ' || _dinheiro(v_valor)); end if;
  if a.dia_vencimento <> v_dia::int then v_mudou := v_mudou || ('dia ' || a.dia_vencimento || ' → ' || v_dia::int); end if;
  if a.periodicidade <> v_per then v_mudou := v_mudou || (a.periodicidade || ' → ' || v_per); end if;
  if a.ativa <> v_ativa then v_mudou := v_mudou || (case when v_ativa then 'reativada' else 'desativada' end); end if;
  perform _auditar('Despesa mensal editada', v_desc || case when array_length(v_mudou, 1) > 0 then ' | ' || array_to_string(v_mudou, ' | ') else '' end);
  v_n := _gerar_despesas_recorrentes(_competencia_atual());
  return jsonb_build_object('ok', true, 'message', 'Despesa mensal atualizada.' || case when v_n > 0 then ' ' || v_n || ' conta(s) gerada(s) neste mês.' else '' end);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_forma_pagamento(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  f formas_pagamento%rowtype; v_id uuid := _uuid(p->>'id');
  v_pct numeric; v_fixa numeric; v_prazo numeric; v_erro text; v_novo text; v_mudou text := '';
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into f from formas_pagamento where id = v_id;
  if not found then return _falha('Forma de pagamento não encontrada.'); end if;
  if _versao_conflita(p, 'formas_pagamento', v_id) then return _conflito('Este registro foi alterado por outra pessoa enquanto você editava. A tela foi atualizada — confira e edite de novo.'); end if;
  v_pct   := case when p ? 'novaTaxaPct'   then _num(p->>'novaTaxaPct')   else f.taxa_percentual end;
  v_fixa  := case when p ? 'novaTaxaFixa'  then _num(p->>'novaTaxaFixa')  else f.taxa_fixa end;
  v_prazo := case when p ? 'novoPrazoDias' then _num(p->>'novoPrazoDias') else f.prazo_dias end;
  v_erro := _validar_forma(v_pct, v_fixa, v_prazo);
  if v_erro <> '' then return _falha(v_erro); end if;
  v_novo := btrim(coalesce(p->>'novoNome', ''));
  if v_novo <> '' and v_novo <> f.nome then
    if exists (select 1 from formas_pagamento where id <> f.id and lower(nome) = lower(v_novo)) then return _falha('Já existe uma forma de pagamento com esse nome.'); end if;
    -- vendas antigas guardam o NOME da forma; renomear quebraria o vínculo
    if exists (select 1 from pagamentos_venda where forma_pagamento = f.nome) or exists (select 1 from vendas where forma_pagamento = f.nome) then
      return _falha('Essa forma já foi usada em vendas e não pode ser renomeada. Desative e cadastre uma nova.');
    end if;
    update formas_pagamento set nome = v_novo where id = f.id;
  end if;
  if p ? 'novoAtivo' then update formas_pagamento set ativa = (coalesce(p->>'novoAtivo','') <> 'false') where id = f.id; end if;
  if p ? 'novoVisivelCardapio' then update formas_pagamento set visivel_cardapio = (coalesce(p->>'novoVisivelCardapio','') <> 'false') where id = f.id; end if;
  if p ? 'novoPermiteTroco' then update formas_pagamento set permite_troco = coalesce((p->>'novoPermiteTroco')::boolean, false) where id = f.id; end if;
  if p ? 'novaOrdem' then update formas_pagamento set ordem = _num(p->>'novaOrdem')::int where id = f.id; end if;
  update formas_pagamento set taxa_percentual = v_pct, taxa_fixa = v_fixa, prazo_dias = v_prazo::int where id = f.id;
  if v_pct <> f.taxa_percentual then v_mudou := v_mudou || ' | taxa % ' || f.taxa_percentual || ' → ' || v_pct; end if;
  if v_fixa <> f.taxa_fixa then v_mudou := v_mudou || ' | taxa fixa R$ ' || to_char(f.taxa_fixa, 'FM999990.00') || ' → R$ ' || to_char(v_fixa, 'FM999990.00'); end if;
  if v_prazo <> f.prazo_dias then v_mudou := v_mudou || ' | prazo ' || f.prazo_dias || 'd → ' || v_prazo::int || 'd'; end if;
  perform _auditar('Forma de pagamento atualizada', coalesce(nullif(v_novo, ''), f.nome) || v_mudou);
  return jsonb_build_object('ok', true, 'message', 'Forma de pagamento atualizada.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_ingrediente(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare e estoque%rowtype; v_id uuid := _uuid(p->>'id'); v_qtd numeric := _num(p->>'quantidade'); v_nome text := btrim(coalesce(p->>'nome', ''));
        v_un text := coalesce(nullif(p->>'unidade', ''), 'un');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into e from estoque where id = v_id;
  if not found then return _falha('Ingrediente não encontrado.'); end if;
  if v_nome = '' then v_nome := e.ingrediente; end if;
  if v_un not in ('un','g','kg','ml','l') then v_un := 'un'; end if;
  update estoque set ingrediente = v_nome, quantidade = v_qtd, quantidade_minima = _num(p->>'minimo'),
         unidade = v_un::unidade_estoque, custo_unitario = _num(p->>'custo') where id = e.id;
  if p ? 'ativo' then update estoque set status = case when coalesce(p->>'ativo','') = 'false' then 'Inativo' else 'Ativo' end where id = e.id; end if;
  if v_qtd <> e.quantidade then
    insert into movimentacoes_estoque (ingrediente_id, tipo, quantidade, qtd_antes, qtd_depois, motivo_referencia, usuario_id)
    values (e.id, 'Ajuste', v_qtd - e.quantidade, e.quantidade, v_qtd, 'Edição manual do cadastro', auth.uid());
  end if;
  perform _auditar('Estoque atualizado', v_nome || ': ' || e.quantidade || ' → ' || v_qtd || ' ' || v_un);
  return jsonb_build_object('ok', true, 'message', 'Estoque atualizado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_ordem_cardapio_combo(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not exists (select 1 from combos where id = v_id) then return _falha('Combo não encontrado.'); end if;
  update combos set ordem_cardapio = _num(p->>'ordem')::int where id = v_id;
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_ordem_cardapio_produto(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not exists (select 1 from produtos where id = v_id) then return _falha('Produto não encontrado.'); end if;
  update produtos set ordem_cardapio = _num(p->>'ordem')::int where id = v_id;
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_premio_produto(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare v_id uuid := nullif(btrim(coalesce(p->>'produtoId','')),'')::uuid;
begin
  if not public.tem_nivel('Admin') then return public._negado(); end if;
  if v_id is null then return public._falha('Produto inválido.'); end if;
  update public.produtos
     set premio_fidelidade = coalesce((p->>'premioFidelidade')::boolean, premio_fidelidade),
         premio_indicacao  = coalesce((p->>'premioIndicacao')::boolean,  premio_indicacao)
   where id = v_id;
  if not found then return public._falha('Produto não encontrado.'); end if;
  return jsonb_build_object('ok', true, 'message', 'Prêmio atualizado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_produto(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare pr produtos%rowtype; v_id uuid := _uuid(p->>'id'); v_nome text := btrim(coalesce(p->>'nome', '')); v_proprio uuid; v_det text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into pr from produtos where id = v_id;
  if not found then return _falha('Produto não encontrado.'); end if;
  if _versao_conflita(p, 'produtos', v_id) then return _conflito('Este registro foi alterado por outra pessoa enquanto você editava. A tela foi atualizada — confira e edite de novo.'); end if;
  if v_nome = '' then return _falha('Informe o nome do produto.'); end if;
  if jsonb_typeof(p->'precos') = 'array' then
    select coalesce(string_agg(f.nome || ': R$ ' || to_char(a.preco, 'FM999990.00') || ' → R$ ' || to_char(_num(e->>'preco'), 'FM999990.00'), '; '), '') into v_det
    from jsonb_array_elements(p->'precos') e
    join produto_precos a on a.produto_id = v_id and a.forma_pagamento_id = _uuid(e->>'formaPagamentoId')
    join formas_pagamento f on f.id = a.forma_pagamento_id
    where a.preco <> _num(e->>'preco');
  end if;
  v_proprio := _estoque_proprio(pr.estoque_proprio_ingrediente_id, v_nome, p->'estoqueProprio');
  update produtos set nome = v_nome, descricao = coalesce(p->>'descricao', ''), categoria_id = _uuid(p->>'categoria'),
         ativo = (coalesce(p->>'ativo','') <> 'false'), estoque_proprio_ingrediente_id = v_proprio where id = v_id;
  if p ? 'destaque' then update produtos set destaque = coalesce((p->>'destaque')::boolean, false) where id = v_id; end if;
  if p ? 'premioFidelidade' then update produtos set premio_fidelidade = coalesce((p->>'premioFidelidade')::boolean, false) where id = v_id; end if;
  if p ? 'premioIndicacao' then update produtos set premio_indicacao = coalesce((p->>'premioIndicacao')::boolean, false) where id = v_id; end if;
  if jsonb_typeof(p->'precos') = 'array' then perform _produto_gravar_precos(v_id, p->'precos'); end if;
  perform _produto_gravar_receita(v_id, p->'ingredientes', v_proprio);
  if p ? 'adicionaisIds' then perform _produto_gravar_adicionais(v_id, p->'adicionaisIds'); end if;
  perform _auditar('Produto editado', v_nome || case when coalesce(v_det, '') <> '' then ' — Preços alterados: ' || v_det else '' end);
  return jsonb_build_object('ok', true, 'message', 'Produto atualizado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_status_feedback(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_st text := coalesce(nullif(btrim(p->>'novoStatus'), ''), 'Novo');
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if v_st <> all (array['Novo','Visto','Respondido']) then return _falha('Status de feedback inválido.'); end if;
  update feedbacks set status = v_st where id = _uuid(p->>'id');
  if not found then return _falha('Feedback não encontrado.'); end if;
  perform _auditar('Feedback atualizado', 'Status: ' || v_st);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_status_mesa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare m mesas%rowtype; v_id uuid := _uuid(p->>'id'); v_novo text := p->>'novoStatus'; v_eu uuid := auth.uid(); v_nivel nivel_acesso := auth_nivel();
begin
  if v_nivel is null or v_nivel not in ('Admin','Operador','Garçom') then return _negado(); end if;
  if v_novo is null or v_novo not in ('Livre','Ocupada','Aguardando fechamento','Fechada','Bloqueada/Manutenção') then return _falha('Status de mesa inválido.'); end if;
  select * into m from mesas where id = v_id;
  if not found then return _falha('Mesa não encontrada.'); end if;
  if v_nivel = 'Garçom' then
    if not ((m.status = 'Livre' and v_novo = 'Ocupada') or (m.status = 'Ocupada' and v_novo = 'Aguardando fechamento')) then
      return _falha('O garçom só pode abrir uma mesa livre ou pedir o fechamento de uma mesa ocupada.');
    end if;
    if m.status = 'Ocupada' and m.garcom_responsavel_id is not null and m.garcom_responsavel_id <> v_eu then
      return _falha('Esta mesa está sob responsabilidade de outro garçom.');
    end if;
    update mesas set status = v_novo::status_mesa where id = m.id;
    if v_novo = 'Ocupada' then update mesas set garcom_responsavel_id = v_eu where id = m.id; end if;
    if p ? 'observacao' then update mesas set observacao = p->>'observacao' where id = m.id; end if;
    if v_novo = 'Aguardando fechamento' then perform _auditar('Fechamento de mesa solicitado', 'Mesa ' || m.numero); end if;
  else
    update mesas set status = v_novo::status_mesa where id = m.id;
    if p ? 'observacao' then update mesas set observacao = p->>'observacao' where id = m.id; end if;
    if v_novo = 'Livre' then update mesas set garcom_responsavel_id = null where id = m.id; end if;
  end if;
  perform _auditar('Status de mesa alterado', 'Mesa ' || m.numero || ': ' || m.status || ' → ' || v_novo);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_usuario(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  u usuarios%rowtype;
  v_alvo text := coalesce(p->>'loginAlvo', '');
  v_aut text; v_erro text;
  v_sera_admin boolean; v_sera_ativo boolean; v_contato boolean := false; v_nome text; v_tel text;
  v_nivel_real nivel_acesso; v_sessao uuid;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select nivel into v_nivel_real from usuarios where id = auth.uid() and ativo;
  if v_nivel_real is null then return _negado(); end if;
  if p ? 'novoNivel' and coalesce(p->>'novoNivel', '') not in ('Admin','Operador','Garçom','Cozinha','Entregador','Desenvolvedor') then return _falha('Nível de acesso inválido.'); end if;
  if p ? 'novoNivel' and p->>'novoNivel' = 'Desenvolvedor' and coalesce((select nivel::text from usuarios where lower(login) = lower(coalesce(p->>'loginAlvo','')) ), '') <> 'Desenvolvedor' then
    return _falha('Não é possível conceder o nível Desenvolvedor.');
  end if;
  if p ? 'novoNivel' and p->>'novoNivel' = 'Desenvolvedor' and v_nivel_real <> 'Desenvolvedor' then
    return _falha('Somente um Desenvolvedor pode conceder o nível Desenvolvedor.');
  end if;
  v_aut := _exige_admin(p->>'senhaAdminConfirmacao');
  if v_aut is null then return _falha('Senha de administrador incorreta.'); end if;
  select * into u from usuarios where lower(login) = lower(v_alvo);
  if not found then return _falha('Usuário não encontrado.'); end if;
  if u.nivel = 'Desenvolvedor' and v_nivel_real <> 'Desenvolvedor' then
    return _falha('A conta de Desenvolvedor é protegida e só pode ser alterada por um Desenvolvedor.');
  end if;
  if p ? 'nome' and length(coalesce(p->>'nome', '')) > 60 then return _falha('O nome pode ter no máximo 60 caracteres.'); end if;
  if p ? 'telefone' and length(coalesce(p->>'telefone', '')) > 25 then return _falha('O telefone pode ter no máximo 25 caracteres.'); end if;
  v_sera_admin := case when p ? 'novoNivel' then p->>'novoNivel' = 'Admin' else u.nivel = 'Admin' end;
  v_sera_ativo := case when p ? 'novoAtivo' then coalesce((p->>'novoAtivo')::boolean, false) else u.ativo end;
  if u.id = auth.uid() and p ? 'novoAtivo' and not v_sera_ativo then return _falha('Você não pode desativar o seu próprio acesso.'); end if;
  if u.id = auth.uid() and p ? 'novoNivel' and p->>'novoNivel' <> u.nivel::text then return _falha('Você não pode alterar o seu próprio perfil.'); end if;
  if u.nivel = 'Admin' and (not v_sera_admin or not v_sera_ativo) then
    if not exists (select 1 from usuarios where nivel = 'Admin' and ativo and id <> u.id) then return _falha('Não é possível remover o último administrador ativo.'); end if;
  end if;
  -- ao editar a si mesmo, a sessão atual continua valendo (as outras caem)
  v_sessao := case when u.id = auth.uid() then nullif(auth.jwt() ->> 'session_id', '')::uuid else null end;
  if coalesce(p->>'novaSenha', '') <> '' then
    v_erro := _erro_senha_fraca(p->>'novaSenha', u.login);
    if v_erro <> '' then return _falha(v_erro); end if;
    update auth.users set encrypted_password = crypt(p->>'novaSenha', gen_salt('bf')), updated_at = now() where id = u.id;
    delete from auth.sessions where user_id = u.id and id is distinct from v_sessao;
  end if;
  if p ? 'novoNivel' then update usuarios set nivel = (p->>'novoNivel')::nivel_acesso where id = u.id; end if;
  if p ? 'novoAtivo' then
    update usuarios set ativo = v_sera_ativo where id = u.id;
    if not v_sera_ativo then delete from auth.sessions where user_id = u.id and id is distinct from v_sessao; end if;
  end if;
  if p ? 'nome' then v_nome := btrim(coalesce(p->>'nome', '')); if v_nome <> coalesce(u.nome, '') then update usuarios set nome = v_nome where id = u.id; v_contato := true; end if; end if;
  if p ? 'telefone' then v_tel := btrim(coalesce(p->>'telefone', '')); if v_tel <> coalesce(u.telefone, '') then update usuarios set telefone = v_tel where id = u.id; v_contato := true; end if; end if;
  perform _auditar('Usuário editado', u.login || case when coalesce(p->>'novaSenha', '') <> '' then ' (senha alterada)' else '' end
    || case when v_contato then ' (nome/telefone alterado)' else '' end
    || case when p ? 'novoNivel' then ' nível=' || (p->>'novoNivel') else '' end
    || case when p ? 'novoAtivo' then ' ativo=' || case when v_sera_ativo then 'Sim' else 'Não' end else '' end);
  return jsonb_build_object('ok', true, 'message', 'Usuário atualizado.');
end
$function$
;

CREATE OR REPLACE FUNCTION public.api_editar_venda(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v vendas%rowtype; v_aut text; v_motivo text := btrim(coalesce(p->>'motivo', '')); v_itens jsonb := p->'itens'; v_login text;
  it record; v_qtd numeric; v_v numeric; v_c numeric; v_nome text; v_extra numeric; v_n_ad int; v_n_ok int; v_exige boolean; v_prod uuid; v_comb uuid;
  v_ads jsonb; v_soma numeric := 0; v_custo numeric := 0; v_total numeric; v_novos jsonb := '[]'::jsonb; v_npag int; v_antes numeric; v_st text; v_antes_aceite boolean; v_aviso text := '';
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  v_aut := _exige_admin(p->>'senhaAdminConfirmacao');
  if v_aut is null then return _falha('Senha de administrador incorreta.'); end if;
  if v_motivo = '' then return _falha('Informe o motivo da edição.'); end if;
  if jsonb_typeof(v_itens) <> 'array' or jsonb_array_length(v_itens) = 0 then return _falha('A venda precisa ter ao menos um item.'); end if;
  if jsonb_array_length(v_itens) > 60 then return _falha('Itens demais na venda.'); end if;
  select * into v from vendas where id = _uuid(p->>'id') for update;
  if not found then return _falha('Venda não encontrada.'); end if;
  if _versao_conflita(p, 'vendas', v.id) then return _conflito('Este registro foi alterado por outra pessoa enquanto você editava. A tela foi atualizada — confira e edite de novo.'); end if;
  if v.status <> 'Confirmada' then return _falha('Só é possível editar vendas confirmadas.'); end if;
  if v.fechamento_entrega_id is not null then return _falha('Esta entrega já está em um fechamento — não pode mais ser alterada.'); end if;
  v_st := v.status_pedido::text;
  if v_st is not null and v_st not in ('Em preparo', 'Recebido') then return _falha('Este pedido já está "' || v_st || '" — não é mais possível editar os itens.'); end if;
  v_antes_aceite := v_st = 'Recebido';
  select count(*) into v_npag from pagamentos_venda where venda_id = v.id;
  if v_npag > 1 then return _falha('Venda com pagamento dividido não pode ser editada. Cancele e lance novamente.'); end if;
  v_exige := not (auth_nivel() = 'Admin' and v.origem::text <> 'Cardápio');

  for it in select value as e from jsonb_array_elements(v_itens) loop
    v_nome := coalesce(nullif(it.e->>'descricao', ''), 'item');
    v_qtd := _num(it.e->>'quantidade'); v_v := _num(it.e->>'valorUnitario', -1); v_c := _num(it.e->>'custoUnitario');
    v_prod := _uuid(it.e->>'produtoId'); v_comb := _uuid(it.e->>'comboId');
    if not (v_qtd > 0) or v_qtd > 200 or v_qtd <> floor(v_qtd) then return _falha('Quantidade inválida em "' || v_nome || '".'); end if;
    if v_v < 0 then return _falha('Preço inválido em "' || v_nome || '".'); end if;
    if v_c < 0 then return _falha('Custo inválido em "' || v_nome || '".'); end if;
    -- adicionais: os enviados; se não vierem, mantém os do item antigo de mesma descrição (como na planilha)
    v_ads := case when jsonb_typeof(it.e->'adicionaisIds') = 'array' then it.e->'adicionaisIds'
                  else coalesce((select to_jsonb(iv.adicionais_ids) from itens_venda iv where iv.venda_id = v.id and iv.descricao = it.e->>'descricao' limit 1), '[]'::jsonb) end;
    if v_exige and not exists (select 1 from itens_venda iv where iv.venda_id = v.id and iv.descricao = it.e->>'descricao' and abs(iv.valor_unitario - v_v) <= 0.001 and abs(iv.custo_unitario - v_c) <= 0.011
                                 and coalesce(iv.produto_id, iv.combo_id) is not distinct from coalesce(v_prod, v_comb)) then
      -- item novo ou com preço mudado: precisa conferir com o cadastro
      if (v_prod is null and v_comb is null) or (v_prod is not null and v_comb is not null) then return _falha('"' || v_nome || '" não é um item cadastrado de forma válida.'); end if;
      select count(*), coalesce(sum(a.preco) filter (where a.ativo), 0), count(a.id) filter (where a.ativo and ((v_prod is not null and exists (select 1 from produto_adicionais pa where pa.produto_id = v_prod and pa.adicional_id = a.id)) or (v_comb is not null and exists (select 1 from combo_itens ci join produto_adicionais pa on pa.produto_id = ci.produto_id where ci.combo_id = v_comb and pa.adicional_id = a.id)))) into v_n_ad, v_extra, v_n_ok
        from jsonb_array_elements_text(v_ads) x left join adicionais a on a.id = _uuid(x);
      if v_n_ad <> v_n_ok then return _falha('O adicional selecionado para "' || v_nome || '" não está disponível.'); end if;
      if v_prod is not null then
        if not exists (select 1 from produto_precos pp where pp.produto_id = v_prod and abs(pp.preco + v_extra - v_v) <= 0.011) then
          perform _auditar('Preço divergente bloqueado', v_nome || ' enviado a R$ ' || _dinheiro(v_v) || ' (edição de venda)');
          return _falha('O preço de "' || v_nome || '" não confere com o cadastro.');
        end if;
        if not exists (select 1 from produto_precos pp where pp.produto_id = v_prod and abs(pp.preco + v_extra - v_v) <= 0.011 and abs(pp.custo - v_c) <= 0.011) then
          perform _auditar('Custo divergente bloqueado', v_nome || ' enviado com custo R$ ' || _dinheiro(v_c) || ' (edição de venda)');
          return _falha('O custo de "' || v_nome || '" não confere com o cadastro.');
        end if;
      else
        if not exists (select 1 from combo_precos cp where cp.combo_id = v_comb and abs(cp.preco + v_extra - v_v) <= 0.011) then
          perform _auditar('Preço divergente bloqueado', v_nome || ' enviado a R$ ' || _dinheiro(v_v) || ' (edição de venda)');
          return _falha('O preço de "' || v_nome || '" não confere com o cadastro.');
        end if;
        if not exists (select 1 from combo_precos cp where cp.combo_id = v_comb and abs(cp.preco + v_extra - v_v) <= 0.011 and abs(cp.custo - v_c) <= 0.011) then
          perform _auditar('Custo divergente bloqueado', v_nome || ' enviado com custo R$ ' || _dinheiro(v_c) || ' (edição de venda)');
          return _falha('O custo de "' || v_nome || '" não confere com o cadastro.');
        end if;
      end if;
    end if;
    v_novos := v_novos || jsonb_build_array(jsonb_build_object('produtoId', v_prod, 'comboId', v_comb, 'descricao', v_nome, 'quantidade', v_qtd,
                                                                 'valorUnitario', v_v, 'custoUnitario', v_c, 'adicionaisIds', v_ads));
    v_soma := v_soma + round(v_qtd * v_v, 2); v_custo := v_custo + v_qtd * v_c;
  end loop;
  v_soma := round(v_soma, 2); v_custo := round(v_custo, 2);
  if v.valor_desconto >= v_soma then return _falha('Com o desconto já aplicado, o novo total ficaria zero ou negativo.'); end if;
  v_total := round(v_soma - v.valor_desconto + v.taxa_entrega, 2);
  v_antes := v.valor_total;

  perform _ajustar_estoque(_itens_da_venda(v.id), -1, v.id);
  delete from itens_venda where venda_id = v.id;
  insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
  select v.id, _uuid(e->>'produtoId'), _uuid(e->>'comboId'), e->>'descricao', _num(e->>'quantidade', 1)::int, _num(e->>'valorUnitario'), _num(e->>'custoUnitario'),
         round(_num(e->>'quantidade', 1) * _num(e->>'valorUnitario'), 2),
         coalesce((select array_agg(_uuid(x)) filter (where _uuid(x) is not null) from jsonb_array_elements_text(e->'adicionaisIds') x), '{}')
  from jsonb_array_elements(v_novos) e;
  update vendas set valor_total = v_total, custo_total = v_custo, valor_original = v_soma where id = v.id;
  if v_npag = 1 then
    update pagamentos_venda pv set valor = v_total,
      taxa_aplicada = coalesce((select round(v_total * f.taxa_percentual / 100 + f.taxa_fixa, 2) from formas_pagamento f where lower(f.nome) = lower(pv.forma_pagamento) limit 1), 0)
    where pv.venda_id = v.id;
  end if;
  perform _ajustar_estoque(v_novos, 1, v.id);
  select login into v_login from usuarios where id = auth.uid();
  perform _auditar('Venda editada', case when v_antes_aceite then '[edição antes do aceite] ' else '' end || 'Autorizado por ' || coalesce(nullif(current_setting('app.autorizador', true), ''), v_login)
    || ' | Motivo: ' || v_motivo || ' | Total: R$ ' || _dinheiro(v_antes) || ' → R$ ' || _dinheiro(v_total), v.telefone_cliente);
  if v_antes_aceite and v.origem::text = 'Cardápio' and v.status_pagamento::text = 'Pago' and abs(v_total - v_antes) >= 0.01 then
    v_aviso := ' ATENÇÃO: o valor mudou (R$ ' || _dinheiro(v_antes) || ' → R$ ' || _dinheiro(v_total) || ') e este pedido já consta como pago — acerte a diferença com o cliente.';
  end if;
  return jsonb_build_object('ok', true, 'message', 'Venda atualizada. Novo total: R$ ' || _dinheiro(v_total) || '.' || v_aviso, 'aviso', v_aviso <> '');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_visibilidade_cardapio_combo(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not exists (select 1 from combos where id = v_id) then return _falha('Combo não encontrado.'); end if;
  if p ? 'ativo' then update combos set ativo = (coalesce(p->>'ativo','') <> 'false') where id = v_id; end if;
  if p ? 'destaque' then update combos set destaque = coalesce((p->>'destaque')::boolean, false) where id = v_id; end if;
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_visibilidade_cardapio_produto(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not exists (select 1 from produtos where id = v_id) then return _falha('Produto não encontrado.'); end if;
  if p ? 'ativo' then update produtos set ativo = (coalesce(p->>'ativo','') <> 'false') where id = v_id; end if;
  if p ? 'destaque' then update produtos set destaque = coalesce((p->>'destaque')::boolean, false) where id = v_id; end if;
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_encerrar_sessao_remota(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'auth', 'extensions'
AS $function$
declare v_alvo text := coalesce(p->>'sessaoId', ''); s record; v_atual uuid := nullif(auth.jwt() ->> 'session_id', '')::uuid;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_alvo !~ '^[0-9a-f]{12}$' then return _falha('Sessão inválida.'); end if;
  select se.id, us.login, se.user_agent into s from auth.sessions se join usuarios us on us.id = se.user_id
    where left(replace(se.id::text, '-', ''), 12) = v_alvo limit 1;
  if not found then return _falha('Sessão não encontrada (talvez já tenha expirado).'); end if;
  if s.id = v_atual then return _falha('Esta é a sua sessão atual. Use "Sair" para encerrá-la.'); end if;
  delete from auth.sessions where id = s.id;
  perform _auditar('Acesso encerrado remotamente (usuário)', 'Sessão de ' || s.login || ' | ' || coalesce(s.user_agent, ''));
  return jsonb_build_object('ok', true, 'message', 'Sessão de ' || s.login || ' encerrada.');
end $function$
;

CREATE OR REPLACE FUNCTION public._limite_banco_mb()
 RETURNS numeric
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$ select coalesce((select nullif(valor #>> '{}', '')::numeric from sistema where chave = 'LIMITE_BANCO_MB'), 500) $function$
;
revoke all on function public._limite_banco_mb() from public, anon, authenticated;

CREATE OR REPLACE FUNCTION public.api_espaco_percentual_servico()
 RETURNS numeric
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$ select round(pg_database_size(current_database())/1024.0/1024.0/_limite_banco_mb()*100, 1) $function$
;

CREATE OR REPLACE FUNCTION public.api_espaco_uso()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_db bigint;
BEGIN
  IF NOT tem_nivel('Admin') THEN RETURN _negado(); END IF;
  SELECT pg_database_size(current_database()) INTO v_db;
  RETURN jsonb_build_object('ok',true,'db_bytes',v_db,'db_mb',round(v_db/1024.0/1024.0,2),
    'limite_mb',_limite_banco_mb(),'percentual',round(v_db/1024.0/1024.0/_limite_banco_mb()*100,1),
    'vendas_total',(SELECT count(*) FROM vendas),
    'vendas_arquivadas',(SELECT count(*) FROM arquivo_historico WHERE tabela='vendas'),
    'backups_total',(SELECT count(*) FROM backups),
    'backups_bytes',(SELECT coalesce(sum(tamanho_bytes),0) FROM backups));
END $function$
;

CREATE OR REPLACE FUNCTION public.api_excluir_adicional(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  delete from adicionais where id = v_id;   -- os vínculos com produtos saem junto
  perform _auditar('Adicional excluído', v_id::text);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_excluir_categoria(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id'); v_prod int; v_comb int;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select count(*) into v_prod from produtos where categoria_id = v_id;
  select count(*) into v_comb from combos where categoria_id = v_id;
  if v_prod + v_comb > 0 then
    return _falha((v_prod + v_comb) || ' item(ns) usam essa categoria (' || v_prod || ' produto(s), ' || v_comb || ' combo(s)). Mova-os para outra categoria antes de excluir.');
  end if;
  delete from categorias where id = v_id;
  perform _auditar('Categoria excluída', v_id::text);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_excluir_cliente(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id'); v_aut text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  v_aut := _exige_admin(p->>'senhaAdminConfirmacao');
  if v_aut is null then return _falha('Senha de administrador incorreta.'); end if;
  delete from clientes where id = v_id;   -- vendas antigas ficam com o nome e telefone gravados
  perform _auditar('Cliente excluído', v_id::text);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_excluir_combo(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  delete from combos where id = v_id;   -- preços e itens saem junto
  perform _auditar('Combo excluído', v_id::text);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_excluir_ingrediente(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if exists (select 1 from produto_ingredientes where ingrediente_id = v_id) then
    return _falha('Este ingrediente faz parte da receita de algum produto. Tire-o das receitas antes de excluir (ou deixe-o inativo).');
  end if;
  if exists (select 1 from movimentacoes_estoque where ingrediente_id = v_id) then
    return _falha('Este ingrediente tem histórico de movimentações e não pode ser excluído. Deixe-o inativo.');
  end if;
  delete from estoque where id = v_id;
  perform _auditar('Ingrediente excluído', v_id::text);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_excluir_mesa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare m mesas%rowtype; v_id uuid := _uuid(p->>'id');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into m from mesas where id = v_id;
  if found and m.status = 'Ocupada' then return _falha('Não é possível excluir uma mesa ocupada.'); end if;
  delete from mesas where id = v_id;
  perform _auditar('Mesa excluída', coalesce('Mesa ' || m.numero, v_id::text));
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_excluir_produto(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if exists (select 1 from combo_itens where produto_id = v_id) then
    return _falha('Este produto faz parte de um ou mais combos. Tire-o dos combos antes de excluir (ou deixe-o inativo).');
  end if;
  delete from produtos where id = v_id;   -- preços, receita e adicionais saem junto
  perform _auditar('Produto excluído', v_id::text);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_excluir_usuario(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'auth', 'extensions'
AS $function$
declare u usuarios%rowtype; v_aut text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  v_aut := _exige_admin(p->>'senhaAdminConfirmacao');
  if v_aut is null then return _falha('Senha de administrador incorreta.'); end if;
  select * into u from usuarios where lower(login) = lower(coalesce(p->>'loginAlvo', ''));
  if not found then return _falha('Usuário não encontrado.'); end if;
  if u.nivel = 'Desenvolvedor' then
    return _falha('O acesso de Desenvolvedor não pode ser excluído. Nada foi alterado.');
  end if;
  if u.nivel = 'Admin' and not exists (select 1 from usuarios where nivel = 'Admin' and ativo and id <> u.id) then
    return _falha('Não é possível excluir o último administrador.');
  end if;
  perform _auditar('Usuário excluído', u.login);
  delete from auth.users where id = u.id;
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_fechar_caixa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  s caixa_sessoes%rowtype; v_login text; v_chave text; v_seg int; v_contado numeric; v_fim timestamptz := now();
  v_mesas text[]; v_pend text[]; v_nrec text[]; v_msgs text[] := '{}';
  v_total numeric; v_pendente numeric; v_qv int; v_desp numeric; v_qd int; v_sang numeric; v_qs int;
  v_forma jsonb; v_dinheiro numeric; v_saldo numeric; v_dif numeric; v_nomes_dinheiro text[];
  v_feitos jsonb := '[]'::jsonb; v_falhas jsonb := '[]'::jsonb; ed record; c record; fid uuid; v_req_auto text;
  v_acertos numeric := 0;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  select login into v_login from usuarios where id = auth.uid();
  v_chave := 'falhas_senha_propria_' || lower(coalesce(v_login, ''));
  if _excedeu(v_chave, 5) then
    select greatest(1, extract(epoch from (bloqueado_ate - now()))::int) into v_seg from tentativas where chave = v_chave;
    return jsonb_build_object('ok', false, 'bloqueioSegundos', v_seg, 'message', 'Muitas tentativas erradas. Aguarde ' || ceil(v_seg / 60.0)::int || ' min e tente de novo.');
  end if;
  if coalesce(p->>'senhaConfirmacao', '') = '' or not _senha_confere(auth.uid(), p->>'senhaConfirmacao') then
    perform _registrar_falha(v_chave);
    return _falha('Senha incorreta. O caixa não foi fechado.');
  end if;
  perform _limpar_falhas(v_chave);
  if nullif(btrim(coalesce(p->>'valorContado', '')), '') is null or _num(p->>'valorContado', -1) < 0 then
    return _falha('Informe quanto dinheiro há na gaveta (pode ser zero).');
  end if;
  v_contado := round(_num(p->>'valorContado'), 2);
  select * into s from caixa_sessoes where id = _uuid(p->>'id') for update;
  if not found then return _falha('Sessão de caixa não encontrada.'); end if;
  if s.status = 'Fechado' then return _falha('Este caixa já foi fechado.'); end if;

  -- trava: mesas abertas, pedidos pendentes ou não recebidos
  select coalesce(array_agg('Mesa ' || numero order by numero), '{}') into v_mesas from mesas where status in ('Ocupada','Aguardando fechamento');
  select coalesce(array_agg('#' || numero_pedido || case when btrim(coalesce(cliente_nome, '')) <> '' then ' ' || split_part(btrim(cliente_nome), ' ', 1) else '' end || ' (' || status_pedido || ')' order by numero_pedido), '{}')
    into v_pend from vendas where status = 'Confirmada' and status_pedido is not null and status_pedido not in ('Entregue','Retirada','Servida');
  select coalesce(array_agg('#' || numero_pedido || case when btrim(coalesce(cliente_nome, '')) <> '' then ' ' || split_part(btrim(cliente_nome), ' ', 1) else '' end order by numero_pedido), '{}')
    into v_nrec from vendas where status = 'Confirmada' and status_pagamento = 'A Receber';
  if coalesce(array_length(v_mesas, 1), 0) + coalesce(array_length(v_pend, 1), 0) + coalesce(array_length(v_nrec, 1), 0) > 0 then
    if array_length(v_mesas, 1) > 0 then v_msgs := v_msgs || ('Mesas abertas: ' || _lista_curta(v_mesas)); end if;
    if array_length(v_pend, 1) > 0 then v_msgs := v_msgs || ('Pedidos pendentes: ' || _lista_curta(v_pend)); end if;
    if array_length(v_nrec, 1) > 0 then v_msgs := v_msgs || ('Pedidos não recebidos: ' || _lista_curta(v_nrec)); end if;
    return jsonb_build_object('ok', false, 'pendencias', true, 'mesas', to_jsonb(v_mesas), 'pedidos', to_jsonb(v_pend), 'naoRecebidos', to_jsonb(v_nrec),
      'message', 'O caixa não pode ser fechado enquanto houver pendências. ' || array_to_string(v_msgs, ' | ') || '. Resolva (finalize, receba ou cancele) e tente de novo.');
  end if;

  select coalesce(sum(valor_total), 0), coalesce(sum(valor_total) filter (where status_pagamento = 'A Receber'), 0), count(*)
    into v_total, v_pendente, v_qv from vendas where status = 'Confirmada' and data_hora >= s.abertura and data_hora <= v_fim;
  select coalesce(sum(valor), 0), count(*) into v_desp, v_qd from despesas
    where status = 'Paga' and saiu_do_caixa and data_hora >= s.abertura and data_hora <= v_fim;
  select coalesce(sum(valor), 0), count(*) into v_sang, v_qs from sangrias where data_hora >= s.abertura and data_hora <= v_fim;
  -- o dinheiro conta na sessão em que ENTROU (data do recebimento), não em que o pedido foi criado
  select coalesce(jsonb_object_agg(forma, tot), '{}'::jsonb) into v_forma from (
    select pv.forma_pagamento as forma, sum(pv.valor) as tot
    from pagamentos_venda pv join vendas v on v.id = pv.venda_id
    where v.status = 'Confirmada' and v.status_pagamento <> 'A Receber'
      and coalesce(v.recebido_em, v.data_hora) >= s.abertura and coalesce(v.recebido_em, v.data_hora) <= v_fim
    group by pv.forma_pagamento) t;
  select coalesce(array_agg(nome), '{}') into v_nomes_dinheiro from formas_pagamento where permite_troco;
  if coalesce(array_length(v_nomes_dinheiro, 1), 0) = 0 then v_nomes_dinheiro := array['Dinheiro']; end if;
  select coalesce(sum((value)::numeric), 0) into v_dinheiro from jsonb_each_text(v_forma) where key = any(v_nomes_dinheiro);
  v_saldo := s.fundo_caixa + v_dinheiro - v_desp - v_sang;
  v_dif := round(v_contado - v_saldo, 2);

  update caixa_sessoes set fechamento = v_fim, total_vendas = v_total, total_despesas = v_desp, saldo_final = v_saldo, status = 'Fechado',
         usuario_fechamento = auth.uid(), valor_contado = v_contado, diferenca = v_dif where id = s.id;
  perform _auditar('Caixa fechado', 'Esperado: R$ ' || _dinheiro(v_saldo) || ' | Contado: R$ ' || _dinheiro(v_contado) || ' | Diferença: R$ ' || _dinheiro(v_dif));
  if abs(v_dif) >= 0.01 then
    perform _auditar('Diferença de caixa', case when v_dif > 0 then 'SOBRA' else 'FALTA' end || ' de R$ ' || _dinheiro(abs(v_dif)) || ' no fechamento');
  end if;

  -- fechamento automático das entregas concluídas na sessão (um fechamento por entregador e por dia)
  for ed in
    select distinct v.entregador_id, u.login, (v.concluida_em at time zone 'America/Sao_Paulo')::date as dia
      from vendas v join usuarios u on u.id = v.entregador_id
     where v.status = 'Confirmada' and v.tipo = 'Entrega' and v.status_pedido::text = 'Entregue'
       and v.entregador_id is not null and v.fechamento_entrega_id is null
       and v.concluida_em >= s.abertura and v.concluida_em <= v_fim
     order by 3, 2
  loop
    begin
      fid := null;
      perform pg_advisory_xact_lock(hashtext(ed.entregador_id::text || ed.dia::text));
      select * into c from _calc_fechamento_entrega(ed.login, ed.dia);
      if c.qtd > 0 then
        v_req_auto := 'auto-' || s.id::text || '-' || lower(ed.login) || '-' || ed.dia::text;
        insert into fechamentos_entrega (data_ref, entregador_id, qtd_entregas, total_taxas, ajuda_diaria, total_devido, valor_pago, diferenca, fechado_por, observacao, requisicao_id)
        values (ed.dia, ed.entregador_id, c.qtd, c.total_taxas, c.ajuda, c.total, c.total, 0, auth.uid(), 'Fechamento automático ao fechar o caixa', v_req_auto)
        on conflict (requisicao_id) do nothing returning id into fid;
        if fid is not null then
          v_acertos := v_acertos + c.total;
          insert into entregas_fechadas (fechamento_id, venda_id, data_ref, entregador_id, taxa)
          select fid, id, ed.dia, ed.entregador_id, taxa_entrega from vendas where id = any(c.ids);
          update vendas set fechamento_entrega_id = fid where id = any(c.ids);
          perform _auditar('Fechamento de entregas (automático)', ed.login || ' | ' || ed.dia || ' | ' || c.qtd || ' entregas | devido e pago R$ ' || _dinheiro(c.total));
          v_feitos := v_feitos || to_jsonb(ed.login || ' (' || to_char(ed.dia, 'DD/MM/YYYY') || '): R$ ' || _dinheiro(c.total));
        end if;
      end if;
    exception when others then
      v_falhas := v_falhas || to_jsonb(ed.login || ' (' || to_char(ed.dia, 'DD/MM/YYYY') || '): ' || sqlerrm);
    end;
  end loop;
  if jsonb_array_length(v_falhas) > 0 then
    perform _auditar('Falha no fechamento automático de entregas', v_falhas::text);
  end if;

  return jsonb_build_object('ok', true, 'entregasAuto', jsonb_build_object('feitos', v_feitos, 'falhas', v_falhas),
    'relatorio', jsonb_build_object(
      'abertura', to_char(s.abertura at time zone 'America/Sao_Paulo', 'DD/MM/YYYY HH24:MI'),
      'fechamento', to_char(v_fim at time zone 'America/Sao_Paulo', 'DD/MM/YYYY HH24:MI'),
      'fundoCaixa', s.fundo_caixa, 'totalVendas', v_total, 'totalVendasDinheiro', v_dinheiro, 'porForma', v_forma,
      'totalPendente', v_pendente, 'totalDespesas', v_desp, 'totalSangrias', v_sang, 'saldoFinal', v_saldo,
      'acertoEntregadores', v_acertos, 'saldoAposAcertos', v_saldo - v_acertos,
      'valorContado', v_contado, 'diferenca', v_dif, 'quantidadeVendas', v_qv, 'quantidadeDespesas', v_qd, 'quantidadeSangrias', v_qs,
      'reconciliadasNaSessao', jsonb_build_object('quantidade', 0, 'valor', 0), 'pendentesContingencia', 0));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_fechar_conta_mesa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare m mesas; eu uuid := auth.uid(); nv text; ids uuid[]; total numeric; soma numeric; pg record; resumo text; v record; parte numeric; forma formas_pagamento;
begin
  if not tem_nivel('Admin','Operador','Garçom') then return _negado(); end if;
  select * into m from mesas where id = _uuid(p->>'mesaId') for update;
  if not found then return _falha('Mesa não encontrada.'); end if;
  select nivel::text into nv from usuarios where id = eu;
  if nv = 'Garçom' and m.garcom_responsavel_id is not null and m.garcom_responsavel_id <> eu then return _falha('Esta mesa está sob responsabilidade de outro garçom.'); end if;
  if exists (select 1 from jsonb_array_elements(coalesce(p->'pagamentos','[]'::jsonb)) e where btrim(coalesce(e->>'forma','')) = 'A Receber (Mesa)') then return _falha('Forma de pagamento inválida para esta operação.'); end if;
  select array_agg(id), coalesce(round(sum(valor_total), 2), 0) into ids, total from vendas where mesa_id = m.id and status = 'Confirmada' and status_pagamento = 'A Receber';
  if ids is null then
    update mesas set status = 'Livre', garcom_responsavel_id = null, chamado_tipo = null, chamado_em = null where id = m.id;
    perform _auditar('Status de mesa alterado', 'Mesa ' || m.numero || ' → Livre');
    return jsonb_build_object('ok', true, 'message', 'Essa mesa não tinha conta pendente. Liberada.');
  end if;
  if not exists (select 1 from caixa_sessoes where status = 'Aberto') then return _falha('Abra o caixa antes de fechar a conta da mesa — o valor recebido precisa entrar no fechamento do caixa.'); end if;
  if jsonb_typeof(p->'pagamentos') <> 'array' or jsonb_array_length(p->'pagamentos') = 0 then return _falha('Informe ao menos uma forma de pagamento.'); end if;
  for pg in select value as e from jsonb_array_elements(p->'pagamentos') loop
    if btrim(coalesce(pg.e->>'forma','')) = '' then return _falha('Forma de pagamento não informada.'); end if;
    if not (_num(pg.e->>'valor', 0) > 0) then return _falha('Cada pagamento deve ter um valor maior que zero.'); end if;
    select * into forma from formas_pagamento where lower(nome) = lower(btrim(pg.e->>'forma')) limit 1;
    if not found then return _falha('Forma de pagamento não cadastrada: ' || btrim(pg.e->>'forma')); end if;
    if not forma.ativa then return _falha('A forma de pagamento está inativa: ' || btrim(pg.e->>'forma')); end if;
  end loop;
  select round(coalesce(sum(_num(e->>'valor')), 0), 2) into soma from jsonb_array_elements(p->'pagamentos') e;
  if abs(soma - total) > 0.02 then return _falha('A soma dos pagamentos (R$ ' || _dinheiro(soma) || ') não bate com a conta da mesa (R$ ' || _dinheiro(total) || ').'); end if;
  select string_agg(btrim(e->>'forma'), ' + ') into resumo from jsonb_array_elements(p->'pagamentos') e;
  for v in select id, valor_total, telefone_cliente, cliente_nome from vendas where id = any(ids) loop
    update vendas set forma_pagamento = resumo, status_pagamento = 'Pago', recebido_em = now() where id = v.id;
    delete from pagamentos_venda where venda_id = v.id and forma_pagamento = 'A Receber (Mesa)';
    for pg in select value as e from jsonb_array_elements(p->'pagamentos') loop
      parte := round(_num(pg.e->>'valor') * (case when total > 0 then v.valor_total / total else 1.0 / array_length(ids, 1) end), 2);
      insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada) values (v.id, btrim(pg.e->>'forma'), parte, coalesce((select round(parte * f.taxa_percentual / 100 + f.taxa_fixa, 2) from formas_pagamento f where lower(f.nome) = lower(btrim(pg.e->>'forma'))), 0));
    end loop;
  end loop;
  perform _carimbar_fidelidade(t.tel, t.nome) from (select distinct on (regexp_replace(telefone_cliente, '\D', '', 'g')) telefone_cliente as tel, cliente_nome as nome from vendas where id = any(ids) and nullif(telefone_cliente,'') is not null) t;
  update mesas set status = 'Livre', garcom_responsavel_id = null, chamado_tipo = null, chamado_em = null where id = m.id;
  perform _auditar('Conta de mesa fechada', 'Mesa ' || m.numero || ': R$ ' || _dinheiro(total) || ' | ' || resumo || ' | recebido por ' || coalesce(_login_de(eu), '?') || ' (' || nv || ')');
  return jsonb_build_object('ok', true, 'message', 'Conta da mesa ' || m.numero || ' fechada — R$ ' || _dinheiro(total) || '.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_fechar_periodo_entregador(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare u usuarios; c record; pago numeric; dif numeric; fid uuid; d date; v_saldo numeric;
        req text := btrim(coalesce(p->>'requisicaoId','')); obs text := btrim(coalesce(p->>'observacao',''));
        forma text := btrim(coalesce(p->>'forma',''));
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if btrim(coalesce(p->>'entregador','')) = '' or coalesce(p->>'dataRef','') !~ '^\d{4}-\d{2}-\d{2}$' then return _falha('Informe o entregador e a data.'); end if;
  if req = '' then return _falha('Requisição sem identificador.'); end if;
  if exists (select 1 from fechamentos_entrega where requisicao_id = req) then
    return jsonb_build_object('ok', true, 'duplicado', true, 'message', 'Este fechamento já havia sido registrado.'); end if;
  pago := _num(p->>'valorPago', -1);
  if pago < 0 then return _falha('Informe o valor pago ao entregador.'); end if;
  if forma not in ('Dinheiro','Pix') then return _falha('Escolha a forma de pagamento do entregador: Dinheiro ou Pix.'); end if;
  select * into u from usuarios where lower(login) = lower(p->>'entregador') and nivel::text = 'Entregador';
  if not found then return _falha('Entregador não encontrado.'); end if;
  d := (p->>'dataRef')::date;
  perform pg_advisory_xact_lock(hashtext(u.id::text || d::text));
  select * into c from _calc_fechamento_entrega(u.login, d);
  if c.qtd = 0 then return _falha('Não há entregas concluídas em aberto para esse entregador nessa data.'); end if;
  pago := round(pago, 2); dif := round(pago - c.total, 2);
  if dif <> 0 and obs = '' then return _falha('O valor pago é diferente do devido (R$ ' || _dinheiro(c.total) || '). Informe o motivo da diferença.'); end if;
  if forma = 'Dinheiro' and pago > 0 then
    v_saldo := _saldo_gaveta_aberta();
    if v_saldo is not null and pago > v_saldo then
      return _falha('O dinheiro na gaveta (R$ ' || _dinheiro(v_saldo) || ') não cobre o pagamento de R$ ' || _dinheiro(pago) || '. Escolha Pix ou ajuste o valor. Nada foi registrado.');
    end if;
  end if;
  insert into fechamentos_entrega (data_ref, entregador_id, qtd_entregas, total_taxas, ajuda_diaria, total_devido, valor_pago, diferenca, fechado_por, observacao, requisicao_id, forma_pagamento)
  values (d, u.id, c.qtd, c.total_taxas, c.ajuda, c.total, pago, dif, auth.uid(), nullif(obs,''), req, forma) returning id into fid;
  insert into entregas_fechadas (fechamento_id, venda_id, data_ref, entregador_id, taxa)
  select fid, id, d, u.id, taxa_entrega from vendas where id = any(c.ids);
  update vendas set fechamento_entrega_id = fid where id = any(c.ids);
  perform _lancar_pagamento_entregador(fid, u.id, d, c.total_taxas, pago, forma, exists (select 1 from caixa_sessoes where status = 'Aberto'));
  perform _auditar('Fechamento de entregas', u.login || ' | ' || d || ' | ' || c.qtd || ' entregas | devido R$ ' || _dinheiro(c.total) || ' | pago R$ ' || _dinheiro(pago) || ' em ' || forma || ' | dif R$ ' || _dinheiro(dif) || case when obs <> '' then ' | ' || obs else '' end);
  return jsonb_build_object('ok', true, 'message', 'Fechamento registrado: devido R$ ' || _dinheiro(c.total) || ', pago R$ ' || _dinheiro(pago) || ' em ' || forma || '.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_garantir_despesas_do_mes(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_comp text := _competencia_atual(); v_n int := 0;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if coalesce((select valor #>> '{}' from sistema where chave = 'ULTIMA_GERACAO_DESPESAS'), '') <> v_comp then
    v_n := _gerar_despesas_recorrentes(v_comp);
    perform _cfg_gravar('ULTIMA_GERACAO_DESPESAS', to_jsonb(v_comp));
  end if;
  return jsonb_build_object('ok', true, 'geradas', v_n);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_gerar_despesas_mes(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_n int; v_comp text := _competencia_atual();
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  v_n := _gerar_despesas_recorrentes(v_comp);
  perform _cfg_gravar('ULTIMA_GERACAO_DESPESAS', to_jsonb(v_comp));
  return jsonb_build_object('ok', true, 'message', case when v_n > 0 then v_n || ' conta(s) gerada(s) para este mês.' else 'Nenhuma conta nova: este mês já está gerado.' end);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_gerar_novo_codigo_mesa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare m mesas;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into m from mesas where id = _uuid(p->>'mesaId');
  if not found then return _falha('Mesa não encontrada.'); end if;
  insert into mesas_codigos (mesa_id, codigo) values (m.id, substr(replace(gen_random_uuid()::text, '-', ''), 1, 12))
    on conflict (mesa_id) do update set codigo = excluded.codigo, gerado_em = now();
  perform _auditar('Código QR da mesa renovado', 'Mesa ' || m.numero || ' — o QR antigo deixou de funcionar');
  return jsonb_build_object('ok', true, 'message', 'Novo código gerado. Imprima o QR da mesa ' || m.numero || ' de novo.', 'mesas', _lista_qr_mesas());
end $function$
;

CREATE OR REPLACE FUNCTION public.api_get_mesa_publica(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_q jsonb := _mesa_qr(p->>'mesa', p->>'codigo'); m mesas; v_ped jsonb; v_total numeric;
begin
  if v_q->>'ok' <> 'true' then return v_q; end if;
  select * into m from mesas where id = (v_q->>'mesaId')::uuid;
  select coalesce(round(sum(valor_total), 2), 0) into v_total from vendas where mesa_id = m.id and status = 'Confirmada' and status_pagamento = 'A Receber';
  select coalesce(jsonb_agg(t.j order by t.dh), '[]'::jsonb) into v_ped from (
    select v.data_hora as dh, jsonb_build_object('id', v.id, 'numero', v.numero_pedido,
      'hora', to_char(v.data_hora at time zone 'America/Sao_Paulo', 'HH24:MI'), 'valor', v.valor_total, 'cancelado', v.status = 'Cancelada',
      'status', case when v.status = 'Cancelada' then 'Cancelado' else case v.status_pedido::text when 'Recebido' then 'Aguardando confirmação' when 'Em preparo' then 'Em preparo'
                      when 'Pronta' then 'Pronto' when 'Servida' then 'Servido' when 'Suspenso' then 'Em preparo' else coalesce(v.status_pedido::text, '') end end,
      'podeCancelar', (v.status = 'Confirmada' and v.origem = 'Cardápio' and v.status_pedido = 'Recebido'),
      'itens', (select coalesce(jsonb_agg(jsonb_build_object('quantidade', i.quantidade, 'descricao', i.descricao) order by i.ctid), '[]'::jsonb) from itens_venda i where i.venda_id = v.id)) as j
    from vendas v
    where v.mesa_id = m.id and ((v.status = 'Confirmada' and v.status_pagamento = 'A Receber') or (v.status = 'Cancelada' and v.origem = 'Cardápio' and v.data_hora >= now() - interval '3 hours'))
    order by v.data_hora desc limit 12) t;
  return jsonb_build_object('ok', true, 'mesa', jsonb_build_object('numero', m.numero, 'status', m.status::text, 'chamando', m.chamado_em is not null),
    'pedidos', v_ped, 'total', v_total, 'caixaAberto', exists (select 1 from caixa_sessoes where status = 'Aberto'));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_get_qr_mesas(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  insert into mesas_codigos (mesa_id, codigo) select m.id, substr(replace(gen_random_uuid()::text, '-', ''), 1, 12) from mesas m
    where not exists (select 1 from mesas_codigos c where c.mesa_id = m.id);
  return jsonb_build_object('ok', true, 'mesas', _lista_qr_mesas());
end $function$
;

CREATE OR REPLACE FUNCTION public.api_get_status_pedido_publico(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_alvo text := lower(btrim(coalesce(p->>'codigo', ''))); v vendas%rowtype; v_ip text := _ip_cliente(); v_itens jsonb; v_resta int; v_cancelavel boolean;
begin
  if v_alvo !~ '^[0-9a-f-]{8,36}$' then return _falha('Código do pedido inválido.'); end if;
  if _excedeu('statuspub_ip_' || v_ip, 40) or _excedeu('statuspub_falhas', 200) then
    return jsonb_build_object('ok', false, 'message', 'Muitas consultas seguidas. Aguarde alguns minutos.', 'limite', true);
  end if;
  select * into v from vendas where right(id::text, 8) = right(v_alvo, 8) and right(id::text, length(v_alvo)) = v_alvo order by data_hora desc limit 1;
  if not found then
    perform _registrar_falha('statuspub_ip_' || v_ip, 600); perform _registrar_falha('statuspub_falhas', 600);
    return _falha('Pedido não encontrado. Confira o código.');
  end if;
  select coalesce(jsonb_agg(i.quantidade || 'x ' || coalesce(i.descricao, '') order by i.ctid), '[]'::jsonb) into v_itens from itens_venda i where i.venda_id = v.id;
  v_cancelavel := v.origem = 'Cardápio' and v.mesa_id is null and v.status = 'Confirmada' and v.status_pedido = 'Recebido' and v.status_pagamento = 'A Receber';
  v_resta := greatest(0, ceil(180 - extract(epoch from (now() - v.data_hora)))::int);
  return jsonb_build_object('ok', true, 'status', v.status::text, 'statusPedido', v.status_pedido::text, 'tipoEntrega', v.tipo::text,
    'motivoCancelamento', coalesce(v.motivo_cancelamento, ''), 'clienteNome', split_part(btrim(coalesce(v.cliente_nome, '')), ' ', 1),
    'itens', v_itens, 'valorTotal', v.valor_total, 'data', to_char(v.data_hora at time zone 'America/Sao_Paulo', 'DD/MM/YYYY HH24:MI'),
    'statusPagamento', v.status_pagamento::text, 'numero', v.numero_pedido,
    'podeCancelar', (v_cancelavel and v_resta > 0), 'segundosParaCancelar', case when v_cancelavel then v_resta else 0 end);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_indicar_novo_cliente(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_ti text := btrim(coalesce(p->>'telIndicador', '')); v_ni text := btrim(coalesce(p->>'nomeIndicador', ''));
        v_nome text := btrim(coalesce(p->>'nome', '')); v_tel text := btrim(coalesce(p->>'telefone', ''));
        v_r jsonb; v_ja indicacoes%rowtype;
begin
  if not tem_nivel('Admin','Operador','Garçom') then return _negado(); end if;
  if v_nome = '' or v_tel = '' then return _falha('Nome e telefone são obrigatórios.'); end if;
  if v_ti = '' or v_ni = '' then return _falha('Preencha todos os campos.'); end if;
  if _so_digitos(v_ti) = _so_digitos(v_tel) then return _falha('Quem indicou e quem foi indicado não podem ser a mesma pessoa.'); end if;
  v_r := api_salvar_cliente((p - 'id') || jsonb_build_object('nome', v_nome, 'telefone', v_tel));
  if coalesce(v_r->>'ok', '') <> 'true' then return v_r; end if;
  select * into v_ja from indicacoes where _so_digitos(telefone_indicado) = _so_digitos(v_tel) limit 1;
  if v_ja.id is not null then
    return jsonb_build_object('ok', true, 'message', 'Cliente cadastrado, mas: ' || v_nome || ' já foi indicado antes (por ' || coalesce(v_ja.nome_indicador, '') || ').');
  end if;
  insert into indicacoes (indicador_id, indicado_id, nome_indicador, telefone_indicador, nome_indicado, telefone_indicado, status, observacoes)
  values (_upsert_cliente(v_ti, v_ni), _upsert_cliente(v_tel, v_nome), v_ni, v_ti, v_nome, v_tel, 'Pendente', '');
  perform _auditar('Indicação registrada', v_ni || ' indicou ' || v_nome, v_tel);
  return jsonb_build_object('ok', true, 'message', 'Cliente cadastrado e indicação registrada! ' || v_ni || ' ganhará 1 batata pequena na próxima compra.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_iniciar_preparo_pedido(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare t record; v vendas; v_eu uuid := auth.uid(); v_nivel text;
begin
  if not tem_nivel('Admin','Operador','Cozinha','Garçom') then return _negado(); end if;
  select * into t from _pedido_trava(p); v := t.v; if t.erro is not null then return t.erro; end if;
  if v.status_pedido::text not in ('Recebido','Em preparo') then return _conflito('Este pedido já está "' || coalesce(v.status_pedido::text,'') || '". A tela foi atualizada.'); end if;
  v_nivel := auth_nivel()::text;
  if v_nivel = 'Garçom' and not (v.registrado_por = v_eu or exists (select 1 from mesas m where m.id = v.mesa_id and m.garcom_responsavel_id = v_eu)) then
    return _falha('Este pedido não está no seu escopo operacional.');
  end if;
  if v.status_pedido::text = 'Recebido' then perform _auditar('Pedido aceito', '#' || v.numero_pedido || ' — aceito e em preparo', v.telefone_cliente); end if;
  update vendas set status_pedido = 'Em preparo', inicio_preparo_em = coalesce(inicio_preparo_em, now()) where id = v.id;
  perform _auditar('Preparo iniciado', '#' || v.numero_pedido);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_iniciar_venda(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_nivel nivel_acesso := auth_nivel(); v_eu uuid := auth.uid(); v_login text;
  v_itens jsonb := p->'itens'; v_pags jsonb := p->'pagamentos'; v_tipo_in text := p->>'tipoEntrega';
  v_mesa_id uuid := _uuid(p->>'mesaId'); v_mesa mesas%rowtype; v_mesa_status text; v_mesa_garcom uuid;
  v_origem text := coalesce(nullif(p->>'origem', ''), 'Balcão'); v_status_pag text := p->>'statusPagamento';
  v_nome text := btrim(coalesce(p->>'clienteNome', '')); v_tel text := btrim(coalesce(p->>'clienteTelefone', ''));
  v_de jsonb := case when jsonb_typeof(p->'dadosEntrega') = 'object' then p->'dadosEntrega' else '{}'::jsonb end;
  v_desc jsonb := case when jsonb_typeof(p->'desconto') = 'object' then p->'desconto' else null end;
  v_req text := nullif(left(coalesce(p->>'requisicaoId', ''), 80), ''); v_ja uuid;
  it record; pg record; v_exige boolean; v_qtd numeric; v_v numeric; v_c numeric; v_nome_item text; v_extra numeric; v_n_ad int; v_n_ok int;
  v_orig numeric := 0; v_custo numeric := 0; v_total_item numeric; v_desc_val numeric := 0; v_desc_det text := ''; v_sol numeric; v_aut text;
  v_tipo venda_tipo; v_taxa numeric := 0; v_total numeric; v_soma numeric := 0; v_erro text; v_venda uuid := gen_random_uuid();
  v_pad numeric; v_t numeric; v_forma_row formas_pagamento%rowtype; v_resumo text; v_origem_final origem_venda; v_status_pedido_ini status_pedido;
  v_status_pag_final status_pagamento; v_numero int; v_msg_extra text := ''; v_caixa uuid; v_bloqueia boolean; r record;
begin
  if v_nivel is null or v_nivel not in ('Admin','Operador','Garçom') then return _negado(); end if;
  if jsonb_typeof(v_itens) <> 'array' or jsonb_array_length(v_itens) = 0 then return _falha('Adicione ao menos um item à venda.'); end if;
  if jsonb_typeof(v_pags) <> 'array' or jsonb_array_length(v_pags) = 0 then return _falha('Informe ao menos uma forma de pagamento.'); end if;
  if v_tipo_in = 'Mesa' and v_mesa_id is null then return _falha('Informe a mesa.'); end if;
  if v_origem like 'Contingência%' then return _falha('Vendas da contingência entram pelo botão "Trazer vendas pendentes da contingência" (Administrador).'); end if;
  if coalesce(p->'promocaoValidada'->>'ok', '') = 'true' then return _falha('Cupom não é aceito no Caixa. Use o desconto por porcentagem.'); end if;
  select login into v_login from usuarios where id = v_eu;
  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;
  if v_caixa is null then return _falha(case when v_nivel = 'Garçom' then 'O caixa está fechado — peça ao caixa para abrir.' else 'Abra o caixa antes de registrar uma venda.' end); end if;

  -- garçom: só mesa/entrega/retirada, sem desconto, sem receber pagamento; vale no servidor, não só na tela
  if v_nivel = 'Garçom' then
    if v_tipo_in not in ('Mesa','Entrega','Retirada') then return _falha('O garçom só lança pedidos de mesa, entrega ou retirada.'); end if;
    if v_tipo_in <> 'Mesa' and v_tel = '' then return _falha('Informe o cliente (nome e telefone) para pedidos por telefone.'); end if;
    if v_tipo_in = 'Mesa' then
      select * into v_mesa from mesas where id = v_mesa_id for update;
      if not found then return _falha('Mesa não encontrada.'); end if;
      if v_mesa.status not in ('Livre','Ocupada') then return _falha('A mesa ' || v_mesa.numero || ' está "' || v_mesa.status || '" — não aceita novos itens.'); end if;
      if v_mesa.status = 'Ocupada' and v_mesa.garcom_responsavel_id is not null and v_mesa.garcom_responsavel_id <> v_eu then
        return _falha('Esta mesa está sob responsabilidade de outro garçom.');
      end if;
    end if;
    v_origem := 'Garçom'; v_desc := null; v_status_pag := 'A Receber';
    if v_tipo_in = 'Mesa' then
      v_pags := jsonb_build_array(jsonb_build_object('forma', 'A Receber (Mesa)', 'valor', _num(v_pags->0->>'valor')));
    else
      v_pags := jsonb_build_array(jsonb_build_object('forma', btrim(coalesce(v_pags->0->>'forma', '')), 'valor', _num(v_pags->0->>'valor')));
    end if;
  elsif v_tipo_in = 'Mesa' then
    select * into v_mesa from mesas where id = v_mesa_id for update;
    if not found then return _falha('Mesa não encontrada.'); end if;
  end if;

  if v_tipo_in = 'Mesa' then v_mesa_status := v_mesa.status::text; v_mesa_garcom := v_mesa.garcom_responsavel_id; end if;

  -- idempotência: a mesma requisição (duplo toque, nova tentativa) nunca gera duas vendas
  if v_req is not null then
    perform pg_advisory_xact_lock(hashtext('venda:' || v_req));
    select id into v_ja from vendas where requisicao_id = v_req;
    if found then return jsonb_build_object('ok', true, 'duplicado', true, 'id', v_ja, 'message', 'Venda já registrada — requisição repetida ignorada.'); end if;
  end if;

  -- itens: quantidade, preço, custo e (para quem não é Admin) preço conferido com o cadastro
  v_exige := not (v_nivel = 'Admin' and v_origem <> 'Cardápio');
  for it in select value as e from jsonb_array_elements(v_itens) loop
    v_nome_item := coalesce(nullif(it.e->>'descricao', ''), 'item');
    v_qtd := _num(it.e->>'quantidade'); v_v := _num(it.e->>'valorUnitario', -1); v_c := _num(it.e->>'custoUnitario');
    if not (v_qtd > 0) or v_qtd > 200 or v_qtd <> floor(v_qtd) then return _falha('Quantidade inválida em "' || v_nome_item || '".'); end if;
    if v_v < 0 then return _falha('Preço inválido em "' || v_nome_item || '".'); end if;
    if v_c < 0 then return _falha('Custo inválido em "' || v_nome_item || '".'); end if;
    if v_exige then
      if (_uuid(it.e->>'produtoId') is null and _uuid(it.e->>'comboId') is null) or (_uuid(it.e->>'produtoId') is not null and _uuid(it.e->>'comboId') is not null) then
        return _falha('"' || v_nome_item || '" não é um item cadastrado de forma válida.');
      end if;
      select count(*), coalesce(sum(a.preco) filter (where a.ativo), 0), count(a.id) filter (where a.ativo and ((_uuid(it.e->>'produtoId') is not null and exists (select 1 from produto_adicionais pa where pa.produto_id = _uuid(it.e->>'produtoId') and pa.adicional_id = a.id)) or (_uuid(it.e->>'comboId') is not null and exists (select 1 from combo_itens ci join produto_adicionais pa on pa.produto_id = ci.produto_id where ci.combo_id = _uuid(it.e->>'comboId') and pa.adicional_id = a.id))))
        into v_n_ad, v_extra, v_n_ok
        from jsonb_array_elements_text(case when jsonb_typeof(it.e->'adicionaisIds') = 'array' then it.e->'adicionaisIds' else '[]'::jsonb end) x
        left join adicionais a on a.id = _uuid(x);
      if v_n_ad <> v_n_ok then return _falha('O adicional selecionado para "' || v_nome_item || '" não está disponível.'); end if;
      if _uuid(it.e->>'produtoId') is not null then
        if not exists (select 1 from produto_precos pp where pp.produto_id = _uuid(it.e->>'produtoId') and abs(pp.preco + v_extra - v_v) <= 0.011) then
          perform _auditar('Preço divergente bloqueado', v_nome_item || ' enviado a R$ ' || _dinheiro(v_v));
          return _falha('O preço de "' || v_nome_item || '" não confere com o cadastro.');
        end if;
        if not exists (select 1 from produto_precos pp where pp.produto_id = _uuid(it.e->>'produtoId') and abs(pp.preco + v_extra - v_v) <= 0.011 and abs(pp.custo - v_c) <= 0.011) then
          perform _auditar('Custo divergente bloqueado', v_nome_item || ' enviado com custo R$ ' || _dinheiro(v_c));
          return _falha('O custo de "' || v_nome_item || '" não confere com o cadastro.');
        end if;
      else
        if not exists (select 1 from combo_precos cp where cp.combo_id = _uuid(it.e->>'comboId') and abs(cp.preco + v_extra - v_v) <= 0.011) then
          perform _auditar('Preço divergente bloqueado', v_nome_item || ' enviado a R$ ' || _dinheiro(v_v));
          return _falha('O preço de "' || v_nome_item || '" não confere com o cadastro.');
        end if;
        if not exists (select 1 from combo_precos cp where cp.combo_id = _uuid(it.e->>'comboId') and abs(cp.preco + v_extra - v_v) <= 0.011 and abs(cp.custo - v_c) <= 0.011) then
          perform _auditar('Custo divergente bloqueado', v_nome_item || ' enviado com custo R$ ' || _dinheiro(v_c));
          return _falha('O custo de "' || v_nome_item || '" não confere com o cadastro.');
        end if;
      end if;
    end if;
    v_total_item := round(v_qtd * v_v, 2);
    v_orig := v_orig + v_total_item; v_custo := v_custo + v_qtd * v_c;
  end loop;
  v_orig := round(v_orig, 2); v_custo := round(v_custo, 2);

  -- estoque (só se a regra "bloquear venda sem estoque" estiver ligada)
  select coalesce((select (valor #>> '{}') = 'true' from sistema where chave = 'BLOQUEAR_ESTOQUE_NEGATIVO'), false) into v_bloqueia;
  if v_bloqueia then
    for r in select c.ingrediente_id, c.qtd, e.ingrediente, e.quantidade from _consumo(v_itens) c join estoque e on e.id = c.ingrediente_id loop
      if r.quantidade + 0.000000001 < r.qtd then
        if v_origem = 'Cardápio' then return _falha('Um dos itens do pedido acabou. Escolha outro item ou fale com o restaurante.'); end if;
        return _falha('Estoque insuficiente de "' || r.ingrediente || '" (tem ' || r.quantidade || ', a venda precisa de ' || round(r.qtd, 3) || ').');
      end if;
    end loop;
  end if;

  -- desconto manual (precisa da senha de Admin quando quem lança não é Admin)
  if v_desc is not null and v_desc->>'valor' is not null then
    v_sol := _num(v_desc->>'valor', -1);
    if v_sol <= 0 then return _falha('Valor de desconto inválido.'); end if;
    v_aut := _exige_admin(p->>'senhaAdminConfirmacao');
    if v_aut is null then return _falha('Senha de administrador incorreta — desconto não aplicado.'); end if;
    if v_desc->>'tipo' = 'percentual' then
      if v_sol > 100 then return _falha('O desconto percentual não pode ser maior que 100%.'); end if;
      v_desc_val := round(v_orig * (v_sol / 100), 2);
      v_desc_det := v_sol || '% (R$ ' || _dinheiro(v_desc_val) || ')';
    elsif coalesce(v_desc->>'tipo', 'fixo') = 'fixo' then
      if v_sol > v_orig then return _falha('O desconto fixo não pode ser maior que o valor da venda.'); end if;
      v_desc_val := round(v_sol, 2);
      v_desc_det := 'R$ ' || _dinheiro(v_desc_val) || ' fixo';
    else
      return _falha('Tipo de desconto inválido.');
    end if;
    if v_desc_val <= 0 or v_desc_val >= v_orig then return _falha('O desconto não pode deixar a venda com valor zero ou negativo.'); end if;
  end if;

  -- tipo, taxa de entrega e total
  v_tipo := case v_tipo_in when 'Entrega' then 'Entrega' when 'Mesa' then 'Mesa' else 'Retirada' end::venda_tipo;
  if v_tipo = 'Entrega' and btrim(coalesce(v_de->>'endereco', '')) = '' then return _falha('Informe o endereço da entrega.'); end if;
  if v_tipo = 'Entrega' and coalesce(v_de->>'freteGratis', '') <> 'true' then
    select coalesce(_num(valor #>> '{}'), 0) into v_pad from sistema where chave = 'TaxaEntregaPadrao';
    v_taxa := coalesce(v_pad, 0);
    if v_nivel in ('Admin','Operador') and nullif(btrim(coalesce(v_de->>'taxa', '')), '') is not null then
      v_t := _num(v_de->>'taxa', -1);
      if v_t >= 0 and v_t <= 500 then v_taxa := round(v_t, 2); end if;
    end if;
  end if;
  v_total := round(v_orig - v_desc_val + v_taxa, 2);
  if v_total < 0.01 then return _falha('O total da venda precisa ser maior que zero.'); end if;
  if v_nivel = 'Garçom' and v_tipo_in <> 'Mesa' then
    v_pags := jsonb_build_array(jsonb_build_object('forma', v_pags->0->>'forma', 'valor', v_total));
  end if;

  -- pagamentos
  if exists (select 1 from jsonb_array_elements(v_pags) e where e->>'forma' = 'A Receber (Mesa)') then
    if jsonb_array_length(v_pags) <> 1 then return _falha('Forma de pagamento inválida para esta operação.'); end if;
    v_status_pag := 'A Receber';
  end if;
  for pg in select value as e from jsonb_array_elements(v_pags) loop
    if btrim(coalesce(pg.e->>'forma', '')) = '' then return _falha('Forma de pagamento não informada.'); end if;
    if not (_num(pg.e->>'valor', 0) > 0) then return _falha('Cada pagamento deve ter um valor maior que zero.'); end if;
    if btrim(pg.e->>'forma') = 'A Receber (Mesa)' then
      if v_nivel not in ('Admin','Operador','Garçom') or v_tipo_in <> 'Mesa' then return _falha('Forma de pagamento inválida para esta operação.'); end if;
      continue;
    end if;
    select * into v_forma_row from formas_pagamento where lower(nome) = lower(btrim(pg.e->>'forma')) limit 1;
    if not found then return _falha('Forma de pagamento não cadastrada: ' || btrim(pg.e->>'forma')); end if;
    if not v_forma_row.ativa then return _falha('A forma de pagamento está inativa: ' || btrim(pg.e->>'forma')); end if;
  end loop;
  select round(coalesce(sum(_num(e->>'valor')), 0), 2) into v_soma from jsonb_array_elements(v_pags) e;
  if abs(v_soma - v_total) > 0.02 then
    return _falha('A soma dos pagamentos (R$ ' || _dinheiro(v_soma) || ') não bate com o total da venda (R$ ' || _dinheiro(v_total) || ').');
  end if;

  -- grava tudo
  v_status_pag_final := case when v_status_pag = 'A Receber' then 'A Receber' else 'Pago' end::status_pagamento;
  v_origem_final := (case when v_origem in ('Cardápio','Garçom') then v_origem else 'Balcão' end)::origem_venda;
  v_status_pedido_ini := (case when v_origem_final = 'Cardápio' then 'Recebido' else 'Em preparo' end)::status_pedido;
  select string_agg(btrim(e->>'forma'), ' + ') into v_resumo from jsonb_array_elements(v_pags) e;

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido,
                      endereco, complemento, referencia, observacoes_entrega, status_pagamento, recebido_em, valor_original, valor_desconto,
                      desconto_detalhe, origem, mesa_id, taxa_entrega, registrado_por, caixa_id, requisicao_id)
  values (v_venda, v_nome, v_tel, v_resumo, v_total, v_custo, 'Confirmada', v_tipo, v_status_pedido_ini,
          case when v_tipo = 'Entrega' then coalesce(v_de->>'endereco', '') else '' end,
          case when v_tipo = 'Entrega' then coalesce(v_de->>'complemento', '') else '' end,
          case when v_tipo = 'Entrega' then coalesce(v_de->>'referencia', '') else '' end,
          coalesce(v_de->>'observacoes', ''), v_status_pag_final, case when v_status_pag_final = 'Pago' then now() else null end,
          v_orig, v_desc_val, v_desc_det, v_origem_final, case when v_tipo = 'Mesa' then v_mesa_id else null end, v_taxa, v_eu, v_caixa, v_req)
  returning numero_pedido into v_numero;

  insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
  select v_venda, _uuid(e->>'produtoId'), _uuid(e->>'comboId'), e->>'descricao', _num(e->>'quantidade', 1)::int,
         _num(e->>'valorUnitario'), _num(e->>'custoUnitario'), round(_num(e->>'quantidade', 1) * _num(e->>'valorUnitario'), 2),
         coalesce((select array_agg(_uuid(x)) filter (where _uuid(x) is not null)
                   from jsonb_array_elements_text(case when jsonb_typeof(e->'adicionaisIds') = 'array' then e->'adicionaisIds' else '[]'::jsonb end) x), '{}')
  from jsonb_array_elements(v_itens) e;

  insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada)
  select v_venda, btrim(e->>'forma'), _num(e->>'valor'),
         coalesce((select round(_num(e->>'valor') * f.taxa_percentual / 100 + f.taxa_fixa, 2) from formas_pagamento f where f.nome = btrim(e->>'forma')), 0)
  from jsonb_array_elements(v_pags) e;

  if v_tipo = 'Mesa' and v_mesa_status = 'Livre' then
    update mesas set status = 'Ocupada', garcom_responsavel_id = case when v_nivel = 'Garçom' then v_eu else garcom_responsavel_id end where id = v_mesa_id;
  elsif v_tipo = 'Mesa' and v_nivel = 'Garçom' and v_mesa_garcom is null then
    update mesas set garcom_responsavel_id = v_eu where id = v_mesa_id;
  end if;

  perform _ajustar_estoque(v_itens, 1, v_venda);

  if v_desc_val > 0 then
    perform _auditar('Desconto aplicado na venda', 'Autorizado por ' || coalesce(nullif(current_setting('app.autorizador', true), ''), v_login) || ' | Valor original: R$ ' || _dinheiro(v_orig)
      || ' → Desconto: ' || v_desc_det || ' → Valor final: R$ ' || _dinheiro(v_total), v_tel);
  end if;
  if v_tel <> '' then
    perform _upsert_cliente(v_tel, v_nome);
    if v_origem_final = 'Balcão' and v_status_pag_final = 'Pago' then
      perform _carimbar_fidelidade(v_tel, v_nome);
      v_msg_extra := ' Marca de fidelidade adicionada para ' || v_nome || '.';
    end if;
  end if;
  perform _auditar('Venda registrada', 'Total R$ ' || _dinheiro(v_total) || ' via ' || v_resumo || ' (' || v_tipo || ', ' || v_status_pag_final || ')', v_tel);

  return jsonb_build_object('ok', true, 'message', 'Venda registrada: R$ ' || _dinheiro(v_total) || '.' || v_msg_extra,
                            'id', v_venda, 'numero', v_numero, 'valorTotal', v_total);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_ler_tabelas(p jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'public'
AS $function$
declare
  v_permitidas text[] := array['formas_pagamento','v_formas_operacional','categorias','produtos','produto_precos','produto_ingredientes','combos','combo_precos','combo_itens','adicionais','produto_adicionais','sistema','usuarios','promocoes','estoque','v_mesas','clientes','movimentacoes_estoque','sangrias','v_vendas','v_itens_venda','pagamentos_venda','v_fidelidade','v_sessao_aberta','caixa_sessoes','fechamentos_entrega','entregas_fechadas','despesas','despesas_recorrentes','ajustes_pos_venda','cupons','eventos','v_indicacoes','feedbacks','v_ocorrencias','v_cardapio_mais_pedidos'];
  v_nome text; v_ord text; v_arr jsonb; v_dados jsonb := '{}'::jsonb;
begin
  if auth_nivel() is null then return _negado(); end if;
  for v_nome in select jsonb_array_elements_text(coalesce(p->'tabelas', '[]'::jsonb)) loop
    if not (v_nome = any(v_permitidas)) then continue; end if;
    v_ord := case v_nome
      when 'v_vendas' then 't.data_hora, t.id'
      when 'v_fidelidade' then 't.cliente_id'
      when 'sistema' then 't.chave'
      when 'despesas' then 't.data_hora, t.id'
      when 'despesas_recorrentes' then 't.criada_em, t.id'
      when 'ajustes_pos_venda' then 't.data_hora, t.id'
      when 'cupons' then 't.criado_em, t.id'
      when 'eventos' then 't.data, t.id'
      when 'v_indicacoes' then 't.data, t.id'
      when 'feedbacks' then 't.data, t.id'
      when 'v_ocorrencias' then 't.numero, t.id'
      when 'v_cardapio_mais_pedidos' then 't.posicao'
      when 'v_formas_operacional' then 't.ordem'
      when 'caixa_sessoes' then 't.abertura desc, t.id'
      when 'fechamentos_entrega' then 't.fechado_em, t.id'
      else 't.id' end;
    execute format('select coalesce(jsonb_agg(to_jsonb(t) order by %s), ''[]''::jsonb) from public.%I t', v_ord, v_nome) into v_arr;
    v_dados := v_dados || jsonb_build_object(v_nome, v_arr);
  end loop;
  return jsonb_build_object('ok', true, 'dados', v_dados);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_listar_sessoes(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'auth', 'extensions'
AS $function$
declare v_atual uuid := nullif(auth.jwt() ->> 'session_id', '')::uuid;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'sessoes', coalesce((
    select jsonb_agg(x order by (x->>'vistoMs')::bigint desc) from (
      select jsonb_build_object(
        'sessaoId', left(replace(s.id::text, '-', ''), 12), 'login', u.login, 'nivel', u.nivel, 'deviceId', '',
        'ua', coalesce(s.user_agent, ''),
        'criadaEm', to_char(s.created_at at time zone 'America/Sao_Paulo', 'DD/MM/YYYY HH24:MI'),
        'vistoEm', to_char(coalesce(s.refreshed_at, s.updated_at, s.created_at) at time zone 'America/Sao_Paulo', 'DD/MM/YYYY HH24:MI'),
        'vistoMs', (extract(epoch from coalesce(s.refreshed_at, s.updated_at, s.created_at)) * 1000)::bigint,
        'atual', s.id = v_atual) as x
      from auth.sessions s join usuarios u on u.id = s.user_id
    ) t), '[]'::jsonb));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_pagar_despesa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare d despesas%rowtype; v_req text := nullif(p->>'requisicaoId', ''); v_r jsonb; v_caixa boolean := (coalesce(p->>'saiuDoCaixa', '') = 'true'); v_valor numeric;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_req is not null then perform pg_advisory_xact_lock(hashtext(v_req)); v_r := _idem_ler(v_req); if v_r is not null then return v_r; end if; end if;
  select * into d from despesas where id = _uuid(p->>'id') for update;
  if not found then return _falha('Despesa não encontrada.'); end if;
  if d.status = 'Cancelada' then return _falha('Essa despesa está cancelada.'); end if;
  if d.status <> 'A pagar' then return _falha('Essa despesa já foi paga.'); end if;
  if v_caixa and not exists (select 1 from caixa_sessoes where status = 'Aberto') then
    return _falha('Abra o caixa para registrar um pagamento que sai do caixa.');
  end if;
  v_valor := d.valor;
  if nullif(btrim(coalesce(p->>'valorPago', '')), '') is not null then
    v_valor := round(_num(p->>'valorPago'), 2);
    if v_valor <= 0 then return _falha('Informe um valor pago maior que zero.'); end if;
    if v_valor > 9999999 then return _falha('Valor alto demais.'); end if;
  end if;
  update despesas set data_hora = now(), valor = v_valor, status = 'Paga', situacao = 'Paga', saiu_do_caixa = v_caixa where id = d.id;
  perform _auditar('Conta paga', d.descricao || ' | previsto R$ ' || _dinheiro(d.valor) || ' | pago R$ ' || _dinheiro(v_valor) || ' | ' || case when v_caixa then 'saiu do caixa' else 'fora do caixa' end);
  v_r := jsonb_build_object('ok', true, 'message', 'Pagamento registrado: R$ ' || _dinheiro(v_valor));
  if v_req is not null then perform _idem_gravar(v_req, 'pagarDespesa', v_r); end if;
  return v_r;
end $function$
;

CREATE OR REPLACE FUNCTION public.api_pedir_conta_mesa(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_q jsonb := _mesa_qr(p->>'mesa', p->>'codigo'); m mesas;
begin
  if v_q->>'ok' <> 'true' then return v_q; end if;
  select * into m from mesas where id = (v_q->>'mesaId')::uuid for update;
  if m.status::text = 'Aguardando fechamento' then return jsonb_build_object('ok', true, 'message', 'A conta já foi pedida. Já estamos a caminho!'); end if;
  if m.status::text <> 'Ocupada' then return _falha('Faça um pedido antes de pedir a conta.'); end if;
  if _excedeu('pedirconta_' || m.id::text, 3) then return _falha('Já recebemos seu pedido de conta. Aguarde um instante.'); end if;
  update mesas set status = 'Aguardando fechamento' where id = m.id;
  perform _registrar_falha('pedirconta_' || m.id::text, 600);
  perform _auditar_publico('Conta pedida pelo cliente na mesa', 'Mesa ' || m.numero, null);
  return jsonb_build_object('ok', true, 'message', 'Conta solicitada! Em instantes alguém vem até a sua mesa.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_preview_fechamento_entrega(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c record;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if btrim(coalesce(p->>'entregador','')) = '' or coalesce(p->>'dataRef','') !~ '^\d{4}-\d{2}-\d{2}$' then return _falha('Informe o entregador e a data.'); end if;
  select * into c from _calc_fechamento_entrega(p->>'entregador', (p->>'dataRef')::date);
  return jsonb_build_object('ok', true, 'qtd', c.qtd, 'totalTaxas', c.total_taxas, 'ajudaDiaria', c.ajuda, 'totalDevido', c.total, 'vendaIds', to_jsonb(coalesce(c.ids, '{}'::uuid[])));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_reconciliar_venda_contingencia(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_id text := nullif(left(btrim(coalesce(p->>'idFila','')), 120), '');
  d jsonb := p->'dados'; v_ja contingencia_reconciliada%rowtype; v_r jsonb; v_req text; v_venda uuid; v_origem text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_id is null or jsonb_typeof(d) <> 'object' or jsonb_typeof(d->'itens') <> 'array' then return _falha('Item da fila da contingência inválido.'); end if;
  perform pg_advisory_xact_lock(hashtext('recon:' || v_id));
  select * into v_ja from contingencia_reconciliada where id_fila = v_id;
  if found then return jsonb_build_object('ok', true, 'jaFeita', true, 'id', v_ja.venda_id); end if;

  v_origem := coalesce(d->>'origem', '');
  if v_origem = 'Cardápio' then
    -- mesmo caminho do pedido do cardápio; o id da fila vira requisicaoId (reenvio devolve o pedido já criado)
    v_r := _criar_pedido_publico((d - 'desconto' - 'senhaAdminConfirmacao') || jsonb_build_object('requisicaoId', v_id), null);
  elsif v_origem = 'Caixa' then
    -- usa o id da tentativa original: se o servidor chegou a gravar a venda antes de cair, não duplica
    v_req := coalesce(nullif(d->>'requisicaoOriginal', ''), v_id);
    v_r := api_iniciar_venda((d - 'desconto' - 'senhaAdminConfirmacao' - 'timestampOriginal' - 'requisicaoOriginal' - 'emergenciaOperador')
      || jsonb_build_object('origem', 'Balcão', 'requisicaoId', v_req));
  else
    return _falha('Origem desconhecida na fila: ' || left(v_origem, 40));
  end if;

  if coalesce(v_r->>'ok', '') <> 'true' then
    return jsonb_build_object('ok', false, 'message', coalesce(v_r->>'message', 'Não foi possível lançar a venda.'));
  end if;
  v_venda := nullif(v_r->>'id', '')::uuid;
  insert into contingencia_reconciliada (id_fila, venda_id, origem, usuario_id) values (v_id, v_venda, v_origem, auth.uid()) on conflict do nothing;
  perform _auditar('Venda da contingência reconciliada',
    'Fila ' || v_id || ' · origem ' || v_origem || ' · venda ' || left(coalesce(v_venda::text, ''), 8)
      || case when coalesce(d->>'emergenciaOperador', '') <> '' then ' · feita em modo emergência por ' || left(d->>'emergenciaOperador', 40) else '' end, '');
  return jsonb_build_object('ok', true, 'id', v_venda, 'numero', v_r->'numero', 'duplicado', coalesce((v_r->>'duplicado')::boolean, false));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_registrar_ajuste_pos_venda(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_aut text; v_aut_id uuid; v_req text := nullif(p->>'requisicaoId', ''); v_r jsonb;
        v_tipo text := btrim(coalesce(p->>'tipo', '')); v_motivo text := btrim(coalesce(p->>'motivo', '')); v_det text := left(btrim(coalesce(p->>'detalhe', '')), 200);
        v_valor numeric := round(_num(p->>'valor'), 2); ve vendas%rowtype; v_saida boolean; v_onde text; v_ja numeric; v_desp uuid; v_ref text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_req is not null then perform pg_advisory_xact_lock(hashtext(v_req)); v_r := _idem_ler(v_req); if v_r is not null then return v_r; end if; end if;
  v_aut := _exige_admin(p->>'senhaAdminConfirmacao');
  if v_aut is null then return _falha('Senha de administrador incorreta.'); end if;
  if v_tipo <> all (array['Reembolso em dinheiro','Crédito para próxima compra','Cortesia (item grátis)','Desconto retroativo']) then return _falha('Escolha o tipo de ajuste.'); end if;
  if v_motivo <> all (array['Produto errado','Item faltando','Qualidade do produto','Atraso na entrega','Cobrança em duplicidade','Atendimento','Outro']) then return _falha('Escolha o motivo do ajuste.'); end if;
  if v_motivo = 'Outro' and v_det = '' then return _falha('Descreva o motivo (campo "Detalhe") quando escolher "Outro".'); end if;
  if not (v_valor > 0) then return _falha('Informe um valor maior que zero.'); end if;
  select * into ve from vendas where id = _uuid(p->>'vendaId') for update;
  if not found then return _falha('Venda não encontrada.'); end if;
  if ve.status <> 'Confirmada' then return _falha('Só dá para ajustar venda confirmada. Venda cancelada já foi tratada no cancelamento.'); end if;
  if ve.status_pedido is not null and ve.status_pedido::text not in ('Entregue','Retirada','Servida') then
    return _falha('O pedido ainda está "' || ve.status_pedido || '". Antes de terminar, use Editar ou Cancelar. Ajuste pós-venda é para pedido já entregue.');
  end if;
  v_saida := v_tipo in ('Reembolso em dinheiro', 'Desconto retroativo');
  if v_saida and ve.status_pagamento::text is distinct from 'Pago' then return _falha('Esta venda ainda não foi paga — não há o que devolver. Use Editar ou Cancelar.'); end if;
  if v_valor > ve.valor_total + 0.001 then return _falha('O ajuste (R$ ' || _dinheiro(v_valor) || ') não pode ser maior que o valor da venda (R$ ' || _dinheiro(ve.valor_total) || ').'); end if;
  if v_saida then
    select coalesce(sum(valor), 0) into v_ja from ajustes_pos_venda where venda_id = ve.id and status = 'Ativo' and tipo in ('Reembolso em dinheiro', 'Desconto retroativo');
    if v_ja + v_valor > ve.valor_total + 0.001 then
      return _falha('Já foram devolvidos R$ ' || _dinheiro(v_ja) || ' desta venda. Com este ajuste passaria do valor da venda (R$ ' || _dinheiro(ve.valor_total) || ').');
    end if;
  end if;
  v_onde := case when v_saida then (case when p->>'saida' = 'Do caixa' then 'Do caixa' else 'Fora do caixa' end) else 'Sem saída de dinheiro' end;
  if v_onde = 'Do caixa' and not exists (select 1 from caixa_sessoes where status = 'Aberto') then
    return _falha('Abra o caixa para registrar uma devolução que sai do caixa (ou escolha "Fora do caixa").');
  end if;
  v_ref := coalesce('nº ' || ve.numero_pedido, right(ve.id::text, 8));
  if v_saida then
    insert into despesas (descricao, valor, observacao, status, categoria, situacao, saiu_do_caixa)
    values ('Ajuste pós-venda: ' || v_tipo || ' — pedido ' || v_ref, v_valor,
            'Venda ' || right(ve.id::text, 8) || ' | ' || v_motivo || case when v_det <> '' then ' — ' || v_det else '' end,
            'Paga', 'Ajuste pós-venda', 'Paga', (v_onde = 'Do caixa'))
    returning id into v_desp;
  end if;
  select id into v_aut_id from usuarios where lower(login) = lower(v_aut);
  insert into ajustes_pos_venda (venda_id, pedido_numero, cliente, telefone, tipo, valor, motivo, detalhe, saida, despesa_id, status, autorizado_por, registrado_por)
  values (ve.id, ve.numero_pedido, ve.cliente_nome, ve.telefone_cliente, v_tipo, v_valor, v_motivo, v_det, v_saida, v_desp, 'Ativo', v_aut_id, auth.uid());
  perform _auditar('Ajuste pós-venda registrado', v_tipo || ' R$ ' || _dinheiro(v_valor) || ' | pedido ' || v_ref || ' | ' || v_motivo
                   || case when v_det <> '' then ' — ' || v_det else '' end || ' | ' || v_onde, ve.telefone_cliente);
  v_r := jsonb_build_object('ok', true, 'message', 'Ajuste registrado: ' || v_tipo || ' de R$ ' || _dinheiro(v_valor) || '.');
  if v_req is not null then perform _idem_gravar(v_req, 'registrarAjustePosVenda', v_r); end if;
  return v_r;
end $function$
;

CREATE OR REPLACE FUNCTION public.api_registrar_brinde(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_tipo text := btrim(coalesce(p->>'tipo', ''));
  v_req text := nullif(left(coalesce(p->>'requisicaoId', ''), 80), '');
  v_tel text := btrim(coalesce(p->>'telefone', ''));
  v_tel_ind text := _so_digitos(p->>'telIndicado');
  v_prod uuid := _uuid(p->>'produtoId');
  pr produtos%rowtype; f fidelidade%rowtype; i indicacoes%rowtype; e estoque%rowtype; c record;
  v_r jsonb; v_caixa uuid; v_cli uuid; v_nome text := ''; v_tel_ben text := '';
  v_custo numeric := 0; v_novo numeric; v_bloqueia boolean; v_id uuid := gen_random_uuid(); v_desp uuid;
  v_cons jsonb := '[]'::jsonb; v_itens jsonb;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if v_req is not null then
    perform pg_advisory_xact_lock(hashtext('brinde:' || v_req));
    v_r := _idem_ler(v_req); if v_r is not null then return v_r; end if;
  end if;
  if v_tipo not in ('Fidelidade','Indicação') then return _falha('Tipo de benefício inválido.'); end if;
  if v_prod is null then return _falha('Escolha o prêmio que vai ser entregue.'); end if;
  select id into v_caixa from caixa_sessoes where status = 'Aberto'::status_caixa order by abertura desc limit 1;
  if v_caixa is null then return _falha('Abra o caixa antes de resgatar o prêmio — ele fica registrado no turno.'); end if;

  select * into pr from produtos where id = v_prod;
  if pr.id is null then return _falha('Produto não encontrado.'); end if;
  if not ((v_tipo = 'Fidelidade' and pr.premio_fidelidade) or (v_tipo = 'Indicação' and pr.premio_indicacao)) then
    return _falha('Este produto não está marcado como prêmio de ' || lower(v_tipo) || '. Marque em Editar produto › Opções avançadas.');
  end if;

  -- 1) só validações
  if v_tipo = 'Fidelidade' then
    if _so_digitos(v_tel) = '' then return _falha('Cliente não encontrado.'); end if;
    select id into v_cli from clientes where _so_digitos(telefone) = _so_digitos(v_tel) limit 1;
    if v_cli is not null then select * into f from fidelidade where cliente_id = v_cli for update; end if;
    if f.id is null then return _falha('Cliente não encontrado.'); end if;
    if f.carimbos < 10 then return _falha('Este cartão ainda não completou 10 marcas.'); end if;
    select nome, telefone into v_nome, v_tel_ben from clientes where id = v_cli;
  else
    if v_tel_ind = '' then return _falha('Indicação não encontrada.'); end if;
    select * into i from indicacoes where _so_digitos(telefone_indicado) = v_tel_ind and status = 'Pendente' order by data limit 1 for update;
    if i.id is null then return _falha('Esta indicação não está pendente (já foi resgatada ou não existe).'); end if;
    v_cli := i.indicador_id; v_nome := coalesce(i.nome_indicador, ''); v_tel_ben := coalesce(i.telefone_indicador, '');
  end if;

  v_itens := jsonb_build_array(jsonb_build_object('produtoId', pr.id, 'quantidade', 1));
  select coalesce((select (valor #>> '{}') = 'true' from sistema where chave = 'BLOQUEAR_ESTOQUE_NEGATIVO'), false) into v_bloqueia;
  for c in select * from _consumo(v_itens) order by ingrediente_id loop
    select * into e from estoque where id = c.ingrediente_id for update;
    if e.id is null then continue; end if;
    if v_bloqueia and e.quantidade + 0.000000001 < c.qtd then
      return _falha('Estoque insuficiente de "' || e.ingrediente || '" (tem ' || e.quantidade || ', o prêmio usa ' || c.qtd || ').');
    end if;
    v_custo := v_custo + round(coalesce(e.custo_unitario, 0) * c.qtd, 2);
  end loop;

  -- 2) grava
  if v_tipo = 'Fidelidade' then
    update fidelidade set carimbos = 0, premios_resgatados = f.premios_resgatados + 1, atualizada_em = now() where id = f.id;
  else
    update indicacoes set status = 'Resgatado' where id = i.id;
  end if;
  for c in select * from _consumo(v_itens) order by ingrediente_id loop
    select * into e from estoque where id = c.ingrediente_id for update;
    if e.id is null then continue; end if;
    v_novo := round(e.quantidade - c.qtd, 3);
    update estoque set quantidade = v_novo where id = e.id;
    insert into movimentacoes_estoque (ingrediente_id, tipo, quantidade, qtd_antes, qtd_depois, motivo_referencia, usuario_id)
    values (e.id, 'Saída'::tipo_mov_estoque, -c.qtd, e.quantidade, v_novo, '🎁 Prêmio ' || lower(v_tipo) || ' — ' || pr.nome || ' (' || v_nome || ')', auth.uid());
    if v_novo < 0 then perform _auditar('Estoque negativo', e.ingrediente || ': ' || v_novo || ' (prêmio)'); end if;
    v_cons := v_cons || jsonb_build_array(jsonb_build_object('ingredienteId', c.ingrediente_id, 'qtd', c.qtd));
  end loop;
  v_custo := round(v_custo, 2);
  if v_custo > 0 then
    insert into despesas (data_hora, descricao, valor, observacao, status, categoria, situacao, saiu_do_caixa)
    values (now(), '🎁 Prêmio ' || lower(v_tipo) || ' — ' || pr.nome || ' (' || v_nome || ')', v_custo,
            'Custo do prêmio entregue ao cliente (não sai do caixa)', 'Paga'::status_despesa, 'Marketing', 'Paga', false)
    returning id into v_desp;
  end if;
  insert into brindes (id, tipo, cliente_id, cliente_nome, telefone, indicacao_id, produto_id, produto_nome, custo, consumo, caixa_id, despesa_id, registrado_por, requisicao_id)
  values (v_id, v_tipo, v_cli, v_nome, v_tel_ben, i.id, pr.id, pr.nome, v_custo, v_cons, v_caixa, v_desp, auth.uid(), v_req);
  perform _auditar('Prêmio entregue (' || v_tipo || ')', pr.nome || ' para ' || v_nome, v_tel_ben);

  v_r := jsonb_build_object('ok', true, 'id', v_id, 'message', '🎁 ' || pr.nome || ' entregue a ' || v_nome || '.' ||
          case when jsonb_array_length(v_cons) = 0 then ' (o produto não tem receita cadastrada: nada foi baixado do estoque)' else '' end);
  if v_req is not null then perform _idem_gravar(v_req, 'registrarBrinde', v_r); end if;
  return v_r;
end $function$
;

CREATE OR REPLACE FUNCTION public.api_registrar_entrada_estoque(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare e estoque%rowtype; v_qtd numeric := _num(p->>'quantidade'); v_req text := nullif(p->>'requisicaoId', ''); v_r jsonb; v_depois numeric;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_req is not null then perform pg_advisory_xact_lock(hashtext(v_req)); v_r := _idem_ler(v_req); if v_r is not null then return v_r; end if; end if;
  if v_qtd <= 0 then return _falha('Informe uma quantidade de entrada maior que zero.'); end if;
  select * into e from estoque where id = _uuid(p->>'ingredienteId') for update;
  if not found then return _falha('Ingrediente não encontrado.'); end if;
  v_depois := e.quantidade + v_qtd;
  update estoque set quantidade = v_depois where id = e.id;
  insert into movimentacoes_estoque (ingrediente_id, tipo, quantidade, qtd_antes, qtd_depois, motivo_referencia, usuario_id)
  values (e.id, 'Entrada', v_qtd, e.quantidade, v_depois, coalesce(nullif(p->>'motivo', ''), 'Reposição de estoque'), auth.uid());
  perform _auditar('Entrada de estoque', e.ingrediente || ': +' || v_qtd);
  v_r := jsonb_build_object('ok', true, 'message', 'Entrada registrada.');
  if v_req is not null then perform _idem_gravar(v_req, 'registrarEntradaEstoque', v_r); end if;
  return v_r;
end $function$
;

CREATE OR REPLACE FUNCTION public.api_registrar_inventario_estoque(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare e estoque%rowtype; v_nova numeric := _num(p->>'novaQuantidade', -1); v_req text := nullif(p->>'requisicaoId', ''); v_r jsonb;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_req is not null then perform pg_advisory_xact_lock(hashtext(v_req)); v_r := _idem_ler(v_req); if v_r is not null then return v_r; end if; end if;
  if v_nova < 0 then return _falha('Informe uma quantidade de inventário válida.'); end if;
  select * into e from estoque where id = _uuid(p->>'ingredienteId') for update;
  if not found then return _falha('Ingrediente não encontrado.'); end if;
  update estoque set quantidade = v_nova where id = e.id;
  insert into movimentacoes_estoque (ingrediente_id, tipo, quantidade, qtd_antes, qtd_depois, motivo_referencia, usuario_id)
  values (e.id, 'Inventário', v_nova - e.quantidade, e.quantidade, v_nova, coalesce(nullif(p->>'motivo', ''), 'Contagem de inventário'), auth.uid());
  perform _auditar('Inventário de estoque', e.ingrediente || ': ' || e.quantidade || ' → ' || v_nova || ' (contagem física)');
  v_r := jsonb_build_object('ok', true, 'message', 'Inventário registrado.');
  if v_req is not null then perform _idem_gravar(v_req, 'registrarInventarioEstoque', v_r); end if;
  return v_r;
end $function$
;

CREATE OR REPLACE FUNCTION public.api_registrar_ocorrencia(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_tipo text := btrim(coalesce(p->>'tipo', '')); v_desc text := btrim(coalesce(p->>'descricao', ''));
        v_vid uuid := _uuid(p->>'vendaId'); ve vendas%rowtype; v_niv text := auth_nivel()::text; v_nivel_real text; v_login text := _login_de(auth.uid());
        v_ok boolean := false; v_setor text; v_id uuid; v_num integer;
begin
  if not tem_nivel('Admin','Operador','Garçom','Cozinha','Entregador') then return _negado(); end if;
  if v_tipo <> all (array['Produção','Entrega','Atendimento','Pagamento','Estoque','Outro']) then return _falha('Escolha o tipo da ocorrência.'); end if;
  if char_length(v_desc) < 3 then return _falha('Descreva o que aconteceu.'); end if;
  if char_length(v_desc) > 600 then return _falha('Descrição muito longa (máximo 600 caracteres).'); end if;
  if nullif(btrim(coalesce(p->>'vendaId', '')), '') is not null then
    if v_vid is null then return _falha('Pedido não encontrado.'); end if;
    select * into ve from vendas where id = v_vid;
    if ve.id is null then return _falha('Pedido não encontrado.'); end if;
    v_ok := case v_niv
      when 'Admin' then true when 'Operador' then true
      when 'Entregador' then ve.tipo::text = 'Entrega' and ve.entregador_id = auth.uid()
      when 'Garçom' then ve.mesa_id is not null and ve.registrado_por = auth.uid()
                         and exists (select 1 from mesas m where m.id = ve.mesa_id and m.status::text in ('Ocupada','Aguardando fechamento'))
      when 'Cozinha' then ve.status::text = 'Confirmada' and coalesce(ve.status_pedido::text, '') in ('Recebido','Em preparo','Pronta','Servida','Retirada','Saiu para entrega','Entregue')
      else false end;
    if not v_ok then return _falha('Este pedido não está no seu escopo operacional.'); end if;
  end if;
  select nivel::text into v_nivel_real from usuarios where id = auth.uid();
  v_setor := case v_niv when 'Cozinha' then 'Cozinha' when 'Garçom' then 'Salão' when 'Entregador' then 'Entrega' when 'Operador' then 'Caixa' when 'Admin' then 'Administração' else 'Outro' end;
  insert into ocorrencias (tipo, setor, venda_id, cliente, telefone, registrado_por, descricao, status, historico)
  values (v_tipo, v_setor, ve.id, ve.cliente_nome, ve.telefone_cliente, auth.uid(), v_desc, 'Aberta',
          jsonb_build_array(_agora_br() || ' — ' || coalesce(v_login, '') || ' (' || coalesce(v_nivel_real, v_niv) || '): ocorrência registrada'))
  returning id, numero into v_id, v_num;
  perform _auditar('Ocorrência registrada', '#' || v_num || ' ' || v_tipo
                   || case when ve.id is not null then ' — pedido #' || coalesce(ve.numero_pedido::text, right(ve.id::text, 5)) else '' end
                   || ': ' || left(v_desc, 120));
  return jsonb_build_object('ok', true, 'message', 'Ocorrência #' || v_num || ' registrada.', 'id', v_id);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_registrar_perda_estoque(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare e estoque%rowtype; v_qtd numeric := _num(p->>'quantidade'); v_req text := nullif(p->>'requisicaoId', ''); v_r jsonb; v_depois numeric; v_motivo text := btrim(coalesce(p->>'motivo', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_req is not null then perform pg_advisory_xact_lock(hashtext(v_req)); v_r := _idem_ler(v_req); if v_r is not null then return v_r; end if; end if;
  if v_qtd <= 0 then return _falha('Informe uma quantidade de perda maior que zero.'); end if;
  if v_motivo = '' then return _falha('Informe o motivo da perda.'); end if;
  select * into e from estoque where id = _uuid(p->>'ingredienteId') for update;
  if not found then return _falha('Ingrediente não encontrado.'); end if;
  if v_qtd > e.quantidade then return _falha('A perda (' || v_qtd || ') é maior que o estoque atual de ' || e.ingrediente || ' (' || e.quantidade || '). Nada foi registrado.'); end if;
  v_depois := greatest(0, e.quantidade - v_qtd);
  update estoque set quantidade = v_depois where id = e.id;
  insert into movimentacoes_estoque (ingrediente_id, tipo, quantidade, qtd_antes, qtd_depois, motivo_referencia, usuario_id)
  values (e.id, 'Perda', -v_qtd, e.quantidade, v_depois, v_motivo, auth.uid());
  perform _auditar('Perda de estoque', e.ingrediente || ': -' || v_qtd || ' (' || v_motivo || ')');
  v_r := jsonb_build_object('ok', true, 'message', 'Perda registrada.');
  if v_req is not null then perform _idem_gravar(v_req, 'registrarPerdaEstoque', v_r); end if;
  return v_r;
end $function$
;

CREATE OR REPLACE FUNCTION public.api_rejeitar_pedido(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  return api_cancelar_venda(jsonb_build_object('id', p->>'vendaId', 'motivo', coalesce(nullif(btrim(p->>'motivo'),''), 'Pedido rejeitado'),
    'senhaAdminConfirmacao', p->>'senhaAdminConfirmacao', 'mercadoriaPerdida', 'false'));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_resgatar_premio_fidelidade(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  return public.api_registrar_brinde(jsonb_build_object('tipo', 'Fidelidade', 'telefone', p->>'telefone', 'produtoId', p->>'produtoId', 'requisicaoId', p->>'requisicaoId'));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_retomar_pedido(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare t record; v vendas; antes text;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  select * into t from _pedido_trava(p); v := t.v; if t.erro is not null then return t.erro; end if;
  if v.status_pedido::text <> 'Suspenso' then return _conflito('Este pedido não está suspenso.'); end if;
  antes := coalesce(nullif(v.status_antes_suspensao,''), 'Em preparo');
  update vendas set status_pedido = (case when antes in ('Recebido','Pronta') then antes else 'Em preparo' end)::status_pedido, status_antes_suspensao = null where id = v.id;
  perform _auditar('Pedido retomado', '#' || v.numero_pedido || ' → ' || antes, v.telefone_cliente);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_salvar_cliente(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_nome text := btrim(coalesce(p->>'nome', '')); v_tel text := btrim(coalesce(p->>'telefone', ''));
        v_alvo text := nullif(btrim(coalesce(p->>'id', '')), ''); v_nasc date; v_id uuid; v_novo_id uuid := gen_random_uuid();
begin
  if not tem_nivel('Admin','Operador','Garçom') then return _negado(); end if;
  if v_nome = '' or v_tel = '' then return _falha('Nome e telefone são obrigatórios.'); end if;
  if length(v_nome) > 120 then return _falha('Nome muito longo.'); end if;
  if length(v_tel) > 25 then return _falha('Telefone muito longo.'); end if;
  perform pg_advisory_xact_lock(hashtextextended('cliente:' || _so_digitos(v_tel), 0)); -- dois cadastros do mesmo telefone ao mesmo tempo passam um de cada vez
  begin v_nasc := nullif(btrim(coalesce(p->>'dataNascimento', '')), '')::date; exception when others then v_nasc := null; end;
  -- o cliente que estamos editando (por id; por compatibilidade, também pelo telefone original)
  if v_alvo is not null then
    select id into v_id from clientes where id::text = v_alvo or _so_digitos(telefone) = _so_digitos(v_alvo) limit 1;
  end if;
  if exists (select 1 from clientes where _so_digitos(telefone) = _so_digitos(v_tel) and id is distinct from v_id) then
    return _falha('Já existe outro cliente cadastrado com esse telefone.');
  end if;
  if v_alvo is not null then
    if v_id is null then return _falha('Cliente não encontrado para edição.'); end if;
  if _versao_conflita(p, 'clientes', v_id) then return _conflito('Este registro foi alterado por outra pessoa enquanto você editava. A tela foi atualizada — confira e edite de novo.'); end if;
    update clientes set nome = v_nome, telefone = v_tel, data_nascimento = v_nasc, endereco = coalesce(p->>'endereco', ''), como_conheceu = coalesce(p->>'comoConheceu', '') where id = v_id;
    if p ? 'observacao' then update clientes set observacoes = coalesce(p->>'observacao', '') where id = v_id; end if;
    perform _auditar('Cliente atualizado', v_nome, v_tel);
    return jsonb_build_object('ok', true, 'message', 'Cadastro atualizado.');
  end if;
  insert into clientes (id, nome, telefone, data_nascimento, endereco, como_conheceu, primeiro_contato, observacoes)
  values (v_novo_id, v_nome, v_tel, v_nasc, coalesce(p->>'endereco', ''), coalesce(p->>'comoConheceu', ''), now(), coalesce(p->>'observacao', ''));
  perform _auditar('Cliente cadastrado', v_nome, v_tel);
  return jsonb_build_object('ok', true, 'message', 'Cliente cadastrado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_salvar_config_cardapio(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  perform _cfg_gravar('CardapioKicker', to_jsonb(coalesce(p->>'kicker', '')));
  perform _cfg_gravar('CardapioFrase', to_jsonb(coalesce(p->>'frase', '')));
  if p ? 'tempoEntrega' then perform _cfg_gravar('CardapioTempoEntrega', to_jsonb(coalesce(p->>'tempoEntrega', ''))); end if;
  if p ? 'tempoRetirada' then perform _cfg_gravar('CardapioTempoRetirada', to_jsonb(coalesce(p->>'tempoRetirada', ''))); end if;
  if p ? 'tempoMesa' then perform _cfg_gravar('CardapioTempoMesa', to_jsonb(coalesce(p->>'tempoMesa', ''))); end if;
  perform _auditar('Configuração do Cardápio Digital atualizada');
  return jsonb_build_object('ok', true, 'message', 'Cardápio atualizado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_salvar_config_entrega(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare t numeric := _num(p->>'taxaPadrao', -1); a numeric := _num(p->>'ajudaDiaria', -1); v_t0 numeric; v_a0 numeric;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if t < 0 or t > 500 then return _falha('Taxa de entrega inválida.'); end if;
  if a < 0 or a > 1000 then return _falha('Ajuda diária inválida.'); end if;
  select coalesce(_num(valor #>> '{}'), 0) into v_t0 from sistema where chave = 'TaxaEntregaPadrao';
  select coalesce(_num(valor #>> '{}'), 0) into v_a0 from sistema where chave = 'AjudaDiariaEntregador';
  perform _cfg_gravar('TaxaEntregaPadrao', to_jsonb(round(t, 2)));
  perform _cfg_gravar('AjudaDiariaEntregador', to_jsonb(round(a, 2)));
  perform _auditar('Configuração de entrega alterada', 'Taxa: R$ ' || to_char(coalesce(v_t0, 0), 'FM999990.00') || ' → R$ ' || to_char(t, 'FM999990.00')
    || ' | Ajuda diária: R$ ' || to_char(coalesce(v_a0, 0), 'FM999990.00') || ' → R$ ' || to_char(a, 'FM999990.00') || ' (vale só para pedidos e fechamentos futuros)');
  return jsonb_build_object('ok', true, 'message', 'Configuração de entrega salva.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_salvar_config_estoque(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_b boolean := coalesce(p->>'bloquear', '') in ('true', 't');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  perform _cfg_gravar('BLOQUEAR_ESTOQUE_NEGATIVO', to_jsonb(v_b));
  perform _auditar('Regra de estoque alterada', 'Bloquear venda sem estoque: ' || case when v_b then 'Sim' else 'Não' end);
  return jsonb_build_object('ok', true, 'message', 'Regra de estoque salva.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_salvar_config_notificacoes(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_antes jsonb; v_novo jsonb; k text; e jsonb; v_perfis jsonb;
        v_ids text[] := array['pedido','entrega','estoque','financeiro','ocorrencia','sistema','fidelidade','indicacao','aniversario','inativos'];
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if jsonb_typeof(p->'eventos') <> 'object' then return _falha('Configuração inválida.'); end if;
  select coalesce(valor, '{}'::jsonb) into v_antes from sistema where chave = 'NotificacoesConfig';
  if v_antes is null or jsonb_typeof(v_antes) <> 'object' then v_antes := '{}'::jsonb; end if;
  v_novo := v_antes;
  foreach k in array v_ids loop
    e := p->'eventos'->k;
    if e is null or jsonb_typeof(e) <> 'object' then continue; end if;
    select coalesce(jsonb_agg(distinct x), '[]'::jsonb) into v_perfis
      from jsonb_array_elements_text(case when jsonb_typeof(e->'perfis') = 'array' then e->'perfis' else '[]'::jsonb end) x
      where x in ('Admin','Operador','Cozinha');
    v_novo := v_novo || jsonb_build_object(k, jsonb_build_object('ativo', (coalesce(e->>'ativo','') <> 'false'), 'perfis', v_perfis));
  end loop;
  if length(v_novo::text) > 4000 then return _falha('Configuração grande demais.'); end if;
  perform _cfg_gravar('NotificacoesConfig', v_novo);
  if v_novo <> v_antes then perform _auditar('Configuração de notificações alterada', 'Eventos atualizados'); end if;
  return jsonb_build_object('ok', true, 'message', case when v_novo <> v_antes then 'Notificações atualizadas.' else 'Nada mudou.' end);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_salvar_cupom(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v record;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into v from _cupom_validar(p, null);
  if v.erro is not null then return _falha(v.erro); end if;
  insert into cupons (codigo, nome, tipo, valor, frete_gratis, data_inicio, data_fim, hora_inicio, hora_fim, limite_total, limite_por_cliente, valor_minimo, ativa, acumula, criado_por)
  values ((v.c).codigo, (v.c).nome, (v.c).tipo, (v.c).valor, (v.c).frete_gratis, (v.c).data_inicio, (v.c).data_fim, (v.c).hora_inicio, (v.c).hora_fim, (v.c).limite_total, (v.c).limite_por_cliente, (v.c).valor_minimo, (v.c).ativa, (v.c).acumula, auth.uid());
  perform _auditar('Cupom criado', (v.c).codigo, (v.c).nome || ' | benefício ' || (v.c).tipo || ' ' || (v.c).valor);
  return jsonb_build_object('ok', true, 'message', 'Cupom criado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_salvar_evento(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id'); v_nome text := left(btrim(coalesce(p->>'nome', '')), 120); v_data date := _data_iso(btrim(coalesce(p->>'data', '')));
        v_st text := coalesce(nullif(btrim(p->>'status'), ''), 'Orçamento'); v_vc numeric; v_novo uuid;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_nome = '' or v_data is null then return _falha('Informe nome e data do evento.'); end if;
  if v_st <> all (array['Orçamento','Confirmado','Em andamento','Concluído','Cancelado']) then v_st := 'Orçamento'; end if;
  v_vc := case when btrim(coalesce(p->>'valorContratado', '')) = '' then 0 else _num(p->>'valorContratado', -1) end;
  if v_vc < 0 then return _falha('Valor contratado inválido.'); end if;
  v_vc := round(v_vc, 2);
  if v_id is not null and exists (select 1 from eventos where id = v_id) then
  if _versao_conflita(p, 'eventos', v_id) then return _conflito('Este registro foi alterado por outra pessoa enquanto você editava. A tela foi atualizada — confira e edite de novo.'); end if;
    update eventos set nome = v_nome, tipo = left(coalesce(p->>'tipo', ''), 60), data = v_data, hora_inicio = _hora_valida(p->>'horaInicio'), hora_fim = _hora_valida(p->>'horaFim'),
           local = left(coalesce(p->>'local', ''), 160), contratante = left(coalesce(p->>'contratante', ''), 120), telefone = left(coalesce(p->>'telefone', ''), 30),
           status = v_st, valor_contratado = v_vc, observacoes = left(coalesce(p->>'observacoes', ''), 1000)
     where id = v_id;
    perform _recalcular_evento(v_id);
    perform _auditar('Evento alterado', v_id::text, v_nome);
    return jsonb_build_object('ok', true, 'message', 'Evento atualizado.', 'evento', _evento_json(v_id));
  end if;
  insert into eventos (nome, tipo, data, hora_inicio, hora_fim, local, contratante, telefone, status, valor_contratado, valor_recebido, valor_a_receber, custo_total, resultado, observacoes, criado_por)
  values (v_nome, left(coalesce(p->>'tipo', ''), 60), v_data, _hora_valida(p->>'horaInicio'), _hora_valida(p->>'horaFim'), left(coalesce(p->>'local', ''), 160),
          left(coalesce(p->>'contratante', ''), 120), left(coalesce(p->>'telefone', ''), 30), v_st, v_vc, 0, v_vc, 0, v_vc, left(coalesce(p->>'observacoes', ''), 1000), auth.uid())
  returning id into v_novo;
  perform _auditar('Evento criado', v_novo::text, v_nome);
  return jsonb_build_object('ok', true, 'message', 'Evento criado.', 'evento', _evento_json(v_novo));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_salvar_meta(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_tipo text := p->>'tipo'; v_val numeric := _num(p->>'valor');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_tipo is null or v_tipo not in ('MetaMensal','MetaDiaria') then return _falha('Tipo de meta inválido.'); end if;
  perform _cfg_gravar(v_tipo, to_jsonb(v_val));
  perform _auditar('Meta atualizada', v_tipo || ': R$ ' || to_char(v_val, 'FM999990.00'));
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_seed_cardapio_texas_burger(p jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_itens jsonb := $j$[
   ["p","Smash Catupiry","Pão de Brioche, Smash de 80 gr, Catupiry, queijo mussarela, alface","Smash",23.50,24.90],
   ["p","Smash Cheddar","Pão de Brioche, Smash de 80 gr, queijo cheddar e cebola caramelizada","Smash",23.50,24.90],
   ["p","Smash Tasty","Pão de Brioche, Smash de 80 gr, queijo mussarela, alface e tomate","Smash",23.50,24.90],
   ["p","Burguer Rustic","1 Hambúrguer 150gr, Queijo, Bacon, Rúcula, Geleia de Pimenta, Pão com gergelim","Texas Gourmet",38.30,40.90],
   ["p","Barbecue Mister","1 Hambúrguer 150gr, Queijo, Picles, Bacon, Barbecue, Cebola Crispy, Pão com gergelim","Texas Gourmet",39.50,41.90],
   ["p","Onion Texas","1 Hambúrguer 150gr, Queijo, Bacon, Anéis de Cebola, Barbecue, Picles","Texas Gourmet",41.70,44.90],
   ["p","X Texas","1 Hambúrguer 200gr linguiça, Queijo, Rúcula, Tomate, Geleia de pimenta","Texas Gourmet",36.00,38.90],
   ["p","Duplo Cheddar","Dois hambúrgueres 150g, duplo cheddar, bacon, cebola caramelizada, molho da casa","Texas Gourmet",48.40,51.90],
   ["p","Picles Cheddar","1 Hambúrguer 150gr, Cheddar, Alface, Tomate, Cebola Roxa, Picles","Texas Gourmet",36.00,38.90],
   ["p","Texas Honey","1 Hambúrguer 150gr, Cheddar, Bacon, mostarda com mel, Pão Brioche","Texas Gourmet",38.30,40.90],
   ["p","Catupiry Bacon","Pão Brioche, 1 Hambúrguer 150gr, Disco Catupiry 100gr, Bacon, Mussarela, Alface, Tomate","Texas Gourmet",45.00,48.90],
   ["p","Cheddar","Pão Brioche, 1 Hambúrguer 150gr, Cheddar cremoso, Bacon, Cebola Caramelizada","Texas Gourmet",34.00,35.90],
   ["p","X Picanha","Pão Brioche, Hambúrguer 150gr de Picanha, Queijo, Rúcula, Tomate","Texas Gourmet",39.40,42.00],
   ["p","X Costela","Pão com Gergelim, Hambúrguer 150gr de Costela, Queijo, Rúcula, Tomate","Texas Gourmet",38.30,41.00],
   ["p","X Salada","Pão, hambúrguer 150g, presunto, queijo, tomate, alface","Lanches de Hambúrguer",28.25,29.90],
   ["p","X Burguer","Pão, hambúrguer 150g, presunto, queijo, tomate","Lanches de Hambúrguer",28.25,29.90],
   ["p","X Bacon","Pão, hambúrguer 150g, bacon crocante, presunto, queijo, tomate, alface","Lanches de Hambúrguer",36.00,38.90],
   ["p","X Egg","Pão, hambúrguer 150g, dois ovos fritos, presunto, queijo, tomate, alface","Lanches de Hambúrguer",31.65,33.90],
   ["p","X Egg Bacon","Pão, hambúrguer 150g, dois ovos, bacon crocante, presunto, queijo, tomate, alface","Lanches de Hambúrguer",39.55,39.90],
   ["p","X Tudo","Pão, hambúrguer 150g, bacon, salsicha, ovo, presunto, queijo, tomate, alface","Lanches de Hambúrguer",39.55,41.90],
   ["p","X Tudo Especial","Pão, hambúrguer 150g, bacon, milho, salsicha, ovo, batata palha, catupiry, queijo, presunto, tomate","Lanches de Hambúrguer",45.00,47.90],
   ["p","Frango Egg","Pão, 250g frango, ovo, queijo, alface, tomate","Lanches de Frango",32.00,33.90],
   ["p","Frango Bacon","Pão, 250g frango crocante, bacon, queijo derretido, tomate, alface","Lanches de Frango",38.00,40.90],
   ["p","Frango Catupiry","Pão, 250g frango, catupiry cremoso, queijo, alface, tomate","Lanches de Frango",34.00,35.90],
   ["p","Frango Bacon Catupiry","Pão, 250g frango, bacon crocante, catupiry cremoso, queijo, alface, tomate","Lanches de Frango",39.00,41.90],
   ["p","Frango Cubano","Pão, 250g frango, milho, batata palha, catupiry cremoso, queijo, alface, tomate","Lanches de Frango",41.70,44.90],
   ["p","Frango Salada","Pão macio, 250g frango, queijo derretido, tomate fresco, alface crocante","Lanches de Frango",31.00,32.90],
   ["p","Churrasco Tudo","Carne suculenta, ingredientes completos","Churrasco",50.85,53.90],
   ["p","Fritas Simples","Batatas em palito, crocantes","Fritas Texas",34.00,35.90],
   ["p","Fritas 3 Queijos","Batata com mussarela, catupiry e cheddar","Fritas Texas",67.80,71.90],
   ["p","Fritas C C B","Batata com cheddar cremoso, catupiry e bacon crocante","Fritas Texas",67.80,71.90],
   ["p","Fritas Cheddar Bacon","Batata com cheddar cremoso e bacon crocante","Fritas Texas",67.80,71.90],
   ["p","Fritas Especial Texas","Batata com carne, frango, catupiry, cheddar, bacon e mussarela","Fritas Texas",90.00,95.90],
   ["p","Frango a Passarinho","","Fritas Texas",50.00,50.00],
   ["p","Batata Recheada Frango Bacon","Frango, bacon crocante, queijo, creme de leite, batata palha — 500g","Batata Recheada",38.30,41.00],
   ["p","Batata Recheada Frango Cubano","Frango, bacon, milho, catupiry, queijo, batata palha — 500g","Batata Recheada",41.70,45.00],
   ["p","Batata Recheada Churrasco Cubano Contra Filé","Carne, bacon, milho, catupiry, queijo, batata palha — 500g","Batata Recheada",50.85,54.90],
   ["p","Batata Recheada Carne e Queijo Contra Filé","Carne suculenta, queijo derretido, batata palha — 500g","Batata Recheada",50.85,54.90],
   ["p","Batata Recheada Presunto e Queijo","Presunto, Catupiry, creme de leite, batata palha — 500g","Batata Recheada",33.00,35.00],
   ["p","Batata Recheada Brócolis e Bacon","Brócolis frescos, bacon defumado, queijo, batata palha — 500g","Batata Recheada",36.00,38.00],
   ["p","Batata Recheada Frango Bacon e Catupiry","Frango, bacon, queijo, catupiry aveludado, creme de leite, palha — 500g","Batata Recheada",41.00,43.00],
   ["p","Franguinho","Mini lanche frango empanado com queijo","Kids",22.60,23.99],
   ["p","Hamburguinho","Mini hambúrguer com queijo derretido","Kids",22.60,23.99],
   ["p","Doguinho","Pão fofinho, salsicha, batata palha, ketchup, maionese","Kids",17.00,17.99],
   ["p","Coca Cola Lata 350ml","","Bebidas",6.00,7.50],
   ["p","Coca Cola Zero Lata 350ml","","Bebidas",6.00,7.50],
   ["p","Coca Cola 1L","","Bebidas",10.00,12.00],
   ["p","Coca Cola Zero 1L","","Bebidas",10.00,12.00],
   ["p","Coca Cola 2L","","Bebidas",16.00,19.00],
   ["p","Coca Cola Zero 2L","","Bebidas",16.00,19.00],
   ["c","Burguer Rustic Combo","Texas Gourmet",49.60,52.90,["Burguer Rustic","Fritas Simples","Coca Cola Lata 350ml"]],
   ["c","Texas Honey Combo","Texas Gourmet",49.60,52.90,["Texas Honey","Fritas Simples","Coca Cola Lata 350ml"]],
   ["c","Duplo Cheddar Combo","Texas Gourmet",59.80,63.90,["Duplo Cheddar","Fritas Simples","Coca Cola Lata 350ml"]],
   ["c","Barbecue Mister Combo","Texas Gourmet",50.00,53.90,["Barbecue Mister","Fritas Simples","Coca Cola Lata 350ml"]],
   ["c","Catupiry Bacon Combo","Texas Gourmet",56.40,59.90,["Catupiry Bacon","Fritas Simples","Coca Cola Lata 350ml"]],
   ["c","Onion Texas Combo","Texas Gourmet",52.00,56.90,["Onion Texas","Fritas Simples","Coca Cola Lata 350ml"]],
   ["c","Cheddar Combo","Texas Gourmet",45.00,47.90,["Cheddar","Fritas Simples","Coca Cola Lata 350ml"]],
   ["c","X Texas Combo","Texas Gourmet",47.00,49.90,["X Texas","Fritas Simples","Coca Cola Lata 350ml"]],
   ["c","Picles Cheddar Combo","Texas Gourmet",47.00,49.90,["Picles Cheddar","Fritas Simples","Coca Cola Lata 350ml"]],
   ["c","Combo Texas","Combos",79.00,84.99,[]],
   ["c","Combo X Bacon","Combos",99.90,107.99,[]],
   ["c","Combo Salada Burguer","Combos",90.00,95.99,[]],
   ["c","Duplo Tudo","Combos",60.00,71.99,[]],
   ["c","Cheddar em Dobro","Combos",90.00,107.99,[]],
   ["c","Dobro Burguer + Churros","Combos",80.00,95.99,[]],
   ["p","Nacho Dog Texas","Pão de cachorro-quente, salsicha, bacon, muito cheddar e cebola caramelizada","Hot Dog Gourmet",21.50,22.90],
   ["p","The Master Dog","Pão de cachorro-quente, salsicha, bacon, molho especial, picles e cebola","Hot Dog Gourmet",21.50,22.90]
  ]$j$::jsonb;
  v_ingr text[] := array['Pão','Pão com gergelim','Pão Brioche','Hambúrguer 150g','Hambúrguer 200g de linguiça','Hambúrguer 150g de Picanha','Hambúrguer 150g de Costela',
    'Frango','Frango crocante','Carne Contra Filé','Bacon','Presunto','Salsicha','Ovo','Queijo Mussarela','Cheddar cremoso','Catupiry','Creme de leite',
    'Rúcula','Alface','Tomate','Anel de Cebola','Cebola Caramelizada','Cebola Roxa','Picles','Milho','Brócolis','Batata palha','Batata frita',
    'Geleia de Pimenta','Molho Barbecue','Mostarda com mel','Molho da casa','Ketchup','Maionese','Hambúrguer Smash 80g','Pão de cachorro-quente'];
  v_adic text[] := array['Hambúrguer extra (150g)','Bacon extra','Ovo extra','Frango extra','Costela extra','Queijo extra (mussarela)','Cheddar extra','Catupiry extra','Cream cheese',
    'Maionese temperada','Maionese verde','Molho rosê','Molho picante/pimenta','Molho ranch','Tomate seco','Pepino','Jalapeño','Cebola frita crocante',
    'Porção extra de batata frita','Batata rústica','Onion rings extra'];
  it jsonb; v_nome text; v_cat text; v_cat_id uuid; v_id uuid; v_ordem int; v_loja numeric; v_ifood numeric; f record; n text; v_comp text; v_pid uuid;
  n_cat int := 0; n_prod int := 0; n_combo int := 0; n_ing int := 0; n_adic int := 0; v_avisos jsonb := '[]'::jsonb; v_msg text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  perform pg_advisory_xact_lock(hashtext('seed_cardapio_texas'));

  for it in select * from jsonb_array_elements(v_itens) loop
    if it->>0 = 'p' then
      v_nome := it->>1; v_cat := it->>3; v_loja := (it->>4)::numeric; v_ifood := (it->>5)::numeric;
    else
      v_nome := it->>1; v_cat := it->>2; v_loja := (it->>3)::numeric; v_ifood := (it->>4)::numeric;
    end if;
    if it->>0 = 'p' and exists (select 1 from produtos where lower(nome) = lower(v_nome)) then
      v_avisos := v_avisos || to_jsonb('Produto já existia, não duplicado: ' || v_nome); continue;
    end if;
    if it->>0 = 'c' and exists (select 1 from combos where lower(nome) = lower(v_nome)) then
      v_avisos := v_avisos || to_jsonb('Combo já existia, não duplicado: ' || v_nome); continue;
    end if;
    select id into v_cat_id from categorias where lower(nome) = lower(v_cat) order by ordem limit 1;
    if v_cat_id is null then
      insert into categorias (nome, ativa, ordem) values (v_cat, true, coalesce((select max(ordem) from categorias), 0) + 1) returning id into v_cat_id;
      n_cat := n_cat + 1;
    end if;
    v_ordem := greatest(coalesce((select max(ordem_cardapio) from produtos where categoria_id = v_cat_id), 0), coalesce((select max(ordem_cardapio) from combos where categoria_id = v_cat_id), 0)) + 1;
    if it->>0 = 'p' then
      insert into produtos (nome, descricao, categoria_id, ativo, destaque, ordem_cardapio) values (v_nome, it->>2, v_cat_id, true, false, v_ordem) returning id into v_id;
      for f in select id, nome from formas_pagamento loop
        insert into produto_precos (produto_id, forma_pagamento_id, preco, custo) values (v_id, f.id, case when lower(f.nome) like '%ifood%' then v_ifood else v_loja end, 0);
      end loop;
      n_prod := n_prod + 1;
    else
      insert into combos (nome, categoria_id, ativo, destaque, ordem_cardapio) values (v_nome, v_cat_id, true, false, v_ordem) returning id into v_id;
      for f in select id, nome from formas_pagamento loop
        insert into combo_precos (combo_id, forma_pagamento_id, preco, custo) values (v_id, f.id, case when lower(f.nome) like '%ifood%' then v_ifood else v_loja end, 0);
      end loop;
      for v_comp in select jsonb_array_elements_text(it->5) loop
        select id into v_pid from produtos where lower(nome) = lower(v_comp) limit 1;
        if v_pid is not null then insert into combo_itens (combo_id, produto_id, quantidade) values (v_id, v_pid, 1); end if;
      end loop;
      n_combo := n_combo + 1;
    end if;
  end loop;

  foreach n in array v_ingr loop
    if exists (select 1 from estoque where lower(ingrediente) = lower(n)) then
      v_avisos := v_avisos || to_jsonb('Ingrediente já existia, não duplicado: ' || n);
    else
      insert into estoque (ingrediente, quantidade, quantidade_minima, unidade, custo_unitario, status) values (n, 0, 0, 'un', 0, 'Ativo'); n_ing := n_ing + 1;
    end if;
  end loop;
  foreach n in array v_adic loop
    if exists (select 1 from adicionais where lower(nome) = lower(n)) then
      v_avisos := v_avisos || to_jsonb('Adicional já existia, não duplicado: ' || n);
    else
      insert into adicionais (nome, preco, ativo) values (n, 0, true); n_adic := n_adic + 1;
    end if;
  end loop;

  v_msg := n_cat || ' categorias, ' || n_prod || ' produtos, ' || n_combo || ' combos, ' || n_ing || ' ingredientes e ' || n_adic || ' adicionais cadastrados.';
  perform _auditar('Importação inicial de cardápio executada', v_msg);
  return jsonb_build_object('ok', true, 'message', v_msg,
    'detalhes', jsonb_build_object('categorias', n_cat, 'produtos', n_prod, 'combos', n_combo, 'ingredientes', n_ing, 'adicionaisBasicos', n_adic, 'avisos', v_avisos));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_segredo(p_nome text)
 RETURNS text
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public', 'vault'
AS $function$
  select decrypted_secret from vault.decrypted_secrets
  where name = p_nome and p_nome in ('sheets_main_url','chave_servidor_planilha','publishable_key','service_key') limit 1 $function$
;

CREATE OR REPLACE FUNCTION public.api_simular_precificacao(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare pr produtos%rowtype; f formas_pagamento%rowtype; pp produto_precos%rowtype; v_tec numeric; v_preco numeric := _num(p->>'precoSimulado', 0);
        v_emb numeric := greatest(0, _num(p->>'embalagem')); v_out numeric := greatest(0, _num(p->>'outrosCustos')); v_mp numeric := greatest(0, _num(p->>'taxaMarketplace'));
        v_taxa numeric; v_taxa_mp numeric; v_total numeric; v_res numeric;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into pr from produtos where id = _uuid(p->>'produtoId');
  if pr.id is null then return _falha('Produto não encontrado.'); end if;
  select * into f from formas_pagamento where id = _uuid(p->>'formaPagamentoId') and ativa;
  if f.id is null then return _falha('Forma de pagamento não encontrada.'); end if;
  select * into pp from produto_precos where produto_id = pr.id and forma_pagamento_id = f.id;
  if pp.id is null then return _falha('Preço do produto para esta forma de pagamento não encontrado.'); end if;
  select coalesce(sum(e.custo_unitario * pi.quantidade_por_unidade), 0) into v_tec
    from produto_ingredientes pi join estoque e on e.id = pi.ingrediente_id where pi.produto_id = pr.id;
  if v_tec <= 0 then v_tec := coalesce(pp.custo, 0); end if;
  if not (v_preco > 0) then return _falha('Preço simulado inválido.'); end if;
  v_taxa := round(v_preco * f.taxa_percentual / 100 + f.taxa_fixa, 2);
  v_taxa_mp := round(v_preco * v_mp / 100, 2);
  v_total := round(v_tec + v_emb + v_out + v_taxa + v_taxa_mp, 2);
  v_res := round(v_preco - v_total, 2);
  return jsonb_build_object('ok', true, 'produto', pr.nome, 'formaPagamento', f.nome, 'precoAtual', pp.preco, 'precoSimulado', v_preco,
    'custoTecnico', round(v_tec, 2), 'embalagem', v_emb, 'outrosCustos', v_out, 'taxaPagamento', v_taxa, 'taxaPagamentoPct', f.taxa_percentual,
    'taxaPagamentoFixa', f.taxa_fixa, 'taxaMarketplace', v_taxa_mp, 'taxaMarketplacePct', v_mp, 'custoTotal', v_total, 'resultado', v_res,
    'margem', round(v_res / v_preco * 100, 2), 'markup', case when v_total > 0 then round(v_preco / v_total, 2) else 0 end);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_suspender_pedido(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare t record; v vendas; m text := left(btrim(coalesce(p->>'motivo','')), 200);
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if m = '' then return _falha('Informe o motivo da suspensão.'); end if;
  select * into t from _pedido_trava(p); v := t.v; if t.erro is not null then return t.erro; end if;
  if v.status_pedido::text not in ('Recebido','Em preparo','Pronta') then
    return _conflito('Só dá para suspender pedido em "Recebido", "Em preparo" ou "Pronta" (agora está "' || coalesce(v.status_pedido::text,'') || '").'); end if;
  update vendas set status_antes_suspensao = status_pedido::text, status_pedido = 'Suspenso' where id = v.id;
  perform _auditar('Pedido suspenso', '#' || v.numero_pedido || ' | de "' || v.status_pedido::text || '" | ' || m, v.telefone_cliente);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_sync_limpar()
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_n int;
BEGIN
  WITH d AS (DELETE FROM fila_sync WHERE principal_ok_em IS NOT NULL
    AND principal_ok_em < now() - interval '30 days' RETURNING id) SELECT count(*) INTO v_n FROM d;
  RETURN jsonb_build_object('ok',true,'removidos',v_n);
END $function$
;

CREATE OR REPLACE FUNCTION public.api_sync_lote(p_limite integer DEFAULT 100)
 RETURNS jsonb
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT jsonb_build_object('ok',true,'itens',coalesce(jsonb_agg(jsonb_build_object(
    'id',id,'tabela',tabela,'registro_id',registro_id,'operacao',operacao,'payload',payload,'criado_em',criado_em)
    ORDER BY id),'[]'::jsonb))
  FROM (SELECT * FROM fila_sync WHERE principal_ok_em IS NULL ORDER BY id LIMIT p_limite) t $function$
;

CREATE OR REPLACE FUNCTION public.api_sync_marcar(p_ids bigint[], p_destino text, p_ok boolean, p_erro text DEFAULT NULL::text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF p_destino = 'principal' THEN
    IF p_ok THEN UPDATE fila_sync SET principal_ok_em=now(), principal_erro=NULL,
                   contingencia_ok_em=coalesce(contingencia_ok_em, now()), contingencia_erro=NULL WHERE id = ANY(p_ids);
    ELSE UPDATE fila_sync SET principal_tentativas=principal_tentativas+1, principal_erro=left(coalesce(p_erro,'erro'),500) WHERE id = ANY(p_ids); END IF;
    UPDATE sync_estado SET
      principal_ultimo_ok = CASE WHEN p_ok THEN now() ELSE principal_ultimo_ok END,
      principal_ultimo_erro = CASE WHEN NOT p_ok THEN now() ELSE principal_ultimo_erro END,
      principal_ultimo_erro_msg = CASE WHEN NOT p_ok THEN left(coalesce(p_erro,''),500) ELSE principal_ultimo_erro_msg END,
      atualizado_em=now() WHERE id=true;
  ELSE
    IF p_ok THEN UPDATE fila_sync SET contingencia_ok_em=now(), contingencia_erro=NULL WHERE id = ANY(p_ids);
    ELSE UPDATE fila_sync SET contingencia_tentativas=contingencia_tentativas+1, contingencia_erro=left(coalesce(p_erro,'erro'),500) WHERE id = ANY(p_ids); END IF;
  END IF;
  RETURN jsonb_build_object('ok',true);
END $function$
;

CREATE OR REPLACE FUNCTION public.api_sync_status()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_e sync_estado%rowtype;
BEGIN
  IF NOT tem_nivel('Admin','Operador') THEN RETURN _negado(); END IF;
  SELECT * INTO v_e FROM sync_estado WHERE id=true;
  RETURN jsonb_build_object('ok',true,
    'pendentes_principal',(SELECT count(*) FROM fila_sync WHERE principal_ok_em IS NULL),
    'pendentes_contingencia',(SELECT count(*) FROM fila_sync WHERE contingencia_ok_em IS NULL),
    'erros_principal',(SELECT count(*) FROM fila_sync WHERE principal_erro IS NOT NULL AND principal_ok_em IS NULL),
    'erros_contingencia',(SELECT count(*) FROM fila_sync WHERE contingencia_erro IS NOT NULL AND contingencia_ok_em IS NULL),
    'principal_ultimo_ok',v_e.principal_ultimo_ok,'principal_ultimo_erro',v_e.principal_ultimo_erro,
    'principal_ultimo_erro_msg',v_e.principal_ultimo_erro_msg,
    'contingencia_ultimo_ok',v_e.contingencia_ultimo_ok,'contingencia_ultimo_erro',v_e.contingencia_ultimo_erro,
    'contingencia_ultimo_erro_msg',v_e.contingencia_ultimo_erro_msg,
    'itens_mais_antigos',(SELECT coalesce(jsonb_agg(x ORDER BY x->>'em'),'[]'::jsonb) FROM (
        SELECT jsonb_build_object('tabela',tabela,'id',registro_id,'em',criado_em,'tentativas',principal_tentativas,'erro',principal_erro) x
        FROM fila_sync WHERE principal_ok_em IS NULL ORDER BY id LIMIT 20) q),
    'alerta_itens',v_e.alerta_itens_limite,'alerta_horas',v_e.alerta_horas_limite);
END $function$
;

CREATE OR REPLACE FUNCTION public.api_sync_verificar_alerta()
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_e sync_estado%rowtype; v_pend int; v_horas numeric;
BEGIN
  SELECT * INTO v_e FROM sync_estado WHERE id=true;
  SELECT count(*) INTO v_pend FROM fila_sync WHERE principal_ok_em IS NULL;
  v_horas := CASE WHEN v_pend = 0 THEN 0 WHEN v_e.principal_ultimo_ok IS NULL THEN 999
                  ELSE extract(epoch from (now()-v_e.principal_ultimo_ok))/3600 END;
  IF (v_pend > v_e.alerta_itens_limite OR v_horas > v_e.alerta_horas_limite)
     AND NOT EXISTS (SELECT 1 FROM auditoria WHERE acao='ALERTA: fila de sincronização parada' AND data_hora > now() - interval '6 hours') THEN
    INSERT INTO auditoria (usuario_login, acao, detalhes)
    VALUES ('sistema','ALERTA: fila de sincronização parada', v_pend||' itens pendentes · último envio há '||round(v_horas)||'h');
  END IF;
  RETURN jsonb_build_object('ok',true,'pendentes',v_pend,'horas',v_horas);
END $function$
;

CREATE OR REPLACE FUNCTION public.api_toggle_resgate_indicacao(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_tel text := _so_digitos(p->>'telIndicado'); v_st status_indicacao;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  select status into v_st from indicacoes where _so_digitos(telefone_indicado) = v_tel order by data limit 1;
  if v_st = 'Resgatado' then return _falha('Esta indicação já foi resgatada. Para desfazer, o Admin cancela o prêmio no cadastro do cliente.'); end if;
  return public.api_registrar_brinde(jsonb_build_object('tipo', 'Indicação', 'telIndicado', p->>'telIndicado', 'produtoId', p->>'produtoId', 'requisicaoId', p->>'requisicaoId'));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_trocar_minha_senha(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'auth', 'extensions'
AS $function$
declare u usuarios%rowtype; v_atual text := coalesce(p->>'senhaAtual', ''); v_nova text := coalesce(p->>'novaSenha', ''); v_chave text; v_erro text;
        v_sessao uuid := nullif(auth.jwt() ->> 'session_id', '')::uuid;
begin
  select * into u from usuarios where id = auth.uid();
  if not found then return _falha('Sessão inválida. Faça login novamente.'); end if;
  if v_atual = '' or v_nova = '' then return _falha('Preencha a senha atual e a nova senha.'); end if;
  v_chave := 'falhas_troca_' || lower(u.login);
  if _excedeu(v_chave, 5) then return _falha('Muitas tentativas erradas. Aguarde 10 minutos e tente de novo.'); end if;
  if not u.ativo then return _falha('Este acesso está desativado.'); end if;
  if not _senha_confere(u.id, v_atual) then
    perform _registrar_falha(v_chave);
    perform _auditar('Falha ao trocar a própria senha', 'Senha atual incorreta: ' || u.login);
    return _falha('A senha atual está incorreta.');
  end if;
  if v_nova = v_atual then return _falha('A nova senha precisa ser diferente da atual.'); end if;
  v_erro := _erro_senha_fraca(v_nova, u.login);
  if v_erro <> '' then return _falha(v_erro); end if;
  update auth.users set encrypted_password = crypt(v_nova, gen_salt('bf')), updated_at = now() where id = u.id;
  perform _limpar_falhas(v_chave);
  delete from auth.sessions where user_id = u.id and id is distinct from v_sessao;   -- outros aparelhos precisam entrar de novo
  perform _auditar('Senha alterada pelo próprio usuário', u.login);
  return jsonb_build_object('ok', true, 'message', 'Senha alterada. Em outros aparelhos você precisará entrar de novo.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_validar_cupom_cardapio(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_ip text := _ip_cliente(); v_r jsonb;
begin
  if _excedeu('cupomval_ip_' || v_ip, 15) or _excedeu('cupomval_global', 200) then
    return jsonb_build_object('ok', false, 'message', 'Muitas tentativas de cupom. Aguarde alguns minutos.', 'limite', true);
  end if;
  v_r := _cupom_calcular(p->>'codigo', p->>'telefone', _num(p->>'subtotal'), p->>'tipoEntrega');
  if coalesce(v_r->>'ok', '') <> 'true' then
    perform _registrar_falha('cupomval_ip_' || v_ip, 600); perform _registrar_falha('cupomval_global', 600);
  end if;
  return v_r;
end $function$
;

CREATE OR REPLACE FUNCTION public.api_verificar_senha_admin(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if auth_nivel() is null then return _negado(); end if;
  return jsonb_build_object('ok', _exige_admin(p->>'senha') is not null);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_versoes()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if auth_nivel() is null then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'cad', coalesce((select n::text from versoes_sync where grupo = 'cad'), '0'),
    'din', coalesce((select n::text from versoes_sync where grupo = 'din'), '0'));
end $function$
;

CREATE OR REPLACE FUNCTION public.api_versoes_registros(p jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_nivel text := auth_nivel()::text;
  v_mapa jsonb := jsonb_build_object('produtos','produtos','combos','combos','adicionais','adicionais','formasPagamento','formas_pagamento','categorias','categorias',
                                     'clientes','clientes','cupons','cupons','eventos','eventos','despesas','despesas','despesasRecorrentes','despesas_recorrentes',
                                     'usuarios','usuarios','vendas','vendas');
  v_chaves text[]; k text; r jsonb := '{}'::jsonb; m jsonb;
begin
  if v_nivel is null then return _negado(); end if;
  if v_nivel in ('Admin', 'Operador') then
    v_chaves := array['produtos','combos','adicionais','formasPagamento','categorias','clientes','cupons','eventos','despesas','despesasRecorrentes','usuarios','vendas'];
  elsif v_nivel = 'Garçom' then
    v_chaves := array['clientes'];
  else
    return jsonb_build_object('ok', true, 'versoes', '{}'::jsonb);
  end if;
  if jsonb_typeof(p->'chaves') = 'array' then
    v_chaves := array(select c from unnest(v_chaves) c where c in (select jsonb_array_elements_text(p->'chaves')));
  end if;
  foreach k in array v_chaves loop
    select coalesce(jsonb_object_agg(t.rid::text, t.ver), '{}'::jsonb) into m from _versoes_tabela(v_mapa->>k, null) t;
    r := r || jsonb_build_object(k, m);
  end loop;
  return jsonb_build_object('ok', true, 'versoes', r);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_vincular_adicionais_em_lote(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_cats uuid[]; v_ads uuid[]; v_prod int; v_novas int;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select coalesce(array_agg(_uuid(x)) filter (where _uuid(x) is not null), '{}') into v_cats from jsonb_array_elements_text(coalesce(p->'categorias', '[]'::jsonb)) x;
  select coalesce(array_agg(a.id), '{}') into v_ads from adicionais a
    where a.id in (select _uuid(x) from jsonb_array_elements_text(coalesce(p->'adicionaisIds', '[]'::jsonb)) x);
  if coalesce(array_length(v_cats, 1), 0) = 0 then return _falha('Escolha ao menos uma categoria.'); end if;
  if coalesce(jsonb_array_length(coalesce(p->'adicionaisIds', '[]'::jsonb)), 0) = 0 then return _falha('Escolha ao menos um adicional.'); end if;
  if coalesce(array_length(v_ads, 1), 0) = 0 then return _falha('Nenhum adicional válido selecionado.'); end if;
  select count(*) into v_prod from produtos where categoria_id = any(v_cats);
  if v_prod = 0 then return _falha('Não há produtos nessas categorias.'); end if;
  with ins as (
    insert into produto_adicionais (produto_id, adicional_id)
    select pr.id, a from produtos pr cross join unnest(v_ads) a where pr.categoria_id = any(v_cats)
    on conflict (produto_id, adicional_id) do nothing returning 1)
  select count(*) into v_novas from ins;
  perform _auditar('Adicionais vinculados em lote', v_prod || ' produtos x ' || array_length(v_ads, 1) || ' adicionais');
  return jsonb_build_object('ok', true, 'message', case when v_novas > 0 then v_novas || ' vínculos criados em ' || v_prod || ' produtos.' else 'Esses vínculos já existiam.' end);
end $function$
;

CREATE OR REPLACE FUNCTION public.auth_nivel()
 RETURNS nivel_acesso
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select case when u.nivel::text = 'Desenvolvedor' then 'Admin'::nivel_acesso else u.nivel end
  from usuarios u
  where u.id = auth.uid() and u.ativo
    and (coalesce(auth.jwt() ->> 'session_id', '') = ''
         or exists (select 1 from auth.sessions s where s.id = (auth.jwt() ->> 'session_id')::uuid))
$function$
;

CREATE OR REPLACE FUNCTION public.chamar_edge(p_funcao text, p_body jsonb DEFAULT '{}'::jsonb)
 RETURNS bigint
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions'
AS $function$
  SELECT net.http_post(
    url := 'https://awryywtgqfaxppayzpca.supabase.co/functions/v1/'||p_funcao,
    headers := jsonb_build_object('Content-Type','application/json',
      'Authorization','Bearer '||(SELECT decrypted_secret FROM vault.decrypted_secrets WHERE name='service_key')),
    body := p_body) $function$
;

CREATE OR REPLACE FUNCTION public.chat_abrir(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  cfg chat_config%rowtype; v_ip text := _ip_cliente();
  v_cod text := lower(btrim(coalesce(p->>'codigo', '')));
  v_num text := btrim(coalesce(p->>'numero', ''));
  v_tel4 text := regexp_replace(coalesce(p->>'telefone4', ''), '\D', '', 'g');
  -- Acompanhamento do pedido: quem já está dentro do pedido (código completo, sem telefone) não precisa informar os 4 dígitos.
  v_sem_tel boolean := coalesce(p->>'acompanhamento', '') = 'true' and length(lower(btrim(coalesce(p->>'codigo', '')))) >= 32;
  v vendas%rowtype; c chat_conversas%rowtype; v_tok text;
begin
  select * into cfg from chat_config where id;
  if not coalesce(cfg.chat_publico_ligado, false) then
    return jsonb_build_object('ok', false, 'desligado', true, 'message', 'O atendimento por chat está indisponível no momento.');
  end if;
  if not v_sem_tel and v_tel4 !~ '^[0-9]{4}$' then return _falha('Informe os 4 últimos dígitos do telefone do pedido.'); end if;
  if _excedeu('chat_ip_' || v_ip, 10) or _excedeu('chat_falhas', 200) then
    return jsonb_build_object('ok', false, 'limite', true, 'message', 'Muitas tentativas seguidas. Aguarde alguns minutos.');
  end if;
  if v_cod ~ '^[0-9a-f-]{8,36}$' then
    select * into v from vendas
     where right(id::text, 8) = right(v_cod, 8) and right(id::text, length(v_cod)) = v_cod
       and (v_sem_tel or right(regexp_replace(coalesce(telefone_cliente, ''), '\D', '', 'g'), 4) = v_tel4)
     order by data_hora desc limit 1;
  elsif v_num ~ '^[0-9]{1,9}$' and not v_sem_tel then
    select * into v from vendas
     where numero_pedido = v_num::int
       and right(regexp_replace(coalesce(telefone_cliente, ''), '\D', '', 'g'), 4) = v_tel4
     order by data_hora desc limit 1;
  end if;
  if v.id is null then
    perform _registrar_falha('chat_ip_' || v_ip, 600); perform _registrar_falha('chat_falhas', 600);
    return _falha('Não encontrei um pedido com esses dados. Confira o número e os 4 últimos dígitos do telefone.');
  end if;
  if v.data_hora < now() - make_interval(hours => cfg.janela_horas) then
    return _falha('Este pedido passou do prazo de atendimento pelo chat. Fale diretamente com o restaurante.');
  end if;
  v_tok := replace(gen_random_uuid()::text, '-', '') || replace(gen_random_uuid()::text, '-', '');
  select * into c from chat_conversas where venda_id = v.id and estado <> 'encerrada' for update;
  if c.id is null then
    begin
      insert into chat_conversas (venda_id) values (v.id) returning * into c;
    exception when unique_violation then
      select * into c from chat_conversas where venda_id = v.id and estado <> 'encerrada';
    end;
  end if;
  insert into chat_tokens (conversa_id, token_hash) values (c.id, _chat_hash(v_tok))
  on conflict (conversa_id) do update set token_hash = excluded.token_hash, criado_em = now();
  return jsonb_build_object('ok', true, 'token', v_tok, 'conversaId', c.id, 'estado', c.estado, 'caixaAberto', _chat_caixa_aberto(),
    'pedido', jsonb_build_object('numero', v.numero_pedido, 'status', v.status::text, 'statusPedido', v.status_pedido::text,
      'tipoEntrega', v.tipo::text, 'data', to_char(v.data_hora at time zone 'America/Sao_Paulo', 'DD/MM/YYYY HH24:MI')));
end $function$
;

CREATE OR REPLACE FUNCTION public.chat_assumir(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'conversaId'); c chat_conversas%rowtype; v_login text := _login_de(auth.uid());
        v_forcar boolean := coalesce(p->>'forcar', '') = 'true' and auth_nivel()::text = 'Admin';
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  select * into c from chat_conversas where id = v_id for update;
  if c.id is null then return _falha('Conversa não encontrada.'); end if;
  if c.estado = 'encerrada' then return _falha('Este atendimento já foi encerrado.'); end if;
  if c.estado = 'recepcao' then return _falha('O cliente ainda não terminou de pedir ajuda.'); end if;
  if c.estado = 'em_atendimento' and c.atendente_id is distinct from auth.uid() and not v_forcar then
    return _falha('Este atendimento já foi assumido por ' || coalesce(_login_de(c.atendente_id), 'outra pessoa') || '.');
  end if;
  if c.estado = 'em_atendimento' and c.atendente_id = auth.uid() then
    return jsonb_build_object('ok', true, 'message', 'Você já está neste atendimento.');
  end if;
  update chat_conversas set estado = 'em_atendimento', atendente_id = auth.uid(), atualizado_em = now() where id = v_id;
  insert into chat_mensagens (conversa_id, autor, autor_id, texto) values (v_id, 'sistema', auth.uid(), coalesce(v_login, 'A equipe') || ' assumiu o atendimento.');
  if c.ocorrencia_id is not null then
    update ocorrencias set status = 'Em andamento', responsavel = v_login, atualizada_em = now(),
      historico = historico || jsonb_build_array(_agora_br() || ' — ' || coalesce(v_login, '') || ': assumiu o atendimento pelo chat')
    where id = c.ocorrencia_id and status <> 'Resolvida';
  end if;
  perform _auditar('Chat: atendimento assumido', 'conversa ' || left(v_id::text, 8));
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.chat_encerrar(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'conversaId'); v_sol text := _chat_limpar(p->>'solucao'); c chat_conversas%rowtype; v_login text := _login_de(auth.uid());
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  if char_length(v_sol) < 3 then return _falha('Registre a solução antes de encerrar.'); end if;
  if char_length(v_sol) > 600 then return _falha('Solução muito longa (máximo 600 caracteres).'); end if;
  select * into c from chat_conversas where id = v_id for update;
  if c.id is null then return _falha('Conversa não encontrada.'); end if;
  if c.estado = 'encerrada' then return jsonb_build_object('ok', true, 'message', 'Este atendimento já estava encerrado.'); end if;
  if c.estado = 'recepcao' then return _falha('O cliente ainda não pediu atendimento da equipe.'); end if;
  if c.estado = 'em_atendimento' and c.atendente_id is distinct from auth.uid() and auth_nivel()::text <> 'Admin' then
    return _falha('Este atendimento está com ' || coalesce(_login_de(c.atendente_id), 'outra pessoa') || '.');
  end if;
  update chat_conversas set estado = 'encerrada', solucao = v_sol, encerrada_em = now(), atualizado_em = now(),
    atendente_id = coalesce(atendente_id, auth.uid()), nao_lidas_equipe = 0, nao_lidas_cliente = nao_lidas_cliente + 1
  where id = v_id;
  insert into chat_mensagens (conversa_id, autor, autor_id, texto) values (v_id, 'sistema', auth.uid(), 'Atendimento encerrado pela equipe.');
  if c.ocorrencia_id is not null then
    update ocorrencias set status = 'Resolvida', solucao = v_sol, atualizada_em = now(),
      responsavel = coalesce(nullif(responsavel, ''), v_login),
      historico = historico || jsonb_build_array(_agora_br() || ' — ' || coalesce(v_login, '') || ': atendimento encerrado pelo chat — ' || left(v_sol, 120))
    where id = c.ocorrencia_id;
  end if;
  perform _auditar('Chat: atendimento encerrado', 'conversa ' || left(v_id::text, 8));
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.chat_enviar(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_id uuid := _uuid(p->>'conversaId'); v_tok text := coalesce(p->>'token', ''); v_ip text := _ip_cliente();
  v_txt text := _chat_limpar(p->>'texto'); c chat_conversas%rowtype; v_mid bigint;
begin
  if not _chat_ligado() then return jsonb_build_object('ok', false, 'desligado', true, 'message', 'O atendimento por chat está indisponível no momento.'); end if;
  if v_id is null or length(v_tok) < 32 or length(v_tok) > 128 then return _falha('Conversa não encontrada.'); end if;
  if _excedeu('chat_tok_' || v_ip, 20) then
    return jsonb_build_object('ok', false, 'limite', true, 'message', 'Muitas tentativas seguidas. Aguarde alguns minutos.');
  end if;
  if not _chat_validar(v_id, v_tok) then
    perform _registrar_falha('chat_tok_' || v_ip, 600);
    return _falha('Conversa não encontrada.');
  end if;
  if char_length(v_txt) < 1 then return _falha('Escreva a mensagem.'); end if;
  if char_length(v_txt) > 300 then return _falha('Mensagem muito longa (máximo 300 caracteres).'); end if;
  perform _registrar_falha('chatenv_' || v_id::text, 300);
  if _excedeu('chatenv_' || v_id::text, 15) then
    return jsonb_build_object('ok', false, 'limite', true, 'message', 'Muitas mensagens seguidas. Aguarde alguns minutos.');
  end if;
  select * into c from chat_conversas where id = v_id for update;
  if c.id is null then return _falha('Conversa não encontrada.'); end if;
  if c.estado = 'encerrada' then return _falha('Este atendimento foi encerrado.'); end if;
  if (select count(*) from chat_mensagens where conversa_id = v_id and autor = 'cliente') >= 60 then
    return _falha('Limite de mensagens desta conversa atingido.');
  end if;
  insert into chat_mensagens (conversa_id, autor, texto) values (v_id, 'cliente', v_txt) returning id into v_mid;
  update chat_conversas set atualizado_em = now(),
    nao_lidas_equipe = nao_lidas_equipe + case when estado in ('aguardando', 'em_atendimento') then 1 else 0 end
  where id = v_id;
  return jsonb_build_object('ok', true, 'id', v_mid);
end $function$
;

CREATE OR REPLACE FUNCTION public.chat_ia_consumir_cota()
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_limite integer;
  v_usado integer;
  v_dia date := current_date;
begin
  select ia_publica_cota_dia into v_limite
  from chat_config where id = true for update;

  if v_limite is null then v_limite := 30; end if;

  insert into chat_ia_cotas (dia, chamadas) values (v_dia, 0)
  on conflict (dia) do nothing;

  update chat_ia_cotas
     set chamadas = chamadas + 1, atualizado_em = now()
   where dia = v_dia and chamadas < v_limite
  returning chamadas into v_usado;

  if v_usado is null then
    select chamadas into v_usado from chat_ia_cotas where dia = v_dia;
    return jsonb_build_object('ok', false, 'limite', true, 'usado', v_usado, 'cota', v_limite);
  end if;

  return jsonb_build_object('ok', true, 'limite', false, 'usado', v_usado,
    'cota', v_limite, 'restante', greatest(v_limite - v_usado, 0));
end;
$function$
;

CREATE OR REPLACE FUNCTION public.chat_ia_reservar_chamada(p_conversa_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_novo smallint;
begin
  update chat_conversas
     set ia_chamadas = ia_chamadas + 1, atualizado_em = now()
   where id = p_conversa_id and estado = 'recepcao' and ia_chamadas < 6
  returning ia_chamadas into v_novo;
  if v_novo is null then return jsonb_build_object('ok', false, 'codigo', 'limite_ia_conversa'); end if;
  return jsonb_build_object('ok', true, 'ia_chamadas', v_novo);
end;
$function$
;

CREATE OR REPLACE FUNCTION public.chat_ia_validar(p_conversa uuid, p_token text, p_ip text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_chave text := 'iapub_ip_' || left(coalesce(nullif(p_ip, ''), 'sem_ip'), 64);
begin
  -- limite por IP: no máximo 12 tentativas/chamadas em 10 min
  if _excedeu(v_chave, 12) then
    return jsonb_build_object('ok', false, 'motivo', 'limite_ip');
  end if;
  -- token da conversa (o mesmo que o chat_abrir entrega ao cliente)
  if p_conversa is null or length(coalesce(p_token, '')) < 32 or length(p_token) > 128
     or not _chat_validar(p_conversa, p_token) then
    perform _registrar_falha(v_chave, 600);
    return jsonb_build_object('ok', false, 'motivo', 'conversa');
  end if;
  perform _registrar_falha(v_chave, 600); -- conta a chamada válida no mesmo limite
  return jsonb_build_object('ok', true);
end;
$function$
;

CREATE OR REPLACE FUNCTION public.chat_ler(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_id uuid := _uuid(p->>'conversaId'); v_tok text := coalesce(p->>'token', ''); v_ip text := _ip_cliente();
  v_dep bigint := case when (p->>'depois') ~ '^[0-9]{1,18}$' then (p->>'depois')::bigint else 0 end;
  c chat_conversas%rowtype; v_msgs jsonb;
begin
  if not _chat_ligado() then return jsonb_build_object('ok', false, 'desligado', true, 'message', 'O atendimento por chat está indisponível no momento.'); end if;
  if v_id is null or length(v_tok) < 32 or length(v_tok) > 128 then return _falha('Conversa não encontrada.'); end if;
  if _excedeu('chat_tok_' || v_ip, 20) then
    return jsonb_build_object('ok', false, 'limite', true, 'message', 'Muitas tentativas seguidas. Aguarde alguns minutos.');
  end if;
  if not _chat_validar(v_id, v_tok) then
    perform _registrar_falha('chat_tok_' || v_ip, 600);
    return _falha('Conversa não encontrada.');
  end if;
  perform _registrar_falha('chatler_' || v_id::text, 60);
  if _excedeu('chatler_' || v_id::text, 40) then
    return jsonb_build_object('ok', false, 'limite', true, 'message', 'Aguarde alguns segundos.');
  end if;
  select * into c from chat_conversas where id = v_id;
  select coalesce(jsonb_agg(jsonb_build_object('id', m.id, 'autor', m.autor, 'texto', m.texto, 'em', m.criado_em) order by m.id), '[]'::jsonb)
    into v_msgs from (select * from chat_mensagens where conversa_id = v_id and id > v_dep order by id limit 100) m;
  if c.nao_lidas_cliente > 0 then update chat_conversas set nao_lidas_cliente = 0 where id = v_id; end if;
  return jsonb_build_object('ok', true, 'estado', c.estado, 'mensagens', v_msgs, 'caixaAberto', _chat_caixa_aberto());
end $function$
;

CREATE OR REPLACE FUNCTION public.chat_ler_fila()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_lista jsonb;
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;   -- Desenvolvedor já vale como Admin em auth_nivel()
  select coalesce(jsonb_agg(jsonb_build_object(
      'id', c.id, 'vendaId', c.venda_id, 'estado', c.estado, 'tipo', c.tipo_problema, 'resumo', c.resumo,
      'naoLidas', c.nao_lidas_equipe, 'atendenteId', c.atendente_id, 'ocorrenciaId', c.ocorrencia_id,
      'nome', c.nome_cliente, 'telefone', c.telefone_cliente, 'pedidoNaoLocalizado', c.pedido_nao_localizado,
      'outrosPedidos', c.outros_pedidos, 'antesDePedir', (c.intencao = 'antes_de_pedir'),
      'criadoEm', c.criado_em, 'atualizadoEm', c.atualizado_em)
    order by case when c.estado = 'aguardando' then 0 else 1 end, c.atualizado_em asc), '[]'::jsonb)
  into v_lista from chat_conversas c where c.estado in ('aguardando', 'em_atendimento');
  return jsonb_build_object('ok', true, 'conversas', v_lista);
end $function$
;

CREATE OR REPLACE FUNCTION public.chat_marcar_lida(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  update chat_conversas set nao_lidas_equipe = 0 where id = _uuid(p->>'conversaId') and nao_lidas_equipe > 0;
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.chat_responder(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'conversaId'); v_txt text := _chat_limpar(p->>'texto'); c chat_conversas%rowtype; v_mid bigint;
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  if char_length(v_txt) < 1 then return _falha('Escreva a mensagem.'); end if;
  if char_length(v_txt) > 1000 then return _falha('Mensagem muito longa (máximo 1000 caracteres).'); end if;
  select * into c from chat_conversas where id = v_id for update;
  if c.id is null then return _falha('Conversa não encontrada.'); end if;
  if c.estado <> 'em_atendimento' then return _falha('Assuma o atendimento antes de responder.'); end if;
  if c.atendente_id is distinct from auth.uid() and auth_nivel()::text <> 'Admin' then
    return _falha('Este atendimento está com ' || coalesce(_login_de(c.atendente_id), 'outra pessoa') || '.');
  end if;
  insert into chat_mensagens (conversa_id, autor, autor_id, texto) values (v_id, 'atendente', auth.uid(), v_txt) returning id into v_mid;
  update chat_conversas set atualizado_em = now(), nao_lidas_equipe = 0, nao_lidas_cliente = nao_lidas_cliente + 1 where id = v_id;
  return jsonb_build_object('ok', true, 'id', v_mid);
end $function$
;

CREATE OR REPLACE FUNCTION public.chat_status(p jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select jsonb_build_object('ok', true, 'ligado', public._chat_ligado(), 'caixaAberto', public._chat_caixa_aberto());
$function$
;

CREATE OR REPLACE FUNCTION public.chat_transferir(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_id uuid := _uuid(p->>'conversaId'); v_tok text := coalesce(p->>'token', ''); v_ip text := _ip_cliente();
  v_tipo text := btrim(coalesce(p->>'tipo', '')); v_txt text := _chat_limpar(p->>'texto');
  v_res text := nullif(left(_chat_limpar(p->>'resumo'), 600), '');
  c chat_conversas%rowtype; ve vendas%rowtype; v_oc uuid; v_rot text; v_otipo text; v_aberto boolean;
begin
  if not _chat_ligado() then return jsonb_build_object('ok', false, 'desligado', true, 'message', 'O atendimento por chat está indisponível no momento.'); end if;
  if v_id is null or length(v_tok) < 32 or length(v_tok) > 128 then return _falha('Conversa não encontrada.'); end if;
  if _excedeu('chat_tok_' || v_ip, 20) then
    return jsonb_build_object('ok', false, 'limite', true, 'message', 'Muitas tentativas seguidas. Aguarde alguns minutos.');
  end if;
  if not _chat_validar(v_id, v_tok) then
    perform _registrar_falha('chat_tok_' || v_ip, 600);
    return _falha('Conversa não encontrada.');
  end if;
  if v_tipo <> all (array['atraso','item_errado','item_faltando','cobranca','qualidade','outro','antes_de_pedir']) then v_tipo := 'outro'; end if;
  if char_length(v_txt) < 3 then return _falha('Descreva o que você precisa.'); end if;
  if char_length(v_txt) > 300 then return _falha('Descrição muito longa (máximo 300 caracteres).'); end if;
  select * into c from chat_conversas where id = v_id for update;
  if c.id is null then return _falha('Conversa não encontrada.'); end if;
  if c.estado = 'encerrada' then return _falha('Este atendimento foi encerrado.'); end if;
  v_aberto := _chat_caixa_aberto();
  if c.estado <> 'recepcao' then
    return jsonb_build_object('ok', true, 'jaTransferida', true, 'estado', c.estado, 'caixaAberto', v_aberto);
  end if;
  -- consistência entre intenção e tipo
  if c.intencao = 'antes_de_pedir' then v_tipo := 'antes_de_pedir';
  elsif v_tipo = 'antes_de_pedir' then v_tipo := 'outro'; end if;
  if c.intencao is null and c.venda_id is not null then c.intencao := 'pedido_feito'; end if;
  if c.intencao is null then c.intencao := case when v_tipo = 'antes_de_pedir' then 'antes_de_pedir' else 'pedido_feito' end; end if;

  if c.venda_id is not null and c.intencao = 'pedido_feito' then
    select * into ve from vendas where id = c.venda_id;
    v_rot := case v_tipo when 'atraso' then 'Atraso' when 'item_errado' then 'Item errado' when 'item_faltando' then 'Item faltando'
                         when 'cobranca' then 'Cobrança' when 'qualidade' then 'Qualidade' else 'Outro' end;
    v_otipo := case v_tipo when 'atraso' then 'Entrega' when 'cobranca' then 'Pagamento' when 'outro' then 'Atendimento' else 'Produção' end;
    insert into ocorrencias (tipo, setor, venda_id, cliente, telefone, registrado_por, descricao, status, historico)
    values (v_otipo, 'Outro', ve.id, ve.cliente_nome, ve.telefone_cliente, null,
            left('Chat do cliente — ' || v_rot || ': ' || coalesce(v_res, v_txt), 600), 'Aberta',
            jsonb_build_array(_agora_br() || ' — Cliente (chat): pediu atendimento da equipe'))
    returning id into v_oc;
  end if;

  insert into chat_mensagens (conversa_id, autor, texto) values (v_id, 'cliente', v_txt);
  insert into chat_mensagens (conversa_id, autor, texto) values (v_id, 'sistema',
    case when v_aberto then 'Pedido de ajuda enviado. Uma pessoa da equipe vai responder aqui.'
         else 'O restaurante está fechado agora. Sua mensagem ficou registrada e a resposta vem quando ele abrir.' end);
  update chat_conversas set estado = 'aguardando', tipo_problema = v_tipo, intencao = c.intencao, resumo = coalesce(v_res, v_txt), texto_original = v_txt,
    ocorrencia_id = v_oc, transferida_em = now(), atualizado_em = now(), nao_lidas_equipe = nao_lidas_equipe + 1
  where id = v_id;
  return jsonb_build_object('ok', true, 'estado', 'aguardando', 'caixaAberto', v_aberto);
end $function$
;

CREATE OR REPLACE FUNCTION public.chat_triagem_abrir(p jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_ip text := _ip_cliente(); c chat_conversas%rowtype; v_tok text;
begin
  if not _chat_ligado() then
    return jsonb_build_object('ok', false, 'desligado', true, 'message', 'O atendimento por chat está indisponível no momento.');
  end if;
  if not _chat_caixa_aberto() then
    return jsonb_build_object('ok', false, 'fechado', true, 'message', 'O restaurante está fechado agora. Volte no horário de atendimento.');
  end if;
  if _excedeu('triagem_ip_' || v_ip, 3) or _excedeu('triagem_global', 200) then
    return jsonb_build_object('ok', false, 'limite', true, 'message', 'Muitas tentativas seguidas. Aguarde alguns minutos.');
  end if;
  perform _registrar_falha('triagem_ip_' || v_ip, 3600);
  perform _registrar_falha('triagem_global', 86400);
  insert into chat_conversas (venda_id) values (null) returning * into c;
  v_tok := replace(gen_random_uuid()::text, '-', '') || replace(gen_random_uuid()::text, '-', '');
  insert into chat_tokens (conversa_id, token_hash) values (c.id, _chat_hash(v_tok));
  return jsonb_build_object('ok', true, 'conversaId', c.id, 'token', v_tok, 'estado', c.estado);
end $function$
;

CREATE OR REPLACE FUNCTION public.chat_vincular_pedido(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_id uuid := _uuid(p->>'conversaId'); v_tok text := coalesce(p->>'token', ''); v_ip text := _ip_cliente();
  v_nome text := left(_chat_limpar(p->>'nome'), 80);
  v_tel text := right(regexp_replace(coalesce(p->>'telefone', ''), '\D', '', 'g'), 11);
  cfg chat_config%rowtype; c chat_conversas%rowtype; v_venda uuid; v_outros int := 0;
  v_ok constant jsonb := jsonb_build_object('ok', true, 'message', 'Certo, vamos chamar a equipe.');
begin
  select * into cfg from chat_config where id;
  if not coalesce(cfg.chat_publico_ligado, false) then
    return jsonb_build_object('ok', false, 'desligado', true, 'message', 'O atendimento por chat está indisponível no momento.');
  end if;
  if v_id is null or length(v_tok) < 32 or length(v_tok) > 128 then return _falha('Conversa não encontrada.'); end if;
  if length(v_tel) < 10 or char_length(v_nome) < 2 then return _falha('Informe seu nome e o telefone com DDD.'); end if;
  if _excedeu('chat_ip_' || v_ip, 10) or _excedeu('chat_vinc_' || v_tel, 5) then
    return jsonb_build_object('ok', false, 'limite', true, 'message', 'Muitas tentativas seguidas. Aguarde alguns minutos.');
  end if;
  perform _registrar_falha('chat_vinc_' || v_tel, 3600);
  if not _chat_validar(v_id, v_tok) then
    perform _registrar_falha('chat_ip_' || v_ip, 600);
    return _falha('Conversa não encontrada.');
  end if;
  select * into c from chat_conversas where id = v_id for update;
  if c.id is null or c.estado <> 'recepcao' then return _falha('Conversa não encontrada.'); end if;

  select count(*) into v_outros from vendas
   where right(regexp_replace(coalesce(telefone_cliente, ''), '\D', '', 'g'), 11) = v_tel
     and data_hora >= now() - make_interval(hours => cfg.janela_horas);
  select v.id into v_venda from vendas v
   where right(regexp_replace(coalesce(v.telefone_cliente, ''), '\D', '', 'g'), 11) = v_tel
     and v.data_hora >= now() - make_interval(hours => cfg.janela_horas)
     and not exists (select 1 from chat_conversas x where x.venda_id = v.id and x.estado <> 'encerrada' and x.id <> v_id)
   order by v.data_hora desc limit 1;

  begin
    update chat_conversas set intencao = 'pedido_feito', nome_cliente = v_nome, telefone_cliente = v_tel,
      venda_id = v_venda, pedido_nao_localizado = (v_venda is null),
      outros_pedidos = greatest(v_outros - (case when v_venda is null then 0 else 1 end), 0), atualizado_em = now()
    where id = v_id;
  exception when unique_violation then
    update chat_conversas set intencao = 'pedido_feito', nome_cliente = v_nome, telefone_cliente = v_tel,
      venda_id = null, pedido_nao_localizado = true, atualizado_em = now() where id = v_id;
  end;
  return v_ok;   -- nunca revela se existe pedido
end $function$
;

CREATE OR REPLACE FUNCTION public.enfileirar_sync()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare reg jsonb; rid text;
begin
  if current_setting('txb.sem_fila', true) = 'on' then return null; end if;
  if tg_op = 'DELETE' then reg := to_jsonb(old); else reg := to_jsonb(new); end if;
  rid := coalesce(reg->>'id', reg->>'chave');
  insert into fila_sync (tabela, registro_id, operacao, payload)
  values (tg_table_name, rid, tg_op::op_sync, case when tg_op = 'DELETE' then null else reg end);
  return null;
end $function$
;

CREATE OR REPLACE FUNCTION public.entrega_atualizar_posicao(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_user uuid := auth.uid(); v_venda uuid; v_lat double precision; v_lng double precision; v_prec real;
  v_ent uuid; v_st text;
begin
  if v_user is null then return jsonb_build_object('ok', false, 'codigo', 'sem_login'); end if;
  begin
    v_venda := (p->>'vendaId')::uuid; v_lat := (p->>'lat')::double precision; v_lng := (p->>'lng')::double precision;
    v_prec := nullif(p->>'precisaoM', '')::real;
  exception when others then return jsonb_build_object('ok', false, 'codigo', 'dados_invalidos'); end;
  if v_lat is null or v_lng is null or v_lat not between -90 and 90 or v_lng not between -180 and 180 then
    return jsonb_build_object('ok', false, 'codigo', 'dados_invalidos'); end if;
  if v_prec is not null then v_prec := least(greatest(v_prec, 0), 5000); end if;
  select entregador_id, status_pedido::text into v_ent, v_st from vendas where id = v_venda;
  if v_ent is null or v_ent <> v_user then return jsonb_build_object('ok', false, 'codigo', 'sem_permissao'); end if;
  if v_st <> 'Saiu para entrega' then return jsonb_build_object('ok', false, 'codigo', 'fora_da_entrega'); end if;
  insert into entregador_posicoes (venda_id, entregador_id, lat, lng, precisao_m, atualizado_em)
  values (v_venda, v_user, v_lat, v_lng, v_prec, now())
  on conflict (venda_id) do update set lat = excluded.lat, lng = excluded.lng, precisao_m = excluded.precisao_m, atualizado_em = now(), entregador_id = excluded.entregador_id;
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.entrega_ver_posicao(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_nivel text := auth_nivel()::text; v_venda uuid; pos entregador_posicoes%rowtype; d entrega_destinos%rowtype; v_st text; v_seg int;
begin
  if v_nivel is null or v_nivel not in ('Admin', 'Operador') then return jsonb_build_object('ok', false, 'codigo', 'sem_permissao'); end if;
  begin v_venda := (p->>'vendaId')::uuid; exception when others then return jsonb_build_object('ok', false, 'codigo', 'dados_invalidos'); end;
  select status_pedido::text into v_st from vendas where id = v_venda;
  if v_st is null then return jsonb_build_object('ok', false, 'codigo', 'nao_encontrado'); end if;
  if v_st <> 'Saiu para entrega' then return jsonb_build_object('ok', true, 'estado', 'aguardando'); end if;
  select * into pos from entregador_posicoes where venda_id = v_venda;
  if not found then return jsonb_build_object('ok', true, 'estado', 'sem_posicao'); end if;
  v_seg := greatest(0, extract(epoch from (now() - pos.atualizado_em))::int);
  select * into d from entrega_destinos where venda_id = v_venda;
  return jsonb_build_object('ok', true, 'estado', case when v_seg > 300 then 'sem_sinal' else 'ok' end,
    'lat', pos.lat, 'lng', pos.lng, 'precisaoM', pos.precisao_m, 'atualizadoHaSeg', v_seg,
    'km', case when d.venda_id is not null then round(_dist_km(pos.lat, pos.lng, d.lat, d.lng)::numeric, 1) end,
    'destinoCompartilhado', d.venda_id is not null);
end $function$
;

CREATE OR REPLACE FUNCTION public.erro_limpa_(t text, n integer DEFAULT 300)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
  select left(regexp_replace(regexp_replace(regexp_replace(regexp_replace(ia_limpa_(t, 2000),
         'eyJ[[:alnum:]_.-]{20,}', '[token]', 'g'),
         '(apikey|token|senha|password|authorization|bearer)[=: ]+[^ ]+', '\1=[oculto]', 'gi'),
         '\?[^ )]*', '', 'g'),
         '[<>]', ' ', 'g'), n)
$function$
;

CREATE OR REPLACE FUNCTION public.ia_agregar(p_tabela text, p_coluna text, p_ini date DEFAULT NULL::date, p_fim date DEFAULT NULL::date, p_busca text DEFAULT NULL::text)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  adm boolean := tem_nivel('Admin');
  tz constant text := 'America/Sao_Paulo';
  t text := lower(btrim(coalesce(p_tabela, '')));
  c text := lower(btrim(coalesce(p_coluna, '')));
  b text := nullif(replace(replace(btrim(coalesce(p_busca, '')), '%', ''), '_', ''), '');
  dcol text; dtipo text; ctipo text; dexpr text := 'true'; dd text := 'null::date'; kx text; sql text; r jsonb;
begin
  if not tem_nivel('Admin','Operador') then return jsonb_build_object('ok', false, 'message', 'Sem permissão.'); end if;
  if not (t = any(public._ia_tabelas(adm))) then return jsonb_build_object('ok', false, 'message', 'Tabela não disponível para o seu perfil.'); end if;
  select c2.column_name::text, c2.data_type::text into dcol, dtipo
    from information_schema.columns c2
   where c2.table_schema = 'public' and c2.table_name::text = t
     and c2.column_name::text in ('data_hora','data','criado_em','abertura','atualizada_em','recebido_em')
   order by array_position(array['data_hora','data','criado_em','abertura','atualizada_em','recebido_em'], c2.column_name::text) limit 1;
  if dcol is not null then
    dd := case when dtipo = 'date' then format('t.%I', dcol) else format('(t.%I at time zone %L)::date', dcol, tz) end;
  end if;
  if c in ('dia','mes') then
    if dcol is null then return jsonb_build_object('ok', false, 'message', 'Esta tabela não tem coluna de data para agrupar por dia/mês.'); end if;
    kx := format('to_char(d, %L)', case when c = 'dia' then 'YYYY-MM-DD' else 'YYYY-MM' end);
  else
    select c3.data_type::text into ctipo from information_schema.columns c3
     where c3.table_schema = 'public' and c3.table_name::text = t and c3.column_name::text = c;
    if ctipo is null or public._ia_oculta(c, adm) then return jsonb_build_object('ok', false, 'message', 'Coluna não disponível para agrupar (use o nome exato do catálogo, ou "dia"/"mes").'); end if;
    kx := format('coalesce(nullif(m->>%L, %L), %L)', c, '', '(vazio)');
  end if;
  if p_ini is not null or p_fim is not null then
    if p_ini is null or p_fim is null or p_fim < p_ini or (p_fim - p_ini) > 732 then
      return jsonb_build_object('ok', false, 'message', 'Período inválido (máx. 2 anos).');
    end if;
    if dcol is not null then dexpr := format('%s between %L::date and %L::date', dd, p_ini, p_fim); end if;
  end if;
  sql := format($q$
    with f as (select public._ia_mascara(to_jsonb(t), $1) m, %s d from public.%I t where %s),
    g as (select m, d from f where $2::text is null or m::text ilike '%%' || $2 || '%%'),
    k as (select %s as chave, m from g),
    cnt as (select chave, count(*) qtd from k group by 1 order by 2 desc limit 60),
    sm as (select k.chave, e.key kk, sum((e.value #>> '{}')::numeric) vv
             from k join cnt on cnt.chave = k.chave, jsonb_each(k.m) e
            where $1 and jsonb_typeof(e.value) = 'number' and e.key <> %L
              and e.key not in ('id','ordem','numero','numero_pedido','prazo_dias','capacidade','ordem_cardapio')
            group by 1, 2)
    select jsonb_build_object(
      'total', (select count(*) from g),
      'grupos', coalesce((select jsonb_agg(jsonb_build_object('chave', cnt.chave, 'qtd', cnt.qtd)
            || case when $1 then jsonb_build_object('somas', coalesce((select jsonb_object_agg(sm.kk, sm.vv) from sm where sm.chave = cnt.chave), '{}'::jsonb)) else '{}'::jsonb end
            order by cnt.qtd desc) from cnt), '[]'::jsonb))
  $q$, dd, t, dexpr, kx, c);
  execute sql into r using adm, b;
  return jsonb_build_object('ok', true, 'tabela', t, 'agrupado_por', c, 'periodo', case when p_ini is null then null else p_ini::text || ' a ' || p_fim::text end,
                            'aviso', 'Mostra até 60 grupos, os maiores primeiro.') || r;
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_ajuda_buscar(p_pergunta text, p_perfil text DEFAULT NULL::text)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare q text; r jsonb; v_real text := (select nivel::text from usuarios where id = auth.uid() and ativo);
        v_nivel text := auth_nivel()::text; v_alvo text; v_todos boolean;
begin
  if v_real is null or v_nivel is null then return jsonb_build_object('ok', false, 'message', 'Sem permissão.'); end if;
  v_todos := (v_real = 'Desenvolvedor' and p_perfil is null);
  v_alvo := case when v_real = 'Desenvolvedor' and p_perfil in ('Admin','Operador','Garçom','Cozinha','Entregador') then p_perfil else v_nivel end;
  -- palavras da pergunta (sem acento) + sinônimos de uso comum, para "funcionário" achar "usuário", "apagar" achar "excluir" etc.
  select string_agg(distinct w, ' | ') into q from (
    with base as (
      select distinct regexp_replace(translate(lower(x), 'áàâãäéèêëíìîïóòôõöúùûüç', 'aaaaaeeeeiiiiooooouuuuc'), '[^a-z0-9]', '', 'g') w
        from regexp_split_to_table(left(coalesce(p_pergunta, ''), 500), '\s+') x)
    select w from base
     where length(w) >= 3 and w not in ('como','que','uma','uns','para','por','com','eu','posso','fazer','faco','onde','qual','quais','meu','minha','nao','sistema','tem','dos','das','nos','nas','mais','esse','essa','isso','quero','preciso','ver')
    union
    select s from base b, lateral unnest(case
        when b.w in ('funcionario','funcionaria','funcionarios','colaborador','colaboradora','colaboradores','empregado','empregada','atendente','atendentes') then array['usuario','acesso','login','perfil']
        when b.w in ('cadastrar','cadastro','cadastrei','registrar','incluir','criar','adicionar','inserir','novo','nova') then array['cadastrar','criar']
        when b.w in ('apagar','deletar','remover','tirar','excluir') then array['excluir','remover']
        when b.w in ('menu','cardapios') then array['cardapio','produto']
        when b.w in ('comanda','comandas') then array['pedido','venda']
        when b.w in ('motoboy','motoqueiro','entregadores') then array['entregador','entrega']
        else array[]::text[] end) s
     where length(b.w) >= 3
  ) z where w is not null and w <> '';
  if q is null then return jsonb_build_object('ok', true, 'topicos', '[]'::jsonb); end if;
  select coalesce(jsonb_agg(jsonb_build_object('titulo', titulo, 'passos', passos, 'perfis', perfis) order by rk desc), '[]'::jsonb) into r from (
   select * from (
    select titulo, passos, perfis, ts_rank(
             setweight(to_tsvector('portuguese', translate(lower(titulo), 'áàâãäéèêëíìîïóòôõöúùûüç', 'aaaaaeeeeiiiiooooouuuuc')), 'A') ||
             setweight(to_tsvector('portuguese', translate(lower(palavras_chave), 'áàâãäéèêëíìîïóòôõöúùûüç', 'aaaaaeeeeiiiiooooouuuuc')), 'B') ||
             setweight(to_tsvector('portuguese', translate(lower(passos), 'áàâãäéèêëíìîïóòôõöúùûüç', 'aaaaaeeeeiiiiooooouuuuc')), 'C'),
             to_tsquery('portuguese', q)) rk
      from ai_ajuda where ativo and (v_todos or v_alvo = any(perfis))) m
   where rk > 0 order by rk desc limit 3) z;
  return jsonb_build_object('ok', true, 'topicos', coalesce(r, '[]'::jsonb));
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_alerta_(cod text, sev text, titulo text, valor numeric, ref numeric DEFAULT NULL::numeric, det jsonb DEFAULT NULL::jsonb)
 RETURNS jsonb
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
  select jsonb_strip_nulls(jsonb_build_object('codigo', cod, 'severidade', sev, 'titulo', titulo, 'valor', valor, 'referencia', ref, 'detalhe', det))
$function$
;

CREATE OR REPLACE FUNCTION public.ia_anomalias(p_data date DEFAULT NULL::date)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'public'
AS $function$
declare
  hoje date := (now() at time zone 'America/Sao_Paulo')::date;
  d date; res jsonb := '[]'::jsonb; a jsonb; t jsonb; i int; n int := 0; sf numeric := 0; media numeric;
  fat numeric; ped int; canc int; m_dia numeric; m_base numeric; b28 jsonb; x record; qtd int; val numeric;
begin
  if not tem_nivel('Admin','Operador') then
    return jsonb_build_object('ok', false, 'message', 'Sem permissão.');
  end if;
  d := coalesce(p_data, hoje);
  a := ia_totais_(d, d);
  fat := (a->>'faturamento')::numeric; ped := (a->>'pedidos')::int; canc := (a->>'cancelados')::int;

  for i in 1..4 loop
    t := ia_totais_(d - 7 * i, d - 7 * i);
    if (t->>'pedidos')::int > 0 then n := n + 1; sf := sf + (t->>'faturamento')::numeric; end if;
  end loop;
  if n >= 2 then media := sf / n; end if;

  if d < hoje and media > 0 then
    if fat < media * 0.6 then
      res := res || ia_alerta_('FATURAMENTO_BAIXO','media','Faturamento do dia bem abaixo da média do mesmo dia da semana', fat, round(media,2));
    elsif fat > media * 1.5 then
      res := res || ia_alerta_('FATURAMENTO_ALTO','info','Faturamento do dia bem acima da média do mesmo dia da semana', fat, round(media,2));
    end if;
  end if;

  if canc >= 3 and canc::numeric / (ped + canc) >= 0.15 then
    res := res || ia_alerta_('CANCELAMENTOS_ALTOS','alta','Muitos cancelamentos no dia', canc, ped + canc);
  end if;

  if fat > 0 and ped >= 5 then
    m_dia := (fat - (a->>'custo')::numeric - (a->>'taxas')::numeric) / fat * 100;
    b28 := ia_totais_(d - 28, d - 1);
    if (b28->>'faturamento')::numeric > 0 then
      m_base := ((b28->>'faturamento')::numeric - (b28->>'custo')::numeric - (b28->>'taxas')::numeric) / (b28->>'faturamento')::numeric * 100;
      if m_dia < m_base - 5 then
        res := res || ia_alerta_('MARGEM_EM_QUEDA','media','Margem do dia mais de 5 pontos abaixo dos últimos 28 dias', round(m_dia,1), round(m_base,1));
      end if;
    end if;
  end if;

  if d = hoje then
    select count(*) into qtd from vendas
     where status = 'Confirmada' and status_pedido in ('Recebido','Em preparo','Pronta')
       and data_hora < now() - interval '60 minutes' and data_hora >= now() - interval '12 hours';
    if qtd > 0 then res := res || ia_alerta_('PEDIDOS_PARADOS','alta','Pedidos há mais de 60 min sem andamento', qtd); end if;
  end if;

  select count(*) into qtd from vendas
   where status = 'Confirmada' and status_pedido = 'Suspenso' and data_hora >= now() - interval '24 hours';
  if qtd > 0 then res := res || ia_alerta_('PEDIDOS_SUSPENSOS','media','Pedidos suspensos nas últimas 24 h', qtd); end if;

  select count(*) filter (where quantidade <= 0) as zerados,
         count(*) filter (where quantidade <= quantidade_minima and quantidade_minima > 0) as baixos,
         coalesce(jsonb_agg(ingrediente) filter (where quantidade <= quantidade_minima and quantidade_minima > 0), '[]'::jsonb) as nomes
    into x from (select ingrediente, quantidade, quantidade_minima from estoque where status = 'Ativo'
                 order by case when quantidade_minima > 0 then quantidade / quantidade_minima else 9999 end limit 200) e;
  if x.zerados > 0 then res := res || ia_alerta_('ESTOQUE_ZERADO','alta','Ingredientes com estoque zerado', x.zerados); end if;
  if x.baixos > 0 then
    res := res || ia_alerta_('ESTOQUE_BAIXO','media','Ingredientes no mínimo ou abaixo', x.baixos, null, (select jsonb_agg(v) from (select jsonb_array_elements(x.nomes) v limit 5) q));
  end if;

  select diferenca into val from caixa_sessoes
   where status = 'Fechado' and fechamento >= now() - interval '7 days' and diferenca is not null and diferenca <> 0
   order by fechamento desc limit 1;
  if val is not null then
    res := res || ia_alerta_('CAIXA_DIFERENCA', case when abs(val) >= 20 then 'alta' else 'baixa' end, 'Diferença no último fechamento de caixa', val);
  end if;

  select count(*), coalesce(sum(valor),0) into qtd, val from despesas where status = 'A pagar' and vencimento < hoje;
  if qtd > 0 then res := res || ia_alerta_('CONTAS_VENCIDAS','media','Contas a pagar vencidas', val, qtd); end if;

  select count(*), coalesce(sum(valor_total),0) into qtd, val from vendas
   where status = 'Confirmada' and status_pagamento = 'A Receber'
     and status_pedido in ('Entregue','Retirada','Servida') and data_hora < now() - interval '24 hours';
  if qtd > 0 then res := res || ia_alerta_('A_RECEBER_ANTIGO','media','Vendas concluídas há mais de 24 h ainda a receber', val, qtd); end if;

  return jsonb_build_object('ok', true, 'data', d, 'parcial', d = hoje, 'alertas', res);
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_catalogo()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare adm boolean := tem_nivel('Admin'); r text;
begin
  if not tem_nivel('Admin','Operador') then return jsonb_build_object('ok', false, 'message', 'Sem permissão.'); end if;
  select string_agg(t || '(' || cols || ')', '; ' order by t) into r
  from (select c.table_name::text t, string_agg(c.column_name::text, ',' order by c.ordinal_position) cols
        from information_schema.columns c
        where c.table_schema = 'public' and c.table_name::text = any(public._ia_tabelas(adm))
          and not public._ia_oculta(c.column_name::text, adm)
        group by c.table_name) x;
  return jsonb_build_object('ok', true, 'tabelas', coalesce(r,'') || '. PRIVACIDADE: telefone, endereço, localização, e-mail, CPF, nascimento, login e senhas dos clientes e usuários são ocultos de propósito e nunca devem ser informados nem inventados.');
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_codigo_catalogo()
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if coalesce(ia_nivel_real(), '') <> 'Desenvolvedor' then return jsonb_build_object('ok', false, 'message', 'Sem permissão.'); end if;
  return jsonb_build_object('ok', true,
    'funcoes', coalesce((select jsonb_agg(distinct p.proname) from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname = 'public'), '[]'::jsonb),
    'tabelas', coalesce((select jsonb_agg(c.relname) from pg_class c join pg_namespace n on n.oid = c.relnamespace where n.nspname = 'public' and c.relkind in ('r', 'v', 'm', 'p')), '[]'::jsonb));
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_codigo_faltantes(p_arquivo text, p_hashes jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if coalesce(ia_nivel_real(), '') <> 'Desenvolvedor' then return jsonb_build_object('ok', false, 'message', 'Sem permissão.'); end if;
  if p_arquivo not in ('index.html', 'texas-burger-planilha.gs', 'texas-burger-contingencia.gs') then return jsonb_build_object('ok', false, 'message', 'Arquivo desconhecido.'); end if;
  if jsonb_typeof(p_hashes) <> 'array' or jsonb_array_length(p_hashes) > 400 then return jsonb_build_object('ok', false, 'message', 'Lista de hashes inválida.'); end if;
  return jsonb_build_object('ok', true, 'faltantes', coalesce((
    select jsonb_agg(h.v) from (select distinct jsonb_array_elements_text(p_hashes) as v) h
    where not exists (select 1 from codigo_snapshots s where s.arquivo = p_arquivo and s.hash = h.v)
  ), '[]'::jsonb));
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_codigo_gravar(p_arquivo text, p_versao text, p_blocos jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare b jsonb; v_hash text; v_novos int := 0; v_tot bigint := 0;
begin
  if coalesce(ia_nivel_real(), '') <> 'Desenvolvedor' then return jsonb_build_object('ok', false, 'message', 'Sem permissão.'); end if;
  if p_arquivo not in ('index.html', 'texas-burger-planilha.gs', 'texas-burger-contingencia.gs') then return jsonb_build_object('ok', false, 'message', 'Arquivo desconhecido.'); end if;
  if jsonb_typeof(p_blocos) <> 'array' or jsonb_array_length(p_blocos) > 40 then return jsonb_build_object('ok', false, 'message', 'Lote de blocos inválido (máx. 40).'); end if;
  for b in select * from jsonb_array_elements(p_blocos) loop
    if coalesce(b->>'conteudo', '') = '' or length(b->>'conteudo') > 150000 then return jsonb_build_object('ok', false, 'message', 'Bloco vazio ou grande demais.'); end if;
    v_hash := encode(sha256(convert_to(b->>'conteudo', 'UTF8')), 'hex');
    if v_hash <> coalesce(b->>'hash', '') then return jsonb_build_object('ok', false, 'message', 'Hash do bloco ' || coalesce(b->>'bloco', '?') || ' não confere com o conteúdo.'); end if;
    v_tot := v_tot + length(b->>'conteudo');
    insert into codigo_snapshots (arquivo, bloco, hash, conteudo, versao, enviado_por)
      values (p_arquivo, (b->>'bloco')::int, v_hash, b->>'conteudo', left(p_versao, 40), auth.uid())
      on conflict (arquivo, bloco, hash) do nothing;
    if found then v_novos := v_novos + 1; end if;
  end loop;
  return jsonb_build_object('ok', true, 'novos', v_novos, 'bytes', v_tot);
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_codigo_registrar_versao(p_arquivo text, p_versao text, p_blocos jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare b jsonb; v_total text; v_id bigint; v_existente bigint;
begin
  if coalesce(ia_nivel_real(), '') <> 'Desenvolvedor' then return jsonb_build_object('ok', false, 'message', 'Sem permissão.'); end if;
  if p_arquivo not in ('index.html', 'texas-burger-planilha.gs', 'texas-burger-contingencia.gs') then return jsonb_build_object('ok', false, 'message', 'Arquivo desconhecido.'); end if;
  if jsonb_typeof(p_blocos) <> 'array' or jsonb_array_length(p_blocos) = 0 or jsonb_array_length(p_blocos) > 400 then return jsonb_build_object('ok', false, 'message', 'Manifesto inválido.'); end if;
  for b in select * from jsonb_array_elements(p_blocos) loop
    if not exists (select 1 from codigo_snapshots s where s.arquivo = p_arquivo and s.hash = b->>'hash') then
      return jsonb_build_object('ok', false, 'message', 'Bloco ' || coalesce(b->>'bloco', '?') || ' ainda não foi enviado.');
    end if;
  end loop;
  select md5(string_agg(e->>'hash', ',' order by (e->>'bloco')::int)) into v_total from jsonb_array_elements(p_blocos) e;
  select id into v_existente from codigo_versoes where arquivo = p_arquivo and hash_total = v_total;
  if v_existente is not null then return jsonb_build_object('ok', true, 'igual', true, 'id', v_existente, 'blocos', jsonb_array_length(p_blocos)); end if;
  insert into codigo_versoes (arquivo, versao, hash_total, blocos, enviado_por)
    values (p_arquivo, left(p_versao, 40), v_total, p_blocos, auth.uid()) returning id into v_id;
  return jsonb_build_object('ok', true, 'igual', false, 'id', v_id, 'blocos', jsonb_array_length(p_blocos));
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_comparativo(p_ini date, p_fim date)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'public'
AS $function$
declare
  len int; a jsonb; b jsonb; t jsonb; i int; n int := 0; sf numeric := 0; sp numeric := 0;
  fa numeric; fb numeric; pa int; pb int; sem jsonb := null;
begin
  if not tem_nivel('Admin','Operador') then
    return jsonb_build_object('ok', false, 'message', 'Sem permissão.');
  end if;
  if p_ini is null or p_fim is null or p_fim < p_ini or (p_fim - p_ini) > 92 then
    return jsonb_build_object('ok', false, 'message', 'Período inválido.');
  end if;
  len := p_fim - p_ini + 1;
  a := ia_totais_(p_ini, p_fim);
  b := ia_totais_(p_ini - len, p_ini - 1);
  fa := (a->>'faturamento')::numeric; fb := (b->>'faturamento')::numeric;
  pa := (a->>'pedidos')::int;         pb := (b->>'pedidos')::int;
  if p_ini = p_fim then
    for i in 1..4 loop
      t := ia_totais_(p_ini - 7 * i, p_ini - 7 * i);
      if (t->>'pedidos')::int > 0 then n := n + 1; sf := sf + (t->>'faturamento')::numeric; sp := sp + (t->>'pedidos')::int; end if;
    end loop;
    if n > 0 then
      sem := jsonb_build_object('dias_base', n, 'media_faturamento', round(sf / n, 2), 'media_pedidos', round(sp / n, 1),
               'var_faturamento_pct', case when sf > 0 then round((fa - sf / n) / (sf / n) * 100, 1) end);
    end if;
  end if;
  return jsonb_build_object('ok', true,
    'atual',    jsonb_build_object('faturamento', fa, 'pedidos', pa),
    'anterior', jsonb_build_object('ini', p_ini - len, 'fim', p_ini - 1, 'faturamento', fb, 'pedidos', pb),
    'var_faturamento_pct', case when fb > 0 then round((fa - fb) / fb * 100, 1) end,
    'var_pedidos_pct',     case when pb > 0 then round((pa - pb)::numeric / pb * 100, 1) end,
    'mesmo_dia_da_semana', sem);
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_consulta(p_tipo text, p_ini date, p_fim date, p_busca text DEFAULT NULL::text)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  tz constant text := 'America/Sao_Paulo';
  adm boolean := tem_nivel('Admin');
  t_ini timestamptz; t_fim timestamptz; b text := nullif(btrim(coalesce(p_busca,'')), '');
begin
  if not tem_nivel('Admin','Operador') then return jsonb_build_object('ok', false, 'message', 'Sem permissão.'); end if;
  if p_ini is null or p_fim is null or p_fim < p_ini or (p_fim - p_ini) > 92 then return jsonb_build_object('ok', false, 'message', 'Período inválido (máx. 93 dias).'); end if;
  t_ini := (p_ini::timestamp at time zone tz); t_fim := ((p_fim + 1)::timestamp at time zone tz);
  if p_tipo = 'resumo' then
    return jsonb_build_object('ok', true, 'tipo', p_tipo, 'resumo', ia_periodo_(p_ini, p_fim, adm),
      'top_produtos', ia_top_produtos_(p_ini, p_fim, adm, 10, 'mais'));
  elsif p_tipo = 'serie_diaria' then
    return jsonb_build_object('ok', true, 'tipo', p_tipo, 'dias', coalesce((select jsonb_agg(
        jsonb_build_object('dia', dia, 'pedidos', n) || case when adm then jsonb_build_object('faturamento', v) else '{}'::jsonb end order by dia)
      from (select (data_hora at time zone tz)::date dia, count(*) n, sum(valor_total) v from vendas where status::text='Confirmada' and data_hora>=t_ini and data_hora<t_fim group by 1) x), '[]'::jsonb));
  elsif p_tipo = 'produto' then
    if b is null then return jsonb_build_object('ok', false, 'message', 'Informe o nome do produto.'); end if;
    return jsonb_build_object('ok', true, 'tipo', p_tipo, 'busca', b, 'produtos', coalesce((select jsonb_agg(
        jsonb_build_object('produto', d, 'qtd', q) || case when adm then jsonb_build_object('valor', v) else '{}'::jsonb end order by q desc)
      from (select iv.descricao d, sum(iv.quantidade) q, sum(iv.valor_total_item) v from itens_venda iv join vendas ve on ve.id=iv.venda_id
            where ve.status::text='Confirmada' and ve.data_hora>=t_ini and ve.data_hora<t_fim and iv.descricao ilike '%' || replace(replace(b,'%',''),'_','') || '%' group by 1 order by 2 desc limit 10) x), '[]'::jsonb));
  elsif p_tipo = 'cliente' then
    if not adm then return jsonb_build_object('ok', false, 'message', 'Só o Administrador consulta clientes.'); end if;
    if b is null then return jsonb_build_object('ok', false, 'message', 'Informe o nome do cliente.'); end if;
    return jsonb_build_object('ok', true, 'tipo', p_tipo, 'busca', b, 'clientes', coalesce((select jsonb_agg(jsonb_build_object('nome', n, 'pedidos', p, 'gasto', g, 'ultimo_pedido', u))
      from (select ve.cliente_nome n, count(*) p, sum(ve.valor_total) g, to_char(max(ve.data_hora) at time zone tz, 'DD/MM/YYYY') u from vendas ve
            where ve.status::text='Confirmada' and ve.data_hora>=t_ini and ve.data_hora<t_fim and ve.cliente_nome ilike '%' || replace(replace(b,'%',''),'_','') || '%' group by 1 order by 3 desc limit 5) x), '[]'::jsonb));
  elsif p_tipo = 'despesas' then
    if not adm then return jsonb_build_object('ok', false, 'message', 'Só o Administrador consulta despesas.'); end if;
    return jsonb_build_object('ok', true, 'tipo', p_tipo, 'por_categoria', coalesce((select jsonb_agg(jsonb_build_object('categoria', coalesce(cat,'Sem categoria'), 'status', st, 'total', v, 'qtd', n) order by v desc)
      from (select categoria::text cat, status::text st, sum(valor) v, count(*) n from despesas where data_hora>=t_ini and data_hora<t_fim and status::text <> 'Cancelada' group by 1,2) x), '[]'::jsonb));
  end if;
  return jsonb_build_object('ok', false, 'message', 'Tipo de consulta desconhecido.');
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_contexto_geral()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  tz constant text := 'America/Sao_Paulo';
  adm boolean := tem_nivel('Admin');
  h date := (now() at time zone tz)::date;
  d0 timestamptz := ((now() at time zone tz)::date::timestamp at time zone tz);
  r jsonb; cx record;
begin
  if not tem_nivel('Admin','Operador') then return jsonb_build_object('ok', false, 'message', 'Sem permissão.'); end if;

  r := jsonb_build_object(
    'ok', true,
    'agora', to_char(now() at time zone tz, 'DD/MM/YYYY HH24:MI'),
    'dia_semana', trim(to_char(now() at time zone tz, 'TMDay')),
    'perfil', case when adm then 'Admin' else 'Operador' end,
    'periodos', jsonb_build_object(
      'hoje', ia_periodo_(h, h, adm),
      'ontem', ia_periodo_(h-1, h-1, adm),
      'ultimos_7_dias', ia_periodo_(h-6, h, adm),
      'ultimos_30_dias', ia_periodo_(h-29, h, adm),
      'mes_atual', ia_periodo_(date_trunc('month', h)::date, h, adm)),
    'top_produtos_hoje', ia_top_produtos_(h, h, adm, 8, 'mais'),
    'top_produtos_30d', ia_top_produtos_(h-29, h, adm, 10, 'mais'),
    'menos_vendidos_30d', ia_top_produtos_(h-29, h, adm, 5, 'menos'),
    'pedidos_por_hora_30d', coalesce((select jsonb_object_agg(hh, n) from (select extract(hour from data_hora at time zone tz)::int hh, count(*) n from vendas where status::text='Confirmada' and data_hora >= now() - interval '30 days' group by 1) x), '{}'::jsonb),
    'pedidos_por_dia_semana_30d', coalesce((select jsonb_object_agg(dw, n) from (select trim(to_char(data_hora at time zone tz, 'TMDay')) dw, count(*) n from vendas where status::text='Confirmada' and data_hora >= now() - interval '30 days' group by 1) x), '{}'::jsonb),
    'producao', (ia_producao_operacional() - 'ok'),
    'entregas', (ia_entregas_operacional() - 'ok'),
    'estoque', (ia_estoque_operacional() - 'ok'),
    'pedidos_em_andamento', coalesce((select jsonb_agg(jsonb_build_object('pedido', v.numero_pedido, 'tipo', v.tipo::text, 'status', v.status_pedido::text, 'minutos_desde_recebido', floor(extract(epoch from now() - coalesce(v.recebido_em, v.data_hora))/60), 'origem', v.origem::text, 'mesa', m.numero) || case when adm then jsonb_build_object('valor', v.valor_total) else '{}'::jsonb end order by coalesce(v.recebido_em, v.data_hora))
        from (select * from vendas where status::text='Confirmada' and status_pedido::text in ('Recebido','Em preparo','Pronta','Saiu para entrega','Suspenso') order by coalesce(recebido_em, data_hora) limit 25) v left join mesas m on m.id = v.mesa_id), '[]'::jsonb),
    'mesas', jsonb_build_object(
      'por_status', coalesce((select jsonb_object_agg(s, n) from (select status::text s, count(*) n from mesas group by 1) x), '{}'::jsonb),
      'chamados', coalesce((select jsonb_agg(jsonb_build_object('mesa', numero, 'chamado', chamado_tipo::text)) from mesas where chamado_tipo is not null and chamado_tipo::text <> ''), '[]'::jsonb)),
    'cupons_ativos', coalesce((select jsonb_agg(jsonb_build_object('codigo', codigo, 'nome', nome, 'tipo', tipo::text, 'valor', valor, 'frete_gratis', frete_gratis, 'valor_minimo', valor_minimo, 'ate', data_fim)) from (select * from cupons where ativa and (data_fim is null or data_fim >= h) order by criado_em desc limit 10) c), '[]'::jsonb),
    'formas_pagamento', coalesce((select jsonb_agg(jsonb_build_object('nome', nome, 'permite_troco', permite_troco) || case when adm then jsonb_build_object('taxa_percentual', taxa_percentual, 'taxa_fixa', taxa_fixa, 'prazo_dias', prazo_dias) else '{}'::jsonb end order by ordem) from formas_pagamento where ativa), '[]'::jsonb),
    'feedbacks_30d', jsonb_build_object(
      'quantidade', (select count(*) from feedbacks where data >= now() - interval '30 days'),
      'nota_media', (select round(avg(nota)::numeric, 2) from feedbacks where data >= now() - interval '30 days'),
      'recentes', coalesce((select jsonb_agg(jsonb_build_object('nota', nota, 'comentario', public._ia_scrub(left(coalesce(comentario,''), 140)))) from (select * from feedbacks order by data desc limit 5) f), '[]'::jsonb)),
    'ocorrencias_abertas', jsonb_build_object(
      'quantidade', (select count(*) from ocorrencias where status::text <> 'Resolvida'),
      'recentes', coalesce((select jsonb_agg(jsonb_build_object('numero', numero, 'tipo', tipo::text, 'setor', setor::text, 'status', status::text, 'descricao', public._ia_scrub(left(coalesce(descricao,''), 140)))) from (select * from ocorrencias where status::text <> 'Resolvida' order by data_hora desc limit 5) o), '[]'::jsonb)),
    'cardapio', jsonb_build_object(
      'produtos', coalesce((select jsonb_agg(jsonb_build_object('nome', p.nome, 'categoria', c.nome, 'preco_de', pr.pmin, 'preco_ate', pr.pmax, 'esgotado', exists(select 1 from v_cardapio_esgotados e where e.id = p.id)) order by c.ordem, p.ordem_cardapio)
          from v_cardapio_produtos p left join v_cardapio_categorias c on c.id = p.categoria_id
          left join lateral (select min(preco) pmin, max(preco) pmax from v_cardapio_precos x where x.item_id = p.id and x.tipo = 'produto') pr on true), '[]'::jsonb),
      'combos', coalesce((select jsonb_agg(jsonb_build_object('nome', b.nome, 'preco_de', pr.pmin, 'preco_ate', pr.pmax, 'esgotado', exists(select 1 from v_cardapio_esgotados e where e.id = b.id)))
          from v_cardapio_combos b left join lateral (select min(preco) pmin, max(preco) pmax from v_cardapio_precos x where x.item_id = b.id and x.tipo <> 'produto') pr on true), '[]'::jsonb))
  );

  select * into cx from caixa_sessoes where status::text = 'Aberto' order by abertura desc limit 1;
  if found then
    r := r || jsonb_build_object('caixa', jsonb_build_object('aberto', true, 'desde', to_char(cx.abertura at time zone tz, 'DD/MM HH24:MI'), 'fundo_caixa', cx.fundo_caixa,
      'sangrias', coalesce((select sum(valor) from sangrias where caixa_id = cx.id), 0),
      'pedidos_na_sessao', (select count(*) from vendas where caixa_id = cx.id and status::text='Confirmada')));
    if adm then
      r := jsonb_set(r, '{caixa,vendas_na_sessao}', to_jsonb(coalesce((select sum(valor_total) from vendas where caixa_id = cx.id and status::text='Confirmada'), 0)));
    end if;
  else
    r := r || jsonb_build_object('caixa', jsonb_build_object('aberto', false));
  end if;

  if adm then
    r := r || jsonb_build_object(
      'despesas', jsonb_build_object(
        'a_pagar_vencidas', jsonb_build_object('qtd', (select count(*) from despesas where status::text='A pagar' and vencimento < h), 'total', coalesce((select sum(valor) from despesas where status::text='A pagar' and vencimento < h),0)),
        'a_pagar_proximos_7_dias', jsonb_build_object('qtd', (select count(*) from despesas where status::text='A pagar' and vencimento >= h and vencimento <= h+7), 'total', coalesce((select sum(valor) from despesas where status::text='A pagar' and vencimento >= h and vencimento <= h+7),0)),
        'pagas_30d_por_categoria', coalesce((select jsonb_object_agg(coalesce(cat,'Sem categoria'), v) from (select categoria::text cat, sum(valor) v from despesas where status::text='Paga' and data_hora >= now() - interval '30 days' group by 1 order by 2 desc limit 10) x), '{}'::jsonb)),
      'clientes', jsonb_build_object(
        'total', (select count(*) from clientes),
        'novos_30d', (select count(*) from clientes where criado_em >= now() - interval '30 days'),
        'melhores_30d', coalesce((select jsonb_agg(jsonb_build_object('nome', n, 'pedidos', p, 'gasto', g)) from (select ve.cliente_nome n, count(*) p, sum(ve.valor_total) g from vendas ve where ve.status::text='Confirmada' and ve.data_hora >= now() - interval '30 days' and coalesce(ve.cliente_nome,'') <> '' group by 1 order by 3 desc limit 5) x), '[]'::jsonb)),
      'eventos_proximos', coalesce((select jsonb_agg(jsonb_build_object('nome', nome, 'data', data, 'status', status::text, 'a_receber', valor_a_receber)) from (select * from eventos where data >= h order by data limit 5) e), '[]'::jsonb),
      'estoque_valor_total', (select coalesce(sum(quantidade * coalesce(custo_unitario,0)),0) from estoque where quantidade > 0)
    );
  end if;
  return r;
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_cota_tentar(p_user uuid, p_nivel text DEFAULT 'Admin'::text)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c ai_config; g int; u int; lim int; hoje date := (now() at time zone 'America/Sao_Paulo')::date;
begin
  select * into c from ai_config where id;
  select coalesce(sum(chamadas),0) into g from ai_uso where dia = hoje;
  select coalesce(sum(chamadas),0) into u from ai_uso where dia = hoje and usuario_id = p_user;
  lim := case when p_nivel = 'Operador' then c.cota_diaria_operador
              when p_nivel in ('Garçom','Cozinha','Entregador') then least(c.cota_diaria_operador, 15)
              else c.cota_diaria_usuario end;
  if g >= c.cota_diaria_global then return jsonb_build_object('ok', false, 'motivo', 'cota_global'); end if;
  if u >= lim then return jsonb_build_object('ok', false, 'motivo', 'cota_usuario'); end if;
  return jsonb_build_object('ok', true, 'restante_usuario', lim - u, 'restante_global', c.cota_diaria_global - g);
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_cron_status_()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'cron'
AS $function$
begin
  if coalesce(ia_nivel_real(), '') <> 'Desenvolvedor' then return jsonb_build_object('ok', false); end if;
  return jsonb_build_object('ok', true,
    'jobs_ativos', (select count(*) from cron.job where active),
    'falhas_7d', coalesce((select jsonb_agg(jsonb_build_object('job', j.jobname, 'falhas', f.n, 'ultima_msg', ia_limpa_(f.msg, 150)) order by f.n desc)
        from (select jobid, count(*) n, max(return_message) msg from cron.job_run_details where status = 'failed' and start_time >= now() - interval '7 days' group by jobid) f
        join cron.job j on j.jobid = f.jobid), '[]'::jsonb),
    'ultima_execucao', coalesce((select jsonb_agg(jsonb_build_object('job', j.jobname, 'status', d.status, 'em', d.start_time) order by j.jobname)
        from cron.job j left join lateral (select status, start_time from cron.job_run_details where jobid = j.jobid order by start_time desc limit 1) d on true where j.active), '[]'::jsonb));
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_diag_banco()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'public'
AS $function$
declare ns oid := 'public'::regnamespace;
begin
  if coalesce(ia_nivel_real(), '') <> 'Desenvolvedor' then
    return jsonb_build_object('ok', false, 'message', 'Disponível só para o Desenvolvedor.');
  end if;
  return jsonb_build_object('ok', true,
    'tabelas_total', (select count(*) from pg_class where relnamespace = ns and relkind = 'r'),
    'tabelas_sem_rls', coalesce((select jsonb_agg(relname order by relname) from pg_class where relnamespace = ns and relkind = 'r' and not relrowsecurity), '[]'::jsonb),
    'tabelas_rls_sem_politica', coalesce((select jsonb_agg(c.relname order by c.relname) from pg_class c where c.relnamespace = ns and c.relkind = 'r' and c.relrowsecurity
        and not exists (select 1 from pg_policies p where p.schemaname = 'public' and p.tablename = c.relname)), '[]'::jsonb),
    'tabelas_anon_pode_escrever', coalesce((select jsonb_agg(c.relname order by c.relname) from pg_class c where c.relnamespace = ns and c.relkind = 'r'
        and (has_table_privilege('anon', c.oid, 'INSERT') or has_table_privilege('anon', c.oid, 'UPDATE') or has_table_privilege('anon', c.oid, 'DELETE'))), '[]'::jsonb),
    'politicas_escrita_sem_filtro', coalesce((select jsonb_agg(tablename || '.' || policyname || ' (' || cmd || ')' order by tablename)
        from pg_policies where schemaname = 'public' and cmd <> 'SELECT' and (coalesce(qual, 'true') = 'true' and coalesce(with_check, 'true') = 'true')), '[]'::jsonb),
    'funcoes_definer_total', (select count(*) from pg_proc where pronamespace = ns and prosecdef),
    'funcoes_definer_sem_search_path', coalesce((select jsonb_agg(proname order by proname) from pg_proc where pronamespace = ns and prosecdef
        and (proconfig is null or not (proconfig::text ilike '%search_path%'))), '[]'::jsonb),
    'funcoes_anon_executa', coalesce((select jsonb_agg(proname order by proname) from pg_proc where pronamespace = ns and prokind = 'f'
        and prorettype <> 'trigger'::regtype and has_function_privilege('anon', oid, 'execute') and proname not like 'ia\_%' and proname not in ('registrar_erro_cliente')), '[]'::jsonb),
    'views_definer', coalesce((select jsonb_agg(c.relname order by c.relname) from pg_class c where c.relnamespace = ns and c.relkind = 'v'
        and not coalesce(c.reloptions::text, '') ilike '%security_invoker=true%'), '[]'::jsonb),
    'fks_sem_indice', coalesce((select jsonb_agg(x.tabela || '.' || x.conname order by x.tabela) from (
        select c.conrelid::regclass::text tabela, c.conname from pg_constraint c where c.contype = 'f' and c.connamespace = ns
          and not exists (select 1 from pg_index i where i.indrelid = c.conrelid
                and array(select unnest(c.conkey) order by 1) = array(select unnest((i.indkey::int2[])[0:array_length(c.conkey, 1) - 1]) order by 1)) limit 15) x), '[]'::jsonb),
    'indices_nunca_usados', coalesce((select jsonb_agg(jsonb_build_object('indice', s.indexrelname, 'tabela', s.relname, 'kb', pg_relation_size(s.indexrelid) / 1024) order by pg_relation_size(s.indexrelid) desc)
        from (select * from pg_stat_user_indexes si where si.schemaname = 'public' and si.idx_scan = 0
                and not exists (select 1 from pg_index i where i.indexrelid = si.indexrelid and (i.indisunique or i.indisprimary)) order by pg_relation_size(si.indexrelid) desc limit 8) s), '[]'::jsonb),
    'tabelas_leitura_sequencial', coalesce((select jsonb_agg(jsonb_build_object('tabela', relname, 'linhas', n_live_tup, 'seq_scans', seq_scan, 'idx_scans', coalesce(idx_scan, 0)) order by seq_scan desc)
        from (select * from pg_stat_user_tables where schemaname = 'public' and n_live_tup > 500 and seq_scan > 100 and seq_scan > 5 * coalesce(idx_scan, 0) order by seq_scan desc limit 6) t), '[]'::jsonb),
    'tabelas_com_lixo', coalesce((select jsonb_agg(jsonb_build_object('tabela', relname, 'mortas', n_dead_tup, 'vivas', n_live_tup) order by n_dead_tup desc)
        from (select * from pg_stat_user_tables where schemaname = 'public' and n_dead_tup > 100 and n_dead_tup > 0.2 * greatest(n_live_tup, 1) order by n_dead_tup desc limit 6) t), '[]'::jsonb),
    'gatilhos_desativados', coalesce((select jsonb_agg(c.relname || '.' || t.tgname order by c.relname) from pg_trigger t join pg_class c on c.oid = t.tgrelid
        where c.relnamespace = ns and not t.tgisinternal and t.tgenabled = 'D'), '[]'::jsonb),
    'agendador', ia_cron_status_());
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_diag_codigo()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'public'
AS $function$
declare r record;
begin
  if coalesce(ia_nivel_real(), '') <> 'Desenvolvedor' then return jsonb_build_object('ok', false); end if;
  select gerado_em, resumo into r from ia_relatorio_codigo order by gerado_em desc limit 1;
  if not found then return jsonb_build_object('ok', true, 'existe', false); end if;
  return jsonb_build_object('ok', true, 'existe', true, 'gerado_em', r.gerado_em, 'dias_desde', extract(day from now() - r.gerado_em), 'resumo', r.resumo);
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_diag_sistema()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'public'
AS $function$
begin
  if coalesce(ia_nivel_real(), '') <> 'Desenvolvedor' then
    return jsonb_build_object('ok', false, 'message', 'Disponível só para o Desenvolvedor.');
  end if;
  return jsonb_build_object('ok', true, 'gerado_em', now(),
    'sync', (select jsonb_build_object(
        'principal_ultimo_ok', principal_ultimo_ok, 'principal_ultimo_erro', principal_ultimo_erro, 'principal_erro_msg', ia_limpa_(principal_ultimo_erro_msg),
        'contingencia_ultimo_ok', contingencia_ultimo_ok, 'contingencia_ultimo_erro', contingencia_ultimo_erro, 'contingencia_erro_msg', ia_limpa_(contingencia_ultimo_erro_msg),
        'contingencia_atraso_min', contingencia_atraso_minutos, 'limite_itens', alerta_itens_limite, 'limite_horas', alerta_horas_limite)
      from sync_estado limit 1),
    'fila', (select jsonb_build_object(
        'pendentes_principal', count(*) filter (where principal_ok_em is null),
        'pendentes_contingencia', count(*) filter (where contingencia_ok_em is null),
        'com_erro_principal', count(*) filter (where principal_ok_em is null and principal_erro is not null),
        'com_erro_contingencia', count(*) filter (where contingencia_ok_em is null and contingencia_erro is not null),
        'mais_antigo_min', round(extract(epoch from now() - min(criado_em) filter (where principal_ok_em is null or contingencia_ok_em is null)) / 60))
      from fila_sync),
    'fila_erros', coalesce((select jsonb_agg(jsonb_build_object('tabela', tabela, 'operacao', operacao, 'destino', destino, 'erro', erro, 'qtd', qtd) order by qtd desc)
      from (select * from (
              select tabela, operacao::text operacao, 'principal' destino, ia_limpa_(principal_erro) erro, count(*) qtd
                from fila_sync where principal_ok_em is null and principal_erro is not null group by 1, 2, 4
              union all
              select tabela, operacao::text, 'contingencia', ia_limpa_(contingencia_erro), count(*)
                from fila_sync where contingencia_ok_em is null and contingencia_erro is not null group by 1, 2, 4) u
            order by qtd desc limit 6) x), '[]'::jsonb),
    'backups', coalesce((select jsonb_agg(jsonb_build_object('data', data_hora, 'tipo', tipo::text, 'status', status, 'tamanho_mb', round(coalesce(tamanho_bytes, 0) / 1048576.0, 1), 'tentativas', tentativas, 'erro', ia_limpa_(erro)) order by data_hora desc)
      from (select * from backups order by data_hora desc limit 5) b), '[]'::jsonb),
    'integridade', coalesce((select jsonb_agg(jsonb_build_object('data', criado_em, 'vendas_supabase', supabase_vendas, 'vendas_planilha', planilha_vendas, 'diferenca', diferenca_vendas, 'status', status) order by criado_em desc)
      from (select * from integridade_checks order by criado_em desc limit 3) i), '[]'::jsonb),
    'auditoria_24h', coalesce((select jsonb_agg(jsonb_build_object('acao', ia_limpa_(acao, 60), 'qtd', qtd) order by qtd desc)
      from (select acao, count(*) qtd from auditoria where data_hora >= now() - interval '24 hours' group by 1 order by 2 desc limit 10) a), '[]'::jsonb),
    'banco', jsonb_build_object('tamanho_mb', round(pg_database_size(current_database()) / 1048576.0),
      'maiores_tabelas', coalesce((select jsonb_agg(jsonb_build_object('tabela', relname, 'mb', mb) order by mb desc)
        from (select c.relname, round(pg_total_relation_size(c.oid) / 1048576.0, 1) mb from pg_class c join pg_namespace n on n.oid = c.relnamespace
               where n.nspname = 'public' and c.relkind = 'r' order by pg_total_relation_size(c.oid) desc limit 5) t), '[]'::jsonb)),
    'erros_js_total_48h', (select coalesce(sum(ocorrencias), 0) from erros_cliente where ultima_em >= now() - interval '48 hours'),
    'erros_js_48h', coalesce((select jsonb_agg(jsonb_build_object('mensagem', mensagem, 'origem', origem, 'tela', tela, 'ocorrencias', oc, 'usuarios', us, 'ultima', ult, 'pilha', pilha) order by oc desc)
      from (select mensagem, origem, max(tela) tela, sum(ocorrencias) oc, count(distinct usuario_id) us, max(ultima_em) ult, max(left(pilha, 300)) pilha
              from erros_cliente where ultima_em >= now() - interval '48 hours' group by mensagem, origem order by sum(ocorrencias) desc limit 8) e), '[]'::jsonb),
    'ia_erros_24h', coalesce((select jsonb_agg(jsonb_build_object('codigo', cod, 'provedor', provedor, 'qtd', qtd) order by qtd desc)
      from (select coalesce(detalhe, '?') cod, provedor, count(*) qtd from ai_log where status = 'erro' and criado_em >= now() - interval '24 hours' group by 1, 2 order by 3 desc limit 6) e), '[]'::jsonb));
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_entregas_operacional()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r jsonb;
begin
  if not tem_nivel('Admin','Operador') then return jsonb_build_object('ok', false, 'message', 'Sem permissão.'); end if;
  select jsonb_build_object('ok', true,
    'em_rota', (select count(*) from vendas where status_pedido::text = 'Saiu para entrega'),
    'prontas_aguardando', (select count(*) from vendas where status_pedido::text = 'Pronta' and tipo::text ilike '%entrega%'),
    'mais_antiga_em_rota_min', (select floor(extract(epoch from now() - min(saiu_em)) / 60) from vendas where status_pedido::text = 'Saiu para entrega'),
    'tempo_medio_7d_min', (select round(avg(extract(epoch from concluida_em - saiu_em) / 60)::numeric, 0) from vendas where saiu_em is not null and concluida_em is not null and concluida_em >= now() - interval '7 days'),
    'por_entregador', coalesce((select jsonb_agg(jsonb_build_object('entregador', u.login, 'em_rota', c.n)) from (select entregador_id, count(*) n from vendas where status_pedido::text = 'Saiu para entrega' and entregador_id is not null group by 1) c join usuarios u on u.id = c.entregador_id), '[]'::jsonb)
  ) into r;
  return r;
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_estoque_operacional()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare r jsonb;
begin
  if not tem_nivel('Admin','Operador') then return jsonb_build_object('ok', false, 'message', 'Sem permissão.'); end if;
  select jsonb_build_object('ok', true,
    'total_itens', (select count(*) from estoque where status::text = 'Ativo' or status::text ilike 'ativ%'),
    'zerados', coalesce((select jsonb_agg(jsonb_build_object('ingrediente', ingrediente, 'unidade', unidade)) from (select * from estoque where quantidade <= 0 order by ingrediente limit 15) z), '[]'::jsonb),
    'abaixo_do_minimo', coalesce((select jsonb_agg(jsonb_build_object('ingrediente', ingrediente, 'quantidade', quantidade, 'minimo', quantidade_minima, 'unidade', unidade)) from (select * from estoque where quantidade > 0 and quantidade_minima > 0 and quantidade <= quantidade_minima order by (quantidade / nullif(quantidade_minima,0)) limit 15) z), '[]'::jsonb)
  ) into r;
  return r;
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_explorar(p_tabela text, p_ini date DEFAULT NULL::date, p_fim date DEFAULT NULL::date, p_busca text DEFAULT NULL::text, p_limite integer DEFAULT 30)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  adm boolean := tem_nivel('Admin');
  tz constant text := 'America/Sao_Paulo';
  t text := lower(btrim(coalesce(p_tabela, '')));
  b text := nullif(replace(replace(btrim(coalesce(p_busca, '')), '%', ''), '_', ''), '');
  lim int := least(greatest(coalesce(p_limite, 30), 1), 100);
  dcol text; dtipo text; dexpr text := 'true'; dsel text; sql text; r jsonb;
begin
  if not tem_nivel('Admin','Operador') then return jsonb_build_object('ok', false, 'message', 'Sem permissão.'); end if;
  if not (t = any(public._ia_tabelas(adm))) then return jsonb_build_object('ok', false, 'message', 'Tabela não disponível para o seu perfil.'); end if;
  select c.column_name::text, c.data_type::text into dcol, dtipo
    from information_schema.columns c
   where c.table_schema = 'public' and c.table_name::text = t
     and c.column_name::text in ('data_hora','data','criado_em','abertura','atualizada_em','recebido_em')
   order by array_position(array['data_hora','data','criado_em','abertura','atualizada_em','recebido_em'], c.column_name::text) limit 1;
  dsel := case when dcol is null then 'null::timestamptz' else format('t.%I', dcol) end;
  if p_ini is not null or p_fim is not null then
    if p_ini is null or p_fim is null or p_fim < p_ini or (p_fim - p_ini) > 366 then
      return jsonb_build_object('ok', false, 'message', 'Período inválido (máx. 366 dias).');
    end if;
    if dcol is not null then
      if dtipo = 'date' then dexpr := format('t.%I between %L::date and %L::date', dcol, p_ini, p_fim);
      else dexpr := format('(t.%I at time zone %L)::date between %L::date and %L::date', dcol, tz, p_ini, p_fim); end if;
    end if;
  end if;
  sql := format($q$
    with f as (select public._ia_mascara(to_jsonb(t), $1) m, %s d from public.%I t where %s),
    g as (select m, d from f where $2::text is null or m::text ilike '%%' || $2 || '%%')
    select jsonb_build_object(
      'total', (select count(*) from g),
      'linhas', coalesce((select jsonb_agg(m) from (select m from g order by d desc nulls last limit %s) z), '[]'::jsonb),
      'somas', case when $1 and (select count(*) from g) <= 5000 then coalesce((
          select jsonb_object_agg(s.k, s.v) from (
            select e.k, sum((e.v #>> '{}')::numeric) v from g, jsonb_each(g.m) e(k, v)
             where jsonb_typeof(e.v) = 'number' and e.k not in ('id','ordem','numero','numero_pedido','prazo_dias','capacidade','ordem_cardapio')
             group by e.k) s), '{}'::jsonb) else null end)
  $q$, dsel, t, dexpr, lim);
  execute sql into r using adm, b;
  return jsonb_build_object('ok', true, 'tabela', t, 'periodo', case when p_ini is null then null else p_ini::text || ' a ' || p_fim::text end) || r;
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_limpa_(t text, n integer DEFAULT 160)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
  select left(regexp_replace(regexp_replace(regexp_replace(coalesce(t, ''),
         '[[:alnum:]._%+-]+@[[:alnum:].-]+', '[email]', 'g'), '[0-9]{6,}', '#', 'g'), '[\r\n\t]+', ' ', 'g'), n)
$function$
;

CREATE OR REPLACE FUNCTION public.ia_nivel_real()
 RETURNS text
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select nivel::text from usuarios where id = auth.uid() and ativo
$function$
;

CREATE OR REPLACE FUNCTION public.ia_painel_uso()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'public'
AS $function$
begin
  if not tem_nivel('Admin') then return jsonb_build_object('ok', false, 'message', 'Sem permissão.'); end if;
  return jsonb_build_object('ok', true,
    'hoje', coalesce((select jsonb_agg(jsonb_build_object('provedor', provedor, 'chamadas', c, 'erros', e)) from
        (select provedor, sum(chamadas) c, sum(erros) e from ai_uso where dia = (now() at time zone 'America/Sao_Paulo')::date group by 1) x), '[]'::jsonb),
    'ultimos_7_dias', coalesce((select sum(chamadas) from ai_uso where dia >= current_date - 7), 0),
    'erros_24h', (select count(*) from ai_log where status = 'erro' and criado_em >= now() - interval '24 hours'),
    'cache_24h', (select count(*) from ai_log where status = 'cache' and criado_em >= now() - interval '24 hours'));
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_periodo_(p_a date, p_b date, p_adm boolean)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  tz constant text := 'America/Sao_Paulo';
  t_ini timestamptz := (p_a::timestamp at time zone tz);
  t_fim timestamptz := ((p_b + 1)::timestamp at time zone tz);
  r jsonb; tot jsonb; fat numeric; cus numeric; tx numeric; ped int;
begin
  r := jsonb_build_object(
    'de', p_a, 'ate', p_b,
    'pedidos', (select count(*) from vendas where status::text='Confirmada' and data_hora>=t_ini and data_hora<t_fim),
    'cancelados', (select count(*) from vendas where status::text='Cancelada' and data_hora>=t_ini and data_hora<t_fim),
    'por_tipo', coalesce((select jsonb_object_agg(k, n) from (select tipo::text k, count(*) n from vendas where status::text='Confirmada' and data_hora>=t_ini and data_hora<t_fim group by 1) x), '{}'::jsonb),
    'por_origem', coalesce((select jsonb_object_agg(k, n) from (select origem::text k, count(*) n from vendas where status::text='Confirmada' and data_hora>=t_ini and data_hora<t_fim group by 1) x), '{}'::jsonb)
  );
  if p_adm then
    tot := ia_totais_(p_a, p_b);
    fat := coalesce((tot->>'faturamento')::numeric,0); cus := coalesce((tot->>'custo')::numeric,0); tx := coalesce((tot->>'taxas')::numeric,0); ped := coalesce((tot->>'pedidos')::int,0);
    r := r || jsonb_build_object(
      'faturamento', fat, 'custo_vendas', cus, 'taxas_pagamento', tx, 'lucro_bruto', fat - tx - cus,
      'margem_pct', case when fat > 0 and cus > 0 then round((fat - tx - cus) / fat * 100, 1) end,
      'ticket_medio', case when ped > 0 then round(fat / ped, 2) end,
      'descontos', coalesce((select sum(valor_desconto) from vendas where status::text='Confirmada' and data_hora>=t_ini and data_hora<t_fim),0),
      'taxas_entrega', coalesce((select sum(taxa_entrega) from vendas where status::text='Confirmada' and data_hora>=t_ini and data_hora<t_fim),0),
      'a_receber', coalesce((select sum(valor_total) from vendas where status::text='Confirmada' and status_pagamento::text='A Receber' and data_hora>=t_ini and data_hora<t_fim),0),
      'despesas_pagas', coalesce((select sum(valor) from despesas where status::text='Paga' and data_hora>=t_ini and data_hora<t_fim),0),
      'por_pagamento', coalesce((select jsonb_object_agg(f, v) from (select pv.forma_pagamento f, sum(pv.valor) v from pagamentos_venda pv join vendas ve on ve.id=pv.venda_id where ve.status::text='Confirmada' and ve.data_hora>=t_ini and ve.data_hora<t_fim group by 1) x), '{}'::jsonb)
    );
  end if;
  return r;
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_producao_operacional()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  r jsonb;
  ini_hoje timestamptz := date_trunc('day', now() at time zone 'America/Sao_Paulo') at time zone 'America/Sao_Paulo';
begin
  if not tem_nivel('Admin','Operador') then
    return jsonb_build_object('ok', false, 'message', 'Sem permissão.');
  end if;
  select jsonb_build_object('ok', true,
    'recebidos_agora', (select count(*) from vendas where status_pedido::text = 'Recebido' and status::text <> 'Cancelada'),
    'em_preparo_agora', (select count(*) from vendas where status_pedido::text = 'Em preparo' and status::text <> 'Cancelada'),
    'prontos_agora', (select count(*) from vendas where status_pedido::text = 'Pronta' and status::text <> 'Cancelada'),
    'pedidos_hoje', (select count(*) from vendas where data_hora >= ini_hoje and status::text <> 'Cancelada'),
    'pedido_aberto_mais_antigo_min', (select floor(extract(epoch from now() - min(recebido_em)) / 60) from vendas where status_pedido::text in ('Recebido','Em preparo','Pronta') and status::text <> 'Cancelada' and recebido_em is not null),
    'preparo_medio_hoje_min', (select round(avg(extract(epoch from pronta_em - inicio_preparo_em) / 60)::numeric, 0) from vendas where inicio_preparo_em is not null and pronta_em is not null and pronta_em >= inicio_preparo_em and pronta_em >= ini_hoje and status::text <> 'Cancelada'),
    'preparo_medio_7d_min', (select round(avg(extract(epoch from pronta_em - inicio_preparo_em) / 60)::numeric, 0) from vendas where inicio_preparo_em is not null and pronta_em is not null and pronta_em >= inicio_preparo_em and pronta_em >= now() - interval '7 days' and status::text <> 'Cancelada'),
    'espera_antes_do_preparo_7d_min', (select round(avg(extract(epoch from inicio_preparo_em - recebido_em) / 60)::numeric, 0) from vendas where recebido_em is not null and inicio_preparo_em is not null and inicio_preparo_em >= recebido_em and inicio_preparo_em >= now() - interval '7 days' and status::text <> 'Cancelada'),
    'tempo_total_medio_7d_min', (select round(avg(extract(epoch from concluida_em - recebido_em) / 60)::numeric, 0) from vendas where recebido_em is not null and concluida_em is not null and concluida_em >= recebido_em and concluida_em >= now() - interval '7 days' and status::text <> 'Cancelada'),
    'pedidos_concluidos_7d', (select count(*) from vendas where concluida_em is not null and concluida_em >= now() - interval '7 days' and status::text <> 'Cancelada')
  ) into r;
  return r;
end
$function$
;

CREATE OR REPLACE FUNCTION public.ia_publico_contexto()
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select jsonb_set(b, '{adicionais_disponiveis_em_todos_os_lanches}',
           coalesce((select jsonb_agg(jsonb_build_object('nome', e->>'nome', 'preco', nullif((e->>'preco')::numeric, 0)))
                       from jsonb_array_elements(b->'adicionais_disponiveis_em_todos_os_lanches') e), '[]'::jsonb))
         || jsonb_build_object('aviso_adicionais', 'Adicional com preco nulo: o valor aparece na tela ao montar o pedido. Nunca diga que e gratis nem invente valor.')
  from (select public.ia_publico_contexto_base() b) x;
$function$
;

CREATE OR REPLACE FUNCTION public.ia_publico_contexto_base()
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  with esg as (select tipo::text tipo, id from public.v_cardapio_esgotados),
  pr as (
    select p.tipo::text tipo, p.item_id,
           case when count(distinct p.preco) = 1 then to_jsonb(min(p.preco))
                else jsonb_object_agg(coalesce(f.nome, '?'), p.preco) end preco
      from public.v_cardapio_precos p left join public.v_cardapio_formas f on f.id = p.forma_pagamento_id
     group by p.tipo, p.item_id)
  select jsonb_build_object(
    'caixa_aberto', coalesce((select bool_or(caixa_aberto) from public.v_cardapio_status), false),
    'config', (select coalesce(jsonb_object_agg(chave, valor), '{}'::jsonb) from public.v_cardapio_config
                where chave in ('CardapioTempoRetirada','CardapioTempoMesa','CardapioTempoEntrega','TaxaEntregaPadrao') and valor::text not in ('""','null')),
    'formas_pagamento', (select coalesce(jsonb_agg(jsonb_build_object('nome', nome, 'aceita_troco', permite_troco) order by ordem), '[]'::jsonb) from public.v_cardapio_formas),
    'adicionais_disponiveis_em_todos_os_lanches', (select coalesce(jsonb_agg(jsonb_build_object('nome', nome, 'preco', preco) order by nome), '[]'::jsonb)
                                                  from (select distinct nome, preco from public.v_cardapio_adicionais) a),
    'produtos', (select coalesce(jsonb_agg(jsonb_build_object(
        'nome', p.nome, 'descricao', left(coalesce(p.descricao,''), 220), 'categoria', c.nome, 'destaque', coalesce(p.destaque,false),
        'esgotado', exists(select 1 from esg e where e.tipo = 'produto' and e.id = p.id),
        'preco', (select pr.preco from pr where pr.tipo = 'produto' and pr.item_id = p.id)
      ) order by c.ordem, p.ordem_cardapio, p.nome), '[]'::jsonb)
      from public.v_cardapio_produtos p left join public.v_cardapio_categorias c on c.id = p.categoria_id),
    'combos', (select coalesce(jsonb_agg(jsonb_build_object(
        'nome', b.nome, 'categoria', c.nome, 'destaque', coalesce(b.destaque,false),
        'esgotado', exists(select 1 from esg e where e.tipo = 'combo' and e.id = b.id),
        'preco', (select pr.preco from pr where pr.tipo = 'combo' and pr.item_id = b.id),
        'itens', coalesce((select jsonb_agg(ci.quantidade || 'x ' || pp.nome) from public.v_cardapio_combo_itens ci join public.v_cardapio_produtos pp on pp.id = ci.produto_id where ci.combo_id = b.id), '[]'::jsonb)
      ) order by c.ordem, b.ordem_cardapio, b.nome), '[]'::jsonb)
      from public.v_cardapio_combos b left join public.v_cardapio_categorias c on c.id = b.categoria_id),
    'mais_pedidos', (select coalesce(jsonb_agg(n order by pos), '[]'::jsonb) from (
        select coalesce(p.nome, b.nome) n, m.posicao pos from public.v_cardapio_mais_pedidos m
          left join public.v_cardapio_produtos p on m.tipo::text = 'produto' and p.id = m.id
          left join public.v_cardapio_combos b on m.tipo::text = 'combo' and b.id = m.id
         order by m.posicao limit 8) z where n is not null),
    'promocoes', (select coalesce(jsonb_agg(jsonb_build_object('nome', nome, 'beneficio', beneficio)), '[]'::jsonb)
                    from (select distinct nome, beneficio from public.promocoes where ativa) q)
  );
$function$
;

CREATE OR REPLACE FUNCTION public.ia_publico_limite(p_ip text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_k text := 'iaqa_ip_' || left(coalesce(nullif(p_ip,''), 'sem_ip'), 64);
begin
  if public._excedeu(v_k, 20) then return jsonb_build_object('ok', false, 'motivo', 'limite_ip'); end if;
  perform public._registrar_falha(v_k, 600);
  return jsonb_build_object('ok', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_publico_status_pedido(p_telefone text, p_ip text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_tel text := right(public._so_digitos(p_telefone), 11);
  v_ipk text := 'iastat_ip_' || left(coalesce(nullif(p_ip,''), 'sem_ip'), 64);
  v_telk text; cfg public.chat_config%rowtype; r jsonb;
begin
  if length(v_tel) < 10 then return jsonb_build_object('ok', false, 'motivo', 'telefone_invalido'); end if;
  v_telk := 'iastat_tel_' || v_tel;
  if public._excedeu(v_ipk, 10) or public._excedeu(v_telk, 6) then return jsonb_build_object('ok', false, 'motivo', 'limite'); end if;
  perform public._registrar_falha(v_ipk, 600); perform public._registrar_falha(v_telk, 600);
  select * into cfg from public.chat_config where id;
  select coalesce(jsonb_agg(jsonb_build_object(
      'numero', x.numero_pedido, 'situacao', x.status::text, 'andamento', x.status_pedido::text, 'tipo', x.tipo::text,
      'quando', to_char(x.data_hora at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI'), 'valor_total', x.valor_total,
      'pagamento', x.status_pagamento::text, 'motivo_cancelamento', nullif(x.motivo_cancelamento, ''),
      'itens', coalesce((select jsonb_agg(i.quantidade || 'x ' || coalesce(i.descricao,'') order by i.ctid) from public.itens_venda i where i.venda_id = x.id), '[]'::jsonb)
    ) order by x.data_hora desc), '[]'::jsonb) into r
  from (select * from public.vendas v
         where right(public._so_digitos(v.telefone_cliente), 11) = v_tel
           and v.data_hora >= now() - make_interval(hours => coalesce(cfg.janela_horas, 48))
         order by v.data_hora desc limit 3) x;
  return jsonb_build_object('ok', true, 'pedidos', r);
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_resumo_periodo(p_ini date, p_fim date)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'public'
AS $function$
declare
  tz constant text := 'America/Sao_Paulo';
  t_ini timestamptz; t_fim timestamptz; tot jsonb; fat numeric; cus numeric; tx numeric; ped int;
begin
  if not tem_nivel('Admin','Operador') then
    return jsonb_build_object('ok', false, 'message', 'Sem permissão.');
  end if;
  if p_ini is null or p_fim is null or p_fim < p_ini or (p_fim - p_ini) > 92 then
    return jsonb_build_object('ok', false, 'message', 'Período inválido (máx. 93 dias).');
  end if;
  t_ini := (p_ini::timestamp at time zone tz);
  t_fim := ((p_fim + 1)::timestamp at time zone tz);
  tot := ia_totais_(p_ini, p_fim);
  fat := (tot->>'faturamento')::numeric; cus := (tot->>'custo')::numeric; tx := (tot->>'taxas')::numeric; ped := (tot->>'pedidos')::int;
  return jsonb_build_object(
    'ok', true, 'ini', p_ini, 'fim', p_fim,
    'faturamento', fat, 'custo', cus, 'taxas_pagamento', tx, 'lucro_bruto', fat - tx - cus,
    'margem_pct', case when fat > 0 then round((fat - tx - cus) / fat * 100, 1) end,
    'pedidos', ped, 'cancelados', (tot->>'cancelados')::int,
    'ticket_medio', case when ped > 0 then round(fat / ped, 2) end,
    'descontos', coalesce((select sum(valor_desconto) from vendas where status = 'Confirmada' and data_hora >= t_ini and data_hora < t_fim), 0),
    'taxas_entrega', coalesce((select sum(taxa_entrega) from vendas where status = 'Confirmada' and data_hora >= t_ini and data_hora < t_fim), 0),
    'a_receber', coalesce((select sum(valor_total) from vendas where status = 'Confirmada' and status_pagamento = 'A Receber' and data_hora >= t_ini and data_hora < t_fim), 0),
    'despesas_pagas', coalesce((select sum(valor) from despesas where status = 'Paga' and data_hora >= t_ini and data_hora < t_fim), 0),
    'por_tipo', coalesce((select jsonb_agg(jsonb_build_object('tipo', tipo, 'pedidos', n, 'valor', v) order by v desc)
        from (select tipo::text tipo, count(*) n, sum(valor_total) v from vendas
              where status = 'Confirmada' and data_hora >= t_ini and data_hora < t_fim group by 1) x), '[]'::jsonb),
    'por_origem', coalesce((select jsonb_agg(jsonb_build_object('origem', origem, 'pedidos', n, 'valor', v) order by v desc)
        from (select origem::text origem, count(*) n, sum(valor_total) v from vendas
              where status = 'Confirmada' and data_hora >= t_ini and data_hora < t_fim group by 1) x), '[]'::jsonb),
    'por_pagamento', coalesce((select jsonb_agg(jsonb_build_object('forma', f, 'valor', v) order by v desc)
        from (select pv.forma_pagamento f, sum(pv.valor) v from pagamentos_venda pv join vendas ve on ve.id = pv.venda_id
              where ve.status = 'Confirmada' and ve.data_hora >= t_ini and ve.data_hora < t_fim group by 1) x), '[]'::jsonb),
    'top_produtos', coalesce((select jsonb_agg(jsonb_build_object('nome', d, 'qtd', q, 'valor', v, 'margem_pct', m) order by v desc)
        from (select iv.descricao d, sum(iv.quantidade) q, sum(iv.valor_total_item) v,
                     case when sum(iv.valor_total_item) > 0
                          then round((sum(iv.valor_total_item) - sum(iv.custo_unitario * iv.quantidade)) / sum(iv.valor_total_item) * 100, 1) end m
              from itens_venda iv join vendas ve on ve.id = iv.venda_id
              where ve.status = 'Confirmada' and ve.data_hora >= t_ini and ve.data_hora < t_fim
              group by iv.descricao order by sum(iv.valor_total_item) desc limit 5) x), '[]'::jsonb),
    'por_hora', coalesce((select jsonb_agg(jsonb_build_object('hora', h, 'pedidos', n, 'valor', v) order by h)
        from (select extract(hour from data_hora at time zone tz)::int h, count(*) n, sum(valor_total) v from vendas
              where status = 'Confirmada' and data_hora >= t_ini and data_hora < t_fim group by 1) x), '[]'::jsonb)
  );
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_sugestao_compras(p_dias integer DEFAULT 14, p_cobertura integer DEFAULT 7)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'public'
AS $function$
declare itens jsonb; total numeric;
begin
  if not tem_nivel('Admin','Operador') then
    return jsonb_build_object('ok', false, 'message', 'Sem permissão.');
  end if;
  p_dias := least(greatest(coalesce(p_dias,14),3),60); p_cobertura := least(greatest(coalesce(p_cobertura,7),1),30);
  with cons as (
    select ingrediente_id, sum(abs(quantidade)) q from movimentacoes_estoque
     where tipo in ('Venda','Perda','Saída') and data >= now() - make_interval(days => p_dias) group by 1
  ), base as (
    select e.id, e.ingrediente, e.unidade::text un, e.quantidade, e.quantidade_minima, e.custo_unitario,
           coalesce(c.q,0) / p_dias cdia
      from estoque e left join cons c on c.ingrediente_id = e.id where e.status = 'Ativo'
  ), calc as (
    select *, case when cdia > 0 then round(quantidade / cdia, 1) end dias_restantes,
           greatest(0, ceil(cdia * p_cobertura + quantidade_minima - quantidade)) sugerido
      from base
  ), sel as (
    select * from calc
     where sugerido > 0 or (quantidade_minima > 0 and quantidade <= quantidade_minima)
     order by (case when dias_restantes is null then 9999 else dias_restantes end), ingrediente limit 30
  )
  select coalesce(jsonb_agg(jsonb_build_object('ingrediente', ingrediente, 'unidade', un, 'em_estoque', quantidade,
           'minimo', quantidade_minima, 'consumo_dia', round(cdia,2), 'dias_restantes', dias_restantes,
           'sugerido', sugerido, 'custo_estimado', round(sugerido * coalesce(custo_unitario,0), 2))), '[]'::jsonb),
         coalesce(sum(sugerido * coalesce(custo_unitario,0)),0)
    into itens, total from sel;
  return jsonb_build_object('ok', true, 'janela_dias', p_dias, 'cobertura_dias', p_cobertura,
                            'custo_total_estimado', round(total,2), 'itens', itens);
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_top_produtos_(p_a date, p_b date, p_adm boolean, p_limite integer, p_ordem text)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare tz constant text := 'America/Sao_Paulo'; t_ini timestamptz := (p_a::timestamp at time zone tz); t_fim timestamptz := ((p_b + 1)::timestamp at time zone tz);
begin
  return coalesce((select jsonb_agg(
      jsonb_build_object('produto', d, 'qtd', q) ||
      case when p_adm then jsonb_build_object('valor', v, 'margem_pct', m) else '{}'::jsonb end)
    from (select iv.descricao d, sum(iv.quantidade) q, sum(iv.valor_total_item) v,
                 case when sum(iv.valor_total_item) > 0 and sum(iv.custo_unitario*iv.quantidade) > 0 then round((sum(iv.valor_total_item) - sum(iv.custo_unitario*iv.quantidade)) / sum(iv.valor_total_item) * 100, 1) end m
          from itens_venda iv join vendas ve on ve.id=iv.venda_id
          where ve.status::text='Confirmada' and ve.data_hora>=t_ini and ve.data_hora<t_fim
          group by iv.descricao
          order by case when p_ordem='menos' then sum(iv.quantidade) end asc, case when p_ordem<>'menos' then sum(iv.quantidade) end desc
          limit greatest(1, least(coalesce(p_limite,10), 25))) x), '[]'::jsonb);
end $function$
;

CREATE OR REPLACE FUNCTION public.ia_totais_(p_ini date, p_fim date)
 RETURNS jsonb
 LANGUAGE sql
 STABLE
 SET search_path TO 'public'
AS $function$
  select jsonb_build_object(
    'faturamento', coalesce(sum(valor_total) filter (where status = 'Confirmada'), 0),
    'custo',       coalesce(sum(custo_total) filter (where status = 'Confirmada'), 0),
    'pedidos',     count(*) filter (where status = 'Confirmada'),
    'cancelados',  count(*) filter (where status = 'Cancelada'),
    'taxas', coalesce((select sum(pv.taxa_aplicada) from pagamentos_venda pv join vendas ve on ve.id = pv.venda_id
                        where ve.status = 'Confirmada'
                          and ve.data_hora >= (p_ini::timestamp at time zone 'America/Sao_Paulo')
                          and ve.data_hora <  ((p_fim + 1)::timestamp at time zone 'America/Sao_Paulo')), 0))
  from vendas
  where data_hora >= (p_ini::timestamp at time zone 'America/Sao_Paulo')
    and data_hora <  ((p_fim + 1)::timestamp at time zone 'America/Sao_Paulo')
$function$
;

CREATE OR REPLACE FUNCTION public.ia_uso_somar(p_user uuid, p_provedor text, p_erro boolean, p_tin integer DEFAULT 0, p_tout integer DEFAULT 0)
 RETURNS void
 LANGUAGE sql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  insert into ai_uso (dia, provedor, usuario_id, chamadas, erros, tokens_in, tokens_out)
  values ((now() at time zone 'America/Sao_Paulo')::date, p_provedor, p_user, 1, case when p_erro then 1 else 0 end, coalesce(p_tin,0), coalesce(p_tout,0))
  on conflict (dia, provedor, usuario_id) do update
    set chamadas = ai_uso.chamadas + 1, erros = ai_uso.erros + excluded.erros,
        tokens_in = ai_uso.tokens_in + excluded.tokens_in, tokens_out = ai_uso.tokens_out + excluded.tokens_out
$function$
;

CREATE OR REPLACE FUNCTION public.registrar_erro_cliente(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  uid uuid := auth.uid(); hoje date := (now() at time zone 'America/Sao_Paulo')::date;
  tp text; msg text; ori text; pil text; h text; vezes int; novos int; total int;
begin
  if uid is null or p is null or jsonb_typeof(p) <> 'object' then return jsonb_build_object('ok', false); end if;
  tp := case when p->>'tipo' = 'promise' then 'promise' else 'error' end;
  msg := erro_limpa_(p->>'mensagem', 300); ori := erro_limpa_(p->>'origem', 120); pil := erro_limpa_(p->>'pilha', 600);
  if msg = '' then return jsonb_build_object('ok', false); end if;
  h := md5(tp || '|' || msg || '|' || ori);
  vezes := case when (p->>'vezes') ~ '^[0-9]{1,2}$' then greatest((p->>'vezes')::int, 1) else 1 end;
  update erros_cliente set ocorrencias = least(ocorrencias + vezes, 9999), ultima_em = now() where hash = h and dia = hoje;
  if found then return jsonb_build_object('ok', true, 'novo', false); end if;
  select count(*) into novos from erros_cliente where usuario_id = uid and criado_em > now() - interval '1 hour';
  select count(*) into total from erros_cliente where dia = hoje;
  if novos >= 20 or total >= 300 then return jsonb_build_object('ok', false, 'motivo', 'limite'); end if;
  insert into erros_cliente (usuario_id, nivel, tipo, mensagem, origem, pilha, tela, versao, aparelho, hash, ocorrencias)
  values (uid, coalesce(ia_nivel_real(), '?'), tp, msg, ori, pil,
          left(regexp_replace(coalesce(p->>'tela', ''), '[^a-zA-Z0-9_-]', '', 'g'), 40),
          left(regexp_replace(coalesce(p->>'versao', ''), '[^a-zA-Z0-9._-]', '', 'g'), 30),
          erro_limpa_(p->>'aparelho', 80), h, vezes)
  on conflict (hash, dia) do update set ocorrencias = least(erros_cliente.ocorrencias + vezes, 9999), ultima_em = now();
  return jsonb_build_object('ok', true, 'novo', true);
end $function$
;

CREATE OR REPLACE FUNCTION public.rls_auto_enable()
 RETURNS event_trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'pg_catalog'
AS $function$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.tem_nivel(VARIADIC niveis nivel_acesso[])
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  select coalesce(auth_nivel() = any(niveis), false)
$function$
;

CREATE OR REPLACE FUNCTION public.tocar_atualizado_em()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO 'public', 'pg_catalog'
AS $function$
begin new.atualizado_em := now(); return new; end $function$
;


-- ---------------------------------------------------------------------
-- 6. CHAVES PRIMÁRIAS, ÚNICAS E CHECKS
-- ---------------------------------------------------------------------
alter table public.adicionais add constraint adicionais_pkey PRIMARY KEY (id);
alter table public.ai_ajuda add constraint ai_ajuda_grupo_check CHECK ((grupo = ANY (ARRAY['secao'::text, 'lista'::text, 'erro'::text])));
alter table public.ai_ajuda add constraint ai_ajuda_passos_check CHECK (((length(passos) >= 10) AND (length(passos) <= 4000)));
alter table public.ai_ajuda add constraint ai_ajuda_pkey PRIMARY KEY (id);
alter table public.ai_ajuda add constraint ai_ajuda_slug_key UNIQUE (slug);
alter table public.ai_ajuda add constraint ai_ajuda_titulo_check CHECK (((length(titulo) >= 3) AND (length(titulo) <= 120)));
alter table public.ai_cache add constraint ai_cache_pkey PRIMARY KEY (hash);
alter table public.ai_config add constraint ai_config_cache_ttl_min_check CHECK ((cache_ttl_min >= 0));
alter table public.ai_config add constraint ai_config_cota_diaria_global_check CHECK ((cota_diaria_global >= 0));
alter table public.ai_config add constraint ai_config_cota_diaria_operador_check CHECK ((cota_diaria_operador >= 0));
alter table public.ai_config add constraint ai_config_cota_diaria_usuario_check CHECK ((cota_diaria_usuario >= 0));
alter table public.ai_config add constraint ai_config_id_check CHECK (id);
alter table public.ai_config add constraint ai_config_limite_por_minuto_check CHECK ((limite_por_minuto > 0));
alter table public.ai_config add constraint ai_config_limite_por_minuto_operador_check CHECK ((limite_por_minuto_operador > 0));
alter table public.ai_config add constraint ai_config_pkey PRIMARY KEY (id);
alter table public.ai_config add constraint ai_config_provedor_principal_check CHECK ((provedor_principal = ANY (ARRAY['gemini'::text, 'groq'::text])));
alter table public.ai_config add constraint ai_config_provedor_reserva_check CHECK ((provedor_reserva = ANY (ARRAY['gemini'::text, 'groq'::text])));
alter table public.ai_log add constraint ai_log_pkey PRIMARY KEY (id);
alter table public.ai_log add constraint ai_log_status_check CHECK ((status = ANY (ARRAY['ok'::text, 'cache'::text, 'erro'::text, 'bloqueado'::text, 'desligada'::text, 'cota'::text, 'limite'::text, 'indisponivel'::text])));
alter table public.ai_segredos add constraint ai_segredos_pkey PRIMARY KEY (provedor);
alter table public.ai_segredos add constraint ai_segredos_provedor_check CHECK ((provedor = ANY (ARRAY['gemini'::text, 'groq'::text])));
alter table public.ai_uso add constraint ai_uso_pkey PRIMARY KEY (dia, provedor, usuario_id);
alter table public.ajustes_pos_venda add constraint ajustes_pos_venda_pkey PRIMARY KEY (id);
alter table public.arquivo_historico add constraint arquivo_historico_pkey PRIMARY KEY (id);
alter table public.arquivo_historico add constraint arquivo_historico_tabela_registro_id_key UNIQUE (tabela, registro_id);
alter table public.auditoria add constraint auditoria_pkey PRIMARY KEY (id);
alter table public.backup_config add constraint backup_config_arquivar_dias_check CHECK ((arquivar_dias >= 30));
alter table public.backup_config add constraint backup_config_arquivar_emerg_pct_check CHECK (((arquivar_emerg_pct >= 70) AND (arquivar_emerg_pct <= 99)));
alter table public.backup_config add constraint backup_config_id_check CHECK (id);
alter table public.backup_config add constraint backup_config_pkey PRIMARY KEY (id);
alter table public.backups add constraint backups_pkey PRIMARY KEY (id);
alter table public.brindes add constraint brindes_pkey PRIMARY KEY (id);
alter table public.brindes add constraint brindes_tipo_check CHECK ((tipo = ANY (ARRAY['Fidelidade'::text, 'Indicação'::text])));
alter table public.caixa_sessoes add constraint caixa_sessoes_pkey PRIMARY KEY (id);
alter table public.categorias add constraint categorias_pkey PRIMARY KEY (id);
alter table public.chat_config add constraint chat_config_ia_publica_cota_dia_check CHECK ((ia_publica_cota_dia >= 0));
alter table public.chat_config add constraint chat_config_id_check CHECK (id);
alter table public.chat_config add constraint chat_config_janela_horas_check CHECK (((janela_horas >= 1) AND (janela_horas <= 720)));
alter table public.chat_config add constraint chat_config_pkey PRIMARY KEY (id);
alter table public.chat_conversas add constraint chat_conversas_estado_check CHECK ((estado = ANY (ARRAY['recepcao'::text, 'aguardando'::text, 'em_atendimento'::text, 'encerrada'::text])));
alter table public.chat_conversas add constraint chat_conversas_ia_chamadas_check CHECK (((ia_chamadas >= 0) AND (ia_chamadas <= 3)));
alter table public.chat_conversas add constraint chat_conversas_intencao_check CHECK (((intencao IS NULL) OR (intencao = ANY (ARRAY['pedido_feito'::text, 'antes_de_pedir'::text]))));
alter table public.chat_conversas add constraint chat_conversas_pedido_ao_transferir CHECK (((estado = 'recepcao'::text) OR (intencao IS DISTINCT FROM 'pedido_feito'::text) OR (venda_id IS NOT NULL) OR pedido_nao_localizado));
alter table public.chat_conversas add constraint chat_conversas_pkey PRIMARY KEY (id);
alter table public.chat_conversas add constraint chat_conversas_resumo_check CHECK ((char_length(resumo) <= 600));
alter table public.chat_conversas add constraint chat_conversas_solucao_check CHECK ((char_length(solucao) <= 600));
alter table public.chat_conversas add constraint chat_conversas_texto_original_check CHECK ((char_length(texto_original) <= 300));
alter table public.chat_conversas add constraint chat_conversas_tipo_problema_check CHECK (((tipo_problema IS NULL) OR (tipo_problema = ANY (ARRAY['atraso'::text, 'item_errado'::text, 'item_faltando'::text, 'cobranca'::text, 'qualidade'::text, 'outro'::text, 'antes_de_pedir'::text]))));
alter table public.chat_ia_cotas add constraint chat_ia_cotas_pkey PRIMARY KEY (dia);
alter table public.chat_mensagens add constraint chat_mensagens_autor_check CHECK ((autor = ANY (ARRAY['cliente'::text, 'ia'::text, 'atendente'::text, 'sistema'::text])));
alter table public.chat_mensagens add constraint chat_mensagens_pkey PRIMARY KEY (id);
alter table public.chat_mensagens add constraint chat_mensagens_texto_check CHECK (((char_length(texto) >= 1) AND (char_length(texto) <= 1000)));
alter table public.chat_tokens add constraint chat_tokens_pkey PRIMARY KEY (conversa_id);
alter table public.clientes add constraint clientes_pkey PRIMARY KEY (id);
alter table public.codigo_analises add constraint codigo_analises_arquivo_hash_key UNIQUE (arquivo, hash);
alter table public.codigo_analises add constraint codigo_analises_pkey PRIMARY KEY (id);
alter table public.codigo_snapshots add constraint codigo_snapshots_arquivo_bloco_hash_key UNIQUE (arquivo, bloco, hash);
alter table public.codigo_snapshots add constraint codigo_snapshots_pkey PRIMARY KEY (id);
alter table public.codigo_versoes add constraint codigo_versoes_arquivo_hash_total_key UNIQUE (arquivo, hash_total);
alter table public.codigo_versoes add constraint codigo_versoes_pkey PRIMARY KEY (id);
alter table public.combo_itens add constraint combo_itens_pkey PRIMARY KEY (id);
alter table public.combo_itens add constraint combo_itens_quantidade_check CHECK ((quantidade > 0));
alter table public.combo_precos add constraint combo_precos_combo_id_forma_pagamento_id_key UNIQUE (combo_id, forma_pagamento_id);
alter table public.combo_precos add constraint combo_precos_pkey PRIMARY KEY (id);
alter table public.combos add constraint combos_pkey PRIMARY KEY (id);
alter table public.configuracoes_fotos add constraint configuracoes_fotos_id_check CHECK (id);
alter table public.configuracoes_fotos add constraint configuracoes_fotos_pkey PRIMARY KEY (id);
alter table public.contingencia_config add constraint contingencia_config_id_check CHECK (id);
alter table public.contingencia_config add constraint contingencia_config_pkey PRIMARY KEY (id);
alter table public.contingencia_reconciliada add constraint contingencia_reconciliada_pkey PRIMARY KEY (id_fila);
alter table public.cupons add constraint cupons_codigo_key UNIQUE (codigo);
alter table public.cupons add constraint cupons_pkey PRIMARY KEY (id);
alter table public.cupons_usos add constraint cupons_usos_pkey PRIMARY KEY (id);
alter table public.despesas add constraint despesas_pkey PRIMARY KEY (id);
alter table public.despesas_recorrentes add constraint despesas_recorrentes_dia_vencimento_check CHECK (((dia_vencimento >= 1) AND (dia_vencimento <= 31)));
alter table public.despesas_recorrentes add constraint despesas_recorrentes_pkey PRIMARY KEY (id);
alter table public.entrega_destinos add constraint entrega_destinos_lat_check CHECK (((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)));
alter table public.entrega_destinos add constraint entrega_destinos_lng_check CHECK (((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision)));
alter table public.entrega_destinos add constraint entrega_destinos_pkey PRIMARY KEY (venda_id);
alter table public.entregador_posicoes add constraint entregador_posicoes_lat_check CHECK (((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)));
alter table public.entregador_posicoes add constraint entregador_posicoes_lng_check CHECK (((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision)));
alter table public.entregador_posicoes add constraint entregador_posicoes_pkey PRIMARY KEY (venda_id);
alter table public.entregador_posicoes add constraint entregador_posicoes_precisao_m_check CHECK ((precisao_m >= (0)::double precision));
alter table public.entregas_fechadas add constraint entregas_fechadas_pkey PRIMARY KEY (id);
alter table public.entregas_fechadas add constraint entregas_fechadas_venda_id_key UNIQUE (venda_id);
alter table public.erros_cliente add constraint erros_cliente_hash_dia_key UNIQUE (hash, dia);
alter table public.erros_cliente add constraint erros_cliente_ocorrencias_check CHECK (((ocorrencias >= 1) AND (ocorrencias <= 9999)));
alter table public.erros_cliente add constraint erros_cliente_pkey PRIMARY KEY (id);
alter table public.erros_cliente add constraint erros_cliente_tipo_check CHECK ((tipo = ANY (ARRAY['error'::text, 'promise'::text])));
alter table public.estoque add constraint estoque_pkey PRIMARY KEY (id);
alter table public.eventos add constraint eventos_pkey PRIMARY KEY (id);
alter table public.eventos_custos add constraint eventos_custos_pkey PRIMARY KEY (id);
alter table public.eventos_recebimentos add constraint eventos_recebimentos_pkey PRIMARY KEY (id);
alter table public.faq_publico add constraint faq_publico_palavras_chave_check CHECK ((char_length(palavras_chave) <= 300));
alter table public.faq_publico add constraint faq_publico_pergunta_check CHECK (((char_length(pergunta) >= 3) AND (char_length(pergunta) <= 200)));
alter table public.faq_publico add constraint faq_publico_pkey PRIMARY KEY (id);
alter table public.faq_publico add constraint faq_publico_resposta_check CHECK (((char_length(resposta) >= 1) AND (char_length(resposta) <= 1500)));
alter table public.fechamentos_entrega add constraint fechamentos_entrega_forma_chk CHECK (((forma_pagamento IS NULL) OR (forma_pagamento = ANY (ARRAY['Dinheiro'::text, 'Pix'::text]))));
alter table public.fechamentos_entrega add constraint fechamentos_entrega_pkey PRIMARY KEY (id);
alter table public.fechamentos_entrega add constraint fechamentos_entrega_requisicao_id_key UNIQUE (requisicao_id);
alter table public.feedbacks add constraint feedbacks_nota_check CHECK (((nota >= 1) AND (nota <= 5)));
alter table public.feedbacks add constraint feedbacks_pkey PRIMARY KEY (id);
alter table public.fidelidade add constraint fidelidade_carimbos_check CHECK (((carimbos >= 0) AND (carimbos <= 10)));
alter table public.fidelidade add constraint fidelidade_cliente_id_key UNIQUE (cliente_id);
alter table public.fidelidade add constraint fidelidade_pkey PRIMARY KEY (id);
alter table public.fila_sync add constraint fila_sync_pkey PRIMARY KEY (id);
alter table public.formas_pagamento add constraint formas_pagamento_pkey PRIMARY KEY (id);
alter table public.fotos_historico add constraint fotos_historico_acao_check CHECK ((acao = ANY (ARRAY['upload'::text, 'substituir'::text, 'mover'::text, 'remover'::text, 'replicar'::text])));
alter table public.fotos_historico add constraint fotos_historico_pkey PRIMARY KEY (id);
alter table public.ia_relatorio_codigo add constraint ia_relatorio_codigo_pkey PRIMARY KEY (id);
alter table public.ia_relatorio_codigo add constraint ia_relatorio_codigo_resumo_check CHECK ((pg_column_size(resumo) < 30000));
alter table public.indicacoes add constraint indicacoes_pkey PRIMARY KEY (id);
alter table public.integridade_checks add constraint integridade_checks_pkey PRIMARY KEY (id);
alter table public.integridade_checks add constraint integridade_checks_status_check CHECK ((status = ANY (ARRAY['ok'::text, 'divergencia'::text, 'erro'::text])));
alter table public.itens_venda add constraint itens_venda_pkey PRIMARY KEY (id);
alter table public.itens_venda add constraint itens_venda_quantidade_check CHECK ((quantidade > 0));
alter table public.mesas add constraint mesas_numero_key UNIQUE (numero);
alter table public.mesas add constraint mesas_pkey PRIMARY KEY (id);
alter table public.mesas_codigos add constraint mesas_codigos_pkey PRIMARY KEY (mesa_id);
alter table public.movimentacoes_estoque add constraint movimentacoes_estoque_pkey PRIMARY KEY (id);
alter table public.ocorrencias add constraint ocorrencias_pkey PRIMARY KEY (id);
alter table public.pagamentos_venda add constraint pagamentos_venda_pkey PRIMARY KEY (id);
alter table public.pedido_destinos add constraint pedido_destinos_lat_check CHECK (((lat >= ('-90'::integer)::double precision) AND (lat <= (90)::double precision)));
alter table public.pedido_destinos add constraint pedido_destinos_lng_check CHECK (((lng >= ('-180'::integer)::double precision) AND (lng <= (180)::double precision)));
alter table public.pedido_destinos add constraint pedido_destinos_pkey PRIMARY KEY (venda_id);
alter table public.produto_adicionais add constraint produto_adicionais_pkey PRIMARY KEY (id);
alter table public.produto_adicionais add constraint produto_adicionais_produto_id_adicional_id_key UNIQUE (produto_id, adicional_id);
alter table public.produto_ingredientes add constraint produto_ingredientes_pkey PRIMARY KEY (id);
alter table public.produto_precos add constraint produto_precos_pkey PRIMARY KEY (id);
alter table public.produto_precos add constraint produto_precos_produto_id_forma_pagamento_id_key UNIQUE (produto_id, forma_pagamento_id);
alter table public.produtos add constraint produtos_pkey PRIMARY KEY (id);
alter table public.promocoes add constraint promocoes_pkey PRIMARY KEY (id);
alter table public.requisicoes add constraint requisicoes_pkey PRIMARY KEY (chave);
alter table public.sangrias add constraint sangrias_pkey PRIMARY KEY (id);
alter table public.sistema add constraint sistema_pkey PRIMARY KEY (chave);
alter table public.sync_estado add constraint sync_estado_id_check CHECK (id);
alter table public.sync_estado add constraint sync_estado_pkey PRIMARY KEY (id);
alter table public.tentativas add constraint tentativas_pkey PRIMARY KEY (chave);
alter table public.usuarios add constraint usuarios_login_key UNIQUE (login);
alter table public.usuarios add constraint usuarios_pkey PRIMARY KEY (id);
alter table public.vendas add constraint vendas_pkey PRIMARY KEY (id);
alter table public.vendas add constraint vendas_requisicao_id_key UNIQUE (requisicao_id);
alter table public.versoes_sync add constraint versoes_sync_pkey PRIMARY KEY (grupo);

-- ---------------------------------------------------------------------
-- 7. CHAVES ESTRANGEIRAS
-- ---------------------------------------------------------------------
alter table public.adicionais add constraint adicionais_ingrediente_id_fkey FOREIGN KEY (ingrediente_id) REFERENCES estoque(id) ON DELETE SET NULL;
alter table public.ajustes_pos_venda add constraint ajustes_pos_venda_autorizado_por_fkey FOREIGN KEY (autorizado_por) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.ajustes_pos_venda add constraint ajustes_pos_venda_despesa_id_fkey FOREIGN KEY (despesa_id) REFERENCES despesas(id) ON DELETE SET NULL;
alter table public.ajustes_pos_venda add constraint ajustes_pos_venda_registrado_por_fkey FOREIGN KEY (registrado_por) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.ajustes_pos_venda add constraint ajustes_pos_venda_venda_id_fkey FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE RESTRICT;
alter table public.auditoria add constraint auditoria_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.backups add constraint backups_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.brindes add constraint brindes_caixa_id_fkey FOREIGN KEY (caixa_id) REFERENCES caixa_sessoes(id);
alter table public.brindes add constraint brindes_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES clientes(id);
alter table public.brindes add constraint brindes_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE SET NULL;
alter table public.caixa_sessoes add constraint caixa_sessoes_usuario_abertura_fkey FOREIGN KEY (usuario_abertura) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.caixa_sessoes add constraint caixa_sessoes_usuario_fechamento_fkey FOREIGN KEY (usuario_fechamento) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.chat_conversas add constraint chat_conversas_atendente_id_fkey FOREIGN KEY (atendente_id) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.chat_conversas add constraint chat_conversas_ocorrencia_id_fkey FOREIGN KEY (ocorrencia_id) REFERENCES ocorrencias(id) ON DELETE SET NULL;
alter table public.chat_conversas add constraint chat_conversas_venda_id_fkey FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE CASCADE;
alter table public.chat_mensagens add constraint chat_mensagens_autor_id_fkey FOREIGN KEY (autor_id) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.chat_mensagens add constraint chat_mensagens_conversa_id_fkey FOREIGN KEY (conversa_id) REFERENCES chat_conversas(id) ON DELETE CASCADE;
alter table public.chat_tokens add constraint chat_tokens_conversa_id_fkey FOREIGN KEY (conversa_id) REFERENCES chat_conversas(id) ON DELETE CASCADE;
alter table public.codigo_snapshots add constraint codigo_snapshots_enviado_por_fkey FOREIGN KEY (enviado_por) REFERENCES usuarios(id);
alter table public.codigo_versoes add constraint codigo_versoes_enviado_por_fkey FOREIGN KEY (enviado_por) REFERENCES usuarios(id);
alter table public.combo_itens add constraint combo_itens_combo_id_fkey FOREIGN KEY (combo_id) REFERENCES combos(id) ON DELETE CASCADE;
alter table public.combo_itens add constraint combo_itens_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE RESTRICT;
alter table public.combo_precos add constraint combo_precos_combo_id_fkey FOREIGN KEY (combo_id) REFERENCES combos(id) ON DELETE CASCADE;
alter table public.combo_precos add constraint combo_precos_forma_pagamento_id_fkey FOREIGN KEY (forma_pagamento_id) REFERENCES formas_pagamento(id) ON DELETE CASCADE;
alter table public.combos add constraint combos_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL;
alter table public.cupons add constraint cupons_criado_por_fkey FOREIGN KEY (criado_por) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.cupons_usos add constraint cupons_usos_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL;
alter table public.cupons_usos add constraint cupons_usos_cupom_id_fkey FOREIGN KEY (cupom_id) REFERENCES cupons(id) ON DELETE CASCADE;
alter table public.cupons_usos add constraint cupons_usos_venda_id_fkey FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE SET NULL;
alter table public.despesas add constraint despesas_recorrente_id_fkey FOREIGN KEY (recorrente_id) REFERENCES despesas_recorrentes(id) ON DELETE SET NULL;
alter table public.entrega_destinos add constraint entrega_destinos_venda_id_fkey FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE CASCADE;
alter table public.entregador_posicoes add constraint entregador_posicoes_entregador_id_fkey FOREIGN KEY (entregador_id) REFERENCES usuarios(id) ON DELETE CASCADE;
alter table public.entregador_posicoes add constraint entregador_posicoes_venda_id_fkey FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE CASCADE;
alter table public.entregas_fechadas add constraint entregas_fechadas_entregador_id_fkey FOREIGN KEY (entregador_id) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.entregas_fechadas add constraint entregas_fechadas_fechamento_id_fkey FOREIGN KEY (fechamento_id) REFERENCES fechamentos_entrega(id) ON DELETE CASCADE;
alter table public.entregas_fechadas add constraint entregas_fechadas_venda_id_fkey FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE RESTRICT;
alter table public.eventos add constraint eventos_criado_por_fkey FOREIGN KEY (criado_por) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.eventos_custos add constraint eventos_custos_criado_por_fkey FOREIGN KEY (criado_por) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.eventos_custos add constraint eventos_custos_evento_id_fkey FOREIGN KEY (evento_id) REFERENCES eventos(id) ON DELETE CASCADE;
alter table public.eventos_recebimentos add constraint eventos_recebimentos_criado_por_fkey FOREIGN KEY (criado_por) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.eventos_recebimentos add constraint eventos_recebimentos_evento_id_fkey FOREIGN KEY (evento_id) REFERENCES eventos(id) ON DELETE CASCADE;
alter table public.fechamentos_entrega add constraint fechamentos_entrega_entregador_id_fkey FOREIGN KEY (entregador_id) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.fechamentos_entrega add constraint fechamentos_entrega_fechado_por_fkey FOREIGN KEY (fechado_por) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.feedbacks add constraint feedbacks_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL;
alter table public.feedbacks add constraint feedbacks_venda_id_fkey FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE SET NULL;
alter table public.fidelidade add constraint fidelidade_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE CASCADE;
alter table public.fotos_historico add constraint fotos_historico_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.indicacoes add constraint indicacoes_indicado_id_fkey FOREIGN KEY (indicado_id) REFERENCES clientes(id) ON DELETE SET NULL;
alter table public.indicacoes add constraint indicacoes_indicador_id_fkey FOREIGN KEY (indicador_id) REFERENCES clientes(id) ON DELETE SET NULL;
alter table public.itens_venda add constraint itens_venda_combo_id_fkey FOREIGN KEY (combo_id) REFERENCES combos(id) ON DELETE SET NULL;
alter table public.itens_venda add constraint itens_venda_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE SET NULL;
alter table public.itens_venda add constraint itens_venda_venda_id_fkey FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE CASCADE;
alter table public.mesas add constraint mesas_garcom_responsavel_id_fkey FOREIGN KEY (garcom_responsavel_id) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.mesas_codigos add constraint mesas_codigos_mesa_id_fkey FOREIGN KEY (mesa_id) REFERENCES mesas(id) ON DELETE CASCADE;
alter table public.movimentacoes_estoque add constraint movimentacoes_estoque_ingrediente_id_fkey FOREIGN KEY (ingrediente_id) REFERENCES estoque(id) ON DELETE RESTRICT;
alter table public.movimentacoes_estoque add constraint movimentacoes_estoque_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.ocorrencias add constraint ocorrencias_registrado_por_fkey FOREIGN KEY (registrado_por) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.ocorrencias add constraint ocorrencias_venda_id_fkey FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE SET NULL;
alter table public.pagamentos_venda add constraint pagamentos_venda_venda_id_fkey FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE CASCADE;
alter table public.pedido_destinos add constraint pedido_destinos_venda_id_fkey FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE CASCADE;
alter table public.produto_adicionais add constraint produto_adicionais_adicional_id_fkey FOREIGN KEY (adicional_id) REFERENCES adicionais(id) ON DELETE CASCADE;
alter table public.produto_adicionais add constraint produto_adicionais_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE CASCADE;
alter table public.produto_ingredientes add constraint produto_ingredientes_ingrediente_id_fkey FOREIGN KEY (ingrediente_id) REFERENCES estoque(id) ON DELETE RESTRICT;
alter table public.produto_ingredientes add constraint produto_ingredientes_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE CASCADE;
alter table public.produto_precos add constraint produto_precos_forma_pagamento_id_fkey FOREIGN KEY (forma_pagamento_id) REFERENCES formas_pagamento(id) ON DELETE CASCADE;
alter table public.produto_precos add constraint produto_precos_produto_id_fkey FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE CASCADE;
alter table public.produtos add constraint produtos_categoria_id_fkey FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL;
alter table public.produtos add constraint produtos_estoque_proprio_ingrediente_id_fkey FOREIGN KEY (estoque_proprio_ingrediente_id) REFERENCES estoque(id) ON DELETE SET NULL;
alter table public.requisicoes add constraint requisicoes_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.sangrias add constraint sangrias_caixa_id_fkey FOREIGN KEY (caixa_id) REFERENCES caixa_sessoes(id) ON DELETE SET NULL;
alter table public.sangrias add constraint sangrias_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.usuarios add constraint usuarios_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;
alter table public.vendas add constraint vendas_caixa_id_fkey FOREIGN KEY (caixa_id) REFERENCES caixa_sessoes(id) ON DELETE SET NULL;
alter table public.vendas add constraint vendas_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL;
alter table public.vendas add constraint vendas_entregador_id_fkey FOREIGN KEY (entregador_id) REFERENCES usuarios(id) ON DELETE SET NULL;
alter table public.vendas add constraint vendas_fechamento_entrega_id_fkey FOREIGN KEY (fechamento_entrega_id) REFERENCES fechamentos_entrega(id) ON DELETE SET NULL;
alter table public.vendas add constraint vendas_mesa_id_fkey FOREIGN KEY (mesa_id) REFERENCES mesas(id) ON DELETE SET NULL;
alter table public.vendas add constraint vendas_registrado_por_fkey FOREIGN KEY (registrado_por) REFERENCES usuarios(id) ON DELETE SET NULL;

-- ---------------------------------------------------------------------
-- 8. ÍNDICES
-- ---------------------------------------------------------------------
CREATE UNIQUE INDEX ai_ajuda_slug_uq ON public.ai_ajuda USING btree (slug);
CREATE INDEX ai_cache_expira_idx ON public.ai_cache USING btree (expira_em);
CREATE INDEX ai_log_criado_idx ON public.ai_log USING btree (criado_em DESC);
CREATE INDEX ai_log_usuario_idx ON public.ai_log USING btree (usuario_id, criado_em DESC);
CREATE INDEX auditoria_data_idx ON public.auditoria USING btree (data_hora DESC);
CREATE INDEX brindes_caixa_idx ON public.brindes USING btree (caixa_id);
CREATE INDEX brindes_cliente_idx ON public.brindes USING btree (cliente_id, data_hora DESC);
CREATE UNIQUE INDEX caixa_um_aberto_uq ON public.caixa_sessoes USING btree (status) WHERE (status = 'Aberto'::status_caixa);
CREATE INDEX chat_conversas_atendente_idx ON public.chat_conversas USING btree (atendente_id);
CREATE INDEX chat_conversas_fila_idx ON public.chat_conversas USING btree (estado, atualizado_em DESC) WHERE (estado <> 'encerrada'::text);
CREATE INDEX chat_conversas_ocorrencia_idx ON public.chat_conversas USING btree (ocorrencia_id);
CREATE UNIQUE INDEX chat_conversas_uma_ativa_por_pedido ON public.chat_conversas USING btree (venda_id) WHERE (estado <> 'encerrada'::text);
CREATE INDEX chat_conversas_venda_idx ON public.chat_conversas USING btree (venda_id);
CREATE INDEX chat_mensagens_autor_idx ON public.chat_mensagens USING btree (autor_id);
CREATE INDEX chat_mensagens_conversa_idx ON public.chat_mensagens USING btree (conversa_id, id);
CREATE UNIQUE INDEX clientes_telefone_digitos_uq ON public.clientes USING btree (_so_digitos(telefone)) WHERE ((telefone IS NOT NULL) AND (telefone <> ''::text) AND (_so_digitos(telefone) <> ''::text));
CREATE UNIQUE INDEX clientes_telefone_uq ON public.clientes USING btree (telefone) WHERE ((telefone IS NOT NULL) AND (telefone <> ''::text));
CREATE INDEX codigo_snapshots_arquivo_hash_idx ON public.codigo_snapshots USING btree (arquivo, hash);
CREATE INDEX codigo_versoes_arquivo_idx ON public.codigo_versoes USING btree (arquivo, enviado_em DESC);
CREATE INDEX despesas_data_idx ON public.despesas USING btree (data_hora DESC);
CREATE UNIQUE INDEX despesas_recorrente_mes_uq ON public.despesas USING btree (recorrente_id, competencia) WHERE (recorrente_id IS NOT NULL);
CREATE INDEX entregador_posicoes_entregador_idx ON public.entregador_posicoes USING btree (entregador_id);
CREATE INDEX erros_cliente_ultima_idx ON public.erros_cliente USING btree (ultima_em DESC);
CREATE INDEX fila_sync_pend_contingencia_idx ON public.fila_sync USING btree (id) WHERE (contingencia_ok_em IS NULL);
CREATE INDEX fila_sync_pend_principal_idx ON public.fila_sync USING btree (id) WHERE (principal_ok_em IS NULL);
CREATE INDEX idx_fk_17822 ON public.produtos USING btree (categoria_id);
CREATE INDEX idx_fk_17827 ON public.produtos USING btree (estoque_proprio_ingrediente_id);
CREATE INDEX idx_fk_17844 ON public.combos USING btree (categoria_id);
CREATE INDEX idx_fk_17864 ON public.produto_precos USING btree (forma_pagamento_id);
CREATE INDEX idx_fk_17884 ON public.combo_precos USING btree (forma_pagamento_id);
CREATE INDEX idx_fk_17897 ON public.combo_itens USING btree (combo_id);
CREATE INDEX idx_fk_17902 ON public.combo_itens USING btree (produto_id);
CREATE INDEX idx_fk_17914 ON public.produto_ingredientes USING btree (produto_id);
CREATE INDEX idx_fk_17919 ON public.produto_ingredientes USING btree (ingrediente_id);
CREATE INDEX idx_fk_17935 ON public.adicionais USING btree (ingrediente_id);
CREATE INDEX idx_fk_17953 ON public.produto_adicionais USING btree (adicional_id);
CREATE INDEX idx_fk_17986 ON public.cupons USING btree (criado_por);
CREATE INDEX idx_fk_18002 ON public.mesas USING btree (garcom_responsavel_id);
CREATE INDEX idx_fk_18029 ON public.caixa_sessoes USING btree (usuario_abertura);
CREATE INDEX idx_fk_18034 ON public.caixa_sessoes USING btree (usuario_fechamento);
CREATE INDEX idx_fk_18057 ON public.fechamentos_entrega USING btree (entregador_id);
CREATE INDEX idx_fk_18062 ON public.fechamentos_entrega USING btree (fechado_por);
CREATE INDEX idx_fk_18088 ON public.vendas USING btree (cliente_id);
CREATE INDEX idx_fk_18103 ON public.vendas USING btree (fechamento_entrega_id);
CREATE INDEX idx_fk_18108 ON public.vendas USING btree (registrado_por);
CREATE INDEX idx_fk_18113 ON public.vendas USING btree (caixa_id);
CREATE INDEX idx_fk_18142 ON public.itens_venda USING btree (produto_id);
CREATE INDEX idx_fk_18147 ON public.itens_venda USING btree (combo_id);
CREATE INDEX idx_fk_18178 ON public.entregas_fechadas USING btree (fechamento_id);
CREATE INDEX idx_fk_18188 ON public.entregas_fechadas USING btree (entregador_id);
CREATE INDEX idx_fk_18204 ON public.cupons_usos USING btree (cupom_id);
CREATE INDEX idx_fk_18209 ON public.cupons_usos USING btree (venda_id);
CREATE INDEX idx_fk_18214 ON public.cupons_usos USING btree (cliente_id);
CREATE INDEX idx_fk_18233 ON public.movimentacoes_estoque USING btree (usuario_id);
CREATE INDEX idx_fk_18281 ON public.sangrias USING btree (usuario_id);
CREATE INDEX idx_fk_18286 ON public.sangrias USING btree (caixa_id);
CREATE INDEX idx_fk_18303 ON public.ajustes_pos_venda USING btree (venda_id);
CREATE INDEX idx_fk_18308 ON public.ajustes_pos_venda USING btree (despesa_id);
CREATE INDEX idx_fk_18313 ON public.ajustes_pos_venda USING btree (autorizado_por);
CREATE INDEX idx_fk_18318 ON public.ajustes_pos_venda USING btree (registrado_por);
CREATE INDEX idx_fk_18338 ON public.eventos USING btree (criado_por);
CREATE INDEX idx_fk_18353 ON public.eventos_custos USING btree (evento_id);
CREATE INDEX idx_fk_18358 ON public.eventos_custos USING btree (criado_por);
CREATE INDEX idx_fk_18373 ON public.eventos_recebimentos USING btree (evento_id);
CREATE INDEX idx_fk_18378 ON public.eventos_recebimentos USING btree (criado_por);
CREATE INDEX idx_fk_18412 ON public.indicacoes USING btree (indicador_id);
CREATE INDEX idx_fk_18417 ON public.indicacoes USING btree (indicado_id);
CREATE INDEX idx_fk_18433 ON public.feedbacks USING btree (venda_id);
CREATE INDEX idx_fk_18438 ON public.feedbacks USING btree (cliente_id);
CREATE INDEX idx_fk_18457 ON public.ocorrencias USING btree (venda_id);
CREATE INDEX idx_fk_18462 ON public.ocorrencias USING btree (registrado_por);
CREATE INDEX idx_fk_18484 ON public.auditoria USING btree (usuario_id);
CREATE INDEX idx_fk_18501 ON public.backups USING btree (usuario_id);
CREATE INDEX idx_fk_18514 ON public.requisicoes USING btree (usuario_id);
CREATE INDEX idx_fotos_historico_usuario_id ON public.fotos_historico USING btree (usuario_id);
CREATE INDEX itens_venda_venda_idx ON public.itens_venda USING btree (venda_id);
CREATE INDEX mov_estoque_ing_idx ON public.movimentacoes_estoque USING btree (ingrediente_id, data DESC);
CREATE INDEX pagamentos_venda_venda_idx ON public.pagamentos_venda USING btree (venda_id);
CREATE INDEX requisicoes_data_idx ON public.requisicoes USING btree (data_hora);
CREATE INDEX vendas_data_idx ON public.vendas USING btree (data_hora DESC);
CREATE INDEX vendas_entregador_idx ON public.vendas USING btree (entregador_id) WHERE (entregador_id IS NOT NULL);
CREATE INDEX vendas_id_sufixo8_idx ON public.vendas USING btree ("right"((id)::text, 8));
CREATE INDEX vendas_mesa_idx ON public.vendas USING btree (mesa_id) WHERE (mesa_id IS NOT NULL);
CREATE INDEX vendas_status_pedido_idx ON public.vendas USING btree (status_pedido) WHERE (status = 'Confirmada'::venda_status);
CREATE INDEX vendas_telefone_idx ON public.vendas USING btree (telefone_cliente);

-- ---------------------------------------------------------------------
-- 9. VIEWS
-- ---------------------------------------------------------------------
create or replace view public.v_cardapio_adicionais as
 SELECT pa.produto_id,
    a.id AS adicional_id,
    a.nome,
    a.preco
   FROM produto_adicionais pa
     JOIN adicionais a ON a.id = pa.adicional_id AND a.ativo
     JOIN produtos p ON p.id = pa.produto_id AND p.ativo;

create or replace view public.v_cardapio_categorias as
 SELECT id,
    nome,
    ordem
   FROM categorias
  WHERE ativa;

create or replace view public.v_cardapio_combo_itens as
 SELECT ci.combo_id,
    ci.produto_id,
    ci.quantidade
   FROM combo_itens ci
     JOIN combos c ON c.id = ci.combo_id AND c.ativo;

create or replace view public.v_cardapio_combos as
 SELECT id,
    nome,
    categoria_id,
    destaque,
    ordem_cardapio,
    foto_id_principal,
    foto_id_contingencia,
    foto_url_principal,
    foto_url_contingencia,
    foto_preferida
   FROM combos
  WHERE ativo;

create or replace view public.v_cardapio_config as
 SELECT chave,
    valor
   FROM sistema
  WHERE chave = ANY (ARRAY['CardapioKicker'::text, 'CardapioFrase'::text, 'CardapioTempoRetirada'::text, 'CardapioTempoMesa'::text, 'CardapioTempoEntrega'::text, 'TaxaEntregaPadrao'::text, 'MANUTENCAO'::text]);

create or replace view public.v_cardapio_formas as
 SELECT id,
    nome,
    ordem,
    permite_troco
   FROM formas_pagamento
  WHERE ativa AND visivel_cardapio;

create or replace view public.v_cardapio_precos as
 SELECT 'produto'::text AS tipo,
    pp.produto_id AS item_id,
    pp.forma_pagamento_id,
    pp.preco
   FROM produto_precos pp
     JOIN produtos p ON p.id = pp.produto_id AND p.ativo
     JOIN formas_pagamento f ON f.id = pp.forma_pagamento_id AND f.ativa AND f.visivel_cardapio
UNION ALL
 SELECT 'combo'::text AS tipo,
    cp.combo_id AS item_id,
    cp.forma_pagamento_id,
    cp.preco
   FROM combo_precos cp
     JOIN combos c ON c.id = cp.combo_id AND c.ativo
     JOIN formas_pagamento f ON f.id = cp.forma_pagamento_id AND f.ativa AND f.visivel_cardapio;

create or replace view public.v_cardapio_produtos as
 SELECT id,
    nome,
    descricao,
    categoria_id,
    destaque,
    ordem_cardapio,
    foto_id_principal,
    foto_id_contingencia,
    foto_url_principal,
    foto_url_contingencia,
    foto_preferida
   FROM produtos
  WHERE ativo;

create or replace view public.v_cardapio_status as
 SELECT (EXISTS ( SELECT 1
           FROM caixa_sessoes
          WHERE caixa_sessoes.status = 'Aberto'::status_caixa)) AS caixa_aberto;

create or replace view public.v_fidelidade with (security_invoker=true) as
 SELECT c.nome,
    c.telefone,
    f.carimbos,
    f.premios_resgatados AS premios,
    f.atualizada_em AS atualizado,
    f.observacoes AS observacao,
    f.cliente_id
   FROM fidelidade f
     JOIN clientes c ON c.id = f.cliente_id;

create or replace view public.v_formas_operacional with (security_invoker=true) as
 SELECT id,
    nome,
    ordem,
    permite_troco
   FROM formas_pagamento
  WHERE ativa;

create or replace view public.v_indicacoes as
 SELECT id,
    nome_indicador,
    telefone_indicador,
    nome_indicado,
    telefone_indicado,
    data,
    status,
    observacoes,
    indicador_id,
    indicado_id
   FROM indicacoes i
  WHERE tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]) OR tem_nivel(VARIADIC ARRAY['Garçom'::nivel_acesso]) AND _so_digitos(telefone_indicador) <> ''::text AND _so_digitos(telefone_indicador) = (( SELECT _so_digitos(u.telefone) AS _so_digitos
           FROM usuarios u
          WHERE u.id = auth.uid()));

create or replace view public.v_itens_venda with (security_invoker=true) as
 SELECT id,
    venda_id,
    produto_id,
    combo_id,
    descricao,
    quantidade,
    valor_unitario,
        CASE
            WHEN auth_nivel() = ANY (ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]) THEN custo_unitario
            ELSE NULL::numeric
        END AS custo_unitario,
    valor_total_item,
    adicionais_ids
   FROM itens_venda i;

create or replace view public.v_mesas as
 SELECT m.id,
    m.numero,
    m.status,
    m.capacidade,
    m.observacao,
    m.chamado_tipo,
    m.chamado_em,
    u.login AS garcom_responsavel
   FROM mesas m
     LEFT JOIN usuarios u ON u.id = m.garcom_responsavel_id
  WHERE tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso, 'Garçom'::nivel_acesso]);

create or replace view public.v_ocorrencias with (security_invoker=true) as
 SELECT id,
    numero,
    data_hora,
    tipo,
    setor,
    venda_id,
    cliente,
    telefone,
    _login_de(registrado_por) AS registrado_por,
    responsavel,
    descricao,
    solucao,
    status,
    atualizada_em,
    historico
   FROM ocorrencias o;

create or replace view public.v_sessao_aberta as
 SELECT id,
    abertura,
        CASE
            WHEN auth_nivel()::text = ANY (ARRAY['Admin'::text, 'Operador'::text, 'Desenvolvedor'::text]) THEN fundo_caixa
            ELSE NULL::numeric
        END::numeric(10,2) AS fundo_caixa,
    _login_de(usuario_abertura) AS usuario_abertura
   FROM caixa_sessoes s
  WHERE status = 'Aberto'::status_caixa AND auth_nivel() IS NOT NULL;

create or replace view public.v_vendas with (security_invoker=true) as
 SELECT id,
    numero_pedido AS numero,
    data_hora,
    cliente_nome,
    telefone_cliente AS cliente_telefone,
    forma_pagamento,
    valor_total,
        CASE
            WHEN auth_nivel() = ANY (ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]) THEN custo_total
            ELSE NULL::numeric
        END AS custo_total,
    status,
    motivo_cancelamento,
    tipo AS tipo_entrega,
    status_pedido,
    endereco,
    complemento,
    referencia,
    observacoes_entrega,
    pronta_em,
    concluida_em,
    status_pagamento,
    recebido_em,
    valor_original,
    valor_desconto,
    desconto_detalhe,
    _login_de(entregador_id) AS entregador,
    saiu_em,
    origem,
    mesa_id,
    taxa_entrega,
    fechamento_entrega_id,
    _login_de(registrado_por) AS registrado_por,
    inicio_preparo_em,
    _mesa_numero_de(mesa_id) AS mesa_numero
   FROM vendas v;

create or replace view public.v_cardapio_esgotados as
 WITH ligado AS (
         SELECT COALESCE(( SELECT (sistema.valor #>> '{}'::text[]) = ANY (ARRAY['true'::text, 'Sim'::text])
                   FROM sistema
                  WHERE sistema.chave = 'BLOQUEAR_ESTOQUE_NEGATIVO'::text), false) AS on_
        ), falta AS (
         SELECT pi.produto_id,
            bool_or(pi.quantidade_por_unidade > 0::numeric AND (e.quantidade + 0.000000001) < pi.quantidade_por_unidade) AS f1,
            min(
                CASE
                    WHEN pi.quantidade_por_unidade > 0::numeric THEN e.quantidade / pi.quantidade_por_unidade
                    ELSE NULL::numeric
                END) AS razao
           FROM produto_ingredientes pi
             JOIN estoque e ON e.id = pi.ingrediente_id
          GROUP BY pi.produto_id
        )
 SELECT 'produto'::text AS tipo,
    p.id
   FROM v_cardapio_produtos p
     JOIN falta f ON f.produto_id = p.id,
    ligado
  WHERE ligado.on_ AND f.f1
UNION ALL
 SELECT 'combo'::text AS tipo,
    b.id
   FROM v_cardapio_combos b,
    ligado
  WHERE ligado.on_ AND (EXISTS ( SELECT 1
           FROM combo_itens ci
             JOIN produto_ingredientes pi ON pi.produto_id = ci.produto_id
             JOIN estoque e ON e.id = pi.ingrediente_id
          WHERE ci.combo_id = b.id AND pi.quantidade_por_unidade > 0::numeric AND (e.quantidade + 0.000000001) < (pi.quantidade_por_unidade * GREATEST(COALESCE(ci.quantidade, 1), 1)::numeric)));

create or replace view public.v_cardapio_mais_pedidos as
 WITH cont AS (
         SELECT COALESCE('p_'::text || iv.produto_id::text, 'c_'::text || iv.combo_id::text) AS chave,
                CASE
                    WHEN iv.produto_id IS NOT NULL THEN 'produto'::text
                    ELSE 'combo'::text
                END AS tipo,
            COALESCE(iv.produto_id, iv.combo_id) AS item_id,
            sum(COALESCE(iv.quantidade, 1)) AS qtd
           FROM itens_venda iv
             JOIN vendas v ON v.id = iv.venda_id
          WHERE v.status = 'Confirmada'::venda_status AND v.data_hora >= (now() - '30 days'::interval) AND (iv.produto_id IS NOT NULL OR iv.combo_id IS NOT NULL)
          GROUP BY (COALESCE('p_'::text || iv.produto_id::text, 'c_'::text || iv.combo_id::text)), (
                CASE
                    WHEN iv.produto_id IS NOT NULL THEN 'produto'::text
                    ELSE 'combo'::text
                END), (COALESCE(iv.produto_id, iv.combo_id))
        ), vis AS (
         SELECT c.tipo,
            c.item_id,
            c.qtd
           FROM cont c
          WHERE c.tipo = 'produto'::text AND (EXISTS ( SELECT 1
                   FROM v_cardapio_produtos p
                  WHERE p.id = c.item_id)) OR c.tipo = 'combo'::text AND (EXISTS ( SELECT 1
                   FROM v_cardapio_combos b
                  WHERE b.id = c.item_id))
        )
 SELECT tipo,
    item_id AS id,
    row_number() OVER (ORDER BY qtd DESC, item_id)::integer AS posicao
   FROM vis
  ORDER BY qtd DESC, item_id
 LIMIT 8;


-- ---------------------------------------------------------------------
-- 10. TRIGGERS
-- ---------------------------------------------------------------------
CREATE TRIGGER adicionais_sync AFTER INSERT OR DELETE OR UPDATE ON public.adicionais FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER adicionais_versao AFTER INSERT OR DELETE OR UPDATE ON public.adicionais DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER ajustes_pos_venda_sync AFTER INSERT OR DELETE OR UPDATE ON public.ajustes_pos_venda FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER ajustes_pos_venda_versao AFTER INSERT OR DELETE OR UPDATE ON public.ajustes_pos_venda DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER caixa_sessoes_sync AFTER INSERT OR DELETE OR UPDATE ON public.caixa_sessoes FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER caixa_sessoes_versao AFTER INSERT OR DELETE OR UPDATE ON public.caixa_sessoes DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER categorias_sync AFTER INSERT OR DELETE OR UPDATE ON public.categorias FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER categorias_versao AFTER INSERT OR DELETE OR UPDATE ON public.categorias DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER chat_conversas_normalizar_intencao BEFORE INSERT OR UPDATE ON public.chat_conversas FOR EACH ROW EXECUTE FUNCTION _chat_normalizar_intencao();
CREATE TRIGGER clientes_sync AFTER INSERT OR DELETE OR UPDATE ON public.clientes FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER clientes_versao AFTER INSERT OR DELETE OR UPDATE ON public.clientes DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER combo_itens_sync AFTER INSERT OR DELETE OR UPDATE ON public.combo_itens FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER combo_itens_versao AFTER INSERT OR DELETE OR UPDATE ON public.combo_itens DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER combo_precos_sync AFTER INSERT OR DELETE OR UPDATE ON public.combo_precos FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER combo_precos_versao AFTER INSERT OR DELETE OR UPDATE ON public.combo_precos DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER combos_sync AFTER INSERT OR DELETE OR UPDATE ON public.combos FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER combos_versao AFTER INSERT OR DELETE OR UPDATE ON public.combos DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER fotos_cfg_atualizado BEFORE UPDATE ON public.configuracoes_fotos FOR EACH ROW EXECUTE FUNCTION tocar_atualizado_em();
CREATE TRIGGER cupons_sync AFTER INSERT OR DELETE OR UPDATE ON public.cupons FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER cupons_versao AFTER INSERT OR DELETE OR UPDATE ON public.cupons DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER cupons_usos_sync AFTER INSERT OR DELETE OR UPDATE ON public.cupons_usos FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER cupons_usos_versao AFTER INSERT OR DELETE OR UPDATE ON public.cupons_usos DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER despesas_sync AFTER INSERT OR DELETE OR UPDATE ON public.despesas FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER despesas_versao AFTER INSERT OR DELETE OR UPDATE ON public.despesas DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER despesas_recorrentes_sync AFTER INSERT OR DELETE OR UPDATE ON public.despesas_recorrentes FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER despesas_recorrentes_versao AFTER INSERT OR DELETE OR UPDATE ON public.despesas_recorrentes DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER entregas_fechadas_sync AFTER INSERT OR DELETE OR UPDATE ON public.entregas_fechadas FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER entregas_fechadas_versao AFTER INSERT OR DELETE OR UPDATE ON public.entregas_fechadas DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER estoque_sync AFTER INSERT OR DELETE OR UPDATE ON public.estoque FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER estoque_versao AFTER INSERT OR DELETE OR UPDATE ON public.estoque DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER eventos_atualizado BEFORE UPDATE ON public.eventos FOR EACH ROW EXECUTE FUNCTION tocar_atualizado_em();
CREATE TRIGGER eventos_sync AFTER INSERT OR DELETE OR UPDATE ON public.eventos FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER eventos_versao AFTER INSERT OR DELETE OR UPDATE ON public.eventos DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER eventos_custos_sync AFTER INSERT OR DELETE OR UPDATE ON public.eventos_custos FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER eventos_custos_versao AFTER INSERT OR DELETE OR UPDATE ON public.eventos_custos DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER eventos_recebimentos_sync AFTER INSERT OR DELETE OR UPDATE ON public.eventos_recebimentos FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER eventos_recebimentos_versao AFTER INSERT OR DELETE OR UPDATE ON public.eventos_recebimentos DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER fechamentos_entrega_sync AFTER INSERT OR DELETE OR UPDATE ON public.fechamentos_entrega FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER fechamentos_entrega_versao AFTER INSERT OR DELETE OR UPDATE ON public.fechamentos_entrega DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER feedbacks_sync AFTER INSERT OR DELETE OR UPDATE ON public.feedbacks FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER feedbacks_versao AFTER INSERT OR DELETE OR UPDATE ON public.feedbacks DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER fidelidade_sync AFTER INSERT OR DELETE OR UPDATE ON public.fidelidade FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER fidelidade_versao AFTER INSERT OR DELETE OR UPDATE ON public.fidelidade DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER formas_pagamento_sync AFTER INSERT OR DELETE OR UPDATE ON public.formas_pagamento FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER formas_pagamento_versao AFTER INSERT OR DELETE OR UPDATE ON public.formas_pagamento DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER indicacoes_sync AFTER INSERT OR DELETE OR UPDATE ON public.indicacoes FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER indicacoes_versao AFTER INSERT OR DELETE OR UPDATE ON public.indicacoes DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER itens_venda_sync AFTER INSERT OR DELETE OR UPDATE ON public.itens_venda FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE TRIGGER itens_venda_validar_adicionais BEFORE INSERT OR UPDATE OF produto_id, combo_id, adicionais_ids ON public.itens_venda FOR EACH ROW EXECUTE FUNCTION _validar_adicionais_item_venda();
CREATE CONSTRAINT TRIGGER itens_venda_versao AFTER INSERT OR DELETE OR UPDATE ON public.itens_venda DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER mesas_sync AFTER INSERT OR DELETE OR UPDATE ON public.mesas FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER mesas_versao AFTER INSERT OR DELETE OR UPDATE ON public.mesas DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER movimentacoes_estoque_sync AFTER INSERT OR DELETE OR UPDATE ON public.movimentacoes_estoque FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER movimentacoes_estoque_versao AFTER INSERT OR DELETE OR UPDATE ON public.movimentacoes_estoque DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER ocorrencias_sync AFTER INSERT OR DELETE OR UPDATE ON public.ocorrencias FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER ocorrencias_versao AFTER INSERT OR DELETE OR UPDATE ON public.ocorrencias DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER pagamentos_venda_sync AFTER INSERT OR DELETE OR UPDATE ON public.pagamentos_venda FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER pagamentos_venda_versao AFTER INSERT OR DELETE OR UPDATE ON public.pagamentos_venda DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER produto_adicionais_sync AFTER INSERT OR DELETE OR UPDATE ON public.produto_adicionais FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER produto_adicionais_versao AFTER INSERT OR DELETE OR UPDATE ON public.produto_adicionais DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER produto_ingredientes_sync AFTER INSERT OR DELETE OR UPDATE ON public.produto_ingredientes FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER produto_ingredientes_versao AFTER INSERT OR DELETE OR UPDATE ON public.produto_ingredientes DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER produto_precos_sync AFTER INSERT OR DELETE OR UPDATE ON public.produto_precos FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER produto_precos_versao AFTER INSERT OR DELETE OR UPDATE ON public.produto_precos DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER produtos_sync AFTER INSERT OR DELETE OR UPDATE ON public.produtos FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER produtos_versao AFTER INSERT OR DELETE OR UPDATE ON public.produtos DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER promocoes_sync AFTER INSERT OR DELETE OR UPDATE ON public.promocoes FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER promocoes_versao AFTER INSERT OR DELETE OR UPDATE ON public.promocoes DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER sangrias_sync AFTER INSERT OR DELETE OR UPDATE ON public.sangrias FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER sangrias_versao AFTER INSERT OR DELETE OR UPDATE ON public.sangrias DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER sistema_atualizado BEFORE UPDATE ON public.sistema FOR EACH ROW EXECUTE FUNCTION tocar_atualizado_em();
CREATE TRIGGER sistema_sync AFTER INSERT OR DELETE OR UPDATE ON public.sistema FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER sistema_versao AFTER INSERT OR DELETE OR UPDATE ON public.sistema DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER usuarios_proteger_desenvolvedor BEFORE DELETE OR UPDATE ON public.usuarios FOR EACH ROW EXECUTE FUNCTION _proteger_desenvolvedor_usuarios();
CREATE TRIGGER usuarios_unico_dev BEFORE INSERT OR DELETE OR UPDATE OF nivel ON public.usuarios FOR EACH ROW EXECUTE FUNCTION _travar_unico_desenvolvedor();
CREATE CONSTRAINT TRIGGER usuarios_versao AFTER INSERT OR DELETE OR UPDATE ON public.usuarios DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();
CREATE TRIGGER vendas_limpar_loc AFTER UPDATE OF status_pedido, status ON public.vendas FOR EACH ROW WHEN (((old.status_pedido IS DISTINCT FROM new.status_pedido) OR (old.status IS DISTINCT FROM new.status))) EXECUTE FUNCTION _entrega_limpar_loc();
CREATE TRIGGER vendas_sync AFTER INSERT OR DELETE OR UPDATE ON public.vendas FOR EACH ROW EXECUTE FUNCTION enfileirar_sync();
CREATE CONSTRAINT TRIGGER vendas_versao AFTER INSERT OR DELETE OR UPDATE ON public.vendas DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION _bump_versao_sync();

-- ---------------------------------------------------------------------
-- 11. RLS LIGADO NAS TABELAS
-- ---------------------------------------------------------------------
alter table public.adicionais enable row level security;
alter table public.ai_ajuda enable row level security;
alter table public.ai_ajuda_bkp_20261007 enable row level security;
alter table public.ai_cache enable row level security;
alter table public.ai_config enable row level security;
alter table public.ai_log enable row level security;
alter table public.ai_segredos enable row level security;
alter table public.ai_uso enable row level security;
alter table public.ajustes_pos_venda enable row level security;
alter table public.arquivo_historico enable row level security;
alter table public.auditoria enable row level security;
alter table public.backup_config enable row level security;
alter table public.backups enable row level security;
alter table public.brindes enable row level security;
alter table public.caixa_sessoes enable row level security;
alter table public.categorias enable row level security;
alter table public.chat_config enable row level security;
alter table public.chat_conversas enable row level security;
alter table public.chat_ia_cotas enable row level security;
alter table public.chat_mensagens enable row level security;
alter table public.chat_tokens enable row level security;
alter table public.clientes enable row level security;
alter table public.codigo_analises enable row level security;
alter table public.codigo_snapshots enable row level security;
alter table public.codigo_versoes enable row level security;
alter table public.combo_itens enable row level security;
alter table public.combo_precos enable row level security;
alter table public.combos enable row level security;
alter table public.configuracoes_fotos enable row level security;
alter table public.contingencia_config enable row level security;
alter table public.contingencia_reconciliada enable row level security;
alter table public.cupons enable row level security;
alter table public.cupons_usos enable row level security;
alter table public.despesas enable row level security;
alter table public.despesas_recorrentes enable row level security;
alter table public.entrega_destinos enable row level security;
alter table public.entregador_posicoes enable row level security;
alter table public.entregas_fechadas enable row level security;
alter table public.erros_cliente enable row level security;
alter table public.estoque enable row level security;
alter table public.eventos enable row level security;
alter table public.eventos_custos enable row level security;
alter table public.eventos_recebimentos enable row level security;
alter table public.faq_publico enable row level security;
alter table public.fechamentos_entrega enable row level security;
alter table public.feedbacks enable row level security;
alter table public.fidelidade enable row level security;
alter table public.fila_sync enable row level security;
alter table public.formas_pagamento enable row level security;
alter table public.fotos_historico enable row level security;
alter table public.ia_relatorio_codigo enable row level security;
alter table public.indicacoes enable row level security;
alter table public.integridade_checks enable row level security;
alter table public.itens_venda enable row level security;
alter table public.mesas enable row level security;
alter table public.mesas_codigos enable row level security;
alter table public.movimentacoes_estoque enable row level security;
alter table public.ocorrencias enable row level security;
alter table public.pagamentos_venda enable row level security;
alter table public.pedido_destinos enable row level security;
alter table public.produto_adicionais enable row level security;
alter table public.produto_ingredientes enable row level security;
alter table public.produto_precos enable row level security;
alter table public.produtos enable row level security;
alter table public.promocoes enable row level security;
alter table public.requisicoes enable row level security;
alter table public.sangrias enable row level security;
alter table public.sistema enable row level security;
alter table public.sync_estado enable row level security;
alter table public.tentativas enable row level security;
alter table public.usuarios enable row level security;
alter table public.vendas enable row level security;
alter table public.versoes_sync enable row level security;

-- ---------------------------------------------------------------------
-- 12. POLÍTICAS (RLS) — quem pode ler/gravar o quê
-- ---------------------------------------------------------------------
create policy adicionais_admin on public.adicionais as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy adicionais_ler on public.adicionais as PERMISSIVE for SELECT to authenticated using ((auth_nivel() IS NOT NULL));
create policy ai_ajuda_admin on public.ai_ajuda as PERMISSIVE for ALL to public using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy ai_ajuda_ler on public.ai_ajuda as PERMISSIVE for SELECT to public using ((ativo AND ((auth_nivel())::text = ANY (perfis))));
create policy ai_config_alterar on public.ai_config as PERMISSIVE for UPDATE to public using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy ai_config_ler on public.ai_config as PERMISSIVE for SELECT to public using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy ai_log_ler on public.ai_log as PERMISSIVE for SELECT to public using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy ai_uso_ler on public.ai_uso as PERMISSIVE for SELECT to public using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy ajustes_pos_venda_ler_admin on public.ajustes_pos_venda as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy arquivo_historico_admin on public.arquivo_historico as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy auditoria_ler_admin on public.auditoria as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy backup_config_admin on public.backup_config as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy backups_ler_admin on public.backups as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy brindes_ler on public.brindes as PERMISSIVE for SELECT to public using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy caixa_ler on public.caixa_sessoes as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy categorias_admin on public.categorias as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy categorias_ler on public.categorias as PERMISSIVE for SELECT to authenticated using ((auth_nivel() IS NOT NULL));
create policy chat_config_alterar on public.chat_config as PERMISSIVE for UPDATE to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy chat_config_ler on public.chat_config as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy chat_conversas_equipe on public.chat_conversas as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy chat_mensagens_equipe on public.chat_mensagens as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy clientes_alterar on public.clientes as PERMISSIVE for UPDATE to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso, 'Garçom'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso, 'Garçom'::nivel_acesso]));
create policy clientes_criar on public.clientes as PERMISSIVE for INSERT to authenticated with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso, 'Garçom'::nivel_acesso]));
create policy clientes_excluir on public.clientes as PERMISSIVE for DELETE to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy clientes_ler on public.clientes as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso, 'Garçom'::nivel_acesso]));
create policy combo_itens_admin on public.combo_itens as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy combo_itens_ler on public.combo_itens as PERMISSIVE for SELECT to authenticated using ((auth_nivel() IS NOT NULL));
create policy combo_precos_admin on public.combo_precos as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy combo_precos_ler on public.combo_precos as PERMISSIVE for SELECT to authenticated using ((auth_nivel() IS NOT NULL));
create policy combos_admin on public.combos as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy combos_ler on public.combos as PERMISSIVE for SELECT to authenticated using ((auth_nivel() IS NOT NULL));
create policy fotos_cfg_admin on public.configuracoes_fotos as PERMISSIVE for UPDATE to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy fotos_cfg_ler on public.configuracoes_fotos as PERMISSIVE for SELECT to authenticated using ((auth_nivel() IS NOT NULL));
create policy contingencia_config_admin on public.contingencia_config as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy contrec_admin on public.contingencia_reconciliada as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy cupons_ler_admin on public.cupons as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy cupons_usos_ler on public.cupons_usos as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy despesas_alterar on public.despesas as PERMISSIVE for UPDATE to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy despesas_criar on public.despesas as PERMISSIVE for INSERT to authenticated with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy despesas_ler on public.despesas as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy despesas_recorrentes_ler_admin on public.despesas_recorrentes as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy posicoes_ler on public.entregador_posicoes as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy entregas_fechadas_ler on public.entregas_fechadas as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy entregas_fechadas_ler_admin on public.entregas_fechadas as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy entregas_fechadas_ler_entregador on public.entregas_fechadas as PERMISSIVE for SELECT to authenticated using ((tem_nivel(VARIADIC ARRAY['Entregador'::nivel_acesso]) AND (entregador_id = ( SELECT auth.uid() AS uid))));
create policy erros_cliente_ler on public.erros_cliente as PERMISSIVE for SELECT to public using ((ia_nivel_real() = 'Desenvolvedor'::text));
create policy estoque_admin on public.estoque as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy estoque_ler on public.estoque as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy eventos_ler_admin on public.eventos as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy eventos_custos_ler_admin on public.eventos_custos as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy eventos_recebimentos_ler_admin on public.eventos_recebimentos as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy faq_gravar_admin on public.faq_publico as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy faq_ler_admin on public.faq_publico as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy faq_ler_publico on public.faq_publico as PERMISSIVE for SELECT to anon, authenticated using (ativo);
create policy fechamentos_entrega_ler on public.fechamentos_entrega as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy fechamentos_entrega_ler_admin on public.fechamentos_entrega as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy fechamentos_entrega_ler_entregador on public.fechamentos_entrega as PERMISSIVE for SELECT to authenticated using ((tem_nivel(VARIADIC ARRAY['Entregador'::nivel_acesso]) AND (entregador_id = ( SELECT auth.uid() AS uid))));
create policy feedbacks_ler on public.feedbacks as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy feedbacks_status on public.feedbacks as PERMISSIVE for UPDATE to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy fidelidade_ler on public.fidelidade as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy fila_sync_ler_admin on public.fila_sync as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy formas_pagamento_admin on public.formas_pagamento as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy formas_pagamento_ler on public.formas_pagamento as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy fotos_historico_ler on public.fotos_historico as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy ia_relatorio_codigo_ler on public.ia_relatorio_codigo as PERMISSIVE for SELECT to public using ((ia_nivel_real() = 'Desenvolvedor'::text));
create policy indicacoes_ler on public.indicacoes as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy integridade_checks_ler on public.integridade_checks as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy itens_venda_alterar on public.itens_venda as PERMISSIVE for UPDATE to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy itens_venda_criar on public.itens_venda as PERMISSIVE for INSERT to authenticated with check ((tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso, 'Garçom'::nivel_acesso]) AND (EXISTS ( SELECT 1
   FROM vendas v
  WHERE (v.id = itens_venda.venda_id)))));
create policy itens_venda_ler on public.itens_venda as PERMISSIVE for SELECT to authenticated using ((EXISTS ( SELECT 1
   FROM vendas v
  WHERE (v.id = itens_venda.venda_id))));
create policy mesas_admin_criar on public.mesas as PERMISSIVE for INSERT to authenticated with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy mesas_admin_excluir on public.mesas as PERMISSIVE for DELETE to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy mesas_ler on public.mesas as PERMISSIVE for SELECT to authenticated using ((tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]) OR (tem_nivel(VARIADIC ARRAY['Garçom'::nivel_acesso]) AND ((garcom_responsavel_id IS NULL) OR (garcom_responsavel_id = auth.uid())))));
create policy mesas_status on public.mesas as PERMISSIVE for UPDATE to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso, 'Garçom'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso, 'Garçom'::nivel_acesso]));
create policy mov_estoque_ler on public.movimentacoes_estoque as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy ocorrencias_alterar on public.ocorrencias as PERMISSIVE for UPDATE to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy ocorrencias_criar on public.ocorrencias as PERMISSIVE for INSERT to authenticated with check (((( SELECT auth_nivel() AS auth_nivel) IS NOT NULL) AND (registrado_por = ( SELECT auth.uid() AS uid))));
create policy ocorrencias_ler on public.ocorrencias as PERMISSIVE for SELECT to authenticated using ((( SELECT tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]) AS tem_nivel) OR (registrado_por = ( SELECT auth.uid() AS uid))));
create policy pagamentos_venda_alterar on public.pagamentos_venda as PERMISSIVE for UPDATE to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy pagamentos_venda_criar on public.pagamentos_venda as PERMISSIVE for INSERT to authenticated with check ((tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso, 'Garçom'::nivel_acesso]) AND (EXISTS ( SELECT 1
   FROM vendas v
  WHERE (v.id = pagamentos_venda.venda_id)))));
create policy pagamentos_venda_ler on public.pagamentos_venda as PERMISSIVE for SELECT to authenticated using ((tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso, 'Entregador'::nivel_acesso]) AND (EXISTS ( SELECT 1
   FROM vendas v
  WHERE (v.id = pagamentos_venda.venda_id)))));
create policy destinos_ler on public.pedido_destinos as PERMISSIVE for SELECT to authenticated using ((tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]) OR (tem_nivel(VARIADIC ARRAY['Entregador'::nivel_acesso]) AND (EXISTS ( SELECT 1
   FROM vendas v
  WHERE ((v.id = pedido_destinos.venda_id) AND (v.entregador_id = auth.uid())))))));
create policy produto_adicionais_admin on public.produto_adicionais as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy produto_adicionais_ler on public.produto_adicionais as PERMISSIVE for SELECT to authenticated using ((auth_nivel() IS NOT NULL));
create policy produto_ingredientes_admin on public.produto_ingredientes as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy produto_ingredientes_ler on public.produto_ingredientes as PERMISSIVE for SELECT to authenticated using ((auth_nivel() IS NOT NULL));
create policy produto_precos_admin on public.produto_precos as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy produto_precos_ler on public.produto_precos as PERMISSIVE for SELECT to authenticated using ((auth_nivel() IS NOT NULL));
create policy produtos_admin on public.produtos as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy produtos_ler on public.produtos as PERMISSIVE for SELECT to authenticated using ((auth_nivel() IS NOT NULL));
create policy promocoes_admin on public.promocoes as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy promocoes_ler on public.promocoes as PERMISSIVE for SELECT to authenticated using ((auth_nivel() IS NOT NULL));
create policy sangrias_criar on public.sangrias as PERMISSIVE for INSERT to authenticated with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy sangrias_ler on public.sangrias as PERMISSIVE for SELECT to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy sistema_admin on public.sistema as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy sistema_ler on public.sistema as PERMISSIVE for SELECT to authenticated using ((auth_nivel() IS NOT NULL));
create policy sync_estado_admin on public.sync_estado as PERMISSIVE for ALL to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso]));
create policy usuarios_ler_proprio on public.usuarios as PERMISSIVE for SELECT to authenticated using (((id = ( SELECT auth.uid() AS uid)) OR ( SELECT tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]) AS tem_nivel)));
create policy vendas_alterar on public.vendas as PERMISSIVE for UPDATE to authenticated using (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso])) with check (tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]));
create policy vendas_criar on public.vendas as PERMISSIVE for INSERT to authenticated with check ((( SELECT tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]) AS tem_nivel) OR (( SELECT tem_nivel(VARIADIC ARRAY['Garçom'::nivel_acesso]) AS tem_nivel) AND (registrado_por = ( SELECT auth.uid() AS uid)))));
create policy vendas_ler on public.vendas as PERMISSIVE for SELECT to authenticated using ((tem_nivel(VARIADIC ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]) OR (tem_nivel(VARIADIC ARRAY['Garçom'::nivel_acesso]) AND (((tipo = 'Mesa'::venda_tipo) AND (mesa_id IN ( SELECT m.id
   FROM mesas m
  WHERE (m.garcom_responsavel_id = auth.uid())))) OR (registrado_por = auth.uid()))) OR (tem_nivel(VARIADIC ARRAY['Cozinha'::nivel_acesso]) AND (status = 'Confirmada'::venda_status) AND (status_pedido = ANY (ARRAY['Recebido'::status_pedido, 'Em preparo'::status_pedido, 'Pronta'::status_pedido, 'Suspenso'::status_pedido]))) OR (tem_nivel(VARIADIC ARRAY['Cozinha'::nivel_acesso]) AND (status = 'Confirmada'::venda_status) AND (status_pedido = ANY (ARRAY['Retirada'::status_pedido, 'Entregue'::status_pedido, 'Servida'::status_pedido])) AND (caixa_id = ( SELECT _caixa_aberto_id() AS _caixa_aberto_id))) OR (tem_nivel(VARIADIC ARRAY['Entregador'::nivel_acesso]) AND (tipo = 'Entrega'::venda_tipo) AND (entregador_id = auth.uid()))));

-- ---------------------------------------------------------------------
-- 13. PERMISSÕES DAS TABELAS E VIEWS
-- ---------------------------------------------------------------------
revoke all on table public.adicionais from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.adicionais to authenticated;
revoke all on table public.ai_ajuda from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.ai_ajuda to authenticated;
revoke all on table public.ai_ajuda_bkp_20261007 from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.ai_ajuda_bkp_20261007 to authenticated;
revoke all on table public.ai_cache from anon, authenticated;
revoke all on table public.ai_config from anon, authenticated; grant REFERENCES, SELECT, TRIGGER, UPDATE on table public.ai_config to authenticated;
revoke all on table public.ai_log from anon, authenticated; grant REFERENCES, SELECT, TRIGGER on table public.ai_log to authenticated;
revoke all on table public.ai_segredos from anon, authenticated;
revoke all on table public.ai_uso from anon, authenticated; grant REFERENCES, SELECT, TRIGGER on table public.ai_uso to authenticated;
revoke all on table public.ajustes_pos_venda from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.ajustes_pos_venda to authenticated;
revoke all on table public.arquivo_historico from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.arquivo_historico to authenticated;
revoke all on table public.auditoria from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.auditoria to authenticated;
revoke all on table public.backup_config from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.backup_config to authenticated;
revoke all on table public.backups from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.backups to authenticated;
revoke all on table public.brindes from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.brindes to authenticated;
revoke all on table public.caixa_sessoes from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.caixa_sessoes to authenticated;
revoke all on table public.categorias from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.categorias to authenticated;
revoke all on table public.chat_config from anon, authenticated; grant SELECT on table public.chat_config to authenticated;
revoke all on table public.chat_conversas from anon, authenticated; grant SELECT on table public.chat_conversas to authenticated;
revoke all on table public.chat_ia_cotas from anon, authenticated;
revoke all on table public.chat_mensagens from anon, authenticated; grant SELECT on table public.chat_mensagens to authenticated;
revoke all on table public.chat_tokens from anon, authenticated;
revoke all on table public.clientes from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.clientes to authenticated;
revoke all on table public.codigo_analises from anon, authenticated;
revoke all on table public.codigo_snapshots from anon, authenticated;
revoke all on table public.codigo_versoes from anon, authenticated;
revoke all on table public.combo_itens from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.combo_itens to authenticated;
revoke all on table public.combo_precos from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.combo_precos to authenticated;
revoke all on table public.combos from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.combos to authenticated;
revoke all on table public.configuracoes_fotos from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.configuracoes_fotos to authenticated;
revoke all on table public.contingencia_config from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.contingencia_config to authenticated;
revoke all on table public.contingencia_reconciliada from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.contingencia_reconciliada to authenticated;
revoke all on table public.cupons from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.cupons to authenticated;
revoke all on table public.cupons_usos from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.cupons_usos to authenticated;
revoke all on table public.despesas from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.despesas to authenticated;
revoke all on table public.despesas_recorrentes from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.despesas_recorrentes to authenticated;
revoke all on table public.entrega_destinos from anon, authenticated;
revoke all on table public.entregador_posicoes from anon, authenticated; grant SELECT on table public.entregador_posicoes to authenticated;
revoke all on table public.entregas_fechadas from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.entregas_fechadas to authenticated;
revoke all on table public.erros_cliente from anon, authenticated; grant SELECT on table public.erros_cliente to authenticated;
revoke all on table public.estoque from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.estoque to authenticated;
revoke all on table public.eventos from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.eventos to authenticated;
revoke all on table public.eventos_custos from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.eventos_custos to authenticated;
revoke all on table public.eventos_recebimentos from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.eventos_recebimentos to authenticated;
revoke all on table public.faq_publico from anon, authenticated; grant SELECT on table public.faq_publico to anon; grant DELETE, INSERT, SELECT, UPDATE on table public.faq_publico to authenticated;
revoke all on table public.fechamentos_entrega from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.fechamentos_entrega to authenticated;
revoke all on table public.feedbacks from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.feedbacks to authenticated;
revoke all on table public.fidelidade from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.fidelidade to authenticated;
revoke all on table public.fila_sync from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.fila_sync to authenticated;
revoke all on table public.formas_pagamento from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.formas_pagamento to authenticated;
revoke all on table public.fotos_historico from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.fotos_historico to authenticated;
revoke all on table public.ia_relatorio_codigo from anon, authenticated; grant SELECT on table public.ia_relatorio_codigo to authenticated;
revoke all on table public.indicacoes from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.indicacoes to authenticated;
revoke all on table public.integridade_checks from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.integridade_checks to authenticated;
revoke all on table public.itens_venda from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.itens_venda to authenticated;
revoke all on table public.mesas from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.mesas to authenticated;
revoke all on table public.mesas_codigos from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.mesas_codigos to authenticated;
revoke all on table public.movimentacoes_estoque from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.movimentacoes_estoque to authenticated;
revoke all on table public.ocorrencias from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.ocorrencias to authenticated;
revoke all on table public.pagamentos_venda from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.pagamentos_venda to authenticated;
revoke all on table public.pedido_destinos from anon, authenticated; grant SELECT on table public.pedido_destinos to authenticated;
revoke all on table public.produto_adicionais from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.produto_adicionais to authenticated;
revoke all on table public.produto_ingredientes from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.produto_ingredientes to authenticated;
revoke all on table public.produto_precos from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.produto_precos to authenticated;
revoke all on table public.produtos from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.produtos to authenticated;
revoke all on table public.promocoes from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.promocoes to authenticated;
revoke all on table public.requisicoes from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.requisicoes to authenticated;
revoke all on table public.sangrias from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.sangrias to authenticated;
revoke all on table public.sistema from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.sistema to authenticated;
revoke all on table public.sync_estado from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.sync_estado to authenticated;
revoke all on table public.tentativas from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.tentativas to authenticated;
revoke all on table public.usuarios from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.usuarios to authenticated;
revoke all on table public.v_cardapio_adicionais from anon, authenticated; grant SELECT on table public.v_cardapio_adicionais to anon; grant SELECT on table public.v_cardapio_adicionais to authenticated;
revoke all on table public.v_cardapio_categorias from anon, authenticated; grant SELECT on table public.v_cardapio_categorias to anon; grant SELECT on table public.v_cardapio_categorias to authenticated;
revoke all on table public.v_cardapio_combo_itens from anon, authenticated; grant SELECT on table public.v_cardapio_combo_itens to anon; grant SELECT on table public.v_cardapio_combo_itens to authenticated;
revoke all on table public.v_cardapio_combos from anon, authenticated; grant SELECT on table public.v_cardapio_combos to anon; grant SELECT on table public.v_cardapio_combos to authenticated;
revoke all on table public.v_cardapio_config from anon, authenticated; grant SELECT on table public.v_cardapio_config to anon; grant SELECT on table public.v_cardapio_config to authenticated;
revoke all on table public.v_cardapio_esgotados from anon, authenticated; grant SELECT on table public.v_cardapio_esgotados to anon; grant SELECT on table public.v_cardapio_esgotados to authenticated;
revoke all on table public.v_cardapio_formas from anon, authenticated; grant SELECT on table public.v_cardapio_formas to anon; grant SELECT on table public.v_cardapio_formas to authenticated;
revoke all on table public.v_cardapio_mais_pedidos from anon, authenticated; grant SELECT on table public.v_cardapio_mais_pedidos to anon; grant SELECT on table public.v_cardapio_mais_pedidos to authenticated;
revoke all on table public.v_cardapio_precos from anon, authenticated; grant SELECT on table public.v_cardapio_precos to anon; grant SELECT on table public.v_cardapio_precos to authenticated;
revoke all on table public.v_cardapio_produtos from anon, authenticated; grant SELECT on table public.v_cardapio_produtos to anon; grant SELECT on table public.v_cardapio_produtos to authenticated;
revoke all on table public.v_cardapio_status from anon, authenticated; grant SELECT on table public.v_cardapio_status to anon; grant SELECT on table public.v_cardapio_status to authenticated;
revoke all on table public.v_fidelidade from anon, authenticated; grant SELECT on table public.v_fidelidade to authenticated;
revoke all on table public.v_formas_operacional from anon, authenticated; grant SELECT on table public.v_formas_operacional to authenticated;
revoke all on table public.v_indicacoes from anon, authenticated; grant SELECT on table public.v_indicacoes to authenticated;
revoke all on table public.v_itens_venda from anon, authenticated; grant SELECT on table public.v_itens_venda to authenticated;
revoke all on table public.v_mesas from anon, authenticated; grant SELECT on table public.v_mesas to authenticated;
revoke all on table public.v_ocorrencias from anon, authenticated; grant SELECT on table public.v_ocorrencias to authenticated;
revoke all on table public.v_sessao_aberta from anon, authenticated; grant SELECT on table public.v_sessao_aberta to authenticated;
revoke all on table public.v_vendas from anon, authenticated; grant SELECT on table public.v_vendas to authenticated;
revoke all on table public.vendas from anon, authenticated; grant DELETE, INSERT, REFERENCES, SELECT, TRIGGER, TRUNCATE, UPDATE on table public.vendas to authenticated;
revoke all on table public.versoes_sync from anon, authenticated;

-- ---------------------------------------------------------------------
-- 14. PERMISSÕES POR COLUNA
-- ---------------------------------------------------------------------
grant UPDATE (atualizado_em) on table public.chat_config to authenticated;
grant UPDATE (chat_publico_ligado) on table public.chat_config to authenticated;
grant UPDATE (ia_publica_cota_dia) on table public.chat_config to authenticated;
grant UPDATE (janela_horas) on table public.chat_config to authenticated;

-- ---------------------------------------------------------------------
-- 15. PERMISSÕES DAS FUNÇÕES (quem pode chamar)
-- ---------------------------------------------------------------------
revoke all on function public._agora_br() from public, anon, authenticated;
revoke all on function public._ajustar_estoque(p_itens jsonb, p_dir integer, p_venda uuid) from public, anon, authenticated;
revoke all on function public._auditar(p_acao text, p_detalhes text, p_telefone text) from public, anon, authenticated;
revoke all on function public._auditar_publico(p_acao text, p_detalhes text, p_tel text) from public, anon, authenticated;
revoke all on function public._bump_versao_sync() from public, anon, authenticated;
revoke all on function public._caixa_aberto_id() from public, anon, authenticated; grant execute on function public._caixa_aberto_id() to authenticated;
revoke all on function public._calc_fechamento_entrega(p_login text, p_data date, OUT qtd integer, OUT total_taxas numeric, OUT ajuda numeric, OUT total numeric, OUT ids uuid[]) from public, anon, authenticated;
revoke all on function public._carimbar_fidelidade(p_tel text, p_nome text) from public, anon, authenticated;
revoke all on function public._categoria_despesa(v text, padrao text) from public, anon, authenticated;
revoke all on function public._cfg_gravar(p_chave text, p_valor jsonb) from public, anon, authenticated;
revoke all on function public._chat_caixa_aberto() from public, anon, authenticated;
revoke all on function public._chat_hash(t text) from public, anon, authenticated;
revoke all on function public._chat_ligado() from public, anon, authenticated;
revoke all on function public._chat_limpar(t text) from public, anon, authenticated;
revoke all on function public._chat_normalizar_intencao() from public, anon, authenticated;
revoke all on function public._chat_validar(p_id uuid, p_token text) from public, anon, authenticated;
revoke all on function public._combo_gravar_itens(p_combo uuid, p_itens jsonb) from public, anon, authenticated;
revoke all on function public._combo_gravar_precos(p_combo uuid, p_precos jsonb) from public, anon, authenticated;
revoke all on function public._comp_valida(v text) from public, anon, authenticated;
revoke all on function public._competencia_atual() from public, anon, authenticated;
revoke all on function public._conflito(p_msg text) from public, anon, authenticated;
revoke all on function public._consumo(p_itens jsonb) from public, anon, authenticated;
revoke all on function public._criar_login_auth(p_id uuid, p_email text, p_senha text) from public, anon, authenticated;
revoke all on function public._criar_pedido_publico(p jsonb, p_mesa_id uuid) from public, anon, authenticated;
revoke all on function public._cupom_calcular(p_codigo text, p_tel text, p_subtotal numeric, p_tipo text) from public, anon, authenticated;
revoke all on function public._cupom_validar(p jsonb, p_id uuid, OUT erro text, OUT c cupons) from public, anon, authenticated;
revoke all on function public._data_iso(v text) from public, anon, authenticated;
revoke all on function public._dinheiro(v numeric) from public, anon, authenticated;
revoke all on function public._dist_km(a_lat double precision, a_lng double precision, b_lat double precision, b_lng double precision) from public, anon, authenticated;
revoke all on function public._email_login(p_login text) from public, anon, authenticated;
revoke all on function public._entrega_limpar_loc() from public, anon, authenticated;
revoke all on function public._erro_recorrente(p_desc text, p_valor numeric, p_dia numeric, p_period text, p_inicio text, p_termino text) from public, anon, authenticated;
revoke all on function public._erro_senha_fraca(p_senha text, p_login text) from public, anon, authenticated;
revoke all on function public._estoque_proprio(p_atual uuid, p_nome text, p_ep jsonb) from public, anon, authenticated;
revoke all on function public._evento_json(p_id uuid) from public, anon, authenticated;
revoke all on function public._excedeu(p_chave text, p_max integer) from public, anon, authenticated;
revoke all on function public._exige_admin(p_senha text) from public, anon, authenticated;
revoke all on function public._falha(p_msg text) from public, anon, authenticated;
revoke all on function public._gerar_despesas_recorrentes(p_comp text) from public, anon, authenticated;
revoke all on function public._hora_valida(v text) from public, anon, authenticated;
revoke all on function public._ia_mascara(j jsonb, p_adm boolean) from public, anon, authenticated; grant execute on function public._ia_mascara(j jsonb, p_adm boolean) to authenticated;
revoke all on function public._ia_oculta(p_coluna text, p_adm boolean) from public, anon, authenticated; grant execute on function public._ia_oculta(p_coluna text, p_adm boolean) to authenticated;
revoke all on function public._ia_scrub(t text) from public, anon, authenticated; grant execute on function public._ia_scrub(t text) to anon; grant execute on function public._ia_scrub(t text) to authenticated;
revoke all on function public._ia_tabelas(p_adm boolean) from public, anon, authenticated; grant execute on function public._ia_tabelas(p_adm boolean) to authenticated;
revoke all on function public._idem_gravar(p_chave text, p_acao text, p_resultado jsonb) from public, anon, authenticated;
revoke all on function public._idem_ler(p_chave text) from public, anon, authenticated;
revoke all on function public._ip_cliente() from public, anon, authenticated;
revoke all on function public._itens_da_venda(p_venda uuid) from public, anon, authenticated;
revoke all on function public._lancar_pagamento_entregador(p_fid uuid, p_entregador uuid, p_dia date, p_taxas numeric, p_pago numeric, p_forma text, p_caixa_aberto boolean) from public, anon, authenticated;
revoke all on function public._limpar_falhas(p_chave text) from public, anon, authenticated;
revoke all on function public._lista_curta(p_itens text[]) from public, anon, authenticated;
revoke all on function public._lista_qr_mesas() from public, anon, authenticated;
revoke all on function public._login_de(p_id uuid) from public, anon, authenticated; grant execute on function public._login_de(p_id uuid) to authenticated;
revoke all on function public._meio_dia(d date) from public, anon, authenticated;
revoke all on function public._mesa_numero_de(p_id uuid) from public, anon, authenticated; grant execute on function public._mesa_numero_de(p_id uuid) to authenticated;
revoke all on function public._mesa_qr(p_numero text, p_codigo text) from public, anon, authenticated;
revoke all on function public._meses_periodicidade(p text) from public, anon, authenticated;
revoke all on function public._negado() from public, anon, authenticated;
revoke all on function public._num(v text, padrao numeric) from public, anon, authenticated;
revoke all on function public._pedido_trava(p jsonb, OUT v vendas, OUT erro jsonb) from public, anon, authenticated;
revoke all on function public._precos_ou_base(p jsonb) from public, anon, authenticated;
revoke all on function public._produto_gravar_adicionais(p_prod uuid, p_ads jsonb) from public, anon, authenticated;
revoke all on function public._produto_gravar_precos(p_prod uuid, p_precos jsonb) from public, anon, authenticated;
revoke all on function public._produto_gravar_receita(p_prod uuid, p_ingr jsonb, p_proprio uuid) from public, anon, authenticated;
revoke all on function public._proteger_desenvolvedor_usuarios() from public, anon, authenticated; grant execute on function public._proteger_desenvolvedor_usuarios() to anon; grant execute on function public._proteger_desenvolvedor_usuarios() to authenticated;
revoke all on function public._recalcular_evento(p_id uuid) from public, anon, authenticated;
revoke all on function public._registrar_falha(p_chave text, p_seg integer) from public, anon, authenticated;
revoke all on function public._saldo_gaveta_aberta() from public, anon, authenticated;
revoke all on function public._senha_confere(p_user uuid, p_senha text) from public, anon, authenticated;
revoke all on function public._so_digitos(t text) from public, anon, authenticated; grant execute on function public._so_digitos(t text) to authenticated;
revoke all on function public._texto_publico(t text, mx integer) from public, anon, authenticated;
revoke all on function public._travar_unico_desenvolvedor() from public, anon, authenticated; grant execute on function public._travar_unico_desenvolvedor() to anon; grant execute on function public._travar_unico_desenvolvedor() to authenticated;
revoke all on function public._upsert_cliente(p_tel text, p_nome text) from public, anon, authenticated;
revoke all on function public._uuid(v text) from public, anon, authenticated;
revoke all on function public._validar_adicionais_item_venda() from public, anon, authenticated; grant execute on function public._validar_adicionais_item_venda() to anon; grant execute on function public._validar_adicionais_item_venda() to authenticated;
revoke all on function public._validar_forma(pct numeric, fixa numeric, prazo numeric) from public, anon, authenticated;
revoke all on function public._versao_conflita(p jsonb, p_tab text, p_id uuid) from public, anon, authenticated;
revoke all on function public._versoes_tabela(p_tab text, p_id uuid) from public, anon, authenticated;
revoke all on function public.api_abrir_caixa(p jsonb) from public, anon, authenticated; grant execute on function public.api_abrir_caixa(p jsonb) to authenticated;
revoke all on function public.api_aceitar_pedido(p jsonb) from public, anon, authenticated; grant execute on function public.api_aceitar_pedido(p jsonb) to authenticated;
revoke all on function public.api_add_adicional(p jsonb) from public, anon, authenticated; grant execute on function public.api_add_adicional(p jsonb) to authenticated;
revoke all on function public.api_add_categoria(p jsonb) from public, anon, authenticated; grant execute on function public.api_add_categoria(p jsonb) to authenticated;
revoke all on function public.api_add_combo(p jsonb) from public, anon, authenticated; grant execute on function public.api_add_combo(p jsonb) to authenticated;
revoke all on function public.api_add_despesa(p jsonb) from public, anon, authenticated; grant execute on function public.api_add_despesa(p jsonb) to authenticated;
revoke all on function public.api_add_despesa_recorrente(p jsonb) from public, anon, authenticated; grant execute on function public.api_add_despesa_recorrente(p jsonb) to authenticated;
revoke all on function public.api_add_feedback(p jsonb) from public, anon, authenticated; grant execute on function public.api_add_feedback(p jsonb) to anon; grant execute on function public.api_add_feedback(p jsonb) to authenticated;
revoke all on function public.api_add_forma_pagamento(p jsonb) from public, anon, authenticated; grant execute on function public.api_add_forma_pagamento(p jsonb) to authenticated;
revoke all on function public.api_add_ingrediente(p jsonb) from public, anon, authenticated; grant execute on function public.api_add_ingrediente(p jsonb) to authenticated;
revoke all on function public.api_add_mesa(p jsonb) from public, anon, authenticated; grant execute on function public.api_add_mesa(p jsonb) to authenticated;
revoke all on function public.api_add_or_stamp_fidelidade(p jsonb) from public, anon, authenticated; grant execute on function public.api_add_or_stamp_fidelidade(p jsonb) to authenticated;
revoke all on function public.api_add_produto(p jsonb) from public, anon, authenticated; grant execute on function public.api_add_produto(p jsonb) to authenticated;
revoke all on function public.api_add_sangria(p jsonb) from public, anon, authenticated; grant execute on function public.api_add_sangria(p jsonb) to authenticated;
revoke all on function public.api_adicionar_custo_evento(p jsonb) from public, anon, authenticated; grant execute on function public.api_adicionar_custo_evento(p jsonb) to authenticated;
revoke all on function public.api_adicionar_recebimento_evento(p jsonb) from public, anon, authenticated; grant execute on function public.api_adicionar_recebimento_evento(p jsonb) to authenticated;
revoke all on function public.api_alternar_cupom(p jsonb) from public, anon, authenticated; grant execute on function public.api_alternar_cupom(p jsonb) to authenticated;
revoke all on function public.api_aplicar_preco_calculadora(p jsonb) from public, anon, authenticated; grant execute on function public.api_aplicar_preco_calculadora(p jsonb) to authenticated;
revoke all on function public.api_arquivar_confirmar_caixa(p_ids uuid[]) from public, anon, authenticated;
revoke all on function public.api_arquivar_confirmar_vendas(p_ids uuid[]) from public, anon, authenticated;
revoke all on function public.api_arquivar_lote_caixa(p_dias integer, p_limite integer, p_min_dias integer) from public, anon, authenticated;
revoke all on function public.api_arquivar_lote_vendas(p_dias integer, p_limite integer, p_min_dias integer) from public, anon, authenticated;
revoke all on function public.api_atender_chamado_mesa(p jsonb) from public, anon, authenticated; grant execute on function public.api_atender_chamado_mesa(p jsonb) to authenticated;
revoke all on function public.api_atribuir_entregador(p jsonb) from public, anon, authenticated; grant execute on function public.api_atribuir_entregador(p jsonb) to authenticated;
revoke all on function public.api_atualizar_ocorrencia(p jsonb) from public, anon, authenticated; grant execute on function public.api_atualizar_ocorrencia(p jsonb) to authenticated;
revoke all on function public.api_avancar_status_pedido(p jsonb) from public, anon, authenticated; grant execute on function public.api_avancar_status_pedido(p jsonb) to authenticated;
revoke all on function public.api_cancelar_ajuste_pos_venda(p jsonb) from public, anon, authenticated; grant execute on function public.api_cancelar_ajuste_pos_venda(p jsonb) to authenticated;
revoke all on function public.api_cancelar_brinde(p jsonb) from public, anon, authenticated; grant execute on function public.api_cancelar_brinde(p jsonb) to authenticated;
revoke all on function public.api_cancelar_despesa(p jsonb) from public, anon, authenticated; grant execute on function public.api_cancelar_despesa(p jsonb) to authenticated;
revoke all on function public.api_cancelar_evento(p jsonb) from public, anon, authenticated; grant execute on function public.api_cancelar_evento(p jsonb) to authenticated;
revoke all on function public.api_cancelar_pedido_cardapio_publico(p jsonb) from public, anon, authenticated; grant execute on function public.api_cancelar_pedido_cardapio_publico(p jsonb) to anon; grant execute on function public.api_cancelar_pedido_cardapio_publico(p jsonb) to authenticated;
revoke all on function public.api_cancelar_pedido_mesa(p jsonb) from public, anon, authenticated; grant execute on function public.api_cancelar_pedido_mesa(p jsonb) to anon; grant execute on function public.api_cancelar_pedido_mesa(p jsonb) to authenticated;
revoke all on function public.api_cancelar_venda(p jsonb) from public, anon, authenticated; grant execute on function public.api_cancelar_venda(p jsonb) to authenticated;
revoke all on function public.api_chamar_garcom_mesa(p jsonb) from public, anon, authenticated; grant execute on function public.api_chamar_garcom_mesa(p jsonb) to anon; grant execute on function public.api_chamar_garcom_mesa(p jsonb) to authenticated;
revoke all on function public.api_compartilhar_destino_pedido(p jsonb) from public, anon, authenticated; grant execute on function public.api_compartilhar_destino_pedido(p jsonb) to anon; grant execute on function public.api_compartilhar_destino_pedido(p jsonb) to authenticated;
revoke all on function public.api_confirmar_recebimento_pedido(p jsonb) from public, anon, authenticated; grant execute on function public.api_confirmar_recebimento_pedido(p jsonb) to authenticated;
revoke all on function public.api_criar_pedido_cardapio(p jsonb) from public, anon, authenticated; grant execute on function public.api_criar_pedido_cardapio(p jsonb) to anon; grant execute on function public.api_criar_pedido_cardapio(p jsonb) to authenticated;
revoke all on function public.api_criar_pedido_mesa(p jsonb) from public, anon, authenticated; grant execute on function public.api_criar_pedido_mesa(p jsonb) to anon; grant execute on function public.api_criar_pedido_mesa(p jsonb) to authenticated;
revoke all on function public.api_criar_usuario(p jsonb) from public, anon, authenticated; grant execute on function public.api_criar_usuario(p jsonb) to authenticated;
revoke all on function public.api_detectar_novos_pedidos(p jsonb) from public, anon, authenticated; grant execute on function public.api_detectar_novos_pedidos(p jsonb) to authenticated;
revoke all on function public.api_distancia_entrega_publico(p jsonb) from public, anon, authenticated; grant execute on function public.api_distancia_entrega_publico(p jsonb) to anon; grant execute on function public.api_distancia_entrega_publico(p jsonb) to authenticated;
revoke all on function public.api_editar_adicional(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_adicional(p jsonb) to authenticated;
revoke all on function public.api_editar_categoria(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_categoria(p jsonb) to authenticated;
revoke all on function public.api_editar_combo(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_combo(p jsonb) to authenticated;
revoke all on function public.api_editar_cupom(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_cupom(p jsonb) to authenticated;
revoke all on function public.api_editar_despesa(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_despesa(p jsonb) to authenticated;
revoke all on function public.api_editar_despesa_recorrente(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_despesa_recorrente(p jsonb) to authenticated;
revoke all on function public.api_editar_forma_pagamento(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_forma_pagamento(p jsonb) to authenticated;
revoke all on function public.api_editar_ingrediente(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_ingrediente(p jsonb) to authenticated;
revoke all on function public.api_editar_ordem_cardapio_combo(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_ordem_cardapio_combo(p jsonb) to authenticated;
revoke all on function public.api_editar_ordem_cardapio_produto(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_ordem_cardapio_produto(p jsonb) to authenticated;
revoke all on function public.api_editar_premio_produto(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_premio_produto(p jsonb) to anon; grant execute on function public.api_editar_premio_produto(p jsonb) to authenticated;
revoke all on function public.api_editar_produto(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_produto(p jsonb) to authenticated;
revoke all on function public.api_editar_status_feedback(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_status_feedback(p jsonb) to authenticated;
revoke all on function public.api_editar_status_mesa(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_status_mesa(p jsonb) to authenticated;
revoke all on function public.api_editar_usuario(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_usuario(p jsonb) to authenticated;
revoke all on function public.api_editar_venda(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_venda(p jsonb) to authenticated;
revoke all on function public.api_editar_visibilidade_cardapio_combo(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_visibilidade_cardapio_combo(p jsonb) to authenticated;
revoke all on function public.api_editar_visibilidade_cardapio_produto(p jsonb) from public, anon, authenticated; grant execute on function public.api_editar_visibilidade_cardapio_produto(p jsonb) to authenticated;
revoke all on function public.api_encerrar_sessao_remota(p jsonb) from public, anon, authenticated; grant execute on function public.api_encerrar_sessao_remota(p jsonb) to authenticated;
revoke all on function public.api_espaco_percentual_servico() from public, anon, authenticated;
revoke all on function public.api_espaco_uso() from public, anon, authenticated; grant execute on function public.api_espaco_uso() to authenticated;
revoke all on function public.api_excluir_adicional(p jsonb) from public, anon, authenticated; grant execute on function public.api_excluir_adicional(p jsonb) to authenticated;
revoke all on function public.api_excluir_categoria(p jsonb) from public, anon, authenticated; grant execute on function public.api_excluir_categoria(p jsonb) to authenticated;
revoke all on function public.api_excluir_cliente(p jsonb) from public, anon, authenticated; grant execute on function public.api_excluir_cliente(p jsonb) to authenticated;
revoke all on function public.api_excluir_combo(p jsonb) from public, anon, authenticated; grant execute on function public.api_excluir_combo(p jsonb) to authenticated;
revoke all on function public.api_excluir_ingrediente(p jsonb) from public, anon, authenticated; grant execute on function public.api_excluir_ingrediente(p jsonb) to authenticated;
revoke all on function public.api_excluir_mesa(p jsonb) from public, anon, authenticated; grant execute on function public.api_excluir_mesa(p jsonb) to authenticated;
revoke all on function public.api_excluir_produto(p jsonb) from public, anon, authenticated; grant execute on function public.api_excluir_produto(p jsonb) to authenticated;
revoke all on function public.api_excluir_usuario(p jsonb) from public, anon, authenticated; grant execute on function public.api_excluir_usuario(p jsonb) to authenticated;
revoke all on function public.api_fechar_caixa(p jsonb) from public, anon, authenticated; grant execute on function public.api_fechar_caixa(p jsonb) to authenticated;
revoke all on function public.api_fechar_conta_mesa(p jsonb) from public, anon, authenticated; grant execute on function public.api_fechar_conta_mesa(p jsonb) to authenticated;
revoke all on function public.api_fechar_periodo_entregador(p jsonb) from public, anon, authenticated; grant execute on function public.api_fechar_periodo_entregador(p jsonb) to authenticated;
revoke all on function public.api_garantir_despesas_do_mes(p jsonb) from public, anon, authenticated; grant execute on function public.api_garantir_despesas_do_mes(p jsonb) to authenticated;
revoke all on function public.api_gerar_despesas_mes(p jsonb) from public, anon, authenticated; grant execute on function public.api_gerar_despesas_mes(p jsonb) to authenticated;
revoke all on function public.api_gerar_novo_codigo_mesa(p jsonb) from public, anon, authenticated; grant execute on function public.api_gerar_novo_codigo_mesa(p jsonb) to authenticated;
revoke all on function public.api_get_mesa_publica(p jsonb) from public, anon, authenticated; grant execute on function public.api_get_mesa_publica(p jsonb) to anon; grant execute on function public.api_get_mesa_publica(p jsonb) to authenticated;
revoke all on function public.api_get_qr_mesas(p jsonb) from public, anon, authenticated; grant execute on function public.api_get_qr_mesas(p jsonb) to authenticated;
revoke all on function public.api_get_status_pedido_publico(p jsonb) from public, anon, authenticated; grant execute on function public.api_get_status_pedido_publico(p jsonb) to anon; grant execute on function public.api_get_status_pedido_publico(p jsonb) to authenticated;
revoke all on function public.api_indicar_novo_cliente(p jsonb) from public, anon, authenticated; grant execute on function public.api_indicar_novo_cliente(p jsonb) to authenticated;
revoke all on function public.api_iniciar_preparo_pedido(p jsonb) from public, anon, authenticated; grant execute on function public.api_iniciar_preparo_pedido(p jsonb) to authenticated;
revoke all on function public.api_iniciar_venda(p jsonb) from public, anon, authenticated; grant execute on function public.api_iniciar_venda(p jsonb) to authenticated;
revoke all on function public.api_ler_tabelas(p jsonb) from public, anon, authenticated; grant execute on function public.api_ler_tabelas(p jsonb) to authenticated;
revoke all on function public.api_listar_sessoes(p jsonb) from public, anon, authenticated; grant execute on function public.api_listar_sessoes(p jsonb) to authenticated;
revoke all on function public.api_pagar_despesa(p jsonb) from public, anon, authenticated; grant execute on function public.api_pagar_despesa(p jsonb) to authenticated;
revoke all on function public.api_pedir_conta_mesa(p jsonb) from public, anon, authenticated; grant execute on function public.api_pedir_conta_mesa(p jsonb) to anon; grant execute on function public.api_pedir_conta_mesa(p jsonb) to authenticated;
revoke all on function public.api_preview_fechamento_entrega(p jsonb) from public, anon, authenticated; grant execute on function public.api_preview_fechamento_entrega(p jsonb) to authenticated;
revoke all on function public.api_reconciliar_venda_contingencia(p jsonb) from public, anon, authenticated; grant execute on function public.api_reconciliar_venda_contingencia(p jsonb) to authenticated;
revoke all on function public.api_registrar_ajuste_pos_venda(p jsonb) from public, anon, authenticated; grant execute on function public.api_registrar_ajuste_pos_venda(p jsonb) to authenticated;
revoke all on function public.api_registrar_brinde(p jsonb) from public, anon, authenticated; grant execute on function public.api_registrar_brinde(p jsonb) to authenticated;
revoke all on function public.api_registrar_entrada_estoque(p jsonb) from public, anon, authenticated; grant execute on function public.api_registrar_entrada_estoque(p jsonb) to authenticated;
revoke all on function public.api_registrar_inventario_estoque(p jsonb) from public, anon, authenticated; grant execute on function public.api_registrar_inventario_estoque(p jsonb) to authenticated;
revoke all on function public.api_registrar_ocorrencia(p jsonb) from public, anon, authenticated; grant execute on function public.api_registrar_ocorrencia(p jsonb) to authenticated;
revoke all on function public.api_registrar_perda_estoque(p jsonb) from public, anon, authenticated; grant execute on function public.api_registrar_perda_estoque(p jsonb) to authenticated;
revoke all on function public.api_rejeitar_pedido(p jsonb) from public, anon, authenticated; grant execute on function public.api_rejeitar_pedido(p jsonb) to authenticated;
revoke all on function public.api_resgatar_premio_fidelidade(p jsonb) from public, anon, authenticated; grant execute on function public.api_resgatar_premio_fidelidade(p jsonb) to authenticated;
revoke all on function public.api_retomar_pedido(p jsonb) from public, anon, authenticated; grant execute on function public.api_retomar_pedido(p jsonb) to authenticated;
revoke all on function public.api_salvar_cliente(p jsonb) from public, anon, authenticated; grant execute on function public.api_salvar_cliente(p jsonb) to authenticated;
revoke all on function public.api_salvar_config_cardapio(p jsonb) from public, anon, authenticated; grant execute on function public.api_salvar_config_cardapio(p jsonb) to authenticated;
revoke all on function public.api_salvar_config_entrega(p jsonb) from public, anon, authenticated; grant execute on function public.api_salvar_config_entrega(p jsonb) to authenticated;
revoke all on function public.api_salvar_config_estoque(p jsonb) from public, anon, authenticated; grant execute on function public.api_salvar_config_estoque(p jsonb) to authenticated;
revoke all on function public.api_salvar_config_notificacoes(p jsonb) from public, anon, authenticated; grant execute on function public.api_salvar_config_notificacoes(p jsonb) to authenticated;
revoke all on function public.api_salvar_cupom(p jsonb) from public, anon, authenticated; grant execute on function public.api_salvar_cupom(p jsonb) to authenticated;
revoke all on function public.api_salvar_evento(p jsonb) from public, anon, authenticated; grant execute on function public.api_salvar_evento(p jsonb) to authenticated;
revoke all on function public.api_salvar_meta(p jsonb) from public, anon, authenticated; grant execute on function public.api_salvar_meta(p jsonb) to authenticated;
revoke all on function public.api_seed_cardapio_texas_burger(p jsonb) from public, anon, authenticated; grant execute on function public.api_seed_cardapio_texas_burger(p jsonb) to authenticated;
revoke all on function public.api_segredo(p_nome text) from public, anon, authenticated;
revoke all on function public.api_simular_precificacao(p jsonb) from public, anon, authenticated; grant execute on function public.api_simular_precificacao(p jsonb) to authenticated;
revoke all on function public.api_suspender_pedido(p jsonb) from public, anon, authenticated; grant execute on function public.api_suspender_pedido(p jsonb) to authenticated;
revoke all on function public.api_sync_limpar() from public, anon, authenticated;
revoke all on function public.api_sync_lote(p_limite integer) from public, anon, authenticated;
revoke all on function public.api_sync_marcar(p_ids bigint[], p_destino text, p_ok boolean, p_erro text) from public, anon, authenticated;
revoke all on function public.api_sync_status() from public, anon, authenticated; grant execute on function public.api_sync_status() to authenticated;
revoke all on function public.api_sync_verificar_alerta() from public, anon, authenticated;
revoke all on function public.api_toggle_resgate_indicacao(p jsonb) from public, anon, authenticated; grant execute on function public.api_toggle_resgate_indicacao(p jsonb) to authenticated;
revoke all on function public.api_trocar_minha_senha(p jsonb) from public, anon, authenticated; grant execute on function public.api_trocar_minha_senha(p jsonb) to authenticated;
revoke all on function public.api_validar_cupom_cardapio(p jsonb) from public, anon, authenticated; grant execute on function public.api_validar_cupom_cardapio(p jsonb) to anon; grant execute on function public.api_validar_cupom_cardapio(p jsonb) to authenticated;
revoke all on function public.api_verificar_senha_admin(p jsonb) from public, anon, authenticated; grant execute on function public.api_verificar_senha_admin(p jsonb) to authenticated;
revoke all on function public.api_versoes() from public, anon, authenticated; grant execute on function public.api_versoes() to authenticated;
revoke all on function public.api_versoes_registros(p jsonb) from public, anon, authenticated; grant execute on function public.api_versoes_registros(p jsonb) to authenticated;
revoke all on function public.api_vincular_adicionais_em_lote(p jsonb) from public, anon, authenticated; grant execute on function public.api_vincular_adicionais_em_lote(p jsonb) to authenticated;
revoke all on function public.auth_nivel() from public, anon, authenticated; grant execute on function public.auth_nivel() to authenticated;
revoke all on function public.chamar_edge(p_funcao text, p_body jsonb) from public, anon, authenticated;
revoke all on function public.chat_abrir(p jsonb) from public, anon, authenticated; grant execute on function public.chat_abrir(p jsonb) to anon; grant execute on function public.chat_abrir(p jsonb) to authenticated;
revoke all on function public.chat_assumir(p jsonb) from public, anon, authenticated; grant execute on function public.chat_assumir(p jsonb) to authenticated;
revoke all on function public.chat_encerrar(p jsonb) from public, anon, authenticated; grant execute on function public.chat_encerrar(p jsonb) to authenticated;
revoke all on function public.chat_enviar(p jsonb) from public, anon, authenticated; grant execute on function public.chat_enviar(p jsonb) to anon; grant execute on function public.chat_enviar(p jsonb) to authenticated;
revoke all on function public.chat_ia_consumir_cota() from public, anon, authenticated;
revoke all on function public.chat_ia_reservar_chamada(p_conversa_id uuid) from public, anon, authenticated;
revoke all on function public.chat_ia_validar(p_conversa uuid, p_token text, p_ip text) from public, anon, authenticated;
revoke all on function public.chat_ler(p jsonb) from public, anon, authenticated; grant execute on function public.chat_ler(p jsonb) to anon; grant execute on function public.chat_ler(p jsonb) to authenticated;
revoke all on function public.chat_ler_fila() from public, anon, authenticated; grant execute on function public.chat_ler_fila() to authenticated;
revoke all on function public.chat_marcar_lida(p jsonb) from public, anon, authenticated; grant execute on function public.chat_marcar_lida(p jsonb) to authenticated;
revoke all on function public.chat_responder(p jsonb) from public, anon, authenticated; grant execute on function public.chat_responder(p jsonb) to authenticated;
revoke all on function public.chat_status(p jsonb) from public, anon, authenticated; grant execute on function public.chat_status(p jsonb) to anon; grant execute on function public.chat_status(p jsonb) to authenticated;
revoke all on function public.chat_transferir(p jsonb) from public, anon, authenticated; grant execute on function public.chat_transferir(p jsonb) to anon; grant execute on function public.chat_transferir(p jsonb) to authenticated;
revoke all on function public.chat_triagem_abrir(p jsonb) from public, anon, authenticated; grant execute on function public.chat_triagem_abrir(p jsonb) to anon; grant execute on function public.chat_triagem_abrir(p jsonb) to authenticated;
revoke all on function public.chat_vincular_pedido(p jsonb) from public, anon, authenticated; grant execute on function public.chat_vincular_pedido(p jsonb) to anon; grant execute on function public.chat_vincular_pedido(p jsonb) to authenticated;
revoke all on function public.enfileirar_sync() from public, anon, authenticated;
revoke all on function public.entrega_atualizar_posicao(p jsonb) from public, anon, authenticated; grant execute on function public.entrega_atualizar_posicao(p jsonb) to authenticated;
revoke all on function public.entrega_ver_posicao(p jsonb) from public, anon, authenticated; grant execute on function public.entrega_ver_posicao(p jsonb) to authenticated;
revoke all on function public.erro_limpa_(t text, n integer) from public, anon, authenticated; grant execute on function public.erro_limpa_(t text, n integer) to authenticated;
revoke all on function public.ia_agregar(p_tabela text, p_coluna text, p_ini date, p_fim date, p_busca text) from public, anon, authenticated; grant execute on function public.ia_agregar(p_tabela text, p_coluna text, p_ini date, p_fim date, p_busca text) to authenticated;
revoke all on function public.ia_ajuda_buscar(p_pergunta text, p_perfil text) from public, anon, authenticated; grant execute on function public.ia_ajuda_buscar(p_pergunta text, p_perfil text) to authenticated;
revoke all on function public.ia_alerta_(cod text, sev text, titulo text, valor numeric, ref numeric, det jsonb) from public, anon, authenticated; grant execute on function public.ia_alerta_(cod text, sev text, titulo text, valor numeric, ref numeric, det jsonb) to authenticated;
revoke all on function public.ia_anomalias(p_data date) from public, anon, authenticated; grant execute on function public.ia_anomalias(p_data date) to authenticated;
revoke all on function public.ia_catalogo() from public, anon, authenticated; grant execute on function public.ia_catalogo() to authenticated;
revoke all on function public.ia_codigo_catalogo() from public, anon, authenticated; grant execute on function public.ia_codigo_catalogo() to authenticated;
revoke all on function public.ia_codigo_faltantes(p_arquivo text, p_hashes jsonb) from public, anon, authenticated; grant execute on function public.ia_codigo_faltantes(p_arquivo text, p_hashes jsonb) to authenticated;
revoke all on function public.ia_codigo_gravar(p_arquivo text, p_versao text, p_blocos jsonb) from public, anon, authenticated; grant execute on function public.ia_codigo_gravar(p_arquivo text, p_versao text, p_blocos jsonb) to authenticated;
revoke all on function public.ia_codigo_registrar_versao(p_arquivo text, p_versao text, p_blocos jsonb) from public, anon, authenticated; grant execute on function public.ia_codigo_registrar_versao(p_arquivo text, p_versao text, p_blocos jsonb) to authenticated;
revoke all on function public.ia_comparativo(p_ini date, p_fim date) from public, anon, authenticated; grant execute on function public.ia_comparativo(p_ini date, p_fim date) to authenticated;
revoke all on function public.ia_consulta(p_tipo text, p_ini date, p_fim date, p_busca text) from public, anon, authenticated; grant execute on function public.ia_consulta(p_tipo text, p_ini date, p_fim date, p_busca text) to authenticated;
revoke all on function public.ia_contexto_geral() from public, anon, authenticated; grant execute on function public.ia_contexto_geral() to authenticated;
revoke all on function public.ia_cota_tentar(p_user uuid, p_nivel text) from public, anon, authenticated;
revoke all on function public.ia_cron_status_() from public, anon, authenticated; grant execute on function public.ia_cron_status_() to authenticated;
revoke all on function public.ia_diag_banco() from public, anon, authenticated; grant execute on function public.ia_diag_banco() to authenticated;
revoke all on function public.ia_diag_codigo() from public, anon, authenticated; grant execute on function public.ia_diag_codigo() to authenticated;
revoke all on function public.ia_diag_sistema() from public, anon, authenticated; grant execute on function public.ia_diag_sistema() to authenticated;
revoke all on function public.ia_entregas_operacional() from public, anon, authenticated; grant execute on function public.ia_entregas_operacional() to authenticated;
revoke all on function public.ia_estoque_operacional() from public, anon, authenticated; grant execute on function public.ia_estoque_operacional() to authenticated;
revoke all on function public.ia_explorar(p_tabela text, p_ini date, p_fim date, p_busca text, p_limite integer) from public, anon, authenticated; grant execute on function public.ia_explorar(p_tabela text, p_ini date, p_fim date, p_busca text, p_limite integer) to authenticated;
revoke all on function public.ia_limpa_(t text, n integer) from public, anon, authenticated; grant execute on function public.ia_limpa_(t text, n integer) to authenticated;
revoke all on function public.ia_nivel_real() from public, anon, authenticated; grant execute on function public.ia_nivel_real() to authenticated;
revoke all on function public.ia_painel_uso() from public, anon, authenticated; grant execute on function public.ia_painel_uso() to authenticated;
revoke all on function public.ia_periodo_(p_a date, p_b date, p_adm boolean) from public, anon, authenticated;
revoke all on function public.ia_producao_operacional() from public, anon, authenticated; grant execute on function public.ia_producao_operacional() to authenticated;
revoke all on function public.ia_publico_contexto() from public, anon, authenticated;
revoke all on function public.ia_publico_contexto_base() from public, anon, authenticated;
revoke all on function public.ia_publico_limite(p_ip text) from public, anon, authenticated;
revoke all on function public.ia_publico_status_pedido(p_telefone text, p_ip text) from public, anon, authenticated;
revoke all on function public.ia_resumo_periodo(p_ini date, p_fim date) from public, anon, authenticated; grant execute on function public.ia_resumo_periodo(p_ini date, p_fim date) to authenticated;
revoke all on function public.ia_sugestao_compras(p_dias integer, p_cobertura integer) from public, anon, authenticated; grant execute on function public.ia_sugestao_compras(p_dias integer, p_cobertura integer) to authenticated;
revoke all on function public.ia_top_produtos_(p_a date, p_b date, p_adm boolean, p_limite integer, p_ordem text) from public, anon, authenticated;
revoke all on function public.ia_totais_(p_ini date, p_fim date) from public, anon, authenticated; grant execute on function public.ia_totais_(p_ini date, p_fim date) to authenticated;
revoke all on function public.ia_uso_somar(p_user uuid, p_provedor text, p_erro boolean, p_tin integer, p_tout integer) from public, anon, authenticated;
revoke all on function public.registrar_erro_cliente(p jsonb) from public, anon, authenticated; grant execute on function public.registrar_erro_cliente(p jsonb) to authenticated;
revoke all on function public.rls_auto_enable() from public, anon, authenticated;
revoke all on function public.tem_nivel(VARIADIC niveis nivel_acesso[]) from public, anon, authenticated; grant execute on function public.tem_nivel(VARIADIC niveis nivel_acesso[]) to authenticated;
revoke all on function public.tocar_atualizado_em() from public, anon, authenticated;

-- ---------------------------------------------------------------------
-- 16. ROTINAS AUTOMÁTICAS (pg_cron)
-- ---------------------------------------------------------------------
select cron.schedule('ai_limpeza', '15 6 * * *', '
  delete from public.ai_cache where expira_em < now();
  delete from public.ai_log where criado_em < now() - interval ''30 days'';
  delete from public.ai_uso where dia < current_date - 90;
');
select cron.schedule('arquivar-diario', '0 8 * * *', ' select public.chamar_edge(''arquivar-antigos'',''{}''::jsonb); ');
select cron.schedule('arquivar-emergencia-horario', '30 * * * *', ' select public.chamar_edge(''arquivar-antigos'',''{"emergencia":true}''::jsonb); ');
select cron.schedule('backup-horario', '0 * * * *', ' select public.chamar_edge(''criar-backup'',''{"tipo":"Automático","cron":true}''); ');
select cron.schedule('chat-limpeza-diaria', '45 6 * * *', '
  delete from public.entregador_posicoes where atualizado_em < now() - interval ''12 hours'';
  delete from public.pedido_destinos d using public.vendas v
   where v.id = d.venda_id and (v.status_pedido::text in (''Entregue'', ''Retirada'', ''Servida'') or d.criado_em < now() - interval ''2 days'');
  delete from public.chat_conversas where estado = ''recepcao'' and atualizado_em < now() - interval ''2 days'';
');
select cron.schedule('contingencia-espelho-10min', '3,13,23,33,43,53 * * * *', ' select public.chamar_edge(''planilha-admin'', ''{"acao":"sincronizarContingencia","rapido":true}''::jsonb); ');
select cron.schedule('contingencia-espelho-diario', '0 6 * * *', ' select public.chamar_edge(''planilha-admin'', ''{"acao":"sincronizarContingencia"}''::jsonb); ');
select cron.schedule('erros_cliente_limpeza', '30 6 * * *', ' delete from public.erros_cliente where criado_em < now() - interval ''14 days'' ');
select cron.schedule('integridade-semanal', '0 9 * * 0', ' select public.chamar_edge(''conferir-integridade'',''{}''::jsonb); ');
select cron.schedule('ping-2dias', '0 12 */2 * *', ' select public.chamar_edge(''ping'',''{}''::jsonb); ');
select cron.schedule('sync-alerta-30min', '*/30 * * * *', ' select public.api_sync_verificar_alerta(); ');
select cron.schedule('sync-fila-2min', '*/2 * * * *', ' select public.chamar_edge(''sync-fila'',''{}''::jsonb); ');
select cron.schedule('sync-limpar-diario', '0 6 * * *', ' select public.api_sync_limpar(); ');

-- ---------------------------------------------------------------------
-- 17. STORAGE (bucket de backups)
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values ('backups', 'backups', 'f', NULL, NULL) on conflict (id) do nothing;

-- ---------------------------------------------------------------------
-- 18. LINHAS INICIAIS DE CONFIGURAÇÃO (sem dados de negócio)
-- ---------------------------------------------------------------------
insert into public.ai_config select * from jsonb_populate_recordset(null::public.ai_config, '[{"id": true, "recursos": {"ajuda": true, "alertas": true, "compras": true, "pergunte": true, "anomalias": true, "conversar": true, "resumo_dia": true, "suporte_pedido": false}, "ia_ligada": true, "modelo_groq": "qwen/qwen3.8-27b", "atualizado_em": "2026-10-09T01:02:22.14+00:00", "cache_ttl_min": 10, "modelo_gemini": "gemini-3.5-flash", "provedor_reserva": "groq", "limite_por_minuto": 10, "recursos_operador": {"ajuda": true, "conversar": true}, "cota_diaria_global": 400, "provedor_principal": "gemini", "cota_diaria_usuario": 120, "cota_diaria_operador": 80, "limite_por_minuto_operador": 8}]'::jsonb) on conflict do nothing;
insert into public.backup_config select * from jsonb_populate_recordset(null::public.backup_config, '[{"id": true, "arquivar_dias": 90, "atualizado_em": "2026-10-06T02:57:32.342839+00:00", "arquivar_ativo": true, "arquivar_emerg_pct": 95, "auto_retencao_dias": 7, "arquivar_emerg_ativo": true, "arquivar_emerg_ultimo": null}]'::jsonb) on conflict do nothing;
insert into public.chat_config select * from jsonb_populate_recordset(null::public.chat_config, '[{"id": true, "janela_horas": 48, "atualizado_em": "2026-10-08T09:41:03.954366+00:00", "chat_publico_ligado": true, "ia_publica_cota_dia": 200}]'::jsonb) on conflict do nothing;
insert into public.configuracoes_fotos select * from jsonb_populate_recordset(null::public.configuracoes_fotos, '[{"id": true, "onde_guardar": "drive_apenas", "atualizado_em": "2026-10-09T10:10:25.670399+00:00", "drive_preferido": "auto", "replicar_antigas": "ativas", "backup_frio_storage": null, "sincronizacao_drives": "manual", "destino_padrao_upload": "ambos", "historico_fotos_ativo": true}]'::jsonb) on conflict do nothing;
insert into public.contingencia_config select * from jsonb_populate_recordset(null::public.contingencia_config, '[{"id": true, "atualizado_em": "2026-10-06T02:57:32.342839+00:00", "reconciliacao_lote": 50, "timeout_planilha_ms": 12000, "timeout_supabase_ms": 8000, "falhas_para_planilha": 3, "falhas_para_contingencia": 3}]'::jsonb) on conflict do nothing;
