-- =====================================================================
-- TEXAS BURGER — IP na auditoria (item 31) · 2026-10-09
-- O IP vem dos cabeçalhos da requisição (função _ip_cliente já existente). Guardado só na auditoria, visível só ao Admin/Dev,
-- e apagado (campo ip = null) após 90 dias. Registra também "Login" e "Falha de login".
-- Seguro para rodar de novo.
-- =====================================================================
alter table public.auditoria add column if not exists ip text;

create or replace function public._ip_auditoria() returns text language sql stable set search_path to 'public' as $f$
  select case when i like 'sem-ip-%' then null else i end from (select _ip_cliente() i) x
$f$;

create or replace function public._aparelho_auditoria() returns text language plpgsql stable set search_path to 'public' as $f$
declare h jsonb;
begin
  begin h := nullif(current_setting('request.headers', true), '')::jsonb; exception when others then h := null; end;
  return nullif(left(regexp_replace(coalesce(h->>'user-agent', ''), '[\u0000-\u001f]', ' ', 'g'), 120), '');
end $f$;

create or replace function public._auditar(p_acao text, p_detalhes text default null::text, p_telefone text default null::text)
 returns void language sql security definer set search_path to 'public' as $f$
  insert into auditoria (usuario_id, usuario_login, perfil, acao, telefone, detalhes, autorizado_por, ip, aparelho)
  select u.id, u.login, u.nivel::text, p_acao, p_telefone, p_detalhes, nullif(current_setting('app.autorizador', true), ''), _ip_auditoria(), _aparelho_auditoria()
  from usuarios u where u.id = auth.uid()
$f$;

create or replace function public._auditar_publico(p_acao text, p_detalhes text, p_tel text)
 returns void language sql security definer set search_path to 'public' as $f$
  insert into auditoria (usuario_login, perfil, acao, telefone, detalhes, ip) values ('Cardápio (cliente)', 'Cliente', p_acao, p_tel, p_detalhes, _ip_auditoria())
$f$;

create or replace function public.api_registrar_acesso(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $f$
begin
  if auth.uid() is null then return jsonb_build_object('ok', false); end if;
  if exists (select 1 from auditoria where usuario_id = auth.uid() and acao = 'Login' and data_hora > now() - interval '1 minute') then return jsonb_build_object('ok', true); end if;
  perform _auditar('Login', null);
  return jsonb_build_object('ok', true);
end $f$;

create or replace function public.api_registrar_falha_login(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare v_ip text := _ip_auditoria(); v_chave text := 'falhalogin_ip_' || coalesce(v_ip, 'sem-ip'); v_n int; v_login text;
begin
  v_login := left(regexp_replace(lower(btrim(coalesce(p->>'login', ''))), '[^a-z0-9._@ -]', '', 'g'), 40);
  v_n := _registrar_falha(v_chave, 3600);
  if v_n > 30 then return jsonb_build_object('ok', true); end if;
  if (select count(*) from auditoria where acao = 'Falha de login' and data_hora > now() - interval '1 hour') >= 300 then return jsonb_build_object('ok', true); end if;
  insert into auditoria (usuario_login, perfil, acao, detalhes, ip, aparelho) values (coalesce(nullif(v_login, ''), '—'), 'Desconhecido', 'Falha de login', 'Senha ou login incorretos', v_ip, _aparelho_auditoria());
  return jsonb_build_object('ok', true);
end $f$;

create or replace function public.api_listar_auditoria(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare v_dias int := least(greatest(coalesce(nullif(p->>'dias', '')::int, 30), 1), 180); v_b text := lower(btrim(coalesce(p->>'busca', '')));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'itens', coalesce((
    select jsonb_agg(jsonb_build_object('id', a.id, 'data', to_char(a.data_hora at time zone 'America/Sao_Paulo', 'DD/MM/YYYY HH24:MI'), 'usuario', a.usuario_login, 'perfil', a.perfil,
        'acao', a.acao, 'detalhes', coalesce(a.detalhes, ''), 'autorizador', a.autorizado_por, 'aparelho', a.aparelho, 'ip', a.ip) order by a.data_hora desc, a.id desc)
    from (select * from auditoria where data_hora > now() - make_interval(days => v_dias)
            and (v_b = '' or lower(coalesce(usuario_login, '') || ' ' || acao || ' ' || coalesce(detalhes, '') || ' ' || coalesce(ip, '')) like '%' || v_b || '%')
          order by data_hora desc, id desc limit 300) a), '[]'::jsonb));
end $f$;

grant execute on function public.api_registrar_acesso(jsonb), public.api_listar_auditoria(jsonb) to authenticated;
grant execute on function public.api_registrar_falha_login(jsonb) to anon, authenticated;
revoke execute on function public.api_registrar_acesso(jsonb), public.api_listar_auditoria(jsonb) from anon, public;
revoke execute on function public._ip_auditoria(), public._aparelho_auditoria() from public, anon, authenticated;

-- api_listar_sessoes: acrescenta 'ip' (auth.sessions.ip) à linha de cada sessão (trecho: 'ip', coalesce(host(s.ip), '') logo depois de 'ua')
do $do$ declare d text; n text; begin
  d := pg_get_functiondef('public.api_listar_sessoes(jsonb)'::regprocedure);
  if position($x$'ip', coalesce(host(s.ip)$x$ in d) = 0 then
    n := replace(d, $a$'ua', coalesce(s.user_agent, ''),$a$, $a$'ua', coalesce(s.user_agent, ''), 'ip', coalesce(host(s.ip), ''),$a$);
    if n = d then raise exception 'api_listar_sessoes mudou: ajuste manual'; end if;
    execute n;
  end if;
end $do$;

-- apaga só o IP depois de 90 dias (o resto do registro continua)
select cron.schedule('auditoria-ip-limpeza', '50 6 * * *', $c$update public.auditoria set ip = null where ip is not null and data_hora < now() - interval '90 days'$c$);
