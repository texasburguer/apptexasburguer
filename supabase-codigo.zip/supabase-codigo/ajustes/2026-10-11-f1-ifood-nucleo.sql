-- =====================================================================
-- FASE 1 — iFOOD NÚCLEO · 2026-10-11
-- Receber pedidos do iFood como venda normal, ligar itens do iFood aos produtos, baixa de ingredientes,
-- fila de ações para o iFood (confirmar/preparo/pronto/despachar/cancelar), leitor único, saúde.
-- TUDO DESLIGADO: sem a integração ligada nada acontece (nenhuma chamada externa, nenhuma venda nova).
-- Precisa da Fase 0 (2026-10-11-f0-base.sql) aplicada antes. Seguro para rodar de novo.
-- ⚠️ Os nomes dos campos do pedido do iFood vêm de fontes de terceiros: o código é tolerante e a primeira
--    ligação real pode pedir ajuste fino ("ainda não testado com o iFood de verdade").
-- =====================================================================

-- ---------- colunas novas na venda ----------
alter table public.vendas add column if not exists canal text;     -- 'iFood' para pedidos vindos do iFood (origem continua "Balcão")
create index if not exists vendas_canal_idx on public.vendas (canal) where canal is not null;

-- formas de pagamento técnicas (inativas: não aparecem no Caixa nem no cardápio)
insert into public.formas_pagamento (nome, ativa, visivel_cardapio, taxa_percentual, taxa_fixa, prazo_dias, permite_troco, ordem)
select x.nome, false, false, 0, 0, 0, false, 99 from (values ('iFood (pago no app)'), ('iFood (pagar na entrega)')) x(nome)
where not exists (select 1 from public.formas_pagamento f where lower(f.nome) = lower(x.nome));

-- ---------- tabelas ----------
create table if not exists public.ifood_estado (
  id boolean primary key default true check (id),
  ultima_consulta timestamptz, ultima_consulta_ok timestamptz, ultimo_pedido_em timestamptz,
  token_ok boolean, ultimo_erro text, ultimo_erro_em timestamptz,
  trava_dono text, trava_ate timestamptz,
  atualizado_em timestamptz not null default now());
insert into public.ifood_estado (id) values (true) on conflict (id) do nothing;
alter table public.ifood_estado enable row level security;

create table if not exists public.ifood_token (
  id boolean primary key default true check (id),
  token text, expira_em timestamptz);
insert into public.ifood_token (id) values (true) on conflict (id) do nothing;
alter table public.ifood_token enable row level security;

create table if not exists public.ifood_eventos (
  id text primary key,                      -- id do evento no iFood (único: nunca duplica)
  codigo text, codigo_completo text, pedido_ifood text,
  criado_ifood timestamptz, recebido_em timestamptz not null default now(),
  bruto jsonb, processado_em timestamptz, tentativas int not null default 0, erro text);
create index if not exists ifood_eventos_pend_idx on public.ifood_eventos (recebido_em) where processado_em is null;
alter table public.ifood_eventos enable row level security;

create table if not exists public.ifood_pedidos (
  pedido_ifood text primary key,
  venda_id uuid references public.vendas(id) on delete set null,
  numero_ifood text,
  estado text not null default 'novo' check (estado in ('novo','confirmado','em_preparo','pronto','despachado','concluido','cancelado')),
  confirmado_em timestamptz, expira_em timestamptz,
  itens_sem_ligacao int not null default 0,
  avisos int not null default 0,            -- avisos de "confirme o pedido" já enviados à equipe (4 e 6 min)
  simulado boolean not null default false,
  bruto jsonb, criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now());
create index if not exists ifood_pedidos_venda_idx on public.ifood_pedidos (venda_id);
alter table public.ifood_pedidos enable row level security;

create table if not exists public.ifood_itens (
  chave text primary key,                   -- código externo do item/opção no iFood (ou o id, se não houver código)
  nome text not null, tipo text not null default 'produto' check (tipo in ('produto','opcao')),
  produto_id uuid references public.produtos(id) on delete set null,
  combo_id uuid references public.combos(id) on delete set null,
  adicional_id uuid references public.adicionais(id) on delete set null,
  ignorar boolean not null default false,
  visto_em timestamptz not null default now(), ligado_em timestamptz);
alter table public.ifood_itens enable row level security;

create table if not exists public.ifood_acoes (
  id bigserial primary key,
  pedido_ifood text not null, acao text not null check (acao in ('confirmar','iniciar_preparo','pronto','despachar','cancelar')),
  dados jsonb not null default '{}'::jsonb,
  estado text not null default 'pendente' check (estado in ('pendente','ok','erro','duvida','pulada')),
  tentativas int not null default 0, erro text,
  criado_em timestamptz not null default now(), executado_em timestamptz);
create unique index if not exists ifood_acoes_pend_uk on public.ifood_acoes (pedido_ifood, acao) where estado in ('pendente','duvida');
alter table public.ifood_acoes enable row level security;

-- ---------- utilitários ----------
create or replace function public._ifood_n(j jsonb) returns numeric language plpgsql immutable as $f$
begin
  if j is null then return 0; end if;
  return case jsonb_typeof(j)
    when 'number' then (j #>> '{}')::numeric
    when 'string' then coalesce(nullif(regexp_replace(j #>> '{}', '[^0-9.\-]', '', 'g'), '')::numeric, 0)
    when 'object' then public._ifood_n(coalesce(j->'value', j->'amount'))
    else 0 end;
exception when others then return 0;
end $f$;

create or replace function public._ifood_norm(t text) returns text language sql immutable as $f$
  select regexp_replace(lower(translate(coalesce(t, ''), 'ÁÀÂÃÄáàâãäÉÈÊËéèêëÍÌÎÏíìîïÓÒÔÕÖóòôõöÚÙÛÜúùûüÇç', 'AAAAAaaaaaEEEEeeeeIIIIiiiiOOOOOoooooUUUUuuuuCc')), '[^a-z0-9]', '', 'g')
$f$;

-- sugestão de ligação por nome (só quando há exatamente 1 produto/adicional com o mesmo nome)
create or replace function public._ifood_sugestao(p_nome text, p_tipo text) returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare v_n int; v_id uuid; v_nome text; v_k text := public._ifood_norm(p_nome);
begin
  if length(v_k) < 3 then return null; end if;
  if p_tipo = 'opcao' then
    select count(*), min(id::text)::uuid, min(nome) into v_n, v_id, v_nome from adicionais where ativo and public._ifood_norm(nome) = v_k;
    if v_n = 1 then return jsonb_build_object('tipo', 'adicional', 'id', v_id, 'nome', v_nome); end if;
  end if;
  select count(*), min(id::text)::uuid, min(nome) into v_n, v_id, v_nome from produtos where ativo and public._ifood_norm(nome) = v_k;
  if v_n = 1 then return jsonb_build_object('tipo', 'produto', 'id', v_id, 'nome', v_nome); end if;
  select count(*), min(id::text)::uuid, min(nome) into v_n, v_id, v_nome from combos where ativo and public._ifood_norm(nome) = v_k;
  if v_n = 1 then return jsonb_build_object('tipo', 'combo', 'id', v_id, 'nome', v_nome); end if;
  return null;
end $f$;

-- registra/atualiza um item visto no iFood; liga sozinho SÓ quando o código externo é exatamente o id de um produto/combo/adicional nosso
create or replace function public._ifood_item_visto(p_chave text, p_nome text, p_tipo text) returns public.ifood_itens
 language plpgsql security definer set search_path to 'public' as $f$
declare r ifood_itens%rowtype; v_u uuid;
begin
  insert into ifood_itens (chave, nome, tipo) values (p_chave, left(coalesce(nullif(p_nome, ''), p_chave), 200), p_tipo)
    on conflict (chave) do update set nome = excluded.nome, visto_em = now() returning * into r;
  if r.produto_id is null and r.combo_id is null and r.adicional_id is null and not r.ignorar then
    v_u := case when p_chave ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then p_chave::uuid end;
    if v_u is not null then
      if exists (select 1 from produtos where id = v_u) then update ifood_itens set produto_id = v_u, ligado_em = now() where chave = p_chave returning * into r;
      elsif exists (select 1 from combos where id = v_u) then update ifood_itens set combo_id = v_u, ligado_em = now() where chave = p_chave returning * into r;
      elsif p_tipo = 'opcao' and exists (select 1 from adicionais where id = v_u) then update ifood_itens set adicional_id = v_u, ligado_em = now() where chave = p_chave returning * into r;
      end if;
    end if;
  end if;
  return r;
end $f$;

-- grava (ou regrava) os itens da venda a partir do pedido do iFood e acerta o estoque. Devolve quantos itens ficaram sem ligação.
create or replace function public._ifood_gravar_itens(p_venda uuid, p_order jsonb, p_regravar boolean) returns int
 language plpgsql security definer set search_path to 'public' as $f$
declare it jsonb; op jsonb; v_item ifood_itens%rowtype; v_op ifood_itens%rowtype; v_chave text; v_qtd int; v_tot numeric; v_ads uuid[]; v_desc text; v_custo numeric; v_sem int := 0; v_obs text; v_oq int;
begin
  if p_regravar then
    perform _ajustar_estoque(_itens_da_venda(p_venda), -1, p_venda);
    delete from itens_venda where venda_id = p_venda;
  end if;
  for it in select value from jsonb_array_elements(coalesce(p_order->'items', '[]'::jsonb)) loop
    v_chave := coalesce(nullif(it->>'externalCode', ''), nullif(it->>'id', ''), 'sem-codigo-' || public._ifood_norm(it->>'name'));
    v_qtd := greatest(1, round(public._ifood_n(it->'quantity'))::int);
    v_tot := public._ifood_n(it->'totalPrice');
    if v_tot <= 0 then v_tot := public._ifood_n(it->'price'); end if;
    if v_tot <= 0 then v_tot := (public._ifood_n(it->'unitPrice') + public._ifood_n(it->'optionsPrice')) * v_qtd; end if;
    v_item := public._ifood_item_visto(v_chave, it->>'name', 'produto');
    v_ads := '{}'; v_desc := coalesce(it->>'name', 'Item iFood'); v_obs := nullif(btrim(coalesce(it->>'observations', '')), '');
    for op in select value from jsonb_array_elements(coalesce(it->'options', '[]'::jsonb)) loop
      v_op := public._ifood_item_visto(coalesce(nullif(op->>'externalCode', ''), nullif(op->>'id', ''), 'sem-codigo-' || public._ifood_norm(op->>'name')), op->>'name', 'opcao');
      v_oq := greatest(1, round(public._ifood_n(op->'quantity'))::int);
      v_desc := v_desc || ' + ' || coalesce(op->>'name', 'opção') || case when v_oq > 1 then ' x' || v_oq else '' end;
      if v_op.adicional_id is not null then
        for i in 1..(v_oq * v_qtd) loop v_ads := v_ads || v_op.adicional_id; end loop;
      end if;
    end loop;
    if v_obs is not null then v_desc := v_desc || ' (obs: ' || v_obs || ')'; end if;
    v_custo := 0;
    if v_item.produto_id is not null then select coalesce(min(custo), 0) into v_custo from produto_precos where produto_id = v_item.produto_id;
    elsif v_item.combo_id is not null then select coalesce(min(custo), 0) into v_custo from combo_precos where combo_id = v_item.combo_id;
    end if;
    if v_item.produto_id is null and v_item.combo_id is null and not v_item.ignorar then v_sem := v_sem + 1; v_desc := v_desc || ' [SEM LIGAÇÃO]'; end if;
    insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
    values (p_venda, case when v_item.ignorar then null else v_item.produto_id end, case when v_item.ignorar then null else v_item.combo_id end,
            left(v_desc, 300), v_qtd, round(v_tot / v_qtd, 2), round(v_custo, 2), round(v_tot, 2), v_ads);
  end loop;
  perform _ajustar_estoque(_itens_da_venda(p_venda), 1, p_venda);
  return v_sem;
end $f$;

-- ---------- criar / atualizar o pedido do iFood como venda ----------
create or replace function public.ifood_criar_pedido(p_order jsonb, p_simulado boolean default false) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare
  v_id text := p_order->>'id'; v_disp text := coalesce(nullif(p_order->>'displayId', ''), right(coalesce(p_order->>'id', ''), 4));
  v_venda uuid := gen_random_uuid(); v_tipo venda_tipo; v_nome text; v_tel text; v_end text; v_comp text; v_ref text; v_obs text;
  v_orig numeric; v_taxa numeric; v_desc numeric; v_total numeric; v_prepago numeric; v_pend numeric; v_sem int; v_caixa uuid; v_numero int; v_met jsonb; v_troco numeric; v_agend text;
  v_stpag status_pagamento; v_forma text; ad jsonb;
begin
  if v_id is null then return jsonb_build_object('ok', false, 'message', 'Pedido sem id.'); end if;
  if exists (select 1 from ifood_pedidos where pedido_ifood = v_id) then return jsonb_build_object('ok', true, 'duplicado', true); end if;
  v_tipo := case when upper(coalesce(p_order->>'orderType', '')) in ('TAKEOUT', 'PICKUP') then 'Retirada' else 'Entrega' end::venda_tipo;
  v_nome := left(btrim(coalesce(p_order->'customer'->>'name', 'Cliente iFood')), 80) || ' (iFood)';
  v_tel := left(regexp_replace(coalesce(p_order->'customer'->'phone'->>'number', ''), '[^0-9]', '', 'g'), 20);
  ad := coalesce(p_order->'delivery'->'deliveryAddress', '{}'::jsonb);
  v_end := coalesce(nullif(ad->>'formattedAddress', ''), btrim(concat_ws(', ', ad->>'streetName', ad->>'streetNumber', ad->>'neighborhood', ad->>'city')));
  v_comp := coalesce(ad->>'complement', ''); v_ref := coalesce(ad->>'reference', '');
  v_total := public._ifood_n(p_order->'total'->'orderAmount'); v_taxa := public._ifood_n(p_order->'total'->'deliveryFee');
  v_desc := public._ifood_n(p_order->'total'->'benefits'); v_orig := public._ifood_n(p_order->'total'->'subTotal');
  if v_orig <= 0 then v_orig := greatest(v_total - v_taxa + v_desc, 0); end if;
  if v_total <= 0 then v_total := greatest(v_orig - v_desc + v_taxa, 0.01); end if;
  v_prepago := public._ifood_n(p_order->'payments'->'prepaid'); v_pend := public._ifood_n(p_order->'payments'->'pending');
  if v_prepago + v_pend <= 0 then v_prepago := v_total; v_pend := 0; end if;
  v_stpag := case when v_pend > 0.009 then 'A Receber' else 'Pago' end;
  v_forma := case when v_pend > 0.009 and v_prepago > 0.009 then 'iFood (pago no app) + iFood (pagar na entrega)' when v_pend > 0.009 then 'iFood (pagar na entrega)' else 'iFood (pago no app)' end;
  v_obs := 'iFood #' || v_disp;
  select (m->'cash'->>'changeFor') into v_troco from jsonb_array_elements(coalesce(p_order->'payments'->'methods', '[]'::jsonb)) m where m->'cash'->>'changeFor' is not null limit 1;
  if v_troco is not null and public._ifood_n(to_jsonb(v_troco)) > 0 then v_obs := v_obs || ' · levar troco para R$ ' || replace(to_char(public._ifood_n(to_jsonb(v_troco)), 'FM9999990.00'), '.', ','); end if;
  if upper(coalesce(p_order->>'orderTiming', '')) = 'SCHEDULED' then
    v_agend := coalesce(p_order->'schedule'->>'deliveryDateTimeStart', p_order->'delivery'->>'deliveryDateTime', p_order->>'preparationStartDateTime', '');
    v_obs := v_obs || ' · AGENDADO' || case when v_agend <> '' then ' para ' || to_char((v_agend::timestamptz) at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') else '' end;
  end if;
  if nullif(btrim(coalesce(p_order->'delivery'->>'observations', '')), '') is not null then v_obs := v_obs || ' · ' || btrim(p_order->'delivery'->>'observations'); end if;
  if p_simulado then v_obs := v_obs || ' · TESTE (simulação)'; end if;
  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido, endereco, complemento, referencia, observacoes_entrega,
                      status_pagamento, recebido_em, valor_original, valor_desconto, desconto_detalhe, origem, taxa_entrega, caixa_id, requisicao_id, canal)
  values (v_venda, v_nome, nullif(v_tel, ''), v_forma, round(v_total, 2), 0, 'Confirmada', v_tipo, 'Recebido',
          case when v_tipo = 'Entrega' then coalesce(v_end, '') else '' end, case when v_tipo = 'Entrega' then v_comp else '' end, case when v_tipo = 'Entrega' then v_ref else '' end, v_obs,
          v_stpag, case when v_stpag = 'Pago' then now() end, round(v_orig, 2), round(v_desc, 2), case when v_desc > 0 then 'Desconto/cupom iFood' else '' end, 'Balcão', round(v_taxa, 2), v_caixa, 'ifood:' || v_id, 'iFood')
  returning numero_pedido into v_numero;

  v_sem := public._ifood_gravar_itens(v_venda, p_order, false);
  update vendas set custo_total = coalesce((select sum(custo_unitario * quantidade) from itens_venda where venda_id = v_venda), 0) where id = v_venda;

  if v_prepago > 0.009 then insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo) values (v_venda, 'iFood (pago no app)', round(v_prepago, 2), 0, 0); end if;
  if v_pend > 0.009 then insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo) values (v_venda, 'iFood (pagar na entrega)', round(v_pend, 2), 0, 0); end if;

  insert into ifood_pedidos (pedido_ifood, venda_id, numero_ifood, estado, expira_em, itens_sem_ligacao, simulado, bruto)
  values (v_id, v_venda, v_disp, 'novo', now() + interval '8 minutes', v_sem, p_simulado, p_order);
  update ifood_estado set ultimo_pedido_em = now(), atualizado_em = now() where id;
  perform _auditar('Pedido do iFood recebido', 'iFood #' || v_disp || ' → venda #' || v_numero || ' · R$ ' || replace(to_char(v_total, 'FM9999990.00'), '.', ',') || case when v_sem > 0 then ' · ' || v_sem || ' item(ns) sem ligação' else '' end || case when p_simulado then ' · SIMULAÇÃO' else '' end);
  perform _integ_log('ifood', case when v_sem > 0 then 'aviso' else 'info' end, 'Pedido #' || v_disp || ' recebido' || case when v_sem > 0 then ' (' || v_sem || ' item sem ligação)' else '' end);
  return jsonb_build_object('ok', true, 'vendaId', v_venda, 'numero', v_numero, 'semLigacao', v_sem);
end $f$;

-- cliente mudou o pedido (ORDER_PATCHED): regrava itens e totais
create or replace function public.ifood_atualizar_pedido(p_order jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r ifood_pedidos%rowtype; v_sem int; v_total numeric;
begin
  select * into r from ifood_pedidos where pedido_ifood = p_order->>'id' for update;
  if not found then return public.ifood_criar_pedido(p_order, false); end if;
  if r.venda_id is null or r.estado = 'cancelado' then return jsonb_build_object('ok', true, 'ignorado', true); end if;
  v_sem := public._ifood_gravar_itens(r.venda_id, p_order, true);
  v_total := public._ifood_n(p_order->'total'->'orderAmount');
  update vendas set valor_total = case when v_total > 0 then round(v_total, 2) else valor_total end,
    valor_original = case when public._ifood_n(p_order->'total'->'subTotal') > 0 then public._ifood_n(p_order->'total'->'subTotal') else valor_original end,
    custo_total = coalesce((select sum(custo_unitario * quantidade) from itens_venda where venda_id = r.venda_id), 0)
    where id = r.venda_id;
  update ifood_pedidos set bruto = p_order, itens_sem_ligacao = v_sem, atualizado_em = now() where pedido_ifood = r.pedido_ifood;
  perform _auditar('Pedido do iFood alterado pelo cliente', 'iFood #' || r.numero_ifood);
  perform _integ_log('ifood', 'aviso', 'Pedido #' || r.numero_ifood || ' foi alterado pelo cliente');
  return jsonb_build_object('ok', true, 'semLigacao', v_sem);
end $f$;

-- eventos oficiais mudam o estado do pedido (nunca a nossa suposição)
create or replace function public.ifood_aplicar_evento(p_codigo text, p_pedido text, p_motivo text default null) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r ifood_pedidos%rowtype; v vendas%rowtype; v_st text;
begin
  select * into r from ifood_pedidos where pedido_ifood = p_pedido for update;
  if not found then return jsonb_build_object('ok', false, 'desconhecido', true); end if;
  if p_codigo in ('CFM', 'CONFIRMED') and r.estado = 'novo' then update ifood_pedidos set estado = 'confirmado', confirmado_em = now(), atualizado_em = now() where pedido_ifood = p_pedido;
  elsif p_codigo in ('RTP', 'READY_TO_PICKUP') and r.estado in ('novo', 'confirmado', 'em_preparo') then update ifood_pedidos set estado = 'pronto', atualizado_em = now() where pedido_ifood = p_pedido;
  elsif p_codigo in ('DSP', 'DISPATCHED') and r.estado <> 'cancelado' then update ifood_pedidos set estado = 'despachado', atualizado_em = now() where pedido_ifood = p_pedido;
  elsif p_codigo in ('CON', 'CONCLUDED') and r.estado <> 'cancelado' then
    update ifood_pedidos set estado = 'concluido', atualizado_em = now() where pedido_ifood = p_pedido;
    update vendas set status_pedido = case when tipo = 'Entrega' then 'Entregue' else 'Retirada' end::status_pedido, concluida_em = coalesce(concluida_em, now())
      where id = r.venda_id and status = 'Confirmada' and status_pedido::text not in ('Entregue', 'Retirada', 'Servida');
  elsif p_codigo in ('CAN', 'CANCELLED') and r.estado <> 'cancelado' then
    update ifood_pedidos set estado = 'cancelado', atualizado_em = now() where pedido_ifood = p_pedido;
    select * into v from vendas where id = r.venda_id for update;
    if found and v.status = 'Confirmada' then
      v_st := v.status_pedido::text;
      update vendas set status = 'Cancelada', motivo_cancelamento = left('Cancelado pelo iFood' || coalesce(' · ' || nullif(p_motivo, ''), ''), 200) where id = v.id;
      if v_st in ('Recebido', 'Em preparo', 'Suspenso') then perform _ajustar_estoque(_itens_da_venda(v.id), -1, v.id); end if;
      update ifood_acoes set estado = 'pulada', erro = 'pedido cancelado' where pedido_ifood = p_pedido and estado in ('pendente', 'duvida');
      perform _auditar('Pedido do iFood cancelado pelo iFood', 'iFood #' || r.numero_ifood || coalesce(' · ' || nullif(p_motivo, ''), '') || case when v_st not in ('Recebido', 'Em preparo', 'Suspenso') then ' · já estava pronto: estoque NÃO devolvido' else '' end);
      perform _integ_log('ifood', 'aviso', 'Pedido #' || r.numero_ifood || ' cancelado pelo iFood');
      begin perform _push_enviar('pedido', '❌ iFood cancelou o pedido #' || r.numero_ifood, coalesce(nullif(p_motivo, ''), 'Veja o painel'), 'ifood-can-' || r.pedido_ifood); exception when others then null; end;
    end if;
  end if;
  return jsonb_build_object('ok', true);
end $f$;

-- ---------- ações para o iFood: a mudança de status na nossa tela vira uma tarefa para o servidor ----------
create or replace function public._ifood_enfileirar(p_pedido text, p_acao text, p_dados jsonb default '{}'::jsonb) returns void
 language sql security definer set search_path to 'public' as $f$
  insert into ifood_acoes (pedido_ifood, acao, dados) values (p_pedido, p_acao, p_dados) on conflict do nothing
$f$;

create or replace function public._ifood_trg_status() returns trigger language plpgsql security definer set search_path to 'public' as $f$
declare r ifood_pedidos%rowtype;
begin
  if new.canal is distinct from 'iFood' then return null; end if;
  if not public._integracao_ligada('ifood') then return null; end if;
  select * into r from ifood_pedidos where venda_id = new.id;
  if not found or r.simulado or r.estado in ('cancelado', 'concluido') then return null; end if;
  if new.status = 'Cancelada' and old.status is distinct from 'Cancelada' then
    perform public._ifood_enfileirar(r.pedido_ifood, 'cancelar', jsonb_build_object('motivo', new.motivo_cancelamento));
  elsif new.status_pedido is distinct from old.status_pedido and new.status = 'Confirmada' then
    if new.status_pedido::text = 'Em preparo' then
      if r.estado = 'novo' then perform public._ifood_enfileirar(r.pedido_ifood, 'confirmar'); end if;
      perform public._ifood_enfileirar(r.pedido_ifood, 'iniciar_preparo');
    elsif new.status_pedido::text = 'Pronta' then
      perform public._ifood_enfileirar(r.pedido_ifood, 'pronto');
    elsif new.status_pedido::text = 'Saiu para entrega' then
      perform public._ifood_enfileirar(r.pedido_ifood, 'despachar');
    end if;
  end if;
  return null;
end $f$;
drop trigger if exists trg_ifood_status on public.vendas;
create trigger trg_ifood_status after update of status, status_pedido on public.vendas for each row when (new.canal = 'iFood') execute function public._ifood_trg_status();

-- aviso à equipe quando entra pedido do iFood (o trigger antigo só avisa pedidos do cardápio)
create or replace function public._ifood_trg_novo() returns trigger language plpgsql security definer set search_path to 'public' as $f$
begin
  perform _push_enviar('pedido', '🛵 Novo pedido iFood #' || coalesce(new.numero_pedido::text, ''), coalesce(new.tipo::text, '') || ' · R$ ' || replace(to_char(coalesce(new.valor_total, 0), 'FM9999990.00'), '.', ','), 'pedido-' || new.id::text);
  return null;
exception when others then return null;
end $f$;
drop trigger if exists trg_ifood_novo on public.vendas;
create trigger trg_ifood_novo after insert on public.vendas for each row when (new.canal = 'iFood') execute function public._ifood_trg_novo();

-- ---------- funções só do servidor (edge function ifood-sync, chave de serviço) ----------
create or replace function public.ifood_credenciais() returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('ligado', public._integracao_ligada('ifood'),
    'clientId', (select valor from integracoes_segredos where chave = 'ifood_client_id'),
    'clientSecret', (select valor from integracoes_segredos where chave = 'ifood_client_secret'),
    'merchantId', (select valor from integracoes_segredos where chave = 'ifood_merchant_id'),
    'config', (select config from integracoes_config where provedor = 'ifood'))
$f$;
create or replace function public.ifood_token_ler() returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('token', token, 'expiraEm', expira_em) from ifood_token where id and expira_em > now() + interval '2 minutes'
$f$;
create or replace function public.ifood_token_gravar(p_token text, p_seg int) returns void language sql security definer set search_path to 'public' as $f$
  update ifood_token set token = p_token, expira_em = now() + make_interval(secs => greatest(p_seg, 60)) where id;
  update ifood_estado set token_ok = true, atualizado_em = now() where id;
$f$;
create or replace function public.ifood_trava_pegar(p_dono text, p_seg int) returns boolean language plpgsql security definer set search_path to 'public' as $f$
declare v int;
begin
  update ifood_estado set trava_dono = p_dono, trava_ate = now() + make_interval(secs => p_seg) where id and (trava_ate is null or trava_ate < now() or trava_dono = p_dono);
  get diagnostics v = row_count;
  return v > 0;
end $f$;
create or replace function public.ifood_trava_soltar(p_dono text) returns void language sql security definer set search_path to 'public' as $f$
  update ifood_estado set trava_ate = null where id and trava_dono = p_dono
$f$;
create or replace function public.ifood_marcar_consulta(p_ok boolean, p_erro text default null, p_token_ok boolean default null) returns void
 language plpgsql security definer set search_path to 'public' as $f$
begin
  update ifood_estado set ultima_consulta = now(),
    ultima_consulta_ok = case when p_ok then now() else ultima_consulta_ok end,
    token_ok = coalesce(p_token_ok, token_ok),
    ultimo_erro = case when p_ok then null else left(p_erro, 300) end,
    ultimo_erro_em = case when p_ok then ultimo_erro_em else now() end, atualizado_em = now() where id;
  if not p_ok and p_erro is not null then perform public._integ_log('ifood', 'erro', p_erro); end if;
end $f$;
create or replace function public.ifood_evento_guardar(p jsonb) returns boolean language plpgsql security definer set search_path to 'public' as $f$
declare v int;
begin
  insert into ifood_eventos (id, codigo, codigo_completo, pedido_ifood, criado_ifood, bruto)
  values (p->>'id', p->>'code', p->>'fullCode', p->>'orderId', nullif(p->>'createdAt', '')::timestamptz, p) on conflict (id) do nothing;
  get diagnostics v = row_count;
  return v > 0;
end $f$;
create or replace function public.ifood_eventos_pendentes() returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select coalesce(jsonb_agg(jsonb_build_object('id', id, 'codigo', coalesce(codigo_completo, codigo), 'pedido', pedido_ifood, 'tentativas', tentativas, 'bruto', bruto) order by recebido_em), '[]'::jsonb)
  from (select * from ifood_eventos where processado_em is null and recebido_em > now() - interval '1 day' order by recebido_em limit 50) x
$f$;
create or replace function public.ifood_evento_resultado(p_id text, p_final boolean, p_erro text default null) returns void language sql security definer set search_path to 'public' as $f$
  update ifood_eventos set tentativas = tentativas + 1, erro = left(p_erro, 300), processado_em = case when p_final then now() else null end where id = p_id
$f$;
create or replace function public.ifood_acoes_pendentes() returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select coalesce(jsonb_agg(jsonb_build_object('id', a.id, 'pedido', a.pedido_ifood, 'acao', a.acao, 'dados', a.dados, 'tentativas', a.tentativas) order by a.id), '[]'::jsonb)
  from (select * from ifood_acoes where estado = 'pendente' order by id limit 20) a
$f$;
create or replace function public.ifood_acao_resultado(p_id bigint, p_estado text, p_erro text default null) returns void
 language plpgsql security definer set search_path to 'public' as $f$
declare a ifood_acoes%rowtype;
begin
  update ifood_acoes set estado = p_estado, tentativas = tentativas + 1, erro = left(p_erro, 300), executado_em = now() where id = p_id returning * into a;
  if a.id is null then return; end if;
  if p_estado = 'ok' then
    if a.acao = 'confirmar' then update ifood_pedidos set estado = 'confirmado', confirmado_em = coalesce(confirmado_em, now()), atualizado_em = now() where pedido_ifood = a.pedido_ifood and estado = 'novo'; end if;
    perform public._integ_log('ifood', 'info', 'Ação enviada ao iFood: ' || a.acao || ' (pedido ' || a.pedido_ifood || ')');
  elsif p_estado in ('erro', 'duvida') then
    perform public._integ_log('ifood', 'erro', 'Ação NÃO confirmada no iFood: ' || a.acao || ' — ' || coalesce(p_erro, ''));
  end if;
end $f$;
create or replace function public.ifood_pedido_dados(p_pedido text) returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('estado', estado, 'simulado', simulado, 'expiraEm', expira_em, 'numero', numero_ifood) from ifood_pedidos where pedido_ifood = p_pedido
$f$;
-- pedidos que ainda não foram confirmados (para confirmar sozinho ou avisar a equipe aos 4 e 6 min)
create or replace function public.ifood_novos_sem_confirmar() returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select coalesce(jsonb_agg(jsonb_build_object('pedido', pedido_ifood, 'numero', numero_ifood, 'minutos', round(extract(epoch from (now() - criado_em)) / 60, 1))), '[]'::jsonb)
  from ifood_pedidos where estado = 'novo' and not simulado and criado_em > now() - interval '15 minutes'
$f$;
create or replace function public.ifood_enfileirar(p_pedido text, p_acao text) returns void language sql security definer set search_path to 'public' as $f$
  select public._ifood_enfileirar(p_pedido, p_acao, '{}'::jsonb)
$f$;
-- pedido novo sem confirmação: avisa a equipe aos 4 e aos 6 minutos (o iFood cancela sozinho aos 8)
create or replace function public.ifood_escalar() returns int language plpgsql security definer set search_path to 'public' as $f$
declare r record; v_n int := 0;
begin
  for r in select pedido_ifood, numero_ifood, avisos, extract(epoch from (now() - criado_em)) / 60 as min from ifood_pedidos where estado = 'novo' and not simulado and criado_em > now() - interval '9 minutes' loop
    if (r.min >= 6 and r.avisos < 2) or (r.min >= 4 and r.avisos < 1) then
      update ifood_pedidos set avisos = case when r.min >= 6 then 2 else 1 end where pedido_ifood = r.pedido_ifood;
      perform _push_enviar('pedido', '⏰ iFood #' || coalesce(r.numero_ifood, '') || ' esperando confirmação', 'Confirme agora: o iFood cancela sozinho em poucos minutos.', 'ifood-conf-' || r.pedido_ifood || '-' || r.avisos);
      v_n := v_n + 1;
    end if;
  end loop;
  return v_n;
end $f$;
create or replace function public.ifood_limpar() returns void language plpgsql security definer set search_path to 'public' as $f$
declare v_dias int := coalesce((select (config->>'retencaoClientesDias')::int from integracoes_config where provedor = 'ifood'), 90);
begin
  delete from ifood_eventos where recebido_em < now() - interval '30 days';
  delete from ifood_acoes where criado_em < now() - interval '60 days' and estado in ('ok', 'pulada');
  update ifood_pedidos set bruto = jsonb_set(coalesce(bruto, '{}'::jsonb) - 'customer' - 'delivery', '{apagado}', 'true'::jsonb) where criado_em < now() - make_interval(days => v_dias) and coalesce((bruto->>'apagado'), '') <> 'true';
  update vendas set telefone_cliente = null, endereco = '', complemento = '', referencia = '', cliente_nome = 'Cliente iFood'
   where canal = 'iFood' and data_hora < now() - make_interval(days => v_dias) and (telefone_cliente is not null or endereco <> '' or cliente_nome <> 'Cliente iFood');
end $f$;

-- ---------- telas do administrador ----------
create or replace function public.api_ifood_pedidos(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'estado', (select jsonb_build_object('ultimaConsulta', ultima_consulta, 'ultimaConsultaOk', ultima_consulta_ok, 'ultimoPedido', ultimo_pedido_em, 'tokenOk', token_ok, 'ultimoErro', ultimo_erro) from ifood_estado where id),
    'pedidos', coalesce((select jsonb_agg(jsonb_build_object('pedido', i.pedido_ifood, 'numero', i.numero_ifood, 'estado', i.estado, 'semLigacao', i.itens_sem_ligacao, 'simulado', i.simulado,
        'venda', v.numero_pedido, 'total', v.valor_total, 'em', i.criado_em, 'cancelado', v.status = 'Cancelada',
        'acaoErro', (select a.acao || ': ' || coalesce(a.erro, '') from ifood_acoes a where a.pedido_ifood = i.pedido_ifood and a.estado in ('erro', 'duvida') order by a.id desc limit 1)) order by i.criado_em desc)
      from (select * from ifood_pedidos order by criado_em desc limit 30) i left join vendas v on v.id = i.venda_id), '[]'::jsonb));
end $f$;

create or replace function public.api_ifood_itens(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'itens', coalesce((select jsonb_agg(jsonb_build_object('chave', i.chave, 'nome', i.nome, 'tipo', i.tipo, 'ignorar', i.ignorar,
        'ligado', case when i.produto_id is not null then 'produto' when i.combo_id is not null then 'combo' when i.adicional_id is not null then 'adicional' end,
        'ligadoId', coalesce(i.produto_id, i.combo_id, i.adicional_id),
        'ligadoNome', coalesce((select nome from produtos where id = i.produto_id), (select nome from combos where id = i.combo_id), (select nome from adicionais where id = i.adicional_id)),
        'sugestao', case when i.produto_id is null and i.combo_id is null and i.adicional_id is null and not i.ignorar then public._ifood_sugestao(i.nome, i.tipo) end)
        order by (i.produto_id is null and i.combo_id is null and i.adicional_id is null and not i.ignorar) desc, i.nome) from ifood_itens i), '[]'::jsonb),
    'produtos', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'nome', nome) order by nome) from produtos where ativo), '[]'::jsonb),
    'combos', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'nome', nome) order by nome) from combos where ativo), '[]'::jsonb),
    'adicionais', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'nome', nome) order by nome) from adicionais where ativo), '[]'::jsonb));
end $f$;

create or replace function public.api_ifood_ligar_item(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_chave text := p->>'chave'; v_tipo text := p->>'tipo'; v_id uuid := nullif(p->>'id', '')::uuid; v_ignorar boolean := coalesce((p->>'ignorar')::boolean, false);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not exists (select 1 from ifood_itens where chave = v_chave) then return _falha('Item não encontrado.'); end if;
  if v_ignorar then
    update ifood_itens set ignorar = true, produto_id = null, combo_id = null, adicional_id = null, ligado_em = now() where chave = v_chave;
  elsif v_tipo = 'produto' and exists (select 1 from produtos where id = v_id) then
    update ifood_itens set ignorar = false, produto_id = v_id, combo_id = null, adicional_id = null, ligado_em = now() where chave = v_chave;
  elsif v_tipo = 'combo' and exists (select 1 from combos where id = v_id) then
    update ifood_itens set ignorar = false, produto_id = null, combo_id = v_id, adicional_id = null, ligado_em = now() where chave = v_chave;
  elsif v_tipo = 'adicional' and exists (select 1 from adicionais where id = v_id) then
    update ifood_itens set ignorar = false, produto_id = null, combo_id = null, adicional_id = v_id, ligado_em = now() where chave = v_chave;
  elsif v_tipo = 'desligar' then
    update ifood_itens set ignorar = false, produto_id = null, combo_id = null, adicional_id = null, ligado_em = null where chave = v_chave;
  else return _falha('Escolha um item válido do sistema.'); end if;
  perform _auditar('Item do iFood ligado', v_chave || ' → ' || coalesce(v_tipo, '') || case when v_ignorar then ' (ignorar)' else '' end);
  return api_ifood_itens('{}');
end $f$;

-- depois de ligar itens, refaz os pedidos que ficaram sem ligação (ajusta custo e estoque)
create or replace function public.api_ifood_reprocessar(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r record; v_n int := 0; v_sem int;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  for r in select i.* from ifood_pedidos i join vendas v on v.id = i.venda_id where i.itens_sem_ligacao > 0 and v.status = 'Confirmada' and i.bruto ? 'items' and v.fechamento_entrega_id is null loop
    v_sem := public._ifood_gravar_itens(r.venda_id, r.bruto, true);
    update vendas set custo_total = coalesce((select sum(custo_unitario * quantidade) from itens_venda where venda_id = r.venda_id), 0) where id = r.venda_id;
    update ifood_pedidos set itens_sem_ligacao = v_sem, atualizado_em = now() where pedido_ifood = r.pedido_ifood;
    v_n := v_n + 1;
  end loop;
  perform _auditar('Pedidos do iFood reprocessados', v_n || ' pedido(s)');
  return jsonb_build_object('ok', true, 'message', v_n || ' pedido(s) refeito(s) com as ligações atuais.') || api_ifood_pedidos('{}');
end $f$;

-- simulação (treino): só Desenvolvedor. Cria um pedido de mentira com itens reais do cardápio; nada é enviado ao iFood.
create or replace function public.api_ifood_simular(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_prod record; v_id text := 'SIM-' || substr(md5(random()::text), 1, 10); v_order jsonb; v_itens jsonb := '[]'::jsonb; v_sub numeric := 0; v_pre boolean := coalesce((p->>'pagoNoApp')::boolean, true); v_res jsonb; v_pr numeric;
begin
  if not public._eh_dev() then return _negado(); end if;
  for v_prod in select pr.id, pr.nome, coalesce((select min(preco) from produto_precos where produto_id = pr.id), 20) preco from produtos pr where pr.ativo order by random() limit 2 loop
    v_pr := v_prod.preco;
    v_itens := v_itens || jsonb_build_object('id', 'it-' || substr(md5(v_prod.id::text), 1, 8), 'name', v_prod.nome, 'externalCode', v_prod.id::text, 'quantity', 1, 'unitPrice', v_pr, 'optionsPrice', 0, 'totalPrice', v_pr, 'observations', 'sem cebola (teste)', 'options', '[]'::jsonb);
    v_sub := v_sub + v_pr;
  end loop;
  if jsonb_array_length(v_itens) = 0 then return _falha('Cadastre ao menos um produto ativo para simular.'); end if;
  v_itens := v_itens || jsonb_build_object('id', 'it-sim-novo', 'name', 'Item novo do iFood (teste sem ligação)', 'externalCode', 'SIM-SEM-LIGACAO', 'quantity', 1, 'unitPrice', 10, 'totalPrice', 10, 'options', '[]'::jsonb);
  v_sub := v_sub + 10;
  v_order := jsonb_build_object('id', v_id, 'displayId', right(v_id, 4), 'orderType', 'DELIVERY', 'orderTiming', 'IMMEDIATE', 'createdAt', now(),
    'customer', jsonb_build_object('name', 'Cliente Teste', 'phone', jsonb_build_object('number', '11999990000')),
    'delivery', jsonb_build_object('deliveredBy', 'MERCHANT', 'deliveryAddress', jsonb_build_object('formattedAddress', 'Rua de Teste, 100 - Centro', 'complement', 'ap 1', 'reference', 'perto da praça')),
    'items', v_itens,
    'total', jsonb_build_object('subTotal', v_sub, 'deliveryFee', 6, 'benefits', 0, 'orderAmount', v_sub + 6),
    'payments', case when v_pre then jsonb_build_object('prepaid', v_sub + 6, 'pending', 0, 'methods', jsonb_build_array(jsonb_build_object('type', 'PREPAID', 'method', 'CREDIT', 'value', v_sub + 6)))
                     else jsonb_build_object('prepaid', 0, 'pending', v_sub + 6, 'methods', jsonb_build_array(jsonb_build_object('type', 'PENDING', 'method', 'CASH', 'value', v_sub + 6, 'cash', jsonb_build_object('changeFor', 100)))) end);
  v_res := public.ifood_criar_pedido(v_order, true);
  update ifood_pedidos set estado = 'confirmado', confirmado_em = now() where pedido_ifood = v_id;
  return jsonb_build_object('ok', true, 'message', 'Pedido de TESTE criado (venda #' || (v_res->>'numero') || '). Cancele a venda depois do treino. Nada foi enviado ao iFood.') || api_ifood_pedidos('{}');
end $f$;

-- ---------- saúde: iFood (e a Nota fiscal, nas fases seguintes) ----------
create or replace function public._saude_integracoes() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_desc int; e ifood_estado%rowtype; v_min numeric; v_sem int; v_novos int; v_acoes int; v_nivel text; v_txt text;
begin
  if exists (select 1 from ai_segredos where provedor = 'nvidia') or exists (select 1 from ai_segredos where provedor = 'cloudflare') then
    select count(*) into v_desc from unnest(array['nvidia', 'cloudflare']) x(p) where _ia_provedor_descansando(x.p);
    v := v || jsonb_build_object('id', 'ia_extras', 'titulo', 'IAs de reserva (NVIDIA / Cloudflare)', 'nivel', case when v_desc > 0 then 'atencao' else 'ok' end,
      'texto', (select string_agg(x.rot || ': ' || case when not exists (select 1 from ai_segredos where provedor = x.p) then 'sem chave' when _ia_provedor_descansando(x.p) then 'descansando (erros recentes)' else 'pronta' end, ' · ')
                from (values ('nvidia', 'NVIDIA'), ('cloudflare', 'Cloudflare')) x(p, rot)));
  end if;
  if _integracao_ligada('ifood') then
    select * into e from ifood_estado where id;
    v_min := case when e.ultima_consulta_ok is null then null else extract(epoch from (now() - e.ultima_consulta_ok)) / 60 end;
    select coalesce(sum(itens_sem_ligacao), 0) into v_sem from ifood_pedidos where estado <> 'cancelado' and criado_em > now() - interval '7 days';
    select count(*) into v_novos from ifood_pedidos where estado = 'novo' and not simulado and criado_em < now() - interval '4 minutes';
    select count(*) into v_acoes from ifood_acoes where estado in ('erro', 'duvida') and criado_em > now() - interval '1 day';
    v_nivel := case when v_min is null or v_min > 2 or e.token_ok is false or v_novos > 0 then 'problema' when v_acoes > 0 or v_sem > 0 or e.ultimo_erro is not null then 'atencao' else 'ok' end;
    v_txt := case when v_min is null then 'Ligado, mas ainda sem nenhuma consulta bem-sucedida ao iFood.' else 'Última consulta ao iFood há ' || round(v_min, 1) || ' min' end
      || case when e.ultimo_pedido_em is not null then ' · último pedido às ' || to_char(e.ultimo_pedido_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') else ' · nenhum pedido ainda' end
      || case when e.token_ok is false then ' · ACESSO RECUSADO (confira as chaves)' else '' end
      || case when v_novos > 0 then ' · ' || v_novos || ' pedido(s) esperando confirmação há mais de 4 min' else '' end
      || case when v_acoes > 0 then ' · ' || v_acoes || ' ação(ões) não confirmada(s) no iFood' else '' end
      || case when v_sem > 0 then ' · ' || v_sem || ' item(ns) sem ligação' else '' end;
    v := v || jsonb_build_object('id', 'ifood', 'titulo', 'iFood', 'nivel', v_nivel, 'texto', v_txt);
  end if;
  for r in select * from integracoes_config where ligado and provedor = 'nfce' loop
    v := v || jsonb_build_object('id', 'nfce', 'titulo', 'Nota fiscal (NFC-e)', 'nivel', 'atencao', 'texto', 'Ligada (' || r.modo || '), aguardando a primeira nota.');
  end loop;
  return v;
end $f$;

-- itens sem ligação / pedido do iFood esperando também entram nas pendências para ligar (checklist)
-- ---------- tarefas automáticas (só chamam o iFood quando a integração está ligada) ----------
do $c$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.schedule('ifood-sync-minuto', '* * * * *', $j$select case when public._integracao_ligada('ifood') then public.chamar_edge('ifood-sync', '{}'::jsonb) end$j$);
    perform cron.schedule('ifood-limpeza-diaria', '55 6 * * *', $j$select public.ifood_limpar()$j$);
  end if;
end $c$;

-- ---------- permissões ----------
revoke execute on function public._ifood_n(jsonb), public._ifood_norm(text), public._ifood_sugestao(text, text), public._ifood_item_visto(text, text, text), public._ifood_gravar_itens(uuid, jsonb, boolean),
  public._ifood_enfileirar(text, text, jsonb), public._ifood_trg_status(), public._ifood_trg_novo(),
  public.ifood_criar_pedido(jsonb, boolean), public.ifood_atualizar_pedido(jsonb), public.ifood_aplicar_evento(text, text, text), public.ifood_credenciais(), public.ifood_token_ler(),
  public.ifood_token_gravar(text, int), public.ifood_trava_pegar(text, int), public.ifood_trava_soltar(text), public.ifood_marcar_consulta(boolean, text, boolean), public.ifood_evento_guardar(jsonb),
  public.ifood_eventos_pendentes(), public.ifood_evento_resultado(text, boolean, text), public.ifood_acoes_pendentes(), public.ifood_acao_resultado(bigint, text, text),
  public.ifood_pedido_dados(text), public.ifood_novos_sem_confirmar(), public.ifood_enfileirar(text, text), public.ifood_escalar(), public.ifood_limpar() from public, anon, authenticated;
grant execute on function public.ifood_criar_pedido(jsonb, boolean), public.ifood_atualizar_pedido(jsonb), public.ifood_aplicar_evento(text, text, text), public.ifood_credenciais(), public.ifood_token_ler(),
  public.ifood_token_gravar(text, int), public.ifood_trava_pegar(text, int), public.ifood_trava_soltar(text), public.ifood_marcar_consulta(boolean, text, boolean), public.ifood_evento_guardar(jsonb),
  public.ifood_eventos_pendentes(), public.ifood_evento_resultado(text, boolean, text), public.ifood_acoes_pendentes(), public.ifood_acao_resultado(bigint, text, text),
  public.ifood_pedido_dados(text), public.ifood_novos_sem_confirmar(), public.ifood_enfileirar(text, text), public.ifood_escalar(), public.ifood_limpar() to service_role;
revoke execute on function public.api_ifood_pedidos(jsonb), public.api_ifood_itens(jsonb), public.api_ifood_ligar_item(jsonb), public.api_ifood_reprocessar(jsonb), public.api_ifood_simular(jsonb) from public, anon;
grant execute on function public.api_ifood_pedidos(jsonb), public.api_ifood_itens(jsonb), public.api_ifood_ligar_item(jsonb), public.api_ifood_reprocessar(jsonb), public.api_ifood_simular(jsonb) to authenticated;

-- ---------- Ajuda do assistente ----------
insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-103-ifood','iFood: pedidos, itens ligados e simulação','ifood pedido itens ligar ligação produto sem ligação reprocessar simulação teste confirmar',
 E'Com o iFood ligado (Contas e acessos → Integrações), os pedidos entram sozinhos como venda normal, com a marca "iFood #número", aviso no celular e baixa dos ingredientes.\nItens do iFood: cada item do cardápio do iFood precisa ser ligado a um produto do sistema (Contas e acessos → Integrações → Itens do iFood). O sistema sugere pelo nome; você confirma. Item sem ligação entra no pedido mesmo assim, com o aviso "SEM LIGAÇÃO"; depois de ligar, toque em "Refazer pedidos sem ligação".\nO andamento (em preparo, pronta, saiu para entrega) é avisado ao iFood automaticamente quando você muda o status do pedido. Se o iFood não confirmar uma ação, aparece um alerta na lista de pedidos do iFood.\nDesenvolvedor: "Simular pedido do iFood (treino)" cria um pedido de mentira, sem enviar nada ao iFood; cancele a venda depois do treino.',
 array['Admin','Operador'],true,'lista',103,'Itens do iFood e simulação: só Administrador/Desenvolvedor.'
where not exists (select 1 from ai_ajuda where slug='man-admin-103-ifood');
