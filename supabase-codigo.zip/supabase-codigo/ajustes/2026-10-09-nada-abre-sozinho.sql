-- TEXAS BURGER — Ajuda do assistente: no Admin nada abre sozinho (só os grupos ao entrar) · 2026-10-09
update ai_ajuda set passos = replace(passos, 'A aba Administrador tem uma barra dividida em 6 grupos:', E'Ao tocar em Admin, nada abre sozinho: aparecem só os 6 grupos; toque num grupo para ver as telas dele e depois na tela que quer abrir.\nA aba Administrador tem uma barra dividida em 6 grupos:')
where ativo and passos like '%A aba Administrador tem uma barra dividida em 6 grupos:%' and passos not like '%nada abre sozinho%';
