-- v1.0 — Cupom progressivo (desconto por faixa do pedido)
-- Rode UMA vez num banco que já existe. Tipo 'progressivo': faixas [{minimo, desconto}]; vale a maior faixa alcançada, sobre os itens (sem taxa de entrega).
alter table public.cupons add column if not exists faixas jsonb not null default '[]'::jsonb;

CREATE OR REPLACE FUNCTION public._cupom_validar(p jsonb, p_id uuid, OUT erro text, OUT c cupons)
 RETURNS record
 LANGUAGE plpgsql
 SET search_path TO 'public'
AS $function$
declare v_fx jsonb := '[]'::jsonb; f record; v_ant numeric := 0; v_n int := 0; v_cod text := upper(regexp_replace(btrim(coalesce(p->>'codigo', '')), '\s+', '', 'g'));
        v_tipo text := coalesce(nullif(btrim(p->>'tipo'), ''), 'percentual'); v_val numeric := _num(p->>'valor');
begin
  if v_cod !~ '^[A-Z0-9_-]{3,40}$' then erro := 'Código inválido. Use letras, números, _ ou -.'; return; end if;
  if btrim(coalesce(p->>'nome', '')) = '' then erro := 'Informe o nome da promoção.'; return; end if;
  if v_tipo <> all (array['percentual','fixo','frete','progressivo']) then erro := 'Tipo de cupom inválido.'; return; end if;
  if v_tipo = 'progressivo' then
    if jsonb_typeof(p->'faixas') <> 'array' or jsonb_array_length(p->'faixas') = 0 then erro := 'Informe ao menos uma faixa de desconto.'; return; end if;
    if jsonb_array_length(p->'faixas') > 10 then erro := 'No máximo 10 faixas.'; return; end if;
    for f in select _num(x->>'minimo') mn, _num(x->>'desconto') ds from jsonb_array_elements(p->'faixas') x order by 1 loop
      v_n := v_n + 1;
      if f.mn <= 0 or f.ds <= 0 then erro := 'Cada faixa precisa de pedido mínimo e desconto maiores que zero.'; return; end if;
      if f.ds >= f.mn then erro := 'O desconto de uma faixa tem que ser menor que o pedido mínimo dela.'; return; end if;
      if f.mn = v_ant then erro := 'Há duas faixas com o mesmo pedido mínimo.'; return; end if;
      v_ant := f.mn;
      v_fx := v_fx || jsonb_build_array(jsonb_build_object('minimo', round(f.mn, 2), 'desconto', round(f.ds, 2)));
    end loop;
    v_val := 0;
  elsif v_tipo <> 'frete' and v_val <= 0 then erro := 'Valor do benefício inválido.'; return; end if;
  if v_tipo = 'percentual' and v_val > 100 then erro := 'Percentual não pode ultrapassar 100%.'; return; end if;
  if exists (select 1 from cupons where codigo = v_cod and id is distinct from p_id) then erro := 'Já existe um cupom com esse código.'; return; end if;
  c.codigo := v_cod; c.nome := left(btrim(p->>'nome'), 80); c.tipo := v_tipo; c.valor := case when v_tipo = 'frete' then greatest(0, v_val) else round(v_val, 2) end; c.faixas := v_fx;
  c.frete_gratis := coalesce(p->>'freteGratis', '') in ('true', 't', 'Sim');
  c.data_inicio := _data_iso(btrim(coalesce(p->>'dataInicio', ''))); c.data_fim := _data_iso(btrim(coalesce(p->>'dataFim', '')));
  c.hora_inicio := _hora_valida(p->>'horaInicio'); c.hora_fim := _hora_valida(p->>'horaFim');
  c.limite_total := greatest(0, floor(_num(p->>'limiteTotal'))::int); c.limite_por_cliente := greatest(0, floor(_num(p->>'limitePorCliente'))::int);
  c.valor_minimo := greatest(0, round(_num(p->>'valorMinimo'), 2));
  c.ativa := coalesce(p->>'ativa', '') not in ('false', 'f', 'Não'); c.acumula := coalesce(p->>'acumula', '') in ('true', 't', 'Sim');
end $function$
;

CREATE OR REPLACE FUNCTION public._cupom_calcular(p_codigo text, p_tel text, p_subtotal numeric, p_tipo text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c cupons%rowtype; v_cod text := upper(regexp_replace(btrim(coalesce(p_codigo, '')), '\s+', '', 'g'));
  v_tel text := _so_digitos(p_tel); v_bruto numeric := round(coalesce(p_subtotal, 0), 2); v_desc numeric := 0;
  v_agora timestamp := now() at time zone 'America/Sao_Paulo'; v_hh int; v_hi int; v_hf int; v_usos int; v_usos_cli int; v_fx record;
begin
  if v_cod = '' then return _falha('Informe um cupom.'); end if;
  select * into c from cupons where codigo = v_cod and ativa;
  if not found then return _falha('Cupom inválido ou inativo.'); end if;
  if (c.data_inicio is not null and v_agora::date < c.data_inicio) or (c.data_fim is not null and v_agora::date > c.data_fim) then
    return _falha('Este cupom está fora do período de validade.');
  end if;
  if c.hora_inicio is not null and c.hora_fim is not null then
    v_hh := extract(hour from v_agora)::int * 60 + extract(minute from v_agora)::int;
    v_hi := extract(hour from c.hora_inicio)::int * 60 + extract(minute from c.hora_inicio)::int;
    v_hf := extract(hour from c.hora_fim)::int * 60 + extract(minute from c.hora_fim)::int;
    if v_hi <= v_hf then
      if v_hh < v_hi or v_hh > v_hf then return _falha('Este cupom está fora do período de validade.'); end if;
    else
      if v_hh < v_hi and v_hh > v_hf then return _falha('Este cupom está fora do período de validade.'); end if;
    end if;
  end if;
  select count(*), count(*) filter (where v_tel <> '' and _so_digitos(telefone) = v_tel) into v_usos, v_usos_cli from cupons_usos where cupom_id = c.id;
  if c.limite_total > 0 and v_usos >= c.limite_total then return _falha('O limite de utilizações deste cupom foi atingido.'); end if;
  if c.limite_por_cliente > 0 and v_usos_cli >= c.limite_por_cliente then return _falha('Você já atingiu o limite de uso deste cupom.'); end if;
  if v_bruto < c.valor_minimo then return _falha('Este cupom exige pedido mínimo de R$ ' || replace(_dinheiro(c.valor_minimo), '.', ',') || '.'); end if;
  if c.tipo = 'percentual' then
    if c.valor <= 0 or c.valor > 100 then return _falha('Cupom configurado com percentual inválido.'); end if;
    v_desc := round(v_bruto * c.valor / 100, 2);
  elsif c.tipo = 'fixo' then
    if c.valor <= 0 then return _falha('Cupom configurado com valor inválido.'); end if;
    v_desc := least(v_bruto, round(c.valor, 2));
  elsif c.tipo = 'progressivo' then
    select (x->>'minimo')::numeric mn, (x->>'desconto')::numeric ds into v_fx from jsonb_array_elements(c.faixas) x where (x->>'minimo')::numeric <= v_bruto order by (x->>'minimo')::numeric desc limit 1;
    if v_fx.mn is null then
      select min((x->>'minimo')::numeric) into v_fx.mn from jsonb_array_elements(c.faixas) x;
      return _falha('Este cupom vale a partir de R$ ' || replace(_dinheiro(coalesce(v_fx.mn, 0)), '.', ',') || ' em pedidos.');
    end if;
    v_desc := least(v_bruto, round(v_fx.ds, 2));
  elsif c.tipo = 'frete' then
    v_desc := 0;
  else
    return _falha('Tipo de cupom não suportado.');
  end if;
  v_desc := round(least(v_desc, greatest(0, v_bruto - 0.01)), 2);
  return jsonb_build_object('ok', true, 'cupomId', c.id, 'codigo', c.codigo, 'nome', c.nome, 'tipo', c.tipo, 'desconto', v_desc,
    'freteGratis', (c.frete_gratis or c.tipo = 'frete'), 'acumula', c.acumula,
    'limiteRestante', case when c.limite_total > 0 then greatest(0, c.limite_total - v_usos - 1) else null end);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_salvar_cupom(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v record;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into v from _cupom_validar(p, null);
  if v.erro is not null then return _falha(v.erro); end if;
  insert into cupons (codigo, nome, tipo, valor, frete_gratis, data_inicio, data_fim, hora_inicio, hora_fim, limite_total, limite_por_cliente, valor_minimo, ativa, acumula, faixas, criado_por)
  values ((v.c).codigo, (v.c).nome, (v.c).tipo, (v.c).valor, (v.c).frete_gratis, (v.c).data_inicio, (v.c).data_fim, (v.c).hora_inicio, (v.c).hora_fim, (v.c).limite_total, (v.c).limite_por_cliente, (v.c).valor_minimo, (v.c).ativa, (v.c).acumula, (v.c).faixas, auth.uid());
  perform _auditar('Cupom criado', (v.c).codigo, (v.c).nome || ' | benefício ' || (v.c).tipo || ' ' || (v.c).valor);
  return jsonb_build_object('ok', true, 'message', 'Cupom criado.');
end $function$
;

CREATE OR REPLACE FUNCTION public.api_editar_cupom(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v record; v_id uuid := _uuid(p->>'id');
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_id is null or not exists (select 1 from cupons where id = v_id) then return _falha('Cupom não encontrado.'); end if;
  if _versao_conflita(p, 'cupons', v_id) then return _conflito('Este registro foi alterado por outra pessoa enquanto você editava. A tela foi atualizada — confira e edite de novo.'); end if;
  select * into v from _cupom_validar(p, v_id);
  if v.erro is not null then return _falha(v.erro); end if;
  update cupons set codigo = (v.c).codigo, nome = (v.c).nome, tipo = (v.c).tipo, valor = (v.c).valor, frete_gratis = (v.c).frete_gratis,
         data_inicio = (v.c).data_inicio, data_fim = (v.c).data_fim, hora_inicio = (v.c).hora_inicio, hora_fim = (v.c).hora_fim,
         limite_total = (v.c).limite_total, limite_por_cliente = (v.c).limite_por_cliente, valor_minimo = (v.c).valor_minimo, ativa = (v.c).ativa, acumula = (v.c).acumula, faixas = (v.c).faixas
   where id = v_id;
  perform _auditar('Cupom alterado', (v.c).codigo, (v.c).nome);
  return jsonb_build_object('ok', true, 'message', 'Cupom atualizado.');
end $function$
;

