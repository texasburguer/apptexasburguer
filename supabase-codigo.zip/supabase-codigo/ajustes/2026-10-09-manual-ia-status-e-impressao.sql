-- Atualiza o manual da IA (ai_ajuda) para o texto novo: o servidor principal agora é o Supabase. Usa o slug (não o id), então vale também num banco recriado.
update ai_ajuda set
 passos = replace(replace(replace(replace(replace(replace(replace(replace(replace(passos,
 '🟠 Contingência = a planilha principal está fora do ar.','🟠 Contingência = o servidor está lento ou fora do ar e o app usa a reserva. Toque na bolinha colorida do topo para ver o estado do Supabase, da planilha principal e da contingência.'),
 'Sem conexão com a planilha','Sem conexão com o servidor'),
 'Quando o sistema não consegue falar com a planilha,','Quando o sistema não consegue falar com o servidor (Supabase),'),
 'Quando o sistema não conseguir falar com a planilha,','Quando o sistema não conseguir falar com o servidor (Supabase),'),
 'Um vigia testa a planilha a cada 30 s. Assim que ela responde','Um vigia testa o servidor a cada 30 s. Assim que ele responde'),
 'Quando a planilha voltar,','Quando o servidor voltar,'),
 'Contingência segura o cardápio se a planilha principal cair. Modo reserva segura o app quando o Supabase cai.','O Supabase é o servidor principal; a planilha principal é a reserva e a planilha de contingência é o último recurso. Se o Supabase cai, o modo reserva segura o app e a contingência segura o cardápio e as vendas.'),
 'Se a planilha principal ficou fora do ar e houve vendas na contingência','Se o Supabase ficou fora do ar e houve vendas na contingência'),
 'Ela entra na planilha sozinha quando voltar','Ela entra no sistema sozinha quando o servidor voltar'),
 titulo = replace(titulo,'Modo emergência (planilha fora do ar)','Modo emergência (servidor fora do ar)')
where slug in ('internet-caiu', 'contingencia-admin', 'man-admin-01-entrar-sair-e-status', 'man-admin-15-contingencia-plano-b', 'man-operador-01-entrar-sair-e-status', 'man-garcom-01-entrar-sair-e-status', 'man-cozinha-01-entrar-sair-e-status', 'err-cozinha-01-a-internet-caiu', 'man-entregador-01-entrar-sair-e-status', 'man-operador-11-modo-emergencia-planilha-fora-do-ar', 'man-admin-08-modo-emergencia-planilha-fora-do-ar', 'man-admin-09-contingencia-e-modo-reserva', 'man-admin-09-modo-emergencia-planilha-fora-do-ar', 'man-admin-10-contingencia-e-modo-reserva');

-- ===== Impressão da comanda (Cozinha): não pergunta mais "Saiu no papel?" =====
update ai_ajuda set passos = E'Depois de mandar imprimir, fica um botão discreto "🔁 Não saiu? Reimprimir" por 10 minutos. Se saiu certo, ninguém precisa confirmar nada.\n🔁 Não saiu? Reimprimir: o sistema tira o pedido de "impressos" e manda de novo.\n✖ Saiu, ocultar: esconde o botão.'
where slug = 'man-cozinha-03-confirmar-impressao-da-comanda';

update ai_ajuda set passos = E'O botão "🔁 Não saiu? Reimprimir" fica visível por 10 minutos depois de imprimir. Se a comanda não saiu, toque nele. Se saiu certo, não precisa fazer nada.'
where slug = 'err-cozinha-04-nao-sei-se-a-comanda-saiu';

-- ===== Operador e Admin: entregador automático (só um entregador ativo) e impressão =====
update ai_ajuda set passos = passos || E'\nCom só um entregador ativo, toda entrega já fica no nome dele. Com mais de um, escolha no campo "Entregador".\nDepois de imprimir a comanda, fica um botão "🔁 Não saiu? Reimprimir" por 10 minutos; não precisa confirmar quando saiu certo.'
where slug in ('man-admin-09-pedidos-e-entregas', 'man-operador-05-pedidos-e-entregas') and passos not like '%Não saiu? Reimprimir%';

update ai_ajuda set passos = passos || E'\nCom só um entregador ativo, toda entrega já fica no nome dele. Com mais de um, escolha no campo "Entregador".'
where slug = 'pedidos-aceitar-entregas' and passos not like '%só um entregador ativo%';
