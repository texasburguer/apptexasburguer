-- =====================================================================
-- TEXAS BURGER — SUBIR-TUDO-supabase.sql · 2026-10-11
-- UM ÚNICO arquivo com tudo que é novo no banco (Fases 0 a 6):
--   0 base (interruptores, cofre de chaves, IAs extras NVIDIA/Cloudflare, Saúde, ajuda)
--   1 iFood núcleo · 2 iFood operação · 3 iFood inteligência
--   4 Nota fiscal: cadastro · 5 NFC-e: emissão · 6 NFC-e: fechamento
-- COMO USAR: Supabase > SQL Editor > cole TUDO > Run. Pode rodar mais de uma vez (é idempotente).
-- Tudo roda numa transação só: se algo falhar, NADA é aplicado (o erro mostra onde).
-- TUDO NASCE DESLIGADO: com os interruptores desligados o sistema fica idêntico ao de hoje.
-- Depois deste arquivo: publicar as funções (ifood-sync, nfce-emitir e as 4 de IA) e só então subir index.html + sw.js.
-- =====================================================================
begin;

-- ################ PARTE: f0-base ################
-- =====================================================================
-- FASE 0 — BASE · 2026-10-11
-- 1) Interruptores das integrações (iFood e Nota fiscal): tudo nasce DESLIGADO.
-- 2) Chaves/segredos das integrações (guardados no banco, sem policy: só funções seguras leem).
-- 3) IAs extras (NVIDIA NIM e Cloudflare Workers AI) em "Contas e acessos": sem chave = nada muda (Gemini/Groq como hoje).
-- 4) Saúde do sistema: ponto de extensão _saude_integracoes() (iFood/Nota/IAs extras só aparecem quando ligados/cadastrados).
-- Seguro para rodar de novo (create or replace / if not exists / on conflict).
-- =====================================================================

-- ---------- 3a) IAs extras: permitir as novas chaves e guardar preferências ----------
alter table public.ai_segredos drop constraint if exists ai_segredos_provedor_check;
alter table public.ai_segredos add constraint ai_segredos_provedor_check
  check (provedor = any (array['gemini','groq','nvidia','cloudflare','cloudflare_conta']));
alter table public.ai_config add column if not exists extras_publico boolean not null default false;   -- usar NVIDIA/Cloudflare também no atendimento ao cliente? (padrão: NÃO)
alter table public.ai_config add column if not exists modelo_nvidia text not null default 'meta/llama-3.3-70b-instruct';
alter table public.ai_config add column if not exists modelo_cloudflare text not null default '@cf/meta/llama-3.3-70b-instruct-fp8-fast';

-- "descansando": mesma regra do circuit breaker das funções (3+ erros em 5 min sem sucesso depois)
create or replace function public._ia_provedor_descansando(p_prov text) returns boolean
 language sql stable security definer set search_path to 'public' as $f$
  with l as (select status, row_number() over (order by criado_em desc) rn from ai_log where provedor = p_prov and criado_em > now() - interval '5 minutes'),
       u as (select coalesce(min(rn), 1000) as rn_ok from l where status = 'ok')
  select (select count(*) from l, u where l.status = 'erro' and l.rn < u.rn_ok) >= 3
$f$;

create or replace function public.api_listar_chaves_ia(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'extrasPublico', coalesce((select extras_publico from ai_config limit 1), false),
    'chaves', coalesce((select jsonb_agg(jsonb_build_object('provedor', v.prov,
           'temChave', length(coalesce(s.chave, '')) > 0 and (v.prov <> 'cloudflare' or length(coalesce(c.chave, '')) > 0),
           'final', case when length(coalesce(s.chave, '')) > 8 then right(s.chave, 4) else '' end,
           'temConta', length(coalesce(c.chave, '')) > 0,
           'descansando', _ia_provedor_descansando(v.prov),
           'atualizadoEm', s.atualizado_em) order by v.ordem)
         from (values ('gemini', 1), ('groq', 2), ('nvidia', 3), ('cloudflare', 4)) v(prov, ordem)
         left join ai_segredos s on s.provedor = v.prov
         left join ai_segredos c on c.provedor = 'cloudflare_conta' and v.prov = 'cloudflare'), '[]'::jsonb));
end $f$;

create or replace function public.api_ver_chave_ia(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare v text; v_conta text; v_prov text := lower(coalesce(p->>'provedor', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_prov not in ('gemini', 'groq', 'nvidia', 'cloudflare') then return _falha('IA desconhecida.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  select chave into v from ai_segredos where provedor = v_prov;
  if coalesce(v, '') = '' then return _falha('Esta IA não tem chave guardada.'); end if;
  select chave into v_conta from ai_segredos where provedor = 'cloudflare_conta' and v_prov = 'cloudflare';
  perform _auditar('Chave de IA visualizada', v_prov);
  return jsonb_build_object('ok', true, 'chave', v) || case when v_prov = 'cloudflare' then jsonb_build_object('contaId', coalesce(v_conta, '')) else '{}'::jsonb end;
end $f$;

create or replace function public.api_salvar_chave_ia(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text := lower(coalesce(p->>'provedor', '')); v_chave text := btrim(coalesce(p->>'chave', '')); v_conta text := lower(btrim(coalesce(p->>'contaId', '')));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_prov not in ('gemini', 'groq', 'nvidia', 'cloudflare') then return _falha('IA desconhecida.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  if length(v_chave) < 20 or length(v_chave) > 300 or v_chave ~ '\s' then return _falha('Chave inválida. Copie a chave inteira, sem espaços.'); end if;
  if v_prov = 'cloudflare' then
    if v_conta = '' and not exists (select 1 from ai_segredos where provedor = 'cloudflare_conta') then return _falha('Informe também o Account ID da Cloudflare.'); end if;
    if v_conta <> '' and v_conta !~ '^[0-9a-f]{32}$' then return _falha('Account ID inválido: são 32 letras e números (copie na tela "Use REST API" do Workers AI).'); end if;
    if v_conta <> '' then
      insert into ai_segredos (provedor, chave, atualizado_em) values ('cloudflare_conta', v_conta, now())
        on conflict (provedor) do update set chave = excluded.chave, atualizado_em = now();
    end if;
  end if;
  insert into ai_segredos (provedor, chave, atualizado_em) values (v_prov, v_chave, now())
    on conflict (provedor) do update set chave = excluded.chave, atualizado_em = now();
  perform _auditar('Chave de IA trocada', v_prov);
  return jsonb_build_object('ok', true, 'message', 'Chave salva. Os assistentes já usam a nova.') || api_listar_chaves_ia('{}');
end $f$;

-- usar as IAs extras também no atendimento público do cardápio? (padrão NÃO: confirmar antes os termos de privacidade do provedor)
create or replace function public.api_salvar_ia_extras(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  update ai_config set extras_publico = coalesce((p->>'publico')::boolean, false), atualizado_em = now() where id;
  perform _auditar('IAs extras no atendimento público', case when coalesce((p->>'publico')::boolean, false) then 'ligado' else 'desligado' end);
  return jsonb_build_object('ok', true, 'message', case when coalesce((p->>'publico')::boolean, false) then 'As IAs extras também atendem os clientes do cardápio.' else 'As IAs extras ficam só no uso interno.' end) || api_listar_chaves_ia('{}');
end $f$;

-- ---------- 1) Interruptores das integrações ----------
create table if not exists public.integracoes_config (
  provedor text primary key check (provedor in ('ifood', 'nfce')),
  ligado boolean not null default false,
  modo text not null default 'homologacao' check (modo in ('homologacao', 'producao')),
  ligado_em timestamptz,
  ligado_por text,
  checklist jsonb not null default '{}'::jsonb,
  config jsonb not null default '{}'::jsonb,          -- ajustes sem segredo (ex.: confirmação automática)
  atualizado_em timestamptz not null default now()
);
alter table public.integracoes_config enable row level security;
insert into public.integracoes_config (provedor, modo, config) values
  ('ifood', 'producao', '{"confirmacaoAutomatica": true, "baixaEstoque": "confirmacao", "abrirFecharComCaixa": true, "pausarSemEstoque": true, "retencaoClientesDias": 90}'::jsonb),
  ('nfce', 'homologacao', '{"canais": ["balcao"], "emitirQuando": "pagamento"}'::jsonb)
on conflict (provedor) do nothing;

create table if not exists public.integracoes_segredos (
  chave text primary key check (chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id', 'nfce_token_homologacao', 'nfce_token_producao')),
  valor text not null,
  atualizado_em timestamptz not null default now()
);
alter table public.integracoes_segredos enable row level security;   -- sem policy: só funções seguras (security definer) e a chave de serviço leem

create table if not exists public.integracoes_log (
  id bigserial primary key,
  criado_em timestamptz not null default now(),
  provedor text not null,
  nivel text not null default 'info' check (nivel in ('info', 'aviso', 'erro')),
  mensagem text not null,
  detalhe jsonb
);
create index if not exists integracoes_log_prov_idx on public.integracoes_log (provedor, criado_em desc);
alter table public.integracoes_log enable row level security;

create or replace function public._integ_log(p_prov text, p_nivel text, p_msg text, p_det jsonb default null) returns void
 language sql security definer set search_path to 'public' as $f$
  insert into integracoes_log (provedor, nivel, mensagem, detalhe) values (p_prov, p_nivel, left(p_msg, 300), p_det)
$f$;

-- só o usuário Desenvolvedor (auth_nivel() trata o Desenvolvedor como Admin, então tem_nivel('Desenvolvedor') nunca é verdadeiro)
create or replace function public._eh_dev() returns boolean
 language sql stable security definer set search_path to 'public' as $f$
  select exists (select 1 from usuarios where id = auth.uid() and ativo and nivel::text = 'Desenvolvedor')
$f$;

create or replace function public._integracao_ligada(p_prov text) returns boolean
 language sql stable security definer set search_path to 'public' as $f$
  select coalesce((select ligado from integracoes_config where provedor = p_prov), false)
$f$;

-- passos do checklist (o texto aparece na tela). auto = o sistema marca sozinho.
create or replace function public._integ_checklist_def(p_prov text) returns jsonb
 language sql immutable as $f$
  select case p_prov
    when 'ifood' then '[
      {"id":"conta_dev","titulo":"O dono criou a conta de desenvolvedor no iFood (precisa do CNPJ)"},
      {"id":"acesso","titulo":"Acesso liberado aos módulos Pedidos, Catálogo, Loja, Financeiro e Avaliações"},
      {"id":"chaves","titulo":"Client ID, Client Secret e código da loja digitados aqui","auto":true},
      {"id":"teste_conexao","titulo":"Teste de conexão deu certo","auto":true},
      {"id":"homologacao","titulo":"Homologação do iFood aprovada"},
      {"id":"itens","titulo":"Itens do iFood ligados aos produtos (aba Itens do iFood)"},
      {"id":"equipe","titulo":"Equipe avisada de como o pedido do iFood aparece"}]'::jsonb
    when 'nfce' then '[
      {"id":"contador","titulo":"O contador definiu NCM, CFOP e situação tributária de cada perfil"},
      {"id":"certificado","titulo":"Certificado digital A1 do restaurante pronto"},
      {"id":"sefaz","titulo":"Credenciamento na Sefaz-SP feito e CSC (código de segurança) obtido"},
      {"id":"focus","titulo":"Conta na Focus NFe criada e empresa cadastrada lá (com o certificado)"},
      {"id":"token","titulo":"Token da Focus digitado aqui","auto":true},
      {"id":"empresa","titulo":"Dados fiscais da empresa preenchidos aqui","auto":true},
      {"id":"perfis","titulo":"Todos os produtos têm perfil fiscal","auto":true},
      {"id":"nota_teste","titulo":"Nota de teste (homologação) emitida e conferida pelo contador"}]'::jsonb
    else '[]'::jsonb end
$f$;

-- pendências para ligar (lista de textos). Fases seguintes substituem esta função para acrescentar verificações.
create or replace function public._integ_pendencias(p_prov text, p_modo text) returns text[]
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_out text[] := '{}'; v_item jsonb; v_ck jsonb; v_ok boolean;
begin
  select checklist into v_ck from integracoes_config where provedor = p_prov;
  for v_item in select * from jsonb_array_elements(_integ_checklist_def(p_prov)) loop
    if coalesce((v_item->>'auto')::boolean, false) then
      v_ok := case v_item->>'id'
        when 'chaves' then (select count(*) from integracoes_segredos where chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id')) = 3
        when 'token' then exists (select 1 from integracoes_segredos where chave = 'nfce_token_' || p_modo)
        else coalesce((v_ck->>(v_item->>'id'))::boolean, false) end;
    else
      v_ok := coalesce((v_ck->>(v_item->>'id'))::boolean, false);
    end if;
    if not v_ok then v_out := v_out || (v_item->>'titulo'); end if;
  end loop;
  return v_out;
end $f$;

create or replace function public.api_integracoes_flags(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if auth_nivel() is null then return _negado(); end if;
  return jsonb_build_object('ok', true, 'ifood', _integracao_ligada('ifood'), 'nfce', _integracao_ligada('nfce'),
    'nfceModo', (select modo from integracoes_config where provedor = 'nfce'));
end $f$;

create or replace function public.api_integracoes_status(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_modo text; v_def jsonb; v_it jsonb; v_pend text[];
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  for r in select * from integracoes_config order by provedor loop
    v_def := _integ_checklist_def(r.provedor); v_pend := _integ_pendencias(r.provedor, r.modo);
    v := v || jsonb_build_object('provedor', r.provedor, 'ligado', r.ligado, 'modo', r.modo, 'ligadoEm', r.ligado_em, 'config', r.config,
      'checklist', (select coalesce(jsonb_agg(jsonb_build_object('id', x->>'id', 'titulo', x->>'titulo', 'auto', coalesce((x->>'auto')::boolean, false),
          'feito', not ((x->>'titulo') = any (v_pend))) ), '[]'::jsonb) from jsonb_array_elements(v_def) x),
      'pendencias', to_jsonb(v_pend), 'podeLigar', coalesce(array_length(v_pend, 1), 0) = 0,
      'segredos', (select coalesce(jsonb_object_agg(s.chave, jsonb_build_object('tem', true, 'final', case when length(s.valor) > 8 then right(s.valor, 4) else '' end, 'em', s.atualizado_em)), '{}'::jsonb)
                    from integracoes_segredos s where (r.provedor = 'ifood' and s.chave like 'ifood\_%') or (r.provedor = 'nfce' and s.chave like 'nfce\_%')));
  end loop;
  return jsonb_build_object('ok', true, 'integracoes', v);
end $f$;

create or replace function public.api_integracoes_marcar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text := p->>'provedor'; v_item text := p->>'item'; v_feito boolean := coalesce((p->>'feito')::boolean, false);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not exists (select 1 from jsonb_array_elements(_integ_checklist_def(v_prov)) x where x->>'id' = v_item and not coalesce((x->>'auto')::boolean, false)) then return _falha('Passo inválido.'); end if;
  update integracoes_config set checklist = jsonb_set(checklist, array[v_item], to_jsonb(v_feito), true), atualizado_em = now() where provedor = v_prov;
  perform _auditar('Integração: passo marcado', v_prov || ' · ' || v_item || ' · ' || v_feito::text);
  return api_integracoes_status('{}');
end $f$;

create or replace function public.api_integracoes_config(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text := p->>'provedor'; v_cfg jsonb := coalesce(p->'config', '{}'::jsonb); v_atual jsonb; v_chave text; v_novo jsonb := '{}'::jsonb;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_prov not in ('ifood', 'nfce') then return _falha('Integração inválida.'); end if;
  select config into v_atual from integracoes_config where provedor = v_prov;
  -- só chaves conhecidas, com valores simples
  for v_chave in select jsonb_object_keys(v_cfg) loop
    if v_prov = 'ifood' and v_chave in ('confirmacaoAutomatica', 'abrirFecharComCaixa', 'pausarSemEstoque', 'enviarPrecos') then v_novo := v_novo || jsonb_build_object(v_chave, coalesce((v_cfg->>v_chave)::boolean, false));
    elsif v_prov = 'ifood' and v_chave = 'baixaEstoque' and (v_cfg->>v_chave) in ('confirmacao', 'entrega') then v_novo := v_novo || jsonb_build_object(v_chave, v_cfg->>v_chave);
    elsif v_prov = 'ifood' and v_chave = 'retencaoClientesDias' and (v_cfg->>v_chave)::int between 7 and 365 then v_novo := v_novo || jsonb_build_object(v_chave, (v_cfg->>v_chave)::int);
    elsif v_prov = 'ifood' and v_chave = 'limitePrecoPct' and (v_cfg->>v_chave)::numeric between 0 and 100 then v_novo := v_novo || jsonb_build_object(v_chave, (v_cfg->>v_chave)::numeric);
    elsif v_prov = 'nfce' and v_chave = 'emitirQuando' and (v_cfg->>v_chave) in ('pagamento', 'entrega') then v_novo := v_novo || jsonb_build_object(v_chave, v_cfg->>v_chave);
    elsif v_prov = 'nfce' and v_chave = 'canais' and jsonb_typeof(v_cfg->v_chave) = 'array' then v_novo := v_novo || jsonb_build_object(v_chave, (select coalesce(jsonb_agg(c), '[]'::jsonb) from jsonb_array_elements_text(v_cfg->v_chave) c where c in ('balcao', 'cardapio', 'ifood', 'mesa')));
    end if;
  end loop;
  update integracoes_config set config = v_atual || v_novo, atualizado_em = now() where provedor = v_prov;
  perform _auditar('Integração: ajustes salvos', v_prov);
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Ajustes salvos.');
end $f$;

create or replace function public.api_integracoes_salvar_segredo(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_chave text := p->>'chave'; v_valor text := btrim(coalesce(p->>'valor', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_chave not in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id', 'nfce_token_homologacao', 'nfce_token_producao') then return _falha('Campo desconhecido.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  if length(v_valor) < 8 or length(v_valor) > 400 or v_valor ~ '\s' then return _falha('Valor inválido. Copie inteiro, sem espaços.'); end if;
  insert into integracoes_segredos (chave, valor, atualizado_em) values (v_chave, v_valor, now())
    on conflict (chave) do update set valor = excluded.valor, atualizado_em = now();
  perform _auditar('Integração: chave salva', v_chave);
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Salvo.');
end $f$;

create or replace function public.api_integracoes_ver_segredo(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  select valor into v from integracoes_segredos where chave = p->>'chave';
  if v is null then return _falha('Nada guardado neste campo.'); end if;
  perform _auditar('Integração: chave visualizada', p->>'chave');
  return jsonb_build_object('ok', true, 'valor', v);
end $f$;

create or replace function public.api_integracoes_ligar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text := p->>'provedor'; v_modo text := coalesce(p->>'modo', 'producao'); v_pend text[]; v_uid text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_prov not in ('ifood', 'nfce') then return _falha('Integração inválida.'); end if;
  if v_prov = 'nfce' and v_modo not in ('homologacao', 'producao') then return _falha('Escolha o ambiente: teste (homologação) ou produção.'); end if;
  if v_prov = 'ifood' then v_modo := 'producao'; end if;
  v_uid := _exige_admin(p->>'senhaAdmin');
  if coalesce(p->>'senhaAdmin', '') = '' or v_uid is null then return _falha('Senha de administrador incorreta.'); end if;
  v_pend := _integ_pendencias(v_prov, v_modo);
  if coalesce(array_length(v_pend, 1), 0) > 0 then return _falha('Ainda faltam passos: ' || array_to_string(v_pend, '; ')); end if;
  update integracoes_config set ligado = true, modo = v_modo, ligado_em = now(), ligado_por = v_uid, atualizado_em = now() where provedor = v_prov;
  perform _auditar('Integração LIGADA', v_prov || ' · ' || v_modo);
  perform _integ_log(v_prov, 'info', 'Integração ligada (' || v_modo || ')');
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Ligado.');
end $f$;

create or replace function public.api_integracoes_desligar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if p->>'provedor' not in ('ifood', 'nfce') then return _falha('Integração inválida.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' or _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  update integracoes_config set ligado = false, atualizado_em = now() where provedor = p->>'provedor';
  perform _auditar('Integração DESLIGADA', p->>'provedor');
  perform _integ_log(p->>'provedor', 'aviso', 'Integração desligada');
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Desligado. O sistema voltou a funcionar como antes.');
end $f$;

create or replace function public.api_integracoes_log(p jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'itens', coalesce((select jsonb_agg(jsonb_build_object('em', to_char(criado_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI:SS'), 'nivel', nivel, 'texto', mensagem) order by criado_em desc)
     from (select * from integracoes_log where provedor = p->>'provedor' order by criado_em desc limit 60) x), '[]'::jsonb));
end $f$;

-- limpeza do log (30 dias)
create or replace function public._integracoes_limpar() returns void
 language sql security definer set search_path to 'public' as $f$
  delete from integracoes_log where criado_em < now() - interval '30 days'
$f$;

-- ---------- 4) Saúde: integrações + IAs extras (só aparecem quando ligadas/cadastradas) ----------
create or replace function public._saude_integracoes() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_txt text; v_desc int;
begin
  -- IAs extras: só se tiver chave
  if exists (select 1 from ai_segredos where provedor = 'nvidia') or exists (select 1 from ai_segredos where provedor = 'cloudflare') then
    select count(*) into v_desc from unnest(array['nvidia', 'cloudflare']) x(p) where _ia_provedor_descansando(x.p);
    v := v || jsonb_build_object('id', 'ia_extras', 'titulo', 'IAs de reserva (NVIDIA / Cloudflare)',
      'nivel', case when v_desc > 0 then 'atencao' else 'ok' end,
      'texto', (select string_agg(x.rot || ': ' || case when not exists (select 1 from ai_segredos where provedor = x.p) then 'sem chave' when _ia_provedor_descansando(x.p) then 'descansando (erros recentes)' else 'pronta' end, ' · ')
                from (values ('nvidia', 'NVIDIA'), ('cloudflare', 'Cloudflare')) x(p, rot)));
  end if;
  for r in select * from integracoes_config where ligado loop
    v_txt := case r.provedor when 'ifood' then 'Ligado, aguardando a primeira consulta ao iFood.' else 'Ligada (' || r.modo || '), aguardando a primeira nota.' end;
    v := v || jsonb_build_object('id', r.provedor, 'titulo', case r.provedor when 'ifood' then 'iFood' else 'Nota fiscal (NFC-e)' end, 'nivel', 'atencao', 'texto', v_txt);
  end loop;
  return v;
end $f$;

create or replace function public.api_saude_sistema(p jsonb DEFAULT '{}'::jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public', 'cron' as $function$
declare itens jsonb := '[]'::jsonb; v_n int; v_min numeric; v_b record; v_i record; v_c int; v_ia int; v_ult timestamptz; v_pior text := 'ok';
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  -- 1) fila de sincronização com as planilhas
  select count(*), coalesce(extract(epoch from (now() - min(criado_em))) / 60, 0) into v_n, v_min from fila_sync where principal_ok_em is null;
  itens := itens || jsonb_build_object('id', 'fila', 'titulo', 'Cópia para a planilha de reserva',
    'nivel', case when v_n = 0 then 'ok' when v_min < 30 then 'atencao' else 'problema' end,
    'texto', case when v_n = 0 then 'Tudo copiado.' else v_n || ' item(ns) esperando; o mais antigo há ' || round(v_min) || ' min.' end);
  -- 2) backup automático
  select * into v_b from backups order by data_hora desc limit 1;
  itens := itens || jsonb_build_object('id', 'backup', 'titulo', 'Backup automático',
    'nivel', case when v_b.id is null then 'problema' when v_b.status <> 'Sucesso' then 'problema' when v_b.data_hora < now() - interval '48 hours' then 'problema' when v_b.data_hora < now() - interval '26 hours' then 'atencao' else 'ok' end,
    'texto', case when v_b.id is null then 'Nenhum backup encontrado.' when v_b.status <> 'Sucesso' then 'O último backup falhou: ' || coalesce(left(v_b.erro, 120), 'sem detalhe') else 'Último backup há ' || round(extract(epoch from (now() - v_b.data_hora)) / 3600, 1) || ' h.' end);
  itens := itens || jsonb_build_object('id', 'drive', 'titulo', 'Cópia do backup no Drive',
    'nivel', case when v_b.id is null then 'atencao' when v_b.copia_drive_erro is not null then 'atencao' when v_b.copia_drive_em is null then 'atencao' else 'ok' end,
    'texto', case when v_b.copia_drive_erro is not null then 'Falhou: ' || left(v_b.copia_drive_erro, 120) when v_b.copia_drive_em is null then 'Ainda não copiado.' else 'Copiado no Drive.' end);
  -- 3) conferência Supabase x planilha
  select * into v_i from integridade_checks order by criado_em desc limit 1;
  itens := itens || jsonb_build_object('id', 'integridade', 'titulo', 'Conferência de vendas (diária)',
    'nivel', case when v_i.id is null then 'atencao' when v_i.status <> 'ok' then 'problema' when v_i.criado_em < now() - interval '3 days' then 'atencao' else 'ok' end,
    'texto', case when v_i.id is null then 'Ainda não rodou.' when v_i.status <> 'ok' then 'Conferência do dia ' || to_char((v_i.detalhe->>'data')::date, 'DD/MM') || ' achou diferença: ' || v_i.supabase_vendas || ' vendas no Supabase x ' || v_i.planilha_vendas || ' na planilha.' else 'Conferido o dia ' || to_char((v_i.detalhe->>'data')::date, 'DD/MM') || ': ' || v_i.supabase_vendas || ' vendas no Supabase e ' || v_i.planilha_vendas || ' na planilha.' end);
  -- 4) tarefas automáticas
  select count(*) into v_c from cron.job j where (select d.status from cron.job_run_details d where d.jobid = j.jobid order by d.start_time desc limit 1) = 'failed';
  itens := itens || jsonb_build_object('id', 'tarefas', 'titulo', 'Tarefas automáticas', 'nivel', case when v_c = 0 then 'ok' else 'problema' end,
    'texto', case when v_c = 0 then 'Todas rodaram bem na última vez.' else v_c || ' tarefa(s) falharam na última execução.' end);
  -- 5) IA
  select count(*) into v_ia from ai_log where criado_em > now() - interval '1 hour' and status = 'erro';
  itens := itens || jsonb_build_object('id', 'ia', 'titulo', 'Assistente (IA)', 'nivel', case when v_ia >= 5 then 'atencao' else 'ok' end,
    'texto', case when v_ia >= 5 then v_ia || ' erro(s) na última hora; o sistema segue normal.' else 'Funcionando.' end);
  -- 6) IAs de reserva, iFood e Nota fiscal (só aparecem quando cadastradas/ligadas)
  itens := itens || _saude_integracoes();
  select case when bool_or(x->>'nivel' = 'problema') then 'problema' when bool_or(x->>'nivel' = 'atencao') then 'atencao' else 'ok' end into v_pior from jsonb_array_elements(itens) x;
  return jsonb_build_object('ok', true, 'geral', v_pior, 'itens', itens, 'em', to_char(now() at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI'));
end $function$;

-- ---------- permissões ----------
revoke execute on function public._ia_provedor_descansando(text), public._integ_log(text, text, text, jsonb), public._integracao_ligada(text), public._eh_dev(),
  public._integ_checklist_def(text), public._integ_pendencias(text, text), public._integracoes_limpar(), public._saude_integracoes() from public, anon, authenticated;
revoke execute on function public.api_listar_chaves_ia(jsonb), public.api_ver_chave_ia(jsonb), public.api_salvar_chave_ia(jsonb), public.api_salvar_ia_extras(jsonb),
  public.api_integracoes_flags(jsonb), public.api_integracoes_status(jsonb), public.api_integracoes_marcar(jsonb), public.api_integracoes_config(jsonb),
  public.api_integracoes_salvar_segredo(jsonb), public.api_integracoes_ver_segredo(jsonb), public.api_integracoes_ligar(jsonb), public.api_integracoes_desligar(jsonb),
  public.api_integracoes_log(jsonb) from public, anon;
grant execute on function public.api_listar_chaves_ia(jsonb), public.api_ver_chave_ia(jsonb), public.api_salvar_chave_ia(jsonb), public.api_salvar_ia_extras(jsonb),
  public.api_integracoes_flags(jsonb), public.api_integracoes_status(jsonb), public.api_integracoes_marcar(jsonb), public.api_integracoes_config(jsonb),
  public.api_integracoes_salvar_segredo(jsonb), public.api_integracoes_ver_segredo(jsonb), public.api_integracoes_ligar(jsonb), public.api_integracoes_desligar(jsonb),
  public.api_integracoes_log(jsonb) to authenticated;

-- ---------- Ajuda do assistente ----------
update ai_ajuda set palavras_chave = 'contas acessos email senha link supabase github planilha apps script cofre ver senha chave ia gemini groq nvidia cloudflare reserva',
  passos = E'Administrador → Sistema → Contas e acessos: lista das contas do sistema (Supabase, GitHub, planilhas…) com e-mail, link e observação.\n"+ Nova conta" cadastra; "Editar" muda os dados ou a senha; "Excluir" apaga a conta e a senha guardada.\nA senha fica no cofre criptografado do Supabase. Para ver, toque em "Ver senha" e digite a SUA senha de administrador; ela aparece por 30 segundos e fica registrado na Auditoria.\nChaves das IAs (Gemini, Groq, NVIDIA e Cloudflare): na mesma tela. "Ver chave" e "Trocar chave" pedem a senha de administrador; a chave nova vale na hora. NVIDIA e Cloudflare são IAs de reserva: sem chave, nada muda; com chave, entram quando o Gemini e a Groq falham ou esgotam o limite grátis.'
where slug = 'man-admin-101-contas-e-acessos';
insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-102-integracoes','Integrações: iFood e Nota fiscal','integrações ifood nota fiscal nfce focus ligar desligar interruptor chaves guia checklist',
 E'Administrador → Sistema → Contas e acessos → cartão "Integrações": o iFood e a Nota fiscal já vêm prontos no sistema, mas DESLIGADOS. Desligado, o sistema funciona exatamente como antes.\nCada integração tem um guia passo a passo na própria tela e um checklist. Só dá para ligar quando todos os passos estiverem prontos; ligar pede a senha de administrador.\nAs chaves são digitadas só nesta tela, ficam guardadas com segurança e só aparecem com a sua senha. Nunca envie chaves por mensagem.\nPara desligar, toque em "Desligar" e confirme com a senha: o sistema volta a funcionar como antes, e o que já foi gravado fica guardado.',
 array['Admin'],true,'lista',102,'Só Administrador e Desenvolvedor veem esta tela.'
where not exists (select 1 from ai_ajuda where slug='man-admin-102-integracoes');


-- ################ PARTE: f0-saude-ajuda ################
-- TEXAS BURGER — Ajuda do assistente: a "Saúde do sistema" fica só em "Conexão e servidores" (bolinha do topo) · 2026-10-11
-- Só atualiza o texto de ajuda (ai_ajuda). Pode rodar mais de uma vez. Substitui a versão de 2026-10-10 (saude-ajuda.sql).
update ai_ajuda set
  palavras_chave = 'saúde sistema conexão servidores backup conferência vendas tarefas automáticas bolinha verde vermelha',
  passos = E'A "Saúde do sistema" fica dentro de "Conexão e servidores": toque na bolinha colorida do topo.\nLá aparecem os servidores e, logo abaixo, cada item: cópia para a planilha, backup (diário às 04:00), cópia no Drive, conferência diária de vendas, tarefas automáticas e Assistente.\nA própria bolinha do topo muda de cor: verde = tudo certo, amarela = atenção, rosa = precisa de cuidado (se a conexão cair, ela fica vermelha ou laranja). Amarelo pede atenção; vermelho pede ação (ex.: backup com mais de 48 h ou vendas diferentes entre Supabase e planilha).\nDesenvolvedor: o botão "Simular queda (treino)" fica em "Conexão e servidores" e finge a queda só neste aparelho. "Encerrar simulação" volta ao normal.',
  comuns = 'Só Admin e Desenvolvedor veem a Saúde do sistema.'
where slug = 'man-admin-97-saude-sistema';


-- ################ PARTE: f1-ifood-nucleo ################
-- =====================================================================
-- FASE 1 — iFOOD NÚCLEO · 2026-10-11
-- Receber pedidos do iFood como venda normal, ligar itens do iFood aos produtos, baixa de ingredientes,
-- fila de ações para o iFood (confirmar/preparo/pronto/despachar/cancelar), leitor único, saúde.
-- TUDO DESLIGADO: sem a integração ligada nada acontece (nenhuma chamada externa, nenhuma venda nova).
-- Precisa da Fase 0 (2026-10-11-f0-base.sql) aplicada antes. Seguro para rodar de novo.
-- ⚠️ Os nomes dos campos do pedido do iFood vêm de fontes de terceiros: o código é tolerante e a primeira
--    ligação real pode pedir ajuste fino ("ainda não testado com o iFood de verdade").
-- =====================================================================

-- ---------- colunas novas na venda ----------
alter table public.vendas add column if not exists canal text;     -- 'iFood' para pedidos vindos do iFood (origem continua "Balcão")
create index if not exists vendas_canal_idx on public.vendas (canal) where canal is not null;

-- formas de pagamento técnicas (inativas: não aparecem no Caixa nem no cardápio)
insert into public.formas_pagamento (nome, ativa, visivel_cardapio, taxa_percentual, taxa_fixa, prazo_dias, permite_troco, ordem)
select x.nome, false, false, 0, 0, 0, false, 99 from (values ('iFood (pago no app)'), ('iFood (pagar na entrega)')) x(nome)
where not exists (select 1 from public.formas_pagamento f where lower(f.nome) = lower(x.nome));

-- ---------- tabelas ----------
create table if not exists public.ifood_estado (
  id boolean primary key default true check (id),
  ultima_consulta timestamptz, ultima_consulta_ok timestamptz, ultimo_pedido_em timestamptz,
  token_ok boolean, ultimo_erro text, ultimo_erro_em timestamptz,
  trava_dono text, trava_ate timestamptz,
  atualizado_em timestamptz not null default now());
insert into public.ifood_estado (id) values (true) on conflict (id) do nothing;
alter table public.ifood_estado enable row level security;

create table if not exists public.ifood_token (
  id boolean primary key default true check (id),
  token text, expira_em timestamptz);
insert into public.ifood_token (id) values (true) on conflict (id) do nothing;
alter table public.ifood_token enable row level security;

create table if not exists public.ifood_eventos (
  id text primary key,                      -- id do evento no iFood (único: nunca duplica)
  codigo text, codigo_completo text, pedido_ifood text,
  criado_ifood timestamptz, recebido_em timestamptz not null default now(),
  bruto jsonb, processado_em timestamptz, tentativas int not null default 0, erro text);
create index if not exists ifood_eventos_pend_idx on public.ifood_eventos (recebido_em) where processado_em is null;
alter table public.ifood_eventos enable row level security;

create table if not exists public.ifood_pedidos (
  pedido_ifood text primary key,
  venda_id uuid references public.vendas(id) on delete set null,
  numero_ifood text,
  estado text not null default 'novo' check (estado in ('novo','confirmado','em_preparo','pronto','despachado','concluido','cancelado')),
  confirmado_em timestamptz, expira_em timestamptz,
  itens_sem_ligacao int not null default 0,
  avisos int not null default 0,            -- avisos de "confirme o pedido" já enviados à equipe (4 e 6 min)
  simulado boolean not null default false,
  bruto jsonb, criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now());
create index if not exists ifood_pedidos_venda_idx on public.ifood_pedidos (venda_id);
alter table public.ifood_pedidos enable row level security;

create table if not exists public.ifood_itens (
  chave text primary key,                   -- código externo do item/opção no iFood (ou o id, se não houver código)
  nome text not null, tipo text not null default 'produto' check (tipo in ('produto','opcao')),
  produto_id uuid references public.produtos(id) on delete set null,
  combo_id uuid references public.combos(id) on delete set null,
  adicional_id uuid references public.adicionais(id) on delete set null,
  ignorar boolean not null default false,
  visto_em timestamptz not null default now(), ligado_em timestamptz);
alter table public.ifood_itens enable row level security;

create table if not exists public.ifood_acoes (
  id bigserial primary key,
  pedido_ifood text not null, acao text not null check (acao in ('confirmar','iniciar_preparo','pronto','despachar','cancelar')),
  dados jsonb not null default '{}'::jsonb,
  estado text not null default 'pendente' check (estado in ('pendente','ok','erro','duvida','pulada')),
  tentativas int not null default 0, erro text,
  criado_em timestamptz not null default now(), executado_em timestamptz);
create unique index if not exists ifood_acoes_pend_uk on public.ifood_acoes (pedido_ifood, acao) where estado in ('pendente','duvida');
alter table public.ifood_acoes enable row level security;

-- ---------- utilitários ----------
create or replace function public._ifood_n(j jsonb) returns numeric language plpgsql immutable as $f$
begin
  if j is null then return 0; end if;
  return case jsonb_typeof(j)
    when 'number' then (j #>> '{}')::numeric
    when 'string' then coalesce(nullif(regexp_replace(j #>> '{}', '[^0-9.\-]', '', 'g'), '')::numeric, 0)
    when 'object' then public._ifood_n(coalesce(j->'value', j->'amount'))
    else 0 end;
exception when others then return 0;
end $f$;

create or replace function public._ifood_norm(t text) returns text language sql immutable as $f$
  select regexp_replace(lower(translate(coalesce(t, ''), 'ÁÀÂÃÄáàâãäÉÈÊËéèêëÍÌÎÏíìîïÓÒÔÕÖóòôõöÚÙÛÜúùûüÇç', 'AAAAAaaaaaEEEEeeeeIIIIiiiiOOOOOoooooUUUUuuuuCc')), '[^a-z0-9]', '', 'g')
$f$;

-- sugestão de ligação por nome (só quando há exatamente 1 produto/adicional com o mesmo nome)
create or replace function public._ifood_sugestao(p_nome text, p_tipo text) returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare v_n int; v_id uuid; v_nome text; v_k text := public._ifood_norm(p_nome);
begin
  if length(v_k) < 3 then return null; end if;
  if p_tipo = 'opcao' then
    select count(*), min(id::text)::uuid, min(nome) into v_n, v_id, v_nome from adicionais where ativo and public._ifood_norm(nome) = v_k;
    if v_n = 1 then return jsonb_build_object('tipo', 'adicional', 'id', v_id, 'nome', v_nome); end if;
  end if;
  select count(*), min(id::text)::uuid, min(nome) into v_n, v_id, v_nome from produtos where ativo and public._ifood_norm(nome) = v_k;
  if v_n = 1 then return jsonb_build_object('tipo', 'produto', 'id', v_id, 'nome', v_nome); end if;
  select count(*), min(id::text)::uuid, min(nome) into v_n, v_id, v_nome from combos where ativo and public._ifood_norm(nome) = v_k;
  if v_n = 1 then return jsonb_build_object('tipo', 'combo', 'id', v_id, 'nome', v_nome); end if;
  return null;
end $f$;

-- registra/atualiza um item visto no iFood; liga sozinho SÓ quando o código externo é exatamente o id de um produto/combo/adicional nosso
create or replace function public._ifood_item_visto(p_chave text, p_nome text, p_tipo text) returns public.ifood_itens
 language plpgsql security definer set search_path to 'public' as $f$
declare r ifood_itens%rowtype; v_u uuid;
begin
  insert into ifood_itens (chave, nome, tipo) values (p_chave, left(coalesce(nullif(p_nome, ''), p_chave), 200), p_tipo)
    on conflict (chave) do update set nome = excluded.nome, visto_em = now() returning * into r;
  if r.produto_id is null and r.combo_id is null and r.adicional_id is null and not r.ignorar then
    v_u := case when p_chave ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then p_chave::uuid end;
    if v_u is not null then
      if exists (select 1 from produtos where id = v_u) then update ifood_itens set produto_id = v_u, ligado_em = now() where chave = p_chave returning * into r;
      elsif exists (select 1 from combos where id = v_u) then update ifood_itens set combo_id = v_u, ligado_em = now() where chave = p_chave returning * into r;
      elsif p_tipo = 'opcao' and exists (select 1 from adicionais where id = v_u) then update ifood_itens set adicional_id = v_u, ligado_em = now() where chave = p_chave returning * into r;
      end if;
    end if;
  end if;
  return r;
end $f$;

-- grava (ou regrava) os itens da venda a partir do pedido do iFood e acerta o estoque. Devolve quantos itens ficaram sem ligação.
create or replace function public._ifood_gravar_itens(p_venda uuid, p_order jsonb, p_regravar boolean) returns int
 language plpgsql security definer set search_path to 'public' as $f$
declare it jsonb; op jsonb; v_item ifood_itens%rowtype; v_op ifood_itens%rowtype; v_chave text; v_qtd int; v_tot numeric; v_ads uuid[]; v_desc text; v_custo numeric; v_sem int := 0; v_obs text; v_oq int;
begin
  if p_regravar then
    perform _ajustar_estoque(_itens_da_venda(p_venda), -1, p_venda);
    delete from itens_venda where venda_id = p_venda;
  end if;
  for it in select value from jsonb_array_elements(coalesce(p_order->'items', '[]'::jsonb)) loop
    v_chave := coalesce(nullif(it->>'externalCode', ''), nullif(it->>'id', ''), 'sem-codigo-' || public._ifood_norm(it->>'name'));
    v_qtd := greatest(1, round(public._ifood_n(it->'quantity'))::int);
    v_tot := public._ifood_n(it->'totalPrice');
    if v_tot <= 0 then v_tot := public._ifood_n(it->'price'); end if;
    if v_tot <= 0 then v_tot := (public._ifood_n(it->'unitPrice') + public._ifood_n(it->'optionsPrice')) * v_qtd; end if;
    v_item := public._ifood_item_visto(v_chave, it->>'name', 'produto');
    v_ads := '{}'; v_desc := coalesce(it->>'name', 'Item iFood'); v_obs := nullif(btrim(coalesce(it->>'observations', '')), '');
    for op in select value from jsonb_array_elements(coalesce(it->'options', '[]'::jsonb)) loop
      v_op := public._ifood_item_visto(coalesce(nullif(op->>'externalCode', ''), nullif(op->>'id', ''), 'sem-codigo-' || public._ifood_norm(op->>'name')), op->>'name', 'opcao');
      v_oq := greatest(1, round(public._ifood_n(op->'quantity'))::int);
      v_desc := v_desc || ' + ' || coalesce(op->>'name', 'opção') || case when v_oq > 1 then ' x' || v_oq else '' end;
      if v_op.adicional_id is not null then
        for i in 1..(v_oq * v_qtd) loop v_ads := v_ads || v_op.adicional_id; end loop;
      end if;
    end loop;
    if v_obs is not null then v_desc := v_desc || ' (obs: ' || v_obs || ')'; end if;
    v_custo := 0;
    if v_item.produto_id is not null then select coalesce(min(custo), 0) into v_custo from produto_precos where produto_id = v_item.produto_id;
    elsif v_item.combo_id is not null then select coalesce(min(custo), 0) into v_custo from combo_precos where combo_id = v_item.combo_id;
    end if;
    if v_item.produto_id is null and v_item.combo_id is null and not v_item.ignorar then v_sem := v_sem + 1; v_desc := v_desc || ' [SEM LIGAÇÃO]'; end if;
    insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
    values (p_venda, case when v_item.ignorar then null else v_item.produto_id end, case when v_item.ignorar then null else v_item.combo_id end,
            left(v_desc, 300), v_qtd, round(v_tot / v_qtd, 2), round(v_custo, 2), round(v_tot, 2), v_ads);
  end loop;
  perform _ajustar_estoque(_itens_da_venda(p_venda), 1, p_venda);
  return v_sem;
end $f$;

-- ---------- criar / atualizar o pedido do iFood como venda ----------
create or replace function public.ifood_criar_pedido(p_order jsonb, p_simulado boolean default false) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare
  v_id text := p_order->>'id'; v_disp text := coalesce(nullif(p_order->>'displayId', ''), right(coalesce(p_order->>'id', ''), 4));
  v_venda uuid := gen_random_uuid(); v_tipo venda_tipo; v_nome text; v_tel text; v_end text; v_comp text; v_ref text; v_obs text;
  v_orig numeric; v_taxa numeric; v_desc numeric; v_total numeric; v_prepago numeric; v_pend numeric; v_sem int; v_caixa uuid; v_numero int; v_met jsonb; v_troco numeric; v_agend text;
  v_stpag status_pagamento; v_forma text; ad jsonb;
begin
  if v_id is null then return jsonb_build_object('ok', false, 'message', 'Pedido sem id.'); end if;
  if exists (select 1 from ifood_pedidos where pedido_ifood = v_id) then return jsonb_build_object('ok', true, 'duplicado', true); end if;
  v_tipo := case when upper(coalesce(p_order->>'orderType', '')) in ('TAKEOUT', 'PICKUP') then 'Retirada' else 'Entrega' end::venda_tipo;
  v_nome := left(btrim(coalesce(p_order->'customer'->>'name', 'Cliente iFood')), 80) || ' (iFood)';
  v_tel := left(regexp_replace(coalesce(p_order->'customer'->'phone'->>'number', ''), '[^0-9]', '', 'g'), 20);
  ad := coalesce(p_order->'delivery'->'deliveryAddress', '{}'::jsonb);
  v_end := coalesce(nullif(ad->>'formattedAddress', ''), btrim(concat_ws(', ', ad->>'streetName', ad->>'streetNumber', ad->>'neighborhood', ad->>'city')));
  v_comp := coalesce(ad->>'complement', ''); v_ref := coalesce(ad->>'reference', '');
  v_total := public._ifood_n(p_order->'total'->'orderAmount'); v_taxa := public._ifood_n(p_order->'total'->'deliveryFee');
  v_desc := public._ifood_n(p_order->'total'->'benefits'); v_orig := public._ifood_n(p_order->'total'->'subTotal');
  if v_orig <= 0 then v_orig := greatest(v_total - v_taxa + v_desc, 0); end if;
  if v_total <= 0 then v_total := greatest(v_orig - v_desc + v_taxa, 0.01); end if;
  v_prepago := public._ifood_n(p_order->'payments'->'prepaid'); v_pend := public._ifood_n(p_order->'payments'->'pending');
  if v_prepago + v_pend <= 0 then v_prepago := v_total; v_pend := 0; end if;
  v_stpag := case when v_pend > 0.009 then 'A Receber' else 'Pago' end;
  v_forma := case when v_pend > 0.009 and v_prepago > 0.009 then 'iFood (pago no app) + iFood (pagar na entrega)' when v_pend > 0.009 then 'iFood (pagar na entrega)' else 'iFood (pago no app)' end;
  v_obs := 'iFood #' || v_disp;
  select (m->'cash'->>'changeFor') into v_troco from jsonb_array_elements(coalesce(p_order->'payments'->'methods', '[]'::jsonb)) m where m->'cash'->>'changeFor' is not null limit 1;
  if v_troco is not null and public._ifood_n(to_jsonb(v_troco)) > 0 then v_obs := v_obs || ' · levar troco para R$ ' || replace(to_char(public._ifood_n(to_jsonb(v_troco)), 'FM9999990.00'), '.', ','); end if;
  if upper(coalesce(p_order->>'orderTiming', '')) = 'SCHEDULED' then
    v_agend := coalesce(p_order->'schedule'->>'deliveryDateTimeStart', p_order->'delivery'->>'deliveryDateTime', p_order->>'preparationStartDateTime', '');
    v_obs := v_obs || ' · AGENDADO' || case when v_agend <> '' then ' para ' || to_char((v_agend::timestamptz) at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') else '' end;
  end if;
  if nullif(btrim(coalesce(p_order->'delivery'->>'observations', '')), '') is not null then v_obs := v_obs || ' · ' || btrim(p_order->'delivery'->>'observations'); end if;
  if p_simulado then v_obs := v_obs || ' · TESTE (simulação)'; end if;
  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido, endereco, complemento, referencia, observacoes_entrega,
                      status_pagamento, recebido_em, valor_original, valor_desconto, desconto_detalhe, origem, taxa_entrega, caixa_id, requisicao_id, canal)
  values (v_venda, v_nome, nullif(v_tel, ''), v_forma, round(v_total, 2), 0, 'Confirmada', v_tipo, 'Recebido',
          case when v_tipo = 'Entrega' then coalesce(v_end, '') else '' end, case when v_tipo = 'Entrega' then v_comp else '' end, case when v_tipo = 'Entrega' then v_ref else '' end, v_obs,
          v_stpag, case when v_stpag = 'Pago' then now() end, round(v_orig, 2), round(v_desc, 2), case when v_desc > 0 then 'Desconto/cupom iFood' else '' end, 'Balcão', round(v_taxa, 2), v_caixa, 'ifood:' || v_id, 'iFood')
  returning numero_pedido into v_numero;

  v_sem := public._ifood_gravar_itens(v_venda, p_order, false);
  update vendas set custo_total = coalesce((select sum(custo_unitario * quantidade) from itens_venda where venda_id = v_venda), 0) where id = v_venda;

  if v_prepago > 0.009 then insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo) values (v_venda, 'iFood (pago no app)', round(v_prepago, 2), 0, 0); end if;
  if v_pend > 0.009 then insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo) values (v_venda, 'iFood (pagar na entrega)', round(v_pend, 2), 0, 0); end if;

  insert into ifood_pedidos (pedido_ifood, venda_id, numero_ifood, estado, expira_em, itens_sem_ligacao, simulado, bruto)
  values (v_id, v_venda, v_disp, 'novo', now() + interval '8 minutes', v_sem, p_simulado, p_order);
  update ifood_estado set ultimo_pedido_em = now(), atualizado_em = now() where id;
  perform _auditar('Pedido do iFood recebido', 'iFood #' || v_disp || ' → venda #' || v_numero || ' · R$ ' || replace(to_char(v_total, 'FM9999990.00'), '.', ',') || case when v_sem > 0 then ' · ' || v_sem || ' item(ns) sem ligação' else '' end || case when p_simulado then ' · SIMULAÇÃO' else '' end);
  perform _integ_log('ifood', case when v_sem > 0 then 'aviso' else 'info' end, 'Pedido #' || v_disp || ' recebido' || case when v_sem > 0 then ' (' || v_sem || ' item sem ligação)' else '' end);
  return jsonb_build_object('ok', true, 'vendaId', v_venda, 'numero', v_numero, 'semLigacao', v_sem);
end $f$;

-- cliente mudou o pedido (ORDER_PATCHED): regrava itens e totais
create or replace function public.ifood_atualizar_pedido(p_order jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r ifood_pedidos%rowtype; v_sem int; v_total numeric;
begin
  select * into r from ifood_pedidos where pedido_ifood = p_order->>'id' for update;
  if not found then return public.ifood_criar_pedido(p_order, false); end if;
  if r.venda_id is null or r.estado = 'cancelado' then return jsonb_build_object('ok', true, 'ignorado', true); end if;
  v_sem := public._ifood_gravar_itens(r.venda_id, p_order, true);
  v_total := public._ifood_n(p_order->'total'->'orderAmount');
  update vendas set valor_total = case when v_total > 0 then round(v_total, 2) else valor_total end,
    valor_original = case when public._ifood_n(p_order->'total'->'subTotal') > 0 then public._ifood_n(p_order->'total'->'subTotal') else valor_original end,
    custo_total = coalesce((select sum(custo_unitario * quantidade) from itens_venda where venda_id = r.venda_id), 0)
    where id = r.venda_id;
  update ifood_pedidos set bruto = p_order, itens_sem_ligacao = v_sem, atualizado_em = now() where pedido_ifood = r.pedido_ifood;
  perform _auditar('Pedido do iFood alterado pelo cliente', 'iFood #' || r.numero_ifood);
  perform _integ_log('ifood', 'aviso', 'Pedido #' || r.numero_ifood || ' foi alterado pelo cliente');
  return jsonb_build_object('ok', true, 'semLigacao', v_sem);
end $f$;

-- eventos oficiais mudam o estado do pedido (nunca a nossa suposição)
create or replace function public.ifood_aplicar_evento(p_codigo text, p_pedido text, p_motivo text default null) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r ifood_pedidos%rowtype; v vendas%rowtype; v_st text;
begin
  select * into r from ifood_pedidos where pedido_ifood = p_pedido for update;
  if not found then return jsonb_build_object('ok', false, 'desconhecido', true); end if;
  if p_codigo in ('CFM', 'CONFIRMED') and r.estado = 'novo' then update ifood_pedidos set estado = 'confirmado', confirmado_em = now(), atualizado_em = now() where pedido_ifood = p_pedido;
  elsif p_codigo in ('RTP', 'READY_TO_PICKUP') and r.estado in ('novo', 'confirmado', 'em_preparo') then update ifood_pedidos set estado = 'pronto', atualizado_em = now() where pedido_ifood = p_pedido;
  elsif p_codigo in ('DSP', 'DISPATCHED') and r.estado <> 'cancelado' then update ifood_pedidos set estado = 'despachado', atualizado_em = now() where pedido_ifood = p_pedido;
  elsif p_codigo in ('CON', 'CONCLUDED') and r.estado <> 'cancelado' then
    update ifood_pedidos set estado = 'concluido', atualizado_em = now() where pedido_ifood = p_pedido;
    update vendas set status_pedido = case when tipo = 'Entrega' then 'Entregue' else 'Retirada' end::status_pedido, concluida_em = coalesce(concluida_em, now())
      where id = r.venda_id and status = 'Confirmada' and status_pedido::text not in ('Entregue', 'Retirada', 'Servida');
  elsif p_codigo in ('CAN', 'CANCELLED') and r.estado <> 'cancelado' then
    update ifood_pedidos set estado = 'cancelado', atualizado_em = now() where pedido_ifood = p_pedido;
    select * into v from vendas where id = r.venda_id for update;
    if found and v.status = 'Confirmada' then
      v_st := v.status_pedido::text;
      update vendas set status = 'Cancelada', motivo_cancelamento = left('Cancelado pelo iFood' || coalesce(' · ' || nullif(p_motivo, ''), ''), 200) where id = v.id;
      if v_st in ('Recebido', 'Em preparo', 'Suspenso') then perform _ajustar_estoque(_itens_da_venda(v.id), -1, v.id); end if;
      update ifood_acoes set estado = 'pulada', erro = 'pedido cancelado' where pedido_ifood = p_pedido and estado in ('pendente', 'duvida');
      perform _auditar('Pedido do iFood cancelado pelo iFood', 'iFood #' || r.numero_ifood || coalesce(' · ' || nullif(p_motivo, ''), '') || case when v_st not in ('Recebido', 'Em preparo', 'Suspenso') then ' · já estava pronto: estoque NÃO devolvido' else '' end);
      perform _integ_log('ifood', 'aviso', 'Pedido #' || r.numero_ifood || ' cancelado pelo iFood');
      begin perform _push_enviar('pedido', '❌ iFood cancelou o pedido #' || r.numero_ifood, coalesce(nullif(p_motivo, ''), 'Veja o painel'), 'ifood-can-' || r.pedido_ifood); exception when others then null; end;
    end if;
  end if;
  return jsonb_build_object('ok', true);
end $f$;

-- ---------- ações para o iFood: a mudança de status na nossa tela vira uma tarefa para o servidor ----------
create or replace function public._ifood_enfileirar(p_pedido text, p_acao text, p_dados jsonb default '{}'::jsonb) returns void
 language sql security definer set search_path to 'public' as $f$
  insert into ifood_acoes (pedido_ifood, acao, dados) values (p_pedido, p_acao, p_dados) on conflict do nothing
$f$;

create or replace function public._ifood_trg_status() returns trigger language plpgsql security definer set search_path to 'public' as $f$
declare r ifood_pedidos%rowtype;
begin
  if new.canal is distinct from 'iFood' then return null; end if;
  if not public._integracao_ligada('ifood') then return null; end if;
  select * into r from ifood_pedidos where venda_id = new.id;
  if not found or r.simulado or r.estado in ('cancelado', 'concluido') then return null; end if;
  if new.status = 'Cancelada' and old.status is distinct from 'Cancelada' then
    perform public._ifood_enfileirar(r.pedido_ifood, 'cancelar', jsonb_build_object('motivo', new.motivo_cancelamento));
  elsif new.status_pedido is distinct from old.status_pedido and new.status = 'Confirmada' then
    if new.status_pedido::text = 'Em preparo' then
      if r.estado = 'novo' then perform public._ifood_enfileirar(r.pedido_ifood, 'confirmar'); end if;
      perform public._ifood_enfileirar(r.pedido_ifood, 'iniciar_preparo');
    elsif new.status_pedido::text = 'Pronta' then
      perform public._ifood_enfileirar(r.pedido_ifood, 'pronto');
    elsif new.status_pedido::text = 'Saiu para entrega' then
      perform public._ifood_enfileirar(r.pedido_ifood, 'despachar');
    end if;
  end if;
  return null;
end $f$;
drop trigger if exists trg_ifood_status on public.vendas;
create trigger trg_ifood_status after update of status, status_pedido on public.vendas for each row when (new.canal = 'iFood') execute function public._ifood_trg_status();

-- aviso à equipe quando entra pedido do iFood (o trigger antigo só avisa pedidos do cardápio)
create or replace function public._ifood_trg_novo() returns trigger language plpgsql security definer set search_path to 'public' as $f$
begin
  perform _push_enviar('pedido', '🛵 Novo pedido iFood #' || coalesce(new.numero_pedido::text, ''), coalesce(new.tipo::text, '') || ' · R$ ' || replace(to_char(coalesce(new.valor_total, 0), 'FM9999990.00'), '.', ','), 'pedido-' || new.id::text);
  return null;
exception when others then return null;
end $f$;
drop trigger if exists trg_ifood_novo on public.vendas;
create trigger trg_ifood_novo after insert on public.vendas for each row when (new.canal = 'iFood') execute function public._ifood_trg_novo();

-- ---------- funções só do servidor (edge function ifood-sync, chave de serviço) ----------
create or replace function public.ifood_credenciais() returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('ligado', public._integracao_ligada('ifood'),
    'clientId', (select valor from integracoes_segredos where chave = 'ifood_client_id'),
    'clientSecret', (select valor from integracoes_segredos where chave = 'ifood_client_secret'),
    'merchantId', (select valor from integracoes_segredos where chave = 'ifood_merchant_id'),
    'config', (select config from integracoes_config where provedor = 'ifood'))
$f$;
create or replace function public.ifood_token_ler() returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('token', token, 'expiraEm', expira_em) from ifood_token where id and expira_em > now() + interval '2 minutes'
$f$;
create or replace function public.ifood_token_gravar(p_token text, p_seg int) returns void language sql security definer set search_path to 'public' as $f$
  update ifood_token set token = p_token, expira_em = now() + make_interval(secs => greatest(p_seg, 60)) where id;
  update ifood_estado set token_ok = true, atualizado_em = now() where id;
$f$;
create or replace function public.ifood_trava_pegar(p_dono text, p_seg int) returns boolean language plpgsql security definer set search_path to 'public' as $f$
declare v int;
begin
  update ifood_estado set trava_dono = p_dono, trava_ate = now() + make_interval(secs => p_seg) where id and (trava_ate is null or trava_ate < now() or trava_dono = p_dono);
  get diagnostics v = row_count;
  return v > 0;
end $f$;
create or replace function public.ifood_trava_soltar(p_dono text) returns void language sql security definer set search_path to 'public' as $f$
  update ifood_estado set trava_ate = null where id and trava_dono = p_dono
$f$;
create or replace function public.ifood_marcar_consulta(p_ok boolean, p_erro text default null, p_token_ok boolean default null) returns void
 language plpgsql security definer set search_path to 'public' as $f$
begin
  update ifood_estado set ultima_consulta = now(),
    ultima_consulta_ok = case when p_ok then now() else ultima_consulta_ok end,
    token_ok = coalesce(p_token_ok, token_ok),
    ultimo_erro = case when p_ok then null else left(p_erro, 300) end,
    ultimo_erro_em = case when p_ok then ultimo_erro_em else now() end, atualizado_em = now() where id;
  if not p_ok and p_erro is not null then perform public._integ_log('ifood', 'erro', p_erro); end if;
end $f$;
create or replace function public.ifood_evento_guardar(p jsonb) returns boolean language plpgsql security definer set search_path to 'public' as $f$
declare v int;
begin
  insert into ifood_eventos (id, codigo, codigo_completo, pedido_ifood, criado_ifood, bruto)
  values (p->>'id', p->>'code', p->>'fullCode', p->>'orderId', nullif(p->>'createdAt', '')::timestamptz, p) on conflict (id) do nothing;
  get diagnostics v = row_count;
  return v > 0;
end $f$;
create or replace function public.ifood_eventos_pendentes() returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select coalesce(jsonb_agg(jsonb_build_object('id', id, 'codigo', coalesce(codigo_completo, codigo), 'pedido', pedido_ifood, 'tentativas', tentativas, 'bruto', bruto) order by recebido_em), '[]'::jsonb)
  from (select * from ifood_eventos where processado_em is null and recebido_em > now() - interval '1 day' order by recebido_em limit 50) x
$f$;
create or replace function public.ifood_evento_resultado(p_id text, p_final boolean, p_erro text default null) returns void language sql security definer set search_path to 'public' as $f$
  update ifood_eventos set tentativas = tentativas + 1, erro = left(p_erro, 300), processado_em = case when p_final then now() else null end where id = p_id
$f$;
create or replace function public.ifood_acoes_pendentes() returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select coalesce(jsonb_agg(jsonb_build_object('id', a.id, 'pedido', a.pedido_ifood, 'acao', a.acao, 'dados', a.dados, 'tentativas', a.tentativas) order by a.id), '[]'::jsonb)
  from (select * from ifood_acoes where estado = 'pendente' order by id limit 20) a
$f$;
create or replace function public.ifood_acao_resultado(p_id bigint, p_estado text, p_erro text default null) returns void
 language plpgsql security definer set search_path to 'public' as $f$
declare a ifood_acoes%rowtype;
begin
  update ifood_acoes set estado = p_estado, tentativas = tentativas + 1, erro = left(p_erro, 300), executado_em = now() where id = p_id returning * into a;
  if a.id is null then return; end if;
  if p_estado = 'ok' then
    if a.acao = 'confirmar' then update ifood_pedidos set estado = 'confirmado', confirmado_em = coalesce(confirmado_em, now()), atualizado_em = now() where pedido_ifood = a.pedido_ifood and estado = 'novo'; end if;
    perform public._integ_log('ifood', 'info', 'Ação enviada ao iFood: ' || a.acao || ' (pedido ' || a.pedido_ifood || ')');
  elsif p_estado in ('erro', 'duvida') then
    perform public._integ_log('ifood', 'erro', 'Ação NÃO confirmada no iFood: ' || a.acao || ' — ' || coalesce(p_erro, ''));
  end if;
end $f$;
create or replace function public.ifood_pedido_dados(p_pedido text) returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('estado', estado, 'simulado', simulado, 'expiraEm', expira_em, 'numero', numero_ifood) from ifood_pedidos where pedido_ifood = p_pedido
$f$;
-- pedidos que ainda não foram confirmados (para confirmar sozinho ou avisar a equipe aos 4 e 6 min)
create or replace function public.ifood_novos_sem_confirmar() returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select coalesce(jsonb_agg(jsonb_build_object('pedido', pedido_ifood, 'numero', numero_ifood, 'minutos', round(extract(epoch from (now() - criado_em)) / 60, 1))), '[]'::jsonb)
  from ifood_pedidos where estado = 'novo' and not simulado and criado_em > now() - interval '15 minutes'
$f$;
create or replace function public.ifood_enfileirar(p_pedido text, p_acao text) returns void language sql security definer set search_path to 'public' as $f$
  select public._ifood_enfileirar(p_pedido, p_acao, '{}'::jsonb)
$f$;
-- pedido novo sem confirmação: avisa a equipe aos 4 e aos 6 minutos (o iFood cancela sozinho aos 8)
create or replace function public.ifood_escalar() returns int language plpgsql security definer set search_path to 'public' as $f$
declare r record; v_n int := 0;
begin
  for r in select pedido_ifood, numero_ifood, avisos, extract(epoch from (now() - criado_em)) / 60 as min from ifood_pedidos where estado = 'novo' and not simulado and criado_em > now() - interval '9 minutes' loop
    if (r.min >= 6 and r.avisos < 2) or (r.min >= 4 and r.avisos < 1) then
      update ifood_pedidos set avisos = case when r.min >= 6 then 2 else 1 end where pedido_ifood = r.pedido_ifood;
      perform _push_enviar('pedido', '⏰ iFood #' || coalesce(r.numero_ifood, '') || ' esperando confirmação', 'Confirme agora: o iFood cancela sozinho em poucos minutos.', 'ifood-conf-' || r.pedido_ifood || '-' || r.avisos);
      v_n := v_n + 1;
    end if;
  end loop;
  return v_n;
end $f$;
create or replace function public.ifood_limpar() returns void language plpgsql security definer set search_path to 'public' as $f$
declare v_dias int := coalesce((select (config->>'retencaoClientesDias')::int from integracoes_config where provedor = 'ifood'), 90);
begin
  delete from ifood_eventos where recebido_em < now() - interval '30 days';
  delete from ifood_acoes where criado_em < now() - interval '60 days' and estado in ('ok', 'pulada');
  update ifood_pedidos set bruto = jsonb_set(coalesce(bruto, '{}'::jsonb) - 'customer' - 'delivery', '{apagado}', 'true'::jsonb) where criado_em < now() - make_interval(days => v_dias) and coalesce((bruto->>'apagado'), '') <> 'true';
  update vendas set telefone_cliente = null, endereco = '', complemento = '', referencia = '', cliente_nome = 'Cliente iFood'
   where canal = 'iFood' and data_hora < now() - make_interval(days => v_dias) and (telefone_cliente is not null or endereco <> '' or cliente_nome <> 'Cliente iFood');
end $f$;

-- ---------- telas do administrador ----------
create or replace function public.api_ifood_pedidos(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'estado', (select jsonb_build_object('ultimaConsulta', ultima_consulta, 'ultimaConsultaOk', ultima_consulta_ok, 'ultimoPedido', ultimo_pedido_em, 'tokenOk', token_ok, 'ultimoErro', ultimo_erro) from ifood_estado where id),
    'pedidos', coalesce((select jsonb_agg(jsonb_build_object('pedido', i.pedido_ifood, 'numero', i.numero_ifood, 'estado', i.estado, 'semLigacao', i.itens_sem_ligacao, 'simulado', i.simulado,
        'venda', v.numero_pedido, 'total', v.valor_total, 'em', i.criado_em, 'cancelado', v.status = 'Cancelada',
        'acaoErro', (select a.acao || ': ' || coalesce(a.erro, '') from ifood_acoes a where a.pedido_ifood = i.pedido_ifood and a.estado in ('erro', 'duvida') order by a.id desc limit 1)) order by i.criado_em desc)
      from (select * from ifood_pedidos order by criado_em desc limit 30) i left join vendas v on v.id = i.venda_id), '[]'::jsonb));
end $f$;

create or replace function public.api_ifood_itens(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'itens', coalesce((select jsonb_agg(jsonb_build_object('chave', i.chave, 'nome', i.nome, 'tipo', i.tipo, 'ignorar', i.ignorar,
        'ligado', case when i.produto_id is not null then 'produto' when i.combo_id is not null then 'combo' when i.adicional_id is not null then 'adicional' end,
        'ligadoId', coalesce(i.produto_id, i.combo_id, i.adicional_id),
        'ligadoNome', coalesce((select nome from produtos where id = i.produto_id), (select nome from combos where id = i.combo_id), (select nome from adicionais where id = i.adicional_id)),
        'sugestao', case when i.produto_id is null and i.combo_id is null and i.adicional_id is null and not i.ignorar then public._ifood_sugestao(i.nome, i.tipo) end)
        order by (i.produto_id is null and i.combo_id is null and i.adicional_id is null and not i.ignorar) desc, i.nome) from ifood_itens i), '[]'::jsonb),
    'produtos', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'nome', nome) order by nome) from produtos where ativo), '[]'::jsonb),
    'combos', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'nome', nome) order by nome) from combos where ativo), '[]'::jsonb),
    'adicionais', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'nome', nome) order by nome) from adicionais where ativo), '[]'::jsonb));
end $f$;

create or replace function public.api_ifood_ligar_item(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_chave text := p->>'chave'; v_tipo text := p->>'tipo'; v_id uuid := nullif(p->>'id', '')::uuid; v_ignorar boolean := coalesce((p->>'ignorar')::boolean, false);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not exists (select 1 from ifood_itens where chave = v_chave) then return _falha('Item não encontrado.'); end if;
  if v_ignorar then
    update ifood_itens set ignorar = true, produto_id = null, combo_id = null, adicional_id = null, ligado_em = now() where chave = v_chave;
  elsif v_tipo = 'produto' and exists (select 1 from produtos where id = v_id) then
    update ifood_itens set ignorar = false, produto_id = v_id, combo_id = null, adicional_id = null, ligado_em = now() where chave = v_chave;
  elsif v_tipo = 'combo' and exists (select 1 from combos where id = v_id) then
    update ifood_itens set ignorar = false, produto_id = null, combo_id = v_id, adicional_id = null, ligado_em = now() where chave = v_chave;
  elsif v_tipo = 'adicional' and exists (select 1 from adicionais where id = v_id) then
    update ifood_itens set ignorar = false, produto_id = null, combo_id = null, adicional_id = v_id, ligado_em = now() where chave = v_chave;
  elsif v_tipo = 'desligar' then
    update ifood_itens set ignorar = false, produto_id = null, combo_id = null, adicional_id = null, ligado_em = null where chave = v_chave;
  else return _falha('Escolha um item válido do sistema.'); end if;
  perform _auditar('Item do iFood ligado', v_chave || ' → ' || coalesce(v_tipo, '') || case when v_ignorar then ' (ignorar)' else '' end);
  return api_ifood_itens('{}');
end $f$;

-- depois de ligar itens, refaz os pedidos que ficaram sem ligação (ajusta custo e estoque)
create or replace function public.api_ifood_reprocessar(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r record; v_n int := 0; v_sem int;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  for r in select i.* from ifood_pedidos i join vendas v on v.id = i.venda_id where i.itens_sem_ligacao > 0 and v.status = 'Confirmada' and i.bruto ? 'items' and v.fechamento_entrega_id is null loop
    v_sem := public._ifood_gravar_itens(r.venda_id, r.bruto, true);
    update vendas set custo_total = coalesce((select sum(custo_unitario * quantidade) from itens_venda where venda_id = r.venda_id), 0) where id = r.venda_id;
    update ifood_pedidos set itens_sem_ligacao = v_sem, atualizado_em = now() where pedido_ifood = r.pedido_ifood;
    v_n := v_n + 1;
  end loop;
  perform _auditar('Pedidos do iFood reprocessados', v_n || ' pedido(s)');
  return jsonb_build_object('ok', true, 'message', v_n || ' pedido(s) refeito(s) com as ligações atuais.') || api_ifood_pedidos('{}');
end $f$;

-- simulação (treino): só Desenvolvedor. Cria um pedido de mentira com itens reais do cardápio; nada é enviado ao iFood.
create or replace function public.api_ifood_simular(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_prod record; v_id text := 'SIM-' || substr(md5(random()::text), 1, 10); v_order jsonb; v_itens jsonb := '[]'::jsonb; v_sub numeric := 0; v_pre boolean := coalesce((p->>'pagoNoApp')::boolean, true); v_res jsonb; v_pr numeric;
begin
  if not public._eh_dev() then return _negado(); end if;
  for v_prod in select pr.id, pr.nome, coalesce((select min(preco) from produto_precos where produto_id = pr.id), 20) preco from produtos pr where pr.ativo order by random() limit 2 loop
    v_pr := v_prod.preco;
    v_itens := v_itens || jsonb_build_object('id', 'it-' || substr(md5(v_prod.id::text), 1, 8), 'name', v_prod.nome, 'externalCode', v_prod.id::text, 'quantity', 1, 'unitPrice', v_pr, 'optionsPrice', 0, 'totalPrice', v_pr, 'observations', 'sem cebola (teste)', 'options', '[]'::jsonb);
    v_sub := v_sub + v_pr;
  end loop;
  if jsonb_array_length(v_itens) = 0 then return _falha('Cadastre ao menos um produto ativo para simular.'); end if;
  v_itens := v_itens || jsonb_build_object('id', 'it-sim-novo', 'name', 'Item novo do iFood (teste sem ligação)', 'externalCode', 'SIM-SEM-LIGACAO', 'quantity', 1, 'unitPrice', 10, 'totalPrice', 10, 'options', '[]'::jsonb);
  v_sub := v_sub + 10;
  v_order := jsonb_build_object('id', v_id, 'displayId', right(v_id, 4), 'orderType', 'DELIVERY', 'orderTiming', 'IMMEDIATE', 'createdAt', now(),
    'customer', jsonb_build_object('name', 'Cliente Teste', 'phone', jsonb_build_object('number', '11999990000')),
    'delivery', jsonb_build_object('deliveredBy', 'MERCHANT', 'deliveryAddress', jsonb_build_object('formattedAddress', 'Rua de Teste, 100 - Centro', 'complement', 'ap 1', 'reference', 'perto da praça')),
    'items', v_itens,
    'total', jsonb_build_object('subTotal', v_sub, 'deliveryFee', 6, 'benefits', 0, 'orderAmount', v_sub + 6),
    'payments', case when v_pre then jsonb_build_object('prepaid', v_sub + 6, 'pending', 0, 'methods', jsonb_build_array(jsonb_build_object('type', 'PREPAID', 'method', 'CREDIT', 'value', v_sub + 6)))
                     else jsonb_build_object('prepaid', 0, 'pending', v_sub + 6, 'methods', jsonb_build_array(jsonb_build_object('type', 'PENDING', 'method', 'CASH', 'value', v_sub + 6, 'cash', jsonb_build_object('changeFor', 100)))) end);
  v_res := public.ifood_criar_pedido(v_order, true);
  update ifood_pedidos set estado = 'confirmado', confirmado_em = now() where pedido_ifood = v_id;
  return jsonb_build_object('ok', true, 'message', 'Pedido de TESTE criado (venda #' || (v_res->>'numero') || '). Cancele a venda depois do treino. Nada foi enviado ao iFood.') || api_ifood_pedidos('{}');
end $f$;

-- ---------- saúde: iFood (e a Nota fiscal, nas fases seguintes) ----------
create or replace function public._saude_integracoes() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_desc int; e ifood_estado%rowtype; v_min numeric; v_sem int; v_novos int; v_acoes int; v_nivel text; v_txt text;
begin
  if exists (select 1 from ai_segredos where provedor = 'nvidia') or exists (select 1 from ai_segredos where provedor = 'cloudflare') then
    select count(*) into v_desc from unnest(array['nvidia', 'cloudflare']) x(p) where _ia_provedor_descansando(x.p);
    v := v || jsonb_build_object('id', 'ia_extras', 'titulo', 'IAs de reserva (NVIDIA / Cloudflare)', 'nivel', case when v_desc > 0 then 'atencao' else 'ok' end,
      'texto', (select string_agg(x.rot || ': ' || case when not exists (select 1 from ai_segredos where provedor = x.p) then 'sem chave' when _ia_provedor_descansando(x.p) then 'descansando (erros recentes)' else 'pronta' end, ' · ')
                from (values ('nvidia', 'NVIDIA'), ('cloudflare', 'Cloudflare')) x(p, rot)));
  end if;
  if _integracao_ligada('ifood') then
    select * into e from ifood_estado where id;
    v_min := case when e.ultima_consulta_ok is null then null else extract(epoch from (now() - e.ultima_consulta_ok)) / 60 end;
    select coalesce(sum(itens_sem_ligacao), 0) into v_sem from ifood_pedidos where estado <> 'cancelado' and criado_em > now() - interval '7 days';
    select count(*) into v_novos from ifood_pedidos where estado = 'novo' and not simulado and criado_em < now() - interval '4 minutes';
    select count(*) into v_acoes from ifood_acoes where estado in ('erro', 'duvida') and criado_em > now() - interval '1 day';
    v_nivel := case when v_min is null or v_min > 2 or e.token_ok is false or v_novos > 0 then 'problema' when v_acoes > 0 or v_sem > 0 or e.ultimo_erro is not null then 'atencao' else 'ok' end;
    v_txt := case when v_min is null then 'Ligado, mas ainda sem nenhuma consulta bem-sucedida ao iFood.' else 'Última consulta ao iFood há ' || round(v_min, 1) || ' min' end
      || case when e.ultimo_pedido_em is not null then ' · último pedido às ' || to_char(e.ultimo_pedido_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') else ' · nenhum pedido ainda' end
      || case when e.token_ok is false then ' · ACESSO RECUSADO (confira as chaves)' else '' end
      || case when v_novos > 0 then ' · ' || v_novos || ' pedido(s) esperando confirmação há mais de 4 min' else '' end
      || case when v_acoes > 0 then ' · ' || v_acoes || ' ação(ões) não confirmada(s) no iFood' else '' end
      || case when v_sem > 0 then ' · ' || v_sem || ' item(ns) sem ligação' else '' end;
    v := v || jsonb_build_object('id', 'ifood', 'titulo', 'iFood', 'nivel', v_nivel, 'texto', v_txt);
  end if;
  for r in select * from integracoes_config where ligado and provedor = 'nfce' loop
    v := v || jsonb_build_object('id', 'nfce', 'titulo', 'Nota fiscal (NFC-e)', 'nivel', 'atencao', 'texto', 'Ligada (' || r.modo || '), aguardando a primeira nota.');
  end loop;
  return v;
end $f$;

-- itens sem ligação / pedido do iFood esperando também entram nas pendências para ligar (checklist)
-- ---------- tarefas automáticas (só chamam o iFood quando a integração está ligada) ----------
do $c$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.schedule('ifood-sync-minuto', '* * * * *', $j$select case when public._integracao_ligada('ifood') then public.chamar_edge('ifood-sync', '{}'::jsonb) end$j$);
    perform cron.schedule('ifood-limpeza-diaria', '55 6 * * *', $j$select public.ifood_limpar()$j$);
  end if;
end $c$;

-- ---------- permissões ----------
revoke execute on function public._ifood_n(jsonb), public._ifood_norm(text), public._ifood_sugestao(text, text), public._ifood_item_visto(text, text, text), public._ifood_gravar_itens(uuid, jsonb, boolean),
  public._ifood_enfileirar(text, text, jsonb), public._ifood_trg_status(), public._ifood_trg_novo(),
  public.ifood_criar_pedido(jsonb, boolean), public.ifood_atualizar_pedido(jsonb), public.ifood_aplicar_evento(text, text, text), public.ifood_credenciais(), public.ifood_token_ler(),
  public.ifood_token_gravar(text, int), public.ifood_trava_pegar(text, int), public.ifood_trava_soltar(text), public.ifood_marcar_consulta(boolean, text, boolean), public.ifood_evento_guardar(jsonb),
  public.ifood_eventos_pendentes(), public.ifood_evento_resultado(text, boolean, text), public.ifood_acoes_pendentes(), public.ifood_acao_resultado(bigint, text, text),
  public.ifood_pedido_dados(text), public.ifood_novos_sem_confirmar(), public.ifood_enfileirar(text, text), public.ifood_escalar(), public.ifood_limpar() from public, anon, authenticated;
grant execute on function public.ifood_criar_pedido(jsonb, boolean), public.ifood_atualizar_pedido(jsonb), public.ifood_aplicar_evento(text, text, text), public.ifood_credenciais(), public.ifood_token_ler(),
  public.ifood_token_gravar(text, int), public.ifood_trava_pegar(text, int), public.ifood_trava_soltar(text), public.ifood_marcar_consulta(boolean, text, boolean), public.ifood_evento_guardar(jsonb),
  public.ifood_eventos_pendentes(), public.ifood_evento_resultado(text, boolean, text), public.ifood_acoes_pendentes(), public.ifood_acao_resultado(bigint, text, text),
  public.ifood_pedido_dados(text), public.ifood_novos_sem_confirmar(), public.ifood_enfileirar(text, text), public.ifood_escalar(), public.ifood_limpar() to service_role;
revoke execute on function public.api_ifood_pedidos(jsonb), public.api_ifood_itens(jsonb), public.api_ifood_ligar_item(jsonb), public.api_ifood_reprocessar(jsonb), public.api_ifood_simular(jsonb) from public, anon;
grant execute on function public.api_ifood_pedidos(jsonb), public.api_ifood_itens(jsonb), public.api_ifood_ligar_item(jsonb), public.api_ifood_reprocessar(jsonb), public.api_ifood_simular(jsonb) to authenticated;

-- ---------- Ajuda do assistente ----------
insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-103-ifood','iFood: pedidos, itens ligados e simulação','ifood pedido itens ligar ligação produto sem ligação reprocessar simulação teste confirmar',
 E'Com o iFood ligado (Contas e acessos → Integrações), os pedidos entram sozinhos como venda normal, com a marca "iFood #número", aviso no celular e baixa dos ingredientes.\nItens do iFood: cada item do cardápio do iFood precisa ser ligado a um produto do sistema (Contas e acessos → Integrações → Itens do iFood). O sistema sugere pelo nome; você confirma. Item sem ligação entra no pedido mesmo assim, com o aviso "SEM LIGAÇÃO"; depois de ligar, toque em "Refazer pedidos sem ligação".\nO andamento (em preparo, pronta, saiu para entrega) é avisado ao iFood automaticamente quando você muda o status do pedido. Se o iFood não confirmar uma ação, aparece um alerta na lista de pedidos do iFood.\nDesenvolvedor: "Simular pedido do iFood (treino)" cria um pedido de mentira, sem enviar nada ao iFood; cancele a venda depois do treino.',
 array['Admin','Operador'],true,'lista',103,'Itens do iFood e simulação: só Administrador/Desenvolvedor.'
where not exists (select 1 from ai_ajuda where slug='man-admin-103-ifood');


-- ################ PARTE: f2-ifood-operacao ################
-- =====================================================================
-- FASE 2 — iFOOD OPERAÇÃO · 2026-10-11
-- Negociação de cancelamento (aceitar / recusar / propor alternativa), loja aberta/fechada/pausada no iFood,
-- abrir/fechar junto com o caixa, saúde da loja. Precisa das Fases 0 e 1 antes. Seguro para rodar de novo. TUDO DESLIGADO.
-- ⚠️ Os endereços e campos do iFood para negociação e loja vêm de fontes de terceiros: ainda não testado com o iFood de verdade.
-- =====================================================================

-- a fila de ações passa a aceitar também negociação e loja
alter table public.ifood_acoes drop constraint if exists ifood_acoes_acao_check;
alter table public.ifood_acoes add constraint ifood_acoes_acao_check check (acao in
  ('confirmar','iniciar_preparo','pronto','despachar','cancelar','negociacao_aceitar','negociacao_recusar','negociacao_alternativa','loja_fechar','loja_abrir','loja_pausar','loja_retomar'));

create table if not exists public.ifood_negociacoes (
  id text primary key,                         -- id da disputa no iFood
  pedido_ifood text not null, tipo text, motivo text,
  expira_em timestamptz, alternativas jsonb not null default '[]'::jsonb,
  estado text not null default 'aberta' check (estado in ('aberta','aceita','recusada','alternativa','encerrada','expirada')),
  bruto jsonb, criado_em timestamptz not null default now(), respondido_em timestamptz, resposta_por text);
create index if not exists ifood_negociacoes_abertas_idx on public.ifood_negociacoes (expira_em) where estado = 'aberta';
alter table public.ifood_negociacoes enable row level security;

create table if not exists public.ifood_loja (
  id boolean primary key default true check (id),
  situacao text,                                -- texto do iFood (ex.: OK, FECHADA)
  disponivel boolean, motivo text,
  pausada_ate timestamptz, interrupcao_id text, fechada_por_nos boolean not null default false,
  verificado_em timestamptz, bruto jsonb, atualizado_em timestamptz not null default now());
insert into public.ifood_loja (id) values (true) on conflict (id) do nothing;
alter table public.ifood_loja enable row level security;

-- ---------- evento de negociação (HANDSHAKE_DISPUTE) e fim (HANDSHAKE_SETTLEMENT) ----------
create or replace function public.ifood_negociacao_registrar(p_evento jsonb, p_pedido text) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare m jsonb := coalesce(p_evento->'metadata', '{}'::jsonb); v_id text := coalesce(nullif(m->>'disputeId', ''), nullif(m->>'handshakeId', ''), nullif(p_evento->>'id', ''));
        v_exp timestamptz; v_num text;
begin
  begin v_exp := nullif(coalesce(m->>'expiresAt', m->>'expirationDate'), '')::timestamptz; exception when others then v_exp := null; end;
  insert into ifood_negociacoes (id, pedido_ifood, tipo, motivo, expira_em, alternativas, bruto)
  values (v_id, p_pedido, coalesce(m->>'handshakeType', m->>'type'), left(coalesce(m->>'message', m->>'reason', m->>'handshakeGroup', ''), 300), coalesce(v_exp, now() + interval '5 minutes'),
          case when jsonb_typeof(m->'alternatives') = 'array' then m->'alternatives' else '[]'::jsonb end, p_evento)
  on conflict (id) do nothing;
  if found then
    select numero_ifood into v_num from ifood_pedidos where pedido_ifood = p_pedido;
    perform _push_enviar('pedido', '⚠️ iFood: cliente pediu cancelamento/reembolso #' || coalesce(v_num, ''), 'Responda no painel (Integrações → iFood) antes do prazo.', 'ifood-neg-' || v_id);
    perform _integ_log('ifood', 'aviso', 'Negociação de cancelamento no pedido #' || coalesce(v_num, p_pedido));
    perform _auditar('Negociação do iFood recebida', 'Pedido iFood #' || coalesce(v_num, p_pedido) || ' · ' || coalesce(m->>'handshakeType', ''));
  end if;
  return jsonb_build_object('ok', true);
end $f$;

create or replace function public.ifood_negociacao_fim(p_evento jsonb, p_pedido text) returns void
 language plpgsql security definer set search_path to 'public' as $f$
declare m jsonb := coalesce(p_evento->'metadata', '{}'::jsonb); v_id text := coalesce(nullif(m->>'disputeId', ''), nullif(m->>'handshakeId', ''));
begin
  update ifood_negociacoes set estado = case when estado = 'aberta' then 'encerrada' else estado end, respondido_em = coalesce(respondido_em, now())
   where (v_id is not null and id = v_id) or (v_id is null and pedido_ifood = p_pedido and estado = 'aberta');
end $f$;

-- ---------- loja ----------
create or replace function public.ifood_loja_gravar(p_status jsonb, p_interrupcao text default null) returns void
 language plpgsql security definer set search_path to 'public' as $f$
declare v_disp boolean; v_sit text;
begin
  v_sit := coalesce(p_status->0->>'state', p_status->>'state', p_status->>'status', '');
  v_disp := coalesce((p_status->0->>'available')::boolean, (p_status->>'available')::boolean, upper(v_sit) in ('OK', 'AVAILABLE', 'OPEN'));
  update ifood_loja set situacao = left(v_sit, 60), disponivel = v_disp,
    motivo = left(coalesce(p_status->0->'validations'->0->>'message', p_status->0->>'message', p_status->>'message', ''), 200),
    interrupcao_id = coalesce(p_interrupcao, interrupcao_id), verificado_em = now(), bruto = p_status, atualizado_em = now() where id;
end $f$;

create or replace function public.ifood_loja_estado() returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select to_jsonb(l) from ifood_loja l where id
$f$;

-- pausa que venceu: volta sozinho a aceitar pedidos
create or replace function public.ifood_loja_verificar() returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare l ifood_loja%rowtype;
begin
  select * into l from ifood_loja where id;
  if l.pausada_ate is not null and l.pausada_ate < now() and not l.fechada_por_nos then
    update ifood_loja set pausada_ate = null where id;
    perform public._ifood_enfileirar('LOJA', 'loja_retomar', '{}'::jsonb);
  end if;
  update ifood_negociacoes set estado = 'expirada' where estado = 'aberta' and expira_em < now() - interval '2 minutes';
  return jsonb_build_object('ok', true);
end $f$;

-- abrir/fechar junto com o caixa (opcional, ajuste "abrirFecharComCaixa")
create or replace function public._ifood_trg_caixa() returns trigger language plpgsql security definer set search_path to 'public' as $f$
begin
  if not public._integracao_ligada('ifood') then return null; end if;
  if not coalesce((select (config->>'abrirFecharComCaixa')::boolean from integracoes_config where provedor = 'ifood'), false) then return null; end if;
  if tg_op = 'INSERT' and new.status::text = 'Aberto' then
    update ifood_loja set fechada_por_nos = false, pausada_ate = null where id;
    perform public._ifood_enfileirar('LOJA', 'loja_abrir', '{}'::jsonb);
  elsif tg_op = 'UPDATE' and old.status::text = 'Aberto' and new.status::text <> 'Aberto' then
    update ifood_loja set fechada_por_nos = true where id;
    perform public._ifood_enfileirar('LOJA', 'loja_fechar', '{}'::jsonb);
  end if;
  return null;
end $f$;
drop trigger if exists trg_ifood_caixa on public.caixa_sessoes;
create trigger trg_ifood_caixa after insert or update of status on public.caixa_sessoes for each row execute function public._ifood_trg_caixa();

-- ---------- telas do administrador ----------
create or replace function public.api_ifood_negociacoes(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'itens', coalesce((select jsonb_agg(jsonb_build_object('id', n.id, 'pedido', i.numero_ifood, 'tipo', n.tipo, 'motivo', n.motivo, 'expiraEm', n.expira_em,
      'segundos', greatest(0, round(extract(epoch from (n.expira_em - now())))), 'estado', n.estado, 'alternativas', n.alternativas, 'em', n.criado_em) order by n.criado_em desc)
    from (select * from ifood_negociacoes order by criado_em desc limit 15) n left join ifood_pedidos i on i.pedido_ifood = n.pedido_ifood), '[]'::jsonb));
end $f$;

create or replace function public.api_ifood_negociacao_responder(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare n ifood_negociacoes%rowtype; v_acao text := p->>'acao'; v_login text;
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  select * into n from ifood_negociacoes where id = p->>'id' for update;
  if not found then return _falha('Negociação não encontrada.'); end if;
  if n.estado <> 'aberta' then return _falha('Esta negociação já foi respondida ou encerrada.'); end if;
  if n.expira_em < now() then return _falha('O prazo para responder acabou; o iFood decide.'); end if;
  if v_acao not in ('aceitar', 'recusar', 'alternativa') then return _falha('Resposta inválida.'); end if;
  select login into v_login from usuarios where id = auth.uid();
  update ifood_negociacoes set estado = case v_acao when 'aceitar' then 'aceita' when 'recusar' then 'recusada' else 'alternativa' end, respondido_em = now(), resposta_por = v_login where id = n.id;
  perform public._ifood_enfileirar(n.pedido_ifood, 'negociacao_' || v_acao, jsonb_build_object('disputa', n.id, 'alternativaId', p->>'alternativaId', 'motivo', left(coalesce(p->>'motivo', ''), 200)));
  perform _auditar('Negociação do iFood respondida', 'Pedido ' || n.pedido_ifood || ' · ' || v_acao || ' por ' || coalesce(v_login, ''));
  return jsonb_build_object('ok', true, 'message', 'Resposta enviada ao iFood.') || api_ifood_negociacoes('{}');
end $f$;

create or replace function public.api_ifood_loja(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'loja', (select to_jsonb(l) - 'bruto' from ifood_loja l where id), 'ligado', _integracao_ligada('ifood'));
end $f$;

create or replace function public.api_ifood_loja_acao(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_acao text := p->>'acao'; v_min int := coalesce(nullif(p->>'minutos', '')::int, 30);
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  if not _integracao_ligada('ifood') then return _falha('O iFood está desligado.'); end if;
  if v_acao = 'pausar' then
    if v_min < 5 or v_min > 480 then return _falha('Escolha entre 5 minutos e 8 horas.'); end if;
    update ifood_loja set pausada_ate = now() + make_interval(mins => v_min), fechada_por_nos = false where id;
    perform _ifood_enfileirar('LOJA', 'loja_pausar', jsonb_build_object('minutos', v_min));
  elsif v_acao = 'retomar' then
    update ifood_loja set pausada_ate = null, fechada_por_nos = false where id;
    perform _ifood_enfileirar('LOJA', 'loja_retomar', '{}'::jsonb);
  elsif v_acao = 'fechar' then
    update ifood_loja set fechada_por_nos = true where id;
    perform _ifood_enfileirar('LOJA', 'loja_fechar', '{}'::jsonb);
  elsif v_acao = 'abrir' then
    update ifood_loja set fechada_por_nos = false, pausada_ate = null where id;
    perform _ifood_enfileirar('LOJA', 'loja_abrir', '{}'::jsonb);
  else return _falha('Ação inválida.'); end if;
  perform _auditar('Loja no iFood', v_acao || case when v_acao = 'pausar' then ' ' || v_min || ' min' else '' end);
  return jsonb_build_object('ok', true, 'message', 'Pedido enviado ao iFood (confira o estado em instantes).') || api_ifood_loja('{}');
end $f$;

-- ---------- saúde: acrescenta loja e negociações ao item iFood ----------
create or replace function public._saude_ifood_extra() returns text language plpgsql stable security definer set search_path to 'public' as $f$
declare l ifood_loja%rowtype; v_neg int; v_urg int; v_txt text := '';
begin
  select * into l from ifood_loja where id;
  select count(*), count(*) filter (where expira_em < now() + interval '3 minutes') into v_neg, v_urg from ifood_negociacoes where estado = 'aberta' and expira_em > now();
  if l.verificado_em is not null then v_txt := v_txt || ' · loja: ' || case when l.disponivel then 'ABERTA no iFood' else 'FECHADA/indisponível no iFood' end || case when l.pausada_ate is not null then ' (pausada até ' || to_char(l.pausada_ate at time zone 'America/Sao_Paulo', 'HH24:MI') || ')' else '' end; end if;
  if v_neg > 0 then v_txt := v_txt || ' · ' || v_neg || ' negociação(ões) de cancelamento esperando resposta' || case when v_urg > 0 then ' (URGENTE)' else '' end; end if;
  return v_txt;
end $f$;

create or replace function public._saude_integracoes() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_desc int; e ifood_estado%rowtype; v_min numeric; v_sem int; v_novos int; v_acoes int; v_nivel text; v_txt text; v_urg int;
begin
  if exists (select 1 from ai_segredos where provedor = 'nvidia') or exists (select 1 from ai_segredos where provedor = 'cloudflare') then
    select count(*) into v_desc from unnest(array['nvidia', 'cloudflare']) x(p) where _ia_provedor_descansando(x.p);
    v := v || jsonb_build_object('id', 'ia_extras', 'titulo', 'IAs de reserva (NVIDIA / Cloudflare)', 'nivel', case when v_desc > 0 then 'atencao' else 'ok' end,
      'texto', (select string_agg(x.rot || ': ' || case when not exists (select 1 from ai_segredos where provedor = x.p) then 'sem chave' when _ia_provedor_descansando(x.p) then 'descansando (erros recentes)' else 'pronta' end, ' · ')
                from (values ('nvidia', 'NVIDIA'), ('cloudflare', 'Cloudflare')) x(p, rot)));
  end if;
  if _integracao_ligada('ifood') then
    select * into e from ifood_estado where id;
    v_min := case when e.ultima_consulta_ok is null then null else extract(epoch from (now() - e.ultima_consulta_ok)) / 60 end;
    select coalesce(sum(itens_sem_ligacao), 0) into v_sem from ifood_pedidos where estado <> 'cancelado' and criado_em > now() - interval '7 days';
    select count(*) into v_novos from ifood_pedidos where estado = 'novo' and not simulado and criado_em < now() - interval '4 minutes';
    select count(*) into v_acoes from ifood_acoes where estado in ('erro', 'duvida') and criado_em > now() - interval '1 day';
    select count(*) into v_urg from ifood_negociacoes where estado = 'aberta' and expira_em > now() and expira_em < now() + interval '3 minutes';
    v_nivel := case when v_min is null or v_min > 2 or e.token_ok is false or v_novos > 0 or v_urg > 0 then 'problema' when v_acoes > 0 or v_sem > 0 or e.ultimo_erro is not null or exists (select 1 from ifood_negociacoes where estado = 'aberta' and expira_em > now()) then 'atencao' else 'ok' end;
    v_txt := case when v_min is null then 'Ligado, mas ainda sem nenhuma consulta bem-sucedida ao iFood.' else 'Última consulta ao iFood há ' || round(v_min, 1) || ' min' end
      || case when e.ultimo_pedido_em is not null then ' · último pedido às ' || to_char(e.ultimo_pedido_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') else ' · nenhum pedido ainda' end
      || case when e.token_ok is false then ' · ACESSO RECUSADO (confira as chaves)' else '' end
      || case when v_novos > 0 then ' · ' || v_novos || ' pedido(s) esperando confirmação há mais de 4 min' else '' end
      || case when v_acoes > 0 then ' · ' || v_acoes || ' ação(ões) não confirmada(s) no iFood' else '' end
      || case when v_sem > 0 then ' · ' || v_sem || ' item(ns) sem ligação' else '' end || public._saude_ifood_extra();
    v := v || jsonb_build_object('id', 'ifood', 'titulo', 'iFood', 'nivel', v_nivel, 'texto', v_txt);
  end if;
  for r in select * from integracoes_config where ligado and provedor = 'nfce' loop
    v := v || jsonb_build_object('id', 'nfce', 'titulo', 'Nota fiscal (NFC-e)', 'nivel', 'atencao', 'texto', 'Ligada (' || r.modo || '), aguardando a primeira nota.');
  end loop;
  return v;
end $f$;

-- ---------- permissões ----------
revoke execute on function public.ifood_negociacao_registrar(jsonb, text), public.ifood_negociacao_fim(jsonb, text), public.ifood_loja_gravar(jsonb, text), public.ifood_loja_estado(), public.ifood_loja_verificar(),
  public._ifood_trg_caixa(), public._saude_ifood_extra() from public, anon, authenticated;
grant execute on function public.ifood_negociacao_registrar(jsonb, text), public.ifood_negociacao_fim(jsonb, text), public.ifood_loja_gravar(jsonb, text), public.ifood_loja_estado(), public.ifood_loja_verificar() to service_role;
revoke execute on function public.api_ifood_negociacoes(jsonb), public.api_ifood_negociacao_responder(jsonb), public.api_ifood_loja(jsonb), public.api_ifood_loja_acao(jsonb) from public, anon;
grant execute on function public.api_ifood_negociacoes(jsonb), public.api_ifood_negociacao_responder(jsonb), public.api_ifood_loja(jsonb), public.api_ifood_loja_acao(jsonb) to authenticated;

insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-104-ifood-operacao','iFood: negociação de cancelamento e loja','ifood cancelamento negociação reembolso aceitar recusar alternativa pausar loja abrir fechar',
 E'Quando o cliente pede cancelamento ou reembolso no iFood, a equipe recebe um aviso no celular. Abra Contas e acessos → Integrações → iFood → "Negociações": veja o pedido e o prazo, e toque em Aceitar, Recusar ou, quando houver, em uma alternativa. Se o prazo acabar, o iFood decide.\nLoja no iFood: o mesmo cartão tem os botões "Pausar 30 min / 1 h", "Retomar", "Fechar" e "Abrir". Com o ajuste "Abrir e fechar a loja no iFood junto com o caixa" ligado, abrir o caixa abre a loja e fechar o caixa fecha.\nO painel de Saúde mostra se a loja está aberta ou indisponível no iFood.',
 array['Admin','Operador'],true,'lista',104,'Pausar, abrir e fechar: Administrador e Operador.'
where not exists (select 1 from ai_ajuda where slug='man-admin-104-ifood-operacao');


-- ################ PARTE: f3-ifood-inteligencia ################
-- =====================================================================
-- FASE 3 — iFOOD INTELIGÊNCIA · 2026-10-11
-- Importar/enviar preços (com trava de segurança, histórico e desfazer), pausar item sem estoque,
-- financeiro (a receber do iFood, repasses, comissão real), avaliações, relatório por canal.
-- Precisa das Fases 0, 1 e 2 antes. Seguro para rodar de novo. TUDO DESLIGADO.
-- ⚠️ Endereços do catálogo, financeiro e avaliações do iFood vêm de fontes de terceiros: ainda não testado com o iFood de verdade.
-- =====================================================================

alter table public.ifood_itens add column if not exists ifood_item_id text;           -- id do item dentro do iFood (para preço e pausa)
alter table public.ifood_itens add column if not exists preco_ifood numeric;
alter table public.ifood_itens add column if not exists preco_visto_em timestamptz;
alter table public.ifood_itens add column if not exists categoria text;
alter table public.ifood_itens add column if not exists pausado_por_nos boolean not null default false;
alter table public.ifood_pedidos add column if not exists repassado_em timestamptz;
alter table public.ifood_pedidos add column if not exists repasse_id text;
alter table public.ifood_pedidos add column if not exists comissao numeric;
alter table public.ifood_estado add column if not exists financeiro_em timestamptz;
alter table public.ifood_estado add column if not exists avaliacoes_em timestamptz;

alter table public.ifood_acoes drop constraint if exists ifood_acoes_acao_check;
alter table public.ifood_acoes add constraint ifood_acoes_acao_check check (acao in
  ('confirmar','iniciar_preparo','pronto','despachar','cancelar','negociacao_aceitar','negociacao_recusar','negociacao_alternativa','loja_fechar','loja_abrir','loja_pausar','loja_retomar',
   'catalogo_importar','catalogo_preco','catalogo_pausar','catalogo_retomar','avaliacao_responder'));

-- a trava de "uma ação pendente por pedido" agora também separa por item/avaliação/disputa (várias pausas e preços podem esperar ao mesmo tempo)
drop index if exists public.ifood_acoes_pend_uk;
create unique index if not exists ifood_acoes_pend_uk2 on public.ifood_acoes (pedido_ifood, acao, (coalesce(dados->>'chave', dados->>'avaliacao', dados->>'disputa', ''))) where estado in ('pendente','duvida');

create table if not exists public.ifood_precos_hist (
  id bigserial primary key, quando timestamptz not null default now(), chave text not null, nome text,
  preco_antes numeric, preco_depois numeric, origem text not null check (origem in ('importar','enviar','desfazer')),
  usuario text, estado text not null default 'pendente' check (estado in ('pendente','ok','erro','desfeito')), erro text);
alter table public.ifood_precos_hist enable row level security;

create table if not exists public.ifood_repasses (
  id text primary key, pago_em date, periodo_ini date, periodo_fim date, valor numeric not null default 0,
  pedidos int not null default 0, bruto jsonb, criado_em timestamptz not null default now());
alter table public.ifood_repasses enable row level security;

create table if not exists public.ifood_avaliacoes (
  id text primary key, pedido_ifood text, nota int, comentario text, criada_em timestamptz, resposta text, respondida_em timestamptz,
  feedback_id uuid, bruto jsonb, visto_em timestamptz not null default now());
alter table public.ifood_avaliacoes enable row level security;

-- ---------- preço do iFood no sistema = linha da forma de pagamento "iFood" (preço próprio) ----------
create or replace function public._ifood_forma() returns uuid language sql stable security definer set search_path to 'public' as $f$
  select id from formas_pagamento where lower(nome) = 'ifood' order by preco_proprio desc limit 1
$f$;

create or replace function public._ifood_preco_sistema(p_item ifood_itens) returns numeric language sql stable security definer set search_path to 'public' as $f$
  select coalesce(
    (select pp.preco from produto_precos pp where pp.produto_id = p_item.produto_id and pp.forma_pagamento_id = public._ifood_forma()),
    (select min(pp.preco) from produto_precos pp where pp.produto_id = p_item.produto_id),
    (select cp.preco from combo_precos cp where cp.combo_id = p_item.combo_id and cp.forma_pagamento_id = public._ifood_forma()),
    (select min(cp.preco) from combo_precos cp where cp.combo_id = p_item.combo_id))
$f$;

-- catálogo trazido do iFood (servidor): atualiza itens e preços vistos
create or replace function public.ifood_catalogo_gravar(p_itens jsonb) returns int language plpgsql security definer set search_path to 'public' as $f$
declare e jsonb; v_n int := 0; r ifood_itens%rowtype; v_chave text;
begin
  for e in select value from jsonb_array_elements(coalesce(p_itens, '[]'::jsonb)) loop
    v_chave := coalesce(nullif(e->>'externalCode', ''), nullif(e->>'id', ''));
    if v_chave is null then continue; end if;
    r := public._ifood_item_visto(v_chave, e->>'name', 'produto');
    update ifood_itens set ifood_item_id = coalesce(nullif(e->>'id', ''), ifood_item_id), preco_ifood = case when e ? 'price' then public._ifood_n(e->'price') else preco_ifood end,
      preco_visto_em = now(), categoria = left(coalesce(nullif(e->>'category', ''), categoria), 120) where chave = v_chave;
    v_n := v_n + 1;
  end loop;
  perform public._integ_log('ifood', 'info', 'Catálogo do iFood importado: ' || v_n || ' item(ns)');
  return v_n;
end $f$;

create or replace function public.ifood_preco_confirmar(p_id bigint, p_ok boolean, p_erro text default null) returns void language plpgsql security definer set search_path to 'public' as $f$
declare h ifood_precos_hist%rowtype;
begin
  update ifood_precos_hist set estado = case when p_ok then 'ok' else 'erro' end, erro = left(p_erro, 300) where id = p_id returning * into h;
  if p_ok and h.id is not null then update ifood_itens set preco_ifood = h.preco_depois, preco_visto_em = now() where chave = h.chave; end if;
end $f$;

-- tela: preços sistema × iFood
create or replace function public.api_ifood_precos(p jsonb default '{}'::jsonb) returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare v_lim numeric := coalesce((select (config->>'limitePrecoPct')::numeric from integracoes_config where provedor = 'ifood'), 30);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'limitePct', v_lim, 'enviarLigado', coalesce((select (config->>'enviarPrecos')::boolean from integracoes_config where provedor = 'ifood'), false),
    'itens', coalesce((select jsonb_agg(x order by (x->>'nome')) from (
      select jsonb_build_object('chave', i.chave, 'nome', coalesce((select nome from produtos where id = i.produto_id), (select nome from combos where id = i.combo_id)), 'nomeIfood', i.nome,
        'precoSistema', public._ifood_preco_sistema(i), 'precoIfood', i.preco_ifood, 'visto', i.preco_visto_em,
        'diff', round(coalesce(i.preco_ifood, 0) - coalesce(public._ifood_preco_sistema(i), 0), 2),
        'pct', case when coalesce(public._ifood_preco_sistema(i), 0) > 0 and i.preco_ifood is not null then round(abs(i.preco_ifood - public._ifood_preco_sistema(i)) / public._ifood_preco_sistema(i) * 100, 1) end,
        'podeEnviar', i.ifood_item_id is not null) x
      from ifood_itens i where (i.produto_id is not null or i.combo_id is not null) and not i.ignorar) t), '[]'::jsonb),
    'historico', coalesce((select jsonb_agg(jsonb_build_object('id', h.id, 'quando', h.quando, 'nome', h.nome, 'antes', h.preco_antes, 'depois', h.preco_depois, 'origem', h.origem, 'estado', h.estado, 'erro', h.erro) order by h.id desc)
      from (select * from ifood_precos_hist order by id desc limit 30) h), '[]'::jsonb));
end $f$;

create or replace function public.api_ifood_precos_pedir_catalogo(p jsonb default '{}'::jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not _integracao_ligada('ifood') then return _falha('O iFood está desligado.'); end if;
  perform _ifood_enfileirar('LOJA', 'catalogo_importar', '{}'::jsonb);
  return jsonb_build_object('ok', true, 'message', 'Pedido enviado: em cerca de 1 minuto o cardápio do iFood aparece aqui. Atualize a lista.');
end $f$;

-- importar: grava o preço do iFood no campo "Preço no iFood" do sistema (linha da forma iFood)
create or replace function public.api_ifood_precos_aplicar(p jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare r ifood_itens%rowtype; v_forma uuid := public._ifood_forma(); v_chave text; v_n int := 0; v_antes numeric; v_login text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_forma is null then return _falha('Cadastre a forma de pagamento "iFood" (com preço próprio) em Pagamentos antes de importar preços.'); end if;
  select login into v_login from usuarios where id = auth.uid();
  for v_chave in select jsonb_array_elements_text(coalesce(p->'chaves', '[]'::jsonb)) loop
    select * into r from ifood_itens where chave = v_chave and preco_ifood is not null and preco_ifood > 0;
    if not found then continue; end if;
    v_antes := public._ifood_preco_sistema(r);
    if r.produto_id is not null then
      update produto_precos set preco = r.preco_ifood where produto_id = r.produto_id and forma_pagamento_id = v_forma;
      if not found then insert into produto_precos (produto_id, forma_pagamento_id, preco, custo) values (r.produto_id, v_forma, r.preco_ifood, coalesce((select min(custo) from produto_precos where produto_id = r.produto_id), 0)); end if;
    elsif r.combo_id is not null then
      update combo_precos set preco = r.preco_ifood where combo_id = r.combo_id and forma_pagamento_id = v_forma;
      if not found then insert into combo_precos (combo_id, forma_pagamento_id, preco, custo) values (r.combo_id, v_forma, r.preco_ifood, coalesce((select min(custo) from combo_precos where combo_id = r.combo_id), 0)); end if;
    else continue; end if;
    insert into ifood_precos_hist (chave, nome, preco_antes, preco_depois, origem, usuario, estado) values (r.chave, r.nome, v_antes, r.preco_ifood, 'importar', v_login, 'ok');
    v_n := v_n + 1;
  end loop;
  perform _auditar('Preços importados do iFood', v_n || ' item(ns)');
  return jsonb_build_object('ok', true, 'message', v_n || ' preço(s) do iFood gravado(s) no sistema.') || api_ifood_precos('{}');
end $f$;

-- enviar nossos preços ao iFood: só com o ajuste ligado, trava de variação e histórico
create or replace function public.api_ifood_precos_enviar(p jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare r ifood_itens%rowtype; v_chave text; v_novo numeric; v_lim numeric := coalesce((select (config->>'limitePrecoPct')::numeric from integracoes_config where provedor = 'ifood'), 30);
        v_n int := 0; v_bloq text[] := '{}'; v_id bigint; v_login text; v_pct numeric;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not _integracao_ligada('ifood') then return _falha('O iFood está desligado.'); end if;
  if not coalesce((select (config->>'enviarPrecos')::boolean from integracoes_config where provedor = 'ifood'), false) then return _falha('Ligue antes o ajuste "Enviar nossos preços ao iFood".'); end if;
  if coalesce(p->>'confirmar', '') <> 'true' then return _falha('Confirme o envio.'); end if;
  select login into v_login from usuarios where id = auth.uid();
  for v_chave in select jsonb_array_elements_text(coalesce(p->'chaves', '[]'::jsonb)) loop
    select * into r from ifood_itens where chave = v_chave;
    if not found or r.ifood_item_id is null then v_bloq := v_bloq || (coalesce(r.nome, v_chave) || ' (importe o cardápio do iFood antes)'); continue; end if;
    v_novo := public._ifood_preco_sistema(r);
    if v_novo is null or v_novo <= 0 then continue; end if;
    if r.preco_ifood is not null and r.preco_ifood > 0 and abs(r.preco_ifood - v_novo) < 0.005 then continue; end if;
    v_pct := case when coalesce(r.preco_ifood, 0) > 0 then abs(v_novo - r.preco_ifood) / r.preco_ifood * 100 else 0 end;
    if v_pct > v_lim and coalesce(p->>'ignorarLimite', '') <> 'true' then v_bloq := v_bloq || (r.nome || ' (' || round(v_pct) || '% de variação, acima do limite de ' || v_lim || '%)'); continue; end if;
    insert into ifood_precos_hist (chave, nome, preco_antes, preco_depois, origem, usuario) values (r.chave, r.nome, r.preco_ifood, v_novo, 'enviar', v_login) returning id into v_id;
    insert into ifood_acoes (pedido_ifood, acao, dados) values ('LOJA', 'catalogo_preco', jsonb_build_object('chave', r.chave, 'itemId', r.ifood_item_id, 'preco', v_novo, 'hist', v_id)) on conflict do nothing;
    v_n := v_n + 1;
  end loop;
  perform _auditar('Preços enviados ao iFood', v_n || ' item(ns)' || case when array_length(v_bloq, 1) > 0 then ' · bloqueados: ' || array_length(v_bloq, 1) else '' end);
  return jsonb_build_object('ok', true, 'message', v_n || ' preço(s) enviado(s) ao iFood.' || case when array_length(v_bloq, 1) > 0 then ' Não enviados: ' || array_to_string(v_bloq, '; ') else '' end) || api_ifood_precos('{}');
end $f$;

create or replace function public.api_ifood_precos_desfazer(p jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare h ifood_precos_hist%rowtype; i ifood_itens%rowtype; v_id bigint;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into h from ifood_precos_hist where id = (p->>'id')::bigint for update;
  if not found or h.origem <> 'enviar' or h.estado <> 'ok' then return _falha('Só dá para desfazer um envio já concluído.'); end if;
  if h.preco_antes is null then return _falha('Não há preço anterior guardado.'); end if;
  select * into i from ifood_itens where chave = h.chave;
  update ifood_precos_hist set estado = 'desfeito' where id = h.id;
  insert into ifood_precos_hist (chave, nome, preco_antes, preco_depois, origem, usuario) values (h.chave, h.nome, h.preco_depois, h.preco_antes, 'desfazer', coalesce((select login from usuarios where id = auth.uid()), '')) returning id into v_id;
  insert into ifood_acoes (pedido_ifood, acao, dados) values ('LOJA', 'catalogo_preco', jsonb_build_object('chave', h.chave, 'itemId', i.ifood_item_id, 'preco', h.preco_antes, 'hist', v_id)) on conflict do nothing;
  perform _auditar('Envio de preço desfeito', h.nome);
  return jsonb_build_object('ok', true, 'message', 'Preço anterior reenviado ao iFood.') || api_ifood_precos('{}');
end $f$;

-- ---------- pausar item no iFood quando o ingrediente acaba (opcional) ----------
create or replace function public._ifood_trg_estoque() returns trigger language plpgsql security definer set search_path to 'public' as $f$
declare r record;
begin
  if not public._integracao_ligada('ifood') then return null; end if;
  if not coalesce((select (config->>'pausarSemEstoque')::boolean from integracoes_config where provedor = 'ifood'), false) then return null; end if;
  if new.quantidade <= 0 and coalesce(old.quantidade, 1) > 0 then
    for r in select distinct ii.chave, ii.ifood_item_id from ifood_itens ii join produto_ingredientes pi on pi.produto_id = ii.produto_id
             where pi.ingrediente_id = new.id and ii.ifood_item_id is not null and not ii.pausado_por_nos and not ii.ignorar loop
      update ifood_itens set pausado_por_nos = true where chave = r.chave;
      insert into ifood_acoes (pedido_ifood, acao, dados) values ('LOJA', 'catalogo_pausar', jsonb_build_object('chave', r.chave, 'itemId', r.ifood_item_id)) on conflict do nothing;
    end loop;
  elsif new.quantidade > 0 and coalesce(old.quantidade, 0) <= 0 then
    for r in select distinct ii.chave, ii.ifood_item_id from ifood_itens ii join produto_ingredientes pi on pi.produto_id = ii.produto_id
             where pi.ingrediente_id = new.id and ii.pausado_por_nos
               and not exists (select 1 from produto_ingredientes p2 join estoque e2 on e2.id = p2.ingrediente_id where p2.produto_id = ii.produto_id and e2.quantidade <= 0) loop
      update ifood_itens set pausado_por_nos = false where chave = r.chave;
      insert into ifood_acoes (pedido_ifood, acao, dados) values ('LOJA', 'catalogo_retomar', jsonb_build_object('chave', r.chave, 'itemId', r.ifood_item_id)) on conflict do nothing;
    end loop;
  end if;
  return null;
exception when others then return null;     -- nunca atrapalhar a venda/estoque por causa do iFood
end $f$;
drop trigger if exists trg_ifood_estoque on public.estoque;
create trigger trg_ifood_estoque after update of quantidade on public.estoque for each row when (new.quantidade is distinct from old.quantidade) execute function public._ifood_trg_estoque();

create or replace function public.ifood_log(p_nivel text, p_msg text) returns void language sql security definer set search_path to 'public' as $f$
  select public._integ_log('ifood', case when p_nivel in ('info','aviso','erro') then p_nivel else 'info' end, p_msg)
$f$;

-- ---------- tarefas periódicas (o servidor pergunta se já está na hora) ----------
create or replace function public.ifood_precisa(p_tarefa text, p_minutos int) returns boolean language plpgsql security definer set search_path to 'public' as $f$
declare v timestamptz;
begin
  select case p_tarefa when 'financeiro' then financeiro_em when 'avaliacoes' then avaliacoes_em end into v from ifood_estado where id;
  if v is not null and v > now() - make_interval(mins => p_minutos) then return false; end if;
  if p_tarefa = 'financeiro' then update ifood_estado set financeiro_em = now() where id; else update ifood_estado set avaliacoes_em = now() where id; end if;
  return true;
end $f$;

-- ---------- financeiro: a receber do iFood, repasses, comissão real ----------
create or replace function public.ifood_repasses_gravar(p_lista jsonb) returns int language plpgsql security definer set search_path to 'public' as $f$
declare e jsonb; o jsonb; v_n int := 0; v_ped int;
begin
  for e in select value from jsonb_array_elements(coalesce(p_lista, '[]'::jsonb)) loop
    if nullif(e->>'id', '') is null then continue; end if;
    v_ped := 0;
    for o in select value from jsonb_array_elements(case when jsonb_typeof(e->'orders') = 'array' then e->'orders' else '[]'::jsonb end) loop
      update ifood_pedidos set repassado_em = coalesce(repassado_em, now()), repasse_id = e->>'id', comissao = coalesce(nullif(public._ifood_n(o->'commission'), 0), nullif(public._ifood_n(o->'fees'), 0), comissao)
       where pedido_ifood = coalesce(o->>'orderId', o->>'id');
      if found then v_ped := v_ped + 1; end if;
    end loop;
    insert into ifood_repasses (id, pago_em, periodo_ini, periodo_fim, valor, pedidos, bruto)
    values (e->>'id', nullif(e->>'paymentDate', '')::date, nullif(e->>'periodStart', '')::date, nullif(e->>'periodEnd', '')::date, public._ifood_n(coalesce(e->'amount', e->'value')), v_ped, e)
    on conflict (id) do update set valor = excluded.valor, pedidos = excluded.pedidos, pago_em = excluded.pago_em, bruto = excluded.bruto;
    v_n := v_n + 1;
  end loop;
  return v_n;
end $f$;

create or replace function public.api_ifood_financeiro(p jsonb default '{}'::jsonb) returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'aReceber', (select jsonb_build_object('pedidos', count(*), 'valor', coalesce(sum(v.valor_total), 0))
       from ifood_pedidos i join vendas v on v.id = i.venda_id
       where not i.simulado and v.status = 'Confirmada' and i.repassado_em is null and i.estado <> 'cancelado'
         and exists (select 1 from pagamentos_venda pv where pv.venda_id = v.id and pv.forma_pagamento = 'iFood (pago no app)')),
    'recebido30d', (select jsonb_build_object('repasses', count(*), 'valor', coalesce(sum(valor), 0)) from ifood_repasses where coalesce(pago_em, criado_em::date) >= current_date - 30),
    'comissao30d', (select coalesce(sum(comissao), 0) from ifood_pedidos where repassado_em > now() - interval '30 days'),
    'repasses', coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'pagoEm', r.pago_em, 'valor', r.valor, 'pedidos', r.pedidos) order by r.pago_em desc nulls last) from (select * from ifood_repasses order by coalesce(pago_em, criado_em::date) desc limit 15) r), '[]'::jsonb));
end $f$;

-- ---------- avaliações ----------
create or replace function public.ifood_avaliacoes_gravar(p_lista jsonb) returns int language plpgsql security definer set search_path to 'public' as $f$
declare e jsonb; v_n int := 0; v_fb uuid; v_venda uuid; v_nota int; v_ja boolean; v_num text;
begin
  for e in select value from jsonb_array_elements(coalesce(p_lista, '[]'::jsonb)) loop
    if nullif(e->>'id', '') is null then continue; end if;
    v_ja := exists (select 1 from ifood_avaliacoes where id = e->>'id');
    v_nota := round(public._ifood_n(coalesce(e->'score', e->'rating', e->'nota')))::int;
    select venda_id, numero_ifood into v_venda, v_num from ifood_pedidos where pedido_ifood = e->>'orderId';
    insert into ifood_avaliacoes (id, pedido_ifood, nota, comentario, criada_em, resposta, bruto)
    values (e->>'id', e->>'orderId', v_nota, left(coalesce(e->>'comment', e->>'text', ''), 1000), nullif(e->>'createdAt', '')::timestamptz,
            nullif(coalesce(e->'replies'->0->>'text', e->>'reply'), ''), e)
    on conflict (id) do update set resposta = coalesce(excluded.resposta, ifood_avaliacoes.resposta), nota = excluded.nota;
    if not v_ja then
      begin
        insert into feedbacks (venda_id, nota, comentario, data, status, origem) values (v_venda, greatest(least(v_nota, 5), 1), left(coalesce(e->>'comment', e->>'text', ''), 1000), coalesce(nullif(e->>'createdAt', '')::timestamptz, now()), 'Novo', 'iFood') returning id into v_fb;
        update ifood_avaliacoes set feedback_id = v_fb where id = e->>'id';
      exception when others then null; end;
      if v_nota <= 2 then perform _push_enviar('feedback', '⭐ Avaliação baixa no iFood (' || v_nota || ')', coalesce(left(e->>'comment', 100), 'Veja no painel'), 'ifood-aval-' || (e->>'id')); end if;
      v_n := v_n + 1;
    end if;
  end loop;
  return v_n;
end $f$;

create or replace function public.api_ifood_avaliacoes(p jsonb default '{}'::jsonb) returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'media30d', (select round(avg(nota), 2) from ifood_avaliacoes where coalesce(criada_em, visto_em) > now() - interval '30 days'),
    'itens', coalesce((select jsonb_agg(jsonb_build_object('id', a.id, 'nota', a.nota, 'comentario', a.comentario, 'em', a.criada_em, 'resposta', a.resposta, 'pedido', i.numero_ifood) order by coalesce(a.criada_em, a.visto_em) desc)
      from (select * from ifood_avaliacoes order by coalesce(criada_em, visto_em) desc limit 20) a left join ifood_pedidos i on i.pedido_ifood = a.pedido_ifood), '[]'::jsonb));
end $f$;

create or replace function public.api_ifood_avaliacao_responder(p jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare v_texto text := btrim(coalesce(p->>'texto', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if length(v_texto) < 3 or length(v_texto) > 600 then return _falha('Escreva a resposta (3 a 600 letras).'); end if;
  if not exists (select 1 from ifood_avaliacoes where id = p->>'id') then return _falha('Avaliação não encontrada.'); end if;
  update ifood_avaliacoes set resposta = v_texto, respondida_em = now() where id = p->>'id';
  insert into ifood_acoes (pedido_ifood, acao, dados) values ('LOJA', 'avaliacao_responder', jsonb_build_object('avaliacao', p->>'id', 'texto', v_texto)) on conflict do nothing;
  perform _auditar('Resposta a avaliação do iFood', left(v_texto, 100));
  return jsonb_build_object('ok', true, 'message', 'Resposta enviada ao iFood.') || api_ifood_avaliacoes('{}');
end $f$;

-- ---------- relatório por canal ----------
create or replace function public.api_ifood_relatorio(p jsonb default '{}'::jsonb) returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare v_dias int := least(greatest(coalesce(nullif(p->>'dias', '')::int, 30), 1), 365);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'dias', v_dias,
    'canais', coalesce((select jsonb_agg(jsonb_build_object('canal', c, 'pedidos', n, 'total', t, 'ticket', case when n > 0 then round(t / n, 2) else 0 end, 'custo', k, 'margem', t - k,
          'margemPct', case when t > 0 then round((t - k) / t * 100, 1) else 0 end, 'cancelados', cx) order by t desc)
      from (select case when canal = 'iFood' then 'iFood' when origem::text = 'Cardápio' then 'Cardápio' when origem::text = 'Garçom' then 'Garçom' else 'Balcão' end c,
                   count(*) filter (where status = 'Confirmada') n, coalesce(sum(valor_total) filter (where status = 'Confirmada'), 0) t,
                   coalesce(sum(custo_total) filter (where status = 'Confirmada'), 0) k, count(*) filter (where status = 'Cancelada') cx
            from vendas where data_hora > now() - make_interval(days => v_dias) group by 1) x), '[]'::jsonb),
    'ifood', jsonb_build_object(
      'confirmacaoMediaMin', (select round(avg(extract(epoch from (confirmado_em - criado_em)) / 60)::numeric, 1) from ifood_pedidos where confirmado_em is not null and not simulado and criado_em > now() - make_interval(days => v_dias)),
      'itensSemLigacao', (select coalesce(sum(itens_sem_ligacao), 0) from ifood_pedidos where criado_em > now() - make_interval(days => v_dias) and estado <> 'cancelado'),
      'comissaoReal', (select coalesce(sum(comissao), 0) from ifood_pedidos where comissao is not null and criado_em > now() - make_interval(days => v_dias)),
      'cancelamentos', coalesce((select jsonb_agg(jsonb_build_object('motivo', m, 'qtd', q) order by q desc) from (select coalesce(nullif(motivo_cancelamento, ''), 'sem motivo') m, count(*) q from vendas where canal = 'iFood' and status = 'Cancelada' and data_hora > now() - make_interval(days => v_dias) group by 1) y), '[]'::jsonb),
      'maisVendidos', coalesce((select jsonb_agg(jsonb_build_object('nome', n, 'qtd', q) order by q desc) from (select left(iv.descricao, 60) n, sum(iv.quantidade) q from itens_venda iv join vendas v on v.id = iv.venda_id where v.canal = 'iFood' and v.status = 'Confirmada' and v.data_hora > now() - make_interval(days => v_dias) group by 1 order by 2 desc limit 8) z), '[]'::jsonb)));
end $f$;

-- ---------- permissões ----------
revoke execute on function public._ifood_forma(), public._ifood_preco_sistema(ifood_itens), public._ifood_trg_estoque(), public.ifood_catalogo_gravar(jsonb), public.ifood_preco_confirmar(bigint, boolean, text),
  public.ifood_precisa(text, int), public.ifood_repasses_gravar(jsonb), public.ifood_avaliacoes_gravar(jsonb), public.ifood_log(text, text) from public, anon, authenticated;
grant execute on function public.ifood_catalogo_gravar(jsonb), public.ifood_preco_confirmar(bigint, boolean, text), public.ifood_precisa(text, int), public.ifood_repasses_gravar(jsonb), public.ifood_avaliacoes_gravar(jsonb), public.ifood_log(text, text) to service_role;
revoke execute on function public.api_ifood_precos(jsonb), public.api_ifood_precos_pedir_catalogo(jsonb), public.api_ifood_precos_aplicar(jsonb), public.api_ifood_precos_enviar(jsonb), public.api_ifood_precos_desfazer(jsonb),
  public.api_ifood_financeiro(jsonb), public.api_ifood_avaliacoes(jsonb), public.api_ifood_avaliacao_responder(jsonb), public.api_ifood_relatorio(jsonb) from public, anon;
grant execute on function public.api_ifood_precos(jsonb), public.api_ifood_precos_pedir_catalogo(jsonb), public.api_ifood_precos_aplicar(jsonb), public.api_ifood_precos_enviar(jsonb), public.api_ifood_precos_desfazer(jsonb),
  public.api_ifood_financeiro(jsonb), public.api_ifood_avaliacoes(jsonb), public.api_ifood_avaliacao_responder(jsonb), public.api_ifood_relatorio(jsonb) to authenticated;

insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-105-ifood-inteligencia','iFood: preços, estoque, repasses, avaliações e relatório','ifood preço importar enviar desfazer pausar estoque repasse receber comissão avaliação relatório canal',
 E'Preços (Integrações → iFood → Preços): "Importar cardápio" traz os preços do iFood; a tabela mostra preço no sistema × preço no iFood × diferença. "Gravar no sistema" grava o preço do iFood no campo "Preço no iFood". "Enviar ao iFood" só funciona com o ajuste "Enviar nossos preços ao iFood" ligado, bloqueia variações acima do limite e guarda histórico com botão Desfazer.\nPausa por estoque: com o ajuste ligado, o item some do iFood quando um ingrediente acaba e volta quando repõe.\nFinanceiro: mostra quanto falta receber do iFood (pedidos pagos no app ainda sem repasse), os repasses recebidos e a comissão real.\nAvaliações: as notas do iFood aparecem aqui e em Feedbacks; nota baixa avisa a equipe; você responde pelo painel.\nRelatório por canal: vendas, ticket, margem e cancelamentos de balcão, cardápio e iFood.',
 array['Admin'],true,'lista',105,'Só Administrador.'
where not exists (select 1 from ai_ajuda where slug='man-admin-105-ifood-inteligencia');


-- ################ PARTE: f4-fiscal-cadastro ################
-- =====================================================================================
-- FASE 4 — Cadastro fiscal (base da Nota Fiscal do Consumidor, NFC-e)
-- Tudo NASCE DESLIGADO: não muda nenhuma tela de venda nem nenhum cálculo enquanto a integração "nfce" estiver desligada.
-- Idempotente (pode rodar mais de uma vez). Depende da f0 (integracoes_*).
-- =====================================================================================

-- 1) o CSC (código de segurança do contribuinte) é guardado como segredo, igual às demais chaves
do $d$
declare c record;
begin
  for c in select conname from pg_constraint where conrelid = 'public.integracoes_segredos'::regclass and contype = 'c' and pg_get_constraintdef(oid) like '%chave%' loop
    execute format('alter table public.integracoes_segredos drop constraint %I', c.conname);
  end loop;
  alter table public.integracoes_segredos add constraint integracoes_segredos_chave_check
    check (chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id', 'nfce_token_homologacao', 'nfce_token_producao', 'nfce_csc'));
end $d$;

-- 2) dados fiscais da empresa (uma única linha)
create table if not exists public.fiscal_empresa (
  id boolean primary key default true check (id),
  razao_social text, nome_fantasia text, cnpj text, inscricao_estadual text,
  regime text not null default 'simples' check (regime in ('mei', 'simples', 'normal')),
  cep text, logradouro text, numero text, complemento text, bairro text,
  municipio text, codigo_municipio text, uf text, telefone text,
  csc_id text,                                   -- identificador do CSC (o código secreto fica em integracoes_segredos)
  serie int not null default 1 check (serie between 1 and 999),
  aliquota_simples numeric(5,2) not null default 0 check (aliquota_simples between 0 and 40),  -- % efetiva do Simples, só para ESTIMAR o imposto no resultado
  perfil_padrao_id uuid,
  atualizado_em timestamptz not null default now()
);
alter table public.fiscal_empresa enable row level security;
insert into public.fiscal_empresa (id) values (true) on conflict (id) do nothing;

-- 3) perfis fiscais (o contador define; vale para vários produtos)
create table if not exists public.fiscal_perfis (
  id uuid primary key default gen_random_uuid(),
  nome text not null unique,
  ncm text not null check (ncm ~ '^[0-9]{8}$'),
  cest text check (cest is null or cest ~ '^[0-9]{7}$'),
  cfop text not null default '5102' check (cfop ~ '^[0-9]{4}$'),
  csosn text check (csosn is null or csosn ~ '^[0-9]{3,4}$'),     -- Simples Nacional / MEI
  cst_icms text check (cst_icms is null or cst_icms ~ '^[0-9]{2}$'), -- regime normal
  origem text not null default '0' check (origem ~ '^[0-8]$'),
  unidade text not null default 'UN',
  pis_cst text not null default '49', cofins_cst text not null default '49',
  ativo boolean not null default true,
  criado_em timestamptz not null default now()
);
alter table public.fiscal_perfis enable row level security;
do $d$ begin
  if not exists (select 1 from pg_constraint where conname = 'fiscal_empresa_perfil_padrao_fk') then
    alter table public.fiscal_empresa add constraint fiscal_empresa_perfil_padrao_fk foreign key (perfil_padrao_id) references public.fiscal_perfis(id) on delete set null;
  end if;
end $d$;

alter table public.produtos add column if not exists perfil_fiscal_id uuid references public.fiscal_perfis(id) on delete set null;
alter table public.categorias add column if not exists perfil_fiscal_id uuid references public.fiscal_perfis(id) on delete set null;
alter table public.combos add column if not exists perfil_fiscal_id uuid references public.fiscal_perfis(id) on delete set null;

-- perfil que vale de verdade: do item; senão da categoria; senão o padrão da empresa
create or replace function public._perfil_fiscal_efetivo(p_produto uuid, p_combo uuid) returns uuid
 language sql stable security definer set search_path to 'public' as $f$
  select coalesce(
    case when p_produto is not null then (select coalesce(p.perfil_fiscal_id, c.perfil_fiscal_id) from produtos p left join categorias c on c.id = p.categoria_id where p.id = p_produto)
         else (select coalesce(b.perfil_fiscal_id, c.perfil_fiscal_id) from combos b left join categorias c on c.id = b.categoria_id where b.id = p_combo) end,
    (select perfil_padrao_id from fiscal_empresa where id))
$f$;

create or replace function public._fiscal_sem_perfil_qtd() returns int
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  return (select count(*) from produtos where ativo and public._perfil_fiscal_efetivo(id, null) is null)::int
       + (select count(*) from combos where ativo and public._perfil_fiscal_efetivo(null, id) is null)::int;
end $f$;

create or replace function public._fiscal_perfis_ok() returns boolean
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  return exists (select 1 from fiscal_perfis where ativo) and public._fiscal_sem_perfil_qtd() = 0;
end $f$;

create or replace function public._cnpj_valido(p text) returns boolean
 language plpgsql immutable as $f$
declare d int[]; s int; i int; pesos1 int[] := array[5,4,3,2,9,8,7,6,5,4,3,2]; pesos2 int[] := array[6,5,4,3,2,9,8,7,6,5,4,3,2];
begin
  if p is null or p !~ '^[0-9]{14}$' or p ~ '^(.)\1{13}$' then return false; end if;
  for i in 1..14 loop d[i] := substr(p, i, 1)::int; end loop;
  s := 0; for i in 1..12 loop s := s + d[i] * pesos1[i]; end loop; s := s % 11; s := case when s < 2 then 0 else 11 - s end;
  if s <> d[13] then return false; end if;
  s := 0; for i in 1..13 loop s := s + d[i] * pesos2[i]; end loop; s := s % 11; s := case when s < 2 then 0 else 11 - s end;
  return s = d[14];
end $f$;

create or replace function public._fiscal_empresa_ok() returns boolean
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  return coalesce((select _cnpj_valido(cnpj) and coalesce(razao_social, '') <> '' and coalesce(inscricao_estadual, '') <> '' and coalesce(logradouro, '') <> ''
                          and coalesce(numero, '') <> '' and coalesce(bairro, '') <> '' and coalesce(municipio, '') <> '' and codigo_municipio ~ '^[0-9]{7}$'
                          and uf ~ '^[A-Z]{2}$' and cep ~ '^[0-9]{8}$' and coalesce(csc_id, '') <> ''
                   from fiscal_empresa where id), false)
     and exists (select 1 from integracoes_segredos where chave = 'nfce_csc');
end $f$;


-- 4) telas do Administrador
create or replace function public.api_fiscal_empresa_ler(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare e fiscal_empresa%rowtype;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into e from fiscal_empresa where id;
  return jsonb_build_object('ok', true, 'empresa', to_jsonb(e) - 'id', 'temCsc', exists (select 1 from integracoes_segredos where chave = 'nfce_csc'),
    'completa', _fiscal_empresa_ok(), 'semPerfil', _fiscal_sem_perfil_qtd());
end $f$;

create or replace function public.api_fiscal_empresa_salvar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_cnpj text := regexp_replace(coalesce(p->>'cnpj', ''), '\D', '', 'g'); v_cep text := regexp_replace(coalesce(p->>'cep', ''), '\D', '', 'g');
  v_uf text := upper(btrim(coalesce(p->>'uf', ''))); v_ibge text := regexp_replace(coalesce(p->>'codigoMunicipio', ''), '\D', '', 'g');
  v_aliq numeric := coalesce(nullif(replace(coalesce(p->>'aliquotaSimples', '0'), ',', '.'), '')::numeric, 0); v_reg text := coalesce(nullif(p->>'regime', ''), 'simples');
  v_serie int := coalesce(nullif(p->>'serie', '')::int, 1);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_cnpj <> '' and not _cnpj_valido(v_cnpj) then return _falha('CNPJ inválido. Confira os 14 números.'); end if;
  if v_cep <> '' and v_cep !~ '^[0-9]{8}$' then return _falha('CEP inválido (8 números).'); end if;
  if v_uf <> '' and v_uf !~ '^[A-Z]{2}$' then return _falha('Estado inválido (2 letras, ex.: SP).'); end if;
  if v_ibge <> '' and v_ibge !~ '^[0-9]{7}$' then return _falha('Código do município inválido (7 números, o contador informa).'); end if;
  if v_aliq < 0 or v_aliq > 40 then return _falha('Alíquota fora do esperado (0 a 40%).'); end if;
  if v_reg not in ('mei', 'simples', 'normal') then return _falha('Regime inválido.'); end if;
  if v_serie < 1 or v_serie > 999 then return _falha('Série inválida (1 a 999).'); end if;
  update fiscal_empresa set
    razao_social = left(btrim(coalesce(p->>'razaoSocial', '')), 120), nome_fantasia = left(btrim(coalesce(p->>'nomeFantasia', '')), 120),
    cnpj = nullif(v_cnpj, ''), inscricao_estadual = left(regexp_replace(coalesce(p->>'inscricaoEstadual', ''), '[^0-9A-Za-z]', '', 'g'), 20),
    regime = v_reg, cep = nullif(v_cep, ''), logradouro = left(btrim(coalesce(p->>'logradouro', '')), 120), numero = left(btrim(coalesce(p->>'numero', '')), 20),
    complemento = left(btrim(coalesce(p->>'complemento', '')), 60), bairro = left(btrim(coalesce(p->>'bairro', '')), 60), municipio = left(btrim(coalesce(p->>'municipio', '')), 60),
    codigo_municipio = nullif(v_ibge, ''), uf = nullif(v_uf, ''), telefone = left(regexp_replace(coalesce(p->>'telefone', ''), '\D', '', 'g'), 14),
    csc_id = left(regexp_replace(coalesce(p->>'cscId', ''), '\D', '', 'g'), 10), serie = v_serie, aliquota_simples = v_aliq, atualizado_em = now()
  where id;
  perform _auditar('Fiscal: dados da empresa salvos', coalesce(nullif(v_cnpj, ''), 'sem CNPJ'));
  return api_fiscal_empresa_ler('{}') || jsonb_build_object('message', 'Dados fiscais salvos.');
end $f$;

create or replace function public.api_fiscal_perfis(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'padraoId', (select perfil_padrao_id from fiscal_empresa where id),
    'perfis', coalesce((select jsonb_agg(jsonb_build_object('id', f.id, 'nome', f.nome, 'ncm', f.ncm, 'cest', f.cest, 'cfop', f.cfop, 'csosn', f.csosn, 'cstIcms', f.cst_icms,
        'origem', f.origem, 'unidade', f.unidade, 'pisCst', f.pis_cst, 'cofinsCst', f.cofins_cst, 'ativo', f.ativo,
        'usos', (select count(*) from produtos x where x.perfil_fiscal_id = f.id) + (select count(*) from combos x where x.perfil_fiscal_id = f.id) + (select count(*) from categorias x where x.perfil_fiscal_id = f.id))
        order by f.nome) from fiscal_perfis f), '[]'::jsonb),
    'categorias', coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'nome', c.nome, 'perfilId', c.perfil_fiscal_id) order by c.ordem, c.nome) from categorias c where c.ativa), '[]'::jsonb),
    'semPerfil', _fiscal_sem_perfil_qtd());
end $f$;

create or replace function public.api_fiscal_perfil_salvar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_id uuid := nullif(p->>'id', '')::uuid; v_nome text := btrim(coalesce(p->>'nome', '')); v_ncm text := regexp_replace(coalesce(p->>'ncm', ''), '\D', '', 'g');
  v_cest text := nullif(regexp_replace(coalesce(p->>'cest', ''), '\D', '', 'g'), ''); v_cfop text := coalesce(nullif(regexp_replace(coalesce(p->>'cfop', ''), '\D', '', 'g'), ''), '5102');
  v_csosn text := nullif(regexp_replace(coalesce(p->>'csosn', ''), '\D', '', 'g'), ''); v_cst text := nullif(regexp_replace(coalesce(p->>'cstIcms', ''), '\D', '', 'g'), '');
  v_origem text := coalesce(nullif(p->>'origem', ''), '0'); v_un text := upper(left(coalesce(nullif(btrim(p->>'unidade'), ''), 'UN'), 6));
  v_reg text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_nome = '' then return _falha('Dê um nome ao perfil (ex.: Lanches, Bebidas).'); end if;
  if v_ncm !~ '^[0-9]{8}$' then return _falha('NCM precisa ter 8 números (o contador informa).'); end if;
  if v_cest is not null and v_cest !~ '^[0-9]{7}$' then return _falha('CEST precisa ter 7 números (ou deixe em branco).'); end if;
  if v_cfop !~ '^[0-9]{4}$' then return _falha('CFOP precisa ter 4 números.'); end if;
  if v_origem !~ '^[0-8]$' then return _falha('Origem inválida (0 a 8).'); end if;
  select regime into v_reg from fiscal_empresa where id;
  if v_reg in ('mei', 'simples') and v_csosn is null then return _falha('Para Simples/MEI informe o CSOSN (o contador informa, ex.: 102).'); end if;
  if v_reg = 'normal' and v_cst is null then return _falha('Para o regime normal informe o CST do ICMS.'); end if;
  if v_id is null then
    insert into fiscal_perfis (nome, ncm, cest, cfop, csosn, cst_icms, origem, unidade, ativo) values (v_nome, v_ncm, v_cest, v_cfop, v_csosn, v_cst, v_origem, v_un, coalesce((p->>'ativo')::boolean, true));
  else
    update fiscal_perfis set nome = v_nome, ncm = v_ncm, cest = v_cest, cfop = v_cfop, csosn = v_csosn, cst_icms = v_cst, origem = v_origem, unidade = v_un, ativo = coalesce((p->>'ativo')::boolean, ativo) where id = v_id;
    if not found then return _falha('Perfil não encontrado.'); end if;
  end if;
  perform _auditar('Fiscal: perfil salvo', v_nome);
  return api_fiscal_perfis('{}') || jsonb_build_object('message', 'Perfil salvo.');
exception when unique_violation then return _falha('Já existe um perfil com esse nome.');
end $f$;

create or replace function public.api_fiscal_perfil_excluir(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_id uuid := (p->>'id')::uuid; v_nome text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select nome into v_nome from fiscal_perfis where id = v_id;
  if v_nome is null then return _falha('Perfil não encontrado.'); end if;
  if exists (select 1 from produtos where perfil_fiscal_id = v_id) or exists (select 1 from combos where perfil_fiscal_id = v_id) or exists (select 1 from categorias where perfil_fiscal_id = v_id)
     or exists (select 1 from fiscal_empresa where perfil_padrao_id = v_id) then
    return _falha('Este perfil está em uso. Troque o perfil dos itens antes de excluir (ou desative o perfil).');
  end if;
  delete from fiscal_perfis where id = v_id;
  perform _auditar('Fiscal: perfil excluído', v_nome);
  return api_fiscal_perfis('{}') || jsonb_build_object('message', 'Perfil excluído.');
end $f$;

-- atribuir: alvo = produto | combo | categoria | padrao ; perfilId nulo = voltar a herdar
create or replace function public.api_fiscal_atribuir(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_alvo text := p->>'alvo'; v_id uuid := nullif(p->>'id', '')::uuid; v_perf uuid := nullif(p->>'perfilId', '')::uuid; v_n int := 0; v_ids uuid[];
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_perf is not null and not exists (select 1 from fiscal_perfis where id = v_perf and ativo) then return _falha('Perfil não encontrado ou desativado.'); end if;
  if v_alvo = 'padrao' then update fiscal_empresa set perfil_padrao_id = v_perf, atualizado_em = now() where id;
  elsif v_alvo = 'categoria' then update categorias set perfil_fiscal_id = v_perf where id = v_id; get diagnostics v_n = row_count;
  elsif v_alvo = 'produto' then update produtos set perfil_fiscal_id = v_perf where id = v_id; get diagnostics v_n = row_count;
  elsif v_alvo = 'combo' then update combos set perfil_fiscal_id = v_perf where id = v_id; get diagnostics v_n = row_count;
  elsif v_alvo = 'lote' then   -- vários itens de uma vez: ids = [{tipo,id}]
    update produtos set perfil_fiscal_id = v_perf where id in (select (x->>'id')::uuid from jsonb_array_elements(coalesce(p->'ids', '[]')) x where x->>'tipo' = 'produto');
    get diagnostics v_n = row_count;
    update combos set perfil_fiscal_id = v_perf where id in (select (x->>'id')::uuid from jsonb_array_elements(coalesce(p->'ids', '[]')) x where x->>'tipo' = 'combo');
  else return _falha('Destino inválido.'); end if;
  if v_alvo <> 'padrao' and v_alvo <> 'lote' and v_n = 0 then return _falha('Item não encontrado.'); end if;
  perform _auditar('Fiscal: perfil atribuído', v_alvo || coalesce(' · ' || v_id::text, ''));
  return api_fiscal_perfis('{}') || jsonb_build_object('message', 'Perfil atribuído.');
end $f$;

create or replace function public.api_fiscal_sem_perfil(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'itens', coalesce((
    select jsonb_agg(x order by x->>'nome') from (
      select jsonb_build_object('tipo', 'produto', 'id', id, 'nome', nome, 'categoria', (select nome from categorias c where c.id = produtos.categoria_id)) x from produtos where ativo and _perfil_fiscal_efetivo(id, null) is null
      union all
      select jsonb_build_object('tipo', 'combo', 'id', id, 'nome', nome, 'categoria', (select nome from categorias c where c.id = combos.categoria_id)) from combos where ativo and _perfil_fiscal_efetivo(null, id) is null) t), '[]'::jsonb));
end $f$;

-- planilha para o contador: uma linha por produto/combo, com o perfil efetivo e todos os campos fiscais
create or replace function public.api_fiscal_exportar(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'linhas', coalesce((
    select jsonb_agg(x order by x->>'tipo', x->>'nome') from (
      select jsonb_build_object('tipo', 'produto', 'id', pr.id, 'nome', pr.nome, 'categoria', c.nome, 'perfil', f.nome, 'ncm', f.ncm, 'cest', f.cest, 'cfop', f.cfop, 'csosn', f.csosn, 'cstIcms', f.cst_icms, 'origem', f.origem, 'unidade', f.unidade) x
        from produtos pr left join categorias c on c.id = pr.categoria_id left join fiscal_perfis f on f.id = _perfil_fiscal_efetivo(pr.id, null) where pr.ativo
      union all
      select jsonb_build_object('tipo', 'combo', 'id', b.id, 'nome', b.nome, 'categoria', c.nome, 'perfil', f.nome, 'ncm', f.ncm, 'cest', f.cest, 'cfop', f.cfop, 'csosn', f.csosn, 'cstIcms', f.cst_icms, 'origem', f.origem, 'unidade', f.unidade)
        from combos b left join categorias c on c.id = b.categoria_id left join fiscal_perfis f on f.id = _perfil_fiscal_efetivo(null, b.id) where b.ativo) t), '[]'::jsonb));
end $f$;

-- importar a planilha devolvida pelo contador: cria/atualiza perfis pelo NOME e liga cada item ao perfil pelo nome
create or replace function public.api_fiscal_importar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare x jsonb; v_ok int := 0; v_ign int := 0; v_msgs text[] := '{}'; v_nome text; v_perf uuid; v_id uuid; v_reg text; v_ncm text; v_csosn text; v_cst text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if jsonb_array_length(coalesce(p->'linhas', '[]')) > 3000 then return _falha('Planilha grande demais (máx. 3000 linhas).'); end if;
  select regime into v_reg from fiscal_empresa where id;
  for x in select * from jsonb_array_elements(coalesce(p->'linhas', '[]')) loop
    v_nome := btrim(coalesce(x->>'perfil', ''));
    v_ncm := regexp_replace(coalesce(x->>'ncm', ''), '\D', '', 'g');
    v_csosn := nullif(regexp_replace(coalesce(x->>'csosn', ''), '\D', '', 'g'), '');
    v_cst := nullif(regexp_replace(coalesce(x->>'cstIcms', ''), '\D', '', 'g'), '');
    if v_nome = '' or v_ncm !~ '^[0-9]{8}$' or (v_reg <> 'normal' and v_csosn is null) or (v_reg = 'normal' and v_cst is null) then
      v_ign := v_ign + 1; if array_length(v_msgs, 1) is null or array_length(v_msgs, 1) < 8 then v_msgs := v_msgs || ('Ignorada: ' || left(coalesce(x->>'nome', '?'), 40)); end if; continue;
    end if;
    insert into fiscal_perfis (nome, ncm, cest, cfop, csosn, cst_icms, origem, unidade)
      values (v_nome, v_ncm, nullif(regexp_replace(coalesce(x->>'cest', ''), '\D', '', 'g'), ''), coalesce(nullif(regexp_replace(coalesce(x->>'cfop', ''), '\D', '', 'g'), ''), '5102'), v_csosn, v_cst,
              coalesce(nullif(x->>'origem', ''), '0'), upper(left(coalesce(nullif(btrim(x->>'unidade'), ''), 'UN'), 6)))
      on conflict (nome) do update set ncm = excluded.ncm, cest = excluded.cest, cfop = excluded.cfop, csosn = excluded.csosn, cst_icms = excluded.cst_icms, origem = excluded.origem, unidade = excluded.unidade
      returning id into v_perf;
    begin v_id := nullif(x->>'id', '')::uuid; exception when others then v_id := null; end;
    if v_id is not null then
      if x->>'tipo' = 'combo' then update combos set perfil_fiscal_id = v_perf where id = v_id;
      elsif x->>'tipo' = 'produto' then update produtos set perfil_fiscal_id = v_perf where id = v_id; end if;
    end if;
    v_ok := v_ok + 1;
  end loop;
  perform _auditar('Fiscal: planilha do contador importada', v_ok || ' linhas, ' || v_ign || ' ignoradas');
  return api_fiscal_perfis('{}') || jsonb_build_object('message', v_ok || ' linha(s) aplicada(s)' || case when v_ign > 0 then ', ' || v_ign || ' ignorada(s) (faltava perfil, NCM ou CSOSN)' else '' end || '.', 'ignoradas', to_jsonb(v_msgs));
end $f$;

-- 5) funções já existentes que ganham o novo comportamento (só efeito com a integração ligada)
create or replace function public.api_integracoes_salvar_segredo(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_chave text := p->>'chave'; v_valor text := btrim(coalesce(p->>'valor', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_chave not in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id', 'nfce_token_homologacao', 'nfce_token_producao', 'nfce_csc') then return _falha('Campo desconhecido.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  if length(v_valor) < 8 or length(v_valor) > 400 or v_valor ~ '\s' then return _falha('Valor inválido. Copie inteiro, sem espaços.'); end if;
  insert into integracoes_segredos (chave, valor, atualizado_em) values (v_chave, v_valor, now())
    on conflict (chave) do update set valor = excluded.valor, atualizado_em = now();
  perform _auditar('Integração: chave salva', v_chave);
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Salvo.');
end $f$;

create or replace function public.api_integracoes_flags(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if auth_nivel() is null then return _negado(); end if;
  return jsonb_build_object('ok', true, 'ifood', _integracao_ligada('ifood'), 'nfce', _integracao_ligada('nfce'),
    'nfceModo', (select modo from integracoes_config where provedor = 'nfce'),
    'impostoPct', case when _integracao_ligada('nfce') then coalesce((select aliquota_simples from fiscal_empresa where id), 0) else 0 end);
end $f$;

create or replace function public._integ_pendencias(p_prov text, p_modo text) returns text[]
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_out text[] := '{}'; v_item jsonb; v_ck jsonb; v_ok boolean;
begin
  select checklist into v_ck from integracoes_config where provedor = p_prov;
  for v_item in select * from jsonb_array_elements(_integ_checklist_def(p_prov)) loop
    if coalesce((v_item->>'auto')::boolean, false) then
      v_ok := case v_item->>'id'
        when 'chaves' then (select count(*) from integracoes_segredos where chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id')) = 3
        when 'token' then exists (select 1 from integracoes_segredos where chave = 'nfce_token_' || p_modo)
        when 'empresa' then public._fiscal_empresa_ok()
        when 'perfis' then public._fiscal_perfis_ok()
        else coalesce((v_ck->>(v_item->>'id'))::boolean, false) end;
    else
      v_ok := coalesce((v_ck->>(v_item->>'id'))::boolean, false);
    end if;
    if not v_ok then v_out := v_out || (v_item->>'titulo'); end if;
  end loop;
  return v_out;
end $f$;

create or replace function public._saude_integracoes() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_desc int; e ifood_estado%rowtype; v_min numeric; v_sem int; v_novos int; v_acoes int; v_nivel text; v_txt text; v_urg int;
begin
  if exists (select 1 from ai_segredos where provedor = 'nvidia') or exists (select 1 from ai_segredos where provedor = 'cloudflare') then
    select count(*) into v_desc from unnest(array['nvidia', 'cloudflare']) x(p) where _ia_provedor_descansando(x.p);
    v := v || jsonb_build_object('id', 'ia_extras', 'titulo', 'IAs de reserva (NVIDIA / Cloudflare)', 'nivel', case when v_desc > 0 then 'atencao' else 'ok' end,
      'texto', (select string_agg(x.rot || ': ' || case when not exists (select 1 from ai_segredos where provedor = x.p) then 'sem chave' when _ia_provedor_descansando(x.p) then 'descansando (erros recentes)' else 'pronta' end, ' · ')
                from (values ('nvidia', 'NVIDIA'), ('cloudflare', 'Cloudflare')) x(p, rot)));
  end if;
  if _integracao_ligada('ifood') then
    select * into e from ifood_estado where id;
    v_min := case when e.ultima_consulta_ok is null then null else extract(epoch from (now() - e.ultima_consulta_ok)) / 60 end;
    select coalesce(sum(itens_sem_ligacao), 0) into v_sem from ifood_pedidos where estado <> 'cancelado' and criado_em > now() - interval '7 days';
    select count(*) into v_novos from ifood_pedidos where estado = 'novo' and not simulado and criado_em < now() - interval '4 minutes';
    select count(*) into v_acoes from ifood_acoes where estado in ('erro', 'duvida') and criado_em > now() - interval '1 day';
    select count(*) into v_urg from ifood_negociacoes where estado = 'aberta' and expira_em > now() and expira_em < now() + interval '3 minutes';
    v_nivel := case when v_min is null or v_min > 2 or e.token_ok is false or v_novos > 0 or v_urg > 0 then 'problema' when v_acoes > 0 or v_sem > 0 or e.ultimo_erro is not null or exists (select 1 from ifood_negociacoes where estado = 'aberta' and expira_em > now()) then 'atencao' else 'ok' end;
    v_txt := case when v_min is null then 'Ligado, mas ainda sem nenhuma consulta bem-sucedida ao iFood.' else 'Última consulta ao iFood há ' || round(v_min, 1) || ' min' end
      || case when e.ultimo_pedido_em is not null then ' · último pedido às ' || to_char(e.ultimo_pedido_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') else ' · nenhum pedido ainda' end
      || case when e.token_ok is false then ' · ACESSO RECUSADO (confira as chaves)' else '' end
      || case when v_novos > 0 then ' · ' || v_novos || ' pedido(s) esperando confirmação há mais de 4 min' else '' end
      || case when v_acoes > 0 then ' · ' || v_acoes || ' ação(ões) não confirmada(s) no iFood' else '' end
      || case when v_sem > 0 then ' · ' || v_sem || ' item(ns) sem ligação' else '' end || public._saude_ifood_extra();
    v := v || jsonb_build_object('id', 'ifood', 'titulo', 'iFood', 'nivel', v_nivel, 'texto', v_txt);
  end if;
  for r in select * from integracoes_config where ligado and provedor = 'nfce' loop
    v := v || jsonb_build_object('id', 'nfce', 'titulo', 'Nota fiscal (NFC-e)', 'nivel',
      'atencao',
      'texto', 'Ligada (' || r.modo || '), aguardando a primeira nota.' || case when public._fiscal_sem_perfil_qtd() > 0 then ' · ' || public._fiscal_sem_perfil_qtd() || ' item(ns) sem perfil fiscal' else '' end);
  end loop;
  return v;
end $f$;

-- 6) permissões
revoke execute on function public._perfil_fiscal_efetivo(uuid, uuid), public._fiscal_sem_perfil_qtd(), public._fiscal_perfis_ok(), public._fiscal_empresa_ok(), public._cnpj_valido(text) from public, anon, authenticated;
revoke execute on function public.api_fiscal_empresa_ler(jsonb), public.api_fiscal_empresa_salvar(jsonb), public.api_fiscal_perfis(jsonb), public.api_fiscal_perfil_salvar(jsonb), public.api_fiscal_perfil_excluir(jsonb),
  public.api_fiscal_atribuir(jsonb), public.api_fiscal_sem_perfil(jsonb), public.api_fiscal_exportar(jsonb), public.api_fiscal_importar(jsonb) from public, anon;
grant execute on function public.api_fiscal_empresa_ler(jsonb), public.api_fiscal_empresa_salvar(jsonb), public.api_fiscal_perfis(jsonb), public.api_fiscal_perfil_salvar(jsonb), public.api_fiscal_perfil_excluir(jsonb),
  public.api_fiscal_atribuir(jsonb), public.api_fiscal_sem_perfil(jsonb), public.api_fiscal_exportar(jsonb), public.api_fiscal_importar(jsonb) to authenticated;
grant execute on function public._fiscal_empresa_ok(), public._fiscal_perfis_ok(), public._fiscal_sem_perfil_qtd(), public._perfil_fiscal_efetivo(uuid, uuid) to service_role;

insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-106-fiscal-cadastro','Nota fiscal: dados da empresa e perfis fiscais','nota fiscal nfc-e cadastro fiscal perfil ncm csosn cfop contador cnpj csc imposto simples',
 E'Contas e acessos → Integrações → Nota fiscal → "Dados fiscais": preencha razão social, CNPJ, inscrição estadual, endereço, código do município (7 números), regime, número do CSC e a alíquota efetiva do Simples (o contador informa). O código secreto do CSC é digitado no botão do próprio cartão, nunca por mensagem.\nPerfis fiscais: cada perfil reúne NCM, CFOP e CSOSN (ou CST). Crie poucos (ex.: Lanches, Bebidas, Sobremesas), marque um como padrão e ligue categorias/itens que sejam exceção. "Itens sem perfil" lista o que ainda falta.\nPlanilha do contador: "Baixar planilha" gera um arquivo com todos os produtos; o contador preenche perfil, NCM, CSOSN e CFOP, e "Enviar planilha" aplica tudo de uma vez.\nCom a nota fiscal ligada, o resultado do período (DRE) passa a mostrar a linha "Impostos sobre vendas (estimado)". Desligada, nada muda.',
 array['Admin'],true,'lista',106,'Só Administrador.'
where not exists (select 1 from ai_ajuda where slug='man-admin-106-fiscal-cadastro');


-- ################ PARTE: f5-nfce-emissao ################
-- =====================================================================================
-- FASE 5 — Emissão da NFC-e (nota do consumidor) pela Focus NFe
-- Tudo NASCE DESLIGADO. Com a integração "nfce" desligada, o gatilho abaixo sai na primeira linha e nada muda nas vendas.
-- Idempotente. Depende da f0 e da f4. Função do servidor: nfce-emitir (publicar depois de rodar este arquivo).
-- ⚠️ Escrito a partir da documentação pública da Focus NFe; NÃO testado com a Focus de verdade (só com servidor de mentira).
-- =====================================================================================

alter table public.vendas add column if not exists cpf_nota text check (cpf_nota is null or cpf_nota ~ '^[0-9]{11}$');

create table if not exists public.nfce_notas (
  id bigserial primary key,
  venda_id uuid not null unique,
  ref text not null unique,                         -- referência única na Focus (= id da venda): impede nota em duplicidade
  ambiente text not null check (ambiente in ('homologacao', 'producao', 'simulado')),
  estado text not null default 'pendente' check (estado in ('pendente', 'emitindo', 'duvida', 'autorizada', 'rejeitada', 'contingencia', 'pendencia', 'cancelando', 'cancelada', 'erro', 'dispensada')),
  numero int, serie int, chave text, protocolo text,
  url_danfe text, url_xml text, url_consulta text,
  status_sefaz text, mensagem text, erro_pt text,
  valor numeric(12,2), cpf text,
  tentativas int not null default 0,
  emitir_apos timestamptz not null default now(),   -- dá um tempinho para o caixa informar o CPF
  proxima_tentativa timestamptz not null default now(),
  trava_ate timestamptz,
  emitida_em timestamptz, cancelada_em timestamptz, cancelamento_motivo text,
  emitido_por text,
  criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create index if not exists nfce_notas_estado_idx on public.nfce_notas (estado, proxima_tentativa);
create index if not exists nfce_notas_criado_idx on public.nfce_notas (criado_em desc);
alter table public.nfce_notas enable row level security;

create or replace function public._cpf_valido(p text) returns boolean
 language plpgsql immutable as $f$
declare s int; i int; d1 int; d2 int;
begin
  if p is null or p !~ '^[0-9]{11}$' or p ~ '^(.)\1{10}$' then return false; end if;
  s := 0; for i in 1..9 loop s := s + substr(p, i, 1)::int * (11 - i); end loop; d1 := (s * 10) % 11; if d1 = 10 then d1 := 0; end if;
  s := 0; for i in 1..10 loop s := s + substr(p, i, 1)::int * (12 - i); end loop; d2 := (s * 10) % 11; if d2 = 10 then d2 := 0; end if;
  return d1 = substr(p, 10, 1)::int and d2 = substr(p, 11, 1)::int;
end $f$;

create or replace function public._nfce_canal_da_venda(p_origem text, p_tipo text, p_canal text) returns text
 language sql immutable as $f$
  select case when p_canal = 'iFood' then 'ifood' when p_origem = 'Cardápio' then 'cardapio' when p_origem = 'Garçom' or p_tipo = 'Mesa' then 'mesa' else 'balcao' end
$f$;

-- código da forma de pagamento na nota (tabela da Sefaz). O contador confere os casos especiais (ex.: pagamento online do iFood).
create or replace function public._nfce_forma_codigo(p text) returns text
 language sql immutable as $f$
  select case
    when lower(coalesce(p, '')) ~ 'dinheiro' then '01'
    when lower(coalesce(p, '')) ~ 'cr[eé]dito' then '03'
    when lower(coalesce(p, '')) ~ 'd[eé]bito' then '04'
    when lower(coalesce(p, '')) ~ 'pix' then '17'
    when lower(coalesce(p, '')) ~ 'alelo|vale|ticket|sodexo|refei|alimenta' then '10'
    else '99' end
$f$;

-- explica a rejeição em português simples
create or replace function public._nfce_traduzir(p text) returns text
 language sql immutable as $f$
  select case
    when p is null or btrim(p) = '' then 'A nota foi rejeitada, sem explicação detalhada. Veja o registro e fale com o contador.'
    when p ~* 'ncm' then 'NCM inválido ou não aceito. Confira o NCM do perfil fiscal do produto (o contador informa).'
    when p ~* 'csosn|situa[cç][aã]o tribut|\mcst\M' then 'Situação tributária (CSOSN/CST) incompatível com o regime da empresa. Confira o perfil fiscal.'
    when p ~* 'cfop' then 'CFOP incompatível com a operação. Confira o perfil fiscal com o contador.'
    when p ~* 'csc' then 'CSC ou número do CSC inválido. Confira o CSC (Sefaz) em Dados fiscais e em Chaves.'
    when p ~* 'certificado' then 'Problema com o certificado digital A1 (vencido ou não enviado à Focus). Fale com o contador ou com a Focus.'
    when p ~* 'inscri[cç][aã]o estadual' then 'Inscrição estadual do emitente não confere. Confira em Dados fiscais da empresa.'
    when p ~* 'cnpj' then 'CNPJ do emitente não confere com o cadastrado na Focus/Sefaz.'
    when p ~* 'duplicidade|duplicad|j[aá] existe|ja existe' then 'Já existe nota para esta venda. Use "Consultar na Focus" antes de reemitir.'
    when p ~* 'data.*(emiss|atras)|atrasad' then 'Horário da emissão fora do permitido (máximo 5 minutos de diferença). Confira o relógio e reemita.'
    when p ~* 'pagamento|total' then 'Soma dos pagamentos diferente do total da nota. Confira descontos, taxa de entrega e acréscimos da venda com o contador.'
    when p ~* 'token|permiss|n[aã]o autorizado|unauthorized|forbidden|acesso negado' then 'A Focus recusou o token. Confira o token (teste × produção) em Chaves.'
    when p ~* 'sefaz|indispon|offline|timeout|conting' then 'A Sefaz está fora do ar ou lenta. O sistema tenta de novo sozinho.'
    else 'Rejeitada: ' || left(p, 220) end
$f$;

-- GATILHO: cria a "nota pendente" quando a venda cumpre a regra configurada. Nunca atrapalha a venda (qualquer erro vira só um registro).
create or replace function public._nfce_trg_venda() returns trigger
 language plpgsql security definer set search_path to 'public' as $f$
declare c integracoes_config%rowtype; v_canal text; v_ok boolean;
begin
  if not public._integracao_ligada('nfce') then return null; end if;
  begin
    if new.status::text <> 'Confirmada' then return null; end if;
    select * into c from integracoes_config where provedor = 'nfce';
    if c.ligado_em is not null and new.data_hora < c.ligado_em then return null; end if;     -- vendas de antes de ligar não geram nota sozinhas
    v_canal := public._nfce_canal_da_venda(new.origem::text, new.tipo::text, new.canal);
    if not (c.config->'canais' ? v_canal) then return null; end if;
    v_ok := case when coalesce(c.config->>'emitirQuando', 'pagamento') = 'entrega'
                 then new.status_pedido::text in ('Entregue', 'Retirada', 'Servida')
                 else new.status_pagamento::text = 'Pago' end;
    if not v_ok then return null; end if;
    insert into nfce_notas (venda_id, ref, ambiente, valor, cpf, emitir_apos, proxima_tentativa)
      values (new.id, new.id::text, c.modo, new.valor_total, new.cpf_nota, now() + interval '45 seconds', now() + interval '45 seconds')
      on conflict (venda_id) do nothing;
  exception when others then
    perform public._integ_log('nfce', 'erro', 'Não consegui preparar a nota da venda ' || coalesce(new.numero_pedido::text, '?') || ': ' || sqlerrm);
  end;
  return null;
end $f$;
drop trigger if exists trg_nfce_venda on public.vendas;
create trigger trg_nfce_venda after insert or update of status, status_pagamento, status_pedido on public.vendas for each row execute function public._nfce_trg_venda();

-- monta o JSON da nota a partir da venda (itens, perfil fiscal, desconto/taxas rateados, pagamentos)
create or replace function public.nfce_montar(p_id bigint) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare n nfce_notas%rowtype; v vendas%rowtype; e fiscal_empresa%rowtype; r record; v_itens jsonb := '[]'::jsonb; v_pags jsonb := '[]'::jsonb;
  v_sem text; v_bruto numeric := 0; v_desc numeric; v_outras numeric; v_total numeric; v_dsum numeric := 0; v_osum numeric := 0; v_di numeric; v_oi numeric;
  v_cnt int; v_i int := 0; v_psum numeric := 0; v_pf fiscal_perfis%rowtype; v_cpf text; v_item jsonb;
begin
  select * into n from nfce_notas where id = p_id; if not found then return jsonb_build_object('ok', false, 'motivo', 'Nota não encontrada.'); end if;
  select * into v from vendas where id = n.venda_id; if not found then return jsonb_build_object('ok', false, 'motivo', 'Venda não encontrada.'); end if;
  select * into e from fiscal_empresa where id;
  if not public._fiscal_empresa_ok() then return jsonb_build_object('ok', false, 'motivo', 'Dados fiscais da empresa incompletos (Integrações → Nota fiscal → Dados fiscais).'); end if;
  select string_agg(distinct coalesce(iv.descricao, '(item)'), ', ') into v_sem from itens_venda iv where iv.venda_id = v.id and iv.valor_total_item > 0 and public._perfil_fiscal_efetivo(iv.produto_id, iv.combo_id) is null;
  if v_sem is not null then return jsonb_build_object('ok', false, 'motivo', 'Item sem perfil fiscal: ' || left(v_sem, 150) || '. Defina o perfil e reemita.'); end if;
  select coalesce(sum(valor_total_item), 0), count(*) into v_bruto, v_cnt from itens_venda where venda_id = v.id and valor_total_item > 0;
  if v_cnt = 0 or v_bruto <= 0 then return jsonb_build_object('ok', false, 'dispensar', true, 'motivo', 'Venda sem valor: não há nota a emitir.'); end if;
  v_desc := coalesce(v.valor_desconto, 0); v_outras := coalesce(v.taxa_entrega, 0) + coalesce(v.acrescimo_forma, 0);
  v_total := round(v_bruto - v_desc + v_outras, 2);
  for r in select iv.id, iv.produto_id, iv.combo_id, iv.descricao, iv.quantidade, iv.valor_total_item vt from itens_venda iv where iv.venda_id = v.id and iv.valor_total_item > 0 order by iv.id loop
    v_i := v_i + 1;
    if v_i = v_cnt then v_di := round(v_desc - v_dsum, 2); v_oi := round(v_outras - v_osum, 2);
    else v_di := round(v_desc * r.vt / v_bruto, 2); v_oi := round(v_outras * r.vt / v_bruto, 2); end if;
    v_dsum := v_dsum + v_di; v_osum := v_osum + v_oi;
    select * into v_pf from fiscal_perfis where id = public._perfil_fiscal_efetivo(r.produto_id, r.combo_id);
    v_item := jsonb_build_object('numero_item', v_i, 'codigo_produto', coalesce(r.produto_id, r.combo_id)::text, 'descricao', left(btrim(coalesce(r.descricao, 'Item')), 120),
      'codigo_ncm', v_pf.ncm, 'cfop', v_pf.cfop, 'unidade_comercial', v_pf.unidade, 'quantidade_comercial', r.quantidade, 'valor_unitario_comercial', round(r.vt / nullif(r.quantidade, 0), 6),
      'unidade_tributavel', v_pf.unidade, 'quantidade_tributavel', r.quantidade, 'valor_unitario_tributavel', round(r.vt / nullif(r.quantidade, 0), 6), 'valor_bruto', round(r.vt, 2),
      'icms_origem', v_pf.origem::int, 'icms_situacao_tributaria', coalesce(v_pf.csosn, v_pf.cst_icms), 'pis_situacao_tributaria', v_pf.pis_cst, 'cofins_situacao_tributaria', v_pf.cofins_cst, 'inclui_no_total', 1);
    if v_pf.cest is not null then v_item := v_item || jsonb_build_object('cest', v_pf.cest); end if;
    if v_di > 0 then v_item := v_item || jsonb_build_object('valor_desconto', v_di); end if;
    if v_oi > 0 then v_item := v_item || jsonb_build_object('valor_outras_despesas', v_oi); end if;
    v_itens := v_itens || v_item;
  end loop;
  -- pagamentos: seguem os da venda; a diferença de centavos vai no maior para a soma bater exatamente com o total da nota
  for r in select forma_pagamento, valor from pagamentos_venda where venda_id = v.id and valor > 0 order by valor desc loop
    v_pags := v_pags || jsonb_build_object('forma_pagamento', public._nfce_forma_codigo(r.forma_pagamento), 'valor_pagamento', round(r.valor, 2));
    v_psum := v_psum + round(r.valor, 2);
  end loop;
  if jsonb_array_length(v_pags) = 0 then
    v_pags := jsonb_build_array(jsonb_build_object('forma_pagamento', public._nfce_forma_codigo(v.forma_pagamento), 'valor_pagamento', v_total));
  elsif v_psum <> v_total then
    v_pags := jsonb_set(v_pags, '{0,valor_pagamento}', to_jsonb(round((v_pags->0->>'valor_pagamento')::numeric + (v_total - v_psum), 2)));
  end if;
  v_cpf := coalesce(n.cpf, v.cpf_nota);
  return jsonb_build_object('ok', true, 'valor', v_total, 'payload', jsonb_strip_nulls(jsonb_build_object(
    'natureza_operacao', 'VENDA AO CONSUMIDOR', 'cnpj_emitente', e.cnpj, 'presenca_comprador', case when v.tipo::text = 'Entrega' then 4 else 1 end,
    'modalidade_frete', 9, 'local_destino', 1, 'consumidor_final', 1, 'cpf_destinatario', v_cpf, 'itens', v_itens, 'formas_pagamento', v_pags)));
end $f$;

create or replace function public.nfce_log(p_nivel text, p_msg text) returns void language sql security definer set search_path to 'public' as $f$
  select public._integ_log('nfce', case when p_nivel in ('info','aviso','erro') then p_nivel else 'info' end, p_msg)
$f$;

-- credenciais para o servidor: token do ambiente da nota
create or replace function public.nfce_credenciais(p_ambiente text) returns jsonb
 language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('ligado', public._integracao_ligada('nfce'), 'modo', (select modo from integracoes_config where provedor = 'nfce'),
    'token', (select valor from integracoes_segredos where chave = 'nfce_token_' || case when p_ambiente = 'producao' then 'producao' else 'homologacao' end),
    'cnpj', (select cnpj from fiscal_empresa where id))
$f$;

-- notas prontas para tratar (reserva por 2 min, para dois ciclos não pegarem a mesma)
create or replace function public.nfce_pegar_pendentes(p_limite int default 5) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r jsonb;
begin
  with c as (select id from nfce_notas where estado in ('pendente', 'duvida', 'contingencia') and emitir_apos <= now() and proxima_tentativa <= now() and (trava_ate is null or trava_ate < now())
               order by id limit greatest(1, least(coalesce(p_limite, 5), 20)) for update skip locked),
  u as (update nfce_notas n set trava_ate = now() + interval '2 minutes', atualizado_em = now() from c where n.id = c.id returning n.id, n.ref, n.venda_id, n.ambiente, n.estado, n.tentativas)
  select coalesce(jsonb_agg(to_jsonb(u)), '[]'::jsonb) into r from u;
  return r;
end $f$;

-- resultado do tratamento de uma nota. p_res: {resultado, numero, serie, chave, protocolo, urlDanfe, urlXml, urlConsulta, statusSefaz, mensagem, motivo}
create or replace function public.nfce_resultado(p_id bigint, p_res jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare n nfce_notas%rowtype; v_r text := p_res->>'resultado'; v_msg text := left(coalesce(p_res->>'mensagem', ''), 600); v_tent int;
begin
  select * into n from nfce_notas where id = p_id for update;
  if not found then return jsonb_build_object('ok', false); end if;
  if n.estado in ('autorizada', 'cancelada') and v_r <> 'autorizada' then return jsonb_build_object('ok', true, 'ignorado', true); end if;
  if v_r = 'autorizada' then
    update nfce_notas set estado = 'autorizada', numero = nullif(p_res->>'numero', '')::int, serie = nullif(p_res->>'serie', '')::int, chave = p_res->>'chave', protocolo = p_res->>'protocolo',
      url_danfe = p_res->>'urlDanfe', url_xml = p_res->>'urlXml', url_consulta = p_res->>'urlConsulta', status_sefaz = p_res->>'statusSefaz', mensagem = v_msg, erro_pt = null,
      emitida_em = coalesce(emitida_em, now()), trava_ate = null, atualizado_em = now(), tentativas = tentativas + 1 where id = p_id;
    perform public._integ_log('nfce', 'info', 'Nota ' || coalesce(p_res->>'numero', '?') || ' autorizada (venda ' || n.ref || ')');
  elsif v_r = 'rejeitada' then
    update nfce_notas set estado = 'rejeitada', status_sefaz = p_res->>'statusSefaz', mensagem = v_msg, erro_pt = public._nfce_traduzir(v_msg), trava_ate = null, atualizado_em = now(), tentativas = tentativas + 1 where id = p_id;
    perform public._integ_log('nfce', 'erro', 'Nota rejeitada (venda ' || n.ref || '): ' || left(v_msg, 200));
  elsif v_r = 'pendencia' then
    update nfce_notas set estado = 'pendencia', erro_pt = left(coalesce(p_res->>'motivo', 'Pendência'), 300), trava_ate = null, atualizado_em = now() where id = p_id;
    perform public._integ_log('nfce', 'aviso', 'Nota parada (venda ' || n.ref || '): ' || left(coalesce(p_res->>'motivo', ''), 200));
  elsif v_r = 'dispensada' then
    update nfce_notas set estado = 'dispensada', erro_pt = left(coalesce(p_res->>'motivo', ''), 300), trava_ate = null, atualizado_em = now() where id = p_id;
  elsif v_r = 'contingencia' then
    update nfce_notas set estado = 'contingencia', numero = nullif(p_res->>'numero', '')::int, serie = nullif(p_res->>'serie', '')::int, chave = p_res->>'chave', mensagem = v_msg,
      proxima_tentativa = now() + interval '3 minutes', trava_ate = null, atualizado_em = now() where id = p_id;
  else   -- 'duvida' (rede/timeout/5xx/ainda processando): nunca reenvia às cegas; da próxima vez consulta primeiro
    v_tent := n.tentativas + 1;
    update nfce_notas set estado = case when v_tent >= 8 then 'erro' else 'duvida' end, tentativas = v_tent, mensagem = v_msg,
      erro_pt = case when v_tent >= 8 then 'Não consegui falar com a Focus/Sefaz depois de várias tentativas. Veja o registro e use "Reemitir".' else null end,
      proxima_tentativa = now() + make_interval(mins => least(power(2, least(v_tent, 5))::int, 30)), trava_ate = null, atualizado_em = now() where id = p_id;
    if v_tent >= 8 then perform public._integ_log('nfce', 'erro', 'Nota parada por erro de comunicação (venda ' || n.ref || ')'); end if;
  end if;
  return jsonb_build_object('ok', true);
end $f$;

-- ---------- telas ----------
create or replace function public.api_nfce_lista(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_est text := nullif(p->>'estado', ''); v_lim int := least(coalesce(nullif(p->>'limite', '')::int, 60), 200);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'contagem', coalesce((select jsonb_object_agg(estado, q) from (select estado, count(*) q from nfce_notas where criado_em > now() - interval '30 days' group by 1) x), '{}'::jsonb),
    'mes', (select count(*) from nfce_notas where estado = 'autorizada' and ambiente = 'producao' and emitida_em >= date_trunc('month', now() at time zone 'America/Sao_Paulo') at time zone 'America/Sao_Paulo'),
    'itens', coalesce((select jsonb_agg(jsonb_build_object('id', n.id, 'vendaId', n.venda_id, 'pedido', v.numero_pedido, 'cliente', v.cliente_nome, 'quando', v.data_hora, 'estado', n.estado, 'ambiente', n.ambiente,
        'numero', n.numero, 'serie', n.serie, 'valor', n.valor, 'erro', n.erro_pt, 'danfe', n.url_danfe, 'xml', n.url_xml, 'consulta', n.url_consulta, 'cpf', (n.cpf is not null), 'tentativas', n.tentativas,
        'emitidaEm', n.emitida_em, 'canceladaEm', n.cancelada_em) order by n.id desc)
      from (select * from nfce_notas where (v_est is null or estado = v_est) order by id desc limit v_lim) n left join vendas v on v.id = n.venda_id), '[]'::jsonb));
end $f$;

create or replace function public.api_nfce_reemitir(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare n nfce_notas%rowtype;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into n from nfce_notas where id = (p->>'id')::bigint for update;
  if not found then return _falha('Nota não encontrada.'); end if;
  if n.estado not in ('rejeitada', 'pendencia', 'erro', 'duvida', 'dispensada') then return _falha('Esta nota não precisa ser reemitida (' || n.estado || ').'); end if;
  update nfce_notas set estado = 'pendente', tentativas = 0, erro_pt = null, emitir_apos = now(), proxima_tentativa = now(), trava_ate = null, ambiente = coalesce((select modo from integracoes_config where provedor = 'nfce'), ambiente), atualizado_em = now() where id = n.id;
  perform _auditar('Nota fiscal: reemissão pedida', n.ref);
  perform public.chamar_edge('nfce-emitir', '{}'::jsonb);
  return api_nfce_lista('{}') || jsonb_build_object('message', 'Pedido de reemissão enviado. Atualize a lista em alguns segundos.');
end $f$;

-- cria a nota de uma venda que ficou sem (ex.: antes de ligar, ou modo "na entrega" que não disparou)
create or replace function public.api_nfce_emitir_venda(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v vendas%rowtype;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not public._integracao_ligada('nfce') then return _falha('A nota fiscal está desligada.'); end if;
  select * into v from vendas where id = (p->>'vendaId')::uuid;
  if not found or v.status::text <> 'Confirmada' then return _falha('Venda não encontrada ou não confirmada.'); end if;
  insert into nfce_notas (venda_id, ref, ambiente, valor, cpf, emitir_apos, proxima_tentativa)
    values (v.id, v.id::text, (select modo from integracoes_config where provedor = 'nfce'), v.valor_total, v.cpf_nota, now(), now()) on conflict (venda_id) do nothing;
  if not found then return _falha('Esta venda já tem nota (veja a lista).'); end if;
  perform _auditar('Nota fiscal: emissão manual pedida', v.id::text);
  perform public.chamar_edge('nfce-emitir', '{}'::jsonb);
  return api_nfce_lista('{}') || jsonb_build_object('message', 'Nota criada; sendo emitida.');
end $f$;

-- CPF na nota: só se o cliente pedir; só antes da emissão
create or replace function public.api_nfce_cpf(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_cpf text := regexp_replace(coalesce(p->>'cpf', ''), '\D', '', 'g'); v_venda uuid := nullif(p->>'vendaId', '')::uuid; n nfce_notas%rowtype;
begin
  if auth_nivel() is null or not tem_nivel('Admin', 'Operador', 'Garçom') then return _negado(); end if;
  if not public._integracao_ligada('nfce') then return jsonb_build_object('ok', true, 'ignorado', true); end if;
  if v_cpf <> '' and not public._cpf_valido(v_cpf) then return _falha('CPF inválido. Confira os 11 números.'); end if;
  select * into n from nfce_notas where venda_id = v_venda for update;
  if found and n.estado not in ('pendente', 'pendencia', 'rejeitada', 'dispensada') then return _falha('A nota desta venda já foi emitida; não dá mais para incluir o CPF.'); end if;
  update vendas set cpf_nota = nullif(v_cpf, '') where id = v_venda;
  if not found then return _falha('Venda não encontrada.'); end if;
  update nfce_notas set cpf = nullif(v_cpf, ''), atualizado_em = now() where venda_id = v_venda;
  return jsonb_build_object('ok', true, 'message', case when v_cpf = '' then 'CPF removido.' else 'CPF incluído na nota.' end);
end $f$;

-- Desenvolvedor: nota de TREINO (não fala com a Focus; o servidor inventa a autorização)
create or replace function public.api_nfce_simular(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v vendas%rowtype; v_m jsonb; v_id bigint;
begin
  if not public._eh_dev() then return _negado(); end if;
  select * into v from vendas where status::text = 'Confirmada' and coalesce(canal, '') <> 'iFood' and not exists (select 1 from nfce_notas x where x.venda_id = vendas.id) order by data_hora desc limit 1;
  if not found then return _falha('Não há venda confirmada sem nota para usar no treino. Faça uma venda de teste antes.'); end if;
  insert into nfce_notas (venda_id, ref, ambiente, valor, cpf, emitir_apos, proxima_tentativa) values (v.id, v.id::text, 'simulado', v.valor_total, v.cpf_nota, now(), now()) returning id into v_id;
  v_m := public.nfce_montar(v_id);
  perform public.chamar_edge('nfce-emitir', '{}'::jsonb);
  return jsonb_build_object('ok', true, 'message', 'Nota de treino criada para o pedido ' || v.numero_pedido || '. ' || case when (v_m->>'ok')::boolean then 'Os dados fiscais estão completos.' else 'Atenção: ' || coalesce(v_m->>'motivo', '') end);
end $f$;

-- saúde: bloco da nota fiscal
create or replace function public._saude_nfce() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare r record; v_rej int; v_pend int; v_atras int; v_cont int; v_dv int; v_nivel text; v_txt text;
begin
  select * into r from integracoes_config where ligado and provedor = 'nfce';
  if not found then return '[]'::jsonb; end if;
  select count(*) filter (where estado in ('rejeitada', 'erro')), count(*) filter (where estado = 'pendencia'), count(*) filter (where estado in ('pendente', 'duvida') and emitir_apos < now() - interval '10 minutes'),
         count(*) filter (where estado = 'contingencia'), count(*) filter (where estado = 'duvida')
    into v_rej, v_pend, v_atras, v_cont, v_dv from nfce_notas where criado_em > now() - interval '7 days';
  v_nivel := case when v_atras > 0 or v_rej > 0 then 'problema' when v_pend > 0 or v_cont > 0 or public._fiscal_sem_perfil_qtd() > 0 then 'atencao' else 'ok' end;
  v_txt := 'Nota fiscal ligada (' || case when r.modo = 'producao' then 'produção' else 'teste' end || ')'
    || case when v_rej > 0 then ' · ' || v_rej || ' nota(s) rejeitada(s)/com erro' else '' end
    || case when v_atras > 0 then ' · ' || v_atras || ' nota(s) esperando emissão há mais de 10 min' else '' end
    || case when v_pend > 0 then ' · ' || v_pend || ' parada(s) por pendência (ex.: item sem perfil)' else '' end
    || case when v_cont > 0 then ' · ' || v_cont || ' em contingência' else '' end
    || case when public._fiscal_sem_perfil_qtd() > 0 then ' · ' || public._fiscal_sem_perfil_qtd() || ' item(ns) sem perfil fiscal' else '' end;
  return jsonb_build_array(jsonb_build_object('id', 'nfce', 'titulo', 'Nota fiscal (NFC-e)', 'nivel', v_nivel, 'texto', v_txt));
end $f$;

create or replace function public._saude_integracoes() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_desc int; e ifood_estado%rowtype; v_min numeric; v_sem int; v_novos int; v_acoes int; v_nivel text; v_txt text; v_urg int;
begin
  if exists (select 1 from ai_segredos where provedor = 'nvidia') or exists (select 1 from ai_segredos where provedor = 'cloudflare') then
    select count(*) into v_desc from unnest(array['nvidia', 'cloudflare']) x(p) where _ia_provedor_descansando(x.p);
    v := v || jsonb_build_object('id', 'ia_extras', 'titulo', 'IAs de reserva (NVIDIA / Cloudflare)', 'nivel', case when v_desc > 0 then 'atencao' else 'ok' end,
      'texto', (select string_agg(x.rot || ': ' || case when not exists (select 1 from ai_segredos where provedor = x.p) then 'sem chave' when _ia_provedor_descansando(x.p) then 'descansando (erros recentes)' else 'pronta' end, ' · ')
                from (values ('nvidia', 'NVIDIA'), ('cloudflare', 'Cloudflare')) x(p, rot)));
  end if;
  if _integracao_ligada('ifood') then
    select * into e from ifood_estado where id;
    v_min := case when e.ultima_consulta_ok is null then null else extract(epoch from (now() - e.ultima_consulta_ok)) / 60 end;
    select coalesce(sum(itens_sem_ligacao), 0) into v_sem from ifood_pedidos where estado <> 'cancelado' and criado_em > now() - interval '7 days';
    select count(*) into v_novos from ifood_pedidos where estado = 'novo' and not simulado and criado_em < now() - interval '4 minutes';
    select count(*) into v_acoes from ifood_acoes where estado in ('erro', 'duvida') and criado_em > now() - interval '1 day';
    select count(*) into v_urg from ifood_negociacoes where estado = 'aberta' and expira_em > now() and expira_em < now() + interval '3 minutes';
    v_nivel := case when v_min is null or v_min > 2 or e.token_ok is false or v_novos > 0 or v_urg > 0 then 'problema' when v_acoes > 0 or v_sem > 0 or e.ultimo_erro is not null or exists (select 1 from ifood_negociacoes where estado = 'aberta' and expira_em > now()) then 'atencao' else 'ok' end;
    v_txt := case when v_min is null then 'Ligado, mas ainda sem nenhuma consulta bem-sucedida ao iFood.' else 'Última consulta ao iFood há ' || round(v_min, 1) || ' min' end
      || case when e.ultimo_pedido_em is not null then ' · último pedido às ' || to_char(e.ultimo_pedido_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') else ' · nenhum pedido ainda' end
      || case when e.token_ok is false then ' · ACESSO RECUSADO (confira as chaves)' else '' end
      || case when v_novos > 0 then ' · ' || v_novos || ' pedido(s) esperando confirmação há mais de 4 min' else '' end
      || case when v_acoes > 0 then ' · ' || v_acoes || ' ação(ões) não confirmada(s) no iFood' else '' end
      || case when v_sem > 0 then ' · ' || v_sem || ' item(ns) sem ligação' else '' end || public._saude_ifood_extra();
    v := v || jsonb_build_object('id', 'ifood', 'titulo', 'iFood', 'nivel', v_nivel, 'texto', v_txt);
  end if;
  v := v || public._saude_nfce();
  return v;
end $f$;

-- cron: chama o servidor 1x por minuto, mas só se a nota estiver ligada e houver nota para tratar
do $c$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.schedule('nfce-emitir-minuto', '* * * * *', $j$select case when public._integracao_ligada('nfce') and exists (select 1 from public.nfce_notas where estado in ('pendente', 'duvida', 'contingencia') and emitir_apos <= now() and proxima_tentativa <= now()) then public.chamar_edge('nfce-emitir', '{}'::jsonb) end$j$);
  end if;
end $c$;

-- ---------- permissões ----------
revoke execute on function public._cpf_valido(text), public._nfce_canal_da_venda(text, text, text), public._nfce_forma_codigo(text), public._nfce_traduzir(text), public._nfce_trg_venda(),
  public.nfce_montar(bigint), public.nfce_credenciais(text), public.nfce_pegar_pendentes(int), public.nfce_resultado(bigint, jsonb), public.nfce_log(text, text), public._saude_nfce() from public, anon, authenticated;
grant execute on function public.nfce_montar(bigint), public.nfce_credenciais(text), public.nfce_pegar_pendentes(int), public.nfce_resultado(bigint, jsonb), public.nfce_log(text, text) to service_role;
revoke execute on function public.api_nfce_lista(jsonb), public.api_nfce_reemitir(jsonb), public.api_nfce_emitir_venda(jsonb), public.api_nfce_cpf(jsonb), public.api_nfce_simular(jsonb) from public, anon;
grant execute on function public.api_nfce_lista(jsonb), public.api_nfce_reemitir(jsonb), public.api_nfce_emitir_venda(jsonb), public.api_nfce_cpf(jsonb), public.api_nfce_simular(jsonb) to authenticated;

insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-107-nfce-emissao','Nota fiscal: emissão automática, CPF na nota e lista de notas','nota fiscal nfc-e emitir emissão cpf rejeitada reemitir danfe focus lista notas contingência',
 E'Com a nota fiscal ligada (Contas e acessos → Integrações → Nota fiscal), cada venda do canal escolhido gera a nota sozinha: ao pagar (balcão) ou na entrega (delivery/iFood). A nota sai cerca de 1 minuto depois da venda, para dar tempo de informar o CPF.\nCPF na nota: só se o cliente pedir. No Caixa, antes de finalizar, digite o CPF no campo "CPF na nota". Depois que a nota sai não dá mais para incluir.\nLista "Notas fiscais": filtre por situação (autorizada, rejeitada, pendência, em contingência). Se uma nota foi rejeitada, o texto explica o motivo em português; corrija (ex.: perfil fiscal do produto) e toque em "Reemitir". "Abrir DANFE" mostra o cupom com QR Code; "Enviar ao cliente" abre o WhatsApp com o link.\nNunca é emitida nota de item sem perfil fiscal: a nota fica como pendência até você definir o perfil.\nDesenvolvedor: "Nota de treino" cria uma nota de mentira, sem falar com a Focus.',
 array['Admin','Operador','Garçom'],true,'lista',107,'Lista de notas e reemissão: só Administrador. CPF na nota: quem faz a venda.'
where not exists (select 1 from ai_ajuda where slug='man-admin-107-nfce-emissao');


-- ################ PARTE: f6-nfce-fechamento ################
-- =====================================================================================
-- FASE 6 — Nota fiscal: cancelamento, inutilização, conferência "Vendas × Notas", pacote do contador, limite do plano
-- Tudo NASCE DESLIGADO (depende da integração "nfce" ligada). Idempotente. Depende da f4 e da f5.
-- ⚠️ Escrito a partir da documentação pública da Focus NFe; NÃO testado com a Focus de verdade.
-- =====================================================================================

alter table public.nfce_notas add column if not exists cancelar_pedido boolean not null default false;   -- a venda foi cancelada enquanto a nota ainda estava em dúvida
alter table public.nfce_notas add column if not exists cancelar_manual boolean not null default false;   -- fora do prazo (30 min) ou recusado: o contador orienta

-- pede o cancelamento da nota autorizada (só dentro do prazo; fora dele vira pendência para o contador)
create or replace function public._nfce_iniciar_cancelamento(p_id bigint, p_motivo text) returns void
 language plpgsql security definer set search_path to 'public' as $f$
declare n nfce_notas%rowtype; v_j text;
begin
  select * into n from nfce_notas where id = p_id for update;
  if not found or n.estado <> 'autorizada' then return; end if;
  if n.ambiente = 'simulado' then
    update nfce_notas set estado = 'cancelada', cancelada_em = now(), cancelar_pedido = false, atualizado_em = now() where id = p_id; return;
  end if;
  if n.emitida_em is null or now() - n.emitida_em > interval '28 minutes' then
    update nfce_notas set cancelar_manual = true, cancelar_pedido = false, atualizado_em = now(),
      erro_pt = 'Venda cancelada depois de 30 minutos da emissão: o cancelamento da nota precisa ser orientado pelo contador.' where id = p_id;
    perform public._integ_log('nfce', 'aviso', 'Venda cancelada fora do prazo da nota (' || n.ref || '): cancelar com o contador');
    return;
  end if;
  v_j := btrim(coalesce(p_motivo, 'Venda cancelada'));
  if length(v_j) < 15 then v_j := v_j || ' (cancelada no sistema)'; end if;
  update nfce_notas set estado = 'cancelando', cancelamento_motivo = left(v_j, 255), tentativas = 0, cancelar_pedido = false, proxima_tentativa = now(), emitir_apos = now(), trava_ate = null, atualizado_em = now() where id = p_id;
end $f$;

-- GATILHO: venda cancelada → cuida da nota. Nunca atrapalha o cancelamento da venda.
create or replace function public._nfce_trg_cancelada() returns trigger
 language plpgsql security definer set search_path to 'public' as $f$
declare n nfce_notas%rowtype;
begin
  if not public._integracao_ligada('nfce') then return null; end if;
  begin
    if new.status::text <> 'Cancelada' or old.status::text = 'Cancelada' then return null; end if;
    select * into n from nfce_notas where venda_id = new.id for update;
    if not found then return null; end if;
    if n.estado in ('pendente', 'pendencia', 'rejeitada', 'erro', 'dispensada') then
      update nfce_notas set estado = 'dispensada', erro_pt = 'Venda cancelada antes da emissão: não há nota.', atualizado_em = now() where id = n.id;
    elsif n.estado in ('duvida', 'contingencia', 'emitindo') then
      update nfce_notas set cancelar_pedido = true, atualizado_em = now() where id = n.id;     -- quando a Focus confirmar a autorização, cancela em seguida
    elsif n.estado = 'autorizada' then
      perform public._nfce_iniciar_cancelamento(n.id, 'Venda cancelada: ' || coalesce(nullif(btrim(new.motivo_cancelamento), ''), 'erro de operação'));
    end if;
  exception when others then
    perform public._integ_log('nfce', 'erro', 'Não consegui tratar a nota da venda cancelada ' || coalesce(new.numero_pedido::text, '?') || ': ' || sqlerrm);
  end;
  return null;
end $f$;
drop trigger if exists trg_nfce_cancelada on public.vendas;
create trigger trg_nfce_cancelada after update of status on public.vendas for each row execute function public._nfce_trg_cancelada();

create or replace function public.nfce_pegar_pendentes(p_limite int default 5) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r jsonb;
begin
  with c as (select id from nfce_notas where estado in ('pendente', 'duvida', 'contingencia', 'cancelando') and emitir_apos <= now() and proxima_tentativa <= now() and (trava_ate is null or trava_ate < now())
               order by id limit greatest(1, least(coalesce(p_limite, 5), 20)) for update skip locked),
  u as (update nfce_notas n set trava_ate = now() + interval '2 minutes', atualizado_em = now() from c where n.id = c.id returning n.id, n.ref, n.venda_id, n.ambiente, n.estado, n.tentativas, n.cancelamento_motivo)
  select coalesce(jsonb_agg(to_jsonb(u)), '[]'::jsonb) into r from u;
  return r;
end $f$;

create or replace function public.nfce_resultado(p_id bigint, p_res jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare n nfce_notas%rowtype; v_r text := p_res->>'resultado'; v_msg text := left(coalesce(p_res->>'mensagem', ''), 600); v_tent int;
begin
  select * into n from nfce_notas where id = p_id for update;
  if not found then return jsonb_build_object('ok', false); end if;
  if n.estado in ('autorizada', 'cancelada') and v_r <> 'autorizada' then return jsonb_build_object('ok', true, 'ignorado', true); end if;
  if v_r = 'autorizada' then
    update nfce_notas set estado = 'autorizada', numero = nullif(p_res->>'numero', '')::int, serie = nullif(p_res->>'serie', '')::int, chave = p_res->>'chave', protocolo = p_res->>'protocolo',
      url_danfe = p_res->>'urlDanfe', url_xml = p_res->>'urlXml', url_consulta = p_res->>'urlConsulta', status_sefaz = p_res->>'statusSefaz', mensagem = v_msg, erro_pt = null,
      emitida_em = coalesce(emitida_em, now()), trava_ate = null, atualizado_em = now(), tentativas = tentativas + 1 where id = p_id;
    perform public._integ_log('nfce', 'info', 'Nota ' || coalesce(p_res->>'numero', '?') || ' autorizada (venda ' || n.ref || ')');
    if n.cancelar_pedido then perform public._nfce_iniciar_cancelamento(p_id, 'Venda cancelada no sistema'); end if;
  elsif v_r = 'rejeitada' then
    update nfce_notas set estado = 'rejeitada', status_sefaz = p_res->>'statusSefaz', mensagem = v_msg, erro_pt = public._nfce_traduzir(v_msg), trava_ate = null, atualizado_em = now(), tentativas = tentativas + 1 where id = p_id;
    perform public._integ_log('nfce', 'erro', 'Nota rejeitada (venda ' || n.ref || '): ' || left(v_msg, 200));
  elsif v_r = 'pendencia' then
    update nfce_notas set estado = 'pendencia', erro_pt = left(coalesce(p_res->>'motivo', 'Pendência'), 300), trava_ate = null, atualizado_em = now() where id = p_id;
    perform public._integ_log('nfce', 'aviso', 'Nota parada (venda ' || n.ref || '): ' || left(coalesce(p_res->>'motivo', ''), 200));
  elsif v_r = 'dispensada' then
    update nfce_notas set estado = 'dispensada', erro_pt = left(coalesce(p_res->>'motivo', ''), 300), trava_ate = null, atualizado_em = now() where id = p_id;
  elsif v_r = 'cancelada' then
    update nfce_notas set estado = 'cancelada', cancelada_em = coalesce(cancelada_em, now()), mensagem = v_msg, erro_pt = null, cancelar_manual = false, trava_ate = null, atualizado_em = now() where id = p_id;
    perform public._integ_log('nfce', 'info', 'Nota cancelada (venda ' || n.ref || ')');
  elsif v_r = 'cancelamento_recusado' then
    update nfce_notas set estado = 'autorizada', cancelar_manual = true, mensagem = v_msg, trava_ate = null, atualizado_em = now(),
      erro_pt = 'A Sefaz/Focus não aceitou o cancelamento da nota (' || left(v_msg, 160) || '). O contador precisa orientar o procedimento.' where id = p_id;
    perform public._integ_log('nfce', 'erro', 'Cancelamento recusado (venda ' || n.ref || '): ' || left(v_msg, 200));
  elsif v_r = 'contingencia' then
    update nfce_notas set estado = 'contingencia', numero = nullif(p_res->>'numero', '')::int, serie = nullif(p_res->>'serie', '')::int, chave = p_res->>'chave', mensagem = v_msg,
      proxima_tentativa = now() + interval '3 minutes', trava_ate = null, atualizado_em = now() where id = p_id;
  elsif n.estado = 'cancelando' then   -- dúvida ao cancelar: tenta de novo (consultando antes); depois de 6 tentativas vira pendência manual
    v_tent := n.tentativas + 1;
    update nfce_notas set tentativas = v_tent, mensagem = v_msg, proxima_tentativa = now() + make_interval(mins => least(power(2, least(v_tent, 4))::int, 15)), trava_ate = null, atualizado_em = now(),
      estado = case when v_tent >= 6 then 'autorizada' else 'cancelando' end,
      cancelar_manual = (v_tent >= 6), erro_pt = case when v_tent >= 6 then 'Não consegui cancelar a nota automaticamente. O contador precisa orientar.' else erro_pt end where id = p_id;
  else   -- 'duvida' (rede/timeout/5xx/ainda processando): nunca reenvia às cegas; da próxima vez consulta primeiro
    v_tent := n.tentativas + 1;
    update nfce_notas set estado = case when v_tent >= 8 then 'erro' else 'duvida' end, tentativas = v_tent, mensagem = v_msg,
      erro_pt = case when v_tent >= 8 then 'Não consegui falar com a Focus/Sefaz depois de várias tentativas. Veja o registro e use "Reemitir".' else null end,
      proxima_tentativa = now() + make_interval(mins => least(power(2, least(v_tent, 5))::int, 30)), trava_ate = null, atualizado_em = now() where id = p_id;
    if v_tent >= 8 then perform public._integ_log('nfce', 'erro', 'Nota parada por erro de comunicação (venda ' || n.ref || ')'); end if;
  end if;
  return jsonb_build_object('ok', true);
end $f$;

-- ---------- inutilização de numeração ----------
create table if not exists public.nfce_inutilizacoes (
  id bigserial primary key, serie int not null, numero_ini int not null, numero_fim int not null check (numero_fim >= numero_ini),
  justificativa text not null check (length(justificativa) between 15 and 255), ambiente text not null check (ambiente in ('homologacao', 'producao')),
  estado text not null default 'pendente' check (estado in ('pendente', 'feita', 'recusada', 'duvida')), resposta text, por text,
  criado_em timestamptz not null default now(), feito_em timestamptz, trava_ate timestamptz, tentativas int not null default 0
);
alter table public.nfce_inutilizacoes enable row level security;

create or replace function public.nfce_inutilizacoes_pendentes() returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r jsonb;
begin
  with c as (select id from nfce_inutilizacoes where estado in ('pendente', 'duvida') and (trava_ate is null or trava_ate < now()) order by id limit 3 for update skip locked),
  u as (update nfce_inutilizacoes i set trava_ate = now() + interval '2 minutes' from c where i.id = c.id returning i.id, i.serie, i.numero_ini, i.numero_fim, i.justificativa, i.ambiente)
  select coalesce(jsonb_agg(to_jsonb(u)), '[]'::jsonb) into r from u;
  return r;
end $f$;

create or replace function public.nfce_inutilizacao_resultado(p_id bigint, p_estado text, p_msg text) returns void
 language plpgsql security definer set search_path to 'public' as $f$
begin
  update nfce_inutilizacoes set estado = case when p_estado in ('feita', 'recusada') then p_estado else case when tentativas + 1 >= 6 then 'recusada' else 'duvida' end end,
    resposta = left(coalesce(p_msg, ''), 400), feito_em = case when p_estado = 'feita' then now() else feito_em end, tentativas = tentativas + 1, trava_ate = null where id = p_id;
  perform public._integ_log('nfce', case when p_estado = 'feita' then 'info' else 'aviso' end, 'Inutilização ' || p_estado || ': ' || left(coalesce(p_msg, ''), 150));
end $f$;

-- ---------- telas ----------
-- conferência: vendas que deveriam ter nota e não têm, notas com problema, numeração pulada
create or replace function public.api_nfce_conferencia(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare c integracoes_config%rowtype; v_dias int := least(coalesce(nullif(p->>'dias', '')::int, 30), 120); v_quando text; v_canais jsonb;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into c from integracoes_config where provedor = 'nfce';
  v_quando := coalesce(c.config->>'emitirQuando', 'pagamento'); v_canais := coalesce(c.config->'canais', '["balcao"]'::jsonb);
  return jsonb_build_object('ok', true, 'ligado', c.ligado, 'modo', c.modo, 'dias', v_dias,
    'semNota', coalesce((select jsonb_agg(jsonb_build_object('vendaId', v.id, 'pedido', v.numero_pedido, 'cliente', v.cliente_nome, 'quando', v.data_hora, 'valor', v.valor_total) order by v.data_hora desc)
       from (select * from vendas v where v.status::text = 'Confirmada' and v.data_hora > now() - make_interval(days => v_dias) and (c.ligado_em is null or v.data_hora >= c.ligado_em)
               and v_canais ? public._nfce_canal_da_venda(v.origem::text, v.tipo::text, v.canal)
               and case when v_quando = 'entrega' then v.status_pedido::text in ('Entregue', 'Retirada', 'Servida') else v.status_pagamento::text = 'Pago' end
               and v.valor_total > 0 and not exists (select 1 from nfce_notas n where n.venda_id = v.id) order by v.data_hora desc limit 100) v), '[]'::jsonb),
    'comProblema', (select count(*) from nfce_notas where estado in ('rejeitada', 'pendencia', 'erro') and criado_em > now() - make_interval(days => v_dias)),
    'cancelarManual', coalesce((select jsonb_agg(jsonb_build_object('id', n.id, 'pedido', v.numero_pedido, 'numero', n.numero, 'motivo', n.erro_pt)) from nfce_notas n left join vendas v on v.id = n.venda_id where n.cancelar_manual), '[]'::jsonb),
    'buracos', coalesce((select jsonb_agg(jsonb_build_object('serie', g.serie, 'ini', g.ini, 'fim', g.fim) order by g.serie, g.ini) from (
        select x.serie, x.numero + 1 ini, x.prox - 1 fim from (select serie, numero, lead(numero) over (partition by serie order by numero) prox
          from (select distinct serie, numero from nfce_notas where ambiente = c.modo and numero is not null and estado in ('autorizada', 'cancelada')) t) x
        where x.prox is not null and x.prox - x.numero > 1
          and not exists (select 1 from nfce_inutilizacoes i where i.serie = x.serie and i.ambiente = c.modo and i.estado in ('feita', 'pendente', 'duvida') and i.numero_ini <= x.numero + 1 and i.numero_fim >= x.prox - 1)) g), '[]'::jsonb),
    'inutilizacoes', coalesce((select jsonb_agg(jsonb_build_object('serie', i.serie, 'ini', i.numero_ini, 'fim', i.numero_fim, 'estado', i.estado, 'em', i.criado_em) order by i.id desc) from (select * from nfce_inutilizacoes order by id desc limit 10) i), '[]'::jsonb),
    'totais', jsonb_build_object(
      'vendas', (select coalesce(sum(v.valor_total), 0) from vendas v where v.status::text = 'Confirmada' and v.data_hora > now() - make_interval(days => v_dias) and (c.ligado_em is null or v.data_hora >= c.ligado_em) and v_canais ? public._nfce_canal_da_venda(v.origem::text, v.tipo::text, v.canal)),
      'notas', (select coalesce(sum(valor), 0) from nfce_notas where estado = 'autorizada' and ambiente <> 'simulado' and criado_em > now() - make_interval(days => v_dias))));
end $f$;

create or replace function public.api_nfce_inutilizar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_ini int := (p->>'ini')::int; v_fim int := (p->>'fim')::int; v_serie int := coalesce(nullif(p->>'serie', '')::int, 1); v_j text := btrim(coalesce(p->>'justificativa', '')); v_modo text; v_uid text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  v_uid := _exige_admin(p->>'senhaAdmin');
  if coalesce(p->>'senhaAdmin', '') = '' or v_uid is null then return _falha('Senha de administrador incorreta.'); end if;
  select modo into v_modo from integracoes_config where provedor = 'nfce';
  if v_ini is null or v_fim is null or v_fim < v_ini or v_fim - v_ini > 50 then return _falha('Faixa de números inválida.'); end if;
  if length(v_j) < 15 then v_j := 'Numeração pulada por falha de emissão'; end if;
  if exists (select 1 from nfce_notas where serie = v_serie and numero between v_ini and v_fim and ambiente = v_modo and estado in ('autorizada', 'cancelada')) then return _falha('Algum desses números já foi usado por uma nota.'); end if;
  insert into nfce_inutilizacoes (serie, numero_ini, numero_fim, justificativa, ambiente, por) values (v_serie, v_ini, v_fim, left(v_j, 255), v_modo, v_uid);
  perform _auditar('Nota fiscal: inutilização pedida', v_serie || ' · ' || v_ini || '-' || v_fim);
  perform public.chamar_edge('nfce-emitir', '{}'::jsonb);
  return api_nfce_conferencia('{}') || jsonb_build_object('message', 'Inutilização enviada. Atualize em instantes.');
end $f$;

-- pacote do contador: dados do mês (a Focus também baixa o conjunto de XML do mês no painel dela)
create or replace function public.api_nfce_pacote(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_ano int := coalesce(nullif(p->>'ano', '')::int, extract(year from now() at time zone 'America/Sao_Paulo')::int); v_mes int := coalesce(nullif(p->>'mes', '')::int, extract(month from now() at time zone 'America/Sao_Paulo')::int);
  v_ini timestamptz; v_fim timestamptz; v_modo text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_mes not between 1 and 12 or v_ano not between 2024 and 2100 then return _falha('Mês inválido.'); end if;
  v_ini := make_timestamptz(v_ano, v_mes, 1, 0, 0, 0, 'America/Sao_Paulo'); v_fim := v_ini + interval '1 month';
  select modo into v_modo from integracoes_config where provedor = 'nfce';
  return jsonb_build_object('ok', true, 'ano', v_ano, 'mes', v_mes, 'ambiente', v_modo,
    'notas', coalesce((select jsonb_agg(jsonb_build_object('pedido', v.numero_pedido, 'emitidaEm', n.emitida_em, 'numero', n.numero, 'serie', n.serie, 'chave', n.chave, 'valor', n.valor, 'estado', n.estado,
        'canceladaEm', n.cancelada_em, 'comCpf', n.cpf is not null, 'xml', n.url_xml, 'danfe', n.url_danfe) order by n.numero)
      from nfce_notas n left join vendas v on v.id = n.venda_id where n.ambiente = v_modo and n.estado in ('autorizada', 'cancelada') and n.emitida_em >= v_ini and n.emitida_em < v_fim), '[]'::jsonb),
    'inutilizacoes', coalesce((select jsonb_agg(jsonb_build_object('serie', serie, 'ini', numero_ini, 'fim', numero_fim, 'estado', estado, 'em', criado_em)) from nfce_inutilizacoes where ambiente = v_modo and criado_em >= v_ini and criado_em < v_fim), '[]'::jsonb));
end $f$;

-- saúde: acrescenta o aviso do limite do plano (80% de 500 notas) e o cancelamento pendente
create or replace function public._saude_nfce() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare r record; v_rej int; v_pend int; v_atras int; v_cont int; v_man int; v_mes int; v_nivel text; v_txt text;
begin
  select * into r from integracoes_config where ligado and provedor = 'nfce';
  if not found then return '[]'::jsonb; end if;
  select count(*) filter (where estado in ('rejeitada', 'erro')), count(*) filter (where estado = 'pendencia'), count(*) filter (where estado in ('pendente', 'duvida', 'cancelando') and emitir_apos < now() - interval '10 minutes'),
         count(*) filter (where estado = 'contingencia'), count(*) filter (where cancelar_manual)
    into v_rej, v_pend, v_atras, v_cont, v_man from nfce_notas where criado_em > now() - interval '7 days' or cancelar_manual;
  select count(*) into v_mes from nfce_notas where estado in ('autorizada', 'cancelada') and ambiente = 'producao' and emitida_em >= date_trunc('month', now() at time zone 'America/Sao_Paulo') at time zone 'America/Sao_Paulo';
  v_nivel := case when v_atras > 0 or v_rej > 0 then 'problema' when v_pend > 0 or v_cont > 0 or v_man > 0 or v_mes >= 400 or public._fiscal_sem_perfil_qtd() > 0 then 'atencao' else 'ok' end;
  v_txt := 'Nota fiscal ligada (' || case when r.modo = 'producao' then 'produção' else 'teste' end || ')'
    || case when v_rej > 0 then ' · ' || v_rej || ' nota(s) rejeitada(s)/com erro' else '' end
    || case when v_atras > 0 then ' · ' || v_atras || ' nota(s) esperando há mais de 10 min' else '' end
    || case when v_pend > 0 then ' · ' || v_pend || ' parada(s) por pendência (ex.: item sem perfil)' else '' end
    || case when v_cont > 0 then ' · ' || v_cont || ' em contingência' else '' end
    || case when v_man > 0 then ' · ' || v_man || ' cancelamento(s) para o contador orientar' else '' end
    || case when v_mes >= 400 then ' · ' || v_mes || ' de 500 notas do plano usadas neste mês' else '' end
    || case when public._fiscal_sem_perfil_qtd() > 0 then ' · ' || public._fiscal_sem_perfil_qtd() || ' item(ns) sem perfil fiscal' else '' end;
  return jsonb_build_array(jsonb_build_object('id', 'nfce', 'titulo', 'Nota fiscal (NFC-e)', 'nivel', v_nivel, 'texto', v_txt));
end $f$;

-- api_nfce_lista passa a mostrar também quem precisa de cancelamento manual
create or replace function public.api_nfce_lista(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_est text := nullif(p->>'estado', ''); v_lim int := least(coalesce(nullif(p->>'limite', '')::int, 60), 200);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'contagem', coalesce((select jsonb_object_agg(estado, q) from (select estado, count(*) q from nfce_notas where criado_em > now() - interval '30 days' group by 1) x), '{}'::jsonb),
    'mes', (select count(*) from nfce_notas where estado in ('autorizada', 'cancelada') and ambiente = 'producao' and emitida_em >= date_trunc('month', now() at time zone 'America/Sao_Paulo') at time zone 'America/Sao_Paulo'),
    'itens', coalesce((select jsonb_agg(jsonb_build_object('id', n.id, 'vendaId', n.venda_id, 'pedido', v.numero_pedido, 'cliente', v.cliente_nome, 'quando', v.data_hora, 'estado', n.estado, 'ambiente', n.ambiente,
        'numero', n.numero, 'serie', n.serie, 'valor', n.valor, 'erro', n.erro_pt, 'danfe', n.url_danfe, 'xml', n.url_xml, 'consulta', n.url_consulta, 'cpf', (n.cpf is not null), 'tentativas', n.tentativas,
        'emitidaEm', n.emitida_em, 'canceladaEm', n.cancelada_em, 'cancelarManual', n.cancelar_manual) order by n.id desc)
      from (select * from nfce_notas where (v_est is null or estado = v_est) order by id desc limit v_lim) n left join vendas v on v.id = n.venda_id), '[]'::jsonb));
end $f$;

-- cron: inclui "cancelando" e inutilizações
do $c$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.schedule('nfce-emitir-minuto', '* * * * *', $j$select case when public._integracao_ligada('nfce') and (exists (select 1 from public.nfce_notas where estado in ('pendente', 'duvida', 'contingencia', 'cancelando') and emitir_apos <= now() and proxima_tentativa <= now()) or exists (select 1 from public.nfce_inutilizacoes where estado in ('pendente', 'duvida'))) then public.chamar_edge('nfce-emitir', '{}'::jsonb) end$j$);
  end if;
end $c$;

-- ---------- permissões ----------
revoke execute on function public._nfce_iniciar_cancelamento(bigint, text), public._nfce_trg_cancelada(), public.nfce_pegar_pendentes(int), public.nfce_resultado(bigint, jsonb),
  public.nfce_inutilizacoes_pendentes(), public.nfce_inutilizacao_resultado(bigint, text, text), public._saude_nfce() from public, anon, authenticated;
grant execute on function public.nfce_pegar_pendentes(int), public.nfce_resultado(bigint, jsonb), public.nfce_inutilizacoes_pendentes(), public.nfce_inutilizacao_resultado(bigint, text, text) to service_role;
revoke execute on function public.api_nfce_conferencia(jsonb), public.api_nfce_inutilizar(jsonb), public.api_nfce_pacote(jsonb), public.api_nfce_lista(jsonb) from public, anon;
grant execute on function public.api_nfce_conferencia(jsonb), public.api_nfce_inutilizar(jsonb), public.api_nfce_pacote(jsonb), public.api_nfce_lista(jsonb) to authenticated;

insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-108-nfce-fechamento','Nota fiscal: cancelamento, numeração pulada, conferência e pacote do contador','nota fiscal nfc-e cancelar cancelamento inutilizar inutilização conferência vendas sem nota pacote contador limite plano 500',
 E'Cancelamento: se você cancela uma venda que já tem nota, o sistema cancela a nota sozinho desde que sejam menos de 30 minutos da emissão. Passou do prazo, a nota fica marcada "cancelamento para o contador orientar" (nada é apagado) e aparece na Saúde do sistema.
Conferência (Integrações → Nota fiscal → Conferência): lista as vendas que deveriam ter nota e não têm (com botão Emitir), notas com problema e números pulados. Para número pulado, toque em Inutilizar (pede sua senha) e informe o motivo.
Pacote do contador: escolha o mês e baixe a planilha com número, série, chave, valor e situação de cada nota, mais a lista de links dos XML. A Focus também baixa todos os XML do mês no painel dela.
Limite do plano: a tela mostra quantas notas já foram emitidas no mês (plano de 500); a 80% aparece um aviso na Saúde do sistema.',
 array['Admin'],true,'lista',108,'Só Administrador.'
where not exists (select 1 from ai_ajuda where slug='man-admin-108-nfce-fechamento');


-- ################ PARTE: f7-assistente-grava-mais ################
-- Manual do Assistente: o que a IA pode propor (sempre com cartão e Confirmar). Seguro para rodar de novo.
insert into public.ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-99-assistente-grava-mais','Assistente: registrar coisas pelo chat',
 'assistente ia registrar lançar despesa pagar estoque entrada perda inventário contagem ingrediente cliente ocorrência sangria compra receber cancelar ajuste pós-venda brinde confirmar cartão',
 E'Peça em frase normal, por exemplo: "comprei 3 kg de farinha do fornecedor X por R$ 20", "perdi 2 kg de farinha", "paguei R$ 120 de luz", "contei 12 kg de açúcar", "sangria de R$ 50 para troco".\nO Assistente nunca grava sozinho: aparece um cartão com o que será gravado. Se faltar algo ou não achar o nome, o cartão avisa em laranja e o botão Confirmar fica travado.\nToque em "Confirmar e gravar" para gravar ou em "Descartar" para não gravar nada.\nPode registrar: compra, receber ou cancelar pedido de compra, fornecedor, despesa nova, pagar despesa, cancelar despesa, entrada/perda/contagem de estoque, cadastrar ou editar ingrediente, cliente, ocorrência, sangria, ajuste pós-venda e brinde.\nCancelar despesa e ajuste pós-venda pedem a senha de administrador no cartão.\nNunca pelo Assistente: excluir qualquer coisa, cancelar ou editar venda, abrir ou fechar caixa, usuários e senhas, contas e acessos, preços, cardápio e configurações. Faça nas telas.',
 array['Admin'],true,'lista',99,'Só Administrador e Desenvolvedor. Sangria e despesa do caixa exigem o caixa aberto.'
where not exists (select 1 from ai_ajuda where slug='man-admin-99-assistente-grava-mais');

commit;
