-- TEXAS BURGER — SQL MANUAL (só o que o Supabase não deixou eu aplicar sozinho) · 2026-10-11
-- Como usar: Supabase → SQL Editor → New query → cole TUDO → Run. Se aparecer aviso de 'destructive/destrutivo', confirme: é normal.
-- Pode rodar mais de uma vez sem problema.

-- 1) Texto da ajuda: Contas e acessos
update ai_ajuda set palavras_chave = 'contas acessos email senha link supabase github planilha apps script cofre ver senha chave ia gemini groq nvidia cloudflare reserva',
  passos = E'Administrador → Sistema → Contas e acessos: lista das contas do sistema (Supabase, GitHub, planilhas…) com e-mail, link e observação.\n"+ Nova conta" cadastra; "Editar" muda os dados ou a senha; "Excluir" apaga a conta e a senha guardada.\nA senha fica no cofre criptografado do Supabase. Para ver, toque em "Ver senha" e digite a SUA senha de administrador; ela aparece por 30 segundos e fica registrado na Auditoria.\nChaves das IAs (Gemini, Groq, NVIDIA e Cloudflare): na mesma tela. "Ver chave" e "Trocar chave" pedem a senha de administrador; a chave nova vale na hora. NVIDIA e Cloudflare são IAs de reserva: sem chave, nada muda; com chave, entram quando o Gemini e a Groq falham ou esgotam o limite grátis.'
where slug = 'man-admin-101-contas-e-acessos';

-- 2) Texto da ajuda: Saúde do sistema
update ai_ajuda set
  palavras_chave = 'saúde sistema conexão servidores backup conferência vendas tarefas automáticas bolinha verde vermelha',
  passos = E'A "Saúde do sistema" fica dentro de "Conexão e servidores": toque na bolinha colorida do topo.\nLá aparecem os servidores e, logo abaixo, cada item: cópia para a planilha, backup (diário às 04:00), cópia no Drive, conferência diária de vendas, tarefas automáticas e Assistente.\nA própria bolinha do topo muda de cor: verde = tudo certo, amarela = atenção, rosa = precisa de cuidado (se a conexão cair, ela fica vermelha ou laranja). Amarelo pede atenção; vermelho pede ação (ex.: backup com mais de 48 h ou vendas diferentes entre Supabase e planilha).\nDesenvolvedor: o botão "Simular queda (treino)" fica em "Conexão e servidores" e finge a queda só neste aparelho. "Encerrar simulação" volta ao normal.',
  comuns = 'Só Admin e Desenvolvedor veem a Saúde do sistema.'
where slug = 'man-admin-97-saude-sistema';

-- 3) iFood: gravar itens do pedido
create or replace function public._ifood_gravar_itens(p_venda uuid, p_order jsonb, p_regravar boolean) returns int
 language plpgsql security definer set search_path to 'public' as $f$
declare it jsonb; op jsonb; v_item ifood_itens%rowtype; v_op ifood_itens%rowtype; v_chave text; v_qtd int; v_tot numeric; v_ads uuid[]; v_desc text; v_custo numeric; v_sem int := 0; v_obs text; v_oq int;
begin
  if p_regravar then
    perform _ajustar_estoque(_itens_da_venda(p_venda), -1, p_venda);
    delete from itens_venda where venda_id = p_venda;
  end if;
  for it in select value from jsonb_array_elements(coalesce(p_order->'items', '[]'::jsonb)) loop
    v_chave := coalesce(nullif(it->>'externalCode', ''), nullif(it->>'id', ''), 'sem-codigo-' || public._ifood_norm(it->>'name'));
    v_qtd := greatest(1, round(public._ifood_n(it->'quantity'))::int);
    v_tot := public._ifood_n(it->'totalPrice');
    if v_tot <= 0 then v_tot := public._ifood_n(it->'price'); end if;
    if v_tot <= 0 then v_tot := (public._ifood_n(it->'unitPrice') + public._ifood_n(it->'optionsPrice')) * v_qtd; end if;
    v_item := public._ifood_item_visto(v_chave, it->>'name', 'produto');
    v_ads := '{}'; v_desc := coalesce(it->>'name', 'Item iFood'); v_obs := nullif(btrim(coalesce(it->>'observations', '')), '');
    for op in select value from jsonb_array_elements(coalesce(it->'options', '[]'::jsonb)) loop
      v_op := public._ifood_item_visto(coalesce(nullif(op->>'externalCode', ''), nullif(op->>'id', ''), 'sem-codigo-' || public._ifood_norm(op->>'name')), op->>'name', 'opcao');
      v_oq := greatest(1, round(public._ifood_n(op->'quantity'))::int);
      v_desc := v_desc || ' + ' || coalesce(op->>'name', 'opção') || case when v_oq > 1 then ' x' || v_oq else '' end;
      if v_op.adicional_id is not null then
        for i in 1..(v_oq * v_qtd) loop v_ads := v_ads || v_op.adicional_id; end loop;
      end if;
    end loop;
    if v_obs is not null then v_desc := v_desc || ' (obs: ' || v_obs || ')'; end if;
    v_custo := 0;
    if v_item.produto_id is not null then select coalesce(min(custo), 0) into v_custo from produto_precos where produto_id = v_item.produto_id;
    elsif v_item.combo_id is not null then select coalesce(min(custo), 0) into v_custo from combo_precos where combo_id = v_item.combo_id;
    end if;
    if v_item.produto_id is null and v_item.combo_id is null and not v_item.ignorar then v_sem := v_sem + 1; v_desc := v_desc || ' [SEM LIGAÇÃO]'; end if;
    insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
    values (p_venda, case when v_item.ignorar then null else v_item.produto_id end, case when v_item.ignorar then null else v_item.combo_id end,
            left(v_desc, 300), v_qtd, round(v_tot / v_qtd, 2), round(v_custo, 2), round(v_tot, 2), v_ads);
  end loop;
  perform _ajustar_estoque(_itens_da_venda(p_venda), 1, p_venda);
  return v_sem;
end $f$;
revoke execute on function public._ifood_gravar_itens(uuid, jsonb, boolean) from public, anon, authenticated;
grant execute on function public._ifood_gravar_itens(uuid, jsonb, boolean) to service_role;

-- 4) iFood: limpeza diária
create or replace function public.ifood_limpar() returns void language plpgsql security definer set search_path to 'public' as $f$
declare v_dias int := coalesce((select (config->>'retencaoClientesDias')::int from integracoes_config where provedor = 'ifood'), 90);
begin
  delete from ifood_eventos where recebido_em < now() - interval '30 days';
  delete from ifood_acoes where criado_em < now() - interval '60 days' and estado in ('ok', 'pulada');
  update ifood_pedidos set bruto = jsonb_set(coalesce(bruto, '{}'::jsonb) - 'customer' - 'delivery', '{apagado}', 'true'::jsonb) where criado_em < now() - make_interval(days => v_dias) and coalesce((bruto->>'apagado'), '') <> 'true';
  update vendas set telefone_cliente = null, endereco = '', complemento = '', referencia = '', cliente_nome = 'Cliente iFood'
   where canal = 'iFood' and data_hora < now() - make_interval(days => v_dias) and (telefone_cliente is not null or endereco <> '' or cliente_nome <> 'Cliente iFood');
end $f$;

revoke execute on function public.ifood_limpar() from public, anon, authenticated;
grant execute on function public.ifood_limpar() to service_role;

-- 5) Nota fiscal: excluir perfil fiscal
create or replace function public.api_fiscal_perfil_excluir(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_id uuid := (p->>'id')::uuid; v_nome text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select nome into v_nome from fiscal_perfis where id = v_id;
  if v_nome is null then return _falha('Perfil não encontrado.'); end if;
  if exists (select 1 from produtos where perfil_fiscal_id = v_id) or exists (select 1 from combos where perfil_fiscal_id = v_id) or exists (select 1 from categorias where perfil_fiscal_id = v_id)
     or exists (select 1 from fiscal_empresa where perfil_padrao_id = v_id) then
    return _falha('Este perfil está em uso. Troque o perfil dos itens antes de excluir (ou desative o perfil).');
  end if;
  delete from fiscal_perfis where id = v_id;
  perform _auditar('Fiscal: perfil excluído', v_nome);
  return api_fiscal_perfis('{}') || jsonb_build_object('message', 'Perfil excluído.');
end $f$;

revoke execute on function public.api_fiscal_perfil_excluir(jsonb) from public, anon;
grant execute on function public.api_fiscal_perfil_excluir(jsonb) to authenticated;

-- 6) Limpezas
drop index if exists public.ifood_acoes_pend_uk;
drop function if exists public._tmp_teste_delete(uuid);
