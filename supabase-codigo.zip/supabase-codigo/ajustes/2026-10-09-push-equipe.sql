-- =====================================================================
-- TEXAS BURGER — Avisos com o app fechado (Web Push) para a equipe (item 28) · 2026-10-09
-- Antes de rodar: guardar as chaves VAPID no Vault (uma vez; gere um par novo, não reuse o de outro sistema):
--   select vault.create_secret('<chave privada>', 'vapid_privada');
--   select vault.create_secret('<chave pública>',  'vapid_publica');
-- A chave PÚBLICA também vai no index.html (constante PUSH_CHAVE_PUBLICA_). Depois publique a função push-enviar (verify_jwt desligado)
-- e suba o sw.js novo (v4) na mesma pasta do index.html. Seguro para rodar de novo.
-- =====================================================================
create table if not exists public.push_inscricoes (
  id uuid primary key default gen_random_uuid(),
  usuario_id uuid not null references public.usuarios(id) on delete cascade,
  endpoint text not null unique check (endpoint like 'https://%' and char_length(endpoint) <= 800),
  p256dh text not null check (char_length(p256dh) <= 200),
  auth text not null check (char_length(auth) <= 100),
  criado_em timestamptz not null default now(),
  ultimo_envio_em timestamptz,
  falhas int not null default 0
);
create index if not exists push_inscricoes_usuario_idx on public.push_inscricoes (usuario_id);
alter table public.push_inscricoes enable row level security;
revoke all on public.push_inscricoes from anon, authenticated;

create or replace function public.api_segredo(p_nome text) returns text language sql security definer set search_path to 'public','vault' as $f$
  select decrypted_secret from vault.decrypted_secrets
  where name = p_nome and p_nome in ('sheets_main_url','chave_servidor_planilha','publishable_key','service_key','vapid_privada','vapid_publica') limit 1 $f$;

create or replace function public.api_push_inscrever(p jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare v_ep text := btrim(coalesce(p->>'endpoint','')); v_k text := btrim(coalesce(p->'keys'->>'p256dh','')); v_a text := btrim(coalesce(p->'keys'->>'auth',''));
begin
  if not tem_nivel('Operador') then return _negado(); end if;
  if v_ep not like 'https://%' or char_length(v_ep) > 800 or v_k = '' or v_a = '' or char_length(v_k) > 200 or char_length(v_a) > 100 then return _falha('Inscrição inválida.'); end if;
  insert into push_inscricoes (usuario_id, endpoint, p256dh, auth) values (auth.uid(), v_ep, v_k, v_a)
  on conflict (endpoint) do update set usuario_id = excluded.usuario_id, p256dh = excluded.p256dh, auth = excluded.auth, falhas = 0;
  delete from push_inscricoes where usuario_id = auth.uid() and id not in (select id from push_inscricoes where usuario_id = auth.uid() order by criado_em desc limit 10);
  perform _auditar('Avisos com app fechado ativados', null);
  return jsonb_build_object('ok', true, 'message', 'Avisos com o app fechado ativados neste aparelho.');
end $f$;

create or replace function public.api_push_cancelar(p jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
begin
  if auth.uid() is null then return _negado(); end if;
  delete from push_inscricoes where usuario_id = auth.uid() and endpoint = btrim(coalesce(p->>'endpoint',''));
  return jsonb_build_object('ok', true, 'message', 'Avisos com o app fechado desativados neste aparelho.');
end $f$;

create or replace function public._push_enviar(p_tipo text, p_titulo text, p_texto text, p_tag text) returns void language plpgsql security definer set search_path to 'public','extensions' as $f$
begin
  if not exists (select 1 from push_inscricoes limit 1) then return; end if;
  perform chamar_edge('push-enviar', jsonb_build_object('tipo', p_tipo, 'titulo', p_titulo, 'texto', p_texto, 'tag', p_tag));
exception when others then null;   -- o aviso nunca atrapalha o pedido nem o chat
end $f$;

create or replace function public._push_novo_pedido() returns trigger language plpgsql security definer set search_path to 'public' as $f$
begin
  if new.origem::text = 'Cardápio' then
    perform _push_enviar('pedido', '🍔 Novo pedido #' || coalesce(new.numero_pedido::text, ''), coalesce(new.tipo::text, '') || ' · R$ ' || replace(to_char(coalesce(new.valor_total, 0), 'FM9999990.00'), '.', ','), 'pedido-' || new.id::text);
  end if;
  return null;
end $f$;

create or replace function public._push_chat_cliente() returns trigger language plpgsql security definer set search_path to 'public' as $f$
begin
  if new.autor = 'cliente' and exists (select 1 from chat_conversas c where c.id = new.conversa_id and c.estado in ('recepcao','em_atendimento'))
     and not exists (select 1 from chat_mensagens m where m.conversa_id = new.conversa_id and m.autor = 'cliente' and m.id <> new.id and m.criado_em > now() - interval '2 minutes') then
    perform _push_enviar('chat', '💬 Cliente no atendimento', 'Há uma mensagem aguardando resposta.', 'chat-' || new.conversa_id::text);
  end if;
  return null;
end $f$;

do $do$ begin
  if not exists (select 1 from pg_trigger where tgname = 'trg_push_novo_pedido') then
    execute 'create trigger trg_push_novo_pedido after insert on public.vendas for each row execute function public._push_novo_pedido()';
  end if;
  if not exists (select 1 from pg_trigger where tgname = 'trg_push_chat_cliente') then
    execute 'create trigger trg_push_chat_cliente after insert on public.chat_mensagens for each row execute function public._push_chat_cliente()';
  end if;
end $do$;

grant execute on function public.api_push_inscrever(jsonb), public.api_push_cancelar(jsonb) to authenticated;
revoke execute on function public.api_push_inscrever(jsonb), public.api_push_cancelar(jsonb) from anon, public;
revoke execute on function public._push_enviar(text,text,text,text), public._push_novo_pedido(), public._push_chat_cliente() from public, anon, authenticated;
