-- =====================================================================
-- FASE 3 — iFOOD INTELIGÊNCIA · 2026-10-11
-- Importar/enviar preços (com trava de segurança, histórico e desfazer), pausar item sem estoque,
-- financeiro (a receber do iFood, repasses, comissão real), avaliações, relatório por canal.
-- Precisa das Fases 0, 1 e 2 antes. Seguro para rodar de novo. TUDO DESLIGADO.
-- ⚠️ Endereços do catálogo, financeiro e avaliações do iFood vêm de fontes de terceiros: ainda não testado com o iFood de verdade.
-- =====================================================================

alter table public.ifood_itens add column if not exists ifood_item_id text;           -- id do item dentro do iFood (para preço e pausa)
alter table public.ifood_itens add column if not exists preco_ifood numeric;
alter table public.ifood_itens add column if not exists preco_visto_em timestamptz;
alter table public.ifood_itens add column if not exists categoria text;
alter table public.ifood_itens add column if not exists pausado_por_nos boolean not null default false;
alter table public.ifood_pedidos add column if not exists repassado_em timestamptz;
alter table public.ifood_pedidos add column if not exists repasse_id text;
alter table public.ifood_pedidos add column if not exists comissao numeric;
alter table public.ifood_estado add column if not exists financeiro_em timestamptz;
alter table public.ifood_estado add column if not exists avaliacoes_em timestamptz;

alter table public.ifood_acoes drop constraint if exists ifood_acoes_acao_check;
alter table public.ifood_acoes add constraint ifood_acoes_acao_check check (acao in
  ('confirmar','iniciar_preparo','pronto','despachar','cancelar','negociacao_aceitar','negociacao_recusar','negociacao_alternativa','loja_fechar','loja_abrir','loja_pausar','loja_retomar',
   'catalogo_importar','catalogo_preco','catalogo_pausar','catalogo_retomar','avaliacao_responder'));

-- a trava de "uma ação pendente por pedido" agora também separa por item/avaliação/disputa (várias pausas e preços podem esperar ao mesmo tempo)
drop index if exists public.ifood_acoes_pend_uk;
create unique index if not exists ifood_acoes_pend_uk2 on public.ifood_acoes (pedido_ifood, acao, (coalesce(dados->>'chave', dados->>'avaliacao', dados->>'disputa', ''))) where estado in ('pendente','duvida');

create table if not exists public.ifood_precos_hist (
  id bigserial primary key, quando timestamptz not null default now(), chave text not null, nome text,
  preco_antes numeric, preco_depois numeric, origem text not null check (origem in ('importar','enviar','desfazer')),
  usuario text, estado text not null default 'pendente' check (estado in ('pendente','ok','erro','desfeito')), erro text);
alter table public.ifood_precos_hist enable row level security;

create table if not exists public.ifood_repasses (
  id text primary key, pago_em date, periodo_ini date, periodo_fim date, valor numeric not null default 0,
  pedidos int not null default 0, bruto jsonb, criado_em timestamptz not null default now());
alter table public.ifood_repasses enable row level security;

create table if not exists public.ifood_avaliacoes (
  id text primary key, pedido_ifood text, nota int, comentario text, criada_em timestamptz, resposta text, respondida_em timestamptz,
  feedback_id uuid, bruto jsonb, visto_em timestamptz not null default now());
alter table public.ifood_avaliacoes enable row level security;

-- ---------- preço do iFood no sistema = linha da forma de pagamento "iFood" (preço próprio) ----------
create or replace function public._ifood_forma() returns uuid language sql stable security definer set search_path to 'public' as $f$
  select id from formas_pagamento where lower(nome) = 'ifood' order by preco_proprio desc limit 1
$f$;

create or replace function public._ifood_preco_sistema(p_item ifood_itens) returns numeric language sql stable security definer set search_path to 'public' as $f$
  select coalesce(
    (select pp.preco from produto_precos pp where pp.produto_id = p_item.produto_id and pp.forma_pagamento_id = public._ifood_forma()),
    (select min(pp.preco) from produto_precos pp where pp.produto_id = p_item.produto_id),
    (select cp.preco from combo_precos cp where cp.combo_id = p_item.combo_id and cp.forma_pagamento_id = public._ifood_forma()),
    (select min(cp.preco) from combo_precos cp where cp.combo_id = p_item.combo_id))
$f$;

-- catálogo trazido do iFood (servidor): atualiza itens e preços vistos
create or replace function public.ifood_catalogo_gravar(p_itens jsonb) returns int language plpgsql security definer set search_path to 'public' as $f$
declare e jsonb; v_n int := 0; r ifood_itens%rowtype; v_chave text;
begin
  for e in select value from jsonb_array_elements(coalesce(p_itens, '[]'::jsonb)) loop
    v_chave := coalesce(nullif(e->>'externalCode', ''), nullif(e->>'id', ''));
    if v_chave is null then continue; end if;
    r := public._ifood_item_visto(v_chave, e->>'name', 'produto');
    update ifood_itens set ifood_item_id = coalesce(nullif(e->>'id', ''), ifood_item_id), preco_ifood = case when e ? 'price' then public._ifood_n(e->'price') else preco_ifood end,
      preco_visto_em = now(), categoria = left(coalesce(nullif(e->>'category', ''), categoria), 120) where chave = v_chave;
    v_n := v_n + 1;
  end loop;
  perform public._integ_log('ifood', 'info', 'Catálogo do iFood importado: ' || v_n || ' item(ns)');
  return v_n;
end $f$;

create or replace function public.ifood_preco_confirmar(p_id bigint, p_ok boolean, p_erro text default null) returns void language plpgsql security definer set search_path to 'public' as $f$
declare h ifood_precos_hist%rowtype;
begin
  update ifood_precos_hist set estado = case when p_ok then 'ok' else 'erro' end, erro = left(p_erro, 300) where id = p_id returning * into h;
  if p_ok and h.id is not null then update ifood_itens set preco_ifood = h.preco_depois, preco_visto_em = now() where chave = h.chave; end if;
end $f$;

-- tela: preços sistema × iFood
create or replace function public.api_ifood_precos(p jsonb default '{}'::jsonb) returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare v_lim numeric := coalesce((select (config->>'limitePrecoPct')::numeric from integracoes_config where provedor = 'ifood'), 30);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'limitePct', v_lim, 'enviarLigado', coalesce((select (config->>'enviarPrecos')::boolean from integracoes_config where provedor = 'ifood'), false),
    'itens', coalesce((select jsonb_agg(x order by (x->>'nome')) from (
      select jsonb_build_object('chave', i.chave, 'nome', coalesce((select nome from produtos where id = i.produto_id), (select nome from combos where id = i.combo_id)), 'nomeIfood', i.nome,
        'precoSistema', public._ifood_preco_sistema(i), 'precoIfood', i.preco_ifood, 'visto', i.preco_visto_em,
        'diff', round(coalesce(i.preco_ifood, 0) - coalesce(public._ifood_preco_sistema(i), 0), 2),
        'pct', case when coalesce(public._ifood_preco_sistema(i), 0) > 0 and i.preco_ifood is not null then round(abs(i.preco_ifood - public._ifood_preco_sistema(i)) / public._ifood_preco_sistema(i) * 100, 1) end,
        'podeEnviar', i.ifood_item_id is not null) x
      from ifood_itens i where (i.produto_id is not null or i.combo_id is not null) and not i.ignorar) t), '[]'::jsonb),
    'historico', coalesce((select jsonb_agg(jsonb_build_object('id', h.id, 'quando', h.quando, 'nome', h.nome, 'antes', h.preco_antes, 'depois', h.preco_depois, 'origem', h.origem, 'estado', h.estado, 'erro', h.erro) order by h.id desc)
      from (select * from ifood_precos_hist order by id desc limit 30) h), '[]'::jsonb));
end $f$;

create or replace function public.api_ifood_precos_pedir_catalogo(p jsonb default '{}'::jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not _integracao_ligada('ifood') then return _falha('O iFood está desligado.'); end if;
  perform _ifood_enfileirar('LOJA', 'catalogo_importar', '{}'::jsonb);
  return jsonb_build_object('ok', true, 'message', 'Pedido enviado: em cerca de 1 minuto o cardápio do iFood aparece aqui. Atualize a lista.');
end $f$;

-- importar: grava o preço do iFood no campo "Preço no iFood" do sistema (linha da forma iFood)
create or replace function public.api_ifood_precos_aplicar(p jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare r ifood_itens%rowtype; v_forma uuid := public._ifood_forma(); v_chave text; v_n int := 0; v_antes numeric; v_login text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_forma is null then return _falha('Cadastre a forma de pagamento "iFood" (com preço próprio) em Pagamentos antes de importar preços.'); end if;
  select login into v_login from usuarios where id = auth.uid();
  for v_chave in select jsonb_array_elements_text(coalesce(p->'chaves', '[]'::jsonb)) loop
    select * into r from ifood_itens where chave = v_chave and preco_ifood is not null and preco_ifood > 0;
    if not found then continue; end if;
    v_antes := public._ifood_preco_sistema(r);
    if r.produto_id is not null then
      update produto_precos set preco = r.preco_ifood where produto_id = r.produto_id and forma_pagamento_id = v_forma;
      if not found then insert into produto_precos (produto_id, forma_pagamento_id, preco, custo) values (r.produto_id, v_forma, r.preco_ifood, coalesce((select min(custo) from produto_precos where produto_id = r.produto_id), 0)); end if;
    elsif r.combo_id is not null then
      update combo_precos set preco = r.preco_ifood where combo_id = r.combo_id and forma_pagamento_id = v_forma;
      if not found then insert into combo_precos (combo_id, forma_pagamento_id, preco, custo) values (r.combo_id, v_forma, r.preco_ifood, coalesce((select min(custo) from combo_precos where combo_id = r.combo_id), 0)); end if;
    else continue; end if;
    insert into ifood_precos_hist (chave, nome, preco_antes, preco_depois, origem, usuario, estado) values (r.chave, r.nome, v_antes, r.preco_ifood, 'importar', v_login, 'ok');
    v_n := v_n + 1;
  end loop;
  perform _auditar('Preços importados do iFood', v_n || ' item(ns)');
  return jsonb_build_object('ok', true, 'message', v_n || ' preço(s) do iFood gravado(s) no sistema.') || api_ifood_precos('{}');
end $f$;

-- enviar nossos preços ao iFood: só com o ajuste ligado, trava de variação e histórico
create or replace function public.api_ifood_precos_enviar(p jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare r ifood_itens%rowtype; v_chave text; v_novo numeric; v_lim numeric := coalesce((select (config->>'limitePrecoPct')::numeric from integracoes_config where provedor = 'ifood'), 30);
        v_n int := 0; v_bloq text[] := '{}'; v_id bigint; v_login text; v_pct numeric;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not _integracao_ligada('ifood') then return _falha('O iFood está desligado.'); end if;
  if not coalesce((select (config->>'enviarPrecos')::boolean from integracoes_config where provedor = 'ifood'), false) then return _falha('Ligue antes o ajuste "Enviar nossos preços ao iFood".'); end if;
  if coalesce(p->>'confirmar', '') <> 'true' then return _falha('Confirme o envio.'); end if;
  select login into v_login from usuarios where id = auth.uid();
  for v_chave in select jsonb_array_elements_text(coalesce(p->'chaves', '[]'::jsonb)) loop
    select * into r from ifood_itens where chave = v_chave;
    if not found or r.ifood_item_id is null then v_bloq := v_bloq || (coalesce(r.nome, v_chave) || ' (importe o cardápio do iFood antes)'); continue; end if;
    v_novo := public._ifood_preco_sistema(r);
    if v_novo is null or v_novo <= 0 then continue; end if;
    if r.preco_ifood is not null and r.preco_ifood > 0 and abs(r.preco_ifood - v_novo) < 0.005 then continue; end if;
    v_pct := case when coalesce(r.preco_ifood, 0) > 0 then abs(v_novo - r.preco_ifood) / r.preco_ifood * 100 else 0 end;
    if v_pct > v_lim and coalesce(p->>'ignorarLimite', '') <> 'true' then v_bloq := v_bloq || (r.nome || ' (' || round(v_pct) || '% de variação, acima do limite de ' || v_lim || '%)'); continue; end if;
    insert into ifood_precos_hist (chave, nome, preco_antes, preco_depois, origem, usuario) values (r.chave, r.nome, r.preco_ifood, v_novo, 'enviar', v_login) returning id into v_id;
    insert into ifood_acoes (pedido_ifood, acao, dados) values ('LOJA', 'catalogo_preco', jsonb_build_object('chave', r.chave, 'itemId', r.ifood_item_id, 'preco', v_novo, 'hist', v_id)) on conflict do nothing;
    v_n := v_n + 1;
  end loop;
  perform _auditar('Preços enviados ao iFood', v_n || ' item(ns)' || case when array_length(v_bloq, 1) > 0 then ' · bloqueados: ' || array_length(v_bloq, 1) else '' end);
  return jsonb_build_object('ok', true, 'message', v_n || ' preço(s) enviado(s) ao iFood.' || case when array_length(v_bloq, 1) > 0 then ' Não enviados: ' || array_to_string(v_bloq, '; ') else '' end) || api_ifood_precos('{}');
end $f$;

create or replace function public.api_ifood_precos_desfazer(p jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare h ifood_precos_hist%rowtype; i ifood_itens%rowtype; v_id bigint;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into h from ifood_precos_hist where id = (p->>'id')::bigint for update;
  if not found or h.origem <> 'enviar' or h.estado <> 'ok' then return _falha('Só dá para desfazer um envio já concluído.'); end if;
  if h.preco_antes is null then return _falha('Não há preço anterior guardado.'); end if;
  select * into i from ifood_itens where chave = h.chave;
  update ifood_precos_hist set estado = 'desfeito' where id = h.id;
  insert into ifood_precos_hist (chave, nome, preco_antes, preco_depois, origem, usuario) values (h.chave, h.nome, h.preco_depois, h.preco_antes, 'desfazer', coalesce((select login from usuarios where id = auth.uid()), '')) returning id into v_id;
  insert into ifood_acoes (pedido_ifood, acao, dados) values ('LOJA', 'catalogo_preco', jsonb_build_object('chave', h.chave, 'itemId', i.ifood_item_id, 'preco', h.preco_antes, 'hist', v_id)) on conflict do nothing;
  perform _auditar('Envio de preço desfeito', h.nome);
  return jsonb_build_object('ok', true, 'message', 'Preço anterior reenviado ao iFood.') || api_ifood_precos('{}');
end $f$;

-- ---------- pausar item no iFood quando o ingrediente acaba (opcional) ----------
create or replace function public._ifood_trg_estoque() returns trigger language plpgsql security definer set search_path to 'public' as $f$
declare r record;
begin
  if not public._integracao_ligada('ifood') then return null; end if;
  if not coalesce((select (config->>'pausarSemEstoque')::boolean from integracoes_config where provedor = 'ifood'), false) then return null; end if;
  if new.quantidade <= 0 and coalesce(old.quantidade, 1) > 0 then
    for r in select distinct ii.chave, ii.ifood_item_id from ifood_itens ii join produto_ingredientes pi on pi.produto_id = ii.produto_id
             where pi.ingrediente_id = new.id and ii.ifood_item_id is not null and not ii.pausado_por_nos and not ii.ignorar loop
      update ifood_itens set pausado_por_nos = true where chave = r.chave;
      insert into ifood_acoes (pedido_ifood, acao, dados) values ('LOJA', 'catalogo_pausar', jsonb_build_object('chave', r.chave, 'itemId', r.ifood_item_id)) on conflict do nothing;
    end loop;
  elsif new.quantidade > 0 and coalesce(old.quantidade, 0) <= 0 then
    for r in select distinct ii.chave, ii.ifood_item_id from ifood_itens ii join produto_ingredientes pi on pi.produto_id = ii.produto_id
             where pi.ingrediente_id = new.id and ii.pausado_por_nos
               and not exists (select 1 from produto_ingredientes p2 join estoque e2 on e2.id = p2.ingrediente_id where p2.produto_id = ii.produto_id and e2.quantidade <= 0) loop
      update ifood_itens set pausado_por_nos = false where chave = r.chave;
      insert into ifood_acoes (pedido_ifood, acao, dados) values ('LOJA', 'catalogo_retomar', jsonb_build_object('chave', r.chave, 'itemId', r.ifood_item_id)) on conflict do nothing;
    end loop;
  end if;
  return null;
exception when others then return null;     -- nunca atrapalhar a venda/estoque por causa do iFood
end $f$;
drop trigger if exists trg_ifood_estoque on public.estoque;
create trigger trg_ifood_estoque after update of quantidade on public.estoque for each row when (new.quantidade is distinct from old.quantidade) execute function public._ifood_trg_estoque();

create or replace function public.ifood_log(p_nivel text, p_msg text) returns void language sql security definer set search_path to 'public' as $f$
  select public._integ_log('ifood', case when p_nivel in ('info','aviso','erro') then p_nivel else 'info' end, p_msg)
$f$;

-- ---------- tarefas periódicas (o servidor pergunta se já está na hora) ----------
create or replace function public.ifood_precisa(p_tarefa text, p_minutos int) returns boolean language plpgsql security definer set search_path to 'public' as $f$
declare v timestamptz;
begin
  select case p_tarefa when 'financeiro' then financeiro_em when 'avaliacoes' then avaliacoes_em end into v from ifood_estado where id;
  if v is not null and v > now() - make_interval(mins => p_minutos) then return false; end if;
  if p_tarefa = 'financeiro' then update ifood_estado set financeiro_em = now() where id; else update ifood_estado set avaliacoes_em = now() where id; end if;
  return true;
end $f$;

-- ---------- financeiro: a receber do iFood, repasses, comissão real ----------
create or replace function public.ifood_repasses_gravar(p_lista jsonb) returns int language plpgsql security definer set search_path to 'public' as $f$
declare e jsonb; o jsonb; v_n int := 0; v_ped int;
begin
  for e in select value from jsonb_array_elements(coalesce(p_lista, '[]'::jsonb)) loop
    if nullif(e->>'id', '') is null then continue; end if;
    v_ped := 0;
    for o in select value from jsonb_array_elements(case when jsonb_typeof(e->'orders') = 'array' then e->'orders' else '[]'::jsonb end) loop
      update ifood_pedidos set repassado_em = coalesce(repassado_em, now()), repasse_id = e->>'id', comissao = coalesce(nullif(public._ifood_n(o->'commission'), 0), nullif(public._ifood_n(o->'fees'), 0), comissao)
       where pedido_ifood = coalesce(o->>'orderId', o->>'id');
      if found then v_ped := v_ped + 1; end if;
    end loop;
    insert into ifood_repasses (id, pago_em, periodo_ini, periodo_fim, valor, pedidos, bruto)
    values (e->>'id', nullif(e->>'paymentDate', '')::date, nullif(e->>'periodStart', '')::date, nullif(e->>'periodEnd', '')::date, public._ifood_n(coalesce(e->'amount', e->'value')), v_ped, e)
    on conflict (id) do update set valor = excluded.valor, pedidos = excluded.pedidos, pago_em = excluded.pago_em, bruto = excluded.bruto;
    v_n := v_n + 1;
  end loop;
  return v_n;
end $f$;

create or replace function public.api_ifood_financeiro(p jsonb default '{}'::jsonb) returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'aReceber', (select jsonb_build_object('pedidos', count(*), 'valor', coalesce(sum(v.valor_total), 0))
       from ifood_pedidos i join vendas v on v.id = i.venda_id
       where not i.simulado and v.status = 'Confirmada' and i.repassado_em is null and i.estado <> 'cancelado'
         and exists (select 1 from pagamentos_venda pv where pv.venda_id = v.id and pv.forma_pagamento = 'iFood (pago no app)')),
    'recebido30d', (select jsonb_build_object('repasses', count(*), 'valor', coalesce(sum(valor), 0)) from ifood_repasses where coalesce(pago_em, criado_em::date) >= current_date - 30),
    'comissao30d', (select coalesce(sum(comissao), 0) from ifood_pedidos where repassado_em > now() - interval '30 days'),
    'repasses', coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'pagoEm', r.pago_em, 'valor', r.valor, 'pedidos', r.pedidos) order by r.pago_em desc nulls last) from (select * from ifood_repasses order by coalesce(pago_em, criado_em::date) desc limit 15) r), '[]'::jsonb));
end $f$;

-- ---------- avaliações ----------
create or replace function public.ifood_avaliacoes_gravar(p_lista jsonb) returns int language plpgsql security definer set search_path to 'public' as $f$
declare e jsonb; v_n int := 0; v_fb uuid; v_venda uuid; v_nota int; v_ja boolean; v_num text;
begin
  for e in select value from jsonb_array_elements(coalesce(p_lista, '[]'::jsonb)) loop
    if nullif(e->>'id', '') is null then continue; end if;
    v_ja := exists (select 1 from ifood_avaliacoes where id = e->>'id');
    v_nota := round(public._ifood_n(coalesce(e->'score', e->'rating', e->'nota')))::int;
    select venda_id, numero_ifood into v_venda, v_num from ifood_pedidos where pedido_ifood = e->>'orderId';
    insert into ifood_avaliacoes (id, pedido_ifood, nota, comentario, criada_em, resposta, bruto)
    values (e->>'id', e->>'orderId', v_nota, left(coalesce(e->>'comment', e->>'text', ''), 1000), nullif(e->>'createdAt', '')::timestamptz,
            nullif(coalesce(e->'replies'->0->>'text', e->>'reply'), ''), e)
    on conflict (id) do update set resposta = coalesce(excluded.resposta, ifood_avaliacoes.resposta), nota = excluded.nota;
    if not v_ja then
      begin
        insert into feedbacks (venda_id, nota, comentario, data, status, origem) values (v_venda, greatest(least(v_nota, 5), 1), left(coalesce(e->>'comment', e->>'text', ''), 1000), coalesce(nullif(e->>'createdAt', '')::timestamptz, now()), 'Novo', 'iFood') returning id into v_fb;
        update ifood_avaliacoes set feedback_id = v_fb where id = e->>'id';
      exception when others then null; end;
      if v_nota <= 2 then perform _push_enviar('feedback', '⭐ Avaliação baixa no iFood (' || v_nota || ')', coalesce(left(e->>'comment', 100), 'Veja no painel'), 'ifood-aval-' || (e->>'id')); end if;
      v_n := v_n + 1;
    end if;
  end loop;
  return v_n;
end $f$;

create or replace function public.api_ifood_avaliacoes(p jsonb default '{}'::jsonb) returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'media30d', (select round(avg(nota), 2) from ifood_avaliacoes where coalesce(criada_em, visto_em) > now() - interval '30 days'),
    'itens', coalesce((select jsonb_agg(jsonb_build_object('id', a.id, 'nota', a.nota, 'comentario', a.comentario, 'em', a.criada_em, 'resposta', a.resposta, 'pedido', i.numero_ifood) order by coalesce(a.criada_em, a.visto_em) desc)
      from (select * from ifood_avaliacoes order by coalesce(criada_em, visto_em) desc limit 20) a left join ifood_pedidos i on i.pedido_ifood = a.pedido_ifood), '[]'::jsonb));
end $f$;

create or replace function public.api_ifood_avaliacao_responder(p jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare v_texto text := btrim(coalesce(p->>'texto', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if length(v_texto) < 3 or length(v_texto) > 600 then return _falha('Escreva a resposta (3 a 600 letras).'); end if;
  if not exists (select 1 from ifood_avaliacoes where id = p->>'id') then return _falha('Avaliação não encontrada.'); end if;
  update ifood_avaliacoes set resposta = v_texto, respondida_em = now() where id = p->>'id';
  insert into ifood_acoes (pedido_ifood, acao, dados) values ('LOJA', 'avaliacao_responder', jsonb_build_object('avaliacao', p->>'id', 'texto', v_texto)) on conflict do nothing;
  perform _auditar('Resposta a avaliação do iFood', left(v_texto, 100));
  return jsonb_build_object('ok', true, 'message', 'Resposta enviada ao iFood.') || api_ifood_avaliacoes('{}');
end $f$;

-- ---------- relatório por canal ----------
create or replace function public.api_ifood_relatorio(p jsonb default '{}'::jsonb) returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
declare v_dias int := least(greatest(coalesce(nullif(p->>'dias', '')::int, 30), 1), 365);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'dias', v_dias,
    'canais', coalesce((select jsonb_agg(jsonb_build_object('canal', c, 'pedidos', n, 'total', t, 'ticket', case when n > 0 then round(t / n, 2) else 0 end, 'custo', k, 'margem', t - k,
          'margemPct', case when t > 0 then round((t - k) / t * 100, 1) else 0 end, 'cancelados', cx) order by t desc)
      from (select case when canal = 'iFood' then 'iFood' when origem::text = 'Cardápio' then 'Cardápio' when origem::text = 'Garçom' then 'Garçom' else 'Balcão' end c,
                   count(*) filter (where status = 'Confirmada') n, coalesce(sum(valor_total) filter (where status = 'Confirmada'), 0) t,
                   coalesce(sum(custo_total) filter (where status = 'Confirmada'), 0) k, count(*) filter (where status = 'Cancelada') cx
            from vendas where data_hora > now() - make_interval(days => v_dias) group by 1) x), '[]'::jsonb),
    'ifood', jsonb_build_object(
      'confirmacaoMediaMin', (select round(avg(extract(epoch from (confirmado_em - criado_em)) / 60)::numeric, 1) from ifood_pedidos where confirmado_em is not null and not simulado and criado_em > now() - make_interval(days => v_dias)),
      'itensSemLigacao', (select coalesce(sum(itens_sem_ligacao), 0) from ifood_pedidos where criado_em > now() - make_interval(days => v_dias) and estado <> 'cancelado'),
      'comissaoReal', (select coalesce(sum(comissao), 0) from ifood_pedidos where comissao is not null and criado_em > now() - make_interval(days => v_dias)),
      'cancelamentos', coalesce((select jsonb_agg(jsonb_build_object('motivo', m, 'qtd', q) order by q desc) from (select coalesce(nullif(motivo_cancelamento, ''), 'sem motivo') m, count(*) q from vendas where canal = 'iFood' and status = 'Cancelada' and data_hora > now() - make_interval(days => v_dias) group by 1) y), '[]'::jsonb),
      'maisVendidos', coalesce((select jsonb_agg(jsonb_build_object('nome', n, 'qtd', q) order by q desc) from (select left(iv.descricao, 60) n, sum(iv.quantidade) q from itens_venda iv join vendas v on v.id = iv.venda_id where v.canal = 'iFood' and v.status = 'Confirmada' and v.data_hora > now() - make_interval(days => v_dias) group by 1 order by 2 desc limit 8) z), '[]'::jsonb)));
end $f$;

-- ---------- permissões ----------
revoke execute on function public._ifood_forma(), public._ifood_preco_sistema(ifood_itens), public._ifood_trg_estoque(), public.ifood_catalogo_gravar(jsonb), public.ifood_preco_confirmar(bigint, boolean, text),
  public.ifood_precisa(text, int), public.ifood_repasses_gravar(jsonb), public.ifood_avaliacoes_gravar(jsonb), public.ifood_log(text, text) from public, anon, authenticated;
grant execute on function public.ifood_catalogo_gravar(jsonb), public.ifood_preco_confirmar(bigint, boolean, text), public.ifood_precisa(text, int), public.ifood_repasses_gravar(jsonb), public.ifood_avaliacoes_gravar(jsonb), public.ifood_log(text, text) to service_role;
revoke execute on function public.api_ifood_precos(jsonb), public.api_ifood_precos_pedir_catalogo(jsonb), public.api_ifood_precos_aplicar(jsonb), public.api_ifood_precos_enviar(jsonb), public.api_ifood_precos_desfazer(jsonb),
  public.api_ifood_financeiro(jsonb), public.api_ifood_avaliacoes(jsonb), public.api_ifood_avaliacao_responder(jsonb), public.api_ifood_relatorio(jsonb) from public, anon;
grant execute on function public.api_ifood_precos(jsonb), public.api_ifood_precos_pedir_catalogo(jsonb), public.api_ifood_precos_aplicar(jsonb), public.api_ifood_precos_enviar(jsonb), public.api_ifood_precos_desfazer(jsonb),
  public.api_ifood_financeiro(jsonb), public.api_ifood_avaliacoes(jsonb), public.api_ifood_avaliacao_responder(jsonb), public.api_ifood_relatorio(jsonb) to authenticated;

insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-105-ifood-inteligencia','iFood: preços, estoque, repasses, avaliações e relatório','ifood preço importar enviar desfazer pausar estoque repasse receber comissão avaliação relatório canal',
 E'Preços (Integrações → iFood → Preços): "Importar cardápio" traz os preços do iFood; a tabela mostra preço no sistema × preço no iFood × diferença. "Gravar no sistema" grava o preço do iFood no campo "Preço no iFood". "Enviar ao iFood" só funciona com o ajuste "Enviar nossos preços ao iFood" ligado, bloqueia variações acima do limite e guarda histórico com botão Desfazer.\nPausa por estoque: com o ajuste ligado, o item some do iFood quando um ingrediente acaba e volta quando repõe.\nFinanceiro: mostra quanto falta receber do iFood (pedidos pagos no app ainda sem repasse), os repasses recebidos e a comissão real.\nAvaliações: as notas do iFood aparecem aqui e em Feedbacks; nota baixa avisa a equipe; você responde pelo painel.\nRelatório por canal: vendas, ticket, margem e cancelamentos de balcão, cardápio e iFood.',
 array['Admin'],true,'lista',105,'Só Administrador.'
where not exists (select 1 from ai_ajuda where slug='man-admin-105-ifood-inteligencia');
