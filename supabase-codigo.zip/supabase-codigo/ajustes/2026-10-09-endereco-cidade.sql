-- =====================================================================
-- TEXAS BURGER — Endereço de entrega com NÚMERO e CIDADE · 2026-10-09
-- Cardápio: número da casa e cidade em campos próprios e obrigatórios na entrega (a página preenche a cidade pela localização/CEP).
-- O endereço gravado no pedido fica "Rua, Bairro, nº 123 — Cidade". NÃO há bloqueio por cidade (o restaurante atende distritos vizinhos).
-- Compatível com a página antiga: só exige número/cidade quando a página nova os envia.
-- Seguro para rodar de novo.
-- =====================================================================
do $do$
declare d text; alvo text := E'    if v_tipo = ''Entrega'' and v_end = '''' then return _falha(''Informe o endereço de entrega.''); end if;\n';
  novo text := E'    if v_tipo = ''Entrega'' and v_end = '''' then return _falha(''Informe o endereço de entrega.''); end if;\n'
  || E'    if v_tipo = ''Entrega'' then\n'
  || E'      declare v_num text := _texto_publico(v_de->>''numero'', 20); v_cid text := _texto_publico(v_de->>''cidade'', 80);\n'
  || E'      begin\n'
  || E'        if v_de ? ''numero'' and v_num = '''' then return _falha(''Informe o número da casa (ou "s/n").''); end if;\n'
  || E'        if v_de ? ''cidade'' and v_cid = '''' then return _falha(''Informe a cidade da entrega.''); end if;\n'
  || E'        if v_num <> '''' then v_end := left(v_end || '', nº '' || v_num, 200); end if;\n'
  || E'        if v_cid <> '''' then v_end := left(v_end || '' — '' || v_cid, 200); end if;\n'
  || E'      end;\n'
  || E'    end if;\n';
begin
  select pg_get_functiondef(p.oid) into d from pg_proc p where p.proname = '_criar_pedido_publico' and p.pronamespace = 'public'::regnamespace;
  if position('Informe o número da casa' in d) = 0 then
    if position(alvo in d) = 0 then raise exception 'trecho de referência não encontrado em _criar_pedido_publico'; end if;
    execute replace(d, alvo, novo);
  end if;
end $do$;

-- Ajuda do assistente
insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-100-endereco-cidades-entrega','Endereço de entrega (número e cidade)','endereço número casa cidade entrega cep localização distrito',
E'No cardápio, o cliente preenche Rua e bairro, NÚMERO e CIDADE. A localização do celular e o CEP preenchem rua, bairro e cidade sozinhos.\nSem o número (ou "s/n") o pedido não é enviado.\nNo pedido, o endereço aparece como "Rua, Bairro, nº 123 — Cidade".',
array['Admin'],true,'lista',100,'Se a localização preencher a cidade errada, o cliente pode corrigir no campo Cidade.'
where not exists (select 1 from ai_ajuda where slug='man-admin-100-endereco-cidades-entrega');
