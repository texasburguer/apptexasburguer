-- =====================================================================
-- TEXAS BURGER — "Contas e acessos" (Admin → Sistema) · 2026-10-10
-- Lista das contas do sistema (serviço, e-mail, link, observação). Só Admin/Desenvolvedor.
-- A senha de cada conta fica no COFRE do Supabase (Vault, criptografado); a tabela guarda só o id do segredo.
-- Ver a senha exige a senha de administrador (conferida de verdade) e fica registrado na Auditoria.
-- Seguro para rodar de novo.
-- =====================================================================
create table if not exists public.contas_acessos (
  id uuid primary key default gen_random_uuid(),
  servico text not null,
  email text not null default '',
  link text not null default '',
  observacao text not null default '',
  senha_id uuid,
  ordem int not null default 0,
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);
alter table public.contas_acessos enable row level security;
revoke all on table public.contas_acessos from anon, authenticated;

create or replace function public.api_listar_contas(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'contas', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'servico', servico, 'email', email, 'link', link,
           'observacao', observacao, 'temSenha', senha_id is not null) order by ordem, servico) from contas_acessos), '[]'::jsonb));
end $f$;

create or replace function public.api_salvar_conta(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public', 'vault' as $f$
declare v_id uuid := _uuid(p->>'id'); c contas_acessos%rowtype; v_serv text := left(btrim(coalesce(p->>'servico', '')), 80);
  v_email text := left(btrim(coalesce(p->>'email', '')), 120); v_link text := left(btrim(coalesce(p->>'link', '')), 500);
  v_obs text := left(btrim(coalesce(p->>'observacao', '')), 500); v_senha text := coalesce(p->>'senha', ''); v_sid uuid;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_serv = '' then return _falha('Informe o nome do serviço (ex.: Supabase, GitHub).'); end if;
  if v_link <> '' and v_link !~* '^https?://' then v_link := 'https://' || v_link; end if;
  if length(v_senha) > 200 then return _falha('Senha longa demais.'); end if;
  if v_id is null then
    insert into contas_acessos (servico, email, link, observacao, ordem) values (v_serv, v_email, v_link, v_obs, coalesce((select max(ordem) + 1 from contas_acessos), 1)) returning * into c;
  else
    update contas_acessos set servico = v_serv, email = v_email, link = v_link, observacao = v_obs, atualizado_em = now() where id = v_id returning * into c;
    if not found then return _falha('Conta não encontrada.'); end if;
  end if;
  if coalesce((p->>'removerSenha')::boolean, false) and c.senha_id is not null then
    delete from vault.secrets where id = c.senha_id; update contas_acessos set senha_id = null where id = c.id;
  elsif v_senha <> '' then
    if c.senha_id is null then
      v_sid := vault.create_secret(v_senha, 'conta_acesso_' || c.id::text, 'Senha da conta ' || v_serv);
      update contas_acessos set senha_id = v_sid where id = c.id;
    else
      perform vault.update_secret(c.senha_id, v_senha);
    end if;
  end if;
  perform _auditar(case when v_id is null then 'Conta cadastrada' else 'Conta editada' end, v_serv || case when v_senha <> '' then ' (senha alterada)' else '' end);
  return jsonb_build_object('ok', true, 'message', 'Conta salva.') || api_listar_contas('{}');
end $f$;

create or replace function public.api_excluir_conta(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public', 'vault' as $f$
declare c contas_acessos%rowtype;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  delete from contas_acessos where id = _uuid(p->>'id') returning * into c;
  if not found then return _falha('Conta não encontrada.'); end if;
  if c.senha_id is not null then delete from vault.secrets where id = c.senha_id; end if;
  perform _auditar('Conta excluída', c.servico);
  return jsonb_build_object('ok', true, 'message', 'Conta excluída.') || api_listar_contas('{}');
end $f$;

create or replace function public.api_ver_senha_conta(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public', 'vault' as $f$
declare c contas_acessos%rowtype; v text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  select * into c from contas_acessos where id = _uuid(p->>'id');
  if not found or c.senha_id is null then return _falha('Esta conta não tem senha guardada.'); end if;
  select decrypted_secret into v from vault.decrypted_secrets where id = c.senha_id;
  perform _auditar('Senha de conta visualizada', c.servico);
  return jsonb_build_object('ok', true, 'senha', coalesce(v, ''));
end $f$;

revoke execute on function public.api_listar_contas(jsonb), public.api_salvar_conta(jsonb), public.api_excluir_conta(jsonb), public.api_ver_senha_conta(jsonb) from public, anon;
grant execute on function public.api_listar_contas(jsonb), public.api_salvar_conta(jsonb), public.api_excluir_conta(jsonb), public.api_ver_senha_conta(jsonb) to authenticated;

-- contas já conhecidas deste sistema (só se a lista estiver vazia; senhas o Admin preenche no app)
insert into contas_acessos (servico, email, link, observacao, ordem)
select * from (values
  ('Supabase (servidor principal)', 'texasburguerbdo388@gmail.com', 'https://supabase.com/dashboard/project/awryywtgqfaxppayzpca', 'Banco de dados, login e funções do sistema.', 1),
  ('GitHub (onde a página fica publicada)', 'texasburguerbdo388@gmail.com', 'https://github.com/texasburguer/apptexasburguer', 'Suba aqui o index.html a cada atualização.', 2),
  ('Site do sistema', '', 'https://texasburguer.github.io/apptexasburguer/', 'Endereço que a equipe e os clientes abrem (QR Codes).', 3),
  ('Planilha principal (Google Sheets / Apps Script)', 'texasburguerbdo388@gmail.com', 'https://script.google.com/macros/s/AKfycbwCftUm-1pxhA8XLNqMB7dMUJxbj5GOsYHgFHZDqlbAH0XXRkUlsOKJkGTlGzR1LWxVpQ/exec', 'Servidor de reserva. O link é o do Apps Script publicado.', 4),
  ('Planilha de contingência (Google Sheets / Apps Script)', 'texasburgercontingencia@gmail.com', 'https://script.google.com/macros/s/AKfycby3WljBnr7gpJrHdkbTvBCh5uIXqS4KCS6wkBYB5idxf5gI04efoDumQj264kR_smoW/exec', 'Último recurso. Conta Google separada só para ela.', 5)
) v(s, e, l, o, n)
where not exists (select 1 from contas_acessos);

-- Ajuda do assistente
insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-101-contas-e-acessos','Contas e acessos','contas acessos email senha link supabase github planilha apps script cofre ver senha',
E'Administrador → Sistema → Contas e acessos: lista das contas do sistema (Supabase, GitHub, planilhas…) com e-mail, link e observação.\n"+ Nova conta" cadastra; "Editar" muda os dados ou a senha; "Excluir" apaga a conta e a senha guardada.\nA senha fica no cofre criptografado do Supabase. Para ver, toque em "Ver senha" e digite a SUA senha de administrador; ela aparece por 30 segundos e fica registrado na Auditoria.',
array['Admin'],true,'lista',101,'Nunca mande senhas por mensagem: digite direto nesta tela.'
where not exists (select 1 from ai_ajuda where slug='man-admin-101-contas-e-acessos');
