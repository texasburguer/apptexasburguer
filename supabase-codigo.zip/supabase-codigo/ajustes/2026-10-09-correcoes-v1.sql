-- v1.0: correções (editar o próprio usuário não derruba a sessão; mensagens do Caixa; limite do banco configurável)
CREATE OR REPLACE FUNCTION public._limite_banco_mb()
 RETURNS numeric
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$ select coalesce((select nullif(valor #>> '{}', '')::numeric from sistema where chave = 'LIMITE_BANCO_MB'), 500) $function$
;
revoke all on function public._limite_banco_mb() from public, anon, authenticated;

CREATE OR REPLACE FUNCTION public.api_editar_usuario(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  u usuarios%rowtype;
  v_alvo text := coalesce(p->>'loginAlvo', '');
  v_aut text; v_erro text;
  v_sera_admin boolean; v_sera_ativo boolean; v_contato boolean := false; v_nome text; v_tel text;
  v_nivel_real nivel_acesso; v_sessao uuid;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select nivel into v_nivel_real from usuarios where id = auth.uid() and ativo;
  if v_nivel_real is null then return _negado(); end if;
  if p ? 'novoNivel' and coalesce(p->>'novoNivel', '') not in ('Admin','Operador','Garçom','Cozinha','Entregador','Desenvolvedor') then return _falha('Nível de acesso inválido.'); end if;
  if p ? 'novoNivel' and p->>'novoNivel' = 'Desenvolvedor' and coalesce((select nivel::text from usuarios where lower(login) = lower(coalesce(p->>'loginAlvo','')) ), '') <> 'Desenvolvedor' then
    return _falha('Não é possível conceder o nível Desenvolvedor.');
  end if;
  if p ? 'novoNivel' and p->>'novoNivel' = 'Desenvolvedor' and v_nivel_real <> 'Desenvolvedor' then
    return _falha('Somente um Desenvolvedor pode conceder o nível Desenvolvedor.');
  end if;
  v_aut := _exige_admin(p->>'senhaAdminConfirmacao');
  if v_aut is null then return _falha('Senha de administrador incorreta.'); end if;
  select * into u from usuarios where lower(login) = lower(v_alvo);
  if not found then return _falha('Usuário não encontrado.'); end if;
  if u.nivel = 'Desenvolvedor' and v_nivel_real <> 'Desenvolvedor' then
    return _falha('A conta de Desenvolvedor é protegida e só pode ser alterada por um Desenvolvedor.');
  end if;
  if p ? 'nome' and length(coalesce(p->>'nome', '')) > 60 then return _falha('O nome pode ter no máximo 60 caracteres.'); end if;
  if p ? 'telefone' and length(coalesce(p->>'telefone', '')) > 25 then return _falha('O telefone pode ter no máximo 25 caracteres.'); end if;
  v_sera_admin := case when p ? 'novoNivel' then p->>'novoNivel' = 'Admin' else u.nivel = 'Admin' end;
  v_sera_ativo := case when p ? 'novoAtivo' then coalesce((p->>'novoAtivo')::boolean, false) else u.ativo end;
  if u.id = auth.uid() and p ? 'novoAtivo' and not v_sera_ativo then return _falha('Você não pode desativar o seu próprio acesso.'); end if;
  if u.id = auth.uid() and p ? 'novoNivel' and p->>'novoNivel' <> u.nivel::text then return _falha('Você não pode alterar o seu próprio perfil.'); end if;
  if u.nivel = 'Admin' and (not v_sera_admin or not v_sera_ativo) then
    if not exists (select 1 from usuarios where nivel = 'Admin' and ativo and id <> u.id) then return _falha('Não é possível remover o último administrador ativo.'); end if;
  end if;
  -- ao editar a si mesmo, a sessão atual continua valendo (as outras caem)
  v_sessao := case when u.id = auth.uid() then nullif(auth.jwt() ->> 'session_id', '')::uuid else null end;
  if coalesce(p->>'novaSenha', '') <> '' then
    v_erro := _erro_senha_fraca(p->>'novaSenha', u.login);
    if v_erro <> '' then return _falha(v_erro); end if;
    update auth.users set encrypted_password = crypt(p->>'novaSenha', gen_salt('bf')), updated_at = now() where id = u.id;
    delete from auth.sessions where user_id = u.id and id is distinct from v_sessao;
  end if;
  if p ? 'novoNivel' then update usuarios set nivel = (p->>'novoNivel')::nivel_acesso where id = u.id; end if;
  if p ? 'novoAtivo' then
    update usuarios set ativo = v_sera_ativo where id = u.id;
    if not v_sera_ativo then delete from auth.sessions where user_id = u.id and id is distinct from v_sessao; end if;
  end if;
  if p ? 'nome' then v_nome := btrim(coalesce(p->>'nome', '')); if v_nome <> coalesce(u.nome, '') then update usuarios set nome = v_nome where id = u.id; v_contato := true; end if; end if;
  if p ? 'telefone' then v_tel := btrim(coalesce(p->>'telefone', '')); if v_tel <> coalesce(u.telefone, '') then update usuarios set telefone = v_tel where id = u.id; v_contato := true; end if; end if;
  perform _auditar('Usuário editado', u.login || case when coalesce(p->>'novaSenha', '') <> '' then ' (senha alterada)' else '' end
    || case when v_contato then ' (nome/telefone alterado)' else '' end
    || case when p ? 'novoNivel' then ' nível=' || (p->>'novoNivel') else '' end
    || case when p ? 'novoAtivo' then ' ativo=' || case when v_sera_ativo then 'Sim' else 'Não' end else '' end);
  return jsonb_build_object('ok', true, 'message', 'Usuário atualizado.');
end
$function$
;

CREATE OR REPLACE FUNCTION public.api_iniciar_venda(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_nivel nivel_acesso := auth_nivel(); v_eu uuid := auth.uid(); v_login text;
  v_itens jsonb := p->'itens'; v_pags jsonb := p->'pagamentos'; v_tipo_in text := p->>'tipoEntrega';
  v_mesa_id uuid := _uuid(p->>'mesaId'); v_mesa mesas%rowtype; v_mesa_status text; v_mesa_garcom uuid;
  v_origem text := coalesce(nullif(p->>'origem', ''), 'Balcão'); v_status_pag text := p->>'statusPagamento';
  v_nome text := btrim(coalesce(p->>'clienteNome', '')); v_tel text := btrim(coalesce(p->>'clienteTelefone', ''));
  v_de jsonb := case when jsonb_typeof(p->'dadosEntrega') = 'object' then p->'dadosEntrega' else '{}'::jsonb end;
  v_desc jsonb := case when jsonb_typeof(p->'desconto') = 'object' then p->'desconto' else null end;
  v_req text := nullif(left(coalesce(p->>'requisicaoId', ''), 80), ''); v_ja uuid;
  it record; pg record; v_exige boolean; v_qtd numeric; v_v numeric; v_c numeric; v_nome_item text; v_extra numeric; v_n_ad int; v_n_ok int;
  v_orig numeric := 0; v_custo numeric := 0; v_total_item numeric; v_desc_val numeric := 0; v_desc_det text := ''; v_sol numeric; v_aut text;
  v_tipo venda_tipo; v_taxa numeric := 0; v_total numeric; v_soma numeric := 0; v_erro text; v_venda uuid := gen_random_uuid();
  v_pad numeric; v_t numeric; v_forma_row formas_pagamento%rowtype; v_resumo text; v_origem_final origem_venda; v_status_pedido_ini status_pedido;
  v_status_pag_final status_pagamento; v_numero int; v_msg_extra text := ''; v_caixa uuid; v_bloqueia boolean; r record;
begin
  if v_nivel is null or v_nivel not in ('Admin','Operador','Garçom') then return _negado(); end if;
  if jsonb_typeof(v_itens) <> 'array' or jsonb_array_length(v_itens) = 0 then return _falha('Adicione ao menos um item à venda.'); end if;
  if jsonb_typeof(v_pags) <> 'array' or jsonb_array_length(v_pags) = 0 then return _falha('Informe ao menos uma forma de pagamento.'); end if;
  if v_tipo_in = 'Mesa' and v_mesa_id is null then return _falha('Informe a mesa.'); end if;
  if v_origem like 'Contingência%' then return _falha('Vendas da contingência entram pelo botão "Trazer vendas pendentes da contingência" (Administrador).'); end if;
  if coalesce(p->'promocaoValidada'->>'ok', '') = 'true' then return _falha('Cupom não é aceito no Caixa. Use o desconto por porcentagem.'); end if;
  select login into v_login from usuarios where id = v_eu;
  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;
  if v_caixa is null then return _falha(case when v_nivel = 'Garçom' then 'O caixa está fechado — peça ao caixa para abrir.' else 'Abra o caixa antes de registrar uma venda.' end); end if;

  -- garçom: só mesa/entrega/retirada, sem desconto, sem receber pagamento; vale no servidor, não só na tela
  if v_nivel = 'Garçom' then
    if v_tipo_in not in ('Mesa','Entrega','Retirada') then return _falha('O garçom só lança pedidos de mesa, entrega ou retirada.'); end if;
    if v_tipo_in <> 'Mesa' and v_tel = '' then return _falha('Informe o cliente (nome e telefone) para pedidos por telefone.'); end if;
    if v_tipo_in = 'Mesa' then
      select * into v_mesa from mesas where id = v_mesa_id for update;
      if not found then return _falha('Mesa não encontrada.'); end if;
      if v_mesa.status not in ('Livre','Ocupada') then return _falha('A mesa ' || v_mesa.numero || ' está "' || v_mesa.status || '" — não aceita novos itens.'); end if;
      if v_mesa.status = 'Ocupada' and v_mesa.garcom_responsavel_id is not null and v_mesa.garcom_responsavel_id <> v_eu then
        return _falha('Esta mesa está sob responsabilidade de outro garçom.');
      end if;
    end if;
    v_origem := 'Garçom'; v_desc := null; v_status_pag := 'A Receber';
    if v_tipo_in = 'Mesa' then
      v_pags := jsonb_build_array(jsonb_build_object('forma', 'A Receber (Mesa)', 'valor', _num(v_pags->0->>'valor')));
    else
      v_pags := jsonb_build_array(jsonb_build_object('forma', btrim(coalesce(v_pags->0->>'forma', '')), 'valor', _num(v_pags->0->>'valor')));
    end if;
  elsif v_tipo_in = 'Mesa' then
    select * into v_mesa from mesas where id = v_mesa_id for update;
    if not found then return _falha('Mesa não encontrada.'); end if;
  end if;

  if v_tipo_in = 'Mesa' then v_mesa_status := v_mesa.status::text; v_mesa_garcom := v_mesa.garcom_responsavel_id; end if;

  -- idempotência: a mesma requisição (duplo toque, nova tentativa) nunca gera duas vendas
  if v_req is not null then
    perform pg_advisory_xact_lock(hashtext('venda:' || v_req));
    select id into v_ja from vendas where requisicao_id = v_req;
    if found then return jsonb_build_object('ok', true, 'duplicado', true, 'id', v_ja, 'message', 'Venda já registrada — requisição repetida ignorada.'); end if;
  end if;

  -- itens: quantidade, preço, custo e (para quem não é Admin) preço conferido com o cadastro
  v_exige := not (v_nivel = 'Admin' and v_origem <> 'Cardápio');
  for it in select value as e from jsonb_array_elements(v_itens) loop
    v_nome_item := coalesce(nullif(it.e->>'descricao', ''), 'item');
    v_qtd := _num(it.e->>'quantidade'); v_v := _num(it.e->>'valorUnitario', -1); v_c := _num(it.e->>'custoUnitario');
    if not (v_qtd > 0) or v_qtd > 200 or v_qtd <> floor(v_qtd) then return _falha('Quantidade inválida em "' || v_nome_item || '".'); end if;
    if v_v < 0 then return _falha('Preço inválido em "' || v_nome_item || '".'); end if;
    if v_c < 0 then return _falha('Custo inválido em "' || v_nome_item || '".'); end if;
    if v_exige then
      if (_uuid(it.e->>'produtoId') is null and _uuid(it.e->>'comboId') is null) or (_uuid(it.e->>'produtoId') is not null and _uuid(it.e->>'comboId') is not null) then
        return _falha('"' || v_nome_item || '" não é um item cadastrado de forma válida.');
      end if;
      select count(*), coalesce(sum(a.preco) filter (where a.ativo), 0), count(a.id) filter (where a.ativo and ((_uuid(it.e->>'produtoId') is not null and exists (select 1 from produto_adicionais pa where pa.produto_id = _uuid(it.e->>'produtoId') and pa.adicional_id = a.id)) or (_uuid(it.e->>'comboId') is not null and exists (select 1 from combo_itens ci join produto_adicionais pa on pa.produto_id = ci.produto_id where ci.combo_id = _uuid(it.e->>'comboId') and pa.adicional_id = a.id))))
        into v_n_ad, v_extra, v_n_ok
        from jsonb_array_elements_text(case when jsonb_typeof(it.e->'adicionaisIds') = 'array' then it.e->'adicionaisIds' else '[]'::jsonb end) x
        left join adicionais a on a.id = _uuid(x);
      if v_n_ad <> v_n_ok then return _falha('O adicional selecionado para "' || v_nome_item || '" não está disponível.'); end if;
      if _uuid(it.e->>'produtoId') is not null then
        if not exists (select 1 from produto_precos pp where pp.produto_id = _uuid(it.e->>'produtoId') and abs(pp.preco + v_extra - v_v) <= 0.011) then
          perform _auditar('Preço divergente bloqueado', v_nome_item || ' enviado a R$ ' || _dinheiro(v_v));
          return _falha('O preço de "' || v_nome_item || '" não confere com o cadastro.');
        end if;
        if not exists (select 1 from produto_precos pp where pp.produto_id = _uuid(it.e->>'produtoId') and abs(pp.preco + v_extra - v_v) <= 0.011 and abs(pp.custo - v_c) <= 0.011) then
          perform _auditar('Custo divergente bloqueado', v_nome_item || ' enviado com custo R$ ' || _dinheiro(v_c));
          return _falha('O custo de "' || v_nome_item || '" não confere com o cadastro.');
        end if;
      else
        if not exists (select 1 from combo_precos cp where cp.combo_id = _uuid(it.e->>'comboId') and abs(cp.preco + v_extra - v_v) <= 0.011) then
          perform _auditar('Preço divergente bloqueado', v_nome_item || ' enviado a R$ ' || _dinheiro(v_v));
          return _falha('O preço de "' || v_nome_item || '" não confere com o cadastro.');
        end if;
        if not exists (select 1 from combo_precos cp where cp.combo_id = _uuid(it.e->>'comboId') and abs(cp.preco + v_extra - v_v) <= 0.011 and abs(cp.custo - v_c) <= 0.011) then
          perform _auditar('Custo divergente bloqueado', v_nome_item || ' enviado com custo R$ ' || _dinheiro(v_c));
          return _falha('O custo de "' || v_nome_item || '" não confere com o cadastro.');
        end if;
      end if;
    end if;
    v_total_item := round(v_qtd * v_v, 2);
    v_orig := v_orig + v_total_item; v_custo := v_custo + v_qtd * v_c;
  end loop;
  v_orig := round(v_orig, 2); v_custo := round(v_custo, 2);

  -- estoque (só se a regra "bloquear venda sem estoque" estiver ligada)
  select coalesce((select (valor #>> '{}') = 'true' from sistema where chave = 'BLOQUEAR_ESTOQUE_NEGATIVO'), false) into v_bloqueia;
  if v_bloqueia then
    for r in select c.ingrediente_id, c.qtd, e.ingrediente, e.quantidade from _consumo(v_itens) c join estoque e on e.id = c.ingrediente_id loop
      if r.quantidade + 0.000000001 < r.qtd then
        if v_origem = 'Cardápio' then return _falha('Um dos itens do pedido acabou. Escolha outro item ou fale com o restaurante.'); end if;
        return _falha('Estoque insuficiente de "' || r.ingrediente || '" (tem ' || r.quantidade || ', a venda precisa de ' || round(r.qtd, 3) || ').');
      end if;
    end loop;
  end if;

  -- desconto manual (precisa da senha de Admin quando quem lança não é Admin)
  if v_desc is not null and v_desc->>'valor' is not null then
    v_sol := _num(v_desc->>'valor', -1);
    if v_sol <= 0 then return _falha('Valor de desconto inválido.'); end if;
    v_aut := _exige_admin(p->>'senhaAdminConfirmacao');
    if v_aut is null then return _falha('Senha de administrador incorreta — desconto não aplicado.'); end if;
    if v_desc->>'tipo' = 'percentual' then
      if v_sol > 100 then return _falha('O desconto percentual não pode ser maior que 100%.'); end if;
      v_desc_val := round(v_orig * (v_sol / 100), 2);
      v_desc_det := v_sol || '% (R$ ' || _dinheiro(v_desc_val) || ')';
    elsif coalesce(v_desc->>'tipo', 'fixo') = 'fixo' then
      if v_sol > v_orig then return _falha('O desconto fixo não pode ser maior que o valor da venda.'); end if;
      v_desc_val := round(v_sol, 2);
      v_desc_det := 'R$ ' || _dinheiro(v_desc_val) || ' fixo';
    else
      return _falha('Tipo de desconto inválido.');
    end if;
    if v_desc_val <= 0 or v_desc_val >= v_orig then return _falha('O desconto não pode deixar a venda com valor zero ou negativo.'); end if;
  end if;

  -- tipo, taxa de entrega e total
  v_tipo := case v_tipo_in when 'Entrega' then 'Entrega' when 'Mesa' then 'Mesa' else 'Retirada' end::venda_tipo;
  if v_tipo = 'Entrega' and btrim(coalesce(v_de->>'endereco', '')) = '' then return _falha('Informe o endereço da entrega.'); end if;
  if v_tipo = 'Entrega' and coalesce(v_de->>'freteGratis', '') <> 'true' then
    select coalesce(_num(valor #>> '{}'), 0) into v_pad from sistema where chave = 'TaxaEntregaPadrao';
    v_taxa := coalesce(v_pad, 0);
    if v_nivel in ('Admin','Operador') and nullif(btrim(coalesce(v_de->>'taxa', '')), '') is not null then
      v_t := _num(v_de->>'taxa', -1);
      if v_t >= 0 and v_t <= 500 then v_taxa := round(v_t, 2); end if;
    end if;
  end if;
  v_total := round(v_orig - v_desc_val + v_taxa, 2);
  if v_total < 0.01 then return _falha('O total da venda precisa ser maior que zero.'); end if;
  if v_nivel = 'Garçom' and v_tipo_in <> 'Mesa' then
    v_pags := jsonb_build_array(jsonb_build_object('forma', v_pags->0->>'forma', 'valor', v_total));
  end if;

  -- pagamentos
  if exists (select 1 from jsonb_array_elements(v_pags) e where e->>'forma' = 'A Receber (Mesa)') then
    if jsonb_array_length(v_pags) <> 1 then return _falha('Forma de pagamento inválida para esta operação.'); end if;
    v_status_pag := 'A Receber';
  end if;
  for pg in select value as e from jsonb_array_elements(v_pags) loop
    if btrim(coalesce(pg.e->>'forma', '')) = '' then return _falha('Forma de pagamento não informada.'); end if;
    if not (_num(pg.e->>'valor', 0) > 0) then return _falha('Cada pagamento deve ter um valor maior que zero.'); end if;
    if btrim(pg.e->>'forma') = 'A Receber (Mesa)' then
      if v_nivel not in ('Admin','Operador','Garçom') or v_tipo_in <> 'Mesa' then return _falha('Forma de pagamento inválida para esta operação.'); end if;
      continue;
    end if;
    select * into v_forma_row from formas_pagamento where lower(nome) = lower(btrim(pg.e->>'forma')) limit 1;
    if not found then return _falha('Forma de pagamento não cadastrada: ' || btrim(pg.e->>'forma')); end if;
    if not v_forma_row.ativa then return _falha('A forma de pagamento está inativa: ' || btrim(pg.e->>'forma')); end if;
  end loop;
  select round(coalesce(sum(_num(e->>'valor')), 0), 2) into v_soma from jsonb_array_elements(v_pags) e;
  if abs(v_soma - v_total) > 0.02 then
    return _falha('A soma dos pagamentos (R$ ' || _dinheiro(v_soma) || ') não bate com o total da venda (R$ ' || _dinheiro(v_total) || ').');
  end if;

  -- grava tudo
  v_status_pag_final := case when v_status_pag = 'A Receber' then 'A Receber' else 'Pago' end::status_pagamento;
  v_origem_final := (case when v_origem in ('Cardápio','Garçom') then v_origem else 'Balcão' end)::origem_venda;
  v_status_pedido_ini := (case when v_origem_final = 'Cardápio' then 'Recebido' else 'Em preparo' end)::status_pedido;
  select string_agg(btrim(e->>'forma'), ' + ') into v_resumo from jsonb_array_elements(v_pags) e;

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido,
                      endereco, complemento, referencia, observacoes_entrega, status_pagamento, recebido_em, valor_original, valor_desconto,
                      desconto_detalhe, origem, mesa_id, taxa_entrega, registrado_por, caixa_id, requisicao_id)
  values (v_venda, v_nome, v_tel, v_resumo, v_total, v_custo, 'Confirmada', v_tipo, v_status_pedido_ini,
          case when v_tipo = 'Entrega' then coalesce(v_de->>'endereco', '') else '' end,
          case when v_tipo = 'Entrega' then coalesce(v_de->>'complemento', '') else '' end,
          case when v_tipo = 'Entrega' then coalesce(v_de->>'referencia', '') else '' end,
          coalesce(v_de->>'observacoes', ''), v_status_pag_final, case when v_status_pag_final = 'Pago' then now() else null end,
          v_orig, v_desc_val, v_desc_det, v_origem_final, case when v_tipo = 'Mesa' then v_mesa_id else null end, v_taxa, v_eu, v_caixa, v_req)
  returning numero_pedido into v_numero;

  insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
  select v_venda, _uuid(e->>'produtoId'), _uuid(e->>'comboId'), e->>'descricao', _num(e->>'quantidade', 1)::int,
         _num(e->>'valorUnitario'), _num(e->>'custoUnitario'), round(_num(e->>'quantidade', 1) * _num(e->>'valorUnitario'), 2),
         coalesce((select array_agg(_uuid(x)) filter (where _uuid(x) is not null)
                   from jsonb_array_elements_text(case when jsonb_typeof(e->'adicionaisIds') = 'array' then e->'adicionaisIds' else '[]'::jsonb end) x), '{}')
  from jsonb_array_elements(v_itens) e;

  insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada)
  select v_venda, btrim(e->>'forma'), _num(e->>'valor'),
         coalesce((select round(_num(e->>'valor') * f.taxa_percentual / 100 + f.taxa_fixa, 2) from formas_pagamento f where f.nome = btrim(e->>'forma')), 0)
  from jsonb_array_elements(v_pags) e;

  if v_tipo = 'Mesa' and v_mesa_status = 'Livre' then
    update mesas set status = 'Ocupada', garcom_responsavel_id = case when v_nivel = 'Garçom' then v_eu else garcom_responsavel_id end where id = v_mesa_id;
  elsif v_tipo = 'Mesa' and v_nivel = 'Garçom' and v_mesa_garcom is null then
    update mesas set garcom_responsavel_id = v_eu where id = v_mesa_id;
  end if;

  perform _ajustar_estoque(v_itens, 1, v_venda);

  if v_desc_val > 0 then
    perform _auditar('Desconto aplicado na venda', 'Autorizado por ' || coalesce(nullif(current_setting('app.autorizador', true), ''), v_login) || ' | Valor original: R$ ' || _dinheiro(v_orig)
      || ' → Desconto: ' || v_desc_det || ' → Valor final: R$ ' || _dinheiro(v_total), v_tel);
  end if;
  if v_tel <> '' then
    perform _upsert_cliente(v_tel, v_nome);
    if v_origem_final = 'Balcão' and v_status_pag_final = 'Pago' then
      perform _carimbar_fidelidade(v_tel, v_nome);
      v_msg_extra := ' Marca de fidelidade adicionada para ' || v_nome || '.';
    end if;
  end if;
  perform _auditar('Venda registrada', 'Total R$ ' || _dinheiro(v_total) || ' via ' || v_resumo || ' (' || v_tipo || ', ' || v_status_pag_final || ')', v_tel);

  return jsonb_build_object('ok', true, 'message', 'Venda registrada: R$ ' || _dinheiro(v_total) || '.' || v_msg_extra,
                            'id', v_venda, 'numero', v_numero, 'valorTotal', v_total);
end $function$
;

CREATE OR REPLACE FUNCTION public.api_espaco_percentual_servico()
 RETURNS numeric
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$ select round(pg_database_size(current_database())/1024.0/1024.0/_limite_banco_mb()*100, 1) $function$
;

CREATE OR REPLACE FUNCTION public.api_espaco_uso()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_db bigint;
BEGIN
  IF NOT tem_nivel('Admin') THEN RETURN _negado(); END IF;
  SELECT pg_database_size(current_database()) INTO v_db;
  RETURN jsonb_build_object('ok',true,'db_bytes',v_db,'db_mb',round(v_db/1024.0/1024.0,2),
    'limite_mb',_limite_banco_mb(),'percentual',round(v_db/1024.0/1024.0/_limite_banco_mb()*100,1),
    'vendas_total',(SELECT count(*) FROM vendas),
    'vendas_arquivadas',(SELECT count(*) FROM arquivo_historico WHERE tabela='vendas'),
    'backups_total',(SELECT count(*) FROM backups),
    'backups_bytes',(SELECT coalesce(sum(tamanho_bytes),0) FROM backups));
END $function$
;
