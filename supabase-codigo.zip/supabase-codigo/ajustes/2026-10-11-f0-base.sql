-- =====================================================================
-- FASE 0 — BASE · 2026-10-11
-- 1) Interruptores das integrações (iFood e Nota fiscal): tudo nasce DESLIGADO.
-- 2) Chaves/segredos das integrações (guardados no banco, sem policy: só funções seguras leem).
-- 3) IAs extras (NVIDIA NIM e Cloudflare Workers AI) em "Contas e acessos": sem chave = nada muda (Gemini/Groq como hoje).
-- 4) Saúde do sistema: ponto de extensão _saude_integracoes() (iFood/Nota/IAs extras só aparecem quando ligados/cadastrados).
-- Seguro para rodar de novo (create or replace / if not exists / on conflict).
-- =====================================================================

-- ---------- 3a) IAs extras: permitir as novas chaves e guardar preferências ----------
alter table public.ai_segredos drop constraint if exists ai_segredos_provedor_check;
alter table public.ai_segredos add constraint ai_segredos_provedor_check
  check (provedor = any (array['gemini','groq','nvidia','cloudflare','cloudflare_conta']));
alter table public.ai_config add column if not exists extras_publico boolean not null default false;   -- usar NVIDIA/Cloudflare também no atendimento ao cliente? (padrão: NÃO)
alter table public.ai_config add column if not exists modelo_nvidia text not null default 'meta/llama-3.3-70b-instruct';
alter table public.ai_config add column if not exists modelo_cloudflare text not null default '@cf/meta/llama-3.3-70b-instruct-fp8-fast';

-- "descansando": mesma regra do circuit breaker das funções (3+ erros em 5 min sem sucesso depois)
create or replace function public._ia_provedor_descansando(p_prov text) returns boolean
 language sql stable security definer set search_path to 'public' as $f$
  with l as (select status, row_number() over (order by criado_em desc) rn from ai_log where provedor = p_prov and criado_em > now() - interval '5 minutes'),
       u as (select coalesce(min(rn), 1000) as rn_ok from l where status = 'ok')
  select (select count(*) from l, u where l.status = 'erro' and l.rn < u.rn_ok) >= 3
$f$;

create or replace function public.api_listar_chaves_ia(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'extrasPublico', coalesce((select extras_publico from ai_config limit 1), false),
    'chaves', coalesce((select jsonb_agg(jsonb_build_object('provedor', v.prov,
           'temChave', length(coalesce(s.chave, '')) > 0 and (v.prov <> 'cloudflare' or length(coalesce(c.chave, '')) > 0),
           'final', case when length(coalesce(s.chave, '')) > 8 then right(s.chave, 4) else '' end,
           'temConta', length(coalesce(c.chave, '')) > 0,
           'descansando', _ia_provedor_descansando(v.prov),
           'atualizadoEm', s.atualizado_em) order by v.ordem)
         from (values ('gemini', 1), ('groq', 2), ('nvidia', 3), ('cloudflare', 4)) v(prov, ordem)
         left join ai_segredos s on s.provedor = v.prov
         left join ai_segredos c on c.provedor = 'cloudflare_conta' and v.prov = 'cloudflare'), '[]'::jsonb));
end $f$;

create or replace function public.api_ver_chave_ia(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare v text; v_conta text; v_prov text := lower(coalesce(p->>'provedor', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_prov not in ('gemini', 'groq', 'nvidia', 'cloudflare') then return _falha('IA desconhecida.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  select chave into v from ai_segredos where provedor = v_prov;
  if coalesce(v, '') = '' then return _falha('Esta IA não tem chave guardada.'); end if;
  select chave into v_conta from ai_segredos where provedor = 'cloudflare_conta' and v_prov = 'cloudflare';
  perform _auditar('Chave de IA visualizada', v_prov);
  return jsonb_build_object('ok', true, 'chave', v) || case when v_prov = 'cloudflare' then jsonb_build_object('contaId', coalesce(v_conta, '')) else '{}'::jsonb end;
end $f$;

create or replace function public.api_salvar_chave_ia(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text := lower(coalesce(p->>'provedor', '')); v_chave text := btrim(coalesce(p->>'chave', '')); v_conta text := lower(btrim(coalesce(p->>'contaId', '')));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_prov not in ('gemini', 'groq', 'nvidia', 'cloudflare') then return _falha('IA desconhecida.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  if length(v_chave) < 20 or length(v_chave) > 300 or v_chave ~ '\s' then return _falha('Chave inválida. Copie a chave inteira, sem espaços.'); end if;
  if v_prov = 'cloudflare' then
    if v_conta = '' and not exists (select 1 from ai_segredos where provedor = 'cloudflare_conta') then return _falha('Informe também o Account ID da Cloudflare.'); end if;
    if v_conta <> '' and v_conta !~ '^[0-9a-f]{32}$' then return _falha('Account ID inválido: são 32 letras e números (copie na tela "Use REST API" do Workers AI).'); end if;
    if v_conta <> '' then
      insert into ai_segredos (provedor, chave, atualizado_em) values ('cloudflare_conta', v_conta, now())
        on conflict (provedor) do update set chave = excluded.chave, atualizado_em = now();
    end if;
  end if;
  insert into ai_segredos (provedor, chave, atualizado_em) values (v_prov, v_chave, now())
    on conflict (provedor) do update set chave = excluded.chave, atualizado_em = now();
  perform _auditar('Chave de IA trocada', v_prov);
  return jsonb_build_object('ok', true, 'message', 'Chave salva. Os assistentes já usam a nova.') || api_listar_chaves_ia('{}');
end $f$;

-- usar as IAs extras também no atendimento público do cardápio? (padrão NÃO: confirmar antes os termos de privacidade do provedor)
create or replace function public.api_salvar_ia_extras(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  update ai_config set extras_publico = coalesce((p->>'publico')::boolean, false), atualizado_em = now() where id;
  perform _auditar('IAs extras no atendimento público', case when coalesce((p->>'publico')::boolean, false) then 'ligado' else 'desligado' end);
  return jsonb_build_object('ok', true, 'message', case when coalesce((p->>'publico')::boolean, false) then 'As IAs extras também atendem os clientes do cardápio.' else 'As IAs extras ficam só no uso interno.' end) || api_listar_chaves_ia('{}');
end $f$;

-- ---------- 1) Interruptores das integrações ----------
create table if not exists public.integracoes_config (
  provedor text primary key check (provedor in ('ifood', 'nfce')),
  ligado boolean not null default false,
  modo text not null default 'homologacao' check (modo in ('homologacao', 'producao')),
  ligado_em timestamptz,
  ligado_por text,
  checklist jsonb not null default '{}'::jsonb,
  config jsonb not null default '{}'::jsonb,          -- ajustes sem segredo (ex.: confirmação automática)
  atualizado_em timestamptz not null default now()
);
alter table public.integracoes_config enable row level security;
insert into public.integracoes_config (provedor, modo, config) values
  ('ifood', 'producao', '{"confirmacaoAutomatica": true, "baixaEstoque": "confirmacao", "abrirFecharComCaixa": true, "pausarSemEstoque": true, "retencaoClientesDias": 90}'::jsonb),
  ('nfce', 'homologacao', '{"canais": ["balcao"], "emitirQuando": "pagamento"}'::jsonb)
on conflict (provedor) do nothing;

create table if not exists public.integracoes_segredos (
  chave text primary key check (chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id', 'nfce_token_homologacao', 'nfce_token_producao')),
  valor text not null,
  atualizado_em timestamptz not null default now()
);
alter table public.integracoes_segredos enable row level security;   -- sem policy: só funções seguras (security definer) e a chave de serviço leem

create table if not exists public.integracoes_log (
  id bigserial primary key,
  criado_em timestamptz not null default now(),
  provedor text not null,
  nivel text not null default 'info' check (nivel in ('info', 'aviso', 'erro')),
  mensagem text not null,
  detalhe jsonb
);
create index if not exists integracoes_log_prov_idx on public.integracoes_log (provedor, criado_em desc);
alter table public.integracoes_log enable row level security;

create or replace function public._integ_log(p_prov text, p_nivel text, p_msg text, p_det jsonb default null) returns void
 language sql security definer set search_path to 'public' as $f$
  insert into integracoes_log (provedor, nivel, mensagem, detalhe) values (p_prov, p_nivel, left(p_msg, 300), p_det)
$f$;

-- só o usuário Desenvolvedor (auth_nivel() trata o Desenvolvedor como Admin, então tem_nivel('Desenvolvedor') nunca é verdadeiro)
create or replace function public._eh_dev() returns boolean
 language sql stable security definer set search_path to 'public' as $f$
  select exists (select 1 from usuarios where id = auth.uid() and ativo and nivel::text = 'Desenvolvedor')
$f$;

create or replace function public._integracao_ligada(p_prov text) returns boolean
 language sql stable security definer set search_path to 'public' as $f$
  select coalesce((select ligado from integracoes_config where provedor = p_prov), false)
$f$;

-- passos do checklist (o texto aparece na tela). auto = o sistema marca sozinho.
create or replace function public._integ_checklist_def(p_prov text) returns jsonb
 language sql immutable as $f$
  select case p_prov
    when 'ifood' then '[
      {"id":"conta_dev","titulo":"O dono criou a conta de desenvolvedor no iFood (precisa do CNPJ)"},
      {"id":"acesso","titulo":"Acesso liberado aos módulos Pedidos, Catálogo, Loja, Financeiro e Avaliações"},
      {"id":"chaves","titulo":"Client ID, Client Secret e código da loja digitados aqui","auto":true},
      {"id":"teste_conexao","titulo":"Teste de conexão deu certo","auto":true},
      {"id":"homologacao","titulo":"Homologação do iFood aprovada"},
      {"id":"itens","titulo":"Itens do iFood ligados aos produtos (aba Itens do iFood)"},
      {"id":"equipe","titulo":"Equipe avisada de como o pedido do iFood aparece"}]'::jsonb
    when 'nfce' then '[
      {"id":"contador","titulo":"O contador definiu NCM, CFOP e situação tributária de cada perfil"},
      {"id":"certificado","titulo":"Certificado digital A1 do restaurante pronto"},
      {"id":"sefaz","titulo":"Credenciamento na Sefaz-SP feito e CSC (código de segurança) obtido"},
      {"id":"focus","titulo":"Conta na Focus NFe criada e empresa cadastrada lá (com o certificado)"},
      {"id":"token","titulo":"Token da Focus digitado aqui","auto":true},
      {"id":"empresa","titulo":"Dados fiscais da empresa preenchidos aqui","auto":true},
      {"id":"perfis","titulo":"Todos os produtos têm perfil fiscal","auto":true},
      {"id":"nota_teste","titulo":"Nota de teste (homologação) emitida e conferida pelo contador"}]'::jsonb
    else '[]'::jsonb end
$f$;

-- pendências para ligar (lista de textos). Fases seguintes substituem esta função para acrescentar verificações.
create or replace function public._integ_pendencias(p_prov text, p_modo text) returns text[]
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_out text[] := '{}'; v_item jsonb; v_ck jsonb; v_ok boolean;
begin
  select checklist into v_ck from integracoes_config where provedor = p_prov;
  for v_item in select * from jsonb_array_elements(_integ_checklist_def(p_prov)) loop
    if coalesce((v_item->>'auto')::boolean, false) then
      v_ok := case v_item->>'id'
        when 'chaves' then (select count(*) from integracoes_segredos where chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id')) = 3
        when 'token' then exists (select 1 from integracoes_segredos where chave = 'nfce_token_' || p_modo)
        else coalesce((v_ck->>(v_item->>'id'))::boolean, false) end;
    else
      v_ok := coalesce((v_ck->>(v_item->>'id'))::boolean, false);
    end if;
    if not v_ok then v_out := v_out || (v_item->>'titulo'); end if;
  end loop;
  return v_out;
end $f$;

create or replace function public.api_integracoes_flags(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if auth_nivel() is null then return _negado(); end if;
  return jsonb_build_object('ok', true, 'ifood', _integracao_ligada('ifood'), 'nfce', _integracao_ligada('nfce'),
    'nfceModo', (select modo from integracoes_config where provedor = 'nfce'));
end $f$;

create or replace function public.api_integracoes_status(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_modo text; v_def jsonb; v_it jsonb; v_pend text[];
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  for r in select * from integracoes_config order by provedor loop
    v_def := _integ_checklist_def(r.provedor); v_pend := _integ_pendencias(r.provedor, r.modo);
    v := v || jsonb_build_object('provedor', r.provedor, 'ligado', r.ligado, 'modo', r.modo, 'ligadoEm', r.ligado_em, 'config', r.config,
      'checklist', (select coalesce(jsonb_agg(jsonb_build_object('id', x->>'id', 'titulo', x->>'titulo', 'auto', coalesce((x->>'auto')::boolean, false),
          'feito', not ((x->>'titulo') = any (v_pend))) ), '[]'::jsonb) from jsonb_array_elements(v_def) x),
      'pendencias', to_jsonb(v_pend), 'podeLigar', coalesce(array_length(v_pend, 1), 0) = 0,
      'segredos', (select coalesce(jsonb_object_agg(s.chave, jsonb_build_object('tem', true, 'final', case when length(s.valor) > 8 then right(s.valor, 4) else '' end, 'em', s.atualizado_em)), '{}'::jsonb)
                    from integracoes_segredos s where (r.provedor = 'ifood' and s.chave like 'ifood\_%') or (r.provedor = 'nfce' and s.chave like 'nfce\_%')));
  end loop;
  return jsonb_build_object('ok', true, 'integracoes', v);
end $f$;

create or replace function public.api_integracoes_marcar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text := p->>'provedor'; v_item text := p->>'item'; v_feito boolean := coalesce((p->>'feito')::boolean, false);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not exists (select 1 from jsonb_array_elements(_integ_checklist_def(v_prov)) x where x->>'id' = v_item and not coalesce((x->>'auto')::boolean, false)) then return _falha('Passo inválido.'); end if;
  update integracoes_config set checklist = jsonb_set(checklist, array[v_item], to_jsonb(v_feito), true), atualizado_em = now() where provedor = v_prov;
  perform _auditar('Integração: passo marcado', v_prov || ' · ' || v_item || ' · ' || v_feito::text);
  return api_integracoes_status('{}');
end $f$;

create or replace function public.api_integracoes_config(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text := p->>'provedor'; v_cfg jsonb := coalesce(p->'config', '{}'::jsonb); v_atual jsonb; v_chave text; v_novo jsonb := '{}'::jsonb;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_prov not in ('ifood', 'nfce') then return _falha('Integração inválida.'); end if;
  select config into v_atual from integracoes_config where provedor = v_prov;
  -- só chaves conhecidas, com valores simples
  for v_chave in select jsonb_object_keys(v_cfg) loop
    if v_prov = 'ifood' and v_chave in ('confirmacaoAutomatica', 'abrirFecharComCaixa', 'pausarSemEstoque', 'enviarPrecos') then v_novo := v_novo || jsonb_build_object(v_chave, coalesce((v_cfg->>v_chave)::boolean, false));
    elsif v_prov = 'ifood' and v_chave = 'baixaEstoque' and (v_cfg->>v_chave) in ('confirmacao', 'entrega') then v_novo := v_novo || jsonb_build_object(v_chave, v_cfg->>v_chave);
    elsif v_prov = 'ifood' and v_chave = 'retencaoClientesDias' and (v_cfg->>v_chave)::int between 7 and 365 then v_novo := v_novo || jsonb_build_object(v_chave, (v_cfg->>v_chave)::int);
    elsif v_prov = 'ifood' and v_chave = 'limitePrecoPct' and (v_cfg->>v_chave)::numeric between 0 and 100 then v_novo := v_novo || jsonb_build_object(v_chave, (v_cfg->>v_chave)::numeric);
    elsif v_prov = 'nfce' and v_chave = 'emitirQuando' and (v_cfg->>v_chave) in ('pagamento', 'entrega') then v_novo := v_novo || jsonb_build_object(v_chave, v_cfg->>v_chave);
    elsif v_prov = 'nfce' and v_chave = 'canais' and jsonb_typeof(v_cfg->v_chave) = 'array' then v_novo := v_novo || jsonb_build_object(v_chave, (select coalesce(jsonb_agg(c), '[]'::jsonb) from jsonb_array_elements_text(v_cfg->v_chave) c where c in ('balcao', 'cardapio', 'ifood', 'mesa')));
    end if;
  end loop;
  update integracoes_config set config = v_atual || v_novo, atualizado_em = now() where provedor = v_prov;
  perform _auditar('Integração: ajustes salvos', v_prov);
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Ajustes salvos.');
end $f$;

create or replace function public.api_integracoes_salvar_segredo(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_chave text := p->>'chave'; v_valor text := btrim(coalesce(p->>'valor', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_chave not in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id', 'nfce_token_homologacao', 'nfce_token_producao') then return _falha('Campo desconhecido.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  if length(v_valor) < 8 or length(v_valor) > 400 or v_valor ~ '\s' then return _falha('Valor inválido. Copie inteiro, sem espaços.'); end if;
  insert into integracoes_segredos (chave, valor, atualizado_em) values (v_chave, v_valor, now())
    on conflict (chave) do update set valor = excluded.valor, atualizado_em = now();
  perform _auditar('Integração: chave salva', v_chave);
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Salvo.');
end $f$;

create or replace function public.api_integracoes_ver_segredo(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  select valor into v from integracoes_segredos where chave = p->>'chave';
  if v is null then return _falha('Nada guardado neste campo.'); end if;
  perform _auditar('Integração: chave visualizada', p->>'chave');
  return jsonb_build_object('ok', true, 'valor', v);
end $f$;

create or replace function public.api_integracoes_ligar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text := p->>'provedor'; v_modo text := coalesce(p->>'modo', 'producao'); v_pend text[]; v_uid text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_prov not in ('ifood', 'nfce') then return _falha('Integração inválida.'); end if;
  if v_prov = 'nfce' and v_modo not in ('homologacao', 'producao') then return _falha('Escolha o ambiente: teste (homologação) ou produção.'); end if;
  if v_prov = 'ifood' then v_modo := 'producao'; end if;
  v_uid := _exige_admin(p->>'senhaAdmin');
  if coalesce(p->>'senhaAdmin', '') = '' or v_uid is null then return _falha('Senha de administrador incorreta.'); end if;
  v_pend := _integ_pendencias(v_prov, v_modo);
  if coalesce(array_length(v_pend, 1), 0) > 0 then return _falha('Ainda faltam passos: ' || array_to_string(v_pend, '; ')); end if;
  update integracoes_config set ligado = true, modo = v_modo, ligado_em = now(), ligado_por = v_uid, atualizado_em = now() where provedor = v_prov;
  perform _auditar('Integração LIGADA', v_prov || ' · ' || v_modo);
  perform _integ_log(v_prov, 'info', 'Integração ligada (' || v_modo || ')');
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Ligado.');
end $f$;

create or replace function public.api_integracoes_desligar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if p->>'provedor' not in ('ifood', 'nfce') then return _falha('Integração inválida.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' or _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  update integracoes_config set ligado = false, atualizado_em = now() where provedor = p->>'provedor';
  perform _auditar('Integração DESLIGADA', p->>'provedor');
  perform _integ_log(p->>'provedor', 'aviso', 'Integração desligada');
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Desligado. O sistema voltou a funcionar como antes.');
end $f$;

create or replace function public.api_integracoes_log(p jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'itens', coalesce((select jsonb_agg(jsonb_build_object('em', to_char(criado_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI:SS'), 'nivel', nivel, 'texto', mensagem) order by criado_em desc)
     from (select * from integracoes_log where provedor = p->>'provedor' order by criado_em desc limit 60) x), '[]'::jsonb));
end $f$;

-- limpeza do log (30 dias)
create or replace function public._integracoes_limpar() returns void
 language sql security definer set search_path to 'public' as $f$
  delete from integracoes_log where criado_em < now() - interval '30 days'
$f$;

-- ---------- 4) Saúde: integrações + IAs extras (só aparecem quando ligadas/cadastradas) ----------
create or replace function public._saude_integracoes() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_txt text; v_desc int;
begin
  -- IAs extras: só se tiver chave
  if exists (select 1 from ai_segredos where provedor = 'nvidia') or exists (select 1 from ai_segredos where provedor = 'cloudflare') then
    select count(*) into v_desc from unnest(array['nvidia', 'cloudflare']) x(p) where _ia_provedor_descansando(x.p);
    v := v || jsonb_build_object('id', 'ia_extras', 'titulo', 'IAs de reserva (NVIDIA / Cloudflare)',
      'nivel', case when v_desc > 0 then 'atencao' else 'ok' end,
      'texto', (select string_agg(x.rot || ': ' || case when not exists (select 1 from ai_segredos where provedor = x.p) then 'sem chave' when _ia_provedor_descansando(x.p) then 'descansando (erros recentes)' else 'pronta' end, ' · ')
                from (values ('nvidia', 'NVIDIA'), ('cloudflare', 'Cloudflare')) x(p, rot)));
  end if;
  for r in select * from integracoes_config where ligado loop
    v_txt := case r.provedor when 'ifood' then 'Ligado, aguardando a primeira consulta ao iFood.' else 'Ligada (' || r.modo || '), aguardando a primeira nota.' end;
    v := v || jsonb_build_object('id', r.provedor, 'titulo', case r.provedor when 'ifood' then 'iFood' else 'Nota fiscal (NFC-e)' end, 'nivel', 'atencao', 'texto', v_txt);
  end loop;
  return v;
end $f$;

create or replace function public.api_saude_sistema(p jsonb DEFAULT '{}'::jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public', 'cron' as $function$
declare itens jsonb := '[]'::jsonb; v_n int; v_min numeric; v_b record; v_i record; v_c int; v_ia int; v_ult timestamptz; v_pior text := 'ok';
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  -- 1) fila de sincronização com as planilhas
  select count(*), coalesce(extract(epoch from (now() - min(criado_em))) / 60, 0) into v_n, v_min from fila_sync where principal_ok_em is null;
  itens := itens || jsonb_build_object('id', 'fila', 'titulo', 'Cópia para a planilha de reserva',
    'nivel', case when v_n = 0 then 'ok' when v_min < 30 then 'atencao' else 'problema' end,
    'texto', case when v_n = 0 then 'Tudo copiado.' else v_n || ' item(ns) esperando; o mais antigo há ' || round(v_min) || ' min.' end);
  -- 2) backup automático
  select * into v_b from backups order by data_hora desc limit 1;
  itens := itens || jsonb_build_object('id', 'backup', 'titulo', 'Backup automático',
    'nivel', case when v_b.id is null then 'problema' when v_b.status <> 'Sucesso' then 'problema' when v_b.data_hora < now() - interval '48 hours' then 'problema' when v_b.data_hora < now() - interval '26 hours' then 'atencao' else 'ok' end,
    'texto', case when v_b.id is null then 'Nenhum backup encontrado.' when v_b.status <> 'Sucesso' then 'O último backup falhou: ' || coalesce(left(v_b.erro, 120), 'sem detalhe') else 'Último backup há ' || round(extract(epoch from (now() - v_b.data_hora)) / 3600, 1) || ' h.' end);
  itens := itens || jsonb_build_object('id', 'drive', 'titulo', 'Cópia do backup no Drive',
    'nivel', case when v_b.id is null then 'atencao' when v_b.copia_drive_erro is not null then 'atencao' when v_b.copia_drive_em is null then 'atencao' else 'ok' end,
    'texto', case when v_b.copia_drive_erro is not null then 'Falhou: ' || left(v_b.copia_drive_erro, 120) when v_b.copia_drive_em is null then 'Ainda não copiado.' else 'Copiado no Drive.' end);
  -- 3) conferência Supabase x planilha
  select * into v_i from integridade_checks order by criado_em desc limit 1;
  itens := itens || jsonb_build_object('id', 'integridade', 'titulo', 'Conferência de vendas (diária)',
    'nivel', case when v_i.id is null then 'atencao' when v_i.status <> 'ok' then 'problema' when v_i.criado_em < now() - interval '3 days' then 'atencao' else 'ok' end,
    'texto', case when v_i.id is null then 'Ainda não rodou.' when v_i.status <> 'ok' then 'Conferência do dia ' || to_char((v_i.detalhe->>'data')::date, 'DD/MM') || ' achou diferença: ' || v_i.supabase_vendas || ' vendas no Supabase x ' || v_i.planilha_vendas || ' na planilha.' else 'Conferido o dia ' || to_char((v_i.detalhe->>'data')::date, 'DD/MM') || ': ' || v_i.supabase_vendas || ' vendas no Supabase e ' || v_i.planilha_vendas || ' na planilha.' end);
  -- 4) tarefas automáticas
  select count(*) into v_c from cron.job j where (select d.status from cron.job_run_details d where d.jobid = j.jobid order by d.start_time desc limit 1) = 'failed';
  itens := itens || jsonb_build_object('id', 'tarefas', 'titulo', 'Tarefas automáticas', 'nivel', case when v_c = 0 then 'ok' else 'problema' end,
    'texto', case when v_c = 0 then 'Todas rodaram bem na última vez.' else v_c || ' tarefa(s) falharam na última execução.' end);
  -- 5) IA
  select count(*) into v_ia from ai_log where criado_em > now() - interval '1 hour' and status = 'erro';
  itens := itens || jsonb_build_object('id', 'ia', 'titulo', 'Assistente (IA)', 'nivel', case when v_ia >= 5 then 'atencao' else 'ok' end,
    'texto', case when v_ia >= 5 then v_ia || ' erro(s) na última hora; o sistema segue normal.' else 'Funcionando.' end);
  -- 6) IAs de reserva, iFood e Nota fiscal (só aparecem quando cadastradas/ligadas)
  itens := itens || _saude_integracoes();
  select case when bool_or(x->>'nivel' = 'problema') then 'problema' when bool_or(x->>'nivel' = 'atencao') then 'atencao' else 'ok' end into v_pior from jsonb_array_elements(itens) x;
  return jsonb_build_object('ok', true, 'geral', v_pior, 'itens', itens, 'em', to_char(now() at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI'));
end $function$;

-- ---------- permissões ----------
revoke execute on function public._ia_provedor_descansando(text), public._integ_log(text, text, text, jsonb), public._integracao_ligada(text), public._eh_dev(),
  public._integ_checklist_def(text), public._integ_pendencias(text, text), public._integracoes_limpar(), public._saude_integracoes() from public, anon, authenticated;
revoke execute on function public.api_listar_chaves_ia(jsonb), public.api_ver_chave_ia(jsonb), public.api_salvar_chave_ia(jsonb), public.api_salvar_ia_extras(jsonb),
  public.api_integracoes_flags(jsonb), public.api_integracoes_status(jsonb), public.api_integracoes_marcar(jsonb), public.api_integracoes_config(jsonb),
  public.api_integracoes_salvar_segredo(jsonb), public.api_integracoes_ver_segredo(jsonb), public.api_integracoes_ligar(jsonb), public.api_integracoes_desligar(jsonb),
  public.api_integracoes_log(jsonb) from public, anon;
grant execute on function public.api_listar_chaves_ia(jsonb), public.api_ver_chave_ia(jsonb), public.api_salvar_chave_ia(jsonb), public.api_salvar_ia_extras(jsonb),
  public.api_integracoes_flags(jsonb), public.api_integracoes_status(jsonb), public.api_integracoes_marcar(jsonb), public.api_integracoes_config(jsonb),
  public.api_integracoes_salvar_segredo(jsonb), public.api_integracoes_ver_segredo(jsonb), public.api_integracoes_ligar(jsonb), public.api_integracoes_desligar(jsonb),
  public.api_integracoes_log(jsonb) to authenticated;

-- ---------- Ajuda do assistente ----------
update ai_ajuda set palavras_chave = 'contas acessos email senha link supabase github planilha apps script cofre ver senha chave ia gemini groq nvidia cloudflare reserva',
  passos = E'Administrador → Sistema → Contas e acessos: lista das contas do sistema (Supabase, GitHub, planilhas…) com e-mail, link e observação.\n"+ Nova conta" cadastra; "Editar" muda os dados ou a senha; "Excluir" apaga a conta e a senha guardada.\nA senha fica no cofre criptografado do Supabase. Para ver, toque em "Ver senha" e digite a SUA senha de administrador; ela aparece por 30 segundos e fica registrado na Auditoria.\nChaves das IAs (Gemini, Groq, NVIDIA e Cloudflare): na mesma tela. "Ver chave" e "Trocar chave" pedem a senha de administrador; a chave nova vale na hora. NVIDIA e Cloudflare são IAs de reserva: sem chave, nada muda; com chave, entram quando o Gemini e a Groq falham ou esgotam o limite grátis.'
where slug = 'man-admin-101-contas-e-acessos';
insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-102-integracoes','Integrações: iFood e Nota fiscal','integrações ifood nota fiscal nfce focus ligar desligar interruptor chaves guia checklist',
 E'Administrador → Sistema → Contas e acessos → cartão "Integrações": o iFood e a Nota fiscal já vêm prontos no sistema, mas DESLIGADOS. Desligado, o sistema funciona exatamente como antes.\nCada integração tem um guia passo a passo na própria tela e um checklist. Só dá para ligar quando todos os passos estiverem prontos; ligar pede a senha de administrador.\nAs chaves são digitadas só nesta tela, ficam guardadas com segurança e só aparecem com a sua senha. Nunca envie chaves por mensagem.\nPara desligar, toque em "Desligar" e confirme com a senha: o sistema volta a funcionar como antes, e o que já foi gravado fica guardado.',
 array['Admin'],true,'lista',102,'Só Administrador e Desenvolvedor veem esta tela.'
where not exists (select 1 from ai_ajuda where slug='man-admin-102-integracoes');
