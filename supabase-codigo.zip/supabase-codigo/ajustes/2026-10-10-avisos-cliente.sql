-- =====================================================================
-- Avisos do pedido no celular do CLIENTE (Web Push) + pergunta "Como foi seu pedido?" + origem do feedback · 2026-10-10
-- Usa as mesmas chaves VAPID e a mesma função push-enviar da equipe (ver push-equipe.sql).
-- Inscrições de clientes ficam numa tabela SEPARADA da equipe: cliente nunca recebe aviso da equipe e vice-versa.
-- O texto do aviso não leva nome, telefone nem endereço (aparece na tela bloqueada).
-- Seguro para rodar de novo.
-- =====================================================================
create table if not exists public.push_clientes (
  id uuid primary key default gen_random_uuid(),
  endpoint text not null unique check (endpoint like 'https://%' and char_length(endpoint) <= 800),
  p256dh text not null check (char_length(p256dh) <= 200),
  auth text not null check (char_length(auth) <= 100),
  criado_em timestamptz not null default now(),
  usado_em timestamptz not null default now(),
  ultimo_envio_em timestamptz,
  falhas int not null default 0
);
create table if not exists public.push_cliente_pedidos (
  venda_id uuid not null references public.vendas(id) on delete cascade,
  inscricao_id uuid not null references public.push_clientes(id) on delete cascade,
  criado_em timestamptz not null default now(),
  feedback_pedido_em timestamptz,
  primary key (venda_id, inscricao_id)
);
create index if not exists push_cliente_pedidos_insc_idx on public.push_cliente_pedidos (inscricao_id);
alter table public.push_clientes enable row level security;
alter table public.push_cliente_pedidos enable row level security;
revoke all on public.push_clientes, public.push_cliente_pedidos from anon, authenticated;

-- origem do feedback: formulario (rodapé), aviso (veio pela notificação "Como foi seu pedido?") ou chat (assistente)
alter table public.feedbacks add column if not exists origem text not null default 'formulario';
do $do$ begin
  if not exists (select 1 from pg_constraint where conname = 'feedbacks_origem_check') then
    alter table public.feedbacks add constraint feedbacks_origem_check check (origem in ('formulario', 'aviso', 'chat'));
  end if;
end $do$;

-- cliente aceita os avisos neste aparelho (com ou sem pedido). Com "codigo" (8 últimos do id do pedido), liga o aparelho ao pedido.
create or replace function public.api_push_cliente_inscrever(p jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare v_ep text := btrim(coalesce(p->>'endpoint','')); v_k text := btrim(coalesce(p->'keys'->>'p256dh','')); v_a text := btrim(coalesce(p->'keys'->>'auth',''));
  v_cod text := lower(btrim(coalesce(p->>'codigo',''))); v_ip text := _ip_cliente(); v_insc uuid; v_venda uuid;
begin
  if v_ep not like 'https://%' or char_length(v_ep) > 800 or v_k = '' or v_a = '' or char_length(v_k) > 200 or char_length(v_a) > 100 then return _falha('Inscrição inválida.'); end if;
  if _excedeu('pushcli_ip_' || v_ip, 30) or _excedeu('pushcli_global', 600) then return _falha('Muitas tentativas. Tente mais tarde.'); end if;
  perform _registrar_falha('pushcli_ip_' || v_ip, 600); perform _registrar_falha('pushcli_global', 600);
  insert into push_clientes (endpoint, p256dh, auth) values (v_ep, v_k, v_a)
  on conflict (endpoint) do update set p256dh = excluded.p256dh, auth = excluded.auth, falhas = 0, usado_em = now()
  returning id into v_insc;
  if v_cod ~ '^[0-9a-f]{8}$' then
    select id into v_venda from vendas where right(id::text, 8) = v_cod and origem = 'Cardápio' and mesa_id is null
      and data_hora > now() - interval '6 hours' order by data_hora desc limit 1;
    if v_venda is not null and (select count(*) from push_cliente_pedidos where venda_id = v_venda) < 5 then
      insert into push_cliente_pedidos (venda_id, inscricao_id) values (v_venda, v_insc) on conflict do nothing;
    end if;
  end if;
  return jsonb_build_object('ok', true, 'ligado', v_venda is not null);
end $f$;

create or replace function public.api_push_cliente_cancelar(p jsonb) returns jsonb language plpgsql security definer set search_path to 'public' as $f$
begin
  delete from push_clientes where endpoint = btrim(coalesce(p->>'endpoint',''));
  return jsonb_build_object('ok', true);
end $f$;

-- manda o aviso para os aparelhos ligados a um pedido (nunca atrapalha a venda)
create or replace function public._push_cliente_enviar(p_venda uuid, p_titulo text, p_texto text, p_url text, p_tag text) returns void language plpgsql security definer set search_path to 'public','extensions' as $f$
begin
  if not exists (select 1 from push_cliente_pedidos where venda_id = p_venda) then return; end if;
  perform chamar_edge('push-enviar', jsonb_build_object('publico', true, 'vendaId', p_venda, 'tipo', 'cliente', 'titulo', p_titulo, 'texto', p_texto, 'url', p_url, 'tag', p_tag));
exception when others then null;
end $f$;

create or replace function public._push_status_cliente() returns trigger language plpgsql security definer set search_path to 'public' as $f$
declare v_n text := coalesce('nº ' || new.numero_pedido::text, ''); v_t text; v_x text; v_url text := './?pedido=' || right(new.id::text, 8);
begin
  if new.origem <> 'Cardápio' or new.mesa_id is not null then return null; end if;
  if new.status = 'Cancelada' and old.status is distinct from 'Cancelada' then
    v_t := '❌ Pedido ' || v_n || ' cancelado'; v_x := 'Toque para ver os detalhes.';
  elsif new.status = 'Confirmada' and new.status_pedido is distinct from old.status_pedido then
    case new.status_pedido::text
      when 'Em preparo' then if old.status_pedido::text = 'Suspenso' then return null; end if;
                             v_t := '👨‍🍳 Pedido ' || v_n || ' confirmado'; v_x := 'Já estamos preparando o seu pedido.';
      when 'Pronta' then if new.tipo::text <> 'Retirada' then return null; end if;
                         v_t := '✅ Pedido ' || v_n || ' pronto'; v_x := 'Já pode retirar no balcão.';
      when 'Saiu para entrega' then v_t := '🛵 Pedido ' || v_n || ' saiu para entrega'; v_x := 'Está a caminho!';
      when 'Entregue' then v_t := '😋 Pedido ' || v_n || ' entregue'; v_x := 'Bom apetite!';
      when 'Retirada' then v_t := '😋 Pedido ' || v_n || ' retirado'; v_x := 'Bom apetite!';
      else return null;
    end case;
  else return null;
  end if;
  perform _push_cliente_enviar(new.id, v_t, v_x, v_url, 'pedido-cli-' || new.id::text);
  return null;
end $f$;

do $do$ begin
  if not exists (select 1 from pg_trigger where tgname = 'trg_push_status_cliente') then
    execute 'create trigger trg_push_status_cliente after update of status, status_pedido on public.vendas for each row execute function public._push_status_cliente()';
  end if;
end $do$;

-- 30 min depois de entregue/retirado: "Como foi seu pedido?" (uma vez por pedido; só até 3 h depois; não pergunta se já deu feedback)
create or replace function public._push_clientes_feedback() returns void language plpgsql security definer set search_path to 'public' as $f$
declare r record;
begin
  for r in select distinct v.id, v.numero_pedido from push_cliente_pedidos l join vendas v on v.id = l.venda_id
           where l.feedback_pedido_em is null and v.status = 'Confirmada' and v.status_pedido in ('Entregue', 'Retirada')
             and coalesce(v.concluida_em, v.data_hora) between now() - interval '3 hours' and now() - interval '30 minutes'
             and not exists (select 1 from feedbacks f where f.venda_id = v.id)
  loop
    update push_cliente_pedidos set feedback_pedido_em = now() where venda_id = r.id;
    perform _push_cliente_enviar(r.id, '⭐ Como foi seu pedido?', 'Toque para dar uma nota. Leva 10 segundos.', './?feedback=' || right(r.id::text, 8), 'feedback-cli-' || r.id::text);
  end loop;
  -- limpeza: ligações com mais de 2 dias e aparelhos sem uso há 6 meses
  delete from push_cliente_pedidos where criado_em < now() - interval '2 days';
  delete from push_clientes where usado_em < now() - interval '180 days';
end $f$;

do $do$ begin
  if exists (select 1 from cron.job where jobname = 'push-clientes-feedback') then perform cron.unschedule('push-clientes-feedback'); end if;
  perform cron.schedule('push-clientes-feedback', '*/5 * * * *', 'select public._push_clientes_feedback()');
end $do$;

-- feedback: aceita "codigo" do pedido (8 últimos do id) e a origem
create or replace function public.api_add_feedback(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $function$
declare v_nota numeric := _num(p->>'nota'); v_dig text := _so_digitos(p->>'telefone'); v_ip text := _ip_cliente(); v_chave text;
        v_venda uuid := _uuid(p->>'vendaId'); v_cli uuid; v_cod text := lower(btrim(coalesce(p->>'codigo','')));
        v_origem text := case when p->>'origem' in ('aviso', 'chat') then p->>'origem' else 'formulario' end;
begin
  if v_nota < 1 or v_nota > 5 or v_nota <> floor(v_nota) then return _falha('A nota deve ser de 1 a 5.'); end if;
  if v_dig <> '' and (length(v_dig) < 10 or length(v_dig) > 13) then return _falha('Telefone inválido.'); end if;
  v_chave := 'feedback_' || coalesce(nullif(v_dig, ''), 'anon');
  if _excedeu(v_chave, 5) or _excedeu('feedback_ip_' || v_ip, 10) or _excedeu('feedback_global', 120) then
    return _falha('Muitos feedbacks em sequência. Aguarde alguns minutos.');
  end if;
  if v_venda is null and v_cod ~ '^[0-9a-f]{8}$' then
    select id into v_venda from vendas where right(id::text, 8) = v_cod and data_hora > now() - interval '3 days' order by data_hora desc limit 1;
  end if;
  if v_venda is not null and not exists (select 1 from vendas where id = v_venda) then v_venda := null; end if;
  if v_dig <> '' then select id into v_cli from clientes where _so_digitos(telefone) = v_dig limit 1; end if;
  insert into feedbacks (venda_id, cliente_id, telefone_cliente, nota, comentario, status, origem)
  values (v_venda, v_cli, v_dig, v_nota::int, _texto_publico(p->>'comentario', 500), 'Novo', v_origem);
  perform _registrar_falha(v_chave, 600); perform _registrar_falha('feedback_ip_' || v_ip, 600); perform _registrar_falha('feedback_global', 600);
  perform _auditar_publico('Feedback recebido', 'Nota ' || v_nota::int || case v_origem when 'chat' then ' (pelo chat)' when 'aviso' then ' (pelo aviso)' else '' end, v_dig);
  return jsonb_build_object('ok', true, 'message', 'Obrigado pelo feedback!');
end $function$;

grant execute on function public.api_push_cliente_inscrever(jsonb), public.api_push_cliente_cancelar(jsonb), public.api_add_feedback(jsonb) to anon, authenticated;
revoke execute on function public._push_cliente_enviar(uuid,text,text,text,text), public._push_status_cliente(), public._push_clientes_feedback() from public, anon, authenticated;

-- Ajuda do assistente
insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-102-avisos-cliente','Avisos do pedido para o cliente e feedbacks','aviso notificacao celular cliente status pedido confirmado pronto saiu entrega entregue como foi seu pedido feedback chat origem',
E'O cliente que aceita os avisos (convite no topo do cardápio ou no cartão "Pedido enviado") recebe no celular: confirmado (Em preparo), pronto (só retirada), saiu para entrega, entregue/retirado e cancelado.\nO aviso sai sozinho quando a equipe muda o status. Mostra só o número do pedido, nunca nome, telefone ou endereço.\n30 minutos depois de entregue (até 3 horas) chega "Como foi seu pedido?", se o cliente ainda não deu feedback daquele pedido.\nEm Painel → Feedbacks aparece de onde veio: "veio pelo aviso do pedido", "veio pelo chat" ou sem marca (rodapé).',
array['Admin','Operador'],true,'lista',102,'Pedido de mesa (QR Code) não recebe aviso. No iPhone o cliente precisa instalar o app (Adicionar à Tela de Início).'
where not exists (select 1 from ai_ajuda where slug='man-admin-102-avisos-cliente');
