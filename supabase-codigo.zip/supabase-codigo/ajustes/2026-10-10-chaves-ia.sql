-- =====================================================================
-- "Chaves das IAs" em Contas e acessos (Admin → Sistema) · 2026-10-10
-- As chaves continuam em public.ai_segredos (onde os assistentes já leem). Sem cópia.
-- Listar: só mostra se tem chave e a data. Ver e trocar: exigem a senha de administrador e ficam na Auditoria.
-- Seguro para rodar de novo.
-- =====================================================================
create or replace function public.api_listar_chaves_ia(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'chaves', coalesce((select jsonb_agg(jsonb_build_object('provedor', v.prov,
           'temChave', length(coalesce(s.chave, '')) > 0, 'final', case when length(coalesce(s.chave, '')) > 8 then right(s.chave, 4) else '' end,
           'atualizadoEm', s.atualizado_em) order by v.ordem)
         from (values ('gemini', 1), ('groq', 2)) v(prov, ordem) left join ai_segredos s on s.provedor = v.prov), '[]'::jsonb));
end $f$;

create or replace function public.api_ver_chave_ia(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare v text; v_prov text := lower(coalesce(p->>'provedor', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  select chave into v from ai_segredos where provedor = v_prov;
  if coalesce(v, '') = '' then return _falha('Esta IA não tem chave guardada.'); end if;
  perform _auditar('Chave de IA visualizada', v_prov);
  return jsonb_build_object('ok', true, 'chave', v);
end $f$;

create or replace function public.api_salvar_chave_ia(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare v_prov text := lower(coalesce(p->>'provedor', '')); v_chave text := btrim(coalesce(p->>'chave', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_prov not in ('gemini', 'groq') then return _falha('IA desconhecida.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  if length(v_chave) < 20 or length(v_chave) > 300 or v_chave ~ '\s' then return _falha('Chave inválida. Copie a chave inteira, sem espaços.'); end if;
  insert into ai_segredos (provedor, chave, atualizado_em) values (v_prov, v_chave, now())
    on conflict (provedor) do update set chave = excluded.chave, atualizado_em = now();
  perform _auditar('Chave de IA trocada', v_prov);
  return jsonb_build_object('ok', true, 'message', 'Chave salva. Os assistentes já usam a nova.') || api_listar_chaves_ia('{}');
end $f$;

revoke execute on function public.api_listar_chaves_ia(jsonb), public.api_ver_chave_ia(jsonb), public.api_salvar_chave_ia(jsonb) from public, anon;
grant execute on function public.api_listar_chaves_ia(jsonb), public.api_ver_chave_ia(jsonb), public.api_salvar_chave_ia(jsonb) to authenticated;

-- Ajuda do assistente (acrescenta as chaves das IAs no tópico de Contas e acessos)
update ai_ajuda set palavras_chave = 'contas acessos email senha link supabase github planilha apps script cofre ver senha chave ia gemini groq',
  passos = E'Administrador → Sistema → Contas e acessos: lista das contas do sistema (Supabase, GitHub, planilhas…) com e-mail, link e observação.\n"+ Nova conta" cadastra; "Editar" muda os dados ou a senha; "Excluir" apaga a conta e a senha guardada.\nA senha fica no cofre criptografado do Supabase. Para ver, toque em "Ver senha" e digite a SUA senha de administrador; ela aparece por 30 segundos e fica registrado na Auditoria.\nChaves das IAs (Gemini e Groq): na mesma tela. "Ver chave" e "Trocar chave" pedem a senha de administrador; a chave nova vale na hora para os assistentes.'
where slug = 'man-admin-101-contas-e-acessos';
