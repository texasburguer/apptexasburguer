-- =====================================================================================
-- FASE 6 — Nota fiscal: cancelamento, inutilização, conferência "Vendas × Notas", pacote do contador, limite do plano
-- Tudo NASCE DESLIGADO (depende da integração "nfce" ligada). Idempotente. Depende da f4 e da f5.
-- ⚠️ Escrito a partir da documentação pública da Focus NFe; NÃO testado com a Focus de verdade.
-- =====================================================================================

alter table public.nfce_notas add column if not exists cancelar_pedido boolean not null default false;   -- a venda foi cancelada enquanto a nota ainda estava em dúvida
alter table public.nfce_notas add column if not exists cancelar_manual boolean not null default false;   -- fora do prazo (30 min) ou recusado: o contador orienta

-- pede o cancelamento da nota autorizada (só dentro do prazo; fora dele vira pendência para o contador)
create or replace function public._nfce_iniciar_cancelamento(p_id bigint, p_motivo text) returns void
 language plpgsql security definer set search_path to 'public' as $f$
declare n nfce_notas%rowtype; v_j text;
begin
  select * into n from nfce_notas where id = p_id for update;
  if not found or n.estado <> 'autorizada' then return; end if;
  if n.ambiente = 'simulado' then
    update nfce_notas set estado = 'cancelada', cancelada_em = now(), cancelar_pedido = false, atualizado_em = now() where id = p_id; return;
  end if;
  if n.emitida_em is null or now() - n.emitida_em > interval '28 minutes' then
    update nfce_notas set cancelar_manual = true, cancelar_pedido = false, atualizado_em = now(),
      erro_pt = 'Venda cancelada depois de 30 minutos da emissão: o cancelamento da nota precisa ser orientado pelo contador.' where id = p_id;
    perform public._integ_log('nfce', 'aviso', 'Venda cancelada fora do prazo da nota (' || n.ref || '): cancelar com o contador');
    return;
  end if;
  v_j := btrim(coalesce(p_motivo, 'Venda cancelada'));
  if length(v_j) < 15 then v_j := v_j || ' (cancelada no sistema)'; end if;
  update nfce_notas set estado = 'cancelando', cancelamento_motivo = left(v_j, 255), tentativas = 0, cancelar_pedido = false, proxima_tentativa = now(), emitir_apos = now(), trava_ate = null, atualizado_em = now() where id = p_id;
end $f$;

-- GATILHO: venda cancelada → cuida da nota. Nunca atrapalha o cancelamento da venda.
create or replace function public._nfce_trg_cancelada() returns trigger
 language plpgsql security definer set search_path to 'public' as $f$
declare n nfce_notas%rowtype;
begin
  if not public._integracao_ligada('nfce') then return null; end if;
  begin
    if new.status::text <> 'Cancelada' or old.status::text = 'Cancelada' then return null; end if;
    select * into n from nfce_notas where venda_id = new.id for update;
    if not found then return null; end if;
    if n.estado in ('pendente', 'pendencia', 'rejeitada', 'erro', 'dispensada') then
      update nfce_notas set estado = 'dispensada', erro_pt = 'Venda cancelada antes da emissão: não há nota.', atualizado_em = now() where id = n.id;
    elsif n.estado in ('duvida', 'contingencia', 'emitindo') then
      update nfce_notas set cancelar_pedido = true, atualizado_em = now() where id = n.id;     -- quando a Focus confirmar a autorização, cancela em seguida
    elsif n.estado = 'autorizada' then
      perform public._nfce_iniciar_cancelamento(n.id, 'Venda cancelada: ' || coalesce(nullif(btrim(new.motivo_cancelamento), ''), 'erro de operação'));
    end if;
  exception when others then
    perform public._integ_log('nfce', 'erro', 'Não consegui tratar a nota da venda cancelada ' || coalesce(new.numero_pedido::text, '?') || ': ' || sqlerrm);
  end;
  return null;
end $f$;
drop trigger if exists trg_nfce_cancelada on public.vendas;
create trigger trg_nfce_cancelada after update of status on public.vendas for each row execute function public._nfce_trg_cancelada();

create or replace function public.nfce_pegar_pendentes(p_limite int default 5) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r jsonb;
begin
  with c as (select id from nfce_notas where estado in ('pendente', 'duvida', 'contingencia', 'cancelando') and emitir_apos <= now() and proxima_tentativa <= now() and (trava_ate is null or trava_ate < now())
               order by id limit greatest(1, least(coalesce(p_limite, 5), 20)) for update skip locked),
  u as (update nfce_notas n set trava_ate = now() + interval '2 minutes', atualizado_em = now() from c where n.id = c.id returning n.id, n.ref, n.venda_id, n.ambiente, n.estado, n.tentativas, n.cancelamento_motivo)
  select coalesce(jsonb_agg(to_jsonb(u)), '[]'::jsonb) into r from u;
  return r;
end $f$;

create or replace function public.nfce_resultado(p_id bigint, p_res jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare n nfce_notas%rowtype; v_r text := p_res->>'resultado'; v_msg text := left(coalesce(p_res->>'mensagem', ''), 600); v_tent int;
begin
  select * into n from nfce_notas where id = p_id for update;
  if not found then return jsonb_build_object('ok', false); end if;
  if n.estado in ('autorizada', 'cancelada') and v_r <> 'autorizada' then return jsonb_build_object('ok', true, 'ignorado', true); end if;
  if v_r = 'autorizada' then
    update nfce_notas set estado = 'autorizada', numero = nullif(p_res->>'numero', '')::int, serie = nullif(p_res->>'serie', '')::int, chave = p_res->>'chave', protocolo = p_res->>'protocolo',
      url_danfe = p_res->>'urlDanfe', url_xml = p_res->>'urlXml', url_consulta = p_res->>'urlConsulta', status_sefaz = p_res->>'statusSefaz', mensagem = v_msg, erro_pt = null,
      emitida_em = coalesce(emitida_em, now()), trava_ate = null, atualizado_em = now(), tentativas = tentativas + 1 where id = p_id;
    perform public._integ_log('nfce', 'info', 'Nota ' || coalesce(p_res->>'numero', '?') || ' autorizada (venda ' || n.ref || ')');
    if n.cancelar_pedido then perform public._nfce_iniciar_cancelamento(p_id, 'Venda cancelada no sistema'); end if;
  elsif v_r = 'rejeitada' then
    update nfce_notas set estado = 'rejeitada', status_sefaz = p_res->>'statusSefaz', mensagem = v_msg, erro_pt = public._nfce_traduzir(v_msg), trava_ate = null, atualizado_em = now(), tentativas = tentativas + 1 where id = p_id;
    perform public._integ_log('nfce', 'erro', 'Nota rejeitada (venda ' || n.ref || '): ' || left(v_msg, 200));
  elsif v_r = 'pendencia' then
    update nfce_notas set estado = 'pendencia', erro_pt = left(coalesce(p_res->>'motivo', 'Pendência'), 300), trava_ate = null, atualizado_em = now() where id = p_id;
    perform public._integ_log('nfce', 'aviso', 'Nota parada (venda ' || n.ref || '): ' || left(coalesce(p_res->>'motivo', ''), 200));
  elsif v_r = 'dispensada' then
    update nfce_notas set estado = 'dispensada', erro_pt = left(coalesce(p_res->>'motivo', ''), 300), trava_ate = null, atualizado_em = now() where id = p_id;
  elsif v_r = 'cancelada' then
    update nfce_notas set estado = 'cancelada', cancelada_em = coalesce(cancelada_em, now()), mensagem = v_msg, erro_pt = null, cancelar_manual = false, trava_ate = null, atualizado_em = now() where id = p_id;
    perform public._integ_log('nfce', 'info', 'Nota cancelada (venda ' || n.ref || ')');
  elsif v_r = 'cancelamento_recusado' then
    update nfce_notas set estado = 'autorizada', cancelar_manual = true, mensagem = v_msg, trava_ate = null, atualizado_em = now(),
      erro_pt = 'A Sefaz/Focus não aceitou o cancelamento da nota (' || left(v_msg, 160) || '). O contador precisa orientar o procedimento.' where id = p_id;
    perform public._integ_log('nfce', 'erro', 'Cancelamento recusado (venda ' || n.ref || '): ' || left(v_msg, 200));
  elsif v_r = 'contingencia' then
    update nfce_notas set estado = 'contingencia', numero = nullif(p_res->>'numero', '')::int, serie = nullif(p_res->>'serie', '')::int, chave = p_res->>'chave', mensagem = v_msg,
      proxima_tentativa = now() + interval '3 minutes', trava_ate = null, atualizado_em = now() where id = p_id;
  elsif n.estado = 'cancelando' then   -- dúvida ao cancelar: tenta de novo (consultando antes); depois de 6 tentativas vira pendência manual
    v_tent := n.tentativas + 1;
    update nfce_notas set tentativas = v_tent, mensagem = v_msg, proxima_tentativa = now() + make_interval(mins => least(power(2, least(v_tent, 4))::int, 15)), trava_ate = null, atualizado_em = now(),
      estado = case when v_tent >= 6 then 'autorizada' else 'cancelando' end,
      cancelar_manual = (v_tent >= 6), erro_pt = case when v_tent >= 6 then 'Não consegui cancelar a nota automaticamente. O contador precisa orientar.' else erro_pt end where id = p_id;
  else   -- 'duvida' (rede/timeout/5xx/ainda processando): nunca reenvia às cegas; da próxima vez consulta primeiro
    v_tent := n.tentativas + 1;
    update nfce_notas set estado = case when v_tent >= 8 then 'erro' else 'duvida' end, tentativas = v_tent, mensagem = v_msg,
      erro_pt = case when v_tent >= 8 then 'Não consegui falar com a Focus/Sefaz depois de várias tentativas. Veja o registro e use "Reemitir".' else null end,
      proxima_tentativa = now() + make_interval(mins => least(power(2, least(v_tent, 5))::int, 30)), trava_ate = null, atualizado_em = now() where id = p_id;
    if v_tent >= 8 then perform public._integ_log('nfce', 'erro', 'Nota parada por erro de comunicação (venda ' || n.ref || ')'); end if;
  end if;
  return jsonb_build_object('ok', true);
end $f$;

-- ---------- inutilização de numeração ----------
create table if not exists public.nfce_inutilizacoes (
  id bigserial primary key, serie int not null, numero_ini int not null, numero_fim int not null check (numero_fim >= numero_ini),
  justificativa text not null check (length(justificativa) between 15 and 255), ambiente text not null check (ambiente in ('homologacao', 'producao')),
  estado text not null default 'pendente' check (estado in ('pendente', 'feita', 'recusada', 'duvida')), resposta text, por text,
  criado_em timestamptz not null default now(), feito_em timestamptz, trava_ate timestamptz, tentativas int not null default 0
);
alter table public.nfce_inutilizacoes enable row level security;

create or replace function public.nfce_inutilizacoes_pendentes() returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r jsonb;
begin
  with c as (select id from nfce_inutilizacoes where estado in ('pendente', 'duvida') and (trava_ate is null or trava_ate < now()) order by id limit 3 for update skip locked),
  u as (update nfce_inutilizacoes i set trava_ate = now() + interval '2 minutes' from c where i.id = c.id returning i.id, i.serie, i.numero_ini, i.numero_fim, i.justificativa, i.ambiente)
  select coalesce(jsonb_agg(to_jsonb(u)), '[]'::jsonb) into r from u;
  return r;
end $f$;

create or replace function public.nfce_inutilizacao_resultado(p_id bigint, p_estado text, p_msg text) returns void
 language plpgsql security definer set search_path to 'public' as $f$
begin
  update nfce_inutilizacoes set estado = case when p_estado in ('feita', 'recusada') then p_estado else case when tentativas + 1 >= 6 then 'recusada' else 'duvida' end end,
    resposta = left(coalesce(p_msg, ''), 400), feito_em = case when p_estado = 'feita' then now() else feito_em end, tentativas = tentativas + 1, trava_ate = null where id = p_id;
  perform public._integ_log('nfce', case when p_estado = 'feita' then 'info' else 'aviso' end, 'Inutilização ' || p_estado || ': ' || left(coalesce(p_msg, ''), 150));
end $f$;

-- ---------- telas ----------
-- conferência: vendas que deveriam ter nota e não têm, notas com problema, numeração pulada
create or replace function public.api_nfce_conferencia(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare c integracoes_config%rowtype; v_dias int := least(coalesce(nullif(p->>'dias', '')::int, 30), 120); v_quando text; v_canais jsonb;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into c from integracoes_config where provedor = 'nfce';
  v_quando := coalesce(c.config->>'emitirQuando', 'pagamento'); v_canais := coalesce(c.config->'canais', '["balcao"]'::jsonb);
  return jsonb_build_object('ok', true, 'ligado', c.ligado, 'modo', c.modo, 'dias', v_dias,
    'semNota', coalesce((select jsonb_agg(jsonb_build_object('vendaId', v.id, 'pedido', v.numero_pedido, 'cliente', v.cliente_nome, 'quando', v.data_hora, 'valor', v.valor_total) order by v.data_hora desc)
       from (select * from vendas v where v.status::text = 'Confirmada' and v.data_hora > now() - make_interval(days => v_dias) and (c.ligado_em is null or v.data_hora >= c.ligado_em)
               and v_canais ? public._nfce_canal_da_venda(v.origem::text, v.tipo::text, v.canal)
               and case when v_quando = 'entrega' then v.status_pedido::text in ('Entregue', 'Retirada', 'Servida') else v.status_pagamento::text = 'Pago' end
               and v.valor_total > 0 and not exists (select 1 from nfce_notas n where n.venda_id = v.id) order by v.data_hora desc limit 100) v), '[]'::jsonb),
    'comProblema', (select count(*) from nfce_notas where estado in ('rejeitada', 'pendencia', 'erro') and criado_em > now() - make_interval(days => v_dias)),
    'cancelarManual', coalesce((select jsonb_agg(jsonb_build_object('id', n.id, 'pedido', v.numero_pedido, 'numero', n.numero, 'motivo', n.erro_pt)) from nfce_notas n left join vendas v on v.id = n.venda_id where n.cancelar_manual), '[]'::jsonb),
    'buracos', coalesce((select jsonb_agg(jsonb_build_object('serie', g.serie, 'ini', g.ini, 'fim', g.fim) order by g.serie, g.ini) from (
        select x.serie, x.numero + 1 ini, x.prox - 1 fim from (select serie, numero, lead(numero) over (partition by serie order by numero) prox
          from (select distinct serie, numero from nfce_notas where ambiente = c.modo and numero is not null and estado in ('autorizada', 'cancelada')) t) x
        where x.prox is not null and x.prox - x.numero > 1
          and not exists (select 1 from nfce_inutilizacoes i where i.serie = x.serie and i.ambiente = c.modo and i.estado in ('feita', 'pendente', 'duvida') and i.numero_ini <= x.numero + 1 and i.numero_fim >= x.prox - 1)) g), '[]'::jsonb),
    'inutilizacoes', coalesce((select jsonb_agg(jsonb_build_object('serie', i.serie, 'ini', i.numero_ini, 'fim', i.numero_fim, 'estado', i.estado, 'em', i.criado_em) order by i.id desc) from (select * from nfce_inutilizacoes order by id desc limit 10) i), '[]'::jsonb),
    'totais', jsonb_build_object(
      'vendas', (select coalesce(sum(v.valor_total), 0) from vendas v where v.status::text = 'Confirmada' and v.data_hora > now() - make_interval(days => v_dias) and (c.ligado_em is null or v.data_hora >= c.ligado_em) and v_canais ? public._nfce_canal_da_venda(v.origem::text, v.tipo::text, v.canal)),
      'notas', (select coalesce(sum(valor), 0) from nfce_notas where estado = 'autorizada' and ambiente <> 'simulado' and criado_em > now() - make_interval(days => v_dias))));
end $f$;

create or replace function public.api_nfce_inutilizar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_ini int := (p->>'ini')::int; v_fim int := (p->>'fim')::int; v_serie int := coalesce(nullif(p->>'serie', '')::int, 1); v_j text := btrim(coalesce(p->>'justificativa', '')); v_modo text; v_uid text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  v_uid := _exige_admin(p->>'senhaAdmin');
  if coalesce(p->>'senhaAdmin', '') = '' or v_uid is null then return _falha('Senha de administrador incorreta.'); end if;
  select modo into v_modo from integracoes_config where provedor = 'nfce';
  if v_ini is null or v_fim is null or v_fim < v_ini or v_fim - v_ini > 50 then return _falha('Faixa de números inválida.'); end if;
  if length(v_j) < 15 then v_j := 'Numeração pulada por falha de emissão'; end if;
  if exists (select 1 from nfce_notas where serie = v_serie and numero between v_ini and v_fim and ambiente = v_modo and estado in ('autorizada', 'cancelada')) then return _falha('Algum desses números já foi usado por uma nota.'); end if;
  insert into nfce_inutilizacoes (serie, numero_ini, numero_fim, justificativa, ambiente, por) values (v_serie, v_ini, v_fim, left(v_j, 255), v_modo, v_uid);
  perform _auditar('Nota fiscal: inutilização pedida', v_serie || ' · ' || v_ini || '-' || v_fim);
  perform public.chamar_edge('nfce-emitir', '{}'::jsonb);
  return api_nfce_conferencia('{}') || jsonb_build_object('message', 'Inutilização enviada. Atualize em instantes.');
end $f$;

-- pacote do contador: dados do mês (a Focus também baixa o conjunto de XML do mês no painel dela)
create or replace function public.api_nfce_pacote(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_ano int := coalesce(nullif(p->>'ano', '')::int, extract(year from now() at time zone 'America/Sao_Paulo')::int); v_mes int := coalesce(nullif(p->>'mes', '')::int, extract(month from now() at time zone 'America/Sao_Paulo')::int);
  v_ini timestamptz; v_fim timestamptz; v_modo text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_mes not between 1 and 12 or v_ano not between 2024 and 2100 then return _falha('Mês inválido.'); end if;
  v_ini := make_timestamptz(v_ano, v_mes, 1, 0, 0, 0, 'America/Sao_Paulo'); v_fim := v_ini + interval '1 month';
  select modo into v_modo from integracoes_config where provedor = 'nfce';
  return jsonb_build_object('ok', true, 'ano', v_ano, 'mes', v_mes, 'ambiente', v_modo,
    'notas', coalesce((select jsonb_agg(jsonb_build_object('pedido', v.numero_pedido, 'emitidaEm', n.emitida_em, 'numero', n.numero, 'serie', n.serie, 'chave', n.chave, 'valor', n.valor, 'estado', n.estado,
        'canceladaEm', n.cancelada_em, 'comCpf', n.cpf is not null, 'xml', n.url_xml, 'danfe', n.url_danfe) order by n.numero)
      from nfce_notas n left join vendas v on v.id = n.venda_id where n.ambiente = v_modo and n.estado in ('autorizada', 'cancelada') and n.emitida_em >= v_ini and n.emitida_em < v_fim), '[]'::jsonb),
    'inutilizacoes', coalesce((select jsonb_agg(jsonb_build_object('serie', serie, 'ini', numero_ini, 'fim', numero_fim, 'estado', estado, 'em', criado_em)) from nfce_inutilizacoes where ambiente = v_modo and criado_em >= v_ini and criado_em < v_fim), '[]'::jsonb));
end $f$;

-- saúde: acrescenta o aviso do limite do plano (80% de 500 notas) e o cancelamento pendente
create or replace function public._saude_nfce() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare r record; v_rej int; v_pend int; v_atras int; v_cont int; v_man int; v_mes int; v_nivel text; v_txt text;
begin
  select * into r from integracoes_config where ligado and provedor = 'nfce';
  if not found then return '[]'::jsonb; end if;
  select count(*) filter (where estado in ('rejeitada', 'erro')), count(*) filter (where estado = 'pendencia'), count(*) filter (where estado in ('pendente', 'duvida', 'cancelando') and emitir_apos < now() - interval '10 minutes'),
         count(*) filter (where estado = 'contingencia'), count(*) filter (where cancelar_manual)
    into v_rej, v_pend, v_atras, v_cont, v_man from nfce_notas where criado_em > now() - interval '7 days' or cancelar_manual;
  select count(*) into v_mes from nfce_notas where estado in ('autorizada', 'cancelada') and ambiente = 'producao' and emitida_em >= date_trunc('month', now() at time zone 'America/Sao_Paulo') at time zone 'America/Sao_Paulo';
  v_nivel := case when v_atras > 0 or v_rej > 0 then 'problema' when v_pend > 0 or v_cont > 0 or v_man > 0 or v_mes >= 400 or public._fiscal_sem_perfil_qtd() > 0 then 'atencao' else 'ok' end;
  v_txt := 'Nota fiscal ligada (' || case when r.modo = 'producao' then 'produção' else 'teste' end || ')'
    || case when v_rej > 0 then ' · ' || v_rej || ' nota(s) rejeitada(s)/com erro' else '' end
    || case when v_atras > 0 then ' · ' || v_atras || ' nota(s) esperando há mais de 10 min' else '' end
    || case when v_pend > 0 then ' · ' || v_pend || ' parada(s) por pendência (ex.: item sem perfil)' else '' end
    || case when v_cont > 0 then ' · ' || v_cont || ' em contingência' else '' end
    || case when v_man > 0 then ' · ' || v_man || ' cancelamento(s) para o contador orientar' else '' end
    || case when v_mes >= 400 then ' · ' || v_mes || ' de 500 notas do plano usadas neste mês' else '' end
    || case when public._fiscal_sem_perfil_qtd() > 0 then ' · ' || public._fiscal_sem_perfil_qtd() || ' item(ns) sem perfil fiscal' else '' end;
  return jsonb_build_array(jsonb_build_object('id', 'nfce', 'titulo', 'Nota fiscal (NFC-e)', 'nivel', v_nivel, 'texto', v_txt));
end $f$;

-- api_nfce_lista passa a mostrar também quem precisa de cancelamento manual
create or replace function public.api_nfce_lista(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_est text := nullif(p->>'estado', ''); v_lim int := least(coalesce(nullif(p->>'limite', '')::int, 60), 200);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'contagem', coalesce((select jsonb_object_agg(estado, q) from (select estado, count(*) q from nfce_notas where criado_em > now() - interval '30 days' group by 1) x), '{}'::jsonb),
    'mes', (select count(*) from nfce_notas where estado in ('autorizada', 'cancelada') and ambiente = 'producao' and emitida_em >= date_trunc('month', now() at time zone 'America/Sao_Paulo') at time zone 'America/Sao_Paulo'),
    'itens', coalesce((select jsonb_agg(jsonb_build_object('id', n.id, 'vendaId', n.venda_id, 'pedido', v.numero_pedido, 'cliente', v.cliente_nome, 'quando', v.data_hora, 'estado', n.estado, 'ambiente', n.ambiente,
        'numero', n.numero, 'serie', n.serie, 'valor', n.valor, 'erro', n.erro_pt, 'danfe', n.url_danfe, 'xml', n.url_xml, 'consulta', n.url_consulta, 'cpf', (n.cpf is not null), 'tentativas', n.tentativas,
        'emitidaEm', n.emitida_em, 'canceladaEm', n.cancelada_em, 'cancelarManual', n.cancelar_manual) order by n.id desc)
      from (select * from nfce_notas where (v_est is null or estado = v_est) order by id desc limit v_lim) n left join vendas v on v.id = n.venda_id), '[]'::jsonb));
end $f$;

-- cron: inclui "cancelando" e inutilizações
do $c$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.schedule('nfce-emitir-minuto', '* * * * *', $j$select case when public._integracao_ligada('nfce') and (exists (select 1 from public.nfce_notas where estado in ('pendente', 'duvida', 'contingencia', 'cancelando') and emitir_apos <= now() and proxima_tentativa <= now()) or exists (select 1 from public.nfce_inutilizacoes where estado in ('pendente', 'duvida'))) then public.chamar_edge('nfce-emitir', '{}'::jsonb) end$j$);
  end if;
end $c$;

-- ---------- permissões ----------
revoke execute on function public._nfce_iniciar_cancelamento(bigint, text), public._nfce_trg_cancelada(), public.nfce_pegar_pendentes(int), public.nfce_resultado(bigint, jsonb),
  public.nfce_inutilizacoes_pendentes(), public.nfce_inutilizacao_resultado(bigint, text, text), public._saude_nfce() from public, anon, authenticated;
grant execute on function public.nfce_pegar_pendentes(int), public.nfce_resultado(bigint, jsonb), public.nfce_inutilizacoes_pendentes(), public.nfce_inutilizacao_resultado(bigint, text, text) to service_role;
revoke execute on function public.api_nfce_conferencia(jsonb), public.api_nfce_inutilizar(jsonb), public.api_nfce_pacote(jsonb), public.api_nfce_lista(jsonb) from public, anon;
grant execute on function public.api_nfce_conferencia(jsonb), public.api_nfce_inutilizar(jsonb), public.api_nfce_pacote(jsonb), public.api_nfce_lista(jsonb) to authenticated;

insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-108-nfce-fechamento','Nota fiscal: cancelamento, numeração pulada, conferência e pacote do contador','nota fiscal nfc-e cancelar cancelamento inutilizar inutilização conferência vendas sem nota pacote contador limite plano 500',
 E'Cancelamento: se você cancela uma venda que já tem nota, o sistema cancela a nota sozinho desde que sejam menos de 30 minutos da emissão. Passou do prazo, a nota fica marcada "cancelamento para o contador orientar" (nada é apagado) e aparece na Saúde do sistema.
Conferência (Integrações → Nota fiscal → Conferência): lista as vendas que deveriam ter nota e não têm (com botão Emitir), notas com problema e números pulados. Para número pulado, toque em Inutilizar (pede sua senha) e informe o motivo.
Pacote do contador: escolha o mês e baixe a planilha com número, série, chave, valor e situação de cada nota, mais a lista de links dos XML. A Focus também baixa todos os XML do mês no painel dela.
Limite do plano: a tela mostra quantas notas já foram emitidas no mês (plano de 500); a 80% aparece um aviso na Saúde do sistema.',
 array['Admin'],true,'lista',108,'Só Administrador.'
where not exists (select 1 from ai_ajuda where slug='man-admin-108-nfce-fechamento');
