-- v1.0 — Fechar o cardápio (manual e por período) + Dados do restaurante
-- Rode UMA vez num banco que já existe. Mesa por QR Code não é bloqueada (pedido feito dentro do restaurante).

CREATE OR REPLACE FUNCTION public._cardapio_bloqueio()
 RETURNS text
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare m jsonb; per jsonb; e jsonb; hoje date := (now() at time zone 'America/Sao_Paulo')::date;
begin
  -- fechamento manual (chave ligada) e períodos programados (férias, manutenção); devolve a mensagem ao cliente ou null se está liberado
  select valor into m from sistema where chave = 'CardapioFechadoManual';
  if m is not null and jsonb_typeof(m) = 'object' and coalesce(m->>'ativo', 'false') = 'true' then
    return coalesce(nullif(btrim(m->>'mensagem'), ''), 'Estamos fechados no momento. Voltamos em breve!');
  end if;
  select valor into per from sistema where chave = 'CardapioPeriodosFechado';
  if per is not null and jsonb_typeof(per) = 'array' then
    for e in select value from jsonb_array_elements(per) loop
      begin
        if hoje between (e->>'inicio')::date and (e->>'fim')::date then
          return coalesce(nullif(btrim(e->>'mensagem'), ''), 'Estamos fechados neste período. Voltamos em breve!');
        end if;
      exception when others then null;
      end;
    end loop;
  end if;
  return null;
end $function$
;

revoke all on function public._cardapio_bloqueio() from public; grant execute on function public._cardapio_bloqueio() to anon, authenticated; -- a view v_cardapio_status (pública) usa esta função

CREATE OR REPLACE FUNCTION public.api_salvar_cardapio_fechamento(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_ativo boolean := coalesce(p->>'manualAtivo', 'false') = 'true'; v_msg text := left(btrim(coalesce(p->>'manualMensagem', '')), 150);
        v_per jsonb := '[]'::jsonb; e jsonb; v_ini date; v_fim date; v_m text; v_antes jsonb; v_n int := 0;
begin
  if not tem_nivel('Admin','Operador') then return _negado(); end if;
  if p ? 'periodos' and jsonb_typeof(p->'periodos') <> 'array' then return _falha('Lista de períodos inválida.'); end if;
  if p ? 'periodos' then
    for e in select value from jsonb_array_elements(p->'periodos') loop
      v_n := v_n + 1;
      if v_n > 30 then return _falha('No máximo 30 períodos.'); end if;
      begin v_ini := (e->>'inicio')::date; v_fim := (e->>'fim')::date;
      exception when others then return _falha('Data inválida em um dos períodos.'); end;
      if v_ini is null or v_fim is null then return _falha('Informe início e fim de cada período.'); end if;
      if v_fim < v_ini then return _falha('O fim do período não pode ser antes do início.'); end if;
      if v_fim - v_ini > 400 then return _falha('Um período não pode passar de 400 dias.'); end if;
      v_m := left(btrim(coalesce(e->>'mensagem', '')), 150);
      v_per := v_per || jsonb_build_array(jsonb_build_object('inicio', v_ini, 'fim', v_fim, 'mensagem', v_m));
    end loop;
    if tem_nivel('Operador') and not tem_nivel('Admin') then
      select valor into v_antes from sistema where chave = 'CardapioPeriodosFechado';
      if coalesce(v_antes, '[]'::jsonb) <> v_per then return _falha('Só o administrador altera os períodos programados.'); end if;
    end if;
    perform _cfg_gravar('CardapioPeriodosFechado', v_per);
  end if;
  perform _cfg_gravar('CardapioFechadoManual', jsonb_build_object('ativo', v_ativo, 'mensagem', v_msg));
  perform _auditar('Fechamento do cardápio atualizado', (case when v_ativo then 'Fechado manualmente' else 'Aberto (sem fechamento manual)' end) || ' | períodos: ' || jsonb_array_length(v_per));
  return jsonb_build_object('ok', true, 'message', case when v_ativo then 'Cardápio fechado. Os clientes veem a mensagem e não conseguem pedir.' else 'Salvo.' end);
end $function$
;

grant execute on function public.api_salvar_cardapio_fechamento(jsonb) to authenticated;

CREATE OR REPLACE FUNCTION public.api_salvar_dados_restaurante(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare k text; chaves text[] := array['nome','endereco','telefone','horario','redes']; lim int[] := array[60,200,30,300,300]; i int; v text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  for i in 1..5 loop
    k := chaves[i];
    v := btrim(coalesce(p->>k, ''));
    if length(v) > lim[i] then return _falha('O campo "' || k || '" passou de ' || lim[i] || ' caracteres.'); end if;
    perform _cfg_gravar('Restaurante' || initcap(k), to_jsonb(v));
  end loop;
  perform _auditar('Dados do restaurante atualizados');
  return jsonb_build_object('ok', true, 'message', 'Dados do restaurante salvos.');
end $function$
;

grant execute on function public.api_salvar_dados_restaurante(jsonb) to authenticated;

create or replace view public.v_cardapio_status as
 SELECT (EXISTS ( SELECT 1 FROM caixa_sessoes WHERE caixa_sessoes.status = 'Aberto'::status_caixa)) AS caixa_aberto,
    _cardapio_bloqueio() AS cardapio_bloqueio;

create or replace view public.v_cardapio_config as
 SELECT chave, valor FROM sistema
  WHERE chave = ANY (ARRAY['CardapioKicker','CardapioFrase','CardapioTempoRetirada','CardapioTempoMesa','CardapioTempoEntrega','TaxaEntregaPadrao','MANUTENCAO','RestauranteNome','RestauranteEndereco','RestauranteTelefone','RestauranteHorario','RestauranteRedes']);

-- pedido do cardápio público: recusa quando o cardápio está fechado (a função inteira, já com o acréscimo por forma de pagamento)
CREATE OR REPLACE FUNCTION public._criar_pedido_publico(p jsonb, p_mesa_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_eh_mesa boolean := p_mesa_id is not null; v_mesa mesas%rowtype;
  v_nome text := _texto_publico(p->>'clienteNome', 80);
  v_tel text := case when p_mesa_id is not null then '' else _texto_publico(p->>'clienteTelefone', 20) end;
  v_dig text := case when p_mesa_id is not null then '' else _so_digitos(p->>'clienteTelefone') end;
  v_obs_troco text := _texto_publico(p->>'observacaoTroco', 200);
  v_de jsonb := case when jsonb_typeof(p->'dadosEntrega') = 'object' then p->'dadosEntrega' else '{}'::jsonb end;
  v_end text := _texto_publico(v_de->>'endereco', 200); v_comp text := _texto_publico(v_de->>'complemento', 100); v_ref text := _texto_publico(v_de->>'referencia', 150);
  v_obs_ent text := _texto_publico(coalesce(nullif(p->>'observacoes', ''), v_de->>'observacoes'), 300);
  v_itens jsonb := p->'itens'; v_tipo_in text := p->>'tipoEntrega'; v_ip text := _ip_cliente();
  v_req text := nullif(left(btrim(coalesce(p->>'requisicaoId', '')), 80), '');
  v_forma formas_pagamento%rowtype; v_caixa uuid; v_tipo venda_tipo; v_ja record; v_prod produtos%rowtype; v_comb combos%rowtype;
  it record; r record; v_prod_id uuid; v_comb_id uuid; v_qtd numeric; v_preco numeric; v_custo_u numeric; v_nome_item text; v_extra numeric; v_n_ad int; v_n_ok int;
  v_ads text; v_obs_item text; v_ads_ids jsonb; v_itens_ok jsonb := '[]'::jsonb; v_orig numeric := 0; v_custo numeric := 0;
  v_cod text := ''; v_cup jsonb; v_desc numeric := 0; v_frete boolean := false; v_taxa numeric := 0; v_pad numeric; v_total numeric;
  v_venda uuid := gen_random_uuid(); v_numero int; v_cli uuid; v_chave text; v_obs_final text; v_bloqueia boolean; v_forma_nome text; v_acr numeric := 0; v_bloq text;
begin
  -- repetição do mesmo envio (duplo toque, nova tentativa): devolve o pedido já criado, sem criar outro
  if v_req is not null then
    perform pg_advisory_xact_lock(hashtext('venda:' || v_req));
    select id, numero_pedido, valor_total into v_ja from vendas where requisicao_id = v_req;
    if found then
      return jsonb_build_object('ok', true, 'duplicado', true, 'id', v_ja.id, 'numero', v_ja.numero_pedido, 'valorTotal', v_ja.valor_total, 'message', 'Pedido já recebido — envio repetido ignorado.');
    end if;
  end if;

  if jsonb_typeof(v_itens) <> 'array' or jsonb_array_length(v_itens) = 0 then return _falha('Carrinho vazio.'); end if;
  if jsonb_array_length(v_itens) > 40 then return _falha('Carrinho grande demais.'); end if;
  if v_eh_mesa then
    if v_nome = '' then return _falha('Informe o seu nome.'); end if;
    v_chave := 'pedmesa_' || p_mesa_id::text;
  else
    if v_nome = '' or v_dig = '' then return _falha('Informe nome e telefone.'); end if;
    if length(v_dig) < 10 or length(v_dig) > 13 then return _falha('Informe um telefone válido com DDD.'); end if;
    v_chave := 'pedcard_' || v_dig;
  end if;
  if _excedeu('pedcard_global', 150) then return _falha('Estamos com muitos pedidos no momento. Tente novamente em alguns minutos ou ligue para o restaurante.'); end if;
  if _excedeu('pedcard_ip_' || v_ip, 40) then return _falha('Muitos pedidos em sequência deste local. Aguarde alguns minutos.'); end if;
  if _excedeu(v_chave, case when v_eh_mesa then 8 else 5 end) then
    return _falha(case when v_eh_mesa then 'Muitos pedidos em sequência nesta mesa. Chame o garçom.' else 'Muitos pedidos em sequência. Aguarde alguns minutos.' end);
  end if;

  -- cardápio fechado à mão ou em período programado (pedido de mesa, feito dentro do restaurante, não é bloqueado)
  if not v_eh_mesa then
    v_bloq := _cardapio_bloqueio();
    if v_bloq is not null then return _falha(v_bloq); end if;
  end if;
  select id into v_caixa from caixa_sessoes where status = 'Aberto' limit 1;
  if v_caixa is null then return _falha('Estamos fechados no momento. Tente novamente mais tarde.'); end if;

  if v_eh_mesa then
    select * into v_mesa from mesas where id = p_mesa_id for update;
    if not found then return _falha('Mesa não encontrada.'); end if;
    if v_mesa.status::text not in ('Livre', 'Ocupada') then
      return _falha(case when v_mesa.status::text = 'Aguardando fechamento' then 'A conta desta mesa já foi pedida. Chame o garçom para novos pedidos.' else 'Esta mesa não está disponível para pedidos pelo celular. Chame o garçom.' end);
    end if;
    v_tipo := 'Mesa';
    -- mesa: o cliente não escolhe a forma; vale a primeira forma do cardápio só para o preço (o recebimento é feito no fechamento da conta)
    select * into v_forma from formas_pagamento where ativa and visivel_cardapio order by ordem limit 1;
    v_forma_nome := 'A Receber (Mesa)';
  else
    v_tipo := (case when v_tipo_in = 'Entrega' then 'Entrega' else 'Retirada' end)::venda_tipo;
    if v_tipo = 'Entrega' and v_end = '' then return _falha('Informe o endereço de entrega.'); end if;
    select * into v_forma from formas_pagamento where id = _uuid(p->>'formaPagamentoId') and ativa and visivel_cardapio;
    v_forma_nome := v_forma.nome;
  end if;
  if v_forma.id is null then return _falha('Forma de pagamento inválida.'); end if;

  -- itens: tudo vem do cadastro (produto/combo ativo, preço da forma escolhida, adicionais ativos e vinculados)
  for it in select value as e from jsonb_array_elements(v_itens) loop
    v_qtd := _num(it.e->>'quantidade');
    if v_qtd <= 0 then continue; end if;
    if v_qtd > 50 or v_qtd <> floor(v_qtd) then return _falha('Quantidade inválida no carrinho.'); end if;
    v_prod_id := _uuid(it.e->>'produtoId'); v_comb_id := _uuid(it.e->>'comboId');
    if (v_prod_id is null) = (v_comb_id is null) then return _falha('Item inválido no carrinho.'); end if;
    if jsonb_typeof(it.e->'adicionaisIds') = 'array' and jsonb_array_length(it.e->'adicionaisIds') > 20 then return _falha('Adicionais demais em um item.'); end if;
    if v_prod_id is not null then
      select * into v_prod from produtos where id = v_prod_id and ativo;
      if not found then return _falha('Um dos produtos não está mais disponível.'); end if;
      v_nome_item := v_prod.nome;
      select preco, custo into v_preco, v_custo_u from produto_precos where produto_id = v_prod_id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_nome_item || '" não tem preço configurado para essa forma de pagamento.'); end if;
    else
      select * into v_comb from combos where id = v_comb_id and ativo;
      if not found then return _falha('Um dos combos não está mais disponível.'); end if;
      if exists (select 1 from combo_itens ci join produtos pr on pr.id = ci.produto_id where ci.combo_id = v_comb_id and not pr.ativo) then
        return _falha('O combo "' || v_comb.nome || '" está temporariamente indisponível.');
      end if;
      v_nome_item := v_comb.nome;
      select preco, custo into v_preco, v_custo_u from combo_precos where combo_id = v_comb_id and forma_pagamento_id = v_forma.id limit 1;
      if not found then return _falha('"' || v_nome_item || '" não tem preço configurado para essa forma de pagamento.'); end if;
    end if;
    select count(*), coalesce(sum(a.preco), 0),
           count(a.id) filter (where a.ativo and ((v_prod_id is not null and exists (select 1 from produto_adicionais pa where pa.produto_id = v_prod_id and pa.adicional_id = a.id)) or (v_comb_id is not null and exists (select 1 from combo_itens ci join produto_adicionais pa on pa.produto_id = ci.produto_id where ci.combo_id = v_comb_id and pa.adicional_id = a.id)))),
           coalesce(string_agg(' + ' || a.nome, '' order by s.ord) filter (where a.id is not null), ''),
           coalesce(jsonb_agg(a.id order by s.ord) filter (where a.id is not null), '[]'::jsonb)
      into v_n_ad, v_extra, v_n_ok, v_ads, v_ads_ids
      from jsonb_array_elements_text(case when jsonb_typeof(it.e->'adicionaisIds') = 'array' then it.e->'adicionaisIds' else '[]'::jsonb end) with ordinality as s(x, ord)
      left join adicionais a on a.id = _uuid(s.x);
    if v_n_ad <> v_n_ok then return _falha('Um adicional escolhido para "' || v_nome_item || '" não está disponível.'); end if;
    v_obs_item := _texto_publico(it.e->>'observacao', 100);
    v_itens_ok := v_itens_ok || jsonb_build_array(jsonb_build_object('produtoId', v_prod_id, 'comboId', v_comb_id,
      'descricao', v_nome_item || v_ads || case when v_obs_item <> '' then ' — Obs: ' || v_obs_item else '' end,
      'quantidade', v_qtd, 'valorUnitario', v_preco + v_extra, 'custoUnitario', v_custo_u, 'adicionaisIds', v_ads_ids));
    v_orig := v_orig + round(v_qtd * (v_preco + v_extra), 2); v_custo := v_custo + v_qtd * v_custo_u;
  end loop;
  if jsonb_array_length(v_itens_ok) = 0 then return _falha('Carrinho vazio.'); end if;
  v_orig := round(v_orig, 2); v_custo := round(v_custo, 2);

  select coalesce((select (valor #>> '{}') = 'true' from sistema where chave = 'BLOQUEAR_ESTOQUE_NEGATIVO'), false) into v_bloqueia;
  if v_bloqueia then
    for r in select c.ingrediente_id, c.qtd, e.quantidade from _consumo(v_itens_ok) c join estoque e on e.id = c.ingrediente_id loop
      if r.quantidade + 0.000000001 < r.qtd then return _falha('Um dos itens do pedido acabou. Escolha outro item ou fale com o restaurante.'); end if;
    end loop;
  end if;

  -- cupom (só no cardápio comum; travado por código para dois pedidos simultâneos não estourarem o limite)
  if not v_eh_mesa then
    v_cod := upper(regexp_replace(btrim(coalesce(p->>'codigoCupom', '')), '\s+', '', 'g'));
    if v_cod <> '' then
      perform pg_advisory_xact_lock(hashtext('cupom:' || v_cod));
      v_cup := _cupom_calcular(v_cod, v_tel, v_orig, v_tipo::text);
      if coalesce(v_cup->>'ok', '') <> 'true' then return v_cup; end if;
      v_desc := (v_cup->>'desconto')::numeric; v_frete := (v_cup->>'freteGratis')::boolean;
    end if;
  end if;

  if v_tipo = 'Entrega' and not v_frete then
    select coalesce(_num(valor #>> '{}'), 0) into v_pad from sistema where chave = 'TaxaEntregaPadrao';
    v_taxa := coalesce(v_pad, 0);
  end if;
  v_total := greatest(0.01, round(v_orig - v_desc + v_taxa, 2));
  -- acréscimo da forma de pagamento escolhida (mesa: o acréscimo entra no fechamento da conta)
  if not v_eh_mesa then v_acr := _acrescimo_forma(v_forma, greatest(0.01, v_total - v_taxa)); v_total := round(v_total + v_acr, 2); end if;
  v_obs_final := coalesce(concat_ws(' — ', nullif(v_obs_ent, ''), nullif(v_obs_troco, '')), '');

  insert into vendas (id, cliente_nome, telefone_cliente, forma_pagamento, valor_total, custo_total, status, tipo, status_pedido,
                      endereco, complemento, referencia, observacoes_entrega, status_pagamento, valor_original, valor_desconto,
                      desconto_detalhe, origem, mesa_id, taxa_entrega, caixa_id, requisicao_id, acrescimo_forma)
  values (v_venda, v_nome, v_tel, v_forma_nome, v_total, v_custo, 'Confirmada', v_tipo, 'Recebido',
          case when v_tipo = 'Entrega' then v_end else '' end, case when v_tipo = 'Entrega' then v_comp else '' end, case when v_tipo = 'Entrega' then v_ref else '' end,
          v_obs_final, 'A Receber', v_orig, v_desc, case when v_cod <> '' then 'Cupom ' || (v_cup->>'codigo') else '' end, 'Cardápio',
          case when v_eh_mesa then p_mesa_id else null end, v_taxa, v_caixa, v_req, v_acr)
  returning numero_pedido into v_numero;

  insert into itens_venda (venda_id, produto_id, combo_id, descricao, quantidade, valor_unitario, custo_unitario, valor_total_item, adicionais_ids)
  select v_venda, _uuid(e->>'produtoId'), _uuid(e->>'comboId'), e->>'descricao', _num(e->>'quantidade', 1)::int, _num(e->>'valorUnitario'), _num(e->>'custoUnitario'),
         round(_num(e->>'quantidade', 1) * _num(e->>'valorUnitario'), 2),
         coalesce((select array_agg(_uuid(x)) filter (where _uuid(x) is not null) from jsonb_array_elements_text(e->'adicionaisIds') x), '{}')
  from jsonb_array_elements(v_itens_ok) e;

  insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo)
  values (v_venda, v_forma_nome, v_total, case when v_eh_mesa then 0 else round(v_total * v_forma.taxa_percentual / 100 + v_forma.taxa_fixa, 2) end, v_acr);

  if v_eh_mesa and v_mesa.status::text = 'Livre' then update mesas set status = 'Ocupada' where id = p_mesa_id; end if;
  perform _ajustar_estoque(v_itens_ok, 1, v_venda);
  if v_tel <> '' then v_cli := _upsert_cliente(v_tel, v_nome); end if;
  if v_cod <> '' then
    insert into cupons_usos (cupom_id, codigo, venda_id, cliente_id, telefone, desconto, frete_gratis, requisicao_id)
    values ((v_cup->>'cupomId')::uuid, v_cup->>'codigo', v_venda, v_cli, v_tel, v_desc, v_frete, v_req);
  end if;
  perform _registrar_falha(v_chave, 600); perform _registrar_falha('pedcard_global', 300); perform _registrar_falha('pedcard_ip_' || v_ip, 600);
  perform _auditar_publico(case when v_eh_mesa then 'Pedido recebido pelo cliente na mesa ' || v_mesa.numero else 'Pedido recebido pelo Cardápio' end,
    'Total R$ ' || _dinheiro(v_total) || case when v_cod <> '' then ' | Cupom ' || (v_cup->>'codigo') else '' end, case when v_eh_mesa then v_nome else v_tel end);

  return jsonb_build_object('ok', true, 'message', 'Pedido enviado! Nº ' || v_numero || '. Total: R$ ' || _dinheiro(v_total) || '.',
    'id', v_venda, 'numero', v_numero, 'valorTotal', v_total, 'valorOriginal', v_orig, 'acrescimo', v_acr, 'valorDesconto', v_desc,
    'cupom', case when v_cod <> '' then v_cup->>'codigo' else '' end, 'freteGratis', v_frete);
end $function$
;
