-- =====================================================================
-- FASE 2 — iFOOD OPERAÇÃO · 2026-10-11
-- Negociação de cancelamento (aceitar / recusar / propor alternativa), loja aberta/fechada/pausada no iFood,
-- abrir/fechar junto com o caixa, saúde da loja. Precisa das Fases 0 e 1 antes. Seguro para rodar de novo. TUDO DESLIGADO.
-- ⚠️ Os endereços e campos do iFood para negociação e loja vêm de fontes de terceiros: ainda não testado com o iFood de verdade.
-- =====================================================================

-- a fila de ações passa a aceitar também negociação e loja
alter table public.ifood_acoes drop constraint if exists ifood_acoes_acao_check;
alter table public.ifood_acoes add constraint ifood_acoes_acao_check check (acao in
  ('confirmar','iniciar_preparo','pronto','despachar','cancelar','negociacao_aceitar','negociacao_recusar','negociacao_alternativa','loja_fechar','loja_abrir','loja_pausar','loja_retomar'));

create table if not exists public.ifood_negociacoes (
  id text primary key,                         -- id da disputa no iFood
  pedido_ifood text not null, tipo text, motivo text,
  expira_em timestamptz, alternativas jsonb not null default '[]'::jsonb,
  estado text not null default 'aberta' check (estado in ('aberta','aceita','recusada','alternativa','encerrada','expirada')),
  bruto jsonb, criado_em timestamptz not null default now(), respondido_em timestamptz, resposta_por text);
create index if not exists ifood_negociacoes_abertas_idx on public.ifood_negociacoes (expira_em) where estado = 'aberta';
alter table public.ifood_negociacoes enable row level security;

create table if not exists public.ifood_loja (
  id boolean primary key default true check (id),
  situacao text,                                -- texto do iFood (ex.: OK, FECHADA)
  disponivel boolean, motivo text,
  pausada_ate timestamptz, interrupcao_id text, fechada_por_nos boolean not null default false,
  verificado_em timestamptz, bruto jsonb, atualizado_em timestamptz not null default now());
insert into public.ifood_loja (id) values (true) on conflict (id) do nothing;
alter table public.ifood_loja enable row level security;

-- ---------- evento de negociação (HANDSHAKE_DISPUTE) e fim (HANDSHAKE_SETTLEMENT) ----------
create or replace function public.ifood_negociacao_registrar(p_evento jsonb, p_pedido text) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare m jsonb := coalesce(p_evento->'metadata', '{}'::jsonb); v_id text := coalesce(nullif(m->>'disputeId', ''), nullif(m->>'handshakeId', ''), nullif(p_evento->>'id', ''));
        v_exp timestamptz; v_num text;
begin
  begin v_exp := nullif(coalesce(m->>'expiresAt', m->>'expirationDate'), '')::timestamptz; exception when others then v_exp := null; end;
  insert into ifood_negociacoes (id, pedido_ifood, tipo, motivo, expira_em, alternativas, bruto)
  values (v_id, p_pedido, coalesce(m->>'handshakeType', m->>'type'), left(coalesce(m->>'message', m->>'reason', m->>'handshakeGroup', ''), 300), coalesce(v_exp, now() + interval '5 minutes'),
          case when jsonb_typeof(m->'alternatives') = 'array' then m->'alternatives' else '[]'::jsonb end, p_evento)
  on conflict (id) do nothing;
  if found then
    select numero_ifood into v_num from ifood_pedidos where pedido_ifood = p_pedido;
    perform _push_enviar('pedido', '⚠️ iFood: cliente pediu cancelamento/reembolso #' || coalesce(v_num, ''), 'Responda no painel (Integrações → iFood) antes do prazo.', 'ifood-neg-' || v_id);
    perform _integ_log('ifood', 'aviso', 'Negociação de cancelamento no pedido #' || coalesce(v_num, p_pedido));
    perform _auditar('Negociação do iFood recebida', 'Pedido iFood #' || coalesce(v_num, p_pedido) || ' · ' || coalesce(m->>'handshakeType', ''));
  end if;
  return jsonb_build_object('ok', true);
end $f$;

create or replace function public.ifood_negociacao_fim(p_evento jsonb, p_pedido text) returns void
 language plpgsql security definer set search_path to 'public' as $f$
declare m jsonb := coalesce(p_evento->'metadata', '{}'::jsonb); v_id text := coalesce(nullif(m->>'disputeId', ''), nullif(m->>'handshakeId', ''));
begin
  update ifood_negociacoes set estado = case when estado = 'aberta' then 'encerrada' else estado end, respondido_em = coalesce(respondido_em, now())
   where (v_id is not null and id = v_id) or (v_id is null and pedido_ifood = p_pedido and estado = 'aberta');
end $f$;

-- ---------- loja ----------
create or replace function public.ifood_loja_gravar(p_status jsonb, p_interrupcao text default null) returns void
 language plpgsql security definer set search_path to 'public' as $f$
declare v_disp boolean; v_sit text;
begin
  v_sit := coalesce(p_status->0->>'state', p_status->>'state', p_status->>'status', '');
  v_disp := coalesce((p_status->0->>'available')::boolean, (p_status->>'available')::boolean, upper(v_sit) in ('OK', 'AVAILABLE', 'OPEN'));
  update ifood_loja set situacao = left(v_sit, 60), disponivel = v_disp,
    motivo = left(coalesce(p_status->0->'validations'->0->>'message', p_status->0->>'message', p_status->>'message', ''), 200),
    interrupcao_id = coalesce(p_interrupcao, interrupcao_id), verificado_em = now(), bruto = p_status, atualizado_em = now() where id;
end $f$;

create or replace function public.ifood_loja_estado() returns jsonb language sql stable security definer set search_path to 'public' as $f$
  select to_jsonb(l) from ifood_loja l where id
$f$;

-- pausa que venceu: volta sozinho a aceitar pedidos
create or replace function public.ifood_loja_verificar() returns jsonb language plpgsql security definer set search_path to 'public' as $f$
declare l ifood_loja%rowtype;
begin
  select * into l from ifood_loja where id;
  if l.pausada_ate is not null and l.pausada_ate < now() and not l.fechada_por_nos then
    update ifood_loja set pausada_ate = null where id;
    perform public._ifood_enfileirar('LOJA', 'loja_retomar', '{}'::jsonb);
  end if;
  update ifood_negociacoes set estado = 'expirada' where estado = 'aberta' and expira_em < now() - interval '2 minutes';
  return jsonb_build_object('ok', true);
end $f$;

-- abrir/fechar junto com o caixa (opcional, ajuste "abrirFecharComCaixa")
create or replace function public._ifood_trg_caixa() returns trigger language plpgsql security definer set search_path to 'public' as $f$
begin
  if not public._integracao_ligada('ifood') then return null; end if;
  if not coalesce((select (config->>'abrirFecharComCaixa')::boolean from integracoes_config where provedor = 'ifood'), false) then return null; end if;
  if tg_op = 'INSERT' and new.status::text = 'Aberto' then
    update ifood_loja set fechada_por_nos = false, pausada_ate = null where id;
    perform public._ifood_enfileirar('LOJA', 'loja_abrir', '{}'::jsonb);
  elsif tg_op = 'UPDATE' and old.status::text = 'Aberto' and new.status::text <> 'Aberto' then
    update ifood_loja set fechada_por_nos = true where id;
    perform public._ifood_enfileirar('LOJA', 'loja_fechar', '{}'::jsonb);
  end if;
  return null;
end $f$;
drop trigger if exists trg_ifood_caixa on public.caixa_sessoes;
create trigger trg_ifood_caixa after insert or update of status on public.caixa_sessoes for each row execute function public._ifood_trg_caixa();

-- ---------- telas do administrador ----------
create or replace function public.api_ifood_negociacoes(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'itens', coalesce((select jsonb_agg(jsonb_build_object('id', n.id, 'pedido', i.numero_ifood, 'tipo', n.tipo, 'motivo', n.motivo, 'expiraEm', n.expira_em,
      'segundos', greatest(0, round(extract(epoch from (n.expira_em - now())))), 'estado', n.estado, 'alternativas', n.alternativas, 'em', n.criado_em) order by n.criado_em desc)
    from (select * from ifood_negociacoes order by criado_em desc limit 15) n left join ifood_pedidos i on i.pedido_ifood = n.pedido_ifood), '[]'::jsonb));
end $f$;

create or replace function public.api_ifood_negociacao_responder(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare n ifood_negociacoes%rowtype; v_acao text := p->>'acao'; v_login text;
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  select * into n from ifood_negociacoes where id = p->>'id' for update;
  if not found then return _falha('Negociação não encontrada.'); end if;
  if n.estado <> 'aberta' then return _falha('Esta negociação já foi respondida ou encerrada.'); end if;
  if n.expira_em < now() then return _falha('O prazo para responder acabou; o iFood decide.'); end if;
  if v_acao not in ('aceitar', 'recusar', 'alternativa') then return _falha('Resposta inválida.'); end if;
  select login into v_login from usuarios where id = auth.uid();
  update ifood_negociacoes set estado = case v_acao when 'aceitar' then 'aceita' when 'recusar' then 'recusada' else 'alternativa' end, respondido_em = now(), resposta_por = v_login where id = n.id;
  perform public._ifood_enfileirar(n.pedido_ifood, 'negociacao_' || v_acao, jsonb_build_object('disputa', n.id, 'alternativaId', p->>'alternativaId', 'motivo', left(coalesce(p->>'motivo', ''), 200)));
  perform _auditar('Negociação do iFood respondida', 'Pedido ' || n.pedido_ifood || ' · ' || v_acao || ' por ' || coalesce(v_login, ''));
  return jsonb_build_object('ok', true, 'message', 'Resposta enviada ao iFood.') || api_ifood_negociacoes('{}');
end $f$;

create or replace function public.api_ifood_loja(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'loja', (select to_jsonb(l) - 'bruto' from ifood_loja l where id), 'ligado', _integracao_ligada('ifood'));
end $f$;

create or replace function public.api_ifood_loja_acao(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_acao text := p->>'acao'; v_min int := coalesce(nullif(p->>'minutos', '')::int, 30);
begin
  if not tem_nivel('Admin', 'Operador') then return _negado(); end if;
  if not _integracao_ligada('ifood') then return _falha('O iFood está desligado.'); end if;
  if v_acao = 'pausar' then
    if v_min < 5 or v_min > 480 then return _falha('Escolha entre 5 minutos e 8 horas.'); end if;
    update ifood_loja set pausada_ate = now() + make_interval(mins => v_min), fechada_por_nos = false where id;
    perform _ifood_enfileirar('LOJA', 'loja_pausar', jsonb_build_object('minutos', v_min));
  elsif v_acao = 'retomar' then
    update ifood_loja set pausada_ate = null, fechada_por_nos = false where id;
    perform _ifood_enfileirar('LOJA', 'loja_retomar', '{}'::jsonb);
  elsif v_acao = 'fechar' then
    update ifood_loja set fechada_por_nos = true where id;
    perform _ifood_enfileirar('LOJA', 'loja_fechar', '{}'::jsonb);
  elsif v_acao = 'abrir' then
    update ifood_loja set fechada_por_nos = false, pausada_ate = null where id;
    perform _ifood_enfileirar('LOJA', 'loja_abrir', '{}'::jsonb);
  else return _falha('Ação inválida.'); end if;
  perform _auditar('Loja no iFood', v_acao || case when v_acao = 'pausar' then ' ' || v_min || ' min' else '' end);
  return jsonb_build_object('ok', true, 'message', 'Pedido enviado ao iFood (confira o estado em instantes).') || api_ifood_loja('{}');
end $f$;

-- ---------- saúde: acrescenta loja e negociações ao item iFood ----------
create or replace function public._saude_ifood_extra() returns text language plpgsql stable security definer set search_path to 'public' as $f$
declare l ifood_loja%rowtype; v_neg int; v_urg int; v_txt text := '';
begin
  select * into l from ifood_loja where id;
  select count(*), count(*) filter (where expira_em < now() + interval '3 minutes') into v_neg, v_urg from ifood_negociacoes where estado = 'aberta' and expira_em > now();
  if l.verificado_em is not null then v_txt := v_txt || ' · loja: ' || case when l.disponivel then 'ABERTA no iFood' else 'FECHADA/indisponível no iFood' end || case when l.pausada_ate is not null then ' (pausada até ' || to_char(l.pausada_ate at time zone 'America/Sao_Paulo', 'HH24:MI') || ')' else '' end; end if;
  if v_neg > 0 then v_txt := v_txt || ' · ' || v_neg || ' negociação(ões) de cancelamento esperando resposta' || case when v_urg > 0 then ' (URGENTE)' else '' end; end if;
  return v_txt;
end $f$;

create or replace function public._saude_integracoes() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_desc int; e ifood_estado%rowtype; v_min numeric; v_sem int; v_novos int; v_acoes int; v_nivel text; v_txt text; v_urg int;
begin
  if exists (select 1 from ai_segredos where provedor = 'nvidia') or exists (select 1 from ai_segredos where provedor = 'cloudflare') then
    select count(*) into v_desc from unnest(array['nvidia', 'cloudflare']) x(p) where _ia_provedor_descansando(x.p);
    v := v || jsonb_build_object('id', 'ia_extras', 'titulo', 'IAs de reserva (NVIDIA / Cloudflare)', 'nivel', case when v_desc > 0 then 'atencao' else 'ok' end,
      'texto', (select string_agg(x.rot || ': ' || case when not exists (select 1 from ai_segredos where provedor = x.p) then 'sem chave' when _ia_provedor_descansando(x.p) then 'descansando (erros recentes)' else 'pronta' end, ' · ')
                from (values ('nvidia', 'NVIDIA'), ('cloudflare', 'Cloudflare')) x(p, rot)));
  end if;
  if _integracao_ligada('ifood') then
    select * into e from ifood_estado where id;
    v_min := case when e.ultima_consulta_ok is null then null else extract(epoch from (now() - e.ultima_consulta_ok)) / 60 end;
    select coalesce(sum(itens_sem_ligacao), 0) into v_sem from ifood_pedidos where estado <> 'cancelado' and criado_em > now() - interval '7 days';
    select count(*) into v_novos from ifood_pedidos where estado = 'novo' and not simulado and criado_em < now() - interval '4 minutes';
    select count(*) into v_acoes from ifood_acoes where estado in ('erro', 'duvida') and criado_em > now() - interval '1 day';
    select count(*) into v_urg from ifood_negociacoes where estado = 'aberta' and expira_em > now() and expira_em < now() + interval '3 minutes';
    v_nivel := case when v_min is null or v_min > 2 or e.token_ok is false or v_novos > 0 or v_urg > 0 then 'problema' when v_acoes > 0 or v_sem > 0 or e.ultimo_erro is not null or exists (select 1 from ifood_negociacoes where estado = 'aberta' and expira_em > now()) then 'atencao' else 'ok' end;
    v_txt := case when v_min is null then 'Ligado, mas ainda sem nenhuma consulta bem-sucedida ao iFood.' else 'Última consulta ao iFood há ' || round(v_min, 1) || ' min' end
      || case when e.ultimo_pedido_em is not null then ' · último pedido às ' || to_char(e.ultimo_pedido_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') else ' · nenhum pedido ainda' end
      || case when e.token_ok is false then ' · ACESSO RECUSADO (confira as chaves)' else '' end
      || case when v_novos > 0 then ' · ' || v_novos || ' pedido(s) esperando confirmação há mais de 4 min' else '' end
      || case when v_acoes > 0 then ' · ' || v_acoes || ' ação(ões) não confirmada(s) no iFood' else '' end
      || case when v_sem > 0 then ' · ' || v_sem || ' item(ns) sem ligação' else '' end || public._saude_ifood_extra();
    v := v || jsonb_build_object('id', 'ifood', 'titulo', 'iFood', 'nivel', v_nivel, 'texto', v_txt);
  end if;
  for r in select * from integracoes_config where ligado and provedor = 'nfce' loop
    v := v || jsonb_build_object('id', 'nfce', 'titulo', 'Nota fiscal (NFC-e)', 'nivel', 'atencao', 'texto', 'Ligada (' || r.modo || '), aguardando a primeira nota.');
  end loop;
  return v;
end $f$;

-- ---------- permissões ----------
revoke execute on function public.ifood_negociacao_registrar(jsonb, text), public.ifood_negociacao_fim(jsonb, text), public.ifood_loja_gravar(jsonb, text), public.ifood_loja_estado(), public.ifood_loja_verificar(),
  public._ifood_trg_caixa(), public._saude_ifood_extra() from public, anon, authenticated;
grant execute on function public.ifood_negociacao_registrar(jsonb, text), public.ifood_negociacao_fim(jsonb, text), public.ifood_loja_gravar(jsonb, text), public.ifood_loja_estado(), public.ifood_loja_verificar() to service_role;
revoke execute on function public.api_ifood_negociacoes(jsonb), public.api_ifood_negociacao_responder(jsonb), public.api_ifood_loja(jsonb), public.api_ifood_loja_acao(jsonb) from public, anon;
grant execute on function public.api_ifood_negociacoes(jsonb), public.api_ifood_negociacao_responder(jsonb), public.api_ifood_loja(jsonb), public.api_ifood_loja_acao(jsonb) to authenticated;

insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-104-ifood-operacao','iFood: negociação de cancelamento e loja','ifood cancelamento negociação reembolso aceitar recusar alternativa pausar loja abrir fechar',
 E'Quando o cliente pede cancelamento ou reembolso no iFood, a equipe recebe um aviso no celular. Abra Contas e acessos → Integrações → iFood → "Negociações": veja o pedido e o prazo, e toque em Aceitar, Recusar ou, quando houver, em uma alternativa. Se o prazo acabar, o iFood decide.\nLoja no iFood: o mesmo cartão tem os botões "Pausar 30 min / 1 h", "Retomar", "Fechar" e "Abrir". Com o ajuste "Abrir e fechar a loja no iFood junto com o caixa" ligado, abrir o caixa abre a loja e fechar o caixa fecha.\nO painel de Saúde mostra se a loja está aberta ou indisponível no iFood.',
 array['Admin','Operador'],true,'lista',104,'Pausar, abrir e fechar: Administrador e Operador.'
where not exists (select 1 from ai_ajuda where slug='man-admin-104-ifood-operacao');
