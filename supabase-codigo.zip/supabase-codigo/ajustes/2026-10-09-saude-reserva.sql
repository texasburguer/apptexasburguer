-- =====================================================================
-- TEXAS BURGER — Saúde do sistema + conferência diária · 2026-10-09
-- Cartão "Saúde do sistema" (Visão geral, só Admin/Dev): fila da planilha, backup, cópia no Drive, conferência de vendas, tarefas automáticas, IA.
-- Backup é diário às 04:00: atenção após 26 h, problema após 48 h.
-- A conferência de integridade passa de semanal para DIÁRIA (09:10 UTC = 06:10 de Brasília), conferindo o dia anterior (função conferir-integridade).
-- Seguro para rodar de novo.
-- =====================================================================
create or replace function public.api_saude_sistema(p jsonb default '{}'::jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public', 'cron' as $function$
declare itens jsonb := '[]'::jsonb; v_n int; v_min numeric; v_b record; v_i record; v_c int; v_ia int; v_pior text := 'ok';
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  -- 1) fila de sincronização com as planilhas
  select count(*), coalesce(extract(epoch from (now() - min(criado_em))) / 60, 0) into v_n, v_min from fila_sync where principal_ok_em is null;
  itens := itens || jsonb_build_object('id', 'fila', 'titulo', 'Cópia para a planilha de reserva',
    'nivel', case when v_n = 0 then 'ok' when v_min < 30 then 'atencao' else 'problema' end,
    'texto', case when v_n = 0 then 'Tudo copiado.' else v_n || ' item(ns) esperando; o mais antigo há ' || round(v_min) || ' min.' end);
  -- 2) backup automático
  select * into v_b from backups order by data_hora desc limit 1;
  itens := itens || jsonb_build_object('id', 'backup', 'titulo', 'Backup automático',
    'nivel', case when v_b.id is null then 'problema' when v_b.status <> 'Sucesso' then 'problema' when v_b.data_hora < now() - interval '48 hours' then 'problema' when v_b.data_hora < now() - interval '26 hours' then 'atencao' else 'ok' end,
    'texto', case when v_b.id is null then 'Nenhum backup encontrado.' when v_b.status <> 'Sucesso' then 'O último backup falhou: ' || coalesce(left(v_b.erro, 120), 'sem detalhe') else 'Último backup há ' || round(extract(epoch from (now() - v_b.data_hora)) / 3600, 1) || ' h.' end);
  itens := itens || jsonb_build_object('id', 'drive', 'titulo', 'Cópia do backup no Drive',
    'nivel', case when v_b.id is null then 'atencao' when v_b.copia_drive_erro is not null then 'atencao' when v_b.copia_drive_em is null then 'atencao' else 'ok' end,
    'texto', case when v_b.copia_drive_erro is not null then 'Falhou: ' || left(v_b.copia_drive_erro, 120) when v_b.copia_drive_em is null then 'Ainda não copiado.' else 'Copiado no Drive.' end);
  -- 3) conferência diária Supabase x planilha
  select * into v_i from integridade_checks order by criado_em desc limit 1;
  itens := itens || jsonb_build_object('id', 'integridade', 'titulo', 'Conferência de vendas (diária)',
    'nivel', case when v_i.id is null then 'atencao' when v_i.status <> 'ok' then 'problema' when v_i.criado_em < now() - interval '3 days' then 'atencao' else 'ok' end,
    'texto', case when v_i.id is null then 'Ainda não rodou.' when v_i.status <> 'ok' then 'Conferência do dia ' || to_char((v_i.detalhe->>'data')::date, 'DD/MM') || ' achou diferença: ' || v_i.supabase_vendas || ' vendas no Supabase x ' || v_i.planilha_vendas || ' na planilha.' else 'Conferido o dia ' || to_char((v_i.detalhe->>'data')::date, 'DD/MM') || ': ' || v_i.supabase_vendas || ' vendas no Supabase e ' || v_i.planilha_vendas || ' na planilha.' end);
  -- 4) tarefas automáticas
  select count(*) into v_c from cron.job j where (select d.status from cron.job_run_details d where d.jobid = j.jobid order by d.start_time desc limit 1) = 'failed';
  itens := itens || jsonb_build_object('id', 'tarefas', 'titulo', 'Tarefas automáticas', 'nivel', case when v_c = 0 then 'ok' else 'problema' end,
    'texto', case when v_c = 0 then 'Todas rodaram bem na última vez.' else v_c || ' tarefa(s) falharam na última execução.' end);
  -- 5) IA
  select count(*) into v_ia from ai_log where criado_em > now() - interval '1 hour' and status = 'erro';
  itens := itens || jsonb_build_object('id', 'ia', 'titulo', 'Assistente (IA)', 'nivel', case when v_ia >= 5 then 'atencao' else 'ok' end,
    'texto', case when v_ia >= 5 then v_ia || ' erro(s) na última hora; o sistema segue normal.' else 'Funcionando.' end);
  select case when bool_or(x->>'nivel' = 'problema') then 'problema' when bool_or(x->>'nivel' = 'atencao') then 'atencao' else 'ok' end into v_pior from jsonb_array_elements(itens) x;
  return jsonb_build_object('ok', true, 'geral', v_pior, 'itens', itens, 'em', to_char(now() at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI'));
end $function$;

grant execute on function public.api_saude_sistema(jsonb) to authenticated;
revoke execute on function public.api_saude_sistema(jsonb) from anon, public;

-- conferência de integridade: de semanal para diária (a função confere o dia anterior quando recebe cron:true)
do $do$ begin
  perform cron.unschedule(jobid) from cron.job where jobname = 'integridade-semanal';
  perform cron.unschedule(jobid) from cron.job where jobname = 'integridade-diaria';
  perform cron.schedule('integridade-diaria', '10 9 * * *', $c$ select public.chamar_edge('conferir-integridade','{"cron":true}'::jsonb); $c$);
end $do$;

-- Ajuda do assistente (ai_ajuda): modo reserva e Saúde do sistema
insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-96-modo-reserva','Modo reserva (quando o sistema cai)','modo reserva caiu fora do ar faixa laranja contingência supabase indisponível fila queda',
E'Uma faixa laranja "Modo reserva" no topo avisa que o servidor principal está fora.\nFunciona: venda do Caixa (retirada ou entrega, sem desconto e sem cupom), pedido do cardápio e consulta dos pedidos em Pedidos.\nNa fila (seguem sozinhos na volta): cadastro de cliente, fidelidade, feedback e ocorrência. Não repita a ação.\nEspera a volta ("indisponível até o Supabase voltar", nada é gravado): mudar status, estoque, compras, relatórios, avisos e Assistente. Anote à mão e lance depois.',
array['Admin','Operador'],true,'lista',96,'Quando a faixa sumir, confira se os pedidos feitos na queda aparecem em Pedidos.'
where not exists (select 1 from ai_ajuda where slug='man-admin-96-modo-reserva');
insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-97-saude-sistema','Saúde do sistema','saúde sistema cartão visão geral backup conferência vendas tarefas automáticas bolinha verde vermelha',
E'Em Visão geral, o cartão "Saúde do sistema" mostra uma bolinha verde, amarela ou vermelha.\nToque em "Ver detalhes" para ler cada item: cópia para a planilha, backup (diário às 04:00), cópia no Drive, conferência diária de vendas, tarefas automáticas e Assistente.\nAmarelo pede atenção; vermelho pede ação (ex.: backup com mais de 48 h ou vendas diferentes entre Supabase e planilha).\nDesenvolvedor: o botão "Simular queda (treino)" no mesmo cartão finge a queda só neste aparelho. "Encerrar simulação" volta ao normal.',
array['Admin'],true,'lista',97,'Só Admin e Desenvolvedor veem este cartão.'
where not exists (select 1 from ai_ajuda where slug='man-admin-97-saude-sistema');

-- CORREÇÃO: a view v_cardapio_status chama _cardapio_bloqueio(); sem esta permissão o cardápio público (anon) falhava e aparecia "Estamos fechados" mesmo com o caixa aberto.
grant execute on function public._cardapio_bloqueio() to anon, authenticated;

-- Ajuda do assistente: botão de abrir/fechar o cardápio
insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-98-botao-abrir-fechar-cardapio','Abrir ou fechar o cardápio em um toque','abrir fechar cardápio botão cardápio fechado clientes pedir início caixa reabrir',
E'Em Início e no Caixa há um botão discreto "🌐 Cardápio aberto".\nToque para fechar: o app pede uma mensagem opcional para o cliente. Os clientes deixam de conseguir pedir.\nQuando estiver fechado o botão vira "🌐 Cardápio fechado"; toque para liberar.\nO cardápio só recebe pedidos com o caixa aberto, mesmo reaberto. ',
array['Admin','Operador'],true,'lista',98,'Disponível para Administrador, Operador e Desenvolvedor.'
where not exists (select 1 from ai_ajuda where slug='man-admin-98-botao-abrir-fechar-cardapio');

-- Ajuda do assistente (id 232, Cardápio Digital): o fechamento agora é só pelo botão
update ai_ajuda set passos = replace(passos, E'Abrir ou fechar o cardápio: no topo do Cardápio Digital, marque "Fechar o cardápio agora" (com mensagem para o cliente) para parar os pedidos sem fechar o caixa, ou programe períodos (férias, feriado) com data de início, fim e mensagem. Pedido de mesa por QR Code continua valendo.', E'Abrir ou fechar o cardápio: use o botão "🌐 Cardápio aberto" em Início ou no Caixa. Um toque fecha (com mensagem opcional para o cliente) e outro reabre, sem fechar o caixa. Pedido de mesa por QR Code continua valendo.') where slug='man-admin-07-cardapio-digital-promocoes-e-eventos';

-- Ajuda do assistente (id 232): novo visual do cardápio do cliente
update ai_ajuda set passos = replace(passos, E'No celular, cada seção tem rolagem lateral (inclusive "Mais pedidos"). O cliente toca na foto para ver o item ampliado, com o botão Adicionar.', E'No celular, "Mais pedidos", "Destaques" e cada categoria rolam para o lado. O cliente toca no botão vermelho "+" para adicionar e na foto para ver o item ampliado. O botão redondo de balão abre o Atendimento.') where slug='man-admin-07-cardapio-digital-promocoes-e-eventos';

-- Ajuda do assistente: menu de baixo no celular
insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-99-menu-de-baixo','Menu de baixo no celular','menu barra embaixo celular navegação abas início caixa pedidos mais bolinha vermelha',
E'No celular, o menu fica fixo na parte de baixo da tela: Início, Caixa, Pedidos e as outras telas do seu perfil. A aba aberta fica em dourado.\nQuando há mais telas do que cabem, aparece "Mais" com as demais. Uma bolinha vermelha avisa que há algo novo naquela aba.\nNo computador o menu continua no topo.',
array['Admin','Operador'],true,'lista',99,'O botão do Assistente sobe um pouco para não ficar em cima do menu.'
where not exists (select 1 from ai_ajuda where slug='man-admin-99-menu-de-baixo');

-- ===== 2026-10-09 (noite): preço base único + senha de administrador de verdade =====
-- Rode também o arquivo preco-base.sql (padroniza os preços, corrige a senha de administrador e a calculadora).
update ai_ajuda set passos = replace(passos, 'toque em "editar" na lista "Usuários cadastrados".', 'toque em "editar" na lista "Usuários cadastrados". Mudar perfil, situação ou senha, e também ativar, desativar ou excluir, pede a SUA senha de administrador (conferida de verdade).') where slug='man-admin-03-criar-usuario-e-trocar-senha' and passos not like '%conferida de verdade%';
update ai_ajuda set passos = replace(passos, 'O preço vale para todas as formas de pagamento.', 'O preço vale para todas as formas de pagamento (é o preço base). Editar o produto nunca cria preços diferentes por forma: quem cobra a mais é o acréscimo da forma, em Pagamentos.') where slug='man-admin-04-cadastrar-produtos-e-estoque' and passos not like '%é o preço base%';
update ai_ajuda set passos = replace(passos, 'simulador de preço', 'simulador de preço ("Aplicar como preço base" vale para todas as formas de pagamento)') where slug='man-admin-07-cardapio-digital-promocoes-e-eventos' and passos not like '%Aplicar como preço base%';
update ai_ajuda set passos = replace(passos, 'a frequência e a retenção', 'o horário e a retenção (por quantos dias guardar)') where slug='man-admin-16-backup-e-armazenamento';
