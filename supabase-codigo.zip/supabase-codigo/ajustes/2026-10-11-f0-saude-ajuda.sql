-- TEXAS BURGER — Ajuda do assistente: a "Saúde do sistema" fica só em "Conexão e servidores" (bolinha do topo) · 2026-10-11
-- Só atualiza o texto de ajuda (ai_ajuda). Pode rodar mais de uma vez. Substitui a versão de 2026-10-10 (saude-ajuda.sql).
update ai_ajuda set
  palavras_chave = 'saúde sistema conexão servidores backup conferência vendas tarefas automáticas bolinha verde vermelha',
  passos = E'A "Saúde do sistema" fica dentro de "Conexão e servidores": toque na bolinha colorida do topo.\nLá aparecem os servidores e, logo abaixo, cada item: cópia para a planilha, backup (diário às 04:00), cópia no Drive, conferência diária de vendas, tarefas automáticas e Assistente.\nA própria bolinha do topo muda de cor: verde = tudo certo, amarela = atenção, rosa = precisa de cuidado (se a conexão cair, ela fica vermelha ou laranja). Amarelo pede atenção; vermelho pede ação (ex.: backup com mais de 48 h ou vendas diferentes entre Supabase e planilha).\nDesenvolvedor: o botão "Simular queda (treino)" fica em "Conexão e servidores" e finge a queda só neste aparelho. "Encerrar simulação" volta ao normal.',
  comuns = 'Só Admin e Desenvolvedor veem a Saúde do sistema.'
where slug = 'man-admin-97-saude-sistema';
