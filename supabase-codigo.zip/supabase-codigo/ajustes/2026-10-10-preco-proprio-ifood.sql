-- =====================================================================
-- TEXAS BURGER — Preço próprio por produto (ex.: iFood) · 2026-10-10
-- Formas de pagamento podem ter "preço próprio por produto" (formas_pagamento.preco_proprio).
-- Nelas, a linha de produto_precos/combo_precos daquela forma guarda o preço próprio; nas demais vale o preço base.
-- A calculadora ("Aplicar como preço base") não mexe nos preços próprios.
-- Seguro para rodar de novo.
-- =====================================================================
alter table public.formas_pagamento add column if not exists preco_proprio boolean not null default false;

do $do$
declare d text;
begin
  select pg_get_functiondef('public.api_add_forma_pagamento(jsonb)'::regprocedure) into d;
  if position('precoProprio' in d) = 0 then
    d := replace(d, E'  -- a nova forma já nasce com', E'  update formas_pagamento set preco_proprio = coalesce((p->>''precoProprio'')::boolean, false) where id = v_id;\n  -- a nova forma já nasce com');
    execute d;
  end if;
  select pg_get_functiondef('public.api_editar_forma_pagamento(jsonb)'::regprocedure) into d;
  if position('novoPrecoProprio' in d) = 0 then
    d := replace(d, E'  if p ? ''novaOrdem''', E'  if p ? ''novoPrecoProprio'' then update formas_pagamento set preco_proprio = coalesce((p->>''novoPrecoProprio'')::boolean, false) where id = f.id; end if;\n  if p ? ''novaOrdem''');
    execute d;
  end if;
  select pg_get_functiondef('public.api_aplicar_preco_calculadora(jsonb)'::regprocedure) into d;
  if position('preco_proprio' in d) = 0 then
    d := replace(d, 'update produto_precos set preco = v_novo where produto_id = v_prod;',
      'update produto_precos pp set preco = v_novo where pp.produto_id = v_prod and (pp.preco = v_antigo or not exists (select 1 from formas_pagamento f where f.id = pp.forma_pagamento_id and f.preco_proprio));');
    execute d;
  end if;
end $do$;

-- Só no Texas Burger (já aplicado em 2026-10-10): iFood com preço próprio e os preços antigos do iFood recolocados da cópia de 09/10.
-- update formas_pagamento set preco_proprio = true where nome = 'iFood';
-- update produto_precos pp set preco = b.preco from precos_backup_20261009 b, formas_pagamento f
--   where f.nome = 'iFood' and pp.forma_pagamento_id = f.id and b.tipo = 'produto' and b.item_id = pp.produto_id and b.forma_pagamento_id = f.id and b.preco <> pp.preco;
-- update combo_precos cp set preco = b.preco from precos_backup_20261009 b, formas_pagamento f
--   where f.nome = 'iFood' and cp.forma_pagamento_id = f.id and b.tipo = 'combo' and b.item_id = cp.combo_id and b.forma_pagamento_id = f.id and b.preco <> cp.preco;

-- Ajuda do assistente
update ai_ajuda set passos = replace(passos, 'O preço vale para todas as formas de pagamento (é o preço base). Editar o produto nunca cria preços diferentes por forma: quem cobra a mais é o acréscimo da forma, em Pagamentos.', 'O preço é o preço base e vale para todas as formas de pagamento. Formas marcadas em Pagamentos como "preço próprio por produto" (ex.: iFood) ganham um campo próprio no produto e no combo ("Preço no iFood"); em branco, vale o preço base. No Caixa, ao escolher iFood, os itens usam o preço do iFood.')
where slug = 'man-admin-04-cadastrar-produtos-e-estoque';
