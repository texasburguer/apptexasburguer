-- =====================================================================================
-- FASE 5 — Emissão da NFC-e (nota do consumidor) pela Focus NFe
-- Tudo NASCE DESLIGADO. Com a integração "nfce" desligada, o gatilho abaixo sai na primeira linha e nada muda nas vendas.
-- Idempotente. Depende da f0 e da f4. Função do servidor: nfce-emitir (publicar depois de rodar este arquivo).
-- ⚠️ Escrito a partir da documentação pública da Focus NFe; NÃO testado com a Focus de verdade (só com servidor de mentira).
-- =====================================================================================

alter table public.vendas add column if not exists cpf_nota text check (cpf_nota is null or cpf_nota ~ '^[0-9]{11}$');

create table if not exists public.nfce_notas (
  id bigserial primary key,
  venda_id uuid not null unique,
  ref text not null unique,                         -- referência única na Focus (= id da venda): impede nota em duplicidade
  ambiente text not null check (ambiente in ('homologacao', 'producao', 'simulado')),
  estado text not null default 'pendente' check (estado in ('pendente', 'emitindo', 'duvida', 'autorizada', 'rejeitada', 'contingencia', 'pendencia', 'cancelando', 'cancelada', 'erro', 'dispensada')),
  numero int, serie int, chave text, protocolo text,
  url_danfe text, url_xml text, url_consulta text,
  status_sefaz text, mensagem text, erro_pt text,
  valor numeric(12,2), cpf text,
  tentativas int not null default 0,
  emitir_apos timestamptz not null default now(),   -- dá um tempinho para o caixa informar o CPF
  proxima_tentativa timestamptz not null default now(),
  trava_ate timestamptz,
  emitida_em timestamptz, cancelada_em timestamptz, cancelamento_motivo text,
  emitido_por text,
  criado_em timestamptz not null default now(), atualizado_em timestamptz not null default now()
);
create index if not exists nfce_notas_estado_idx on public.nfce_notas (estado, proxima_tentativa);
create index if not exists nfce_notas_criado_idx on public.nfce_notas (criado_em desc);
alter table public.nfce_notas enable row level security;

create or replace function public._cpf_valido(p text) returns boolean
 language plpgsql immutable as $f$
declare s int; i int; d1 int; d2 int;
begin
  if p is null or p !~ '^[0-9]{11}$' or p ~ '^(.)\1{10}$' then return false; end if;
  s := 0; for i in 1..9 loop s := s + substr(p, i, 1)::int * (11 - i); end loop; d1 := (s * 10) % 11; if d1 = 10 then d1 := 0; end if;
  s := 0; for i in 1..10 loop s := s + substr(p, i, 1)::int * (12 - i); end loop; d2 := (s * 10) % 11; if d2 = 10 then d2 := 0; end if;
  return d1 = substr(p, 10, 1)::int and d2 = substr(p, 11, 1)::int;
end $f$;

create or replace function public._nfce_canal_da_venda(p_origem text, p_tipo text, p_canal text) returns text
 language sql immutable as $f$
  select case when p_canal = 'iFood' then 'ifood' when p_origem = 'Cardápio' then 'cardapio' when p_origem = 'Garçom' or p_tipo = 'Mesa' then 'mesa' else 'balcao' end
$f$;

-- código da forma de pagamento na nota (tabela da Sefaz). O contador confere os casos especiais (ex.: pagamento online do iFood).
create or replace function public._nfce_forma_codigo(p text) returns text
 language sql immutable as $f$
  select case
    when lower(coalesce(p, '')) ~ 'dinheiro' then '01'
    when lower(coalesce(p, '')) ~ 'cr[eé]dito' then '03'
    when lower(coalesce(p, '')) ~ 'd[eé]bito' then '04'
    when lower(coalesce(p, '')) ~ 'pix' then '17'
    when lower(coalesce(p, '')) ~ 'alelo|vale|ticket|sodexo|refei|alimenta' then '10'
    else '99' end
$f$;

-- explica a rejeição em português simples
create or replace function public._nfce_traduzir(p text) returns text
 language sql immutable as $f$
  select case
    when p is null or btrim(p) = '' then 'A nota foi rejeitada, sem explicação detalhada. Veja o registro e fale com o contador.'
    when p ~* 'ncm' then 'NCM inválido ou não aceito. Confira o NCM do perfil fiscal do produto (o contador informa).'
    when p ~* 'csosn|situa[cç][aã]o tribut|\mcst\M' then 'Situação tributária (CSOSN/CST) incompatível com o regime da empresa. Confira o perfil fiscal.'
    when p ~* 'cfop' then 'CFOP incompatível com a operação. Confira o perfil fiscal com o contador.'
    when p ~* 'csc' then 'CSC ou número do CSC inválido. Confira o CSC (Sefaz) em Dados fiscais e em Chaves.'
    when p ~* 'certificado' then 'Problema com o certificado digital A1 (vencido ou não enviado à Focus). Fale com o contador ou com a Focus.'
    when p ~* 'inscri[cç][aã]o estadual' then 'Inscrição estadual do emitente não confere. Confira em Dados fiscais da empresa.'
    when p ~* 'cnpj' then 'CNPJ do emitente não confere com o cadastrado na Focus/Sefaz.'
    when p ~* 'duplicidade|duplicad|j[aá] existe|ja existe' then 'Já existe nota para esta venda. Use "Consultar na Focus" antes de reemitir.'
    when p ~* 'data.*(emiss|atras)|atrasad' then 'Horário da emissão fora do permitido (máximo 5 minutos de diferença). Confira o relógio e reemita.'
    when p ~* 'pagamento|total' then 'Soma dos pagamentos diferente do total da nota. Confira descontos, taxa de entrega e acréscimos da venda com o contador.'
    when p ~* 'token|permiss|n[aã]o autorizado|unauthorized|forbidden|acesso negado' then 'A Focus recusou o token. Confira o token (teste × produção) em Chaves.'
    when p ~* 'sefaz|indispon|offline|timeout|conting' then 'A Sefaz está fora do ar ou lenta. O sistema tenta de novo sozinho.'
    else 'Rejeitada: ' || left(p, 220) end
$f$;

-- GATILHO: cria a "nota pendente" quando a venda cumpre a regra configurada. Nunca atrapalha a venda (qualquer erro vira só um registro).
create or replace function public._nfce_trg_venda() returns trigger
 language plpgsql security definer set search_path to 'public' as $f$
declare c integracoes_config%rowtype; v_canal text; v_ok boolean;
begin
  if not public._integracao_ligada('nfce') then return null; end if;
  begin
    if new.status::text <> 'Confirmada' then return null; end if;
    select * into c from integracoes_config where provedor = 'nfce';
    if c.ligado_em is not null and new.data_hora < c.ligado_em then return null; end if;     -- vendas de antes de ligar não geram nota sozinhas
    v_canal := public._nfce_canal_da_venda(new.origem::text, new.tipo::text, new.canal);
    if not (c.config->'canais' ? v_canal) then return null; end if;
    v_ok := case when coalesce(c.config->>'emitirQuando', 'pagamento') = 'entrega'
                 then new.status_pedido::text in ('Entregue', 'Retirada', 'Servida')
                 else new.status_pagamento::text = 'Pago' end;
    if not v_ok then return null; end if;
    insert into nfce_notas (venda_id, ref, ambiente, valor, cpf, emitir_apos, proxima_tentativa)
      values (new.id, new.id::text, c.modo, new.valor_total, new.cpf_nota, now() + interval '45 seconds', now() + interval '45 seconds')
      on conflict (venda_id) do nothing;
  exception when others then
    perform public._integ_log('nfce', 'erro', 'Não consegui preparar a nota da venda ' || coalesce(new.numero_pedido::text, '?') || ': ' || sqlerrm);
  end;
  return null;
end $f$;
drop trigger if exists trg_nfce_venda on public.vendas;
create trigger trg_nfce_venda after insert or update of status, status_pagamento, status_pedido on public.vendas for each row execute function public._nfce_trg_venda();

-- monta o JSON da nota a partir da venda (itens, perfil fiscal, desconto/taxas rateados, pagamentos)
create or replace function public.nfce_montar(p_id bigint) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare n nfce_notas%rowtype; v vendas%rowtype; e fiscal_empresa%rowtype; r record; v_itens jsonb := '[]'::jsonb; v_pags jsonb := '[]'::jsonb;
  v_sem text; v_bruto numeric := 0; v_desc numeric; v_outras numeric; v_total numeric; v_dsum numeric := 0; v_osum numeric := 0; v_di numeric; v_oi numeric;
  v_cnt int; v_i int := 0; v_psum numeric := 0; v_pf fiscal_perfis%rowtype; v_cpf text; v_item jsonb;
begin
  select * into n from nfce_notas where id = p_id; if not found then return jsonb_build_object('ok', false, 'motivo', 'Nota não encontrada.'); end if;
  select * into v from vendas where id = n.venda_id; if not found then return jsonb_build_object('ok', false, 'motivo', 'Venda não encontrada.'); end if;
  select * into e from fiscal_empresa where id;
  if not public._fiscal_empresa_ok() then return jsonb_build_object('ok', false, 'motivo', 'Dados fiscais da empresa incompletos (Integrações → Nota fiscal → Dados fiscais).'); end if;
  select string_agg(distinct coalesce(iv.descricao, '(item)'), ', ') into v_sem from itens_venda iv where iv.venda_id = v.id and iv.valor_total_item > 0 and public._perfil_fiscal_efetivo(iv.produto_id, iv.combo_id) is null;
  if v_sem is not null then return jsonb_build_object('ok', false, 'motivo', 'Item sem perfil fiscal: ' || left(v_sem, 150) || '. Defina o perfil e reemita.'); end if;
  select coalesce(sum(valor_total_item), 0), count(*) into v_bruto, v_cnt from itens_venda where venda_id = v.id and valor_total_item > 0;
  if v_cnt = 0 or v_bruto <= 0 then return jsonb_build_object('ok', false, 'dispensar', true, 'motivo', 'Venda sem valor: não há nota a emitir.'); end if;
  v_desc := coalesce(v.valor_desconto, 0); v_outras := coalesce(v.taxa_entrega, 0) + coalesce(v.acrescimo_forma, 0);
  v_total := round(v_bruto - v_desc + v_outras, 2);
  for r in select iv.id, iv.produto_id, iv.combo_id, iv.descricao, iv.quantidade, iv.valor_total_item vt from itens_venda iv where iv.venda_id = v.id and iv.valor_total_item > 0 order by iv.id loop
    v_i := v_i + 1;
    if v_i = v_cnt then v_di := round(v_desc - v_dsum, 2); v_oi := round(v_outras - v_osum, 2);
    else v_di := round(v_desc * r.vt / v_bruto, 2); v_oi := round(v_outras * r.vt / v_bruto, 2); end if;
    v_dsum := v_dsum + v_di; v_osum := v_osum + v_oi;
    select * into v_pf from fiscal_perfis where id = public._perfil_fiscal_efetivo(r.produto_id, r.combo_id);
    v_item := jsonb_build_object('numero_item', v_i, 'codigo_produto', coalesce(r.produto_id, r.combo_id)::text, 'descricao', left(btrim(coalesce(r.descricao, 'Item')), 120),
      'codigo_ncm', v_pf.ncm, 'cfop', v_pf.cfop, 'unidade_comercial', v_pf.unidade, 'quantidade_comercial', r.quantidade, 'valor_unitario_comercial', round(r.vt / nullif(r.quantidade, 0), 6),
      'unidade_tributavel', v_pf.unidade, 'quantidade_tributavel', r.quantidade, 'valor_unitario_tributavel', round(r.vt / nullif(r.quantidade, 0), 6), 'valor_bruto', round(r.vt, 2),
      'icms_origem', v_pf.origem::int, 'icms_situacao_tributaria', coalesce(v_pf.csosn, v_pf.cst_icms), 'pis_situacao_tributaria', v_pf.pis_cst, 'cofins_situacao_tributaria', v_pf.cofins_cst, 'inclui_no_total', 1);
    if v_pf.cest is not null then v_item := v_item || jsonb_build_object('cest', v_pf.cest); end if;
    if v_di > 0 then v_item := v_item || jsonb_build_object('valor_desconto', v_di); end if;
    if v_oi > 0 then v_item := v_item || jsonb_build_object('valor_outras_despesas', v_oi); end if;
    v_itens := v_itens || v_item;
  end loop;
  -- pagamentos: seguem os da venda; a diferença de centavos vai no maior para a soma bater exatamente com o total da nota
  for r in select forma_pagamento, valor from pagamentos_venda where venda_id = v.id and valor > 0 order by valor desc loop
    v_pags := v_pags || jsonb_build_object('forma_pagamento', public._nfce_forma_codigo(r.forma_pagamento), 'valor_pagamento', round(r.valor, 2));
    v_psum := v_psum + round(r.valor, 2);
  end loop;
  if jsonb_array_length(v_pags) = 0 then
    v_pags := jsonb_build_array(jsonb_build_object('forma_pagamento', public._nfce_forma_codigo(v.forma_pagamento), 'valor_pagamento', v_total));
  elsif v_psum <> v_total then
    v_pags := jsonb_set(v_pags, '{0,valor_pagamento}', to_jsonb(round((v_pags->0->>'valor_pagamento')::numeric + (v_total - v_psum), 2)));
  end if;
  v_cpf := coalesce(n.cpf, v.cpf_nota);
  return jsonb_build_object('ok', true, 'valor', v_total, 'payload', jsonb_strip_nulls(jsonb_build_object(
    'natureza_operacao', 'VENDA AO CONSUMIDOR', 'cnpj_emitente', e.cnpj, 'presenca_comprador', case when v.tipo::text = 'Entrega' then 4 else 1 end,
    'modalidade_frete', 9, 'local_destino', 1, 'consumidor_final', 1, 'cpf_destinatario', v_cpf, 'itens', v_itens, 'formas_pagamento', v_pags)));
end $f$;

create or replace function public.nfce_log(p_nivel text, p_msg text) returns void language sql security definer set search_path to 'public' as $f$
  select public._integ_log('nfce', case when p_nivel in ('info','aviso','erro') then p_nivel else 'info' end, p_msg)
$f$;

-- credenciais para o servidor: token do ambiente da nota
create or replace function public.nfce_credenciais(p_ambiente text) returns jsonb
 language sql stable security definer set search_path to 'public' as $f$
  select jsonb_build_object('ligado', public._integracao_ligada('nfce'), 'modo', (select modo from integracoes_config where provedor = 'nfce'),
    'token', (select valor from integracoes_segredos where chave = 'nfce_token_' || case when p_ambiente = 'producao' then 'producao' else 'homologacao' end),
    'cnpj', (select cnpj from fiscal_empresa where id))
$f$;

-- notas prontas para tratar (reserva por 2 min, para dois ciclos não pegarem a mesma)
create or replace function public.nfce_pegar_pendentes(p_limite int default 5) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare r jsonb;
begin
  with c as (select id from nfce_notas where estado in ('pendente', 'duvida', 'contingencia') and emitir_apos <= now() and proxima_tentativa <= now() and (trava_ate is null or trava_ate < now())
               order by id limit greatest(1, least(coalesce(p_limite, 5), 20)) for update skip locked),
  u as (update nfce_notas n set trava_ate = now() + interval '2 minutes', atualizado_em = now() from c where n.id = c.id returning n.id, n.ref, n.venda_id, n.ambiente, n.estado, n.tentativas)
  select coalesce(jsonb_agg(to_jsonb(u)), '[]'::jsonb) into r from u;
  return r;
end $f$;

-- resultado do tratamento de uma nota. p_res: {resultado, numero, serie, chave, protocolo, urlDanfe, urlXml, urlConsulta, statusSefaz, mensagem, motivo}
create or replace function public.nfce_resultado(p_id bigint, p_res jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare n nfce_notas%rowtype; v_r text := p_res->>'resultado'; v_msg text := left(coalesce(p_res->>'mensagem', ''), 600); v_tent int;
begin
  select * into n from nfce_notas where id = p_id for update;
  if not found then return jsonb_build_object('ok', false); end if;
  if n.estado in ('autorizada', 'cancelada') and v_r <> 'autorizada' then return jsonb_build_object('ok', true, 'ignorado', true); end if;
  if v_r = 'autorizada' then
    update nfce_notas set estado = 'autorizada', numero = nullif(p_res->>'numero', '')::int, serie = nullif(p_res->>'serie', '')::int, chave = p_res->>'chave', protocolo = p_res->>'protocolo',
      url_danfe = p_res->>'urlDanfe', url_xml = p_res->>'urlXml', url_consulta = p_res->>'urlConsulta', status_sefaz = p_res->>'statusSefaz', mensagem = v_msg, erro_pt = null,
      emitida_em = coalesce(emitida_em, now()), trava_ate = null, atualizado_em = now(), tentativas = tentativas + 1 where id = p_id;
    perform public._integ_log('nfce', 'info', 'Nota ' || coalesce(p_res->>'numero', '?') || ' autorizada (venda ' || n.ref || ')');
  elsif v_r = 'rejeitada' then
    update nfce_notas set estado = 'rejeitada', status_sefaz = p_res->>'statusSefaz', mensagem = v_msg, erro_pt = public._nfce_traduzir(v_msg), trava_ate = null, atualizado_em = now(), tentativas = tentativas + 1 where id = p_id;
    perform public._integ_log('nfce', 'erro', 'Nota rejeitada (venda ' || n.ref || '): ' || left(v_msg, 200));
  elsif v_r = 'pendencia' then
    update nfce_notas set estado = 'pendencia', erro_pt = left(coalesce(p_res->>'motivo', 'Pendência'), 300), trava_ate = null, atualizado_em = now() where id = p_id;
    perform public._integ_log('nfce', 'aviso', 'Nota parada (venda ' || n.ref || '): ' || left(coalesce(p_res->>'motivo', ''), 200));
  elsif v_r = 'dispensada' then
    update nfce_notas set estado = 'dispensada', erro_pt = left(coalesce(p_res->>'motivo', ''), 300), trava_ate = null, atualizado_em = now() where id = p_id;
  elsif v_r = 'contingencia' then
    update nfce_notas set estado = 'contingencia', numero = nullif(p_res->>'numero', '')::int, serie = nullif(p_res->>'serie', '')::int, chave = p_res->>'chave', mensagem = v_msg,
      proxima_tentativa = now() + interval '3 minutes', trava_ate = null, atualizado_em = now() where id = p_id;
  else   -- 'duvida' (rede/timeout/5xx/ainda processando): nunca reenvia às cegas; da próxima vez consulta primeiro
    v_tent := n.tentativas + 1;
    update nfce_notas set estado = case when v_tent >= 8 then 'erro' else 'duvida' end, tentativas = v_tent, mensagem = v_msg,
      erro_pt = case when v_tent >= 8 then 'Não consegui falar com a Focus/Sefaz depois de várias tentativas. Veja o registro e use "Reemitir".' else null end,
      proxima_tentativa = now() + make_interval(mins => least(power(2, least(v_tent, 5))::int, 30)), trava_ate = null, atualizado_em = now() where id = p_id;
    if v_tent >= 8 then perform public._integ_log('nfce', 'erro', 'Nota parada por erro de comunicação (venda ' || n.ref || ')'); end if;
  end if;
  return jsonb_build_object('ok', true);
end $f$;

-- ---------- telas ----------
create or replace function public.api_nfce_lista(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_est text := nullif(p->>'estado', ''); v_lim int := least(coalesce(nullif(p->>'limite', '')::int, 60), 200);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'contagem', coalesce((select jsonb_object_agg(estado, q) from (select estado, count(*) q from nfce_notas where criado_em > now() - interval '30 days' group by 1) x), '{}'::jsonb),
    'mes', (select count(*) from nfce_notas where estado = 'autorizada' and ambiente = 'producao' and emitida_em >= date_trunc('month', now() at time zone 'America/Sao_Paulo') at time zone 'America/Sao_Paulo'),
    'itens', coalesce((select jsonb_agg(jsonb_build_object('id', n.id, 'vendaId', n.venda_id, 'pedido', v.numero_pedido, 'cliente', v.cliente_nome, 'quando', v.data_hora, 'estado', n.estado, 'ambiente', n.ambiente,
        'numero', n.numero, 'serie', n.serie, 'valor', n.valor, 'erro', n.erro_pt, 'danfe', n.url_danfe, 'xml', n.url_xml, 'consulta', n.url_consulta, 'cpf', (n.cpf is not null), 'tentativas', n.tentativas,
        'emitidaEm', n.emitida_em, 'canceladaEm', n.cancelada_em) order by n.id desc)
      from (select * from nfce_notas where (v_est is null or estado = v_est) order by id desc limit v_lim) n left join vendas v on v.id = n.venda_id), '[]'::jsonb));
end $f$;

create or replace function public.api_nfce_reemitir(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare n nfce_notas%rowtype;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into n from nfce_notas where id = (p->>'id')::bigint for update;
  if not found then return _falha('Nota não encontrada.'); end if;
  if n.estado not in ('rejeitada', 'pendencia', 'erro', 'duvida', 'dispensada') then return _falha('Esta nota não precisa ser reemitida (' || n.estado || ').'); end if;
  update nfce_notas set estado = 'pendente', tentativas = 0, erro_pt = null, emitir_apos = now(), proxima_tentativa = now(), trava_ate = null, ambiente = coalesce((select modo from integracoes_config where provedor = 'nfce'), ambiente), atualizado_em = now() where id = n.id;
  perform _auditar('Nota fiscal: reemissão pedida', n.ref);
  perform public.chamar_edge('nfce-emitir', '{}'::jsonb);
  return api_nfce_lista('{}') || jsonb_build_object('message', 'Pedido de reemissão enviado. Atualize a lista em alguns segundos.');
end $f$;

-- cria a nota de uma venda que ficou sem (ex.: antes de ligar, ou modo "na entrega" que não disparou)
create or replace function public.api_nfce_emitir_venda(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v vendas%rowtype;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not public._integracao_ligada('nfce') then return _falha('A nota fiscal está desligada.'); end if;
  select * into v from vendas where id = (p->>'vendaId')::uuid;
  if not found or v.status::text <> 'Confirmada' then return _falha('Venda não encontrada ou não confirmada.'); end if;
  insert into nfce_notas (venda_id, ref, ambiente, valor, cpf, emitir_apos, proxima_tentativa)
    values (v.id, v.id::text, (select modo from integracoes_config where provedor = 'nfce'), v.valor_total, v.cpf_nota, now(), now()) on conflict (venda_id) do nothing;
  if not found then return _falha('Esta venda já tem nota (veja a lista).'); end if;
  perform _auditar('Nota fiscal: emissão manual pedida', v.id::text);
  perform public.chamar_edge('nfce-emitir', '{}'::jsonb);
  return api_nfce_lista('{}') || jsonb_build_object('message', 'Nota criada; sendo emitida.');
end $f$;

-- CPF na nota: só se o cliente pedir; só antes da emissão
create or replace function public.api_nfce_cpf(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_cpf text := regexp_replace(coalesce(p->>'cpf', ''), '\D', '', 'g'); v_venda uuid := nullif(p->>'vendaId', '')::uuid; n nfce_notas%rowtype;
begin
  if auth_nivel() is null or not tem_nivel('Admin', 'Operador', 'Garçom') then return _negado(); end if;
  if not public._integracao_ligada('nfce') then return jsonb_build_object('ok', true, 'ignorado', true); end if;
  if v_cpf <> '' and not public._cpf_valido(v_cpf) then return _falha('CPF inválido. Confira os 11 números.'); end if;
  select * into n from nfce_notas where venda_id = v_venda for update;
  if found and n.estado not in ('pendente', 'pendencia', 'rejeitada', 'dispensada') then return _falha('A nota desta venda já foi emitida; não dá mais para incluir o CPF.'); end if;
  update vendas set cpf_nota = nullif(v_cpf, '') where id = v_venda;
  if not found then return _falha('Venda não encontrada.'); end if;
  update nfce_notas set cpf = nullif(v_cpf, ''), atualizado_em = now() where venda_id = v_venda;
  return jsonb_build_object('ok', true, 'message', case when v_cpf = '' then 'CPF removido.' else 'CPF incluído na nota.' end);
end $f$;

-- Desenvolvedor: nota de TREINO (não fala com a Focus; o servidor inventa a autorização)
create or replace function public.api_nfce_simular(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v vendas%rowtype; v_m jsonb; v_id bigint;
begin
  if not public._eh_dev() then return _negado(); end if;
  select * into v from vendas where status::text = 'Confirmada' and coalesce(canal, '') <> 'iFood' and not exists (select 1 from nfce_notas x where x.venda_id = vendas.id) order by data_hora desc limit 1;
  if not found then return _falha('Não há venda confirmada sem nota para usar no treino. Faça uma venda de teste antes.'); end if;
  insert into nfce_notas (venda_id, ref, ambiente, valor, cpf, emitir_apos, proxima_tentativa) values (v.id, v.id::text, 'simulado', v.valor_total, v.cpf_nota, now(), now()) returning id into v_id;
  v_m := public.nfce_montar(v_id);
  perform public.chamar_edge('nfce-emitir', '{}'::jsonb);
  return jsonb_build_object('ok', true, 'message', 'Nota de treino criada para o pedido ' || v.numero_pedido || '. ' || case when (v_m->>'ok')::boolean then 'Os dados fiscais estão completos.' else 'Atenção: ' || coalesce(v_m->>'motivo', '') end);
end $f$;

-- saúde: bloco da nota fiscal
create or replace function public._saude_nfce() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare r record; v_rej int; v_pend int; v_atras int; v_cont int; v_dv int; v_nivel text; v_txt text;
begin
  select * into r from integracoes_config where ligado and provedor = 'nfce';
  if not found then return '[]'::jsonb; end if;
  select count(*) filter (where estado in ('rejeitada', 'erro')), count(*) filter (where estado = 'pendencia'), count(*) filter (where estado in ('pendente', 'duvida') and emitir_apos < now() - interval '10 minutes'),
         count(*) filter (where estado = 'contingencia'), count(*) filter (where estado = 'duvida')
    into v_rej, v_pend, v_atras, v_cont, v_dv from nfce_notas where criado_em > now() - interval '7 days';
  v_nivel := case when v_atras > 0 or v_rej > 0 then 'problema' when v_pend > 0 or v_cont > 0 or public._fiscal_sem_perfil_qtd() > 0 then 'atencao' else 'ok' end;
  v_txt := 'Nota fiscal ligada (' || case when r.modo = 'producao' then 'produção' else 'teste' end || ')'
    || case when v_rej > 0 then ' · ' || v_rej || ' nota(s) rejeitada(s)/com erro' else '' end
    || case when v_atras > 0 then ' · ' || v_atras || ' nota(s) esperando emissão há mais de 10 min' else '' end
    || case when v_pend > 0 then ' · ' || v_pend || ' parada(s) por pendência (ex.: item sem perfil)' else '' end
    || case when v_cont > 0 then ' · ' || v_cont || ' em contingência' else '' end
    || case when public._fiscal_sem_perfil_qtd() > 0 then ' · ' || public._fiscal_sem_perfil_qtd() || ' item(ns) sem perfil fiscal' else '' end;
  return jsonb_build_array(jsonb_build_object('id', 'nfce', 'titulo', 'Nota fiscal (NFC-e)', 'nivel', v_nivel, 'texto', v_txt));
end $f$;

create or replace function public._saude_integracoes() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_desc int; e ifood_estado%rowtype; v_min numeric; v_sem int; v_novos int; v_acoes int; v_nivel text; v_txt text; v_urg int;
begin
  if exists (select 1 from ai_segredos where provedor = 'nvidia') or exists (select 1 from ai_segredos where provedor = 'cloudflare') then
    select count(*) into v_desc from unnest(array['nvidia', 'cloudflare']) x(p) where _ia_provedor_descansando(x.p);
    v := v || jsonb_build_object('id', 'ia_extras', 'titulo', 'IAs de reserva (NVIDIA / Cloudflare)', 'nivel', case when v_desc > 0 then 'atencao' else 'ok' end,
      'texto', (select string_agg(x.rot || ': ' || case when not exists (select 1 from ai_segredos where provedor = x.p) then 'sem chave' when _ia_provedor_descansando(x.p) then 'descansando (erros recentes)' else 'pronta' end, ' · ')
                from (values ('nvidia', 'NVIDIA'), ('cloudflare', 'Cloudflare')) x(p, rot)));
  end if;
  if _integracao_ligada('ifood') then
    select * into e from ifood_estado where id;
    v_min := case when e.ultima_consulta_ok is null then null else extract(epoch from (now() - e.ultima_consulta_ok)) / 60 end;
    select coalesce(sum(itens_sem_ligacao), 0) into v_sem from ifood_pedidos where estado <> 'cancelado' and criado_em > now() - interval '7 days';
    select count(*) into v_novos from ifood_pedidos where estado = 'novo' and not simulado and criado_em < now() - interval '4 minutes';
    select count(*) into v_acoes from ifood_acoes where estado in ('erro', 'duvida') and criado_em > now() - interval '1 day';
    select count(*) into v_urg from ifood_negociacoes where estado = 'aberta' and expira_em > now() and expira_em < now() + interval '3 minutes';
    v_nivel := case when v_min is null or v_min > 2 or e.token_ok is false or v_novos > 0 or v_urg > 0 then 'problema' when v_acoes > 0 or v_sem > 0 or e.ultimo_erro is not null or exists (select 1 from ifood_negociacoes where estado = 'aberta' and expira_em > now()) then 'atencao' else 'ok' end;
    v_txt := case when v_min is null then 'Ligado, mas ainda sem nenhuma consulta bem-sucedida ao iFood.' else 'Última consulta ao iFood há ' || round(v_min, 1) || ' min' end
      || case when e.ultimo_pedido_em is not null then ' · último pedido às ' || to_char(e.ultimo_pedido_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') else ' · nenhum pedido ainda' end
      || case when e.token_ok is false then ' · ACESSO RECUSADO (confira as chaves)' else '' end
      || case when v_novos > 0 then ' · ' || v_novos || ' pedido(s) esperando confirmação há mais de 4 min' else '' end
      || case when v_acoes > 0 then ' · ' || v_acoes || ' ação(ões) não confirmada(s) no iFood' else '' end
      || case when v_sem > 0 then ' · ' || v_sem || ' item(ns) sem ligação' else '' end || public._saude_ifood_extra();
    v := v || jsonb_build_object('id', 'ifood', 'titulo', 'iFood', 'nivel', v_nivel, 'texto', v_txt);
  end if;
  v := v || public._saude_nfce();
  return v;
end $f$;

-- cron: chama o servidor 1x por minuto, mas só se a nota estiver ligada e houver nota para tratar
do $c$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.schedule('nfce-emitir-minuto', '* * * * *', $j$select case when public._integracao_ligada('nfce') and exists (select 1 from public.nfce_notas where estado in ('pendente', 'duvida', 'contingencia') and emitir_apos <= now() and proxima_tentativa <= now()) then public.chamar_edge('nfce-emitir', '{}'::jsonb) end$j$);
  end if;
end $c$;

-- ---------- permissões ----------
revoke execute on function public._cpf_valido(text), public._nfce_canal_da_venda(text, text, text), public._nfce_forma_codigo(text), public._nfce_traduzir(text), public._nfce_trg_venda(),
  public.nfce_montar(bigint), public.nfce_credenciais(text), public.nfce_pegar_pendentes(int), public.nfce_resultado(bigint, jsonb), public.nfce_log(text, text), public._saude_nfce() from public, anon, authenticated;
grant execute on function public.nfce_montar(bigint), public.nfce_credenciais(text), public.nfce_pegar_pendentes(int), public.nfce_resultado(bigint, jsonb), public.nfce_log(text, text) to service_role;
revoke execute on function public.api_nfce_lista(jsonb), public.api_nfce_reemitir(jsonb), public.api_nfce_emitir_venda(jsonb), public.api_nfce_cpf(jsonb), public.api_nfce_simular(jsonb) from public, anon;
grant execute on function public.api_nfce_lista(jsonb), public.api_nfce_reemitir(jsonb), public.api_nfce_emitir_venda(jsonb), public.api_nfce_cpf(jsonb), public.api_nfce_simular(jsonb) to authenticated;

insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-107-nfce-emissao','Nota fiscal: emissão automática, CPF na nota e lista de notas','nota fiscal nfc-e emitir emissão cpf rejeitada reemitir danfe focus lista notas contingência',
 E'Com a nota fiscal ligada (Contas e acessos → Integrações → Nota fiscal), cada venda do canal escolhido gera a nota sozinha: ao pagar (balcão) ou na entrega (delivery/iFood). A nota sai cerca de 1 minuto depois da venda, para dar tempo de informar o CPF.\nCPF na nota: só se o cliente pedir. No Caixa, antes de finalizar, digite o CPF no campo "CPF na nota". Depois que a nota sai não dá mais para incluir.\nLista "Notas fiscais": filtre por situação (autorizada, rejeitada, pendência, em contingência). Se uma nota foi rejeitada, o texto explica o motivo em português; corrija (ex.: perfil fiscal do produto) e toque em "Reemitir". "Abrir DANFE" mostra o cupom com QR Code; "Enviar ao cliente" abre o WhatsApp com o link.\nNunca é emitida nota de item sem perfil fiscal: a nota fica como pendência até você definir o perfil.\nDesenvolvedor: "Nota de treino" cria uma nota de mentira, sem falar com a Focus.',
 array['Admin','Operador','Garçom'],true,'lista',107,'Lista de notas e reemissão: só Administrador. CPF na nota: quem faz a venda.'
where not exists (select 1 from ai_ajuda where slug='man-admin-107-nfce-emissao');
