-- v1.0 — Acréscimo por forma de pagamento (substitui o "preço diferente por forma" do produto)
-- Rode UMA vez num banco que já existe. O % incide sobre os itens menos o desconto (não sobre a taxa de entrega); o valor fixo é cobrado uma vez por forma usada.
alter table formas_pagamento add column if not exists acrescimo_percentual numeric not null default 0 check (acrescimo_percentual >= 0 and acrescimo_percentual <= 100);
alter table formas_pagamento add column if not exists acrescimo_fixo numeric not null default 0 check (acrescimo_fixo >= 0 and acrescimo_fixo <= 1000);
alter table vendas add column if not exists acrescimo_forma numeric not null default 0;
alter table pagamentos_venda add column if not exists acrescimo numeric not null default 0;

create or replace function public._acrescimo_forma(f formas_pagamento, base numeric) returns numeric language sql immutable set search_path to 'public' as $$ select case when f.id is null then 0 else round(coalesce(base,0) * f.acrescimo_percentual / 100 + f.acrescimo_fixo, 2) end $$;
revoke all on function public._acrescimo_forma(formas_pagamento, numeric) from public, anon, authenticated;
create or replace function public._acrescimo_pagamento(p_forma text, p_valor numeric) returns numeric language sql stable security definer set search_path to 'public' as $$ select coalesce((select _acrescimo_forma(f, p_valor) from formas_pagamento f where lower(f.nome) = lower(btrim(coalesce(p_forma,''))) limit 1), 0) $$;
revoke all on function public._acrescimo_pagamento(text, numeric) from public, anon, authenticated;

create or replace view public.v_formas_operacional as select id, nome, ordem, permite_troco, acrescimo_percentual, acrescimo_fixo from formas_pagamento where ativa;
create or replace view public.v_cardapio_formas as select id, nome, ordem, permite_troco, acrescimo_percentual, acrescimo_fixo from formas_pagamento where ativa and visivel_cardapio;

-- preço único: com precoBase, todas as formas recebem o mesmo preço
create or replace function public._precos_ou_base(p jsonb) returns jsonb language sql stable security definer set search_path to 'public' as $function$
  select case when not (p ? 'precoBase') and jsonb_typeof(p->'precos') = 'array' and jsonb_array_length(p->'precos') > 0 then p->'precos'
    else coalesce((select jsonb_agg(jsonb_build_object('formaPagamentoId', f.id, 'preco', _num(p->>'precoBase'), 'custo', _num(p->>'custoBase'))) from formas_pagamento f), '[]'::jsonb) end
$function$;

create or replace view public.v_vendas with (security_invoker=true) as
 SELECT id, numero_pedido AS numero, data_hora, cliente_nome, telefone_cliente AS cliente_telefone, forma_pagamento, valor_total,
        CASE WHEN auth_nivel() = ANY (ARRAY['Admin'::nivel_acesso, 'Operador'::nivel_acesso]) THEN custo_total ELSE NULL::numeric END AS custo_total,
    status, motivo_cancelamento, tipo AS tipo_entrega, status_pedido, endereco, complemento, referencia, observacoes_entrega, pronta_em, concluida_em,
    status_pagamento, recebido_em, valor_original, valor_desconto, desconto_detalhe, _login_de(entregador_id) AS entregador, saiu_em, origem, mesa_id,
    taxa_entrega, fechamento_entrega_id, _login_de(registrado_por) AS registrado_por, inicio_preparo_em, _mesa_numero_de(mesa_id) AS mesa_numero, acrescimo_forma
   FROM vendas v;
alter view public.v_vendas set (security_invoker = true);
alter view public.v_formas_operacional set (security_invoker = true);


do $do$ declare d text; o text;
begin
  d := pg_get_functiondef('public._criar_pedido_publico(jsonb,uuid)'::regprocedure); o := d;
  d := replace(d, $q$v_bloqueia boolean; v_forma_nome text;$q$, $q$v_bloqueia boolean; v_forma_nome text; v_acr numeric := 0;$q$); if d = o then raise exception 'trecho 1 não encontrado em public._criar_pedido_publico(jsonb,uuid) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$  v_total := greatest(0.01, round(v_orig - v_desc + v_taxa, 2));$q$, $q$  v_total := greatest(0.01, round(v_orig - v_desc + v_taxa, 2));
  -- acréscimo da forma de pagamento escolhida (mesa: o acréscimo entra no fechamento da conta)
  if not v_eh_mesa then v_acr := _acrescimo_forma(v_forma, greatest(0.01, v_total - v_taxa)); v_total := round(v_total + v_acr, 2); end if;$q$); if d = o then raise exception 'trecho 2 não encontrado em public._criar_pedido_publico(jsonb,uuid) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$desconto_detalhe, origem, mesa_id, taxa_entrega, caixa_id, requisicao_id)$q$, $q$desconto_detalhe, origem, mesa_id, taxa_entrega, caixa_id, requisicao_id, acrescimo_forma)$q$); if d = o then raise exception 'trecho 3 não encontrado em public._criar_pedido_publico(jsonb,uuid) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$v_taxa, v_caixa, v_req)$q$, $q$v_taxa, v_caixa, v_req, v_acr)$q$); if d = o then raise exception 'trecho 4 não encontrado em public._criar_pedido_publico(jsonb,uuid) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada)$q$, $q$insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo)$q$); if d = o then raise exception 'trecho 5 não encontrado em public._criar_pedido_publico(jsonb,uuid) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$else round(v_total * v_forma.taxa_percentual / 100 + v_forma.taxa_fixa, 2) end);$q$, $q$else round(v_total * v_forma.taxa_percentual / 100 + v_forma.taxa_fixa, 2) end, v_acr);$q$); if d = o then raise exception 'trecho 6 não encontrado em public._criar_pedido_publico(jsonb,uuid) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$'valorOriginal', v_orig,$q$, $q$'valorOriginal', v_orig, 'acrescimo', v_acr,$q$); if d = o then raise exception 'trecho 7 não encontrado em public._criar_pedido_publico(jsonb,uuid) (talvez já aplicado)'; end if; o := d;
  execute d;
end $do$;

do $do$ declare d text; o text;
begin
  d := pg_get_functiondef('public.api_iniciar_venda(jsonb)'::regprocedure); o := d;
  d := replace(d, $q$v_bloqueia boolean; r record;$q$, $q$v_bloqueia boolean; r record; v_acr numeric := 0;$q$); if d = o then raise exception 'trecho 1 não encontrado em public.api_iniciar_venda(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$  -- grava tudo$q$, $q$  -- acréscimo por forma de pagamento: os valores enviados são a parte do pedido paga em cada forma (sem acréscimo)
  for pg in select value as e from jsonb_array_elements(v_pags) loop
    if btrim(pg.e->>'forma') = 'A Receber (Mesa)' then continue; end if;
    v_acr := v_acr + _acrescimo_pagamento(pg.e->>'forma', round(_num(pg.e->>'valor') * (case when v_total > 0 then (v_total - v_taxa) / v_total else 1 end), 2));
  end loop;
  v_total := round(v_total + v_acr, 2);

  -- grava tudo$q$); if d = o then raise exception 'trecho 2 não encontrado em public.api_iniciar_venda(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$desconto_detalhe, origem, mesa_id, taxa_entrega, registrado_por, caixa_id, requisicao_id)$q$, $q$desconto_detalhe, origem, mesa_id, taxa_entrega, registrado_por, caixa_id, requisicao_id, acrescimo_forma)$q$); if d = o then raise exception 'trecho 3 não encontrado em public.api_iniciar_venda(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$v_taxa, v_eu, v_caixa, v_req)$q$, $q$v_taxa, v_eu, v_caixa, v_req, v_acr)$q$); if d = o then raise exception 'trecho 4 não encontrado em public.api_iniciar_venda(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada)$q$, $q$insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo)$q$); if d = o then raise exception 'trecho 5 não encontrado em public.api_iniciar_venda(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$select v_venda, btrim(e->>'forma'), _num(e->>'valor'),$q$, $q$select v_venda, btrim(e->>'forma'), _num(e->>'valor') + _acrescimo_pagamento(e->>'forma', _num(e->>'valor')),$q$); if d = o then raise exception 'trecho 6 não encontrado em public.api_iniciar_venda(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$coalesce((select round(_num(e->>'valor') * f.taxa_percentual / 100 + f.taxa_fixa, 2) from formas_pagamento f where f.nome = btrim(e->>'forma')), 0)$q$, $q$coalesce((select round((_num(e->>'valor') + _acrescimo_pagamento(e->>'forma', _num(e->>'valor'))) * f.taxa_percentual / 100 + f.taxa_fixa, 2) from formas_pagamento f where f.nome = btrim(e->>'forma')), 0),
         _acrescimo_pagamento(e->>'forma', _num(e->>'valor'))$q$); if d = o then raise exception 'trecho 7 não encontrado em public.api_iniciar_venda(jsonb) (talvez já aplicado)'; end if; o := d;
  execute d;
end $do$;

do $do$ declare d text; o text;
begin
  d := pg_get_functiondef('public.api_fechar_conta_mesa(jsonb)'::regprocedure); o := d;
  d := replace(d, $q$parte numeric; forma formas_pagamento;$q$, $q$parte numeric; forma formas_pagamento; share numeric; acr_v numeric; acr_p numeric; acr_all numeric := 0;$q$); if d = o then raise exception 'trecho 1 não encontrado em public.api_fechar_conta_mesa(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$    update vendas set forma_pagamento = resumo, status_pagamento = 'Pago', recebido_em = now() where id = v.id;$q$, $q$    share := case when total > 0 then v.valor_total / total else 1.0 / array_length(ids, 1) end;
    acr_v := 0;$q$); if d = o then raise exception 'trecho 2 não encontrado em public.api_fechar_conta_mesa(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$      parte := round(_num(pg.e->>'valor') * (case when total > 0 then v.valor_total / total else 1.0 / array_length(ids, 1) end), 2);$q$, $q$      -- os valores enviados são a parte da conta paga em cada forma (sem acréscimo); o acréscimo da forma é somado aqui
      parte := round(_num(pg.e->>'valor') * share, 2);
      acr_p := round(_acrescimo_pagamento(pg.e->>'forma', _num(pg.e->>'valor')) * share, 2);
      acr_v := acr_v + acr_p;$q$); if d = o then raise exception 'trecho 3 não encontrado em public.api_fechar_conta_mesa(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada) values (v.id, btrim(pg.e->>'forma'), parte, coalesce((select round(parte * f.taxa_percentual / 100 + f.taxa_fixa, 2) from formas_pagamento f where lower(f.nome) = lower(btrim(pg.e->>'forma'))), 0));
    end loop;$q$, $q$insert into pagamentos_venda (venda_id, forma_pagamento, valor, taxa_aplicada, acrescimo) values (v.id, btrim(pg.e->>'forma'), parte + acr_p, coalesce((select round((parte + acr_p) * f.taxa_percentual / 100 + f.taxa_fixa, 2) from formas_pagamento f where lower(f.nome) = lower(btrim(pg.e->>'forma'))), 0), acr_p);
    end loop;
    update vendas set forma_pagamento = resumo, status_pagamento = 'Pago', recebido_em = now(), valor_total = v.valor_total + acr_v, acrescimo_forma = acr_v where id = v.id;
    acr_all := acr_all + acr_v;$q$); if d = o then raise exception 'trecho 4 não encontrado em public.api_fechar_conta_mesa(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$'Mesa ' || m.numero || ': R$ ' || _dinheiro(total) || ' | '$q$, $q$'Mesa ' || m.numero || ': R$ ' || _dinheiro(total + acr_all) || case when acr_all > 0 then ' (acréscimo R$ ' || _dinheiro(acr_all) || ')' else '' end || ' | '$q$); if d = o then raise exception 'trecho 5 não encontrado em public.api_fechar_conta_mesa(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$' fechada — R$ ' || _dinheiro(total) || '.'$q$, $q$' fechada — R$ ' || _dinheiro(total + acr_all) || '.'$q$); if d = o then raise exception 'trecho 6 não encontrado em public.api_fechar_conta_mesa(jsonb) (talvez já aplicado)'; end if; o := d;
  execute d;
end $do$;

do $do$ declare d text; o text;
begin
  d := pg_get_functiondef('public.api_editar_venda(jsonb)'::regprocedure); o := d;
  d := replace(d, $q$v_antes_aceite boolean; v_aviso text := '';$q$, $q$v_antes_aceite boolean; v_aviso text := ''; v_acr numeric := 0; v_forma_ed formas_pagamento%rowtype;$q$); if d = o then raise exception 'trecho 1 não encontrado em public.api_editar_venda(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$  v_total := round(v_soma - v.valor_desconto + v.taxa_entrega, 2);$q$, $q$  v_total := round(v_soma - v.valor_desconto + v.taxa_entrega, 2);
  -- o acréscimo da forma de pagamento acompanha o novo valor dos itens
  if v_npag = 1 then
    select * into v_forma_ed from formas_pagamento where lower(nome) = (select lower(forma_pagamento) from pagamentos_venda where venda_id = v.id limit 1) limit 1;
    if found then v_acr := _acrescimo_forma(v_forma_ed, greatest(0.01, v_total - v.taxa_entrega)); end if;
  end if;
  v_total := round(v_total + v_acr, 2);$q$); if d = o then raise exception 'trecho 2 não encontrado em public.api_editar_venda(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$update vendas set valor_total = v_total, custo_total = v_custo, valor_original = v_soma where id = v.id;$q$, $q$update vendas set valor_total = v_total, custo_total = v_custo, valor_original = v_soma, acrescimo_forma = v_acr where id = v.id;$q$); if d = o then raise exception 'trecho 3 não encontrado em public.api_editar_venda(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$update pagamentos_venda pv set valor = v_total,$q$, $q$update pagamentos_venda pv set valor = v_total, acrescimo = v_acr,$q$); if d = o then raise exception 'trecho 4 não encontrado em public.api_editar_venda(jsonb) (talvez já aplicado)'; end if; o := d;
  execute d;
end $do$;

do $do$ declare d text; o text;
begin
  d := pg_get_functiondef('public.api_add_forma_pagamento(jsonb)'::regprocedure); o := d;
  d := replace(d, $q$v_erro text; v_id uuid := gen_random_uuid(); v_ordem int; v_ref uuid;$q$, $q$v_erro text; v_id uuid := gen_random_uuid(); v_ordem int; v_ref uuid;
  v_ac_pct numeric := _num(p->>'acrescimoPct'); v_ac_fixo numeric := _num(p->>'acrescimoFixo');$q$); if d = o then raise exception 'trecho 1 não encontrado em public.api_add_forma_pagamento(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$  select coalesce(max(ordem), 0) + 1 into v_ordem from formas_pagamento;$q$, $q$  if v_ac_pct < 0 or v_ac_pct > 100 then return _falha('O acréscimo percentual deve ficar entre 0 e 100.'); end if;
  if v_ac_fixo < 0 or v_ac_fixo > 1000 then return _falha('O acréscimo fixo deve ficar entre R$ 0,00 e R$ 1.000,00.'); end if;
  select coalesce(max(ordem), 0) + 1 into v_ordem from formas_pagamento;$q$); if d = o then raise exception 'trecho 2 não encontrado em public.api_add_forma_pagamento(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$prazo_dias, permite_troco, ordem)$q$, $q$prazo_dias, permite_troco, ordem, acrescimo_percentual, acrescimo_fixo)$q$); if d = o then raise exception 'trecho 3 não encontrado em public.api_add_forma_pagamento(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$v_prazo::int, v_troco, v_ordem);$q$, $q$v_prazo::int, v_troco, v_ordem, v_ac_pct, v_ac_fixo);$q$); if d = o then raise exception 'trecho 4 não encontrado em public.api_add_forma_pagamento(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$case when v_troco then 'sim' else 'não' end);$q$, $q$case when v_troco then 'sim' else 'não' end || ' | acréscimo ' || v_ac_pct || '% + R$ ' || to_char(v_ac_fixo, 'FM999990.00'));$q$); if d = o then raise exception 'trecho 5 não encontrado em public.api_add_forma_pagamento(jsonb) (talvez já aplicado)'; end if; o := d;
  execute d;
end $do$;

do $do$ declare d text; o text;
begin
  d := pg_get_functiondef('public.api_editar_forma_pagamento(jsonb)'::regprocedure); o := d;
  d := replace(d, $q$v_erro text; v_novo text; v_mudou text := '';$q$, $q$v_erro text; v_novo text; v_mudou text := ''; v_apct numeric; v_afixo numeric;$q$); if d = o then raise exception 'trecho 1 não encontrado em public.api_editar_forma_pagamento(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$  v_novo := btrim(coalesce(p->>'novoNome', ''));$q$, $q$  v_apct  := case when p ? 'novoAcrescimoPct'  then _num(p->>'novoAcrescimoPct')  else f.acrescimo_percentual end;
  v_afixo := case when p ? 'novoAcrescimoFixo' then _num(p->>'novoAcrescimoFixo') else f.acrescimo_fixo end;
  if v_apct < 0 or v_apct > 100 then return _falha('O acréscimo percentual deve ficar entre 0 e 100.'); end if;
  if v_afixo < 0 or v_afixo > 1000 then return _falha('O acréscimo fixo deve ficar entre R$ 0,00 e R$ 1.000,00.'); end if;
  v_novo := btrim(coalesce(p->>'novoNome', ''));$q$); if d = o then raise exception 'trecho 2 não encontrado em public.api_editar_forma_pagamento(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$prazo_dias = v_prazo::int where id = f.id;$q$, $q$prazo_dias = v_prazo::int, acrescimo_percentual = v_apct, acrescimo_fixo = v_afixo where id = f.id;$q$); if d = o then raise exception 'trecho 3 não encontrado em public.api_editar_forma_pagamento(jsonb) (talvez já aplicado)'; end if; o := d;
  d := replace(d, $q$  perform _auditar('Forma de pagamento atualizada'$q$, $q$  if v_apct <> f.acrescimo_percentual then v_mudou := v_mudou || ' | acréscimo % ' || f.acrescimo_percentual || ' → ' || v_apct; end if;
  if v_afixo <> f.acrescimo_fixo then v_mudou := v_mudou || ' | acréscimo fixo R$ ' || to_char(f.acrescimo_fixo, 'FM999990.00') || ' → R$ ' || to_char(v_afixo, 'FM999990.00'); end if;
  perform _auditar('Forma de pagamento atualizada'$q$); if d = o then raise exception 'trecho 4 não encontrado em public.api_editar_forma_pagamento(jsonb) (talvez já aplicado)'; end if; o := d;
  execute d;
end $do$;

do $do$ declare d text; o text;
begin
  d := pg_get_functiondef('public.api_aplicar_preco_calculadora(jsonb)'::regprocedure); o := d;
  d := replace(d, $q$update produto_precos set preco = v_novo where produto_id = v_prod and forma_pagamento_id = v_forma;$q$, $q$update produto_precos set preco = v_novo where produto_id = v_prod;$q$); if d = o then raise exception 'trecho 1 não encontrado em public.api_aplicar_preco_calculadora(jsonb) (talvez já aplicado)'; end if; o := d;
  execute d;
end $do$;
