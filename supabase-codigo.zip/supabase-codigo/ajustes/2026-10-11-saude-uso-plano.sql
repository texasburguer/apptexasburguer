-- Saúde do sistema: uso do plano gratuito do Supabase (banco, arquivos, usuários ativos, chamadas às funções).
-- Só leitura. Cole no SQL Editor do Supabase e rode uma vez (pode repetir sem problema).
create or replace function public._saude_uso_plano()
returns jsonb language plpgsql stable security definer set search_path to 'public', 'cron' as $f$
declare
  v_banco numeric; v_arq numeric; v_mau int; v_edge_dia int; v_ia_dia int; v_proj numeric;
  itens jsonb := '[]'::jsonb;
begin
  select pg_database_size(current_database()) / 1048576.0 into v_banco;
  begin select coalesce(sum((metadata->>'size')::bigint), 0) / 1048576.0 into v_arq from storage.objects; exception when others then v_arq := null; end;
  begin select count(*) into v_mau from auth.users where last_sign_in_at > now() - interval '30 days'; exception when others then v_mau := null; end;
  -- chamadas às funções: tarefas automáticas que chamam funções (últimas 24 h) + chamadas de IA; iFood e nota fiscal só contam se ligados
  select count(*) into v_edge_dia from cron.job_run_details d join cron.job j on j.jobid = d.jobid
   where d.start_time > now() - interval '24 hours' and j.command ilike '%chamar_edge%'
     and (j.jobname not in ('ifood-sync-minuto') or public._integracao_ligada('ifood'))
     and (j.jobname not in ('nfce-emitir-minuto') or public._integracao_ligada('nfce'));
  select count(*) into v_ia_dia from ai_log where criado_em > now() - interval '24 hours';
  v_proj := (coalesce(v_edge_dia, 0) + coalesce(v_ia_dia, 0)) * 30;
  itens := itens || jsonb_build_object('id', 'uso_banco', 'titulo', 'Plano grátis: tamanho do banco',
    'nivel', case when v_banco >= 450 then 'problema' when v_banco >= 350 then 'atencao' else 'ok' end,
    'texto', replace(round(v_banco, 1)::text, '.', ',') || ' MB de 500 MB (' || replace(round(v_banco / 5, 1)::text, '.', ',') || '%).');
  if v_arq is not null then
    itens := itens || jsonb_build_object('id', 'uso_arquivos', 'titulo', 'Plano grátis: arquivos guardados',
      'nivel', case when v_arq >= 900 then 'problema' when v_arq >= 700 then 'atencao' else 'ok' end,
      'texto', replace(round(v_arq, 1)::text, '.', ',') || ' MB de 1 GB (' || replace(round(v_arq / 10.24, 1)::text, '.', ',') || '%).');
  end if;
  if v_mau is not null then
    itens := itens || jsonb_build_object('id', 'uso_usuarios', 'titulo', 'Plano grátis: usuários ativos no mês',
      'nivel', case when v_mau >= 45000 then 'problema' when v_mau >= 35000 then 'atencao' else 'ok' end,
      'texto', v_mau || ' de 50.000.');
  end if;
  itens := itens || jsonb_build_object('id', 'uso_funcoes', 'titulo', 'Plano grátis: chamadas às funções (estimativa)',
    'nivel', case when v_proj >= 450000 then 'problema' when v_proj >= 350000 then 'atencao' else 'ok' end,
    'texto', 'Cerca de ' || replace(to_char(round(v_proj), 'FM999G999G999'), ',', '.') || ' por mês, de 500.000 (' || replace(round(v_proj / 5000, 1)::text, '.', ',') || '%). Número aproximado, calculado pelas últimas 24 h; o oficial está no painel do Supabase (Settings → Usage).');
  return itens;
end $f$;
revoke all on function public._saude_uso_plano() from public, anon, authenticated;

-- Em api_saude_sistema, acrescente esta linha logo depois de "itens := itens || _saude_integracoes();" :
--   itens := itens || _saude_uso_plano();
-- (No projeto Texas Burger isso já foi aplicado. Nos outros: copie a definição atual de api_saude_sistema, acrescente a linha e rode.)
