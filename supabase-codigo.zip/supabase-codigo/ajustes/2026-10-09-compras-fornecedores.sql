-- =====================================================================
-- TEXAS BURGER — Compras e fornecedores (item 19) · 2026-10-09
-- Só Administrador/Desenvolvedor (tem_nivel('Admin')). Acesso às tabelas apenas pelas funções api_*.
-- Compra "Recebida" soma no estoque (custo médio ponderado), grava movimentação 'Entrada' e gera a despesa (Paga / A pagar).
-- A IA (ai-assistente V2.3) só PROPÕE; quem grava é o app, com o mesmo api_registrar_compra (origem 'ia'), após Confirmar.
-- Seguro para rodar de novo.
-- =====================================================================

create table if not exists public.fornecedores (
  id uuid primary key default gen_random_uuid(),
  nome text not null check (char_length(btrim(nome)) between 2 and 80),
  telefone text not null default '',
  observacao text not null default '',
  ativo boolean not null default true,
  criado_em timestamptz not null default now(),
  criado_por uuid references public.usuarios(id) on delete set null
);
create unique index if not exists fornecedores_nome_uq on public.fornecedores (lower(btrim(nome)));

create table if not exists public.compras (
  id uuid primary key default gen_random_uuid(),
  fornecedor_id uuid not null references public.fornecedores(id),
  data date not null default ((now() at time zone 'America/Sao_Paulo')::date),
  status text not null default 'Recebida' check (status in ('Pedido','Recebida','Cancelada')),
  pagamento text not null default 'Pago' check (pagamento in ('Pago','A pagar')),
  vencimento date,
  total numeric not null default 0 check (total >= 0),
  observacao text not null default '',
  despesa_id uuid references public.despesas(id) on delete set null,
  origem text not null default 'manual' check (origem in ('manual','ia')),
  recebida_em timestamptz,
  motivo_cancelamento text,
  requisicao_id text,
  criado_em timestamptz not null default now(),
  criado_por uuid references public.usuarios(id) on delete set null
);
create index if not exists compras_fornecedor_idx on public.compras (fornecedor_id, data desc);

create table if not exists public.compra_itens (
  id uuid primary key default gen_random_uuid(),
  compra_id uuid not null references public.compras(id) on delete cascade,
  ingrediente_id uuid references public.estoque(id) on delete set null,
  descricao text not null,
  quantidade numeric not null check (quantidade > 0),
  unidade text not null,
  valor_total numeric not null check (valor_total >= 0)
);
create index if not exists compra_itens_compra_idx on public.compra_itens (compra_id);

alter table public.fornecedores enable row level security;
alter table public.compras enable row level security;
alter table public.compra_itens enable row level security;
revoke all on public.fornecedores, public.compras, public.compra_itens from anon, authenticated;

CREATE OR REPLACE FUNCTION public._converter_unidade(p_qtd numeric, p_de text, p_para text)
 RETURNS numeric
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
  select case
    when lower(p_de) = lower(p_para) then p_qtd
    when lower(p_de) = 'kg' and lower(p_para) = 'g' then p_qtd * 1000
    when lower(p_de) = 'g' and lower(p_para) = 'kg' then p_qtd / 1000
    when lower(p_de) = 'l' and lower(p_para) = 'ml' then p_qtd * 1000
    when lower(p_de) = 'ml' and lower(p_para) = 'l' then p_qtd / 1000
    else null end
$function$;

CREATE OR REPLACE FUNCTION public._compra_receber(p_id uuid, p_pagamento text, p_venc date, p_saiu boolean)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare c compras%rowtype; i record; e estoque%rowtype; v_q numeric; v_custo numeric; v_forn text; v_desp uuid; v_hoje date := (now() at time zone 'America/Sao_Paulo')::date;
begin
  select * into c from compras where id = p_id for update;
  if not found then raise exception '%', 'Compra não encontrada.'; end if;
  if c.status <> 'Pedido' then raise exception '%', 'Esta compra já foi ' || lower(c.status) || '.'; end if;
  if p_pagamento = 'A pagar' and p_venc is null then raise exception '%', 'Informe o vencimento da conta a pagar.'; end if;
  select nome into v_forn from fornecedores where id = c.fornecedor_id;
  for i in select * from compra_itens where compra_id = c.id order by id loop
    if i.ingrediente_id is null then continue; end if;
    select * into e from estoque where id = i.ingrediente_id for update;
    if not found then continue; end if;
    v_q := _converter_unidade(i.quantidade, i.unidade, e.unidade::text);
    if v_q is null or v_q <= 0 then raise exception '%', 'A unidade "' || i.unidade || '" de ' || e.ingrediente || ' não combina com a do estoque (' || e.unidade || ').'; end if;
    v_custo := round((greatest(e.quantidade, 0) * e.custo_unitario + i.valor_total) / (greatest(e.quantidade, 0) + v_q), 6);
    update estoque set quantidade = e.quantidade + v_q, custo_unitario = v_custo where id = e.id;
    insert into movimentacoes_estoque (ingrediente_id, tipo, quantidade, qtd_antes, qtd_depois, motivo_referencia, usuario_id)
    values (e.id, 'Entrada', v_q, e.quantidade, e.quantidade + v_q, 'Compra de ' || v_forn || ' (R$ ' || _dinheiro(i.valor_total) || ')', auth.uid());
  end loop;
  if c.total > 0 then
    insert into despesas (data_hora, descricao, valor, observacao, status, categoria, vencimento, situacao, competencia, saiu_do_caixa)
    values (case when p_pagamento = 'A pagar' then _meio_dia(p_venc) else now() end, 'Compra: ' || v_forn, c.total, 'Compra ' || to_char(c.data, 'DD/MM/YYYY') || case when c.observacao <> '' then ' - ' || c.observacao else '' end,
            (case when p_pagamento = 'A pagar' then 'A pagar' else 'Paga' end)::status_despesa, _categoria_despesa('Insumos'), case when p_pagamento = 'A pagar' then p_venc end, case when p_pagamento = 'A pagar' then 'A pagar' else 'Paga' end,
            case when p_pagamento = 'A pagar' then to_char(p_venc, 'YYYY-MM') end, case when p_pagamento = 'Pago' then coalesce(p_saiu, false) else true end)
    returning id into v_desp;
  end if;
  update compras set status = 'Recebida', recebida_em = now(), pagamento = p_pagamento, vencimento = case when p_pagamento = 'A pagar' then p_venc end, despesa_id = v_desp where id = c.id;
  return null;
end $function$;

CREATE OR REPLACE FUNCTION public.api_salvar_fornecedor(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id'); v_nome text := btrim(coalesce(p->>'nome', '')); f fornecedores%rowtype;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if char_length(v_nome) < 2 or char_length(v_nome) > 80 then return _falha('Informe o nome do fornecedor (2 a 80 letras).'); end if;
  if exists (select 1 from fornecedores where lower(btrim(nome)) = lower(v_nome) and id is distinct from v_id) then return _falha('Já existe um fornecedor com esse nome.'); end if;
  if v_id is null then
    insert into fornecedores (nome, telefone, observacao, criado_por) values (v_nome, left(btrim(coalesce(p->>'telefone', '')), 30), left(btrim(coalesce(p->>'observacao', '')), 300), auth.uid()) returning * into f;
    perform _auditar('Fornecedor cadastrado', v_nome);
  else
    update fornecedores set nome = v_nome, telefone = left(btrim(coalesce(p->>'telefone', '')), 30), observacao = left(btrim(coalesce(p->>'observacao', '')), 300),
           ativo = case when p ? 'ativo' then coalesce(p->>'ativo', 'true') not in ('false', 'f') else ativo end
     where id = v_id returning * into f;
    if not found then return _falha('Fornecedor não encontrado.'); end if;
    perform _auditar('Fornecedor alterado', v_nome);
  end if;
  return jsonb_build_object('ok', true, 'message', 'Fornecedor salvo.', 'fornecedor', to_jsonb(f));
end $function$;

CREATE OR REPLACE FUNCTION public.api_registrar_compra(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_req text := nullif(p->>'requisicaoId', ''); v_r jsonb; v_forn uuid; v_fnome text; x jsonb; v_n int := 0; v_tot numeric := 0; v_id uuid := gen_random_uuid();
        v_status text := case when p->>'status' = 'Pedido' then 'Pedido' else 'Recebida' end; v_pg text := case when p->>'pagamento' = 'A pagar' then 'A pagar' else 'Pago' end;
        v_venc date := _data_iso(p->>'vencimento'); v_data date := coalesce(_data_iso(p->>'data'), (now() at time zone 'America/Sao_Paulo')::date);
        v_org text := case when p->>'origem' = 'ia' then 'ia' else 'manual' end; v_ing uuid; v_ie estoque%rowtype; v_val numeric; v_qtd numeric; v_un text; v_desc text; v_erro text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_req is not null then perform pg_advisory_xact_lock(hashtext(v_req)); v_r := _idem_ler(v_req); if v_r is not null then return v_r; end if; end if;
  if v_data > (now() at time zone 'America/Sao_Paulo')::date + 1 then return _falha('A data da compra não pode ser no futuro.'); end if;
  v_forn := _uuid(p->>'fornecedorId');
  if v_forn is null and btrim(coalesce(p->>'fornecedorNome', '')) <> '' then
    select id into v_forn from fornecedores where lower(btrim(nome)) = lower(btrim(p->>'fornecedorNome'));
    if v_forn is null then return _falha('Fornecedor "' || btrim(p->>'fornecedorNome') || '" não está cadastrado. Cadastre-o primeiro.'); end if;
  end if;
  select nome into v_fnome from fornecedores where id = v_forn and ativo;
  if v_fnome is null then return _falha('Escolha um fornecedor ativo.'); end if;
  if jsonb_typeof(p->'itens') <> 'array' or jsonb_array_length(p->'itens') = 0 then return _falha('Informe ao menos um item da compra.'); end if;
  if jsonb_array_length(p->'itens') > 30 then return _falha('No máximo 30 itens por compra.'); end if;
  if v_pg = 'A pagar' and v_status = 'Recebida' and v_venc is null then return _falha('Informe o vencimento da conta a pagar.'); end if;
  insert into compras (id, fornecedor_id, data, status, pagamento, vencimento, observacao, origem, requisicao_id, criado_por)
  values (v_id, v_forn, v_data, 'Pedido', v_pg, v_venc, left(btrim(coalesce(p->>'observacao', '')), 300), v_org, v_req, auth.uid());
  for x in select value from jsonb_array_elements(p->'itens') loop
    v_qtd := _num(x->>'quantidade'); v_val := round(_num(x->>'valorTotal'), 2); v_un := lower(btrim(coalesce(x->>'unidade', '')));
    v_ing := _uuid(x->>'ingredienteId'); v_desc := btrim(coalesce(x->>'descricao', x->>'ingrediente', ''));
    if v_ing is null and btrim(coalesce(x->>'ingrediente', '')) <> '' then
      select id into v_ing from estoque where lower(btrim(ingrediente)) = lower(btrim(x->>'ingrediente')) limit 1;
    end if;
    if v_ing is not null then
      select * into v_ie from estoque where id = v_ing;
      if not found then raise exception 'Ingrediente não encontrado no estoque.'; end if;
      if v_un = '' then v_un := v_ie.unidade::text; end if;
      if v_desc = '' then v_desc := v_ie.ingrediente; end if;
      if _converter_unidade(1, v_un, v_ie.unidade::text) is null then raise exception 'A unidade "%" não combina com a do estoque de % (%).', v_un, v_ie.ingrediente, v_ie.unidade; end if;
    elsif v_desc = '' then
      raise exception 'Cada item precisa de um nome ou de um ingrediente do estoque.';
    elsif btrim(coalesce(x->>'ingrediente', '')) <> '' and btrim(coalesce(x->>'descricao', '')) = '' then
      raise exception 'Ingrediente "%" não está no estoque. Cadastre-o em Estoque antes, ou informe só a descrição do item.', btrim(x->>'ingrediente');
    end if;
    if v_qtd <= 0 then raise exception 'Informe a quantidade de "%" maior que zero.', v_desc; end if;
    if v_val < 0 or v_val > 9999999 then raise exception 'Valor inválido em "%".', v_desc; end if;
    if v_un = '' then v_un := 'un'; end if;
    insert into compra_itens (compra_id, ingrediente_id, descricao, quantidade, unidade, valor_total) values (v_id, v_ing, left(v_desc, 80), v_qtd, left(v_un, 10), v_val);
    v_tot := v_tot + v_val; v_n := v_n + 1;
  end loop;
  update compras set total = round(v_tot, 2) where id = v_id;
  if v_status = 'Recebida' then perform _compra_receber(v_id, v_pg, v_venc, coalesce(p->>'saiuDoCaixa', '') in ('true', 't')); end if;
  perform _auditar('Compra registrada', v_fnome || ' | R$ ' || _dinheiro(v_tot) || ' | ' || v_n || ' item(ns) | ' || v_status || ' | ' || v_org);
  v_r := jsonb_build_object('ok', true, 'message', case when v_status = 'Recebida' then 'Compra registrada e estoque atualizado: R$ ' || _dinheiro(v_tot) else 'Pedido de compra registrado: R$ ' || _dinheiro(v_tot) end, 'id', v_id);
  if v_req is not null then perform _idem_gravar(v_req, 'registrarCompra', v_r); end if;
  return v_r;
exception when others then
  if sqlstate = 'P0001' then return _falha(sqlerrm); end if;
  raise;
end $function$;

CREATE OR REPLACE FUNCTION public.api_receber_compra(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id'); v_pg text := case when p->>'pagamento' = 'A pagar' then 'A pagar' else 'Pago' end; v_venc date := _data_iso(p->>'vencimento'); v_t numeric;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_id is null or not exists (select 1 from compras where id = v_id) then return _falha('Compra não encontrada.'); end if;
  perform _compra_receber(v_id, v_pg, v_venc, coalesce(p->>'saiuDoCaixa', '') in ('true', 't'));
  select total into v_t from compras where id = v_id;
  perform _auditar('Compra recebida', 'R$ ' || _dinheiro(v_t));
  return jsonb_build_object('ok', true, 'message', 'Compra recebida e estoque atualizado.');
exception when others then
  if sqlstate = 'P0001' then return _falha(sqlerrm); end if;
  raise;
end $function$;

CREATE OR REPLACE FUNCTION public.api_cancelar_compra(p jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare v_id uuid := _uuid(p->>'id'); c compras%rowtype; v_m text := left(btrim(coalesce(p->>'motivo', '')), 150);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into c from compras where id = v_id for update;
  if not found then return _falha('Compra não encontrada.'); end if;
  if c.status <> 'Pedido' then return _falha(case when c.status = 'Recebida' then 'Compra já recebida: o estoque e a despesa já foram lançados. Corrija em Estoque (inventário) e em Contas e despesas.' else 'Esta compra já foi cancelada.' end); end if;
  if v_m = '' then return _falha('Informe o motivo do cancelamento.'); end if;
  update compras set status = 'Cancelada', motivo_cancelamento = v_m where id = c.id;
  perform _auditar('Compra cancelada', v_m);
  return jsonb_build_object('ok', true, 'message', 'Pedido de compra cancelado.');
end $function$;

CREATE OR REPLACE FUNCTION public.api_listar_compras(p jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true,
    'fornecedores', coalesce((select jsonb_agg(to_jsonb(f) order by lower(f.nome)) from fornecedores f), '[]'::jsonb),
    'compras', coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'fornecedorId', c.fornecedor_id, 'fornecedor', f.nome, 'data', c.data, 'status', c.status, 'pagamento', c.pagamento,
        'vencimento', c.vencimento, 'total', c.total, 'observacao', c.observacao, 'origem', c.origem, 'motivoCancelamento', c.motivo_cancelamento,
        'itens', coalesce((select jsonb_agg(jsonb_build_object('descricao', i.descricao, 'quantidade', i.quantidade, 'unidade', i.unidade, 'valorTotal', i.valor_total, 'ingredienteId', i.ingrediente_id) order by i.id) from compra_itens i where i.compra_id = c.id), '[]'::jsonb))
        order by c.data desc, c.criado_em desc) from (select * from compras order by data desc, criado_em desc limit 300) c join fornecedores f on f.id = c.fornecedor_id), '[]'::jsonb));
end $function$;

-- as funções internas não são chamadas pelo app; as api_* ficam para o perfil logado (o nível é checado dentro de cada uma)
revoke all on function public._converter_unidade(numeric, text, text) from public, anon, authenticated;
revoke all on function public._compra_receber(uuid, text, date, boolean) from public, anon, authenticated;
revoke all on function public.api_salvar_fornecedor(jsonb), public.api_registrar_compra(jsonb), public.api_receber_compra(jsonb), public.api_cancelar_compra(jsonb), public.api_listar_compras(jsonb) from public, anon;
grant execute on function public.api_salvar_fornecedor(jsonb), public.api_registrar_compra(jsonb), public.api_receber_compra(jsonb), public.api_cancelar_compra(jsonb), public.api_listar_compras(jsonb) to authenticated;
