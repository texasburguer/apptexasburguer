-- =====================================================================
-- TEXAS BURGER — Preço base único + senha de administrador de verdade · 2026-10-09
-- 1) Cada produto/combo passa a ter UM preço (o menor que já tinha = preço base) em todas as formas.
--    O que muda por forma de pagamento (iFood, Alelo…) é o ACRÉSCIMO cadastrado em Pagamentos, somado no final da venda.
--    Os preços antigos ficam guardados em precos_backup_20261009 (para desfazer, se precisar).
-- 2) Aplicar preço da calculadora grava o preço base (vale para todas as formas) e funciona sem exigir a forma escolhida.
-- 3) A senha de administrador agora é conferida também quando quem está logado é Admin (se for informada),
--    e criar/excluir usuário e mudar senha/perfil/situação exigem a senha.
-- Seguro para rodar de novo.
-- =====================================================================
create table if not exists public.precos_backup_20261009 as
  select 'produto'::text as tipo, produto_id as item_id, forma_pagamento_id, preco, custo from public.produto_precos
  union all
  select 'combo', combo_id, forma_pagamento_id, preco, custo from public.combo_precos;
alter table public.precos_backup_20261009 enable row level security;

with base as (select distinct on (produto_id) produto_id, preco, custo from public.produto_precos order by produto_id, preco asc)
update public.produto_precos pp set preco = b.preco, custo = b.custo from base b where pp.produto_id = b.produto_id and (pp.preco <> b.preco or pp.custo <> b.custo);
with base as (select distinct on (combo_id) combo_id, preco, custo from public.combo_precos order by combo_id, preco asc)
update public.combo_precos cp set preco = b.preco, custo = b.custo from base b where cp.combo_id = b.combo_id and (cp.preco <> b.preco or cp.custo <> b.custo);

create or replace function public.api_aplicar_preco_calculadora(p jsonb)
 returns jsonb language plpgsql security definer set search_path to 'public' as $function$
declare v_novo numeric := round(_num(p->>'novoPreco'), 2); v_antigo numeric; v_prod uuid := _uuid(p->>'produtoId'); v_nome text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if not (v_novo > 0) then return _falha('Preço inválido.'); end if;
  select nome into v_nome from produtos where id = v_prod;
  if v_nome is null then return _falha('Produto não encontrado.'); end if;
  select min(preco) into v_antigo from produto_precos where produto_id = v_prod;
  if v_antigo is null then return _falha('Este produto ainda não tem preço cadastrado.'); end if;
  update produto_precos set preco = v_novo where produto_id = v_prod;
  perform _auditar('Preço base aplicado pela calculadora', v_nome || ' | R$ ' || _dinheiro(v_antigo) || ' → R$ ' || _dinheiro(v_novo) || ' (todas as formas; o acréscimo da forma é somado na venda)');
  return jsonb_build_object('ok', true, 'message', 'Preço base aplicado.');
end $function$;

create or replace function public._exige_admin(p_senha text)
 returns text language plpgsql security definer set search_path to 'public', 'auth', 'extensions' as $function$
declare v_eu usuarios%rowtype; v_chave text; v_adm record; v_ok boolean;
begin
  select * into v_eu from usuarios where id = auth.uid() and ativo;
  if not found then return null; end if;
  v_chave := 'falhas_admin_' || lower(v_eu.login);
  if v_eu.nivel::text in ('Admin','Desenvolvedor') then
    -- quem já é Admin: se informou senha, ela precisa ser a dele; sem senha, segue (telas que não pedem senha ao Admin)
    if coalesce(p_senha, '') <> '' then
      if _excedeu(v_chave, 5) then return null; end if;
      select (au.encrypted_password = crypt(p_senha, au.encrypted_password)) into v_ok from auth.users au where au.id = v_eu.id;
      if not coalesce(v_ok, false) then
        perform _registrar_falha(v_chave);
        perform _auditar('Falha na senha de administrador', 'Tentativa por ' || v_eu.login);
        return null;
      end if;
      perform _limpar_falhas(v_chave);
    end if;
    perform set_config('app.autorizador', v_eu.login, true);
    return v_eu.login;
  end if;
  if coalesce(p_senha, '') = '' then return null; end if;
  if _excedeu(v_chave, 5) then return null; end if;
  select us.login into v_adm from usuarios us join auth.users au on au.id = us.id
    where us.nivel in ('Admin','Desenvolvedor') and us.ativo and au.encrypted_password = crypt(p_senha, au.encrypted_password) limit 1;
  if found then
    perform _limpar_falhas(v_chave);
    perform set_config('app.autorizador', v_adm.login, true);
    return v_adm.login;
  end if;
  perform _registrar_falha(v_chave);
  perform _auditar('Falha na senha de administrador', 'Tentativa por ' || v_eu.login);
  return null;
end $function$;

-- senha obrigatória nas ações sensíveis de usuários (a função _exige_admin acima confere se estiver certa)
do $do$
declare d text; alvo text; trecho text := E'  v_aut := _exige_admin(p->>''senhaAdminConfirmacao'');';
begin
  foreach alvo in array array['api_criar_usuario','api_excluir_usuario','api_editar_usuario'] loop
    select pg_get_functiondef(p.oid) into d from pg_proc p where p.proname = alvo and p.pronamespace = 'public'::regnamespace;
    if d is not null and position('Informe a sua senha de administrador' in d) = 0 and position(trecho in d) > 0 then
      d := replace(d, trecho,
        case when alvo = 'api_editar_usuario'
          then E'  if (p ? ''novaSenha'' or p ? ''novoNivel'' or p ? ''novoAtivo'') and coalesce(p->>''senhaAdminConfirmacao'', '''') = '''' then return _falha(''Informe a sua senha de administrador para confirmar.''); end if;\n' || trecho
          else E'  if coalesce(p->>''senhaAdminConfirmacao'', '''') = '''' then return _falha(''Informe a sua senha de administrador para confirmar.''); end if;\n' || trecho end);
      execute d;
    end if;
  end loop;
end $do$;

-- Limpeza: cópia antiga da Ajuda (de 07/10), sem uso. Rode no SQL Editor se ainda existir.
drop table if exists public.ai_ajuda_bkp_20261007;
