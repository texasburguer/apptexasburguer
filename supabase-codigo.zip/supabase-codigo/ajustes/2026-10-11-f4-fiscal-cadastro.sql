-- =====================================================================================
-- FASE 4 — Cadastro fiscal (base da Nota Fiscal do Consumidor, NFC-e)
-- Tudo NASCE DESLIGADO: não muda nenhuma tela de venda nem nenhum cálculo enquanto a integração "nfce" estiver desligada.
-- Idempotente (pode rodar mais de uma vez). Depende da f0 (integracoes_*).
-- =====================================================================================

-- 1) o CSC (código de segurança do contribuinte) é guardado como segredo, igual às demais chaves
do $d$
declare c record;
begin
  for c in select conname from pg_constraint where conrelid = 'public.integracoes_segredos'::regclass and contype = 'c' and pg_get_constraintdef(oid) like '%chave%' loop
    execute format('alter table public.integracoes_segredos drop constraint %I', c.conname);
  end loop;
  alter table public.integracoes_segredos add constraint integracoes_segredos_chave_check
    check (chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id', 'nfce_token_homologacao', 'nfce_token_producao', 'nfce_csc'));
end $d$;

-- 2) dados fiscais da empresa (uma única linha)
create table if not exists public.fiscal_empresa (
  id boolean primary key default true check (id),
  razao_social text, nome_fantasia text, cnpj text, inscricao_estadual text,
  regime text not null default 'simples' check (regime in ('mei', 'simples', 'normal')),
  cep text, logradouro text, numero text, complemento text, bairro text,
  municipio text, codigo_municipio text, uf text, telefone text,
  csc_id text,                                   -- identificador do CSC (o código secreto fica em integracoes_segredos)
  serie int not null default 1 check (serie between 1 and 999),
  aliquota_simples numeric(5,2) not null default 0 check (aliquota_simples between 0 and 40),  -- % efetiva do Simples, só para ESTIMAR o imposto no resultado
  perfil_padrao_id uuid,
  atualizado_em timestamptz not null default now()
);
alter table public.fiscal_empresa enable row level security;
insert into public.fiscal_empresa (id) values (true) on conflict (id) do nothing;

-- 3) perfis fiscais (o contador define; vale para vários produtos)
create table if not exists public.fiscal_perfis (
  id uuid primary key default gen_random_uuid(),
  nome text not null unique,
  ncm text not null check (ncm ~ '^[0-9]{8}$'),
  cest text check (cest is null or cest ~ '^[0-9]{7}$'),
  cfop text not null default '5102' check (cfop ~ '^[0-9]{4}$'),
  csosn text check (csosn is null or csosn ~ '^[0-9]{3,4}$'),     -- Simples Nacional / MEI
  cst_icms text check (cst_icms is null or cst_icms ~ '^[0-9]{2}$'), -- regime normal
  origem text not null default '0' check (origem ~ '^[0-8]$'),
  unidade text not null default 'UN',
  pis_cst text not null default '49', cofins_cst text not null default '49',
  ativo boolean not null default true,
  criado_em timestamptz not null default now()
);
alter table public.fiscal_perfis enable row level security;
do $d$ begin
  if not exists (select 1 from pg_constraint where conname = 'fiscal_empresa_perfil_padrao_fk') then
    alter table public.fiscal_empresa add constraint fiscal_empresa_perfil_padrao_fk foreign key (perfil_padrao_id) references public.fiscal_perfis(id) on delete set null;
  end if;
end $d$;

alter table public.produtos add column if not exists perfil_fiscal_id uuid references public.fiscal_perfis(id) on delete set null;
alter table public.categorias add column if not exists perfil_fiscal_id uuid references public.fiscal_perfis(id) on delete set null;
alter table public.combos add column if not exists perfil_fiscal_id uuid references public.fiscal_perfis(id) on delete set null;

-- perfil que vale de verdade: do item; senão da categoria; senão o padrão da empresa
create or replace function public._perfil_fiscal_efetivo(p_produto uuid, p_combo uuid) returns uuid
 language sql stable security definer set search_path to 'public' as $f$
  select coalesce(
    case when p_produto is not null then (select coalesce(p.perfil_fiscal_id, c.perfil_fiscal_id) from produtos p left join categorias c on c.id = p.categoria_id where p.id = p_produto)
         else (select coalesce(b.perfil_fiscal_id, c.perfil_fiscal_id) from combos b left join categorias c on c.id = b.categoria_id where b.id = p_combo) end,
    (select perfil_padrao_id from fiscal_empresa where id))
$f$;

create or replace function public._fiscal_sem_perfil_qtd() returns int
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  return (select count(*) from produtos where ativo and public._perfil_fiscal_efetivo(id, null) is null)::int
       + (select count(*) from combos where ativo and public._perfil_fiscal_efetivo(null, id) is null)::int;
end $f$;

create or replace function public._fiscal_perfis_ok() returns boolean
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  return exists (select 1 from fiscal_perfis where ativo) and public._fiscal_sem_perfil_qtd() = 0;
end $f$;

create or replace function public._cnpj_valido(p text) returns boolean
 language plpgsql immutable as $f$
declare d int[]; s int; i int; pesos1 int[] := array[5,4,3,2,9,8,7,6,5,4,3,2]; pesos2 int[] := array[6,5,4,3,2,9,8,7,6,5,4,3,2];
begin
  if p is null or p !~ '^[0-9]{14}$' or p ~ '^(.)\1{13}$' then return false; end if;
  for i in 1..14 loop d[i] := substr(p, i, 1)::int; end loop;
  s := 0; for i in 1..12 loop s := s + d[i] * pesos1[i]; end loop; s := s % 11; s := case when s < 2 then 0 else 11 - s end;
  if s <> d[13] then return false; end if;
  s := 0; for i in 1..13 loop s := s + d[i] * pesos2[i]; end loop; s := s % 11; s := case when s < 2 then 0 else 11 - s end;
  return s = d[14];
end $f$;

create or replace function public._fiscal_empresa_ok() returns boolean
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  return coalesce((select _cnpj_valido(cnpj) and coalesce(razao_social, '') <> '' and coalesce(inscricao_estadual, '') <> '' and coalesce(logradouro, '') <> ''
                          and coalesce(numero, '') <> '' and coalesce(bairro, '') <> '' and coalesce(municipio, '') <> '' and codigo_municipio ~ '^[0-9]{7}$'
                          and uf ~ '^[A-Z]{2}$' and cep ~ '^[0-9]{8}$' and coalesce(csc_id, '') <> ''
                   from fiscal_empresa where id), false)
     and exists (select 1 from integracoes_segredos where chave = 'nfce_csc');
end $f$;


-- 4) telas do Administrador
create or replace function public.api_fiscal_empresa_ler(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare e fiscal_empresa%rowtype;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select * into e from fiscal_empresa where id;
  return jsonb_build_object('ok', true, 'empresa', to_jsonb(e) - 'id', 'temCsc', exists (select 1 from integracoes_segredos where chave = 'nfce_csc'),
    'completa', _fiscal_empresa_ok(), 'semPerfil', _fiscal_sem_perfil_qtd());
end $f$;

create or replace function public.api_fiscal_empresa_salvar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_cnpj text := regexp_replace(coalesce(p->>'cnpj', ''), '\D', '', 'g'); v_cep text := regexp_replace(coalesce(p->>'cep', ''), '\D', '', 'g');
  v_uf text := upper(btrim(coalesce(p->>'uf', ''))); v_ibge text := regexp_replace(coalesce(p->>'codigoMunicipio', ''), '\D', '', 'g');
  v_aliq numeric := coalesce(nullif(replace(coalesce(p->>'aliquotaSimples', '0'), ',', '.'), '')::numeric, 0); v_reg text := coalesce(nullif(p->>'regime', ''), 'simples');
  v_serie int := coalesce(nullif(p->>'serie', '')::int, 1);
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_cnpj <> '' and not _cnpj_valido(v_cnpj) then return _falha('CNPJ inválido. Confira os 14 números.'); end if;
  if v_cep <> '' and v_cep !~ '^[0-9]{8}$' then return _falha('CEP inválido (8 números).'); end if;
  if v_uf <> '' and v_uf !~ '^[A-Z]{2}$' then return _falha('Estado inválido (2 letras, ex.: SP).'); end if;
  if v_ibge <> '' and v_ibge !~ '^[0-9]{7}$' then return _falha('Código do município inválido (7 números, o contador informa).'); end if;
  if v_aliq < 0 or v_aliq > 40 then return _falha('Alíquota fora do esperado (0 a 40%).'); end if;
  if v_reg not in ('mei', 'simples', 'normal') then return _falha('Regime inválido.'); end if;
  if v_serie < 1 or v_serie > 999 then return _falha('Série inválida (1 a 999).'); end if;
  update fiscal_empresa set
    razao_social = left(btrim(coalesce(p->>'razaoSocial', '')), 120), nome_fantasia = left(btrim(coalesce(p->>'nomeFantasia', '')), 120),
    cnpj = nullif(v_cnpj, ''), inscricao_estadual = left(regexp_replace(coalesce(p->>'inscricaoEstadual', ''), '[^0-9A-Za-z]', '', 'g'), 20),
    regime = v_reg, cep = nullif(v_cep, ''), logradouro = left(btrim(coalesce(p->>'logradouro', '')), 120), numero = left(btrim(coalesce(p->>'numero', '')), 20),
    complemento = left(btrim(coalesce(p->>'complemento', '')), 60), bairro = left(btrim(coalesce(p->>'bairro', '')), 60), municipio = left(btrim(coalesce(p->>'municipio', '')), 60),
    codigo_municipio = nullif(v_ibge, ''), uf = nullif(v_uf, ''), telefone = left(regexp_replace(coalesce(p->>'telefone', ''), '\D', '', 'g'), 14),
    csc_id = left(regexp_replace(coalesce(p->>'cscId', ''), '\D', '', 'g'), 10), serie = v_serie, aliquota_simples = v_aliq, atualizado_em = now()
  where id;
  perform _auditar('Fiscal: dados da empresa salvos', coalesce(nullif(v_cnpj, ''), 'sem CNPJ'));
  return api_fiscal_empresa_ler('{}') || jsonb_build_object('message', 'Dados fiscais salvos.');
end $f$;

create or replace function public.api_fiscal_perfis(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'padraoId', (select perfil_padrao_id from fiscal_empresa where id),
    'perfis', coalesce((select jsonb_agg(jsonb_build_object('id', f.id, 'nome', f.nome, 'ncm', f.ncm, 'cest', f.cest, 'cfop', f.cfop, 'csosn', f.csosn, 'cstIcms', f.cst_icms,
        'origem', f.origem, 'unidade', f.unidade, 'pisCst', f.pis_cst, 'cofinsCst', f.cofins_cst, 'ativo', f.ativo,
        'usos', (select count(*) from produtos x where x.perfil_fiscal_id = f.id) + (select count(*) from combos x where x.perfil_fiscal_id = f.id) + (select count(*) from categorias x where x.perfil_fiscal_id = f.id))
        order by f.nome) from fiscal_perfis f), '[]'::jsonb),
    'categorias', coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'nome', c.nome, 'perfilId', c.perfil_fiscal_id) order by c.ordem, c.nome) from categorias c where c.ativa), '[]'::jsonb),
    'semPerfil', _fiscal_sem_perfil_qtd());
end $f$;

create or replace function public.api_fiscal_perfil_salvar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_id uuid := nullif(p->>'id', '')::uuid; v_nome text := btrim(coalesce(p->>'nome', '')); v_ncm text := regexp_replace(coalesce(p->>'ncm', ''), '\D', '', 'g');
  v_cest text := nullif(regexp_replace(coalesce(p->>'cest', ''), '\D', '', 'g'), ''); v_cfop text := coalesce(nullif(regexp_replace(coalesce(p->>'cfop', ''), '\D', '', 'g'), ''), '5102');
  v_csosn text := nullif(regexp_replace(coalesce(p->>'csosn', ''), '\D', '', 'g'), ''); v_cst text := nullif(regexp_replace(coalesce(p->>'cstIcms', ''), '\D', '', 'g'), '');
  v_origem text := coalesce(nullif(p->>'origem', ''), '0'); v_un text := upper(left(coalesce(nullif(btrim(p->>'unidade'), ''), 'UN'), 6));
  v_reg text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_nome = '' then return _falha('Dê um nome ao perfil (ex.: Lanches, Bebidas).'); end if;
  if v_ncm !~ '^[0-9]{8}$' then return _falha('NCM precisa ter 8 números (o contador informa).'); end if;
  if v_cest is not null and v_cest !~ '^[0-9]{7}$' then return _falha('CEST precisa ter 7 números (ou deixe em branco).'); end if;
  if v_cfop !~ '^[0-9]{4}$' then return _falha('CFOP precisa ter 4 números.'); end if;
  if v_origem !~ '^[0-8]$' then return _falha('Origem inválida (0 a 8).'); end if;
  select regime into v_reg from fiscal_empresa where id;
  if v_reg in ('mei', 'simples') and v_csosn is null then return _falha('Para Simples/MEI informe o CSOSN (o contador informa, ex.: 102).'); end if;
  if v_reg = 'normal' and v_cst is null then return _falha('Para o regime normal informe o CST do ICMS.'); end if;
  if v_id is null then
    insert into fiscal_perfis (nome, ncm, cest, cfop, csosn, cst_icms, origem, unidade, ativo) values (v_nome, v_ncm, v_cest, v_cfop, v_csosn, v_cst, v_origem, v_un, coalesce((p->>'ativo')::boolean, true));
  else
    update fiscal_perfis set nome = v_nome, ncm = v_ncm, cest = v_cest, cfop = v_cfop, csosn = v_csosn, cst_icms = v_cst, origem = v_origem, unidade = v_un, ativo = coalesce((p->>'ativo')::boolean, ativo) where id = v_id;
    if not found then return _falha('Perfil não encontrado.'); end if;
  end if;
  perform _auditar('Fiscal: perfil salvo', v_nome);
  return api_fiscal_perfis('{}') || jsonb_build_object('message', 'Perfil salvo.');
exception when unique_violation then return _falha('Já existe um perfil com esse nome.');
end $f$;

create or replace function public.api_fiscal_perfil_excluir(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_id uuid := (p->>'id')::uuid; v_nome text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  select nome into v_nome from fiscal_perfis where id = v_id;
  if v_nome is null then return _falha('Perfil não encontrado.'); end if;
  if exists (select 1 from produtos where perfil_fiscal_id = v_id) or exists (select 1 from combos where perfil_fiscal_id = v_id) or exists (select 1 from categorias where perfil_fiscal_id = v_id)
     or exists (select 1 from fiscal_empresa where perfil_padrao_id = v_id) then
    return _falha('Este perfil está em uso. Troque o perfil dos itens antes de excluir (ou desative o perfil).');
  end if;
  delete from fiscal_perfis where id = v_id;
  perform _auditar('Fiscal: perfil excluído', v_nome);
  return api_fiscal_perfis('{}') || jsonb_build_object('message', 'Perfil excluído.');
end $f$;

-- atribuir: alvo = produto | combo | categoria | padrao ; perfilId nulo = voltar a herdar
create or replace function public.api_fiscal_atribuir(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_alvo text := p->>'alvo'; v_id uuid := nullif(p->>'id', '')::uuid; v_perf uuid := nullif(p->>'perfilId', '')::uuid; v_n int := 0; v_ids uuid[];
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_perf is not null and not exists (select 1 from fiscal_perfis where id = v_perf and ativo) then return _falha('Perfil não encontrado ou desativado.'); end if;
  if v_alvo = 'padrao' then update fiscal_empresa set perfil_padrao_id = v_perf, atualizado_em = now() where id;
  elsif v_alvo = 'categoria' then update categorias set perfil_fiscal_id = v_perf where id = v_id; get diagnostics v_n = row_count;
  elsif v_alvo = 'produto' then update produtos set perfil_fiscal_id = v_perf where id = v_id; get diagnostics v_n = row_count;
  elsif v_alvo = 'combo' then update combos set perfil_fiscal_id = v_perf where id = v_id; get diagnostics v_n = row_count;
  elsif v_alvo = 'lote' then   -- vários itens de uma vez: ids = [{tipo,id}]
    update produtos set perfil_fiscal_id = v_perf where id in (select (x->>'id')::uuid from jsonb_array_elements(coalesce(p->'ids', '[]')) x where x->>'tipo' = 'produto');
    get diagnostics v_n = row_count;
    update combos set perfil_fiscal_id = v_perf where id in (select (x->>'id')::uuid from jsonb_array_elements(coalesce(p->'ids', '[]')) x where x->>'tipo' = 'combo');
  else return _falha('Destino inválido.'); end if;
  if v_alvo <> 'padrao' and v_alvo <> 'lote' and v_n = 0 then return _falha('Item não encontrado.'); end if;
  perform _auditar('Fiscal: perfil atribuído', v_alvo || coalesce(' · ' || v_id::text, ''));
  return api_fiscal_perfis('{}') || jsonb_build_object('message', 'Perfil atribuído.');
end $f$;

create or replace function public.api_fiscal_sem_perfil(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'itens', coalesce((
    select jsonb_agg(x order by x->>'nome') from (
      select jsonb_build_object('tipo', 'produto', 'id', id, 'nome', nome, 'categoria', (select nome from categorias c where c.id = produtos.categoria_id)) x from produtos where ativo and _perfil_fiscal_efetivo(id, null) is null
      union all
      select jsonb_build_object('tipo', 'combo', 'id', id, 'nome', nome, 'categoria', (select nome from categorias c where c.id = combos.categoria_id)) from combos where ativo and _perfil_fiscal_efetivo(null, id) is null) t), '[]'::jsonb));
end $f$;

-- planilha para o contador: uma linha por produto/combo, com o perfil efetivo e todos os campos fiscais
create or replace function public.api_fiscal_exportar(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  return jsonb_build_object('ok', true, 'linhas', coalesce((
    select jsonb_agg(x order by x->>'tipo', x->>'nome') from (
      select jsonb_build_object('tipo', 'produto', 'id', pr.id, 'nome', pr.nome, 'categoria', c.nome, 'perfil', f.nome, 'ncm', f.ncm, 'cest', f.cest, 'cfop', f.cfop, 'csosn', f.csosn, 'cstIcms', f.cst_icms, 'origem', f.origem, 'unidade', f.unidade) x
        from produtos pr left join categorias c on c.id = pr.categoria_id left join fiscal_perfis f on f.id = _perfil_fiscal_efetivo(pr.id, null) where pr.ativo
      union all
      select jsonb_build_object('tipo', 'combo', 'id', b.id, 'nome', b.nome, 'categoria', c.nome, 'perfil', f.nome, 'ncm', f.ncm, 'cest', f.cest, 'cfop', f.cfop, 'csosn', f.csosn, 'cstIcms', f.cst_icms, 'origem', f.origem, 'unidade', f.unidade)
        from combos b left join categorias c on c.id = b.categoria_id left join fiscal_perfis f on f.id = _perfil_fiscal_efetivo(null, b.id) where b.ativo) t), '[]'::jsonb));
end $f$;

-- importar a planilha devolvida pelo contador: cria/atualiza perfis pelo NOME e liga cada item ao perfil pelo nome
create or replace function public.api_fiscal_importar(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare x jsonb; v_ok int := 0; v_ign int := 0; v_msgs text[] := '{}'; v_nome text; v_perf uuid; v_id uuid; v_reg text; v_ncm text; v_csosn text; v_cst text;
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if jsonb_array_length(coalesce(p->'linhas', '[]')) > 3000 then return _falha('Planilha grande demais (máx. 3000 linhas).'); end if;
  select regime into v_reg from fiscal_empresa where id;
  for x in select * from jsonb_array_elements(coalesce(p->'linhas', '[]')) loop
    v_nome := btrim(coalesce(x->>'perfil', ''));
    v_ncm := regexp_replace(coalesce(x->>'ncm', ''), '\D', '', 'g');
    v_csosn := nullif(regexp_replace(coalesce(x->>'csosn', ''), '\D', '', 'g'), '');
    v_cst := nullif(regexp_replace(coalesce(x->>'cstIcms', ''), '\D', '', 'g'), '');
    if v_nome = '' or v_ncm !~ '^[0-9]{8}$' or (v_reg <> 'normal' and v_csosn is null) or (v_reg = 'normal' and v_cst is null) then
      v_ign := v_ign + 1; if array_length(v_msgs, 1) is null or array_length(v_msgs, 1) < 8 then v_msgs := v_msgs || ('Ignorada: ' || left(coalesce(x->>'nome', '?'), 40)); end if; continue;
    end if;
    insert into fiscal_perfis (nome, ncm, cest, cfop, csosn, cst_icms, origem, unidade)
      values (v_nome, v_ncm, nullif(regexp_replace(coalesce(x->>'cest', ''), '\D', '', 'g'), ''), coalesce(nullif(regexp_replace(coalesce(x->>'cfop', ''), '\D', '', 'g'), ''), '5102'), v_csosn, v_cst,
              coalesce(nullif(x->>'origem', ''), '0'), upper(left(coalesce(nullif(btrim(x->>'unidade'), ''), 'UN'), 6)))
      on conflict (nome) do update set ncm = excluded.ncm, cest = excluded.cest, cfop = excluded.cfop, csosn = excluded.csosn, cst_icms = excluded.cst_icms, origem = excluded.origem, unidade = excluded.unidade
      returning id into v_perf;
    begin v_id := nullif(x->>'id', '')::uuid; exception when others then v_id := null; end;
    if v_id is not null then
      if x->>'tipo' = 'combo' then update combos set perfil_fiscal_id = v_perf where id = v_id;
      elsif x->>'tipo' = 'produto' then update produtos set perfil_fiscal_id = v_perf where id = v_id; end if;
    end if;
    v_ok := v_ok + 1;
  end loop;
  perform _auditar('Fiscal: planilha do contador importada', v_ok || ' linhas, ' || v_ign || ' ignoradas');
  return api_fiscal_perfis('{}') || jsonb_build_object('message', v_ok || ' linha(s) aplicada(s)' || case when v_ign > 0 then ', ' || v_ign || ' ignorada(s) (faltava perfil, NCM ou CSOSN)' else '' end || '.', 'ignoradas', to_jsonb(v_msgs));
end $f$;

-- 5) funções já existentes que ganham o novo comportamento (só efeito com a integração ligada)
create or replace function public.api_integracoes_salvar_segredo(p jsonb) returns jsonb
 language plpgsql security definer set search_path to 'public' as $f$
declare v_chave text := p->>'chave'; v_valor text := btrim(coalesce(p->>'valor', ''));
begin
  if not tem_nivel('Admin') then return _negado(); end if;
  if v_chave not in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id', 'nfce_token_homologacao', 'nfce_token_producao', 'nfce_csc') then return _falha('Campo desconhecido.'); end if;
  if coalesce(p->>'senhaAdmin', '') = '' then return _falha('Informe a sua senha de administrador.'); end if;
  if _exige_admin(p->>'senhaAdmin') is null then return _falha('Senha de administrador incorreta.'); end if;
  if length(v_valor) < 8 or length(v_valor) > 400 or v_valor ~ '\s' then return _falha('Valor inválido. Copie inteiro, sem espaços.'); end if;
  insert into integracoes_segredos (chave, valor, atualizado_em) values (v_chave, v_valor, now())
    on conflict (chave) do update set valor = excluded.valor, atualizado_em = now();
  perform _auditar('Integração: chave salva', v_chave);
  return api_integracoes_status('{}') || jsonb_build_object('message', 'Salvo.');
end $f$;

create or replace function public.api_integracoes_flags(p jsonb default '{}'::jsonb) returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
begin
  if auth_nivel() is null then return _negado(); end if;
  return jsonb_build_object('ok', true, 'ifood', _integracao_ligada('ifood'), 'nfce', _integracao_ligada('nfce'),
    'nfceModo', (select modo from integracoes_config where provedor = 'nfce'),
    'impostoPct', case when _integracao_ligada('nfce') then coalesce((select aliquota_simples from fiscal_empresa where id), 0) else 0 end);
end $f$;

create or replace function public._integ_pendencias(p_prov text, p_modo text) returns text[]
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v_out text[] := '{}'; v_item jsonb; v_ck jsonb; v_ok boolean;
begin
  select checklist into v_ck from integracoes_config where provedor = p_prov;
  for v_item in select * from jsonb_array_elements(_integ_checklist_def(p_prov)) loop
    if coalesce((v_item->>'auto')::boolean, false) then
      v_ok := case v_item->>'id'
        when 'chaves' then (select count(*) from integracoes_segredos where chave in ('ifood_client_id', 'ifood_client_secret', 'ifood_merchant_id')) = 3
        when 'token' then exists (select 1 from integracoes_segredos where chave = 'nfce_token_' || p_modo)
        when 'empresa' then public._fiscal_empresa_ok()
        when 'perfis' then public._fiscal_perfis_ok()
        else coalesce((v_ck->>(v_item->>'id'))::boolean, false) end;
    else
      v_ok := coalesce((v_ck->>(v_item->>'id'))::boolean, false);
    end if;
    if not v_ok then v_out := v_out || (v_item->>'titulo'); end if;
  end loop;
  return v_out;
end $f$;

create or replace function public._saude_integracoes() returns jsonb
 language plpgsql stable security definer set search_path to 'public' as $f$
declare v jsonb := '[]'::jsonb; r record; v_desc int; e ifood_estado%rowtype; v_min numeric; v_sem int; v_novos int; v_acoes int; v_nivel text; v_txt text; v_urg int;
begin
  if exists (select 1 from ai_segredos where provedor = 'nvidia') or exists (select 1 from ai_segredos where provedor = 'cloudflare') then
    select count(*) into v_desc from unnest(array['nvidia', 'cloudflare']) x(p) where _ia_provedor_descansando(x.p);
    v := v || jsonb_build_object('id', 'ia_extras', 'titulo', 'IAs de reserva (NVIDIA / Cloudflare)', 'nivel', case when v_desc > 0 then 'atencao' else 'ok' end,
      'texto', (select string_agg(x.rot || ': ' || case when not exists (select 1 from ai_segredos where provedor = x.p) then 'sem chave' when _ia_provedor_descansando(x.p) then 'descansando (erros recentes)' else 'pronta' end, ' · ')
                from (values ('nvidia', 'NVIDIA'), ('cloudflare', 'Cloudflare')) x(p, rot)));
  end if;
  if _integracao_ligada('ifood') then
    select * into e from ifood_estado where id;
    v_min := case when e.ultima_consulta_ok is null then null else extract(epoch from (now() - e.ultima_consulta_ok)) / 60 end;
    select coalesce(sum(itens_sem_ligacao), 0) into v_sem from ifood_pedidos where estado <> 'cancelado' and criado_em > now() - interval '7 days';
    select count(*) into v_novos from ifood_pedidos where estado = 'novo' and not simulado and criado_em < now() - interval '4 minutes';
    select count(*) into v_acoes from ifood_acoes where estado in ('erro', 'duvida') and criado_em > now() - interval '1 day';
    select count(*) into v_urg from ifood_negociacoes where estado = 'aberta' and expira_em > now() and expira_em < now() + interval '3 minutes';
    v_nivel := case when v_min is null or v_min > 2 or e.token_ok is false or v_novos > 0 or v_urg > 0 then 'problema' when v_acoes > 0 or v_sem > 0 or e.ultimo_erro is not null or exists (select 1 from ifood_negociacoes where estado = 'aberta' and expira_em > now()) then 'atencao' else 'ok' end;
    v_txt := case when v_min is null then 'Ligado, mas ainda sem nenhuma consulta bem-sucedida ao iFood.' else 'Última consulta ao iFood há ' || round(v_min, 1) || ' min' end
      || case when e.ultimo_pedido_em is not null then ' · último pedido às ' || to_char(e.ultimo_pedido_em at time zone 'America/Sao_Paulo', 'DD/MM HH24:MI') else ' · nenhum pedido ainda' end
      || case when e.token_ok is false then ' · ACESSO RECUSADO (confira as chaves)' else '' end
      || case when v_novos > 0 then ' · ' || v_novos || ' pedido(s) esperando confirmação há mais de 4 min' else '' end
      || case when v_acoes > 0 then ' · ' || v_acoes || ' ação(ões) não confirmada(s) no iFood' else '' end
      || case when v_sem > 0 then ' · ' || v_sem || ' item(ns) sem ligação' else '' end || public._saude_ifood_extra();
    v := v || jsonb_build_object('id', 'ifood', 'titulo', 'iFood', 'nivel', v_nivel, 'texto', v_txt);
  end if;
  for r in select * from integracoes_config where ligado and provedor = 'nfce' loop
    v := v || jsonb_build_object('id', 'nfce', 'titulo', 'Nota fiscal (NFC-e)', 'nivel',
      'atencao',
      'texto', 'Ligada (' || r.modo || '), aguardando a primeira nota.' || case when public._fiscal_sem_perfil_qtd() > 0 then ' · ' || public._fiscal_sem_perfil_qtd() || ' item(ns) sem perfil fiscal' else '' end);
  end loop;
  return v;
end $f$;

-- 6) permissões
revoke execute on function public._perfil_fiscal_efetivo(uuid, uuid), public._fiscal_sem_perfil_qtd(), public._fiscal_perfis_ok(), public._fiscal_empresa_ok(), public._cnpj_valido(text) from public, anon, authenticated;
revoke execute on function public.api_fiscal_empresa_ler(jsonb), public.api_fiscal_empresa_salvar(jsonb), public.api_fiscal_perfis(jsonb), public.api_fiscal_perfil_salvar(jsonb), public.api_fiscal_perfil_excluir(jsonb),
  public.api_fiscal_atribuir(jsonb), public.api_fiscal_sem_perfil(jsonb), public.api_fiscal_exportar(jsonb), public.api_fiscal_importar(jsonb) from public, anon;
grant execute on function public.api_fiscal_empresa_ler(jsonb), public.api_fiscal_empresa_salvar(jsonb), public.api_fiscal_perfis(jsonb), public.api_fiscal_perfil_salvar(jsonb), public.api_fiscal_perfil_excluir(jsonb),
  public.api_fiscal_atribuir(jsonb), public.api_fiscal_sem_perfil(jsonb), public.api_fiscal_exportar(jsonb), public.api_fiscal_importar(jsonb) to authenticated;
grant execute on function public._fiscal_empresa_ok(), public._fiscal_perfis_ok(), public._fiscal_sem_perfil_qtd(), public._perfil_fiscal_efetivo(uuid, uuid) to service_role;

insert into ai_ajuda (slug,titulo,palavras_chave,passos,perfis,ativo,grupo,ordem,comuns)
select 'man-admin-106-fiscal-cadastro','Nota fiscal: dados da empresa e perfis fiscais','nota fiscal nfc-e cadastro fiscal perfil ncm csosn cfop contador cnpj csc imposto simples',
 E'Contas e acessos → Integrações → Nota fiscal → "Dados fiscais": preencha razão social, CNPJ, inscrição estadual, endereço, código do município (7 números), regime, número do CSC e a alíquota efetiva do Simples (o contador informa). O código secreto do CSC é digitado no botão do próprio cartão, nunca por mensagem.\nPerfis fiscais: cada perfil reúne NCM, CFOP e CSOSN (ou CST). Crie poucos (ex.: Lanches, Bebidas, Sobremesas), marque um como padrão e ligue categorias/itens que sejam exceção. "Itens sem perfil" lista o que ainda falta.\nPlanilha do contador: "Baixar planilha" gera um arquivo com todos os produtos; o contador preenche perfil, NCM, CSOSN e CFOP, e "Enviar planilha" aplica tudo de uma vez.\nCom a nota fiscal ligada, o resultado do período (DRE) passa a mostrar a linha "Impostos sobre vendas (estimado)". Desligada, nada muda.',
 array['Admin'],true,'lista',106,'Só Administrador.'
where not exists (select 1 from ai_ajuda where slug='man-admin-106-fiscal-cadastro');
