-- 45: dados cadastrais do restaurante (CNPJ, razão social e endereço da Receita) no Aviso de Privacidade e em Dados fiscais da empresa. Idempotente.
insert into sistema (chave, valor) values ('RestauranteCnpj', to_jsonb('68.769.166/0001-00'::text)) on conflict (chave) do update set valor = excluded.valor;
insert into sistema (chave, valor) values ('RestauranteRazaoSocial', to_jsonb('68.769.166 YASMIN CAROLINE PAULINO'::text)) on conflict (chave) do update set valor = excluded.valor;
insert into fiscal_empresa (id, cnpj, razao_social, cep, bairro, municipio, codigo_municipio, uf, regime)
values (true, '68769166000100', '68.769.166 YASMIN CAROLINE PAULINO', '14700410', 'CENTRO', 'BEBEDOURO', '3506102', 'SP', 'mei')
on conflict (id) do update set cnpj = excluded.cnpj, razao_social = excluded.razao_social, cep = excluded.cep, bairro = excluded.bairro, municipio = excluded.municipio, codigo_municipio = excluded.codigo_municipio, uf = excluded.uf, regime = excluded.regime, atualizado_em = now();
